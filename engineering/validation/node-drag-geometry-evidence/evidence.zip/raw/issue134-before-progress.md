> 命名说明：本功能在 Motion Studio 中统一称为“效果搜索”。后续实现使用 `EffectSearch` 状态类型、`effect_search` 字段与模块、`EFFECT_SEARCH` 快捷键常量；命名整理位于待合并分支 `fix/desktop-quick-issues`，尚未进入主分支。下文固定提交的代码摘录、旧文件路径和行号保留为历史证据。

核验日期：2026-10-12

核验基线：[1771a00](https://github.com/Yukk1o/motion-studio/commit/1771a006104952d2ca7e47df004e729724239b89)，位于 `codex/desktop-shortcuts-20261011`、领先 main；结论仅对该提交成立

## 已核验现状

面板层在同一帧内重复执行只在状态变化时才需要的工作。以下均已核验到具体调用点。

### 一、每个有输入的帧整个工作区绘制两遍

[shell/presentation.rs:305-326](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/app/src/shell/presentation.rs#L305-L326)

```rust
let (mut paint, actions) = self.draw_commands(size);
self.actions.extend(actions);
if !self.actions.is_empty() { return Ok(()); }
if self.dirty && self.dialog.is_none() && self.node_close_prompt.is_none() && self.node_examples.is_none() {
    let neutral = Input { mouse: self.input.mouse, held: self.input.held, modifiers: self.input.modifiers, ..Default::default() };
    paint = PaintList::default();
    let _ = panels::chrome(&mut paint, ..., &mut self.panels, &self.state, &neutral);
}
```

需要澄清一点：第二遍的 `neutral` **保留了** `mouse` / `held` / `modifiers`，因此拖拽、悬停与平移不会因此失效——面板不会因为这次双绘制而失去交互。但 `released` / `pressed` / `keys` / `text` / `wheel` 被 `..Default::default()` 清空，于是两遍面对的是**不同的输入**，而第二遍的结果是被提交的 `paint`。

- 成本：dock 求解、全部面板布局与绘制、全部标签、图标、时间轴行与画布网格，在拖拽帧与节点预览播放帧（`main.rs:704-729` 在 `node_preview.playing` 时以 16 ms 保持循环）都执行两遍
- 风险：面板绘制函数会改动交互状态，同一帧内执行两遍的第二个结果胜出。`node_editor::view::canvas` 的 `Drag::Cut` 分支会重复调用 `collect_cut_inputs`（`interaction.rs:289`），追加重复的断点；`Drag::Pan`（`interaction.rs:313`）以按下原点重算、幂等；`Drag::Marquee` 重算、幂等

### 二、dock 布局每帧求解八次，且分隔条循环逐字重复

`frames(layout, size)`（内含 `dock::solve` 并分配 `Vec<Frame>`）的调用点：`panels/mod.rs:198`、`panels/mod.rs:227`、`shell/presentation.rs:189`（`composition_view`）、`shell/presentation.rs:196`（`node_view`，其自身最多再调 2 次）、`main.rs:699`（每次 poll tick 的 `about_to_wait`）、`ui/workspace.rs:414` 与 `ui/workspace.rs:466`。

更直接的是分隔条循环在 `panels/mod.rs:345-368` 与 `panels/mod.rs:509-520` 各出现一次，二者使用**逐字相同**的

```rust
let layout_area = Rect::new(0., CHROME_HEIGHT, size[0], ...);
for handle in dock::splitters(layout, layout_area) { ... }
```

仅 hover 叠加层的处理不同。

### 三、时间轴每帧重建行与过滤树

见 [issue 127](https://github.com/MAD-Producer/motion-studio/issues/127) 第五节（`rows()` O(L²)、每行两次 `to_lowercase`、可见性剔除之前计算属性树、滚动上限急切求值）。此处不重复。

### 四、节点卡片规格每帧计算两遍

[node_editor/view/mod.rs:305-307](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/app/src/node_editor/view/mod.rs#L305-L307)

```rust
let cards = self.cards(layout.canvas);
self.canvas_input(&cards, layout.canvas, body_input);
let cards = self.cards(layout.canvas);   // 同一结果重算
self.paint_canvas(list, atlas, &cards, layout.canvas, input, language);
```

`cards()`（[view/canvas.rs:4-43](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/app/src/node_editor/view/canvas.rs#L4-L43)）分配 `Vec<Card>`、每节点一个 `Vec<Socket>`，并把节点 id 克隆进每个 `PortRef`，同时对每个节点调用 `motion_graph::node_port_specs`。叠加第一条，每帧执行四遍。

### 五、节点画布的二次复杂度与网格

[view/canvas.rs:132](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/app/src/node_editor/view/canvas.rs#L132) 的 `paint_canvas` 对每条连线执行 `find(&edge.from, …).zip(find(&edge.to, …))`，即 O(E·N·S)；[view/canvas.rs:253-259](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/app/src/node_editor/view/canvas.rs#L253-L259) 在拖线激活时对每个候选插口重扫所有卡片的所有插口，O((N·S)²)。

[view/canvas.rs:64-101](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/app/src/node_editor/view/canvas.rs#L64-L101) 以 1×1 四边形绘制网格：默认 0.85 缩放下 1200×700 画布约 70×41 ≈ 2900 个次网格四边形，加约 110 个主网格，每个展开为 6 个顶点。叠加第一条即每帧两遍。

### 六、效果搜索每帧重建并重排整个效果目录

[panels/fx_console.rs:85-90](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/app/src/panels/fx_console.rs#L85-L90) 调用 `entries()`（`fx_console.rs:20-61`）：遍历每个包与效果，为名称和类别各分配 `String`，每个效果执行 7 次 `to_lowercase()`，每条通过 `json!({...})` 分配一个 `serde_json::Value`，最后 `result.sort_by(...)`。无缓存，也无在查询未变时提前返回的判断。该面板为模态，期间整个工作区同时在绘制两遍。

### 七、面板读取 JSON 时对 id 的 unwrap

`desktop/app/src/panels/` 下 8 处 `layer["id"].as_u64().unwrap()`：`align.rs:8`、`animation_controls.rs:134`、`audio.rs:42`、`effect_controls.rs:188,418,519`、`expressions.rs:22`、`parent_controls.rs:74`；另有 [timeline_shortcuts.rs:301,309,316](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/app/src/panels/timeline_shortcuts.rs#L301) 三处 `value.as_f64().unwrap()` 与 `from_fn(|i| value[i].as_f64().unwrap())`。这些在**绘制面板时**执行，键缺失或类型不符即 panic。

### 八、参数缓存键每参数每帧分配两次

[panels/effect_controls.rs:542-551](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/app/src/panels/effect_controls.rs#L542-L551)

```rust
let key = (object, id, param.to_string());
if !self.tracks.contains_key(&key) { ... }
let track = &self.tracks[&(object, id, param.to_string())];   // 第二次分配
```

每参数每帧两个 `String` 堆分配，缓存未命中时还有一次 `serde_json::from_value` 克隆。缓存本身按 `(root, composition, revision)` 失效（`effect_controls.rs:196-204`），跨播放头移动是正确的，浪费仅在重复建键。

## 实施范围

- [ ] 消除 [presentation.rs:305-326](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/app/src/shell/presentation.rs#L305-L326) 的整帧二次绘制：或让 `chrome` 为纯绘制、或在需要两遍时只重画受影响面板
- [ ] `frames` / `dock::solve` 的结果按 `(layout, size)` 记忆化，仅在布局或尺寸变化时重算
- [ ] 合并 `panels/mod.rs:345-368` 与 `:509-520` 的重复分隔条循环
- [ ] `cards()` 每帧只算一次，连线与插口查找改为建索引的 `HashMap`
- [ ] 画布网格合并为批次（或单次绘制调用），不再逐格四边形
- [ ] 效果搜索目录按包与查询做缓存，查询未变时直接复用
- [ ] 面板读取 id／数值改为返回错误或 `Option`，不 panic
- [ ] `effect_controls` 缓存键每参数只构建一次

## 验收标准

- [ ] 拖拽帧的 UI 绘制量与静止帧相当
- [ ] `dock::solve` 每帧调用次数降至 1
- [ ] 连线与插口查找不随节点数呈平方增长
- [ ] 参数缓存键的每帧分配次数减半

## 依赖与来源

收益与排期须由基线对照确认；本 issue 是待实现/待验证任务，不表示这些改造已完成