. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:RUST_MIN_STACK='33554432'
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:LIBCLANG_PATH='E:/Dev/aem/.tools/python-libclang/clang/native'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
cargo rustc -p motion-desktop --bin motion-studio --profile test --features ffmpeg --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --config profile.test.package.motion-render.debug=0 --config profile.test.package.motion-model.debug=0 --config profile.test.package.motion-host.debug=0 --config profile.test.package.motion-core.debug=0 --config profile.test.package.motion-media.debug=0 --config profile.test.package.motion-scene.debug=0 --config profile.test.package.motion-effects.debug=0 --config profile.test.package.motion-ui.debug=0 --config profile.test.package.motion-desktop-media.debug=0 --config profile.test.package.motion-graph.debug=0 --message-format=json -- -C codegen-units=8 -C debuginfo=0 -C link-arg=/DEBUG:NONE 1> E:/Dev/aem/artifacts/issue-goal-current/node-drag-geometry/original-height-build.jsonl 2> E:/Dev/aem/artifacts/issue-goal-current/node-drag-geometry/original-height-build.stderr
exit $LASTEXITCODE
