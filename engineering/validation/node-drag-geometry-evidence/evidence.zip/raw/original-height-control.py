import hashlib,json,os,subprocess
from pathlib import Path
root=Path('E:/Dev/aem/.worktrees/layer-time-mapping');out=Path(__file__).parent;path=root/'desktop/app/src/node_editor/view/canvas.rs';original=path.read_bytes()
try:
 text=original.decode('utf-8');needle='let height = if std::ptr::eq(card.source_node, node)';assert text.count(needle)==1
 path.write_bytes(text.replace(needle,'let height = if false && std::ptr::eq(card.source_node, node)').encode('utf-8'))
 script=out/'build-original-height.ps1';script.write_text((out/'build-app.ps1').read_text('utf-8').replace('/app-build.','/original-height-build.'),'utf-8')
 r=subprocess.run(['pwsh','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script)],cwd=root);assert r.returncode==0
 rows=[json.loads(l) for l in (out/'original-height-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
 exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
 env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH'];env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
 cmd=[exe,'--exact','node_editor::view::content_height_tests::builtin_canvas_paints_reuse_exact_frame_heights_without_resolving_ports_again','--nocapture'];r=subprocess.run(cmd,env=env,capture_output=True)
 (out/'height-negative.stdout').write_bytes(r.stdout);(out/'height-negative.stderr').write_bytes(r.stderr);assert r.returncode==101
 receipt={'command':cmd,'exit':r.returncode,'original_height_executable_sha256':hashlib.sha256(Path(exe).read_bytes()).hexdigest()};(out/'height-negative.json').write_text(json.dumps(receipt,indent=2),'utf-8');print(json.dumps(receipt))
finally:
 path.write_bytes(original);assert path.read_bytes()==original
 (out/'height-restored.json').write_text(json.dumps({'canvas_sha256':hashlib.sha256(original).hexdigest()}),'utf-8')
