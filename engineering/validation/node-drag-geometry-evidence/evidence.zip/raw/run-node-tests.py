import hashlib
import json
import os
from pathlib import Path
import subprocess

out = Path(__file__).parent
rows = [json.loads(l) for l in (out / 'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
exe = [r['executable'] for r in rows if r.get('reason') == 'compiler-artifact' and r['target']['name'] == 'motion-studio' and r.get('executable')][-1]
env = os.environ.copy()
env.pop('RUST_MIN_STACK', None)
env['MOTION_LOG'] = 'info'
env['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + env['PATH']
env['TEMP'] = env['TMP'] = 'E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['MOTION_NODE_DRAG_EVIDENCE'] = str(out / 'fixed-paint.json')
command = [exe, 'node_editor::', '--test-threads=1', '--nocapture']
result = subprocess.run(command, env=env, capture_output=True)
(out / 'node-tests.stdout').write_bytes(result.stdout)
(out / 'node-tests.stderr').write_bytes(result.stderr)
(out / 'node-tests.json').write_text(json.dumps({'command':command, 'exit':result.returncode,
    'executable_sha256':hashlib.sha256(Path(exe).read_bytes()).hexdigest(), 'runtime_stack_override':False}, indent=2), 'utf-8')
print(result.stdout.decode('utf-8', errors='replace')[-4000:])
print(result.stderr.decode('utf-8', errors='replace')[-2000:])
assert result.returncode == 0
