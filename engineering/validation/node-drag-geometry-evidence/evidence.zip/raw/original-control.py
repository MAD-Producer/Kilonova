import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('E:/Dev/aem/.worktrees/layer-time-mapping')
out = Path(__file__).parent
path = root / 'desktop/app/src/node_editor/view/mod.rs'
original = path.read_bytes()
try:
    text = original.decode('utf-8')
    before = 'let positions_refreshed = moving_nodes'
    assert text.count(before) == 1
    path.write_text(text.replace(before, 'let positions_refreshed = false && moving_nodes'), 'utf-8')
    script = out / 'build-original.ps1'
    script.write_text((out / 'build-app.ps1').read_text('utf-8').replace('/app-build.', '/original-build.'), 'utf-8')
    result = subprocess.run(['pwsh', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(script)], cwd=root)
    assert result.returncode == 0
    rows = [json.loads(l) for l in (out / 'original-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
    exe = [r['executable'] for r in rows if r.get('reason') == 'compiler-artifact' and r['target']['name'] == 'motion-studio' and r.get('executable')][-1]
    env = os.environ.copy()
    env.pop('RUST_MIN_STACK', None)
    env['MOTION_LOG'] = 'info'
    env['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + env['PATH']
    env['TEMP'] = env['TMP'] = 'E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
    env['MOTION_NODE_DRAG_EVIDENCE'] = str(out / 'original-paint.json')
    results = []
    for name, expected in [('steady_node_drags_build_cards_once_and_keep_fresh_geometry_release_and_undo', 101),
        ('record_complete_node_drag_paint_and_history_for_original_path_comparison', 0)]:
        command = [exe, '--exact', 'node_editor::view::frame_cards_tests::drag_geometry::' + name, '--nocapture']
        result = subprocess.run(command, env=env, capture_output=True)
        prefix = 'negative' if expected else 'original-paint'
        (out / (prefix + '.stdout')).write_bytes(result.stdout)
        (out / (prefix + '.stderr')).write_bytes(result.stderr)
        assert result.returncode == expected
        results.append({'command':command, 'exit':result.returncode})
    original_paint = json.loads((out / 'original-paint.json').read_text('utf-8'))
    fixed_paint = json.loads((out / 'fixed-paint.json').read_text('utf-8'))
    assert original_paint == fixed_paint, 'complete paint or history changed'
    assert len(fixed_paint) == 24 and all(len(frames) == 3 for frames in fixed_paint.values())
    receipt = {'original_executable_sha256':hashlib.sha256(Path(exe).read_bytes()).hexdigest(),
        'results':results, 'paint_comparisons':72, 'moving_pointer_controls':24,
        'original_rebuild_negative_exit':101, 'complete_paint_and_state_equal':True}
    (out / 'original-receipt.json').write_text(json.dumps(receipt, indent=2), 'utf-8')
    print(json.dumps(receipt))
finally:
    path.write_bytes(original)
    assert path.read_bytes() == original
    subprocess.run(['git', 'diff', '--exit-code', '--', str(path)], cwd=root, check=True)
    (out / 'original-restored.json').write_text(json.dumps({'source_sha256':hashlib.sha256(original).hexdigest()}), 'utf-8')
