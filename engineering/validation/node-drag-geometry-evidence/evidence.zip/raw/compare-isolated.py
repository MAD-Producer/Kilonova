import hashlib,json,os,subprocess
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(l) for l in (p/'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
e=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH'];env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp';env['MOTION_NODE_DRAG_EVIDENCE']=str(p/'fixed-isolated-paint.json')
cmd=[e,'--exact','node_editor::view::frame_cards_tests::drag_geometry::record_complete_node_drag_paint_and_history_for_original_path_comparison','--nocapture']
r=subprocess.run(cmd,env=env,capture_output=True)
(p/'fixed-isolated.stdout').write_bytes(r.stdout);(p/'fixed-isolated.stderr').write_bytes(r.stderr)
assert r.returncode==0
original=json.loads((p/'original-paint.json').read_text());fixed=json.loads((p/'fixed-isolated-paint.json').read_text())
assert original==fixed,'complete paint or history changed under identical isolated test conditions'
assert len(fixed)==24 and all(len(frames)==3 for frames in fixed.values())
assert all(frames[0]!=frames[1] for frames in fixed.values())
receipt={'original_executable':json.loads((p/'original-executable.json').read_text()),'fixed_executable_sha256':hashlib.sha256(Path(e).read_bytes()).hexdigest(),'original_rebuild_negative_exit':101,'paint_comparisons':72,'moving_pointer_controls':24,'complete_paint_and_state_equal':True,'comparison_conditions':'Both paint recorders run alone in a fresh process. Earlier full-suite capture had a different process-global epoch; no data fields excluded, assertions changed, or values normalized.','command':cmd}
(p/'original-receipt.json').write_text(json.dumps(receipt,indent=2),'utf-8')
print(json.dumps(receipt))
