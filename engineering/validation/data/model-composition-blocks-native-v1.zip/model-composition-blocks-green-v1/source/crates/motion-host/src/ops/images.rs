//! Image inspection, bounded preview proxies and full-resolution decode.
use crate::session::Result;
use motion_core::Asset;
use serde_json::json;
use std::path::PathBuf;

/// Read-only, size-bounded metadata for a caller-selected import candidate.
/// This pre-registration probe accepts external paths and has no session/root
/// authority; it does not register an asset, create a proxy or copy source bytes.
/// Registered asset access and `prepare_image` retain project-relative checks.
pub fn image_info(path: &str) -> Result<serde_json::Value> {
    let (width, height, format, bytes) =
        motion_render::image_resources::inspect(std::path::Path::new(path))?;
    Ok(json!({"version":1,"width":width,"height":height,"format":format!("{format:?}"),"bytes":bytes,
        "maxEncodedBytes":motion_render::image_resources::MAX_ENCODED_BYTES,
        "previewMaxEdge":motion_render::image_resources::MAX_PREVIEW_EDGE}))
}

/// Validate a project-relative image path and warm its preview proxy.
pub fn prepare_image(root: PathBuf, path: String) -> Result<serde_json::Value> {
    motion_core::storage::validate_relative_path(&path).map_err(crate::Error::from)?;
    let (width, height, format, bytes) =
        motion_render::image_resources::inspect(&root.join(&path))?;
    let asset = Asset {
        id: 1,
        path: path.clone(),
        width,
        height,
    };
    let source = motion_render::image_resources::Source::new(&root, &asset)?;
    let proxy = motion_render::image_resources::decode(
        &source,
        motion_render::image_resources::Resolution::Preview(
            motion_render::image_resources::MAX_PREVIEW_EDGE,
        ),
    )?;
    Ok(json!({"version":1,"path":path,"width":width,"height":height,"format":format!("{format:?}"),
        "bytes":bytes,"validated":true,
        "proxyWidth":proxy.width,"proxyHeight":proxy.height,"proxyCached":proxy.cached}))
}

/// Decode one registered asset at original resolution into a caller buffer.
pub fn asset_pixels_into(id: i64, asset: i64, out: &mut [u8]) -> Result<serde_json::Value> {
    crate::session::with_session(id, |s| asset_pixels_into_inner(s, asset, out))
}

pub fn asset_pixels_into_inner(
    s: &mut crate::session::Session,
    asset: i64,
    out: &mut [u8],
) -> Result<serde_json::Value> {
    {
        let a = s
            .engine
            .project()
            .assets
            .iter()
            .find(|a| a.id == asset as u64)
            .ok_or("asset not found")?;
        let source = motion_render::image_resources::Source::new(&s.root, a)?;
        source.validate()?;
        let bytes = u64::from(source.width) * u64::from(source.height) * 4;
        if (out.len() as u64) < bytes {
            return Err("image buffer is too small".into());
        }
        motion_render::image_resources::decode_into_with_budget(
            &source,
            motion_render::image_resources::Resolution::Full,
            &mut out[..bytes as usize],
            s.effects.memory_policy().decoded_image_budget_bytes,
        ).map_err(|cause| crate::Error::with_context(format!("asset_pixels_into asset={asset}"), cause))?;
        Ok(json!({"version":1,"asset":a.id,"width":a.width,"height":a.height,"bytes":bytes,"resolution":"original"}))
    }
}
