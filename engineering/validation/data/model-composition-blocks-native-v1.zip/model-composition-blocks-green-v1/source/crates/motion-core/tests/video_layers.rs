use motion_core::{Command, Content, Engine, Layer, LayerTimeline, Project, VideoAsset, VideoClip};
use motion_render::Scene;
fn project() -> Project {
    let mut p = Project::new(64, 64, 60, 240).unwrap();
    p.video_assets.push(VideoAsset {
        id: 10,
        path: "assets/video.mp4".into(),
        bytes: 1024,
        mime: "video/avc".into(),
        track: 0,
        width: 64,
        height: 64,
        rotation: 0,
        display_width: 64,
        display_height: 64,
        video_start_us: 200_000,
        video_end_us: 2_000_000,
        duration_us: 2_000_000,
        frame_count: 54,
        variable_frame_rate: false,
        nominal_frame_rate: 30.0,
        color_standard: 1,
        color_range: 2,
        audio_asset: None,
    });
    let mut l = Layer::solid(1, "video", [64.; 2], [32., 32., 0.], [1.; 4]);
    l.content = Content::Video {
        video: VideoClip::new(10),
    };
    l.timeline = Some(LayerTimeline {
        in_frame: 0,
        out_frame: 120,
        offset_frame: 0,
    });
    p.layers.push(l);
    p.validate().unwrap();
    p
}
#[test]
fn video_uses_source_time_and_leading_and_trailing_transparency_through_clip_edits() {
    let mut e = Engine::new(project()).unwrap();
    let mut scene = Scene::new(e.project()).unwrap();
    scene.sample(e.project(), 0., None, &motion_core::ExpressionEvaluator).unwrap();
    assert!(scene.layers.is_empty());
    scene.sample(e.project(), 30.5, None, &motion_core::ExpressionEvaluator).unwrap();
    assert_eq!(
        scene.layers[0].video.as_ref().unwrap().source_time_us,
        508333
    );
    e.apply_batch(vec![
        Command::SplitLayerClip {
            object: 1,
            frame: 30,
        },
        Command::MoveLayerClip {
            object: 2,
            in_frame: 60,
        },
    ])
    .unwrap();
    scene.sample(e.project(), 60.5, None, &motion_core::ExpressionEvaluator).unwrap();
    assert_eq!(
        scene.layers[0].video.as_ref().unwrap().source_time_us,
        508333
    );
    scene.sample(e.project(), 150., None, &motion_core::ExpressionEvaluator).unwrap();
    assert!(scene.layers.is_empty());
    let before = e.snapshot();
    assert!(e
        .apply_batch(vec![Command::TrimLayerClip {
            object: 2,
            in_frame: 60,
            out_frame: 180
        }])
        .is_err());
    assert_eq!(before, e.snapshot());
}
#[test]
fn only_current_format_accepts_video_documents() {
    let mut p = project();
    for version in (0..motion_core::CURRENT_PROJECT_VERSION).chain([motion_core::CURRENT_PROJECT_VERSION + 1, u32::MAX]) {
        p.version = version;
        assert!(p.validate().unwrap_err().to_string().contains("unsupported project format"));
    }
    p.version = motion_core::CURRENT_PROJECT_VERSION;
    p.validate().unwrap();
    let reopened: Project = serde_json::from_slice(&serde_json::to_vec(&p).unwrap()).unwrap();
    assert_eq!(reopened, p);
}
#[test]
fn video_span_keeps_recoverable_source_time_before_zero_and_after_composition_end() {
    let mut p=project();p.version = motion_model::CURRENT_PROJECT_VERSION;p.frames=60;
    p.work_area=motion_model::WorkArea::full(p.frames);
    p.layers[0].timeline=Some(LayerTimeline{in_frame:-12,out_frame:100,offset_frame:-12});
    p.validate().unwrap();let mut scene=Scene::new(&p).unwrap();
    scene.sample(&p,0.,None,&motion_core::ExpressionEvaluator).unwrap();
    assert_eq!(scene.layers[0].video.as_ref().unwrap().source_time_us,200_000);
    scene.sample(&p,59.5,None,&motion_core::ExpressionEvaluator).unwrap();
    assert_eq!(scene.layers[0].video.as_ref().unwrap().source_time_us,1_191_667);
    let mut e=Engine::new(p).unwrap();let before=e.snapshot();
    assert!(e.apply(Command::TrimLayerClip{object:1,in_frame:-12,out_frame:109}).is_err());
    assert_eq!(e.snapshot(),before);
    e.apply(Command::MoveLayerClip{object:1,in_frame:-24}).unwrap();
    assert_eq!(e.project().layers[0].timeline,Some(LayerTimeline{in_frame:-24,out_frame:88,offset_frame:-24}));
    e.undo().unwrap();assert_eq!(e.snapshot(),before);
}
