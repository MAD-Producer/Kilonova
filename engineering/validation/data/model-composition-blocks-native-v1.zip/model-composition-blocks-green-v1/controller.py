"""Execute own actual model-block regressions; red precedes any product edit."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys
root = Path('E:/Dev/aem'); work = root / '.worktrees/model-composition-blocks'
mode = sys.argv[1]; assert mode in ('red', 'green')
out = root / ('artifacts/pr-queue/model-composition-blocks-' + mode + '-v1')
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
paths = json.loads((root / 'artifacts/pr-queue/project-model-depth-native-v5/accepted.json').read_text(encoding='utf-8'))['source']
source = {p: sha(work / p) for p in paths}
for p in source:
    dest = out / 'source' / p; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(work / p, dest)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
if mode == 'red':
    test = 'crates/motion-render/tests/model_layers/project_shared.rs'
    assert all(h == paths[p] for p, h in source.items() if p != test)
else:
    red = json.loads((root / 'artifacts/pr-queue/model-composition-blocks-red-v1/reproduced.json').read_text(encoding='utf-8'))
    assert red['sourceUnchanged'] and red['totals'] == dict(passed=0, failed=2, ignored=0)
    assert source['crates/motion-render/tests/model_layers/project_shared.rs'] == red['source']['crates/motion-render/tests/model_layers/project_shared.rs']
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG', None)
receipt = dict(startedUtc=datetime.now(timezone.utc).isoformat(), source=source, steps=[], mode=mode)
cmd = ['cargo', 'test', '-p', 'motion-render', '--features', 'gpu-tests', '--test', 'model_layers', '--locked', '--offline', '--', 'model_blocks_', '--test-threads=1']
with (out / 'stdout.log').open('wb') as so, (out / 'stderr.log').open('wb') as se:
    code = subprocess.run(cmd, cwd=work, env=env, stdout=so, stderr=se).returncode
text = (out / 'stdout.log').read_text(encoding='utf-8')
results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
receipt.update(exitCode=code, sourceUnchanged=all(sha(work / p) == h for p, h in source.items()), command=cmd,
               completedUtc=datetime.now(timezone.utc).isoformat())
if results: receipt['totals'] = dict(zip(('passed', 'failed', 'ignored'), map(int, results[0])))
(out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
assert receipt['sourceUnchanged']
assert len(results) == 1
expected = dict(passed=0, failed=2, ignored=0) if mode == 'red' else dict(passed=2, failed=0, ignored=0)
assert code == (101 if mode == 'red' else 0) and receipt['totals'] == expected
if mode == 'red':
    assert 'mixed left ray must use shared model depth' in text
    assert 'each model block and 2D boundary must keep its own depth/order' in text
name = 'reproduced.json' if mode == 'red' else 'accepted.json'
(out / name).write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(mode=mode, totals=receipt['totals'], sourceUnchanged=True)), flush=True)
