"""Run final unchanged ray assertions against exact parent product Git blobs."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess
root = Path('E:/Dev/aem'); work = root / '.worktrees/model-composition-blocks'
out = root / 'artifacts/pr-queue/model-composition-blocks-control-v2'; out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
products = ['crates/motion-render/src/renderer/model_layers.rs', 'crates/motion-render/src/renderer/model_layers/shared.rs']
test = 'crates/motion-render/tests/model_layers/project_shared.rs'
before = {p: (work / p).read_bytes() for p in products}
test_hash = sha(work / test)
for p, data in before.items():
    dest = out / 'working-source' / p; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(data)
dest = out / 'source' / test; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(work / test, dest)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy(); env.update(CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG', None)
receipt = dict(startedUtc=datetime.now(timezone.utc).isoformat(), parent='4b7aa753b8ee7afb40ac5215fad03505aae4f8df',
               workingProductSource={p: hashlib.sha256(b).hexdigest() for p, b in before.items()}, source={}, testSha256=test_hash)
try:
    for p in products:
        data = subprocess.check_output(['git', 'show', receipt['parent'] + ':' + p], cwd=work)
        (work / p).write_bytes(data)
        dest = out / 'source' / p; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(data)
        receipt['source'][p] = sha(work / p)
    cmd = ['cargo', 'test', '-p', 'motion-render', '--features', 'gpu-tests', '--test', 'model_layers', '--locked', '--offline', '--', 'model_blocks_', '--test-threads=1']
    with (out / 'stdout.log').open('wb') as so, (out / 'stderr.log').open('wb') as se:
        receipt['exitCode'] = subprocess.run(cmd, cwd=work, env=env, stdout=so, stderr=se).returncode
    text = (out / 'stdout.log').read_text(encoding='utf-8')
    results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    if results: receipt['totals'] = dict(zip(('passed', 'failed', 'ignored'), map(int, results[0])))
    assert sha(work / test) == test_hash
    assert receipt['exitCode'] == 101 and len(results) == 1 and receipt['totals']['ignored'] == 0
    for name in ('model_blocks_keep_shared_depth_between_ordinary_background_and_foreground',
                 'model_blocks_share_each_contiguous_run_without_crossing_an_authored_2d_boundary'):
        assert 'test project_shared::' + name + ' ... FAILED' in text
    assert 'mixed right ray must use shared model depth' in text
    assert 'each model block and 2D boundary must keep its own depth/order: x=40' in text
    receipt['finalFixtureReproducesBothOriginalFailures'] = True
finally:
    for p, data in before.items(): (work / p).write_bytes(data)
    receipt['productSourceRestored'] = all((work / p).read_bytes() == data for p, data in before.items())
    receipt['completedUtc'] = datetime.now(timezone.utc).isoformat()
    (out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
assert receipt['productSourceRestored'] and receipt['finalFixtureReproducesBothOriginalFailures']
(out / 'reproduced.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(controlAccepted=True, totals=receipt['totals'], ownProductSourceRestored=True)), flush=True)
