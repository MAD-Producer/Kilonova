"""Check retained real Win32 input evidence, including a fresh process reopen."""
import copy
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('E:/Dev/aem/artifacts/pr-ci-followups')
reports = []
for folder in ['clipboard-pointer-entry-os-en-activated', 'clipboard-pointer-entry-os-zh-activated']:
    directory = ROOT / folder
    initial = json.loads((directory / 'initial-state.json').read_text('utf-8'))
    def state(index):
        return json.loads((directory / f'reply-{index}.json').read_text('utf-8'))['state']
    def keys(project):
        return next(layer for layer in project['layers'] if layer['id'] == 7)['transform']['position']['keys']
    before = initial['project']
    source = next(layer for layer in before['layers'] if layer['id'] == 7)
    first = state(20)['project']
    second = state(22)['project']
    for project, count in [(first, 1), (second, 2)]:
        assert project['layers'][:3] == before['layers'], (folder, 'source layers changed during paste')
        added = project['layers'][3:]
        assert len(added) == count
        assert len(set(layer['id'] for layer in project['layers'])) == 3 + count
        for layer in added:
            expected = copy.deepcopy(source)
            expected['id'] = layer['id']
            assert layer == expected, (folder, 'pasted content, keys, or timing changed')
        expected = copy.deepcopy(before)
        expected['layers'].extend(added)
        assert project == expected
    for index, revision in [(6, 0), (16, 0), (26, 4), (31, 6)]:
        assert state(index)['project'] == before, (folder, index, 'capture, text drafts, or undo changed project')
        assert state(index)['revision'] == initial['revision'] + revision
    for index, revision in [(20, 1), (22, 2), (24, 3), (29, 5)]:
        assert state(index)['revision'] == initial['revision'] + revision
    assert state(24)['project'] == first, (folder, 'undo second paste must restore first paste')
    cut = copy.deepcopy(before)
    cut['layers'] = [layer for layer in cut['layers'] if layer['id'] != 7]
    assert state(29)['project'] == cut
    assert json.loads((directory / 'reply-33.json').read_text('utf-8'))['exit'] == 0
    messages = [json.loads(line) for line in (directory / 'stdout.jsonl').read_text('utf-8').splitlines()]
    assert all(message.get('jsonrpc') == '2.0' and 'error' not in message for message in messages)
    log = (directory / 'userdata/MotionStudio/logs/motion-studio.log').read_text('utf-8')
    stderr = (directory / 'stderr.log').read_text('utf-8')
    assert 'clipboard_read' in log and 'clipboard_commit' in log
    assert not any('ERROR' in line and ('motion_studio::' in line or 'motion_ui::' in line) for line in log.splitlines())
    assert 'editor_action' not in stderr and 'invalid composition viewport' not in stderr
    env = dict(os.environ)
    for name in ['MOTION_LOG', 'MOTION_PROJECT', 'MOTION_LOCALE', 'MOTION_UI_STYLE', 'MOTION_UI_LAYOUT']:
        env.pop(name, None)
    env['PATH'] = os.environ['SystemRoot'] + '/System32;' + os.environ['SystemRoot']
    env['LOCALAPPDATA'] = str(directory / 'reopen-userdata')
    payload = [
        {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {
            'protocolVersion': '2025-11-25', 'capabilities': {},
            'clientInfo': {'name': 'animation-os-reopen', 'version': '1'}}},
        {'jsonrpc': '2.0', 'method': 'notifications/initialized'},
        {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call',
         'params': {'name': 'motion_state', 'arguments': {}}}]
    run = subprocess.run([str(ROOT / 'clipboard-pointer-entry-runtime/motion-studio.exe'),
                          '--mcp', '--project', str(directory / 'project')],
                         input=''.join(json.dumps(v) + '\n' for v in payload),
                         text=True, encoding='utf-8', capture_output=True, env=env, timeout=30)
    (directory / 'reopen.stdout.jsonl').write_text(run.stdout, 'utf-8')
    (directory / 'reopen.stderr.log').write_text(run.stderr, 'utf-8')
    assert run.returncode == 0, (run.returncode, run.stderr)
    response = next(json.loads(line) for line in run.stdout.splitlines() if json.loads(line).get('id') == 2)
    assert response['result']['structuredContent']['project'] == before
    reports.append({'folder': folder, 'source': 'd3074562ccbb85a185bcc886a3971aa6e314fccd', 'realSystemInput': True,
                    'textDraftDidNotReplaceLayerCache': True, 'editMenuAndKeyboardPaste': True,
                    'freshIdsAndIndependentCopies': True, 'singleUndoForCutAndPaste': True,
                    'draftEscapePreservesProject': True, 'saveReopen': True,
                    'defaultInfoAndStdoutIsolation': True, 'dpi': 96, 'exit': 0})
(ROOT / 'clipboard-pointer-entry-os-activated-summary.json').write_text(json.dumps(reports, indent=2), 'utf-8')
print(json.dumps(reports))
