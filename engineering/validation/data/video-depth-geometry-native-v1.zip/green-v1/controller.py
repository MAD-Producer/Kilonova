from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess
root=Path('E:/Dev/aem'); work=root/'.worktrees/video-depth-geometry'
out=root/'artifacts/pr-queue/video-depth-geometry-green-v1'; out.mkdir(exist_ok=False)
assert (root/'artifacts/pr-queue/video-depth-geometry-red-v1/reproduced.json').is_file()
git=lambda *args: subprocess.check_output(['git',*args],cwd=work).decode().strip()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=work).decode().split('\0')
source={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml')) or p=='Cargo.lock')}
for p in git('diff','--name-only','HEAD').splitlines()+git('ls-files','--others','--exclude-standard').splitlines():
    if p in source:
        dest=out/'source'/p; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(work/p,dest)
shutil.copyfile(__file__,out/'controller.py')
env=os.environ.copy(); env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true', MOTION_VIDEO_DEPTH_ARTIFACTS=str(out/'renders'), MOTION_DEPTH_ACCEPTANCE_DIR=str(out/'geometry-renders')); env.pop('MOTION_LOG',None)
steps=[
('host',['cargo','test','-p','motion-host','--lib','--test','depth_session','--test','depth_video','--features','gpu-tests,ai-depth','--locked','--offline','--no-fail-fast','--','--test-threads=1']),
('geometry',['cargo','test','-p','motion-render','--test','depth_surface','--features','gpu-tests','--locked','--offline','--','--test-threads=1']),
('video-regression',['cargo','test','-p','motion-render','--test','video_allocation_budget','--test','video_instances','--test','video_lifetime','--test','video_yuv','--features','gpu-tests','--locked','--offline','--no-fail-fast','--','--test-threads=1']),
('media',['cargo','test','-p','motion-desktop-media','--lib','--features','ffmpeg,gpu-tests,ai-depth','--locked','--offline','--no-fail-fast','--','--test-threads=1','--include-ignored']),
('host-without-depth',['cargo','check','-p','motion-host','--no-default-features','--locked','--offline']),
('desktop',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),
('style',['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
('provenance',['python','tools/validate_provenance.py'])]
r=dict(base=git('rev-parse','HEAD'),startedUtc=datetime.now(timezone.utc).isoformat(),source=source,steps=[],scope='Exact-source-time calibrated video geometry and same-worker owned display colors; controlled decoder with real native GPU output, four precisions and retained revisions. Not temporal calibration tracks, real-codec movie acceptance, complex depth, DOF or final workspace.')
expected={'host':[('109','0','0'),('17','0','0'),('15','0','0')], 'geometry':[('8','0','0')], 'video-regression':[('2','0','0'),('3','0','0'),('8','0','0'),('7','0','0')], 'media':[('56','0','0')]}
for name,cmd in steps:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as stdout, (out/(name+'.stderr.log')).open('wb') as stderr:
        code=subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
    row=dict(name=name,command=cmd,exitCode=code,sourceUnchanged=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in source.items()))
    if name in expected: row['results']=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (out/(name+'.stdout.log')).read_text(encoding='utf-8'))
    r['steps'].append(row); (out/'exit.json').write_text(json.dumps(r,indent=2),encoding='utf-8'); print(json.dumps(row),flush=True)
    assert code==0 and row['sourceUnchanged'], name
    if name in expected: assert row['results']==expected[name], (name,row['results'])
assert len(list((out/'renders').glob('native-*.png')))==4
assert (out/'geometry-renders/video-reverse-first.png').is_file()
assert (out/'geometry-renders/video-reverse-last.png').is_file()
r['completedUtc']=datetime.now(timezone.utc).isoformat(); (out/'accepted.json').write_text(json.dumps(r,indent=2),encoding='utf-8'); print('accepted',flush=True)
