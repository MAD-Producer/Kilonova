from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess
root=Path('E:/Dev/aem'); work=root/'.worktrees/video-depth-geometry'
out=root/'artifacts/pr-queue/video-depth-geometry-red-v1'; out.mkdir(exist_ok=False)
cmd=['cargo','test','-p','motion-host','--test','depth_video','--features','gpu-tests,ai-depth','--locked','--offline','native_video_depth_uses_its_owned_color_and_refuses_other_source_times','--','--test-threads=1']
env=os.environ.copy(); env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true'); env.pop('MOTION_LOG',None)
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=work).decode().split('\0')
source={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and p.endswith(('.rs','.toml','.wgsl'))}
shutil.copyfile(work/'crates/motion-host/tests/depth_video.rs',out/'depth_video.rs'); shutil.copyfile(__file__,out/'controller.py')
with (out/'stdout.log').open('wb') as stdout, (out/'stderr.log').open('wb') as stderr:
    code=subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
unchanged=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in source.items())
r=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),command=cmd,exitCode=code,sourceUnchanged=unchanged,source=source,completedUtc=datetime.now(timezone.utc).isoformat())
(out/'exit.json').write_text(json.dumps(r,indent=2),encoding='utf-8'); print(json.dumps(dict(exitCode=code,sourceUnchanged=unchanged)),flush=True)
text=(out/'stdout.log').read_text(encoding='utf-8')
assert code==101 and unchanged and '0 passed; 1 failed; 0 ignored' in text
assert 'video geometry routing is not implemented' in text
(out/'reproduced.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
