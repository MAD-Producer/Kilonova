"""Source-bound native calibrated geometry gate. New GPU tests must run; pre-existing manual media acceptances are listed explicitly."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

root = Path('E:/Dev/aem')
work = root / '.worktrees/depth-authoring'
out = root / 'artifacts/pr-queue/depth-surface-native-v4'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=work).decode().strip()
main = git('rev-parse', 'origin/main')
subprocess.run(['git', 'merge-base', '--is-ancestor', main, 'HEAD'], cwd=work, check=True)
paths = git('ls-files', '-co', '--exclude-standard', '-z').split('\0')
source = {p: sha(work / p) for p in sorted(set(paths)) if p and (p.endswith(('.rs', '.py', '.toml', '.wgsl', '.json')) or p == 'Cargo.lock')}
base = main
changed = git('diff', '--name-only', base).splitlines()
changed += git('ls-files', '--others', '--exclude-standard').splitlines()
for p in source: os.utime(work / p, None)
for p in sorted(set(changed)):
    if p not in source: continue
    dest = out / 'source' / p
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(work / p, dest)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1',
           CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG', None)
env['MOTION_DEPTH_ACCEPTANCE_DIR'] = str(out / 'renders')
env['PYTHONPATH'] = str(root / '.tools/build-validation-python') + os.pathsep + env.get('PYTHONPATH', '')
receipt = dict(startedUtc=datetime.now(timezone.utc).isoformat(), main=main, base=base, head=git('rev-parse', 'HEAD'),
    source=source, changedSource=changed, existingAssertionsUnchanged=True, steps=[],
    scope='Actual persisted reference-camera calibrated image geometry in ordinary native preview/capture, independent ray and photo oracles, immutable pending submissions and budget refusal recovery; video/multiple-source/complex depth/DOF remain open')

def selected(package, targets, features=None, lib=False):
    cmd = ['cargo', 'test', '-p', package]
    if features: cmd += ['--features', features]
    if lib: cmd += ['--lib']
    for target in targets: cmd += ['--test', target]
    return cmd + ['--locked', '--offline', '--no-fail-fast', '--', '--test-threads=1']

core_targets = ['project_library','camera_lens','camera_workflows','command_registry','composition_candidate_graphs',
    'composition_fps','composition_resources','compositions','imported_cameras','layer_clipboard',
    'model_layers','depth_calibration','media_assets','multiple_cameras','parent_modes','parenting','prepared_commands','scoped_command_transport']
native_targets = ['depth_surface','model_layers','scene_gpu','layer_compositing','layer_rasters','layer_masks','scene_effects',
    'exposure_frame','spatial_effects','compositions','multiple_camera_compositions','mask_error_boundaries',
    'nested_exposure','projected_planes','plane_intersections','exposure_scenes','orthographic_planes','rotation_order']
host_targets = ['depth_jobs','depth_session','depth_video','imported_cameras','failure_boundaries','render_composition_detail',
    'resource_composition_details','image_candidate_contract','session_concurrency']
steps = [('provenance', [sys.executable, 'tools/validate_provenance.py']),
    ('panel-style', [sys.executable, '-c', "import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
    ('workflow', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_ci_workflow.py', '-v']),
    ('media', ['cargo','test','-p','motion-media','--locked','--offline','--no-fail-fast','--','--test-threads=1']),
    ('scene', ['cargo','test','-p','motion-scene','--locked','--offline','--no-fail-fast','--','--test-threads=1']),
    ('model', ['cargo','test','-p','motion-model','--locked','--offline','--no-fail-fast','--','--test-threads=1']),
    ('core', selected('motion-core', core_targets)),
    ('native', selected('motion-render', native_targets, 'gpu-tests', True)),
    ('host', selected('motion-host', host_targets, 'gpu-tests,ai-depth', True)),
    ('host-without-depth', ['cargo','check','-p','motion-host','--no-default-features','--locked','--offline']),
    ('desktop-check', ['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'])]
for name, cmd in steps:
    print(json.dumps(dict(start=name)), flush=True)
    with (out / (name + '.stdout.log')).open('wb') as stdout, (out / (name + '.stderr.log')).open('wb') as stderr:
        code = subprocess.run(cmd, cwd=work, env=env, stdout=stdout, stderr=stderr).returncode
    row = dict(name=name, command=cmd, exitCode=code, sourceUnchanged=all(sha(work/p) == h for p,h in source.items()))
    output = (out / (name + '.stdout.log')).read_text(encoding='utf-8')
    if name in ('media','scene','model','core','native','host'):
        results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', output)
        row.update(targets=len(results), totals=dict(zip(('passed','failed','ignored'), [sum(int(v[i]) for v in results) for i in range(3)])))
    receipt['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], name
    if name in ('media','scene','model','core','native','host'):
        assert row['targets'] > 0 and row['totals']['failed'] == 0
        if name == 'media':
            manual = re.findall(r'^test (\S+) \.\.\. ignored, (.+)$', output, re.MULTILINE)
            expected_manual = {
                'imports_128_mib_sources_and_roundtrips_a_project_over_256_mib': 'large-file acceptance: run explicitly in release mode',
                'large_source_roundtrip_with_shared_audio_and_bounded_read_requests': 'requires MOTION_LARGE_VIDEO_SOURCE (>512 MiB MP4/AAC) and several GiB of free disk',
            }
            assert dict(manual) == expected_manual and len(manual) == 2
            assert row['totals']['ignored'] == 2
            row['unexecutedManualAcceptances'] = dict(manual)
            (out/'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        else:
            assert row['totals']['ignored'] == 0
    if name == 'host':
        for test in ('actual_calibration_authoring_reopens_and_rebinds_without_reusing_live_revisions',
            'saved_calibration_refuses_changed_pixels_and_processing_with_explicit_reauthoring_recovery',
            'calibration_authoring_rejects_pending_canceled_and_changed_candidate_sources_atomically',
            'actual_png_capture_consumes_current_calibrated_geometry_and_refuses_stale_frames',
            'ops::media::frozen::tests::frozen_camera_keeps_owned_sources_and_independent_clock_after_edits_and_close',
            'ops::media::frozen::tests::frozen_camera_native_pixels_match_live_sampling_at_all_precisions_after_source_removal'):
            assert 'test '+test+' ... ok' in output, test
    if name == 'native':
        assert len(re.findall(r'test (?:calibrated_geometry_|missing_or_changed_current_depth_|reference_camera_preserves_).* \.\.\. ok', output)) == 6
        assert len(re.findall(r'test source_editing::.* \.\.\. ok', output)) == 2
        assert row['targets'] == len(native_targets) + 1
        assert len(re.findall(r'test imported_cameras::.* \.\.\. ok', output)) == 6
    if name == 'core':
        assert row['targets'] == len(core_targets)
        assert 'test imported_camera_clipboard_retains_and_remaps_layer_and_nested_camera_sources ... ok' in output
    if name == 'host':
        assert len(re.findall(r'test source_camera_parented_.* \.\.\. ok', output)) == 2
        assert row['targets'] == len(host_targets) + 1
        assert 'test imported_camera_host_capture_matches_native_pixels_after_sources_are_removed ... ok' in output
assert len(list((out / 'renders').glob('*.png'))) == 18
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=True)
(out/'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True, totals={s['name']:s.get('totals') for s in receipt['steps'] if 'totals' in s})), flush=True)
