"""Own serial executable acceptance: original video PTS -> independent projective plane -> actual builtin corner-pin GPU output."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,struct,subprocess,copy
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-camera-native-v1'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def now():return datetime.now(timezone.utc).isoformat()
names=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
sources={n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (WORK/n).is_file()}
report=dict(status='running',controllerPid=os.getpid(),startedUtc=now(),source=sources,steps=[],scope='New calibrated-camera executable target, not a retry or repair of earlier full-host native crashes or MCP test compilation fault')
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def identity():
 for n,h in sources.items():assert hashlib.sha256((WORK/n).read_bytes()).hexdigest()==h,n
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'local-appdata'))
EXE=ROOT/'target/gltf-animation87-contract/debug/motion-studio.exe';project_root=OUT/'project';active=[]
def build():
 identity();args=['cargo','build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline']
 row=dict(name='ffmpeg-build',command=args,startedUtc=now());report['steps'].append(row);save()
 with (OUT/'build.stdout.log').open('wb') as stdout,(OUT/'build.stderr.log').open('wb') as stderr:
  p=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait()
 row['completedUtc']=now();save();assert row['exitCode']==0,row
class Rpc:
 def __init__(self,name,readonly=False):
  identity();self.name=name;self.inputs=[];self.raw=[];self.next_id=0
  args=[str(EXE),'--mcp','--project',str(project_root)]+(['--mcp-read-only'] if readonly else [])
  self.row=dict(name=name,command=args,startedUtc=now(),exeSha256=hashlib.sha256(EXE.read_bytes()).hexdigest());report['steps'].append(self.row)
  self.stderr=(OUT/f'{name}.stderr.log').open('wb')
  self.p=subprocess.Popen(args,cwd=WORK,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr,text=True,encoding='utf-8');active.append(self)
  self.row['pid']=self.p.pid;save()
  self.request('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='owned-camera-binding-proof',version='1')))
  self.send(dict(jsonrpc='2.0',method='notifications/initialized'))
 def send(self,message):
  self.inputs.append(message);self.p.stdin.write(json.dumps(message)+'\n');self.p.stdin.flush()
 def request(self,method,params):
  self.next_id+=1;self.send(dict(jsonrpc='2.0',id=self.next_id,method=method,params=params))
  line=self.p.stdout.readline();self.raw.append(line);assert line,f'{self.name}: stdout closed'
  reply=json.loads(line);assert reply['jsonrpc']=='2.0' and reply['id']==self.next_id and 'error' not in reply,reply
  return reply['result']
 def call(self,name,args):return self.request('tools/call',dict(name=name,arguments=args))
 def ok(self,name,args):
  result=self.call(name,args);assert not result['isError'],result;return result['structuredContent']
 def state(self):return self.ok('motion_state',{})
 def close(self):
  if self.p.stdin and not self.p.stdin.closed:self.p.stdin.close()
  trailing=self.p.stdout.read();assert not trailing,repr(trailing)
  self.row['exitCode']=self.p.wait();self.stderr.close();self.row['completedUtc']=now()
  (OUT/f'{self.name}.stdin.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in self.inputs),encoding='utf-8')
  (OUT/f'{self.name}.stdout.jsonl').write_text(''.join(self.raw),encoding='utf-8')
  log=OUT/'local-appdata/MotionStudio/logs/motion-studio.log'
  if log.exists():(OUT/f'{self.name}.file.log').write_bytes(log.read_bytes())
  active.remove(self);save();assert self.row['exitCode']==0,self.name
save()
try:
 build()
 boot=Rpc('bootstrap');project=boot.state()['project'];boot.close();assert project['version']==35
 project.update(width=640,height=480,fps=24,frames=96,work_area=dict(in_frame=0,out_frame=96),background=[0.02,0.02,0.02,1.])
 project['camera']['created']=True
 name='video-ctts.mp4';folder=WORK/'crates/motion-media/tests/fixtures/video';timing=json.loads((folder/'native-timing.json').read_text(encoding='utf-8'))[name]
 ticks=timing['timescale'];pts=sorted(s[0] for s in timing['samples']);assert ticks==1_000_000 and len(pts)==72
 source=project_root/'assets/plate.mp4';source.parent.mkdir(exist_ok=True);shutil.copyfile(folder/name,source)
 end=max(s[0]+s[1] for s in timing['samples'])
 project['video_assets']=[dict(id=1,path='assets/plate.mp4',bytes=source.stat().st_size,mime='video/avc',track=0,width=256,height=144,rotation=0,display_width=256,display_height=144,video_start_us=pts[0],video_end_us=end,duration_us=end,frame_count=len(pts),variable_frame_rate=True,nominal_frame_rate=24.,color_standard=1,color_range=2,audio_asset=None)]
 (project_root/'project.json').write_text(json.dumps(project),encoding='utf-8')
 cache=project_root/'cache/video-v2/plate/index.pts';cache.parent.mkdir(parents=True)
 cache.write_bytes(b'MSVID001'+struct.pack('<Q',source.stat().st_size)+b''.join(struct.pack('<Q',v) for v in pts))
 import math
 def observation(i,v):
  t=(v-pts[0])/(pts[-1]-pts[0]);angle=math.radians(12.*t)
  return dict(kind='camera',camera_to_world=dict(position=[.8*t,.3*t,-5.],orientation_xyzw=[0.,math.sin(angle/2),0.,math.cos(angle/2)]),calibration=dict(source_extent=[256,144],focal=[180.+20.*t,160.+10.*t],principal=[118.+6.*t,80.-3.*t],radial=[.01 if i==60 else 0.,0.,0.],tangential=[0.,0.]))
 solve=dict(version=1,source_id='independently authored calibrated pinhole control on repository original video',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),source_extent=[256,144],coordinates='right_down_forward',ticks_per_second=ticks,nominal_rate=[24,1],source_pts=pts,meters_per_world_unit=1.,tracks=[dict(id='camera-motion',kind='camera',reference_index=None,samples=[dict(source_index=i,visibility='visible',confidence=1.,manual_correction=i==24,observation=observation(i,v)) for i,v in enumerate(pts)])])
 original=b' \n'+json.dumps(solve,indent=2).encode()+b'\r\n';document=OUT/'original.mstrack';document.write_bytes(original)
 live=Rpc('camera-binding');before=live.state()
 imported=live.ok('import_tracking',dict(path=str(document),source=dict(kind='video',id=1),expectedRevision=before['revision'],expectedDocumentGeneration=before['document_generation']))
 descriptor=imported['project']['tracking_assets'][0];assert descriptor['id']==2 and (project_root/descriptor['path']).read_bytes()==original
 template=json.loads((ROOT/'artifacts/pr-queue/tracking88-point-native-v1/project/project.json').read_text(encoding='utf-8'))['layers'][0]
 points=[[-.8,-.5,1.],[.6,.4,2.],[1.2,-.3,3.]];colors=[[1.,.02,.02,1.],[.02,1.,.02,1.],[.02,.02,1.,1.]]
 layers=[]
 for i,(point,color) in enumerate(zip(points,colors)):
  layer=copy.deepcopy(template);layer.update(id=700+i,name=f'Independent depth fiducial {i}',content=dict(kind='solid',color=color),size=[24.,24.],three_d=True,parent=None,effects=[])
  layer.pop('tracking_point',None);layer.pop('tracking_plane',None)
  layer['transform']['anchor']=[.5,.5];layer['transform']['position']['value']=[320.+100.*point[0],240.+100.*point[1],100.*point[2]];layer['transform']['rotation']['value']=[0.,0.,0.]
  layers.append(layer)
 def edit(commands):
  current=live.state();return live.ok('motion_edit',dict(commands=commands,expectedRevision=current['revision']))
 edit([dict(op='add',layer=l) for l in layers])
 # Capture an explicit ordinary authored reference, independent of raw poses.
 camera=live.state()['project']['camera'];position=camera['position']['value']
 reference=dict(world=dict(position=[position[0]-320.,240.-position[1],-position[2]],orientation_xyzw=[0.,0.,0.,1.]),vertical_fov_degrees=camera['fov']['value'])
 binding=dict(asset=2,track='camera-motion',anchor_local_frame=0,source_anchor_pts=pts[0],speed_numerator=1,speed_denominator=1,world_basis=[1,-2,-3],target_meters_per_unit=.01,target_origin=[0.,0.,0.],correction_reference=reference,crop=[0.,0.,256.,144.],rotation='none',near=.5,far=100000.,interpolation='linear',max_gap_ticks=100000,minimum_confidence=.8,missing='error')
 before=live.state();bad=copy.deepcopy(binding);bad['track']='absent'
 rejected=live.call('motion_edit',dict(commands=[dict(op='set_tracking_camera',object=0,binding=bad)],expectedRevision=before['revision']))
 assert rejected['isError'] and 'phase=binding object=0 asset=2 track=absent' in rejected['content'][0]['text'],rejected
 unchanged=live.state();assert unchanged['project']==before['project'] and unchanged['revision']==before['revision']
 bound=edit([dict(op='set_tracking_camera',object=0,binding=binding)])
 def project_point(frame,point,correction):
  # Independent source RDF pinhole oracle; no engine matrix or sampled camera.
  t=frame/24.*ticks/(pts[-1]-pts[0]);angle=math.radians(12.*t);c,s=math.cos(angle),math.sin(angle)
  dx,dy,dz=point[0]-(.8*t+(.2 if correction else 0.)),point[1]-.3*t,point[2]+5.
  x,y,z=c*dx-s*dz,dy,s*dx+c*dz
  assert z>0
  return [((180.+20.*t)*x/z+118.+6.*t)*640./256.,((160.+10.*t)*y/z+80.-3.*t)*480./144.]
 rows=[]
 def capture(frame,name,correction=False):
  sampled=live.ok('motion_seek',dict(frame=frame));quads=[]
  for i,point in enumerate(points):
   anchor=next(l['anchor'] for l in sampled['projectedLayers'] if l['id']==700+i);expected=project_point(frame,point,correction)
   assert all(abs(anchor[j]-expected[j])<.003 for j in range(2)),(frame,i,anchor,expected)
   quad=[project_point(frame,[point[0]+x,point[1]+y,point[2]],correction) for x,y in [(-.12,-.12),(.12,-.12),(.12,.12),(-.12,.12)]]
   quads.append(dict(id=700+i,anchor=anchor,expected=expected,quad=quad))
  c=live.ok('render_preview',dict(frame=frame));destination=OUT/(name+'.png');shutil.copyfile(c['path'],destination)
  rows.append(dict(frame=frame,markers=quads,path=str(destination),correction=correction))
 capture(0.,'reference');capture(30.,'yaw-and-translation')
 document.unlink()
 undone=live.ok('motion_history',dict(operation='undo'));assert undone['project']['camera'].get('tracking') is None
 redone=live.ok('motion_history',dict(operation='redo'));assert redone['project']==bound['project']
 commands=[]
 for prop in ['position','target']:
  value=camera[prop]['value'].copy();value[0]+=20.
  commands.extend([dict(op='animate',object=0,property=prop,frame=0,enabled=True),dict(op='set_vector',object=0,property=prop,frame=30,value=value)])
 edit(commands);capture(30.,'keyed-manual-correction',True)
 corrected=live.state()['project']
 for prop in ['position','target']:assert len(corrected['camera'][prop]['keys'])==2
 assert corrected['tracking_assets'][0]['data']==bound['project']['tracking_assets'][0]['data']
 live.ok('motion_seek',dict(frame=0.))
 strict=copy.deepcopy(binding);strict['max_gap_ticks']=0
 strict_state=edit([dict(op='set_tracking_camera',object=0,binding=strict)])
 failed=live.call('motion_seek',dict(frame=.5));assert failed['isError'] and 'camera interpolation gap exceeds policy' in failed['content'][0]['text'],failed
 recovered=live.ok('motion_edit',dict(commands=[dict(op='set_tracking_camera',object=0,binding=binding)],expectedRevision=strict_state['revision']));assert recovered['project']==corrected
 # The nonzero calibration is a real source observation, never silently ignored.
 distortion_frame=(pts[60]-pts[0])/ticks*24.
 failed=live.call('motion_seek',dict(frame=distortion_frame));assert failed['isError'] and 'distortion requires explicit output stage' in failed['content'][0]['text'],failed
 live.ok('motion_seek',dict(frame=0.));live.ok('motion_save',{});live.close()
 saved=json.loads((project_root/'project.json').read_text(encoding='utf-8'));assert saved['version']==35 and saved['tracking_assets'][0]['data']['tracks'][0]['samples'][24]['manual_correction'] is True
 reopen=Rpc('readonly-reopen',True);assert reopen.state()['project']==corrected;reopen.close()
 from PIL import Image
 for row in rows:
  img=Image.open(row['path']).convert('RGB');assert img.size==(640,480)
  for channel,marker in enumerate(row['markers']):
   quad=marker['quad'];errors=inside=outside=0
   for y in range(480):
    for x in range(640):
     distances=[]
     for i in range(4):
      a,b=quad[i],quad[(i+1)%4];dx,dy=b[0]-a[0],b[1]-a[1]
      distances.append((dx*(y+.5-a[1])-dy*(x+.5-a[0]))/math.hypot(dx,dy))
     if min(abs(d) for d in distances)<2.:continue
     wanted=min(distances)>0.;color=img.getpixel((x,y));seen=color[channel]>120 and all(color[j]<90 for j in range(3) if j!=channel)
     inside+=wanted;outside+=not wanted;errors+=wanted!=seen
   marker['oracle']=dict(interior=inside,exterior=outside,mismatched=errors,edgeExclusionPixels=2.)
   assert inside>50 and outside>200000 and errors==0,(row,marker)
 report['samples']=rows
 log=(OUT/'camera-binding.file.log').read_text(encoding='utf-8');stderr=(OUT/'camera-binding.stderr.log').read_text(encoding='utf-8',errors='replace')
 for sink in [log,stderr]:
  assert 'phase=binding object=0 asset=2 track=absent' in sink and re.search(r'error #\d+',sink),sink[-4000:]
  assert 'local_frame=0.5' in sink and 'camera interpolation gap exceeds policy' in sink,sink[-4000:]
  assert 'distortion requires explicit output stage' in sink and 'radial=[0.01, 0.0, 0.0]' in sink,sink[-4000:]
 assert ' INFO ' in log and re.search(r'start #\d+ import_tracking',log)
 identity();report.update(status='accepted_native_camera_increment_not_full_issue',originalSha256=hashlib.sha256(original).hexdigest(),frames=len(pts),sourceSha256=solve['source_sha256'])
except BaseException as error:report.update(status='failed',failure=repr(error));raise
finally:
 for rpc in list(active):
  try:rpc.close()
  except BaseException as secondary:report.setdefault('cleanupFailures',[]).append(repr(secondary))
 report['completedUtc']=now();save()
