"""Prepared serial real-model route control; existing frozen numerical gates."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shutil, struct, subprocess, time, tomllib

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-transition75'
PROBE = BASE / 'depth75-mixed-model-source'
OUT = BASE / 'depth75-mixed-model-v2'
OLD = BASE / 'depth75-resolution-models-v1'
PYTHON = ROOT / '.tools/ai-depth74/venv/Scripts/python.exe'
assert Path(__import__('sys').executable).resolve() == PYTHON.resolve()
assert shutil.disk_usage(ROOT).free >= 10 << 30
prior = BASE / 'depth75-routed-native-v1'
native = json.loads((prior / 'receipt.json').read_text(encoding='utf-8'))
assert native['status'] == 'all36_native_alignment_admission_binding_routing_controls_passed'
assert native['sourceUnchanged']
assert json.loads((prior / 'session-consumed.json').read_text(encoding='utf-8'))['exitCode'] == 0
qualification = BASE / 'depth75-restored-runtime-qualification-v2'
assert json.loads((qualification / 'receipt.json').read_text(encoding='utf-8'))['status'] == 'nine_frozen_reference_comparisons_and_three_profile_refusals_passed'
assert json.loads((qualification / 'session-consumed.json').read_text(encoding='utf-8'))['exitCode'] == 0
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
previous = BASE / 'depth75-routed-model-v1'
previous_report = json.loads((previous / 'receipt.json').read_text(encoding='utf-8'))
assert previous_report['status'] == 'actual_serial_two_profile_routes_match_frozen_references_and_default_refusal_channels'
assert previous_report['sourceUnchanged'] and previous_report['probeSourceUnchanged']
previous_consumed = json.loads((previous / 'session-consumed.json').read_text(encoding='utf-8'))
assert previous_consumed['session'] == 30205 and previous_consumed['exitCode'] == 0
HEAD = '15067fc59fb7a814f0a1690c62f63949982e2220'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip() == HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
names = subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
identity = lambda: {name:sha(WORK / name) for name in names}
source = identity()
for name in ('crates/motion-host/src/depth.rs','crates/motion-host/src/depth/routing.rs','crates/motion-host/tests/depth_routing.rs'):
    assert source[name] == native['source'][name]
PROGRAM = BASE / 'depth75-static-program-v1/program.json'
WORKER = ROOT / 'target/colmap88-isolated-check/debug/motion-depth-wgsl.exe'
assert sha(PROGRAM) == '2ec1d8012905198cfd5af1430f88d1770edbf752531fe817dfcc65e1477fef6a'
program = json.loads(PROGRAM.read_text(encoding='utf-8'))
resources = []
for name, resource in program['resources'].items():
    if 'file' not in resource: continue
    relative = Path(resource['file'])
    assert not relative.is_absolute() and '..' not in relative.parts
    path = PROGRAM.parent / relative
    assert path.stat().st_size == resource['bytes'] and sha(path) == resource['sha256']
    resources.append(dict(name=name,file=resource['file'],bytes=resource['bytes'],sha256=resource['sha256']))
# Frozen program has 282 references to 238 distinct content-addressed files.
assert len(resources) == 282 and sum(r['bytes'] for r in resources) == 98843588
unique_resources = {r['file']:r for r in resources}
assert len(unique_resources) == 238 and sum(r['bytes'] for r in unique_resources.values()) == 98843412
preflight = json.loads((BASE / 'depth75-mixed-model-v1-preflight-failed/receipt.json').read_text())
assert preflight['session'] == 88836 and preflight['exitCode'] == 1
assert preflight['consumedVia'] == 'actual write_stdin terminal'
probe_source = {name:sha(PROBE / name) for name in ('Cargo.toml','src/main.rs')}
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = {k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT / 'target/colmap88-isolated-check'),
           CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT / 'appdata'),TEMP=str(OUT / 'tmp'),TMP=str(OUT / 'tmp'),
           PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
Path(env['TEMP']).mkdir()
os.environ.update(TEMP=env['TEMP'], TMP=env['TMP'], LOCALAPPDATA=env['LOCALAPPDATA'])
report = dict(status='preparing',sourceCommit=HEAD,source=source,probeSource=probe_source,
              startedUtc=datetime.now(timezone.utc).isoformat(),stages=[],results=[],
              gates=dict(maxNormalized=2e-4,meanNormalized=2e-5),
              limits=['Actual CPU ONNX266 and Vulkan WGSL518 through one production Routed/Controller/Jobs',
                      '266/518 are explicit profiles, not quality labels; repeated266 is compared independently again',
                      'Same frozen RGB and independent official references; no fit or output normalization',
                      'Mixed backend numerical admission only; no real video, alignment installation, tier/capability or thermal acceptance',
                      'Actual default Info starts before outputs, Error file/stderr and isolated single JSON stdout',
                      'Original10GiB gate, E-only cache/build/temp, one own serial workload; no product retries/timeouts'])
def save(): (OUT / 'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def stage(name,command):
    row = dict(name=name,command=command,startedUtc=datetime.now(timezone.utc).isoformat())
    report['stages'].append(row); save()
    with (OUT / (name+'.stdout.log')).open('wb') as stdout, (OUT / (name+'.stderr.log')).open('wb') as stderr:
        child = subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        row['pid'] = child.pid; save()
        row['exitCode'] = child.wait(); save()
    assert row['exitCode'] == 0, row
try:
    models = [json.loads((OLD / str(side) / 'export/model.json').read_text(encoding='utf-8')) for side in (266,518)]
    keys, paths, references = [], [], []
    width,height = 153,101
    for side,model in zip((266,518),models):
        path = OLD / str(side) / 'export' / model['file']
        assert sha(path) == model['sha256'] and path.stat().st_size == model['bytes']
        reference = next(row for row in json.loads((OLD / str(side) / 'references.json').read_text(encoding='utf-8')) if row['size'] == [width,height])
        case = OLD / str(side) / f'{width}x{height}'
        assert sha(case / 'input.rgb') == reference['inputSha256']
        assert sha(case / 'official-reference.f32') == reference['referenceSha256']
        references.append((case,reference))
        paths.append(str(path))
        keys.append(dict(source=dict(asset=75,revision=1,pts=dict(ticks=0,timescale=24)),
            geometry=dict(source_size=[width,height],crop=[0,0,width,height],quarter_turns=0,mirror_x=False),
            model=dict(id=model['id'],revision=model['revision'],sha256=list(bytes.fromhex(model['sha256'])),processing=model['processing'])))
    rgb = (references[0][0] / 'input.rgb').read_bytes()
    assert rgb == (references[1][0] / 'input.rgb').read_bytes()
    expected_fingerprint = hashlib.sha256(b'MotionStudio/depth/rgb8-srgb-opaque/v1\0'+struct.pack('<II',width,height)+rgb).digest()
    request = dict(python=str(PYTHON),models=paths,keys=keys,size=[width,height],rgb=str(references[0][0] / 'input.rgb'),native_worker=str(WORKER),program=str(PROGRAM))
    (OUT / 'request.json').write_text(json.dumps(request)+'\n',encoding='utf-8')
    report.update(programSha256=sha(PROGRAM),verifiedRawWeights=resources)
    stage('build-native-worker',['cargo','build','--offline','--locked','-p','motion-desktop','--bin','motion-depth-wgsl','--features','ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth'])
    report['workerSha256'] = sha(WORKER); save()
    # Reuse the existing workspace versions; this fixture alone gains a lock.
    assert not (PROBE / 'Cargo.lock').exists()
    shutil.copyfile(WORK / 'Cargo.lock',PROBE / 'Cargo.lock')
    stage('metadata',['cargo','metadata','--offline','--format-version','1','--manifest-path',str(PROBE / 'Cargo.toml')])
    original = tomllib.loads((WORK / 'Cargo.lock').read_text(encoding='utf-8'))
    known = {(p['name'],p['version'],p.get('source')):p.get('checksum') for p in original['package']}
    resolved = tomllib.loads((PROBE / 'Cargo.lock').read_text(encoding='utf-8'))
    for package in resolved['package']:
        if package.get('source'):
            assert known[(package['name'],package['version'],package['source'])] == package.get('checksum')
    report['dependenciesMatchWorkspaceLock'] = True; save()
    stage('build',['cargo','build','--offline','--locked','--manifest-path',str(PROBE / 'Cargo.toml')])
    execution = OUT / 'execution'
    command = [str(ROOT / 'target/colmap88-isolated-check/debug/motion-depth75-mixed-model-probe.exe'),str(OUT / 'request.json'),str(execution)]
    row = dict(name='actual-routed-models',command=command,startsBeforeOutputs=[])
    report['stages'].append(row); save()
    seen = set()
    with (OUT / 'actual.stdout.log').open('wb') as stdout, (OUT / 'actual.stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        row['pid'] = child.pid; save()
        while child.poll() is None:
            log_path = execution / 'logs/motion-studio.log'
            if log_path.exists():
                lines = log_path.read_text(encoding='utf-8',errors='replace').splitlines()
                for number,route in ((1,0),(2,1),(3,0)):
                    if number in seen or (execution / f'output-{number}.f32').exists(): continue
                    matches = [line for line in lines if f'start #{number} depth_infer ' in line and ' INFO ' in line]
                    if matches:
                        assert len(matches) == 1
                        line = matches[0]
                        assert models[route]['processing'] in line and models[route]['sha256'] in line
                        row['startsBeforeOutputs'].append(dict(request=number,route=route,line=line,processRunning=True))
                        seen.add(number); save()
            time.sleep(.01)
        row['exitCode'] = child.wait(); save()
    assert row['exitCode'] == 0 and seen == {1,2,3}
    stdout = (OUT / 'actual.stdout.log').read_text(encoding='utf-8')
    assert len(stdout.splitlines()) == 1 and json.loads(stdout) == {'status':'completed','receipt':'receipt.json'}
    actual = json.loads((execution / 'receipt.json').read_text(encoding='utf-8'))
    assert actual['status'] == 'actual_two_model_routes_and_unbound_refusal_completed'
    assert (actual['submitted'],actual['completed'],actual['failed'],actual['canceled']) == (4,3,1,0)
    assert [r['route'] for r in actual['stages']] == [0,1,0]
    import numpy as np
    for record in actual['stages']:
        number,route = record['request'],record['route']
        assert record['key'] == keys[route]
        assert record['provider'] == 'CPUExecutionProvider' if route == 0 else record['provider'].startswith('WGSL:Vulkan:')
        assert record['prepared'] == dict(rgb_size=[width,height],rgb_sha256=list(expected_fingerprint))
        assert record['values'] == width*height and record['sourceRgbBytes'] == len(rgb)
        expected = np.fromfile(references[route][0] / 'official-reference.f32',dtype='<f4')
        output = execution / f'output-{number}.f32'
        result = np.fromfile(output,dtype='<f4')
        assert result.shape == expected.shape == (width*height,)
        assert np.isfinite(result).all() and np.isfinite(expected).all()
        difference = np.abs(result.astype(np.float64)-expected.astype(np.float64))
        amplitude = max(float(np.abs(expected).max()),1e-6)
        maximum,mean = float(difference.max())/amplitude,float(difference.mean())/amplitude
        assert maximum <= 2e-4 and mean <= 2e-5
        report['results'].append(dict(request=number,route=route,maxNormalized=maximum,meanNormalized=mean,
            outputSha256=sha(output),actual=record)); save()
    cause = 'no depth route for the exact requested model identity'
    file_log = (execution / 'logs/motion-studio.log').read_text(encoding='utf-8')
    stderr = (OUT / 'actual.stderr.log').read_text(encoding='utf-8')
    assert any(' ERROR ' in line and 'request=4 ' in line and cause in line for line in file_log.splitlines())
    assert 'ERROR motion_host::depth:' in stderr and 'request=4 ' in stderr and cause in stderr
    assert len(actual['stages']) == len(report['results']) == 3
    report.update(status='actual_serial_mixed_cpu_wgsl_routes_match_frozen_references_and_default_refusal_channels',actual=actual)
except BaseException as error:
    report.update(status='failed_original_outputs_retained',cause=repr(error))
finally:
    report.update(sourceUnchanged=identity()==source,
        probeSourceUnchanged={name:sha(PROBE / name) for name in probe_source}==probe_source,
        completedUtc=datetime.now(timezone.utc).isoformat())
    save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','probeSource','results','actual','verifiedRawWeights')}))
raise SystemExit(0 if report['status'].startswith('actual_serial_mixed_cpu_wgsl') and report['sourceUnchanged'] and report['probeSourceUnchanged'] else 1)
