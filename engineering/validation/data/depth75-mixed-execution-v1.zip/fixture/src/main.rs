//! Local real-model acceptance control, not a shipped application or quality ranking.
#[path = "E:/Dev/aem/.worktrees/depth-transition75/desktop/app/src/logging/sink.rs"]
mod logging;
mod engine {
    pub fn current_command() -> Option<(u64, &'static str, std::time::Duration)> {
        None
    }
}
use motion_host::depth::{
    onnx::{Config, Onnx, Provider},
    routing::Routed,
    transition::{Activity, Choices, Controller, Policy},
    wgsl::{Config as WgslConfig, Hardware, Wgsl},
    Error, Input, Jobs, Key,
};
use std::{
    fs,
    io::Read,
    path::{Path, PathBuf},
    sync::Arc,
    time::Duration,
};

fn absolute(value: &serde_json::Value) -> Result<PathBuf, Box<dyn std::error::Error>> {
    let path = PathBuf::from(value.as_str().ok_or("missing path")?);
    if !path.is_absolute() || !path.starts_with("E:/Dev/aem") {
        return Err("owned absolute E path required".into());
    }
    Ok(path)
}
fn run(request: &Path, out: &Path) -> Result<serde_json::Value, Box<dyn std::error::Error>> {
    let mut raw = Vec::new();
    fs::File::open(request)?.take(65537).read_to_end(&mut raw)?;
    if raw.len() > 65536 {
        return Err("bounded request required".into());
    }
    let config: serde_json::Value = serde_json::from_slice(&raw)?;
    let python = absolute(&config["python"])?;
    let first: Key = serde_json::from_value(config["keys"][0].clone())?;
    let second: Key = serde_json::from_value(config["keys"][1].clone())?;
    let size: [u32; 2] = serde_json::from_value(config["size"].clone())?;
    let mut rgb = Vec::new();
    fs::File::open(absolute(&config["rgb"])?)?
        .take(4096 * 4096 * 3 + 1)
        .read_to_end(&mut rgb)?;
    let rgb: Arc<[u8]> = rgb.into();
    let make_backend = |index: usize| -> Result<Onnx, Box<dyn std::error::Error>> {
        Ok(Onnx::new(Config {
            python: python.clone(),
            model: absolute(&config["models"][index])?,
            scratch: out.join(format!("scratch-{index}")),
            provider: Provider::Cpu,
        })?)
    };
    for index in 0..2 {
        fs::create_dir(out.join(format!("scratch-{index}")))?;
    }
    let mut jobs = Jobs::start(Routed::new(
        first.model.clone(),
        make_backend(0)?,
        second.model.clone(),
        Wgsl::new(WgslConfig {
            python: python.clone(),
            worker: absolute(&config["native_worker"])?,
            program: absolute(&config["program"])?,
            scratch: out.join("scratch-1"),
            hardware: Hardware::Vulkan,
        })?,
    )?)?;
    let mut controller = Controller::new(Policy {
        idle_delay: Duration::from_millis(100),
        minimum_interactive_residence: Duration::from_millis(300),
    })?;
    let choices = Choices {
        interactive: first.clone(),
        settled: second,
    };
    let mut stages = Vec::new();
    for (activity, clock, expected_route) in [
        (Activity::Interactive, 0, Some(0)),
        (Activity::Idle, 300, None),
        (Activity::Idle, 400, Some(1)),
        (Activity::Interactive, 401, Some(0)),
    ] {
        let ticket = controller.observe(choices.clone(), activity, Duration::from_millis(clock))?;
        let Some(route) = expected_route else {
            if ticket.is_some() {
                return Err("idle admission bypassed explicit hysteresis".into());
            }
            continue;
        };
        let ticket = ticket.ok_or("missing transition ticket")?;
        let request = controller
            .request(
                &ticket,
                &mut jobs,
                Input::new(ticket.key().clone(), size, rgb.clone())?,
            )?
            .ok_or("request not submitted")?;
        fs::write(
            out.join(format!("submitted-{request}.json")),
            serde_json::to_vec(&serde_json::json!({
                "request":request,"generation":ticket.generation(),"model":ticket.key().model,"route":route
            }))?,
        )?;
        // No product timeout or retry. In-flight state remains externally visible.
        let result = loop {
            if let Some(result) = controller.take_ready(&ticket, &mut jobs, ticket.key())? {
                break result;
            }
            std::thread::sleep(Duration::from_millis(5));
        };
        let values = result.estimate().resource.values();
        let mut bytes = Vec::with_capacity(values.len() * 4);
        for value in values {
            bytes.extend(value.to_le_bytes());
        }
        fs::write(out.join(format!("output-{request}.f32")), bytes)?;
        let estimate = result.estimate();
        stages.push(serde_json::json!({"request":request,"generation":ticket.generation(),
            "route":route,"key":ticket.key(),"prepared":result.input(),"provider":estimate.provider,
            "inferenceNs":estimate.costs.inference.as_nanos(),"totalNs":estimate.costs.total.as_nanos(),
            "sourceRgbBytes":estimate.costs.source_rgb_bytes,"values":values.len()}));
    }
    let mut unknown = first;
    unknown.model.processing = "unbound-profile-for-controlled-refusal".into();
    let refused_request = jobs.request(Input::new(unknown.clone(), size, rgb)?)?;
    loop {
        match jobs.take_ready(&unknown) {
            Ok(None) => std::thread::sleep(Duration::from_millis(5)),
            Err(Error::Invalid("no depth route for the exact requested model identity")) => break,
            other => {
                return Err(format!("unbound route did not preserve its refusal: {other:?}").into())
            }
        }
    }
    let counts = jobs.counts()?;
    if counts.submitted != 4
        || counts.completed != 3
        || counts.failed != 1
        || counts.canceled != 0
        || jobs.in_flight()?.is_some()
        || jobs.queue_depth()? != 0
    {
        return Err("actual routed Jobs did not drain with original refusal".into());
    }
    Ok(
        serde_json::json!({"status":"actual_two_model_routes_and_unbound_refusal_completed",
        "stages":stages,"refusedRequest":refused_request,"submitted":counts.submitted,
        "completed":counts.completed,"failed":counts.failed,"canceled":counts.canceled}),
    )
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args_os().skip(1).collect();
    if args.len() != 2 {
        return Err("expected absolute request and output root".into());
    }
    let request = PathBuf::from(&args[0]);
    let out = PathBuf::from(&args[1]);
    if !request.is_absolute() || !out.is_absolute() {
        return Err("absolute paths required".into());
    }
    fs::create_dir(&out)?;
    let _logging = logging::init(out.join("logs"))?;
    let result = run(&request, &out);
    match result {
        Ok(report) => {
            fs::write(
                out.join("receipt.json"),
                serde_json::to_vec_pretty(&report)?,
            )?;
            println!(
                "{}",
                serde_json::json!({"status":"completed","receipt":"receipt.json"})
            );
            Ok(())
        }
        Err(error) => {
            log::error!("operation=routed_depth_acceptance cause={error}");
            Err(error)
        }
    }
}
