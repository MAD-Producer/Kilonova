"""Archive the actual mixed-backend control without models or tensor payloads."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-transition75'
RUN = BASE / 'depth75-mixed-model-v2'
PROBE = BASE / 'depth75-mixed-model-source'
FAILED = BASE / 'depth75-mixed-model-v1-preflight-failed'
OUT = BASE / 'depth75-mixed-public-v1'
report = json.loads((RUN / 'receipt.json').read_text(encoding='utf-8'))
consumed = json.loads((RUN / 'session-consumed.json').read_text(encoding='utf-8'))
assert consumed['session'] == 69903 and consumed['exitCode'] == 0
assert report['status'] == 'actual_serial_mixed_cpu_wgsl_routes_match_frozen_references_and_default_refusal_channels'
assert report['sourceUnchanged'] and report['probeSourceUnchanged']
assert report['sourceCommit'] == '15067fc59fb7a814f0a1690c62f63949982e2220'
assert len(report['results']) == 3
assert [row['route'] for row in report['results']] == [0, 1, 0]
assert report['gates'] == dict(maxNormalized=2e-4, meanNormalized=2e-5)
assert all(row['maxNormalized'] <= 2e-4 and row['meanNormalized'] <= 2e-5 for row in report['results'])
assert len(next(stage for stage in report['stages'] if stage['name'] == 'actual-routed-models')['startsBeforeOutputs']) == 3
failed = json.loads((FAILED / 'receipt.json').read_text(encoding='utf-8'))
assert failed['session'] == 88836 and failed['exitCode'] == 1
assert failed['consumedVia'] == 'actual write_stdin terminal'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
members = {}


def add(directory, names, prefix):
    for name in names:
        members[prefix + '/' + name] = (directory / name).read_bytes()


add(RUN, ('controller.py', 'receipt.json', 'session-consumed.json', 'request.json',
          'build-native-worker.stdout.log', 'build-native-worker.stderr.log',
          'metadata.stdout.log', 'metadata.stderr.log', 'build.stdout.log', 'build.stderr.log',
          'actual.stdout.log', 'actual.stderr.log'), 'evidence/mixed')
add(RUN / 'execution', ('receipt.json', 'logs/motion-studio.log'), 'evidence/mixed/execution')
add(FAILED, ('controller.py', 'receipt.json'), 'evidence/previous-preflight-refusal')
for name in ('Cargo.toml', 'Cargo.lock', 'src/main.rs'):
    raw = (PROBE / name).read_bytes()
    if name in report['probeSource']:
        assert sha(raw) == report['probeSource'][name]
    members['fixture/' + name] = raw
sources = ('crates/motion-host/src/depth.rs', 'crates/motion-host/src/depth/routing.rs',
           'crates/motion-host/src/depth/transition.rs', 'crates/motion-host/src/depth/wgsl.rs',
           'crates/motion-host/src/depth/onnx.rs', 'desktop/app/src/logging/sink.rs')
for name in sources:
    raw = (WORK / name).read_bytes()
    assert sha(raw) == report['source'][name], name
    members['source/' + name] = raw
members['archive-controller.py'] = Path(__file__).read_bytes()
manifest = dict(schema=1, sourceCommit=report['sourceCommit'],
    observedUtc=datetime.now(timezone.utc).isoformat(),
    status='actual_serial_cpu266_vulkan518_cpu266_frozen_comparisons_passed',
    sourceFiles={name: report['source'][name] for name in sources},
    routes=[dict(request=row['request'], route=row['route'], provider=row['actual']['provider'],
                 model=row['actual']['key']['model'], maxNormalized=row['maxNormalized'],
                 meanNormalized=row['meanNormalized']) for row in report['results']],
    originalNumericalGates=report['gates'], workerSha256=report['workerSha256'],
    programSha256=report['programSha256'],
    limits=['Actual heterogeneous production Routed/Controller/Jobs with explicit identities and one worker',
            'Three independent frozen-reference comparisons; no fit or normalization to hide backend differences',
            'Actual default Info starts before outputs; original refusal in file and stderr; one JSON stdout',
            'Previous observer preflight failure is retained: references and unique resource files were confused',
            'Exact program hash, all282 references and238 unique file hashes/bytes checked before execution',
            'No automatic capability/quality choice, real video, installation/cache/export or thermal qualification',
            'No Android or other desktop GPU qualification, default model distribution or UI change',
            'No weights/models, image/RGB/scalar tensors, native executable, symbols or minidump included'],
    members={name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in members.items()})
OUT.mkdir(exist_ok=False)
archive = OUT / 'depth75-mixed-execution-v1.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
    for name,raw in members.items():
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == {'manifest.json', *members}
    assert json.loads(z.read('manifest.json')) == manifest
    for name,item in manifest['members'].items():
        raw = z.read(name)
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256'], name
manifest['archive'] = dict(file=archive.name, bytes=archive.stat().st_size,
    sha256=sha(archive.read_bytes()), verifiedMembers=len(members) + 1)
(OUT / 'depth75-mixed-execution-v1.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key:manifest[key] for key in ('status','sourceCommit','routes','archive')}))
