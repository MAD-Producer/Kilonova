"""Frozen final-source whole-workspace and real desktop protocol acceptance."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/render-dag'
label=sys.argv[1];assert re.fullmatch(r'v[0-9]+',label)
out=root/'artifacts/pr-queue'/('issue78-final-g-'+label);out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=work)
def source():
 names=set()
 for args in [('ls-files','-z'),('ls-files','--others','--exclude-standard','-z')]:
  names.update(p.decode() for p in git(*args).split(b'\0') if p)
 return {p:sha((work/p).read_bytes()) for p in sorted(names) if (work/p).is_file() and (p.endswith(('.rs','.wgsl','.glsl','.json','.toml')) or p=='Cargo.lock')}
assert not git('status','--porcelain').strip(),'start from committed clean source'
inputs=source();head=git('rev-parse','HEAD').decode().strip();base=os.environ.get('MOTION_FINAL_G_BASE') or git('rev-parse','origin/main').decode().strip()
subprocess.run(['git','merge-base','--is-ancestor',base,head],cwd=work,check=True)
changed=[p.decode() for p in git('diff','--name-only','-z',base,head).split(b'\0') if p]
assert not any(p.startswith(('desktop/app/src/panels/','android/')) for p in changed)
for name in inputs:
 if name in changed:
  target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((work/name).read_bytes())
env=os.environ.copy();target=root/'target/original-source-memory-b273180a'
env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',MOTION_EXECUTION_ARTIFACTS=str(out/'output-artifacts'),MOTION_POINTWISE_ARTIFACTS=str(out/'pointwise-artifacts'),MOTION_POINTWISE_EXTREME_ARTIFACTS=str(out/'alpha-artifacts'),MOTION_POINTWISE_FILE_ARTIFACTS=str(out/'compiler-artifacts'),RUST_BACKTRACE='1')
env.pop('MOTION_LOG',None)
features='motion-host/diagnostics,motion-host/gpu-tests,motion-ui/gpu-tests,motion-desktop/gpu-tests,motion-desktop/ffmpeg,motion-desktop-media/gpu-tests,motion-graph/gpu-tests'
binary=target/'debug/motion-studio.exe'
style="import runpy; runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"
steps=[('panel-style-consumers',[sys.executable,'-c',style]),
 ('desktop-check',[sys.executable,'tools/build_desktop.py','--task','check','--debug','--ffmpeg','--locked','--target-dir',str(target)]),
 ('workspace-tests',['cargo','test','--workspace','--exclude','motion-android','--locked','--offline','--features',features,'--no-fail-fast','--','--test-threads=1']),
 ('desktop-binary',['cargo','build','-p','motion-desktop','--features','ffmpeg','--locked','--offline']),
 ('command-list',[str(binary),'--command-list'])]
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
toolchain={name:subprocess.check_output(cmd,cwd=work,env=env,text=True) for name,cmd in [('rustc',['rustc','-Vv']),('cargo',['cargo','-V']),('git',['git','--version'])]}
receipt=dict(head=head,base=base,source=inputs,startedUtc=now(),controllerPid=os.getpid(),steps=[],toolchain=toolchain,
 environment={k:env.get(k) for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_NET_OFFLINE','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','TEMP','TMP','LIBCLANG_PATH','FFMPEG_DIR','MOTION_LOG']})
for name,cmd in steps:
 stage=out/name;stage.mkdir();item=dict(name=name,command=cmd,startedUtc=now());receipt['steps'].append(item)
 childenv=env.copy()
 if name=='command-list':childenv['LOCALAPPDATA']=str(out/'isolated-local-app-data')
 print(json.dumps(dict(starting=name,output=str(stage))),flush=True)
 with (stage/'stdout.log').open('wb') as stdout,(stage/'stderr.log').open('wb') as stderr:
  process=subprocess.Popen(cmd,cwd=work,env=childenv,stdout=stdout,stderr=stderr);item['pid']=process.pid
  (out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');code=process.wait()
 item.update(exitCode=code,completedUtc=now(),sourceUnchanged=source()==inputs,worktreeClean=not git('status','--porcelain').strip())
 for stream in ['stdout','stderr']:item[stream+'Sha256']=sha((stage/(stream+'.log')).read_bytes())
 (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
 assert item['sourceUnchanged'] and item['worktreeClean'],'source changed during final gate'
 if code:print(json.dumps(dict(stage=name,exitCode=code)),flush=True);sys.exit(code)
 if name=='workspace-tests':
  results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (stage/'stdout.log').read_text(encoding='utf-8'))
  assert results and sum(int(r[0]) for r in results)>0
  assert all(int(r[1])==0 for r in results)
  item['totals']=dict(passed=sum(int(r[0]) for r in results),failed=0,ignored=sum(int(r[2]) for r in results),targets=len(results))
 if name=='command-list':
  catalogue=json.loads((stage/'stdout.log').read_text(encoding='utf-8'))
  assert catalogue['protocol']=='motion-core-command-v1' and catalogue['commands']
  assert binary.is_file()
  item['binarySha256']=sha(binary.read_bytes());item['catalogueCommands']=len(catalogue['commands'])
  assert (out/'isolated-local-app-data/MotionStudio/logs/motion-studio.log').is_file()
 print(json.dumps(dict(completed=name,exitCode=code,totals=item.get('totals'))),flush=True)
receipt.update(completedUtc=now(),sourceUnchanged=source()==inputs)
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,output=str(out))),flush=True)
