from pathlib import Path
import json,os,subprocess,sys
root=Path('E:/Dev/aem');folder=root/'.tools/issue-closure-review'
env=os.environ.copy();env['MOTION_FINAL_G_BASE']='9dbdf75f6b6c800b52bed95b00bcf02db8ed3b71'
receipt=dict(controllerPid=os.getpid(),steps=[])
output=root/'artifacts/pr-queue/issue78-complete-regression-v1.json'
for command in [[sys.executable,str(folder/'validate-issue78-full-software-v4.py')],
                [sys.executable,str(folder/'validate-issue78-final-g.py'),'v8']]:
    child=subprocess.Popen(command,cwd=root,env=env)
    step=dict(command=command,pid=child.pid);receipt['steps'].append(step)
    output.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    step['exitCode']=child.wait();output.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    if step['exitCode']:sys.exit(step['exitCode'])
