from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('E:/Dev/aem'); work=root/'.worktrees/render-dag'; out=root/'artifacts/pr-queue'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=work,text=True).strip()
head='8ffb5af7030372d180131d732579b5c036c3b13c'
assert git('rev-parse','HEAD')==head
payload={}
receipts={}
for label in ['issue78-final-g-v8','issue78-full-software-v4']:
    run=out/label; receipt=json.loads((run/'accepted.json').read_text(encoding='utf-8'))
    assert receipt['head']==head and receipt['sourceUnchanged']
    for name,digest in receipt['source'].items():
        assert sha((work/name).read_bytes())==digest,name
    if 'steps' in receipt:
        assert all(s['exitCode']==0 and s['sourceUnchanged'] and s['worktreeClean'] for s in receipt['steps'])
        for s in receipt['steps']:
            for stream in ['stdout','stderr']:
                assert sha((run/s['name']/(stream+'.log')).read_bytes())==s[stream+'Sha256']
        assert next(s['totals'] for s in receipt['steps'] if s['name']=='workspace-tests')==dict(passed=3070,failed=0,ignored=12,targets=302)
    else:
        assert receipt['exitCode']==0 and receipt['totals']==dict(passed=889,failed=0,ignored=1,targets=151)
    for p in run.rglob('*'):
        if p.is_file(): payload[label+'/'+p.relative_to(run).as_posix()]=p.read_bytes()
    receipts[label]=receipt
g=receipts['issue78-final-g-v8']; base=g['base']
assert base=='9dbdf75f6b6c800b52bed95b00bcf02db8ed3b71'
subprocess.run(['git','merge-base','--is-ancestor',base,head],cwd=work,check=True)
main_files=git('diff','--name-only','af1e7f9f07dceb03d8f078889505adf1db78542f',base,'--','*.rs').splitlines()
for name in main_files:
    data=(work/name).read_bytes(); assert sha(data)==g['source'][name]
    payload['aligned-main-source/'+name]=data
ci=json.loads((out/'issue78-shader-budget-ci-current.json').read_text(encoding='utf-8'))
assert len(ci)==7 and all(row['status']=='completed' and row['conclusion'] in ['success','skipped'] for row in ci)
assert sum(row['conclusion']=='success' for row in ci)==5
payload['ci/jobs-run-40315736241.json']=(out/'issue78-shader-budget-ci-current.json').read_bytes()
payload['controller/archive.py']=Path(__file__).read_bytes()
payload['controller/complete-regression.py']=(root/'.tools/issue-closure-review/validate-issue78-complete-regression.py').read_bytes()
payload['controller/software.py']=(root/'.tools/issue-closure-review/validate-issue78-full-software.py').read_bytes()
payload['controller/software-v4.py']=(root/'.tools/issue-closure-review/validate-issue78-full-software-v4.py').read_bytes()
payload['controller/combined-receipt.json']=(out/'issue78-complete-regression-v1.json').read_bytes()
manifest=dict(head=head,base=base,alignedMainRustFiles=len(main_files),
    remoteRun=40315736241,remoteHead=head,
    scope='Frozen whole maintained workspace, native GPU, separate software Vulkan, real desktop binary/command catalogue. Twelve explicitly ignored opt-in tests remain reported; Android excluded by instruction. Later docs are not attributed to executable acceptance.',
    files={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(payload.items())})
payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=work/'engineering/validation/data/typed-render-dag-final-g8-8ffb5af7.zip'
assert not dest.exists()
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(payload.items()): z.writestr(name,data)
with zipfile.ZipFile(dest) as z:
    assert set(z.namelist())==set(payload)
    for name,data in payload.items(): assert sha(z.read(name))==sha(data)
result=dict(file=dest.name,bytes=dest.stat().st_size,files=len(payload),sha256=sha(dest.read_bytes()),head=head,base=base,alignedMainRustFiles=len(main_files))
(out/'issue78-final-g8-archive.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
