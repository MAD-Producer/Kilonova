from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/render-dag'
out=root/'artifacts/pr-queue/issue78-full-software-v4';out.mkdir(exist_ok=False)
def source():
 names=subprocess.check_output(['git','ls-files','-z'],cwd=work).split(b'\0')
 return {p.decode():hashlib.sha256((work/p.decode()).read_bytes()).hexdigest() for p in names if p and (p.endswith((b'.rs',b'.wgsl',b'.glsl',b'.toml',b'.json')) or p==b'Cargo.lock')}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work).strip()
env=os.environ.copy();driver=root/'.tools/android-sdk/emulator/lib64/vulkan/lvp_icd.json'
env.update(CARGO_TARGET_DIR=str(root/'target/original-source-memory-b273180a'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true',WGPU_BACKEND='vulkan',VK_DRIVER_FILES=str(driver),MOTION_EXECUTION_ARTIFACTS=str(out/'output-artifacts'),MOTION_POINTWISE_EXTREME_ARTIFACTS=str(out/'alpha-artifacts'),MOTION_POINTWISE_ARTIFACTS=str(out/'chain-artifacts'))
env['MESA_SHADER_CACHE_DIR']=str(root/'target/software-vulkan-cache')
env['PATH']=str(driver.parent)+os.pathsep+env['PATH'];env.pop('MOTION_LOG',None)
command=['cargo','test','-p','motion-effects','-p','motion-render','-p','motion-graph','--features','motion-graph/gpu-tests','--locked','--offline','--no-fail-fast','--','--test-threads=1']
receipt=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),source=source(),command=command)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 process=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);receipt['pid']=process.pid;(out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');code=process.wait()
receipt.update(exitCode=code,sourceUnchanged=receipt['source']==source());(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');assert receipt['sourceUnchanged']
if code:sys.exit(code)
text=(out/'stdout.log').read_text(encoding='utf-8')
results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
receipt['totals']=dict(passed=sum(int(r[0]) for r in results),failed=sum(int(r[1]) for r in results),ignored=sum(int(r[2]) for r in results),targets=len(results))
ignored=lambda text:set(re.findall(r'^test (\S+) \.\.\. ignored',text,re.M))
baseline=ignored((root/'artifacts/pr-queue/issue78-final-g-v1/workspace-tests/stdout.log').read_text(encoding='utf-8'))
assert results and receipt['totals']['failed']==0 and ignored(text)<=baseline
receipt['ignoredNames']=sorted(ignored(text));(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt['totals']),flush=True)
