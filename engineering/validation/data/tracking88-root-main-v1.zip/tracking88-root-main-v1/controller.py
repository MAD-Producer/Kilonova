from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-import88'
out = root / 'artifacts/pr-queue/tracking88-root-main-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=work, text=True).splitlines()
source = {p: sha(work / p) for p in sorted(set(paths)) if p.endswith(('.rs', 'Cargo.toml', 'Cargo.lock')) and (work / p).is_file()}
owned = ['crates/motion-core/src/command_registry.rs', 'crates/motion-core/src/history_accounting.rs',
    'crates/motion-model/src/commands.rs', 'crates/motion-model/src/lib.rs', 'crates/motion-model/src/model.rs']
for kind in ['point', 'plane', 'camera']:
    owned += [f'crates/motion-model/tests/tracking_{kind}.rs', f'crates/motion-model/tests/tracking_layer_time/{kind}.rs']
for relative in owned:
    target = out / 'source' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((work / relative).read_bytes())
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(root / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1',
    RUST_BACKTRACE='full', TEMP=str(root / 'target/ci-policy-validation-tmp'), TMP=str(root / 'target/ci-policy-validation-tmp'))
command = ['cargo', 'test', '-p', 'motion-model', '-p', 'motion-core', '--locked', '--offline', '--no-fail-fast', '--', '--test-threads=1']
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), command=command, source=source,
    head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip(),
    integratedMain=subprocess.check_output(['git', 'rev-parse', 'MERGE_HEAD'], cwd=work, text=True).strip())
started = time.monotonic()
def save():
    pending = out / 'exit.pending.json'
    pending.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(pending, out / 'exit.json')
save()
try:
    with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    report['sourceUnchanged'] = all(sha(work / p) == digest for p, digest in source.items())
    assert report['sourceUnchanged'], 'source changed during validation'
    assert report['exitCode'] == 0, report['exitCode']
    report['status'] = 'root_pr_complete_model_and_core_packages_on_main_passed'
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - started, 3))
    save()
    print(json.dumps({key: report.get(key) for key in ['status', 'exitCode', 'failure', 'elapsedSeconds']}, indent=2), flush=True)
