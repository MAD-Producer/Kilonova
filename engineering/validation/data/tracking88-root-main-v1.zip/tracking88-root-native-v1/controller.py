from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-import88'
out = root / 'artifacts/pr-queue/tracking88-root-native-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=work, text=True).splitlines()
source = {p: sha(work / p) for p in sorted(set(paths)) if p.endswith(('.rs', '.wgsl', 'Cargo.toml', 'Cargo.lock')) and (work / p).is_file()}
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(root / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1', RUST_BACKTRACE='full',
    MOTION_TRACKING_RELINK_NATIVE_DIR=str(out / 'native'), LIBCLANG_PATH=str(root / '.tools/python-libclang/clang/native'),
    TEMP=str(root / 'target/ci-policy-validation-tmp'), TMP=str(root / 'target/ci-policy-validation-tmp'))
ffmpeg = root / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(FFMPEG_DIR=str(ffmpeg), FFMPEG_INCLUDE_DIR=str(ffmpeg / 'include'), FFMPEG_LIB_DIR=str(ffmpeg / 'lib'))
env['PATH'] = str(ffmpeg / 'bin') + os.pathsep + env['PATH']
renderer = ['cargo', 'test', '-p', 'motion-render', '--locked', '--offline', '--no-fail-fast']
for target in ['tracking_lens', 'layer_time_nested', 'model_layers', 'video_yuv', 'video_instances', 'video_lifetime', 'video_allocation_budget']:
    renderer += ['--test', target]
renderer += ['--', '--test-threads=1']
commands = [('renderer', renderer),
    ('desktop', ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg', '--bin', 'motion-studio', '--locked', '--offline',
        'engine::tracking_relink_tests::tracked_image_relink_keeps_native_output_and_records_wrong_source', '--', '--exact', '--test-threads=1', '--nocapture'])]
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), source=source, steps=[],
    head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip(),
    integratedMain=subprocess.check_output(['git', 'rev-parse', 'MERGE_HEAD'], cwd=work, text=True).strip())
started = time.monotonic()
def save():
    pending = out / 'exit.pending.json'
    pending.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(pending, out / 'exit.json')
save()
try:
    for name, command in commands:
        step = dict(name=name, command=command, startedUtc=datetime.now(timezone.utc).isoformat())
        report['steps'].append(step)
        save()
        with (out / f'{name}.stdout.log').open('wb') as stdout, (out / f'{name}.stderr.log').open('wb') as stderr:
            child = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
            step['pid'] = child.pid
            save()
            step['exitCode'] = child.wait()
        step['completedUtc'] = datetime.now(timezone.utc).isoformat()
        save()
        assert step['exitCode'] == 0, step
        assert all(sha(work / p) == digest for p, digest in source.items()), 'source changed'
    log = (out / 'native/logs/motion-studio.log').read_text(encoding='utf-8')
    stderr = (out / 'desktop.stderr.log').read_text(encoding='utf-8', errors='replace')
    stdout = (out / 'desktop.stdout.log').read_text(encoding='utf-8', errors='replace')
    assert '1 passed; 0 failed' in stdout
    assert 'asset relink tracking start request=desktop-relink-wrong' in log
    for sink in [log, stderr]:
        assert 'asset relink tracking failed request=desktop-relink-wrong' in sink
        assert 'tracking source content differs' in sink
    assert 'asset relink tracking failed' not in stdout
    report['sourceUnchanged'] = all(sha(work / p) == digest for p, digest in source.items())
    assert report['sourceUnchanged']
    report['status'] = 'root_main_renderer_and_actual_native_relink_passed'
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - started, 3))
    save()
    print(json.dumps({key: report.get(key) for key in ['status', 'failure', 'elapsedSeconds']}, indent=2), flush=True)
