from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges';out=root/'.tools/curve-view-ranges'
r=json.loads((out/'performance-current-06/receipt.json').read_text());assert r['source_unchanged'] and r['run']['validated']
folder=out/'integration-followups-30';folder.mkdir(exist_ok=False)
def freeze():
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=work,text=True).splitlines()
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p.startswith(('crates/','desktop/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']}
assert freeze()==r['sources']
assert hashlib.sha256(Path(r['binary']).read_bytes()).hexdigest()==r['binary_sha256']
record=dict(head=r['head'],binary_sha256=r['binary_sha256'],build_receipt=str(out/'performance-current-06/receipt.json'),sources=r['sources'],runs=[],active=None,source_unchanged=True)
def save():
    record['source_unchanged']=freeze()==r['sources'];(folder/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8')
env=os.environ.copy();env.pop('MOTION_LOG',None)
targets=[('project-modal','panels::project::tests::'),('keyboard-routing','panels::keyboard::tests::'),('audio-preview','shell::audio_preview_tests::')]
for name,pattern in targets:
    record['active']=name;save();began=time.monotonic()
    with (folder/(name+'.log')).open('w',encoding='utf8') as sink:
        child=subprocess.run([r['binary'],pattern,'--nocapture','--test-threads=1'],cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT,timeout=1800)
    summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',(folder/(name+'.log')).read_text(encoding='utf8'))
    item=dict(name=name,filter=pattern,exit_code=child.returncode,summary=summaries,seconds=round(time.monotonic()-began,2));record['runs'].append(item);record['active']=None;save();print(json.dumps(item),flush=True)
    assert child.returncode==0 and len(summaries)==1 and summaries[0][0]=='ok' and int(summaries[0][1])>0 and summaries[0][2]=='0' and record['source_unchanged']
record['active']='desktop-all-targets-check';save()
# The final shared-target library build was baseline10. Force the feature's
# embedded sheet and app roots; core libraries have the same frozen main.
for relative in ['desktop/ui/src/lib.rs','desktop/app/src/main.rs']:(work/relative).touch()
command=['cargo','check','-p','motion-desktop','--all-targets','--features','ffmpeg','--locked','--offline','-j1']
began=time.monotonic()
with (folder/'all-targets.log').open('w',encoding='utf8') as sink:child=subprocess.run(command,cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT,timeout=2400)
record['all_targets']=dict(command=command,exit_code=child.returncode,seconds=round(time.monotonic()-began,2));record['active']=None;save()
assert child.returncode==0 and record['source_unchanged']
record['scope']='Three actual integration suites and a real FFmpeg desktop all-targets check at the frozen source. Native/performance and actual CI checkouts are separate records; no repeat of the 136-case default-fault study claimed here.';save()
print(json.dumps(dict(head=record['head'],all_targets=record['all_targets'],source_unchanged=record['source_unchanged'])),flush=True)
