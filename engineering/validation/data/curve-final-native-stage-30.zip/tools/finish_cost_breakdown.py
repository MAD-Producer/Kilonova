from pathlib import Path
import datetime,json,os,subprocess,sys,time
root=Path('E:/Dev/aem');out=root/'.tools/curve-view-ranges';path=out/'cost-breakdown-workflow.json'
assert not path.exists()
record=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),status='running',active=None,steps=[])
def save():path.write_text(json.dumps(record,indent=2),encoding='utf8')
steps=[
    ('paired-work-census','run_profile_sequence.py',['performance-baseline-10','performance-current-06'],7800),
    ('work-census-analysis','analyze_graph_performance.py',['performance-baseline-10','performance-current-06'],120),
    ('panel-work-analysis','analyze_panel_deltas.py',[],120),
    ('native-current-main','verify_graph_ranges_native.py',['30','--compiled-profile=performance-current-06'],2100),
    ('integration-and-all-targets','run_integration_followups.py',[],8400),
]
for name,script,args,limit in steps:
    record['active']=name;save();began=time.monotonic();print('Started '+name,flush=True)
    try:child=subprocess.run([sys.executable,str(out/script),*args],cwd=root,timeout=limit)
    except BaseException as error:
        record.update(status='supervision-failed',cause=type(error).__name__+': '+str(error));save();raise
    record['steps'].append(dict(name=name,exit_code=child.returncode,seconds=round(time.monotonic()-began,2)));record['active']=None;save()
    if child.returncode:record['status']='failed';save();raise SystemExit(child.returncode)
record['status']='completed';save();print(json.dumps(record),flush=True)
