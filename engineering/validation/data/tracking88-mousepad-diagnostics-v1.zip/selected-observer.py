"""Observe the original first15 frames' fit masks; never change a tracker decision."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import logging
import os
import subprocess
import traceback

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/planar-tracker88'
OUT = ART / 'tracking88-mousepad-first-loss-v1'
CP = ART / 'depth75-resume-current.json'
SOURCE = ART / 'tracking88-real-planar-acquisition-v1/mouse-pad.avi'
BASE = ART / 'tracking88-mousepad-full-core-v1'
HEAD = 'd21b9df82f5f3c7b4a35af2bfd5d4e91b7928231'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, value):
    pending = path.with_suffix(path.suffix + '.pending')
    pending.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    pending.replace(path)


state = read(CP)
v = state['versionedCache75']
assert v['activeController'] is None and not v['ownHeavyWorkloads']
assert read(BASE / 'session-consumed.json')['original_tool_result_consumed']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK, text=True).strip()
assert sha(SOURCE) == 'f7cfe7d11fb64111777b6074a21bc58de7fc500ebce15f26577ee0ba2c4f890f'
base_report = read(BASE / 'receipt.json')
baseline = BASE / 'no-corrections/observations.jsonl'
assert sha(baseline) == base_report['blind_output_seals'][0]['sha256']
names = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()
hashes = {name: sha(WORK / name) for name in names}
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
os.environ.update(TEMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'),
                  TMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'), PYTHONDONTWRITEBYTECODE='1')
report = dict(status='running', head=HEAD, source_sha256=hashes,
              started_utc=datetime.now(timezone.utc).isoformat(), source_indices=list(range(15)),
              original_full_source_frames=6946, baseline_sha256=sha(baseline), rows=[],
              scope='Selected original first loss diagnostic; no parameter, label, tracker decision or acceptance change',
              limits=['Selected after observing first loss14; not a blind cohort or full-video acceptance',
                      'All original full6946 and phone2300 outputs remain authoritative',
                      'RANSAC calls return the original matrix and mask without mutation',
                      'No new asset/dependency, annotation input or foreign process is accessed'])
logger = logging.getLogger('tracking88.first_loss')
logger.setLevel(logging.INFO)
file = logging.FileHandler(OUT / 'observation.log', encoding='utf-8')
file.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
console = logging.StreamHandler()
console.setLevel(logging.ERROR)
logger.addHandler(file)
logger.addHandler(console)
v.update(activeController=str(Path(__file__)), ownHeavyWorkloads=[dict(
    kind='selected first-loss unchanged-fit observation', head=HEAD, sourceFrozen=True, output=str(OUT))])
write(CP, state)


def start(operation):
    report['in_flight'] = dict(operation=operation, utc=datetime.now(timezone.utc).isoformat())
    write(OUT / 'receipt.json', report)
    logger.info('start operation=%s', operation)
    file.flush()


try:
    start('import_existing_cv_runtime')
    import sys
    sys.path.insert(0, str(WORK / 'tools/tracking'))
    import plate_flow as flow
    import numpy as np
    flow.cv2.setNumThreads(1)
    flow.cv2.setRNGSeed(88)
    start('decode_declared_selected_source_indices')
    ff = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
    result = subprocess.run([str(ff), '-v', 'error', '-nostdin', '-threads', '1', '-noautorotate',
                             '-copyts', '-i', str(SOURCE), '-an', '-sn', '-dn',
                             '-vf', r'select=lte(n\,14)', '-fps_mode', 'passthrough', '-threads', '1',
                             '-f', 'rawvideo', '-pix_fmt', 'gray', 'pipe:1'], capture_output=True)
    (OUT / 'decode.stderr.log').write_bytes(result.stderr)
    assert result.returncode == 0 and not result.stderr and len(result.stdout) == 15 * 640 * 480
    images = np.frombuffer(result.stdout, np.uint8).reshape(15, 480, 640)
    original_find = flow.cv2.findHomography
    calls = []

    def observed_find(*args, **kwargs):
        matrix, mask = original_find(*args, **kwargs)
        row = dict(points=len(args[0]), method=int(args[2]) if len(args) > 2 else int(kwargs.get('method', 0)),
                   returned=matrix is not None)
        if matrix is not None:
            residual = np.linalg.norm(flow.transform(matrix, args[0]) - np.asarray(args[1]).reshape(-1, 2), axis=1)
            row.update(original_mask_inliers=int(np.sum(mask)) if mask is not None else None,
                       actual_matrix_inliers_at_unchanged_1_5=int(np.sum(residual <= flow.LIMITS['planeFitPixels'])),
                       residual_minimum=float(residual.min()), residual_median=float(np.median(residual)),
                       residual_maximum=float(residual.max()))
        calls.append(row)
        return matrix, mask

    flow.cv2.findHomography = observed_find
    previous = None
    expected = [json.loads(line) for line in baseline.read_text(encoding='utf-8').splitlines()[:15]]
    for index, image in enumerate(images):
        start(f'unchanged_tracker_frame_{index}')
        gray = flow.prepare(image)
        calls = []
        if index == 0:
            tracker = flow.Tracker(dict(id='plane', kind='plane', roi=[200., 140., 340., 260.]), gray)
            observation, confidence = tracker.initial, 1.
        else:
            observation, confidence = tracker.observe(previous, gray)
        prior = next(t for t in expected[index]['tracks'] if t['id'] == 'plane')
        assert observation == prior['observation'] and confidence == prior['confidence'] and tracker.reason == prior['reason']
        report['rows'].append(dict(index=index, visible=observation is not None, reason=tracker.reason,
                                   fitting_points=int(np.sum(~tracker.holdout)),
                                   heldout_points=int(np.sum(tracker.holdout)), calls=calls))
        previous = gray.copy()
    flow.cv2.findHomography = original_find
    report.update(status='original_first_loss_observed_decisions_exactly_preserved', observation_equivalence=True)
except BaseException:
    report.update(status='failed_original_observation_retained', cause=traceback.format_exc())
    logger.error('operation=first_loss cause=%s', report['cause'][-8192:])
finally:
    report.update(in_flight=None, completed_utc=datetime.now(timezone.utc).isoformat(),
                  source_unchanged=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == HEAD
                  and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK, text=True).strip()
                  and all(sha(WORK / name) == digest for name, digest in hashes.items()),
                  input_unchanged=sha(SOURCE) == 'f7cfe7d11fb64111777b6074a21bc58de7fc500ebce15f26577ee0ba2c4f890f'
                  and sha(baseline) == report['baseline_sha256'])
    write(OUT / 'receipt.json', report)
    file.close()
    print(json.dumps({k: report.get(k) for k in ('status', 'observation_equivalence', 'cause', 'source_unchanged')}))
raise SystemExit(0 if report['status'] == 'original_first_loss_observed_decisions_exactly_preserved' and report['source_unchanged'] and report['input_unchanged'] else 1)
