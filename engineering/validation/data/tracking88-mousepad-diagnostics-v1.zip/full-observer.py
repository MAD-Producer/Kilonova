"""First full6946-frame independent core diagnostic; no prototype-cap waiver."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import logging
import os
import subprocess
import sys
import traceback
import zipfile

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/planar-tracker88'
OUT = ART / 'tracking88-mousepad-full-core-v1'
CP = ART / 'depth75-resume-current.json'
DATA = ART / 'tracking88-real-planar-acquisition-v1'
FFMPEG = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
FFPROBE = FFMPEG.with_name('ffprobe.exe')
HEAD = 'd21b9df82f5f3c7b4a35af2bfd5d4e91b7928231'
COUNT = 6946
ROI = [200., 140., 340., 260.]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.pending')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    temporary.replace(path)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK, text=True).strip()


def core(request_path, destination):
    # This diagnostic has no annotation path argument and never opens its ZIP.
    # It does not call/export the frame-bounded prototype track() entry.
    sys.path.insert(0, str(WORK / 'tools/tracking'))
    from track_plate import Run, frames, digest
    request = read(request_path)
    assert request['diagnostic_frame_count'] == COUNT
    source = DATA / 'mouse-pad.avi'
    assert digest(source) == request['source_sha256']
    run = Run(destination)
    decoder = None
    try:
        run.report['phase'] = 'import_existing_cv_runtime'
        run.log.info('start operation=mousepad_full_core phase=import_existing_cv_runtime mode=%s', request['mode'])
        run.save()
        import plate_flow as flow
        from plate_contract import TrackFailures
        import importlib.metadata
        versions = {name: importlib.metadata.version(name) for name in ('opencv-python-headless', 'numpy')}
        assert versions == {'opencv-python-headless': '5.0.0.93', 'numpy': '2.4.6'}
        flow.cv2.setNumThreads(1)
        flow.cv2.setRNGSeed(88)
        run.report.update(scope='Full original-video core diagnostic; no mstrack export, prototype/native admission or issue acceptance',
                          sourceSha256=request['source_sha256'], frameCount=COUNT, implementation=versions,
                          phase='decode_original_frames', limits=flow.LIMITS)
        run.log.info('start operation=mousepad_full_core mode=%s original_frames=%d', request['mode'], COUNT)
        run.save()
        edits = {(e['track'], e['source_index']): e for e in request['corrections']}
        counts = [TrackFailures() for _ in request['tracks']]
        previous = None
        decoder = frames(run, FFMPEG, source, 0, [640, 480], COUNT)
        with (destination / 'observations.jsonl').open('x', encoding='utf-8') as stream:
            for index, data in enumerate(decoder):
                gray = flow.prepare(flow.np.frombuffer(data, flow.np.uint8).reshape(480, 640))
                if index == 0:
                    trackers = [flow.Tracker(seed, gray) for seed in request['tracks']]
                samples = []
                for slot, (seed, tracker) in enumerate(zip(request['tracks'], trackers)):
                    edit = edits.get((seed['id'], index))
                    if edit:
                        observation, confidence = tracker.correct(gray, edit)
                        visibility = edit['visibility']
                    else:
                        observation, confidence = ((tracker.initial, 1. if tracker.initial is not None else 0.)
                                                   if index == 0 else tracker.observe(previous, gray))
                        visibility = 'visible' if observation is not None else 'lost'
                    failed, signal = counts[slot].record(visibility, edit is not None)
                    if signal is not None:
                        logger = run.log.debug if signal == 1 else run.log.error
                        logger('tracking degradation mode=%s track=%s source_index=%d occurrences=%d cause=%s',
                               request['mode'], seed['id'], index, signal, (tracker.reason or 'track remains lost')[:256])
                    samples.append(dict(id=seed['id'], kind=seed['kind'], visibility=visibility,
                                        observation=observation, confidence=confidence,
                                        manual=edit is not None, reason=tracker.reason))
                stream.write(json.dumps(dict(source_index=index, pts=index, tracks=samples), allow_nan=False) + '\n')
                previous = gray.copy()
                if index % 60 == 0:
                    stream.flush()
                    run.report['processedFrames'] = index + 1
                    run.save()
        assert index + 1 == COUNT and digest(source) == request['source_sha256']
        run.report.update(status='complete_full_original_core_observations_not_native_acceptance',
                          phase='done', processedFrames=COUNT,
                          observationsSha256=sha(destination / 'observations.jsonl'))
        run.log.info('done operation=mousepad_full_core mode=%s frames=%d', request['mode'], COUNT)
        run.save()
    except BaseException as cause:
        run.report.update(status='failed', failure=str(cause)[:2048])
        run.log.error('operation=mousepad_full_core phase=%s cause=%s', run.report['phase'], str(cause)[:2048])
        run.save()
        raise
    finally:
        if decoder is not None:
            decoder.close()
        run.close()


def main():
    state = read(CP)
    v = state['versionedCache75']
    assert v['activeController'] is None and not v['ownHeavyWorkloads']
    assert git('rev-parse', 'HEAD') == HEAD and not git('status', '--porcelain')
    assert sha(DATA / 'mouse-pad.avi') == 'f7cfe7d11fb64111777b6074a21bc58de7fc500ebce15f26577ee0ba2c4f890f'
    assert sha(DATA / 'mouse-pad-gt.zip') == '532e0091d649f26d2158261ce1b42e4775fc91bb73c3502d23ed9744b67dba7a'
    assert sha(DATA / 'permission.html') == '6e83e22f9656a5e31062eba6c16de0557fd18690c1f206058811903aa35d3313'
    tracked = git('ls-files').splitlines()
    source_hashes = {name: sha(WORK / name) for name in tracked}
    OUT.mkdir(exist_ok=False)
    (OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
    env = {k: val for k, val in os.environ.items() if not k.startswith('MOTION_')}
    env.update(TEMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'),
               TMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'),
               LOCALAPPDATA=str(OUT / 'appdata'), PYTHONDONTWRITEBYTECODE='1')
    report = dict(status='running', head=HEAD, source_sha256=source_hashes,
                  started_utc=datetime.now(timezone.utc).isoformat(), stages=[], qualified=False,
                  protocol=dict(original_frames=COUNT, original_extent=[640, 480], ticks_per_second=100,
                                original_pts='0..6945', annotation_names='img_00100.txt..img_07045.txt',
                                convention='row,column MATLAB1-based -> x,y0-based', roi=ROI,
                                modes=['no-corrections', 'periodic-manual-200'], manual_step=200,
                                maximum_corner_error_pixels=15, retry=False, truncation=False,
                                initial_roi_selection='Fixed from the already archived first-frame image before any run',
                                quality_labels='Only initial/manual coordinates prepared before both blind core outputs seal'),
                  limits=['Original complete phone2300 failure remains failed at its unchanged15px gate',
                          '6946 frames exceed the unchanged4096 prototype limit; its actual refusal remains refused',
                          'Core-only original-video diagnostic is not native import/export or full issue acceptance',
                          'No product source, gates, new assets, dependencies, model acquisition or foreign process changes'])

    def save():
        write(OUT / 'receipt.json', report)

    v.update(activeController=str(Path(__file__)), ownHeavyWorkloads=[dict(
        kind='full original6946-frame independent planar core diagnostic', head=HEAD,
        output=str(OUT), sourceFrozen=True)])
    write(CP, state)
    logger = logging.getLogger('tracking88.mousepad.controller')
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    file = logging.FileHandler(OUT / 'controller.log', encoding='utf-8')
    file.setFormatter(formatter)
    console = logging.StreamHandler(sys.stderr)
    console.setLevel(logging.ERROR)
    logger.addHandler(file)
    logger.addHandler(console)
    save()

    def command(label, args, expected_exit=0):
        stage = dict(label=label, arguments=[str(a) for a in args], started_utc=datetime.now(timezone.utc).isoformat())
        report['stages'].append(stage)
        report['in_flight'] = dict(operation=label, started_utc=stage['started_utc'])
        save()
        logger.info('start operation=%s source=%s', label, sha(DATA / 'mouse-pad.avi'))
        file.flush()
        with (OUT / (label + '.stdout.log')).open('wb') as stdout, (OUT / (label + '.stderr.log')).open('wb') as stderr:
            child = subprocess.Popen(args, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
            stage['pid'] = child.pid
            save()
            stage['exit_code'] = child.wait()
        save()
        assert stage['exit_code'] == expected_exit, stage
        assert not (OUT / (label + '.stdout.log')).read_bytes()
        report['in_flight'] = None
        save()

    try:
        report['in_flight'] = dict(operation='import_existing_cv_runtime_and_prepare_declared_manual_inputs')
        save()
        logger.info('start operation=import_existing_cv_runtime_and_prepare_declared_manual_inputs')
        file.flush()
        sys.path.insert(0, str(WORK / 'tools/tracking'))
        import plate_flow as flow
        import numpy as np
        flow.cv2.setNumThreads(1)
        # Read only the original initial and predeclared manual coordinates.
        with zipfile.ZipFile(DATA / 'mouse-pad-gt.zip') as z:
            names = sorted(i.filename for i in z.infolist() if not i.is_dir())
            assert names == [f'img_{i:05d}.txt' for i in range(100, 100 + COUNT)]

            def quad(index):
                raw = z.read(names[index])
                assert len(raw) < 1024
                a = np.array([float(x) for x in raw.decode('ascii').split()]).reshape(2, 4)
                assert np.isfinite(a).all()
                return np.column_stack((a[1] - 1., a[0] - 1.))

            initial = quad(0)
            seeds = [dict(id='feature', kind='point', position=initial[0].tolist()),
                     dict(id='plane', kind='plane', roi=ROI)]
            corrections = []
            unsupported = []
            for index in range(200, COUNT, 200):
                q = quad(index)
                x, y = q[0]
                visible = bool(0 <= x < 640 and 0 <= y < 480)
                corrections.append(dict(track='feature', source_index=index, visibility='visible' if visible else 'lost',
                                        observation=dict(kind='point', pixels=[float(x), float(y)]) if visible else None))
                matrix = flow.cv2.getPerspectiveTransform(initial.astype(np.float32), q.astype(np.float32))
                try:
                    flow.plane_matrix(matrix, ROI)
                    observation = dict(kind='plane', matrix=matrix.tolist())
                except ValueError as cause:
                    unsupported.append(dict(index=index, cause=str(cause)))
                    observation = None
                corrections.append(dict(track='plane', source_index=index,
                                        visibility='visible' if observation is not None else 'lost', observation=observation))
        report['unsupported_scheduled_manual_planes'] = unsupported
        bare = dict(version=1, source_sha256=sha(DATA / 'mouse-pad.avi'), stream_index=0,
                    tracks=seeds, corrections=[])
        write(OUT / 'prototype-request.json', bare)
        command('original-prototype', [sys.executable, '-B', str(WORK / 'tools/tracking/track_plate.py'),
                '--source', str(DATA / 'mouse-pad.avi'), '--request', str(OUT / 'prototype-request.json'),
                '--output', str(OUT / 'original-prototype'), '--ffmpeg', str(FFMPEG), '--ffprobe', str(FFPROBE)], 1)
        refusal = read(OUT / 'original-prototype/report.json')
        assert refusal['status'] == 'failed' and 'frame count exceeds 4096' in refusal['failure']
        error = (OUT / 'original-prototype.stderr.log').read_text(encoding='utf-8')
        log = (OUT / 'original-prototype/tracking.log').read_text(encoding='utf-8')
        assert refusal['failure'] in error and refusal['failure'] in log and 'ERROR' in error
        report['original_prototype_refusal'] = refusal['failure']
        # Independent full original PTS verification; no clock synthesized by a
        # truncated prototype receipt is used for the core measurement.
        report['in_flight'] = dict(operation='verify_all_original_pts')
        save()
        logger.info('start operation=verify_all_original_pts')
        file.flush()
        probed = subprocess.run([str(FFPROBE), '-v', 'error', '-select_streams', 'v:0',
                                 '-show_frames', '-show_entries', 'frame=pts,width,height',
                                 '-of', 'json', str(DATA / 'mouse-pad.avi')], capture_output=True, env=env)
        (OUT / 'original-pts.stdout.json').write_bytes(probed.stdout)
        (OUT / 'original-pts.stderr.log').write_bytes(probed.stderr)
        assert probed.returncode == 0 and not probed.stderr
        frames = json.loads(probed.stdout)['frames']
        assert len(frames) == COUNT
        assert [int(f['pts']) for f in frames] == list(range(COUNT))
        assert all([f['width'], f['height']] == [640, 480] for f in frames)
        seals = []
        for mode in report['protocol']['modes']:
            request = dict(bare, mode=mode, diagnostic_frame_count=COUNT,
                           corrections=[] if mode == 'no-corrections' else corrections)
            config = OUT / (mode + '.request.json')
            write(config, request)
            command(mode, [sys.executable, '-B', str(Path(__file__)), '--core', str(config), str(OUT / mode)])
            measured = read(OUT / mode / 'report.json')
            assert measured['processedFrames'] == COUNT and measured['status'].startswith('complete_full_original_core')
            output = OUT / mode / 'observations.jsonl'
            seals.append(dict(mode=mode, sha256=sha(output), request_sha256=sha(config)))
        report['blind_output_seals'] = seals
        report['in_flight'] = dict(operation='independent_annotation_reduction_after_blind_output_seals')
        save()
        logger.info('start operation=independent_annotation_reduction_after_blind_output_seals')
        file.flush()
        # Only now read automatic-frame annotation coordinates.
        with zipfile.ZipFile(DATA / 'mouse-pad-gt.zip') as z:
            truth = []
            for index in range(COUNT):
                a = np.array([float(x) for x in z.read(f'img_{index + 100:05d}.txt').decode('ascii').split()]).reshape(2, 4)
                truth.append(np.column_stack((a[1] - 1., a[0] - 1.)))
        results = []
        for seal in seals:
            path = OUT / seal['mode'] / 'observations.jsonl'
            assert sha(path) == seal['sha256']
            tracks = {s['id']: dict(automatic_visible=0, automatic_lost=0, manual=0, errors=[]) for s in seeds}
            lines = path.read_text(encoding='utf-8').splitlines()
            assert len(lines) == COUNT
            for index, line in enumerate(lines):
                row = json.loads(line)
                assert row['source_index'] == row['pts'] == index and len(row['tracks']) == 2
                for sample in row['tracks']:
                    summary = tracks[sample['id']]
                    if sample['manual']:
                        summary['manual'] += 1
                    elif index == 0:
                        continue
                    elif sample['visibility'] != 'visible':
                        summary['automatic_lost'] += 1
                    else:
                        summary['automatic_visible'] += 1
                        observation = sample['observation']
                        prediction = np.array(observation['pixels']) if sample['kind'] == 'point' else flow.transform(np.array(observation['matrix']), initial)
                        target = truth[index][0] if sample['kind'] == 'point' else truth[index]
                        distance = np.linalg.norm(prediction - target) if sample['kind'] == 'point' else np.linalg.norm(prediction - target, axis=1).max()
                        assert np.isfinite(distance)
                        summary['errors'].append(float(distance))
            for name, summary in tracks.items():
                errors = summary.pop('errors')
                summary.update(track=name, max_pixels=max(errors) if errors else None,
                               rms_pixels=float(np.sqrt(np.mean(np.square(errors)))) if errors else None,
                               over15_pixels=sum(e > 15 for e in errors), missing_not_zero=True)
                assert summary['automatic_visible'] + summary['automatic_lost'] + summary['manual'] + 1 == COUNT
            results.append(dict(mode=seal['mode'], tracks=tracks))
        report.update(status='full_original_core_diagnostic_measured_prototype_refused_not_issue_acceptance', results=results)
    except BaseException:
        report.update(status='failed_original_outputs_retained', cause=traceback.format_exc())
        logger.error('operation=mousepad_full_core_controller cause=%s', report['cause'][-8192:])
    finally:
        report.update(completed_utc=datetime.now(timezone.utc).isoformat(),
                      source_unchanged=git('rev-parse', 'HEAD') == HEAD and not git('status', '--porcelain') and
                      all(sha(WORK / name) == digest for name, digest in source_hashes.items()),
                      source_input_unchanged=sha(DATA / 'mouse-pad.avi') == 'f7cfe7d11fb64111777b6074a21bc58de7fc500ebce15f26577ee0ba2c4f890f',
                      annotation_input_unchanged=sha(DATA / 'mouse-pad-gt.zip') == '532e0091d649f26d2158261ce1b42e4775fc91bb73c3502d23ed9744b67dba7a')
        report['in_flight'] = None
        save()
        logger.removeHandler(file)
        logger.removeHandler(console)
        file.close()
        console.close()
        print(json.dumps({k: report.get(k) for k in ('status', 'results', 'cause', 'source_unchanged')}))
    return 0 if (report['status'].startswith('full_original_core_diagnostic_measured') and report['source_unchanged']
                 and report['source_input_unchanged'] and report['annotation_input_unchanged']) else 1


if __name__ == '__main__':
    if len(sys.argv) == 4 and sys.argv[1] == '--core':
        core(Path(sys.argv[2]), Path(sys.argv[3]))
    else:
        raise SystemExit(main())
