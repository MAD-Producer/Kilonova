"""Archive aggregate evidence; original/derived benchmark payloads remain local."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ART = Path('E:/Dev/aem/artifacts/pr-queue')
WORK = Path('E:/Dev/aem/.worktrees/planar-tracker88')
FULL = ART / 'tracking88-mousepad-full-core-v1'
DETAIL = ART / 'tracking88-mousepad-first-loss-v1'
OUT = ART / 'tracking88-mousepad-public-v1'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


full = read(FULL / 'receipt.json')
detail = read(DETAIL / 'receipt.json')
assert full['status'] == 'full_original_core_diagnostic_measured_prototype_refused_not_issue_acceptance'
assert full['source_unchanged'] and full['source_input_unchanged'] and full['annotation_input_unchanged']
assert detail['status'] == 'original_first_loss_observed_decisions_exactly_preserved'
assert detail['observation_equivalence'] and detail['source_unchanged'] and detail['input_unchanged']
consumed = read(FULL / 'session-consumed.json')
selected_consumed = read(DETAIL / 'session-consumed.json')
assert consumed['session'] == 3421 and consumed['original_tool_result_consumed'] and consumed['exit_code'] == 0
assert selected_consumed['session'] == 31840 and selected_consumed['original_tool_result_consumed'] and selected_consumed['exit_code'] == 0
for name, expected in consumed['retained_logs'].items():
    path = FULL / name
    assert path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256']
row = detail['rows'][-1]
assert row['index'] == 14 and not row['visible'] and row['reason'] == 'plane fit has too few inliers'
fit = row['calls'][-1]
assert fit['points'] == 146 and fit['original_mask_inliers'] == fit['actual_matrix_inliers_at_unchanged_1_5'] == 96
assert row['heldout_points'] == 46 and 96 / 146 < .7
OUT.mkdir(exist_ok=False)
for origin, name in [(FULL / 'controller.py', 'full-observer.py'),
                     (DETAIL / 'controller.py', 'selected-observer.py'),
                     (Path(__file__), 'collector.py'),
                     (FULL / 'session-consumed.json', 'full-session-consumed.json'),
                     (DETAIL / 'session-consumed.json', 'selected-session-consumed.json')]:
    shutil.copyfile(origin, OUT / name)
for name in ('original-prototype.stdout.log', 'original-prototype.stderr.log',
             'no-corrections.stdout.log', 'no-corrections.stderr.log',
             'periodic-manual-200.stdout.log', 'periodic-manual-200.stderr.log', 'controller.log'):
    shutil.copyfile(FULL / name, OUT / name)
for mode in ('original-prototype', 'no-corrections', 'periodic-manual-200'):
    shutil.copyfile(FULL / mode / 'tracking.log', OUT / (mode + '.tracking.log'))
shutil.copyfile(DETAIL / 'observation.log', OUT / 'selected.observation.log')
shutil.copyfile(DETAIL / 'decode.stderr.log', OUT / 'selected.decode.stderr.log')
for name in ('plate_flow.py', 'plate_contract.py', 'track_plate.py'):
    path = WORK / 'tools/tracking' / name
    assert sha(path) == full['source_sha256']['tools/tracking/' + name]
    shutil.copyfile(path, OUT / name)
aggregate = dict(status='independent_full_sequence_and_first_loss_diagnostics_retained_not_accepted',
                 head=full['head'], original_frames=6946, original_extent=[640, 480],
                 media_sha256='f7cfe7d11fb64111777b6074a21bc58de7fc500ebce15f26577ee0ba2c4f890f',
                 annotations_sha256='532e0091d649f26d2158261ce1b42e4775fc91bb73c3502d23ed9744b67dba7a',
                 protocol=full['protocol'], results=full['results'],
                 unsupported_scheduled_manual_planes=full['unsupported_scheduled_manual_planes'],
                 original_cli=dict(exit_code=1, cause=full['original_prototype_refusal'],
                                   default_file_and_error_stderr_verified=True, stdout_empty=True),
                 first_loss=dict(selected_indices_count=15, decisions_exactly_equal=True, index=14,
                                 reason=row['reason'], fitting_points=146, heldout_points=46,
                                 original_inliers=96, independently_recomputed_inliers=96,
                                 unchanged_threshold_pixels=1.5, actual_ratio=96 / 146,
                                 unchanged_minimum_ratio=.7,
                                 implication='Rejects a stale-mask explanation for this selected first loss; not a geometric root cause'),
                 full_tool=dict(session=3421, exit_code=0, original_chunk_id='3b302c'),
                 selected_tool=dict(session=31840, exit_code=0, original_chunk_id='c7db5e'),
                 qualified=False,
                 limits=['Complete original phone2300 failures and15px gate remain unchanged',
                         'Core diagnostic does not bypass or change native/prototype admission',
                         'Missing observations are retained, not counted as zero error',
                         'Selected first15 is post-failure diagnostic, not independent blind acceptance',
                         'No media, annotations, derived captures, requests, per-frame outputs or source-page copy redistributed'])
(OUT / 'aggregate.json').write_text(json.dumps(aggregate, indent=2) + '\n', encoding='utf-8')
members = {p.name: dict(bytes=p.stat().st_size, sha256=sha(p)) for p in OUT.iterdir() if p.is_file()}
archive = OUT / 'tracking88-mousepad-diagnostics-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
    for name in sorted(members):
        target.write(OUT / name, name)
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(members)
    for name, expected in members.items():
        raw = target.read(name)
        assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256']
manifest = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive),
                members=members, qualified=False, readback='Every member CRC, byte length and SHA-256 verified')
(OUT / 'tracking88-mousepad-diagnostics-v1.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: manifest[k] for k in ('archive', 'bytes', 'sha256')}))
