from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

root=Path('E:/Dev/aem');work=root/'.worktrees/native-camera-dof'
out=root/'artifacts/pr-queue/scene87-full-workspace-v1';out.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=work).decode().strip()
assert not git('status','--porcelain')
assert git('merge-base','HEAD','origin/main')==git('rev-parse','origin/main')
prior=json.loads((root/'artifacts/pr-queue/native-camera-dof-regression-v2/accepted.json').read_text(encoding='utf-8'))
def sources():
    paths=git('ls-files','-z').split('\0')
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths
            if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml')) or p=='Cargo.lock')}
source=sources()
assert all(source[p]==sha for p,sha in prior['source'].items())
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='1',
           MOTION_DEPTH_ACCEPTANCE_DIR=str(out/'native-renders'),
           MOTION_FROZEN_DEPTH_ARTIFACTS=str(out/'native-outputs'),
           MOTION_KEY_TIMING_MOVIE_ARTIFACTS=str(out/'manual-key-timing'),
           MOTION_IMAGE_SOURCE=str(root/'.tools/gltf-scene87-normative-extra/Models/AlphaBlendModeTest/glTF/AlphaBlendLabels.png'))
features=','.join(['motion-render/gpu-tests','motion-graph/gpu-tests','motion-host/diagnostics',
                   'motion-host/ai-depth','motion-host/gpu-tests','motion-ui/gpu-tests',
                   'motion-desktop/gpu-tests','motion-desktop/ffmpeg',
                   'motion-desktop-media/gpu-tests','motion-desktop-media/ai-depth'])
common=['--locked','--offline','--features',features]
history='editor::history_accounting_tests::history_accounting_large_document_measurement'
key='movie::keyframe_timing_tests::frozen_keyframe_timing_matches_reopened_pixels_and_differs_from_linear_and_removed_layer'
steps=[('workspace',['cargo','test','--workspace','--exclude','motion-android',*common,'--','--test-threads=1']),
       ('manual-history',['cargo','test','-p','motion-core','--lib',*common,'--','--ignored','--exact',history,'--test-threads=1']),
       ('manual-key-timing',['cargo','test','-p','motion-desktop-media','--lib',*common,'--','--ignored','--exact',key,'--test-threads=1']),
       ('manual-image',['cargo','test','-p','motion-render','--test','image_resources',*common,'--','--ignored','--exact','optional_local_original_image_probe','--test-threads=1']),
       ('desktop-check',['cargo','check','-p','motion-desktop',*common]),
       ('style',['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
       ('provenance',['python','tools/validate_provenance.py'])]
report=dict(head=git('rev-parse','HEAD'),main=git('rev-parse','origin/main'),source=source,steps=[],
            androidExcluded=True,scope='Complete maintained workspace with GPU/FFmpeg/AI-depth; standard manual hardware/performance UI fixtures are enumerated rather than silently counted as passed')
shutil.copyfile(__file__,out/'controller.py')
(out/'started.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
for name,command in steps:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as so,(out/(name+'.stderr.log')).open('wb') as se:
        code=subprocess.run(command,cwd=work,env=env,stdout=so,stderr=se).returncode
    stdout=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
    row=dict(name=name,command=command,exitCode=code,sourceUnchanged=sources()==source,
             counts=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',stdout),
             ignoredTests=re.findall(r'^test (\S+) \.\.\. ignored(?:, (.*))?$',stdout,re.M))
    report['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    assert code==0 and row['sourceUnchanged'],row
    if name in ['workspace','manual-history','manual-key-timing','manual-image']:
        assert row['counts'] and all(int(f)==0 for _,f,_ in row['counts']),row
        assert sum(int(p) for p,_,_ in row['counts'])>(1000 if name=='workspace' else 0),row
        if name!='workspace':assert sum(int(p) for p,_,_ in row['counts'])==1 and all(int(i)==0 for _,_,i in row['counts']),row
report.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=sources()==source,
              passed=sum(int(p) for step in report['steps'] for p,_,_ in step['counts']),
              failed=0,manualFixturesExplicitlyExecuted=[history,key,'optional_local_original_image_probe'],
              remainingManualFixtures=[item for step in report['steps'] if step['name']=='workspace' for item in step['ignoredTests']
                                       if item[0] not in [history,key,'optional_local_original_image_probe']],
              crossPlatformAcceptance='Separate exact-head PR required checks; this receipt is the local native desktop workspace')
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,passed=report['passed'],remainingManual=len(report['remainingManualFixtures']))),flush=True)
