"""Retain the successful full workspace; correct only manual-command selection."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

root = Path('E:/Dev/aem')
work = root / '.worktrees/native-camera-dof'
previous = root / 'artifacts/pr-queue/scene87-full-workspace-v1'
out = root / 'artifacts/pr-queue/scene87-full-workspace-continuation-v2'
out.mkdir(exist_ok=False)
prior = json.loads((previous/'exit.json').read_text(encoding='utf-8'))
workspace = prior['steps'][0]
assert workspace['name'] == 'workspace' and workspace['exitCode'] == 0 and workspace['sourceUnchanged']
assert all(int(failed) == 0 for _, failed, _ in workspace['counts'])
assert prior['steps'][1]['name'] == 'manual-history' and prior['steps'][1]['exitCode'] == 101
assert 'does not contain these features' in (previous/'manual-history.stderr.log').read_text(encoding='utf-8')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=work, text=True).strip()

def unchanged():
    return all(hashlib.sha256((work/path).read_bytes()).hexdigest() == digest
               for path, digest in prior['source'].items())

assert not git('status', '--porcelain') and unchanged()
assert git('rev-parse', 'HEAD') == prior['head']
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0',
    CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    MOTION_KEY_TIMING_MOVIE_ARTIFACTS=str(out/'manual-key-timing'),
    MOTION_IMAGE_SOURCE=str(root/'.tools/gltf-scene87-normative-extra/Models/AlphaBlendModeTest/glTF/AlphaBlendLabels.png'))
history = 'editor::history_accounting_tests::history_accounting_large_document_measurement'
key = 'movie::keyframe_timing_tests::frozen_keyframe_timing_matches_reopened_pixels_and_differs_from_linear_and_removed_layer'
image = 'optional_local_original_image_probe'
common = ['--locked', '--offline']
steps = [
    ('manual-history', ['cargo','test','-p','motion-core','--lib',*common,'--','--ignored','--exact',history,'--test-threads=1']),
    ('manual-key-timing', ['cargo','test','-p','motion-desktop-media','--lib',*common,'--features','ffmpeg,ai-depth,gpu-tests','--','--ignored','--exact',key,'--test-threads=1']),
    ('manual-image', ['cargo','test','-p','motion-render','--test','image_resources',*common,'--features','gpu-tests','--','--ignored','--exact',image,'--test-threads=1']),
    ('desktop-check', ['cargo','check','-p','motion-desktop',*common,'--features','ffmpeg,gpu-tests,motion-host/ai-depth,motion-host/diagnostics']),
    ('style', ['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
    ('provenance', ['python','tools/validate_provenance.py']),
]
report = dict(head=prior['head'], main=git('rev-parse','origin/main'), source=prior['source'],
    inheritedWorkspace=str(previous/'exit.json'), inheritedWorkspaceLog=str(previous/'workspace.stdout.log'),
    steps=[workspace], androidExcluded=True,
    previousSetupFailure='Preserved original manual-history exit101: unselected workspace features; no manual test executed; full workspace remains successful')
shutil.copyfile(__file__, out/'controller.py')
(out/'started.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(controllerPid=os.getpid(), inheritedWorkspacePassed=sum(int(p) for p,_,_ in workspace['counts']))),flush=True)
for name, command in steps:
    assert unchanged()
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as so, (out/(name+'.stderr.log')).open('wb') as se:
        code = subprocess.run(command,cwd=work,env=env,stdout=so,stderr=se).returncode
    text = (out/(name+'.stdout.log')).read_text(encoding='utf-8')
    row = dict(name=name,command=command,exitCode=code,sourceUnchanged=unchanged(),
        counts=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',text))
    report['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    assert code == 0 and row['sourceUnchanged'], row
    if name.startswith('manual-'):
        assert row['counts'] and sum(int(p) for p,_,_ in row['counts']) == 1
        assert all(int(f) == 0 and int(i) == 0 for _,f,i in row['counts'])
report.update(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=unchanged(),
    passed=sum(int(p) for step in report['steps'] for p,_,_ in step['counts']), failed=0,
    manualFixturesExplicitlyExecuted=[history,key,image],
    remainingManualFixtures=[item for item in workspace['ignoredTests'] if item[0] not in [history,key,image]],
    crossPlatformAcceptance='Separate published-head checks; complete local native workspace plus explicitly run manual controls')
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,passed=report['passed'])),flush=True)
