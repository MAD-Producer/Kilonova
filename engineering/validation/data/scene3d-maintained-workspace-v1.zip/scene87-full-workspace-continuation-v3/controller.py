"""Finish only the outstanding controls; retain both actual earlier failures."""
from pathlib import Path
from datetime import datetime, timezone
from PIL import Image, ImageDraw
import hashlib, json, os, re, shutil, subprocess

root = Path('E:/Dev/aem')
work = root / '.worktrees/native-camera-dof'
previous = root / 'artifacts/pr-queue/scene87-full-workspace-continuation-v2'
out = root / 'artifacts/pr-queue/scene87-full-workspace-continuation-v3'
out.mkdir(exist_ok=False)
prior = json.loads((previous/'exit.json').read_text(encoding='utf-8'))
assert [s['name'] for s in prior['steps']] == ['workspace','manual-history','manual-key-timing','manual-image']
assert all(s['exitCode'] == 0 and s['sourceUnchanged'] for s in prior['steps'][:3])
assert prior['steps'][3]['exitCode'] == 101
assert 'assertion failed: warm.cached' in (previous/'manual-image.stdout.log').read_text(encoding='utf-8')
# The initial 1024-square source has no resampling, hence deliberately no proxy.
# Exercise the unchanged manual proxy assertion with a genuinely larger source.
fixture = root / '.tools/scene87-manual-image'
fixture.mkdir(exist_ok=True)
path = fixture/'generated-original-3072x2048.png'
image = Image.new('RGBA', (3072,2048))
draw = ImageDraw.Draw(image)
for y in range(0,2048,32):
    for x in range(0,3072,32):
        draw.rectangle((x,y,x+31,y+31), fill=((x//32*17)%256,(y//32*29)%256,((x+y)//32*11)%256,255))
image.save(path)
manifest = dict(author='Motion Studio validation: independently authored procedural fixture',
    source='This controller, integer checker pattern; no third-party input',width=3072,height=2048,
    sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    scope='External generated PNG for the unchanged cold/warm proxy probe; not photographic or user-source quality acceptance')
(fixture/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')

def git(*args):
    return subprocess.check_output(['git',*args],cwd=work,text=True).strip()

def unchanged():
    return all(hashlib.sha256((work/p).read_bytes()).hexdigest() == digest for p,digest in prior['source'].items())

assert not git('status','--porcelain') and unchanged()
env = os.environ.copy(); env.pop('MOTION_LOG',None)
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',
    CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',MOTION_IMAGE_SOURCE=str(path))
history = 'editor::history_accounting_tests::history_accounting_large_document_measurement'
key = 'movie::keyframe_timing_tests::frozen_keyframe_timing_matches_reopened_pixels_and_differs_from_linear_and_removed_layer'
probe = 'optional_local_original_image_probe'
steps = [
    ('manual-image',['cargo','test','-p','motion-render','--test','image_resources','--locked','--offline','--features','gpu-tests','--','--ignored','--exact',probe,'--test-threads=1']),
    ('desktop-check',['cargo','check','-p','motion-desktop','--locked','--offline','--features','ffmpeg,gpu-tests,motion-host/ai-depth,motion-host/diagnostics']),
    ('style',['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
    ('provenance',['python','tools/validate_provenance.py']),
]
report = dict(head=prior['head'],main=git('rev-parse','origin/main'),source=prior['source'],
    steps=prior['steps'][:3],inheritedWorkspace=prior['inheritedWorkspace'],inheritedSuccessfulManuals=str(previous/'exit.json'),
    androidExcluded=True,unchangedTestAssertions=True,externalFixture=manifest,
    retainedFailures=['scene87-full-workspace-v1: manual command had unselected features',
        'scene87-full-workspace-continuation-v2: selected 1024x1024 source needs no proxy; warm.cached is correctly false'])
shutil.copyfile(__file__,out/'controller.py')
(out/'started.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(controllerPid=os.getpid(),retainedWorkspacePassed=3779)),flush=True)
for name, command in steps:
    assert unchanged()
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as so,(out/(name+'.stderr.log')).open('wb') as se:
        code = subprocess.run(command,cwd=work,env=env,stdout=so,stderr=se).returncode
    output = (out/(name+'.stdout.log')).read_text(encoding='utf-8')
    row = dict(name=name,command=command,exitCode=code,sourceUnchanged=unchanged(),
        counts=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',output))
    report['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    assert code == 0 and row['sourceUnchanged'],row
    if name == 'manual-image': assert row['counts'] == [('1','0','0')]
report.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=unchanged(),
    passed=sum(int(p) for step in report['steps'] for p,_,_ in step['counts']),failed=0,
    manualFixturesExplicitlyExecuted=[history,key,probe],
    remainingManualFixtures=[item for item in report['steps'][0]['ignoredTests'] if item[0] not in [history,key,probe]],
    crossPlatformAcceptance='Separate exact-head published checks; this is complete local native workspace with documented existing manual exclusions')
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,passed=report['passed'])),flush=True)
