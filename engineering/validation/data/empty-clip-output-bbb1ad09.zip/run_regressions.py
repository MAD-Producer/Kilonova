from pathlib import Path
import hashlib,json,os,subprocess,time
out=Path(__file__).resolve().parent;work=Path('E:/Dev/aem/.worktrees/empty-clip-output')
assert not (out/'regressions-receipt.json').exists()
current=Path('E:/Dev/aem/.tools/cache-current-main-integration')
assert json.loads((current/'matrix.json').read_text(encoding='utf-8'))['status']=='passed'
assert json.loads((current/'failure-test-receipt.json').read_text(encoding='utf-8'))['exit_code']==0
source=work/'desktop/ui/src/paint.rs';frozen=hashlib.sha256(source.read_bytes()).hexdigest()
assert frozen==json.loads((out/'after-receipt.json').read_text(encoding='utf-8'))['source_sha256']
command=['cargo','test','-p','motion-ui','--locked','--offline','-j1','--','--test-threads=1']
env=os.environ.copy();env['CARGO_TERM_COLOR']='never';env.pop('MOTION_LOG',None)
start=time.monotonic();log=out/'regressions.log'
with log.open('w',encoding='utf-8') as stream:result=subprocess.run(command,cwd=work,stdout=stream,stderr=subprocess.STDOUT,env=env)
record=dict(command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),source_sha256=frozen,source_unchanged=hashlib.sha256(source.read_bytes()).hexdigest()==frozen,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(out/'regressions-receipt.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
assert result.returncode==0 and record['source_unchanged'];print(json.dumps(record),flush=True)
