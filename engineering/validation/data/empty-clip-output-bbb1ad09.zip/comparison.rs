use motion_ui::{paint::{PaintList,PaintOp,Shape},Color,Rect};
use std::{alloc::{GlobalAlloc,Layout,System},cell::Cell};
thread_local! {static COUNT:Cell<Option<(usize,usize)>>=const{Cell::new(None)};}
struct Allocator;
fn note(bytes:usize){let _=COUNT.try_with(|c|if let Some((n,b))=c.get(){c.set(Some((n.saturating_add(1),b.saturating_add(bytes))));});}
unsafe impl GlobalAlloc for Allocator{
    unsafe fn alloc(&self,l:Layout)->*mut u8{let p=unsafe{System.alloc(l)};if !p.is_null(){note(l.size());}p}
    unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8{let p=unsafe{System.alloc_zeroed(l)};if !p.is_null(){note(l.size());}p}
    unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8{let p=unsafe{System.realloc(p,l,n)};if !p.is_null(){note(n);}p}
    unsafe fn dealloc(&self,p:*mut u8,l:Layout){unsafe{System.dealloc(p,l)}}
}
#[global_allocator] static ALLOCATOR:Allocator=Allocator;
struct Case{name:String,quad:bool,points:Vec<[f32;2]>,area:Rect,mixed:bool}
fn main(){
    let out=std::path::PathBuf::from(std::env::args_os().nth(1).expect("output"));
    let mut cases=Vec::new();
    for (name,p) in [
        ("left",[[-2.,2.],[4.,2.],[4.,6.],[-2.,6.]]),
        ("corner",[[-2.,-2.],[4.,-2.],[4.,4.],[-2.,4.]]),
        ("outside",[[-5.,2.],[-1.,2.],[-1.,6.],[-5.,6.]]),
        ("rotated",[[5.,-2.],[12.,5.],[5.,12.],[-2.,5.]]),
        ("contained",[[2.,2.],[6.,2.],[6.,6.],[2.,6.]]),
        ("max_edge",[[2.,2.],[10.,2.],[10.,6.],[2.,6.]])
    ]{
        for quad in [true,false]{cases.push(Case{name:format!("{}_{name}",if quad{"quad"}else{"triangles"}),quad,points:if quad{p.to_vec()}else{vec![p[0],p[1],p[2],p[0],p[2],p[3]]},area:Rect::new(0.,0.,10.,10.),mixed:false});}
    }
    for (name,points,area,mixed) in [
        ("empty_input",vec![],Rect::new(0.,0.,10.,10.),false),
        ("incomplete_inside",vec![[2.,2.]],Rect::new(0.,0.,10.,10.),false),
        ("incomplete_tail",vec![[-2.,2.],[4.,2.],[4.,6.],[99.,99.]],Rect::new(0.,0.,10.,10.),false),
        ("zero_width",vec![[2.,2.],[4.,2.],[4.,6.]],Rect::new(0.,0.,0.,10.),false),
        ("zero_height",vec![[2.,2.],[4.,2.],[4.,6.]],Rect::new(0.,0.,10.,0.),false),
        ("nonfinite",vec![[f32::NAN,2.],[-2.,4.],[4.,f32::INFINITY]],Rect::new(0.,0.,10.,10.),false),
        ("mixed_kept_removed",vec![[-5.,2.],[-1.,2.],[-1.,6.]],Rect::new(0.,0.,10.,10.),true)
    ]{cases.push(Case{name:name.into(),quad:false,points,area,mixed});}
    let mut results=Vec::new();
    for case in cases{
        let mut list=PaintList::default();
        for i in 0..64{
            let points=if case.mixed && i%2==1{vec![[2.,2.],[4.,2.],[4.,6.]]}else{case.points.clone()};
            let shape=if case.quad{Shape::Quad{points:[points[0],points[1],points[2],points[3]]}}else{Shape::Triangles{points}};
            list.push_shape(shape,Color([0.2+i as f32*0.003,0.4,0.6,1.]));
        }
        COUNT.with(|c|c.set(Some((0,0))));
        std::hint::black_box(&mut list).clip_to(case.area);
        let (allocations,requested_bytes)=COUNT.with(|c|c.replace(None).unwrap());
        let shapes:Vec<_>=list.shapes.iter().map(|s|match s{
            Shape::Quad{points}=>serde_json::json!({"quad_bits":points.map(|p|p.map(f32::to_bits))}),
            Shape::Triangles{points}=>serde_json::json!({"triangle_bits":points.iter().map(|p|p.map(f32::to_bits)).collect::<Vec<_>>(),"capacity":points.capacity()}),
            _=>panic!("unexpected shape")
        }).collect();
        let order:Vec<_>=list.order.iter().map(|op|match op{PaintOp::Shape(i)=>*i,_=>panic!("unexpected glyph")}).collect();
        assert_eq!(list.colors.len(),list.shapes.len());assert_eq!(order,(0..list.shapes.len()).collect::<Vec<_>>());
        results.push(serde_json::json!({"case":case.name,"input_shapes":64,"allocations":allocations,"requested_bytes":requested_bytes,"shapes":shapes,"order":order,"color_bits":list.colors.iter().map(|c|c.0.map(f32::to_bits)).collect::<Vec<_>>(),"outer_capacities":[list.shapes.capacity(),list.colors.capacity(),list.glyphs.capacity(),list.order.capacity()]}));
    }
    std::fs::write(out,serde_json::to_vec_pretty(&results).unwrap()).unwrap();
}
