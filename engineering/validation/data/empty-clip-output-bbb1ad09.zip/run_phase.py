from pathlib import Path
import hashlib,json,os,subprocess,sys,time
out=Path(__file__).resolve().parent;work=Path('E:/Dev/aem/.worktrees/empty-clip-output');phase=sys.argv[1]
assert phase in ['before','after'];receipt=out/(phase+'-receipt.json');assert not receipt.exists()
source=work/'desktop/ui/src/paint.rs';frozen=hashlib.sha256(source.read_bytes()).hexdigest()
example=work/'desktop/ui/examples/empty_clip_comparison.rs'
if not example.exists():example.write_bytes((out/'comparison.rs').read_bytes())
assert example.read_bytes()==(out/'comparison.rs').read_bytes()
if phase=='before':
    assert not (out/'before-paint.rs').exists();(out/'before-paint.rs').write_bytes(source.read_bytes())
command=['cargo','run','-p','motion-ui','--example','empty_clip_comparison','--no-default-features','--locked','--offline','-j1','--',str(out/(phase+'.json'))]
env=os.environ.copy();env['CARGO_TERM_COLOR']='never';start=time.monotonic();log=out/(phase+'.log')
with log.open('w',encoding='utf-8') as stream:result=subprocess.run(command,cwd=work,stdout=stream,stderr=subprocess.STDOUT,env=env)
record=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),source_sha256=frozen,source_unchanged=hashlib.sha256(source.read_bytes()).hexdigest()==frozen,probe_sha256=hashlib.sha256(example.read_bytes()).hexdigest(),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
receipt.write_text(json.dumps(record,indent=2),encoding='utf-8');assert result.returncode==0 and record['source_unchanged'];print(json.dumps(record),flush=True)
