from pathlib import Path
import copy,json,sys
out=Path(__file__).resolve().parent;work=Path('E:/Dev/aem/.worktrees/minimum-workspace-preview')
sys.path.insert(0,str(work/'tools'));from ci_desktop import verify_expanded_workspace_previews
original=json.loads((out/'native-ui/minimum-en-workspace/report.json').read_text(encoding='utf-8'))
verify_expanded_workspace_previews(original,'en')
def expanded(snapshot):return next(r for r in snapshot['workspacePresentationProbe']['presentations'] if r.get('expandedPreview') is not None)
changes=[
    ('restore',lambda r:r['expandedPreview'].__setitem__('layoutRestored',False)),
    ('history',lambda r:r['expandedPreview'].__setitem__('projectAndHistoryUntouched',False)),
    ('normal',lambda r:r.__setitem__('normalNodeOverlay',True)),
    ('overlay',lambda r:r.__setitem__('nodeOverlay',False)),
    ('gpu_counter',lambda r:r['expandedPreview'].__setitem__('encodedFramesAfter',r['expandedPreview']['encodedFramesBefore'])),
    ('missing_image',lambda r:r['expandedPreview'].__setitem__('screenshot',str(out/'missing-native-control.png'))),
    ('invalid_viewport',lambda r:r['expandedPreview'].__setitem__('viewport',[-1,0,232,232])),
    ('one_pixel_viewport',lambda r:r['expandedPreview'].__setitem__('viewport',[0,0,1,1])),
]
results=[]
for name,change in changes:
    fixture=copy.deepcopy(original);change(expanded(fixture))
    try:verify_expanded_workspace_previews(fixture,'en')
    except (RuntimeError,FileNotFoundError) as error:results.append(dict(name=name,rejected=True,cause=type(error).__name__))
    else:raise AssertionError('Invalid native evidence accepted: '+name)
(out/'negative-controls.json').write_text(json.dumps(dict(real_native_report_accepted=True,mutated_evidence_controls=results,all_eight_rejected=True),indent=2),encoding='utf-8')
print('Actual native report accepted; eight mutated evidence controls rejected')
