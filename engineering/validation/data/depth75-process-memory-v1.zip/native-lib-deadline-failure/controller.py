"""One source-frozen validation; preserve original outputs and never retry."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys, traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/depth-wgsl-cache75'
BASE = ROOT / 'artifacts/pr-queue'
TARGET = ROOT / 'target/depth-wgsl-cache75-contract'
OUT = BASE / 'depth75-process-memory-v2'
assert not OUT.exists()
assert shutil.disk_usage(ROOT).free >= 10 << 30
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert head.startswith('b65a016f')
checkpoint_path = BASE / 'depth75-resume-current.json'
checkpoint = json.loads(checkpoint_path.read_text(encoding='utf-8'))
assert not checkpoint['versionedCache75']['ownHeavyWorkloads']
assert checkpoint['versionedCache75']['activeController'] is None
OUT.mkdir()
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
paths = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def hashes(): return {name: sha(WORK / name) for name in paths}
def now(): return datetime.now(timezone.utc).isoformat()
env = {k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(TARGET),
    CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(ROOT / '.tools/skill-validation-python'),
    TEMP=str(TARGET / 'tmp'), TMP=str(TARGET / 'tmp'), LOCALAPPDATA=str(OUT / 'appdata'),
    RUST_BACKTRACE='full')
env['PATH'] = str(ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin') + ';' + env['PATH']
report = dict(status='running', head=head, started_utc=now(), source_sha256=hashes(), stages=[],
    limits=['One own native/model workload, source frozen until original handle terminal and consumed',
        'Existing assertions, ignores, budgets and timeouts unchanged; original failed outputs retained',
        'Self inference-child OS peaks only; parent/resolver/WGSL/device memory and thermal acceptance remain unknown',
        'Two repeated frozen RGB inputs test actual metadata propagation, not independent sensor quality or video acceptance',
        'No Android, panel edits, new dependencies/assets/downloads, cleanup, retries or foreign processes'])
def save():
    pending = OUT / 'receipt.pending.json'
    pending.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    os.replace(pending, OUT / 'receipt.json')
def run(name, command):
    assert shutil.disk_usage(ROOT).free >= 10 << 30
    row = dict(name=name, command=[str(x) for x in command], started_utc=now())
    report['stages'].append(row)
    save()
    with (OUT / (name + '.stdout.log')).open('wb') as stdout, (OUT / (name + '.stderr.log')).open('wb') as stderr:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        row['pid'] = child.pid
        save()
        row['exit_code'] = child.wait()
    row['finished_utc'] = now()
    save()
    assert row['exit_code'] == 0, (name, 'original failure retained; no retry')
    return row
checkpoint['versionedCache75'].update(activeController=str(Path(__file__)),
    ownHeavyWorkloads=[dict(kind='serial tools/native/actual inference validation', output=str(OUT), head=head)],
    localUnpublishedHead=head)
checkpoint['updatedUtc'] = now()
checkpoint_path.write_text(json.dumps(checkpoint, indent=2) + '\n', encoding='utf-8')
save()
try:
    previous = json.loads((BASE / 'depth75-process-memory-v1/receipt.json').read_text())
    assert previous['source_unchanged'] and previous['head'] == head
    assert previous['stages'][-1]['exit_code'] == 101
    assert 'does not contain these features' in (BASE / 'depth75-process-memory-v1/host-lib.stderr.log').read_text()
    report['previous_tools'] = previous['stages'][:3]
    report['corrected_invocation'] = 'Remove unrelated desktop-media features from host-only test selection; no test had started in v1'
    features = 'motion-host/ai-depth,motion-host/gpu-tests,motion-render/gpu-tests'
    host = ['cargo', 'test', '--locked', '--offline', '-p', 'motion-host', '--features', features]
    run('host-lib', host + ['--lib', '--', '--test-threads=1'])
    run('host-capability-session', host + ['--test', 'depth_capability', '--test', 'depth_session', '--no-fail-fast', '--', '--test-threads=1'])
    summaries = []
    for name in ('host-lib', 'host-capability-session'):
        text = (OUT / (name + '.stdout.log')).read_text(encoding='utf-8')
        summaries += re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', text, re.M)
    assert len(summaries) == 3
    report['native_totals'] = dict(targets=3, passed=sum(int(s[1]) for s in summaries),
        failed=sum(int(s[2]) for s in summaries), original_ignored=sum(int(s[3]) for s in summaries),
        filtered=sum(int(s[5]) for s in summaries))
    assert not report['native_totals']['failed'] and not report['native_totals']['filtered']
    run('actual-product-build', ['cargo', 'build', '--locked', '--offline', '-p', 'motion-host', '-p', 'motion-desktop', '-p', 'motion-desktop-media',
        '--example', 'depth_reference', '--example', 'depth_capability', '--example', 'depth_video_capability', '--bin', 'motion-depth-wgsl',
        '--features', 'motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth'])
    driver = TARGET / 'debug/examples/depth_capability.exe'
    model = BASE / 'depth75-resolution-models-v1/266/export/depth_anything_v2_vits_266.onnx'
    rgb = BASE / 'depth75-reference-inputs-v1/00.rgb'
    inputs = json.loads((rgb.parent / 'inputs.json').read_text())
    manifest = json.loads(model.with_name('model.json').read_text())
    assert sha(model) == manifest['sha256'] and sha(rgb) == inputs[0]['rgb_input']['sha256']
    report['actual_inputs'] = dict(driver_sha256=sha(driver), model_sha256=sha(model), rgb_sha256=sha(rgb),
        worker_source_sha256=sha(WORK / 'tools/ai_depth_onnx.py'))
    run('actual-onnx266', [driver, OUT / 'onnx266', 'onnx', ROOT / '.tools/ai-depth74/venv/Scripts/python.exe', model,
        '-', '-', rgb, '640x480', '2', '60000'])
    measured = json.loads((OUT / 'onnx266/measurements.json').read_text())
    assert json.loads((OUT / 'actual-onnx266.stdout.log').read_text()) == measured
    assert len(measured['samples']) == 2 and measured['cache_hits'] == measured['restored'] == 0
    pids = set()
    for sample in measured['samples']:
        memory = sample['inference_process_memory']
        assert memory['status'] == 'observed' and memory['method'] == 'windows_process_memory_counters'
        assert memory['pid'] > 0 and memory['pid'] != os.getpid()
        assert memory['peak_resident_bytes'] > 0 and memory['peak_private_commit_bytes'] > 0
        assert sample['execution']['backend'] == 'onnx' and sample['execution']['provider'] == 'CPUExecutionProvider'
        assert sample['output_values'] == 640 * 480 and sample['worker_total_ns'] >= sample['resolve_ns'] > 0
        pids.add(memory['pid'])
    assert len(pids) == 2
    log = (OUT / 'onnx266/logs/motion-studio.log').read_text(encoding='utf-8')
    assert 'start' in log and 'INFO' in log
    report['actual_observations'] = [s['inference_process_memory'] for s in measured['samples']]
    report['status'] = 'tools_relevant_native_actual_build_and_owned_inference_peaks_passed'
except BaseException:
    report['status'] = 'failed_original_outputs_retained'
    report['cause'] = traceback.format_exc()
    save()
    raise
finally:
    report['source_unchanged'] = hashes() == report['source_sha256']
    report['finished_utc'] = now()
    save()
    assert report['source_unchanged'], 'frozen source changed during validation'
