"""Archive exact-head CI test evidence; never turn partial CI into full acceptance."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/reference-depth76'
DATA = WORK / 'engineering/validation/data'
TARGET = DATA / 'depth75-ci-tests-v1.zip'
MANIFEST = DATA / 'depth75-ci-tests-v1.json'
sha = lambda data: hashlib.sha256(data).hexdigest()
paths = []
for directory in ['depth75-resolution-ci-linux-v1', 'depth75-resolution-ci-windows-mac-v2',
                  'depth75-start-ci-linux-v1', 'depth75-start-ci-linux-v2']:
    folder = ROOT / 'artifacts/pr-queue' / directory
    for path in sorted(folder.iterdir()):
        if path.is_file() and path.suffix in ('.json', '.py', '.log'):
            paths.append(path)
for directory in ['depth75-resolution-ci-windows-mac-v1']:
    folder = ROOT / 'artifacts/pr-queue' / directory
    paths.extend(folder / name for name in ['receipt.json', 'session-consumed.json'])
assert not TARGET.exists() and not MANIFEST.exists()
for directory, expected in [
    ('depth75-resolution-ci-linux-v1', 'completed_linux_ci_new_tests_verified'),
    ('depth75-resolution-ci-windows-mac-v2', 'selected_named_tests_verified_in_completed_exact_head_jobs'),
    ('depth75-start-ci-linux-v2', 'two_blocking_tests_verified_in_desktop_linux_only')]:
    receipt = json.loads((ROOT / 'artifacts/pr-queue' / directory / 'receipt.json').read_text(encoding='utf-8'))
    if directory == 'depth75-resolution-ci-linux-v1':
        assert receipt['sourceCommit'] == '4968ac214003dab3281502a7d1ba8d5c87ee45e1' and len(receipt['tests']) == 11
        assert receipt['status'] != 'running' and receipt.get('completedUtc')
    else:
        assert receipt['status'] == expected
report = dict(schema=1, observedUtc=datetime.now(timezone.utc).isoformat(),
    scope='Source-bound explicit-profile tests and controlled blocked-start observations; not complete integrated regression',
    sourceCommits=['4968ac214003dab3281502a7d1ba8d5c87ee45e1', '2a08e053d1569306a9dd091db40e7eb1f264b2ca'],
    limits=['Profile test bodies passed on Linux, Windows and macOS Intel; Python profile tests passed in Linux Rust/GPU job',
            'Two new blocked-start identity assertions are inspected in desktop Linux only; Rust/GPU excludes motion-host',
            'Two evidence-collector invocation/scope failures are retained; neither was a product test failure',
            'Rebased integrated source still requires its own complete regression and CI',
            'Actual production file-sink experiment is prepared but has not executed',
            'No models, third-party media, annotations, derived frames, tensors, executables or runtime libraries included'],
    members={})
payloads = {}
for path in paths:
    data = path.read_bytes()
    assert len(data) <= 32 << 20
    payloads[path.relative_to(ROOT).as_posix()] = data
for qualified, names in {
    '2a08e053d1569306a9dd091db40e7eb1f264b2ca': ['crates/motion-host/src/depth.rs',
        'crates/motion-host/tests/depth_jobs.rs', 'crates/motion-host/tests/depth_video.rs'],
    '4968ac214003dab3281502a7d1ba8d5c87ee45e1': ['crates/motion-host/src/depth/onnx.rs', 'tools/test_ci_depth_export.py'],
}.items():
    for name in names:
        payloads[f'source/{qualified}/{name}'] = subprocess.check_output(['git', 'show', qualified + ':' + name], cwd=WORK)
payloads['archive-controller.py'] = Path(__file__).read_bytes()
for name, data in payloads.items():
    report['members'][name] = dict(bytes=len(data), sha256=sha(data))
payloads['manifest.json'] = (json.dumps(report, indent=2) + '\n').encode('utf-8')
with zipfile.ZipFile(TARGET, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted(payloads.items()):
        bundle.writestr(name, data)
with zipfile.ZipFile(TARGET) as bundle:
    assert set(bundle.namelist()) == set(payloads)
    assert all(bundle.read(name) == data for name, data in payloads.items())
summary = {key: value for key, value in report.items() if key != 'members'}
summary.update(archive=TARGET.name, bytes=TARGET.stat().st_size, sha256=sha(TARGET.read_bytes()), members=len(payloads),
               readbackVerified=True)
MANIFEST.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
