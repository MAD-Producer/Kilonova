"""Retain completed exact-head CI logs and verify the new tests actually ran."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

ROOT = Path('E:/Dev/aem')
OUT = ROOT / 'artifacts/pr-queue/depth75-resolution-ci-linux-v1'
REPO = 'repos/MAD-Producer/Kilonova'
RUN = 42221745680
HEAD = '4968ac214003dab3281502a7d1ba8d5c87ee45e1'
MAX_LOG = 32 << 20

def api(path):
    return json.loads(subprocess.check_output(['gh', 'api', REPO + path], text=True, encoding='utf-8'))

run = api(f'/actions/runs/{RUN}')
assert run['head_sha'] == HEAD and run['event'] == 'pull_request'
jobs = [(127905632649, 'desktop-linux'), (127905632799, 'rust-gpu-linux')]
metadata = {name: api(f'/actions/jobs/{number}') for number, name in jobs}
assert all(job['run_id'] == RUN and job['status'] == 'completed' and job['conclusion'] == 'success'
           for job in metadata.values())
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='running', observedUtc=datetime.now(timezone.utc).isoformat(), run=RUN, sourceCommit=HEAD,
              jobs={}, tests={}, limits=['Two completed Linux jobs only; Windows/macOS and complete integrated local features remain separate gates',
                                        'Actual named new tests are inspected in retained raw logs, not inferred from green counts',
                                        'CI does not install external model weights or prove quality/thermal switching'])

def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

save()
try:
    for number, name in jobs:
        (OUT / (name + '.job.json')).write_text(json.dumps(metadata[name], indent=2) + '\n', encoding='utf-8')
        destination = OUT / (name + '.log')
        stderr = OUT / (name + '.download.stderr.log')
        count = 0
        with destination.open('xb') as output, stderr.open('xb') as errors:
            child = subprocess.Popen(['gh', 'api', REPO + f'/actions/jobs/{number}/logs'], stdout=subprocess.PIPE, stderr=errors)
            try:
                while block := child.stdout.read(64 << 10):
                    count += len(block)
                    assert count <= MAX_LOG, 'Download bound exceeded; partial output retained'
                    output.write(block)
            except BaseException:
                child.terminate()
                child.wait()
                raise
            finally:
                child.stdout.close()
            code = child.wait()
        assert code == 0 and count > 0, (name, code)
        report['jobs'][name] = dict(job=number, url=metadata[name]['html_url'], downloadExit=code,
                                  bytes=count, sha256=hashlib.sha256(destination.read_bytes()).hexdigest())
        save()
    lines = (OUT / 'desktop-linux.log').read_text(encoding='utf-8').splitlines()
    for name in ['processing_resolution_is_explicit_and_not_a_provider_choice',
                 'report_requires_the_exact_requested_profile_and_tensor_byte_counts']:
        matching = [line for line in lines if name in line and ' ... ok' in line]
        assert len(matching) == 1, name
        report['tests'][name] = matching[0]
    lines = (OUT / 'rust-gpu-linux.log').read_text(encoding='utf-8').splitlines()
    names = ['letterbox_geometry_preserves_crop_orientation_and_odd_padding',
             'host_worker_and_exporter_agree_on_all_processing_profiles',
             'preprocessing_rejects_unsupported_shape_before_array_or_cv_calls',
             'real_worker_rejects_unknown_processing_before_loading_a_model',
             'resolution_is_part_of_processing_identity',
             'invalid_profile_is_refused_before_filesystem_or_model_imports',
             'existing_destination_is_never_overwritten',
             'command_line_requires_explicit_supported_side_without_coercion',
             'optimized_real_cli_refuses_invalid_side_before_output_creation']
    for name in names:
        matching = [line for line in lines if 'test_' + name + ' (' in line and ' ... ok' in line]
        assert len(matching) == 1, name
        report['tests']['test_' + name] = matching[0]
    assert api(f'/actions/runs/{RUN}')['head_sha'] == HEAD
    report['status'] = 'two_native_profile_and_nine_python_tests_confirmed_in_completed_linux_jobs'
except BaseException as error:
    report.update(status='observation_failed_original_outputs_retained', failure=repr(error))
finally:
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps({key: value for key, value in report.items() if key != 'tests'}))
raise SystemExit(0 if report['status'].startswith('two_native_profile_') else 1)
