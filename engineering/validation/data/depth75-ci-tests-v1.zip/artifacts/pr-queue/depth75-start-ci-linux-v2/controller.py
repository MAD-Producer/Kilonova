"""Verify retained raw logs against the jobs' actual package scopes."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('E:/Dev/aem')
OLD = ROOT / 'artifacts/pr-queue/depth75-start-ci-linux-v1'
OUT = ROOT / 'artifacts/pr-queue/depth75-start-ci-linux-v2'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
old = read(OLD / 'receipt.json')
assert old['status'] == 'failed' and old['error'] == "('rust-gpu-linux', 'info_start_identifies_each_processing_profile_before_a_blocked_backend', 0)"
assert old['sourceCommit'] == '2a08e053d1569306a9dd091db40e7eb1f264b2ca'
run = json.loads(subprocess.check_output(['gh', 'api',
    'repos/MAD-Producer/Kilonova/actions/runs/42224811554'], encoding='utf-8'))
assert run['head_sha'] == old['sourceCommit'] and run['event'] == 'pull_request'
for name, row in old['jobs'].items():
    path = OLD / (name + '.log')
    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
    metadata = read(OLD / (name + '.job.json'))
    assert metadata['id'] == row['job'] and metadata['run_id'] == old['run']
    assert metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
desktop = (OLD / 'desktop-linux.log').read_text(encoding='utf-8').splitlines()
gpu = (OLD / 'rust-gpu-linux.log').read_text(encoding='utf-8').splitlines()
desktop_command = next(line for line in desktop if '##[group]Run cargo test -p motion-desktop ' in line)
gpu_command = next(line for line in gpu if '##[group]Run cargo test --workspace ' in line)
assert '-p motion-host ' in desktop_command and 'motion-host/ai-depth' in desktop_command
assert '--exclude motion-host ' in gpu_command
tests = {}
for name in ['info_start_identifies_each_processing_profile_before_a_blocked_backend',
             'decoder_open_is_observable_before_blocking_and_seek_discards_old_request']:
    matches = [line for line in desktop if name in line and ' ... ok' in line]
    assert len(matches) == 1
    assert not any(name in line and ' ... ok' in line for line in gpu)
    tests[name] = matches[0]
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
receipt = dict(status='two_blocking_tests_verified_in_desktop_linux_only',
    observedUtc=datetime.now(timezone.utc).isoformat(), run=old['run'], sourceCommit=old['sourceCommit'],
    originalCollectionReceipt=dict(path=str(OLD / 'receipt.json'), sha256=sha(OLD / 'receipt.json'),
        status='failed; original receipt remains unchanged',
        cause='Collector incorrectly expected motion-host tests in a job explicitly excluding motion-host'),
    jobs=old['jobs'], verifiedTestLines=tests, desktopCommand=desktop_command, rustGpuCommand=gpu_command,
    limits=['Raw CI proves two controlled blocking tests on Linux, not whole-feature local regression',
            'Rust/GPU job excludes motion-host; its green status does not qualify these assertions',
            'Actual default production file-sink verification remains pending',
            'No product source, test assertion, CI command, feature, threshold or prior receipt changed'])
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status=receipt['status'], sourceCommit=receipt['sourceCommit'], tests=len(tests))))
