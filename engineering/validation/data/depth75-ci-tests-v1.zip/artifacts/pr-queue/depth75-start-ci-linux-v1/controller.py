"""Retain exact-head raw CI logs; prove blocked-handler assertions ran."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('E:/Dev/aem')
OUT = ROOT / 'artifacts/pr-queue/depth75-start-ci-linux-v1'
API = 'repos/MAD-Producer/Kilonova'
RUN = 42224811554
HEAD = '2a08e053d1569306a9dd091db40e7eb1f264b2ca'
JOBS = [('desktop-linux', 127915508846), ('rust-gpu-linux', 127915508590)]
TESTS = [
    'info_start_identifies_each_processing_profile_before_a_blocked_backend',
    'decoder_open_is_observable_before_blocking_and_seek_discards_old_request',
]


def api(path):
    return json.loads(subprocess.check_output(['gh', 'api', API + path], encoding='utf-8'))


run = api(f'/actions/runs/{RUN}')
assert run['head_sha'] == HEAD and run['event'] == 'pull_request'
metadata = {name: api(f'/actions/jobs/{number}') for name, number in JOBS}
assert all(row['run_id'] == RUN and row['status'] == 'completed' and row['conclusion'] == 'success'
           for row in metadata.values())
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='running', observedUtc=datetime.now(timezone.utc).isoformat(), sourceCommit=HEAD,
              run=RUN, jobs={}, tests={}, limits=[
                  'Two completed Linux CI jobs only; integrated local full-feature regression remains pending',
                  'Controlled blocking proves publication before handler completion; it does not prove real-model quality',
                  'These capture-based assertions do not replace the prepared actual production file-sink experiment',
                  'No test assertion, timeout, resource admission, feature or original ignore was changed'])


def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')


save()
try:
    for name, number in JOBS:
        (OUT / f'{name}.job.json').write_text(json.dumps(metadata[name], indent=2) + '\n', encoding='utf-8')
        target = OUT / f'{name}.log'
        count = 0
        with target.open('xb') as output, (OUT / f'{name}.download.stderr.log').open('xb') as errors:
            child = subprocess.Popen(['gh', 'api', API + f'/actions/jobs/{number}/logs'],
                                     stdout=subprocess.PIPE, stderr=errors)
            try:
                while block := child.stdout.read(64 << 10):
                    count += len(block)
                    assert count <= 32 << 20, 'Raw log exceeds byte budget; partial evidence retained'
                    output.write(block)
                code = child.wait()
            except BaseException:
                if child.poll() is None:
                    child.terminate()
                child.wait()
                raise
            finally:
                child.stdout.close()
        assert code == 0 and count > 0, (name, code)
        report['jobs'][name] = dict(job=number, bytes=count, downloadExit=code,
                                  sha256=hashlib.sha256(target.read_bytes()).hexdigest(), url=metadata[name]['html_url'])
        lines = target.read_text(encoding='utf-8').splitlines()
        for test in TESTS:
            matching = [line for line in lines if test in line and ' ... ok' in line]
            assert len(matching) == 1, (name, test, len(matching))
            report['tests'][name + '/' + test] = matching[0]
        save()
    assert api(f'/actions/runs/{RUN}')['head_sha'] == HEAD
    report['status'] = 'named_blocking_tests_verified_in_completed_linux_ci'
except BaseException as error:
    report.update(status='failed', error=str(error)[:2048])
    raise
finally:
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps(dict(status=report['status'], sourceCommit=HEAD, jobs=report['jobs'], namedPasses=len(report['tests']))))
