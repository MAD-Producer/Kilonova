from pathlib import Path
import hashlib,json,os,subprocess
root=Path('E:/Dev/aem');work=root/'.worktrees/gltf-scene';base=root/'artifacts/pr-queue/issue87-gpu-v2'
prior=json.loads((base/'accepted.json').read_text(encoding='utf-8'))
out=root/'artifacts/pr-queue/issue87-gpu-software-logger-v1';out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def unchanged():return all(sha((work/n).read_bytes())==h for n,h in prior['source'].items())
assert unchanged()
binary=root/'target/gltf-scene87-contract/debug/motion-scene87-gpu-probe.exe'
assert sha(binary.read_bytes())==prior['steps'][-1]['binarySha256']
env=os.environ.copy();env.pop('MOTION_LOG',None)
driver=root/'.tools/android-sdk/emulator/lib64/vulkan/lvp_icd.json'
env.update(WGPU_BACKEND='vulkan',VK_DRIVER_FILES=str(driver),MESA_SHADER_CACHE_DIR=str(root/'target/software-vulkan-cache'))
env['PATH']=str(driver.parent)+os.pathsep+env['PATH']
command=[str(binary),str(out/'output')]
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
    code=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
assert code==0 and unchanged()
assert (out/'stdout.log').read_bytes()==b''
stderr=(out/'stderr.log').read_text(encoding='utf-8');logs=(out/'output/logs/motion-studio.log').read_text(encoding='utf-8')
for number in [8800,8859,8901]:
    marker=f'scene_gpu_frame #{number} source=87'
    assert logs.count(marker)==1 and stderr.count(marker)==1
assert logs.count('scene_gpu_frame #')==3 and stderr.count('scene_gpu_frame #')==3
for marker in ['start #8701 obj_import','start #8703 scene_gpu_upload','start #8900 scene_gpu_pipeline']:
    assert marker in logs
assert 'DEBUG ' not in logs
report=json.loads((out/'output/report.json').read_text(encoding='utf-8'))
assert 'llvmpipe' in report['adapter'].lower() and 'backend: Vulkan' in report['adapter'],report['adapter']
receipt=dict(command=command,exitCode=code,sourceUnchanged=True,binarySha256=sha(binary.read_bytes()),
    source=prior['source'],adapter=report['adapter'],runtimeProof='same binary and WGPU_BACKEND/VK_DRIVER_FILES used by full software scene gate; actual CPU Vulkan adapter verified',
    stdoutSha256=sha((out/'stdout.log').read_bytes()),stderrSha256=sha((out/'stderr.log').read_bytes()))
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,adapter=report['adapter'])),flush=True)
