from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/gltf-scene';out=root/'artifacts/pr-queue';sha=lambda b:hashlib.sha256(b).hexdigest()
run=out/'issue87-gpu-v2';receipt=json.loads((run/'accepted.json').read_text(encoding='utf-8'))
assert receipt['baseHead']=='7a83a16b726754e93fff7dfabb06460a97fcb95d' and receipt['sourceUnchanged']
assert all(s['exitCode']==0 and s['sourceUnchanged'] for s in receipt['steps'])
assert [s['totals']['passed'] for s in receipt['steps'] if 'totals' in s]==[45,15,31,15]
for name,digest in receipt['source'].items():assert sha((work/name).read_bytes())==digest,name
software=out/'issue87-gpu-software-logger-v1';sr=json.loads((software/'accepted.json').read_text(encoding='utf-8'))
assert sr['sourceUnchanged'] and sr['source']==receipt['source'] and sr['binarySha256']==receipt['steps'][-1]['binarySha256']
payload={}
for label in ['issue87-gpu-v2','issue87-gpu-software-logger-v1','issue87-gpu-v1']:
    for p in (out/label).rglob('*'):
        if p.is_file():payload[label+'/'+p.relative_to(out/label).as_posix()]=p.read_bytes()
names=set()
for args in [('diff','--name-only'),('ls-files','--others','--exclude-standard')]:
    names.update(subprocess.check_output(['git',*args],cwd=work,text=True).splitlines())
for name in names:
    if name.endswith(('.rs','.wgsl','.toml')) or name=='Cargo.lock':
        data=(work/name).read_bytes();assert sha(data)==receipt['source'][name]
        payload['source/'+name]=data
for folder,names in {
    'scene87-gpu-probe':['Cargo.toml','Cargo.lock','src/main.rs'],
    'scene87-keyframe-renderer':['Cargo.toml','Cargo.lock','src/main.rs'],
    'scene87-keyframe-demo':['generate_model.py'],
    'issue-closure-review':['validate-issue87-gpu.py','validate-issue87-gpu-v2.py','validate-issue87-software-logger.py']}.items():
    for name in names:payload['tools/'+folder+'/'+name]=(root/'.tools'/folder/name).read_bytes()
for p in (out/'issue87-keyframe-demo/source').iterdir():
    if p.is_file():payload['original-model-source/'+p.name]=p.read_bytes()
for p in (out/'issue87-keyframe-demo/native-qa').iterdir():
    if p.is_file():payload['internal-headless-qa-not-desktop/'+p.name]=p.read_bytes()
payload['controller/archive.py']=Path(__file__).read_bytes()
manifest=dict(baseHead=receipt['baseHead'],
    scope='106 source-frozen test executions, native and CPU Vulkan adapters, original model internal pixel QA. No desktop model layer/keyframe/movie-export acceptance. v1 rejected for an incorrect controller log label; v2 repeats the full gate after added affine/projection guards.',
    files={n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(payload.items())})
payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=work/'engineering/validation/data/static-scene-gpu-7a83a16b.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(payload.items()):z.writestr(n,b)
with zipfile.ZipFile(dest) as z:
    assert set(z.namelist())==set(payload)
    for n,b in payload.items():assert sha(z.read(n))==sha(b)
result=dict(file=dest.name,sha256=sha(dest.read_bytes()),bytes=dest.stat().st_size,files=len(payload))
(out/'issue87-gpu-archive.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
