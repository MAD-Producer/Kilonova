"""Frozen native/software scene pixels, admission regression and real logger."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/gltf-scene';label=sys.argv[1]
assert re.fullmatch(r'v[0-9]+',label)
out=root/'artifacts/pr-queue'/('issue87-gpu-'+label);out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def source():
    names=set()
    for args in [('ls-files','-z'),('ls-files','--others','--exclude-standard','-z')]:
        names.update(n.decode() for n in subprocess.check_output(['git',*args],cwd=work).split(b'\0') if n)
    return {n:sha((work/n).read_bytes()) for n in sorted(names) if (work/n).is_file() and (n.endswith(('.rs','.wgsl','.glsl','.toml','.json')) or n=='Cargo.lock')}
inputs=source();env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-scene87-contract'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='1')
for key in ['MOTION_LOG','WGPU_BACKEND','VK_DRIVER_FILES','VK_ICD_FILENAMES']:env.pop(key,None)
receipt=dict(baseHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),source=inputs,steps=[],startedUtc=datetime.now(timezone.utc).isoformat())
probe=root/'.tools/scene87-gpu-probe';binary=root/'target/gltf-scene87-contract/debug/motion-scene87-gpu-probe.exe'
format_files=[p.relative_to(work).as_posix() for p in (work/'crates/motion-render/src/scene_gpu').glob('*.rs')]+['crates/motion-render/tests/scene_gpu.rs']
regression=['native_allocation','allocation_retirement','allocation_budget','image_capture','image_formats','layer_compositing','layer_masks']
steps=[('format',['rustfmt','--edition','2021','--check',*format_files]),
    ('clippy',['cargo','clippy','-p','motion-render','--test','scene_gpu','--offline','--locked','--message-format=json']),
    ('scene-cpu',['cargo','test','-p','motion-scene','--offline','--locked','--','--test-threads=1']),
    ('scene-native',['cargo','test','-p','motion-render','--test','scene_gpu','--offline','--locked','--','--test-threads=1']),
    ('native-regression',['cargo','test','-p','motion-render',*[a for t in regression for a in ['--test',t]],'--offline','--locked','--no-fail-fast','--','--test-threads=1']),
    ('scene-software',['cargo','test','-p','motion-render','--test','scene_gpu','--offline','--locked','--','--test-threads=1']),
    ('probe-build',['cargo','build','--manifest-path',str(probe/'Cargo.toml'),'--offline','--locked']),
    ('default-logger',[str(binary),str(out/'logger-output')])]
for name,command in steps:
    stage=out/name;stage.mkdir();childenv=env.copy()
    if name=='scene-software':
        driver=root/'.tools/android-sdk/emulator/lib64/vulkan/lvp_icd.json';assert driver.is_file()
        childenv.update(WGPU_BACKEND='vulkan',VK_DRIVER_FILES=str(driver),MESA_SHADER_CACHE_DIR=str(root/'target/software-vulkan-cache'))
        childenv['PATH']=str(driver.parent)+os.pathsep+childenv['PATH']
    item=dict(name=name,command=command);receipt['steps'].append(item)
    print(json.dumps(dict(starting=name,output=str(stage))),flush=True)
    with (stage/'stdout.log').open('wb') as stdout,(stage/'stderr.log').open('wb') as stderr:
        process=subprocess.Popen(command,cwd=work,env=childenv,stdout=stdout,stderr=stderr);item['pid']=process.pid
        (out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');code=process.wait()
    item.update(exitCode=code,sourceUnchanged=source()==inputs)
    for stream in ['stdout','stderr']:item[stream+'Sha256']=sha((stage/(stream+'.log')).read_bytes())
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    assert item['sourceUnchanged'],'source changed during acceptance'
    if code:print(json.dumps(item),flush=True);sys.exit(code)
    stdout=(stage/'stdout.log').read_text(encoding='utf-8-sig');stderr=(stage/'stderr.log').read_text(encoding='utf-8-sig')
    if name=='clippy':
        own=[]
        for line in stdout.splitlines():
            try:d=json.loads(line)
            except ValueError:continue
            if d.get('reason')!='compiler-message':continue
            m=d['message']
            if m['level'] not in ['error','warning']:continue
            if any(s['is_primary'] and ('scene_gpu' in s['file_name'] or 'native_allocation.rs' in s['file_name']) for s in m.get('spans',[])):own.append(m)
        assert not own,[(m['message'],m.get('code')) for m in own]
    if name in ['scene-cpu','scene-native','native-regression','scene-software']:
        rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout);assert rows
        item['totals']=dict(passed=sum(int(r[0]) for r in rows),failed=sum(int(r[1]) for r in rows),ignored=sum(int(r[2]) for r in rows),targets=len(rows))
        assert item['totals']['failed']==0 and item['totals']['ignored']==0
    if name=='default-logger':
        assert not stdout,'standalone probe must leave stdout empty'
        logs=(out/'logger-output/logs/motion-studio.log').read_text(encoding='utf-8')
        assert 'start #8701 obj_import' in logs
        assert 'start #8702 scene_gpu_upload source=87' in logs
        assert 'start #8900 scene_gpu_pipeline source=87' in logs
        for number in [8800,8859,8901]:
            key=f'scene_gpu_frame #{number} source=87'
            assert logs.count(key)==1 and stderr.count(key)==1,(number,logs,stderr)
        assert logs.count('scene_gpu_frame #')==3 and stderr.count('scene_gpu_frame #')==3
        assert logs.count('scene_gpu_upload #8702 source=87')==1 and stderr.count('scene_gpu_upload #8702 source=87')==1
        assert 'DEBUG ' not in logs and 'INFO ' in logs and 'ERROR ' in logs
        assert 'cause=' in logs and 'elapsed_ms=' in logs
        item['binarySha256']=sha(binary.read_bytes());item['report']=json.loads((out/'logger-output/report.json').read_text(encoding='utf-8'))
    print(json.dumps(dict(completed=name,totals=item.get('totals'))),flush=True)
receipt.update(sourceUnchanged=source()==inputs,completedUtc=datetime.now(timezone.utc).isoformat())
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,output=str(out))),flush=True)
