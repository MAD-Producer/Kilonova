//! Internal native-pixel QA before the editable desktop model-layer bridge.
//! This executable is not represented as a Motion Studio UI/export acceptance.
use glam::{Mat4, Vec3};
use motion_model::{CameraPose, Ease, Keyframe, ProjectionKind, Track};
use motion_render::{
    scene_gpu::{GpuScene, SceneFrame, SceneGpuLimits, SceneLight, SceneRequest},
    Renderer,
};
use serde::{Deserialize, Serialize};
use std::{path::PathBuf, sync::Arc};
const WIDTH: u32 = 960;
const HEIGHT: u32 = 540;
#[derive(Serialize, Deserialize)]
struct Animation {
    rotation_degrees: Track<[f32; 3]>,
    position_metres: Track<[f32; 3]>,
    scale_percent: Track<[f32; 3]>,
}
fn track(values: &[(i32, [f32; 3])]) -> Track<[f32; 3]> {
    Track {
        value: values[0].1,
        keys: values
            .iter()
            .map(|&(frame, value)| Keyframe {
                frame,
                value,
                ease: Ease::InOut,
                curve: None,
                spatial: None,
            })
            .collect(),
        axes: None,
    }
}
fn main() {
    let args: Vec<_> = std::env::args_os().collect();
    assert_eq!(args.len(), 3, "source OBJ and QA output directory");
    let source = PathBuf::from(&args[1]);
    let out = PathBuf::from(&args[2]);
    std::fs::create_dir_all(&out).unwrap();
    let anim = Animation {
        rotation_degrees: track(&[
            (0, [0., -35., 0.]),
            (45, [0., 55., 0.]),
            (135, [0., 305., 0.]),
            (179, [0., 325., 0.]),
        ]),
        position_metres: track(&[
            (0, [0., 0., 0.]),
            (45, [0., 0.12, 0.]),
            (90, [0., 0., 0.]),
            (135, [0., 0.12, 0.]),
            (179, [0., 0., 0.]),
        ]),
        scale_percent: track(&[
            (0, [85.; 3]),
            (30, [100.; 3]),
            (149, [100.; 3]),
            (179, [85.; 3]),
        ]),
    };
    let authored = serde_json::to_vec_pretty(&anim).unwrap();
    std::fs::write(out.join("authored-tracks.json"), &authored).unwrap();
    let anim: Animation =
        serde_json::from_slice(&std::fs::read(out.join("authored-tracks.json")).unwrap()).unwrap();
    let imported = motion_scene::obj::import_obj(
        motion_scene::ImportContext {
            request: 8701,
            source: 87,
        },
        &std::fs::read(&source).unwrap(),
        &mut motion_scene::DirectoryResolver::new(source.parent().unwrap()).unwrap(),
        &Default::default(),
        &Default::default(),
    )
    .unwrap();
    let renderer = pollster::block_on(Renderer::headless()).unwrap();
    let target = renderer.render_target(WIDTH, HEIGHT).unwrap();
    let context = renderer.allocation_context();
    let stride = (WIDTH * 4).div_ceil(wgpu::COPY_BYTES_PER_ROW_ALIGNMENT)
        * wgpu::COPY_BYTES_PER_ROW_ALIGNMENT;
    let buffer = context
        .buffer(&wgpu::BufferDescriptor {
            label: Some("Original model internal QA readback"),
            size: u64::from(stride) * u64::from(HEIGHT),
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        })
        .unwrap();
    let request = SceneRequest {
        request: 8703,
        source: 87,
    };
    let mut gpu = GpuScene::upload(
        &renderer,
        request,
        Arc::new(imported),
        SceneGpuLimits::default(),
    )
    .unwrap();
    let eye = Vec3::new(2.8, 1.8, 3.7);
    let target_point = Vec3::new(0., 0.95, 0.);
    let camera = CameraPose {
        eye,
        target: target_point,
        projection: ProjectionKind::Perspective,
        view_projection: Mat4::perspective_rh(
            40f32.to_radians(),
            WIDTH as f32 / HEIGHT as f32,
            0.05,
            30.,
        ) * Mat4::look_at_rh(eye, target_point, Vec3::Y),
    };
    let lights = [
        SceneLight::Directional {
            direction: [-0.45, -0.7, -1.],
            color: [1., 0.94, 0.86],
            intensity: 1.1,
        },
        SceneLight::Directional {
            direction: [0.8, -0.2, -0.4],
            color: [0.45, 0.7, 1.],
            intensity: 0.3,
        },
        SceneLight::Directional {
            direction: [-0.1, -0.2, 1.],
            color: [1., 0.65, 0.4],
            intensity: 0.65,
        },
    ];
    let mut frame = SceneFrame::new(camera, 0, 1.);
    frame.lights = &lights;
    frame.ambient = [0.65; 3];
    frame.background = [0.018, 0.025, 0.04, 1.];
    frame.samples = 4;
    let selected = [0, 45, 90, 135, 179];
    let mut samples = Vec::new();
    for index in selected {
        let rotation = anim.rotation_degrees.sample(f64::from(index)).unwrap();
        let position = anim.position_metres.sample(f64::from(index)).unwrap();
        let scale = anim.scale_percent.sample(f64::from(index)).unwrap();
        frame.world = Mat4::from_translation(Vec3::from_array(position) + Vec3::new(0., 0.95, 0.))
            * Mat4::from_rotation_y(rotation[1].to_radians())
            * Mat4::from_scale(Vec3::from_array(scale) / 100.)
            * Mat4::from_translation(Vec3::new(0., -0.95, 0.));
        gpu.draw(&renderer, request, &target, &frame).unwrap();
        let mut encoder = renderer
            .allocation_command_encoder(&Default::default())
            .unwrap();
        encoder.copy_texture_to_buffer(
            target.view.texture().as_image_copy(),
            wgpu::TexelCopyBufferInfo {
                buffer: &buffer,
                layout: wgpu::TexelCopyBufferLayout {
                    offset: 0,
                    bytes_per_row: Some(stride),
                    rows_per_image: Some(HEIGHT),
                },
            },
            wgpu::Extent3d {
                width: WIDTH,
                height: HEIGHT,
                depth_or_array_layers: 1,
            },
        );
        renderer.submit_allocated(encoder.finish(), |_| {}).unwrap();
        let (send, receive) = std::sync::mpsc::sync_channel(1);
        buffer
            .slice(..)
            .map_async(wgpu::MapMode::Read, move |result| {
                send.send(result).unwrap();
            });
        renderer
            .device
            .poll(wgpu::PollType::wait_indefinitely())
            .unwrap();
        receive.recv().unwrap().unwrap();
        let mapped = buffer.slice(..).get_mapped_range().unwrap();
        let pixels: Vec<u8> = mapped
            .chunks_exact(stride as usize)
            .flat_map(|r| r[..WIDTH as usize * 4].iter().copied())
            .collect();
        drop(mapped);
        buffer.unmap();
        image::save_buffer(
            out.join(format!("native-qa-{index:03}.png")),
            &pixels,
            WIDTH,
            HEIGHT,
            image::ColorType::Rgba8,
        )
        .unwrap();
        samples.push(serde_json::json!({"frame":index,"rotation":rotation,"position":position,"scale":scale}));
    }
    let report = serde_json::json!({"scope":"internal headless GPU pixel QA, not in-app model editing or export acceptance",
        "adapter":format!("{:?}",renderer.adapter_info),"size":[WIDTH,HEIGHT],"samples":samples,"authoredTracksReopened":true});
    std::fs::write(
        out.join("qa-receipt.json"),
        serde_json::to_vec_pretty(&report).unwrap(),
    )
    .unwrap();
}
