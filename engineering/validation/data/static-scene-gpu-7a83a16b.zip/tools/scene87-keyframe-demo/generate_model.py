"""Original geometric OBJ fixture, authored for the Motion Studio scene demo.

No downloaded model, texture, font or product artwork. Units are metres; Y is up.
This creates source material only, not an in-app or rendered acceptance claim.
"""
from pathlib import Path
import json,math
out=Path('E:/Dev/aem/artifacts/pr-queue/issue87-keyframe-demo/source');out.mkdir(parents=True,exist_ok=True)
vertices=[];faces=[];position_ids={}
def vector(a,b):return [a[i]-b[i] for i in range(3)]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def face(points,center,material,name,smooth=False):
    normal=cross(vector(points[1],points[0]),vector(points[2],points[0]))
    average=[sum(p[i] for p in points)/len(points)-center[i] for i in range(3)]
    if sum(a*b for a,b in zip(normal,average))<0:points=list(reversed(points))
    ids=[]
    for p in points:
        key=(name,tuple(round(v,9) for v in p))
        if key not in position_ids:
            vertices.append(p);position_ids[key]=len(vertices)
        ids.append(position_ids[key])
    faces.append((ids,material,name,smooth))
def box(name,center,size,bevel,material):
    half=[v/2 for v in size];points={}
    for sx in [-1,1]:
      for sy in [-1,1]:
       for sz in [-1,1]:
        sign=(sx,sy,sz)
        for axis in range(3):
            points[sign,axis]=[center[i]+sign[i]*(half[i]-(0 if i==axis else bevel)) for i in range(3)]
    # Six main faces, twelve edge chamfers and eight triangular corners.
    for axis in range(3):
      other=[i for i in range(3) if i!=axis]
      for sign in [-1,1]:
        ring=[]
        for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]:
            s=[0]*3;s[axis]=sign;s[other[0]]=a;s[other[1]]=b
            ring.append(points[tuple(s),axis])
        face(ring,center,material,name)
    for a,b in [(0,1),(0,2),(1,2)]:
      free=3-a-b
      for sa in [-1,1]:
       for sb in [-1,1]:
        ring=[]
        for f,axis in [(-1,a),(-1,b),(1,b),(1,a)]:
            sign=[0]*3;sign[a]=sa;sign[b]=sb;sign[free]=f
            ring.append(points[tuple(sign),axis])
        face(ring,center,material,name)
    for sign in [s for s,a in points if a==0]:
        face([points[sign,i] for i in range(3)],center,material,name)
def sphere(name,center,radius,material):
    n=16;m=10
    def point(i,j):
        phi=math.pi*j/m;theta=2*math.pi*i/n
        return [center[0]+radius*math.sin(phi)*math.cos(theta),center[1]+radius*math.cos(phi),center[2]+radius*math.sin(phi)*math.sin(theta)]
    # Shared original positions let the importer compute smooth sphere normals.
    for j in range(m):
      for i in range(n):
        polygon=[point(i,j),point(i+1,j),point(i+1,j+1),point(i,j+1)]
        if j==0:polygon=polygon[1:]
        elif j==m-1:polygon=polygon[:3]
        face(polygon,center,material,name,True)
box('Torso',[0,.8,0],[.72,.67,.42],.07,'Shell')
box('Belt',[0,.49,0],[.58,.11,.39],.025,'DeepBlue')
box('Head',[0,1.42,0],[.68,.48,.46],.075,'Shell')
box('Faceplate',[0,1.43,.23],[.52,.25,.07],.025,'Faceplate')
for x in [-.13,.13]:box('Eye',[x,1.45,.275],[.095,.065,.025],.012,'Cyan')
box('Neck',[0,1.135,0],[.23,.1,.25],.02,'DeepBlue')
for side in [-1,1]:
    sphere('Shoulder',[side*.455,.97,0],.12,'Orange')
    box('Arm',[side*.51,.73,0],[.19,.36,.23],.03,'Shell')
    sphere('Wrist',[side*.51,.49,0],.08,'DeepBlue')
    box('Hand',[side*.51,.38,.025],[.21,.16,.22],.025,'Orange')
    box('Leg',[side*.20,.28,0],[.22,.30,.25],.03,'Shell')
    box('Foot',[side*.20,.09,.065],[.27,.14,.39],.035,'DeepBlue')
box('Chest',[0,.85,.224],[.30,.19,.055],.02,'DeepBlue')
for x in [-.075,0,.075]:box('Indicator',[x,.85,.258],[.025,.10,.015],.004,'Cyan')
box('Antenna',[.19,1.74,0],[.035,.22,.035],.008,'DeepBlue')
sphere('AntennaTip',[.19,1.875,0],.055,'Orange')
lines=['# Original Motion Studio robot, metres, Y-up','mtllib orbit-robot.mtl']
lines+=['v '+' '.join(f'{v:.9g}' for v in p) for p in vertices]
previous=None
for indices,material,name,smooth in faces:
    state=(material,name,smooth)
    if state!=previous:lines.extend([f'g {name}',f'usemtl {material}','s 1' if smooth else 's off']);previous=state
    lines.append('f '+' '.join(map(str,indices)))
(out/'orbit-robot.obj').write_text('\n'.join(lines)+'\n',encoding='ascii')
materials={'Shell':([.62,.69,.76],[.28]*3,60,[0,0,0]),'DeepBlue':([.025,.065,.11],[.18]*3,100,[0,0,0]),
    'Faceplate':([.012,.03,.04],[.5]*3,150,[0,0,0]),'Cyan':([.01,.5,.65],[.1]*3,30,[.01,.3,.4]),'Orange':([.8,.2,.035],[.22]*3,70,[0,0,0])}
mtl=[]
for name,(kd,ks,ns,ke) in materials.items():
    mtl.extend([f'newmtl {name}','Ka .15 .15 .15','Kd '+' '.join(map(str,kd)),'Ks '+' '.join(map(str,ks)),f'Ns {ns}','Ke '+' '.join(map(str,ke)),'illum 2',''])
(out/'orbit-robot.mtl').write_text('\n'.join(mtl),encoding='ascii')
plan={'status':'source fixture only; actual editable project, app capture and export pending',
      'author':'Motion Studio repository contributors','license':'repository MIT','units':'metres','up':'Y','frames':180,'fps':30,
      'intendedPropertyKeys':{'rotationYDegrees':[[0,-35],[45,55],[135,305],[179,325]],
          'positionYMetres':[[0,0],[45,.12],[90,0],[135,.12],[179,0]],
          'scalePercent':[[0,85],[30,100],[149,100],[179,85]]},
      'requiredDeliverables':['editable in-app model layer and authored property keyframes','real native app screenshots at multiple keyframes','actual animation export video'],
      'vertices':len(vertices),'polygons':len(faces),'materials':len(materials)}
(out/'demo-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(output=str(out),vertices=len(vertices),polygons=len(faces))),flush=True)
