#[path = "../../../.worktrees/gltf-scene/desktop/app/src/logging.rs"]
mod logging;
// This standalone native probe has no desktop worker or fabricated in-flight state.
mod engine {
    pub fn current_command() -> Option<(u64, &'static str, std::time::Duration)> { None }
}
use motion_render::scene_gpu::{GpuScene,SceneFrame,SceneGpuLimits,SceneRequest};
use glam::{Mat4,Vec3};
use std::{path::PathBuf,sync::Arc};

fn main() {
    let out=PathBuf::from(std::env::args_os().nth(1).expect("output directory"));
    std::fs::create_dir_all(&out).unwrap();
    let _guard=logging::init(out.join("logs")).unwrap();
    let renderer=pollster::block_on(motion_render::Renderer::headless()).unwrap();
    let target=renderer.render_target(65,65).unwrap();
    let obj=b"mtllib paint.mtl\nusemtl Paint\nv -0.9 -0.9 0\nv 0.9 -0.9 0\nv 0 0.9 0\nf 1 2 3\n";
    let mtl=out.join("paint.mtl");
    std::fs::write(&mtl,b"newmtl Paint\nKd 0.2 0.4 0.8\nillum 0\n").unwrap();
    let scene=Arc::new(motion_scene::obj::import_obj(
        motion_scene::ImportContext{request:8701,source:87}, obj,
        &mut motion_scene::DirectoryResolver::new(&out).unwrap(),
        &Default::default(),&Default::default()).unwrap());
    let request=SceneRequest{request:8702,source:87};
    let cause=GpuScene::upload(&renderer,request,scene.clone(),SceneGpuLimits{resident_bytes:1,..Default::default()}).err().unwrap();
    assert!(matches!(cause,motion_render::scene_gpu::SceneGpuError::ResidentBudget{..}));
    let mut gpu=GpuScene::upload(&renderer,SceneRequest{request:8703,..request},scene,Default::default()).unwrap();
    let eye=Vec3::new(0.,0.,3.);
    let camera=motion_model::CameraPose{eye,target:Vec3::ZERO,projection:motion_model::ProjectionKind::Orthographic,
        view_projection:Mat4::orthographic_rh(-1.,1.,-1.,1.,0.1,10.)*Mat4::look_at_rh(eye,Vec3::ZERO,Vec3::Y)};
    let mut frame=SceneFrame::new(camera,0,1.);
    frame.lights=&[]; frame.ambient=[0.;3];
    let mut requests=Vec::new();
    frame.world=Mat4::from_scale(Vec3::ZERO);
    for index in 0..61 {
        let r=SceneRequest{request:8800+index,..request};requests.push(r.request);
        assert!(gpu.draw(&renderer,r,&target,&frame).unwrap_err().to_string().contains("singular"));
    }
    frame.world=Mat4::IDENTITY;
    gpu.draw(&renderer,SceneRequest{request:8900,..request},&target,&frame).unwrap();
    frame.world=Mat4::from_scale(Vec3::ZERO);
    assert!(gpu.draw(&renderer,SceneRequest{request:8901,..request},&target,&frame).is_err());
    frame.world=Mat4::IDENTITY;
    gpu.draw(&renderer,SceneRequest{request:8902,..request},&target,&frame).unwrap();
    renderer.device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
    logging::flush();
    let report=serde_json::json!({"adapter":format!("{:?}",renderer.adapter_info),
        "features":format!("{:?}",renderer.device.features()),"errorsInvoked":requests,
        "successResets":[8900,8902],"failureAfterReset":8901,"request":request.request,
        "source":request.source,"residentBytes":gpu.resident_bytes(),
        "ledgerKnownBytes":gpu.texture_resource_ledger().total_known_bytes()});
    std::fs::write(out.join("report.json"),serde_json::to_vec_pretty(&report).unwrap()).unwrap();
}
