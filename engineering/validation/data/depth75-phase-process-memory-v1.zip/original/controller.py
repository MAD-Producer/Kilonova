"""One source-frozen native and real-GPU observation run; no retries."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,re,shutil,subprocess,sys,traceback
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/depth-wgsl-cache75'
BASE=ROOT/'artifacts/pr-queue';TARGET=ROOT/'target/depth-wgsl-cache75-contract'
OUT=BASE/'depth75-phase-process-memory-v1'
assert not OUT.exists() and shutil.disk_usage(ROOT).free >= 10<<30
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip();assert head.startswith('54a4707d')
assert json.loads((BASE/'depth75-native-process-memory-v1/session-consumed.json').read_text())==dict(session=9625,consumed=True,exit_code=0)
checkpoint=BASE/'depth75-resume-current.json';state=json.loads(checkpoint.read_text(encoding='utf-8'))
assert state['versionedCache75']['activeController'] is None and not state['versionedCache75']['ownHeavyWorkloads']
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
paths=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def hashes():return {p:sha(WORK/p) for p in paths}
def now():return datetime.now(timezone.utc).isoformat()
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),
 CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
 TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),LOCALAPPDATA=str(OUT/'appdata'),RUST_BACKTRACE='full',PYTHONDONTWRITEBYTECODE='1')
env['PATH']=str(ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')+';'+env['PATH']
report=dict(status='running',head=head,started_utc=now(),source_sha256=hashes(),stages=[],
 limits=['One owned heavy native/model/GPU workload; original handle must terminate and be consumed before source edits',
 'No assertions, ignores, budgets or timeouts changed; earlier275/1 host-library result remains failed',
 'Actual self-process lifetime peaks only, not whole-process-tree or physical device memory',
 'Two repeated frozen frames per actual route establish metadata propagation, not domain/transition/thermal qualification',
 'No Android, panels, downloads, retries, cleanup or foreign process inspection/stops'])
def save():
 p=OUT/'receipt.pending.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(p,OUT/'receipt.json')
def run(name,args,allowed=(0,)):
 assert shutil.disk_usage(ROOT).free>=10<<30
 row=dict(name=name,command=[str(a) for a in args],started_utc=now());report['stages'].append(row);save()
 with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
  child=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();row['exit_code']=child.wait()
 row['finished_utc']=now();save();assert row['exit_code'] in allowed,(name,'original failure retained; no retry')
 return row
state['versionedCache75'].update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(output=str(OUT),head=head)],localUnpublishedHead=head)
state['updatedUtc']=now();checkpoint.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8');save()
try:
 run('provenance',[sys.executable,'-B','tools/validate_provenance.py'])
 run('inventory',[sys.executable,'-B','tools/validation_inventory.py'])
 env['PYTHONPATH']=str(ROOT/'.tools/skill-validation-python')
 run('complete-tools',[sys.executable,'-B','-m','unittest','discover','-s','tools','-p','test_ci_*.py','-v'])
 tools=(OUT/'complete-tools.stderr.log').read_text(encoding='utf-8')
 matches=re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$',tools,re.M);assert len(matches)==1
 report['tools_discovered']=int(matches[0][0]);save()
 native=run('complete-host-lib-capability-session',['cargo','test','--locked','--offline','-p','motion-host',
  '--features','motion-host/ai-depth,motion-host/gpu-tests,motion-render/gpu-tests','--lib','--test','depth_capability','--test','depth_session',
  '--no-fail-fast','--','--test-threads=1'],allowed=(0,101))
 stdout=(OUT/'complete-host-lib-capability-session.stdout.log').read_text(encoding='utf-8')
 assert 'test process_memory::tests::actual_owned_child_retains_touched_allocation_high_water_marks ... ok' in stdout
 summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
 assert len(summaries)==3,'Compilation/target failure is not a completed test run'
 report['native_totals']=dict(targets=3,passed=sum(int(s[1]) for s in summaries),failed=sum(int(s[2]) for s in summaries),original_ignored=sum(int(s[3]) for s in summaries),filtered=sum(int(s[5]) for s in summaries))
 assert not report['native_totals']['filtered'];save()
 run('host-without-ai-feature',['cargo','check','--locked','--offline','-p','motion-host','--no-default-features','--lib'])
 run('actual-product-build',['cargo','build','--locked','--offline','-p','motion-host','-p','motion-desktop','-p','motion-desktop-media',
  '--example','depth_reference','--example','depth_capability','--example','depth_video_capability','--bin','motion-depth-wgsl',
  '--features','motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth'])
 driver=TARGET/'debug/examples/depth_capability.exe';worker=TARGET/'debug/motion-depth-wgsl.exe'
 rgb=BASE/'depth75-reference-inputs-v1/00.rgb';inputs=json.loads((rgb.parent/'inputs.json').read_text())
 assert sha(rgb)==inputs[0]['rgb_input']['sha256']
 report['binary_sha256']=dict(driver=sha(driver),worker=sha(worker));report['actual_observations']={};save()
 for kind,side in [('onnx',266),('wgsl',518)]:
  model=BASE/f'depth75-resolution-models-v1/{side}/export/depth_anything_v2_vits_{side}.onnx'
  assert sha(model)==json.loads(model.with_name('model.json').read_text())['sha256']
  label=f'{kind}{side}'
  run('actual-'+label,[driver,OUT/label,kind,ROOT/'.tools/ai-depth74/venv/Scripts/python.exe',model,
   BASE/'depth75-wgsl-cache-resources-v2/program.json',worker,rgb,'640x480','2','60000'])
  measured=json.loads((OUT/label/'measurements.json').read_text())
  assert json.loads((OUT/('actual-'+label+'.stdout.log')).read_text())==measured
  assert len(measured['samples'])==2 and measured['cache_hits']==measured['restored']==0
  rows=[s['inference_process_memory'] for s in measured['samples']]
  assert len({r['pid'] for r in rows})==2
  for r in rows:assert r['status']=='observed' and r['method']=='windows_process_memory_counters' and r['peak_resident_bytes']>0 and r['peak_private_commit_bytes']>0
  for s in measured['samples']:
   assert s['execution']['backend']==kind and s['output_values']==640*480
   assert s['worker_total_ns']>=s['resolve_ns']>0
   if kind=='wgsl':assert s['retained_gpu_buffer_capacity_bytes']==227968156
  for sample in measured['samples']:
   snapshot=sample['process_memory'];host=snapshot['host'];children=snapshot['children']
   assert children['backend']==kind and host['status']=='observed'
   assert host['pid']==report['stages'][-1]['pid']
   names=['resolution','inference'] if kind=='onnx' else ['resolution_transform','resolution_native','prepare','inference','remap']
   assert set(children)==set(['backend']+names)
   for phase in names:
    memory=children[phase]
    assert memory['status']=='observed' and memory['pid']!=host['pid']
    assert memory['peak_resident_bytes']>0 and memory['peak_private_commit_bytes']>0
   assert sample['inference_process_memory']==children['inference']
   assert sample['observed_resident_sum_bytes']==host['peak_resident_bytes']+max(children[n]['peak_resident_bytes'] for n in names)
  report.setdefault('phase_observations',{})[label]=[dict(snapshot=s['process_memory'],observed_resident_sum_bytes=s['observed_resident_sum_bytes']) for s in measured['samples']]
  log=(OUT/label/'logs/motion-studio.log').read_text(encoding='utf-8');assert 'start' in log and 'INFO' in log
  report['actual_observations'][label]=rows;save()
 report['status']='host_and_all_direct_child_phases_controls_and_actual_cpu_gpu_observations_passed' if native['exit_code']==0 else 'host_and_child_phase_observations_passed_original_native_failures_retained'
except BaseException:
 report['status']='failed_original_outputs_retained';report['cause']=traceback.format_exc();save();raise
finally:
 report['source_unchanged']=hashes()==report['source_sha256'];report['finished_utc']=now();save();assert report['source_unchanged']
