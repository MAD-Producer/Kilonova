"""Source-bound multi-image integration gate, after the native/audio gate finishes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

root = Path('E:/Dev/aem')
work = root/'.worktrees/depth-multiple-images'
assert (root/'artifacts/pr-queue/depth-audio-main-integration-v1/accepted.json').exists()
git = lambda *args: subprocess.check_output(['git',*args],cwd=work).decode().strip()
assert not git('status','--porcelain')
main = git('rev-parse','8c271bd3')
subprocess.run(['git','merge-base','--is-ancestor',main,'HEAD'],cwd=work,check=True)
out = root/'artifacts/pr-queue/depth-multiple-images-native-v1'
out.mkdir(exist_ok=False)
paths = git('ls-files','-z').split('\0')
source = {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs','.toml','.wgsl','.json','.py')) or p == 'Cargo.lock')}
for p in source: os.utime(work/p,None)
changed = git('diff','--name-only','f787cc25','HEAD').splitlines()
for p in changed:
    if p not in source: continue
    dest = out/'source'/p
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(work/p,dest)
shutil.copyfile(__file__,out/'controller.py')
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',
           CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG',None)
targets = ['depth_jobs','depth_session','depth_video','imported_cameras','failure_boundaries',
           'render_composition_detail','resource_composition_details','image_candidate_contract','session_concurrency']
host = ['cargo','test','-p','motion-host','--lib','--features','gpu-tests,ai-depth']
for target in targets: host += ['--test',target]
host += ['--locked','--offline','--no-fail-fast','--','--test-threads=1']
steps = [
    ('provenance',['python','tools/validate_provenance.py']),
    ('style',['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
    ('host',host),
    ('host-without-depth',['cargo','check','-p','motion-host','--no-default-features','--locked','--offline']),
    ('desktop',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),
]
receipt = dict(head=git('rev-parse','HEAD'),main=main,source=source,changed=changed,
               startedUtc=datetime.now(timezone.utc).isoformat(),steps=[])
for name,cmd in steps:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as stdout, (out/(name+'.stderr.log')).open('wb') as stderr:
        code = subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
    unchanged = all(hashlib.sha256((work/p).read_bytes()).hexdigest() == h for p,h in source.items())
    row = dict(name=name,command=cmd,exitCode=code,sourceUnchanged=unchanged)
    if name == 'host':
        text = (out/(name+'.stdout.log')).read_text(encoding='utf-8')
        results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
        row.update(targets=len(results),totals=dict(zip(('passed','failed','ignored'),[sum(int(v[i]) for v in results) for i in range(3)])))
    receipt['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    assert code == 0 and unchanged,name
    if name == 'host':
        assert len(results) == len(targets)+1 and row['totals']['failed'] == row['totals']['ignored'] == 0
        assert 'test multiple_sources::two_image_depth_results_render_together_and_pending_replacement_seek_and_cancel_cannot_reuse_stale_sources ... ok' in text
        assert len(re.findall(r'test session::depth::retained::tests::.* \.\.\. ok',text)) == 3
receipt['completedUtc'] = datetime.now(timezone.utc).isoformat()
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True)),flush=True)
