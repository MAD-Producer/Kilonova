#[cfg(test)]
mod sampling_tests;
#[cfg(test)]
mod invariant_tests;
#[cfg(test)]
mod preparation_tests;
mod runtime;
mod references;
mod transpile;
pub use transpile::{expression_source_diagnostic, ExpressionSourceDiagnostic};
pub use references::expression_reference_source;

use crate::{ensure, Axis, Error, ExpressionTarget, ExpressionValue, Project, Property, PropertyExpression, Result, Track};
use motion_model::expressions::{active, raw};
use serde_json::json;
use std::{
    borrow::Cow,
    sync::{atomic::AtomicBool, Arc},
    time::{Duration, Instant},
};

fn error(target: &ExpressionTarget, frame: f64, error: Error) -> Error {
    Error::Expression {
        target: serde_json::to_string(target).unwrap_or_default(),
        frame,
        source: Box::new(error),
    }
}
fn prepare(
    project: &Project,
    e: &PropertyExpression,
    frame: f64,
) -> Result<references::Invocation> {
    let track = raw(project, &e.target)?;
    let selected = project.layers.iter().enumerate().find(|(_, l)| l.id == e.target.object());
    let layer = selected.map(|(_, layer)| layer);
    let offset = layer.map_or(0, |l| l.clip(project.frames).offset_frame);
    let fps = f64::from(project.fps);
    let percent = matches!(
        e.target,
        ExpressionTarget::Property {
            property: Property::Opacity,
            ..
        }
    );
    let js_value = move |v: Vec<f32>| {
        let v: Vec<f32> = v
            .into_iter()
            .map(|v| if percent { v * 100.0 } else { v })
            .collect();
        if v.len() == 1 {
            json!(v[0])
        } else {
            json!(v)
        }
    };
    let local = frame - f64::from(offset);
    let keys:Vec<_>=track.frames().iter().map(|&f| -> Result<_> { Ok(json!({"time":(f64::from(f)+f64::from(offset))/fps,"value":js_value(track.sample(f64::from(f))?)})) }).collect::<Result<_>>()?;
    let index = selected.map_or(0, |(index, _)| project.layers.len() - index);
    let clip = layer.map(|l| l.clip(project.frames));
    let seed = e.seed
        ^ (e.target.object() as u32).wrapping_mul(0x9e3779b9)
        ^ serde_json::to_string(&e.target)?
            .bytes()
            .fold(2166136261u32, |s, b| {
                (s ^ u32::from(b)).wrapping_mul(16777619)
            });
    let data=json!({"time":frame/fps,"value":js_value(track.sample(local)?),"index":index,"keys":keys,"seed":seed,
        "comp":{"width":project.width,"height":project.height,"frameRate":fps,"frameRateRatio":project.fps,"frameDuration":1.0/fps,"duration":project.frames as f64/fps},
        "layer":{"name":layer.map_or("Camera",|l|l.name.as_str()),"index":index,"inPoint":clip.map_or(0.0,|c|c.in_frame as f64/fps),"outPoint":clip.map_or(project.frames as f64/fps,|c|c.out_frame as f64/fps),"startTime":offset as f64/fps}}).to_string();
    Ok(references::Invocation { data, track, fps, offset: f64::from(offset), percent })
}
fn evaluate(
    project: &Project, e: &PropertyExpression, frame: f64,
    deadline: Instant, cancel: Arc<AtomicBool>,
) -> Result<Vec<f32>> {
    runtime::evaluate_linked(std::rc::Rc::new(references::Session::new(project.clone())), e, frame, deadline, cancel)
}

/// Keep a native sampling failure even if JavaScript catches the callback exception.
#[cfg(test)]
fn evaluate_source(
    e: &PropertyExpression,
    frame: f64,
    data: &str,
    sample: impl Fn(f64) -> Result<String> + 'static,
    deadline: Instant,
    cancel: Arc<AtomicBool>,
) -> Result<Vec<f32>> {
    let sampling_failure = std::rc::Rc::new(std::cell::RefCell::new(None));
    let captured_failure = sampling_failure.clone();
    let result = runtime::evaluate(
        &e.source,
        &data,
        move |time| match sample(time) {
            Ok(value) => Ok(value),
            Err(cause) => {
                // Retain the native first failure across the JavaScript callback boundary.
                let mut first = captured_failure.borrow_mut();
                if first.is_none() { *first = Some(cause); }
                Err(Error::Invalid("valueAtTime track sampling failed".into()))
            }
        },
        deadline,
        cancel,
    );
    if let Some(source) = sampling_failure.borrow_mut().take() {
        return Err(Error::ExpressionSampling {
            target: serde_json::to_string(&e.target)?.chars().take(512).collect(), frame, source: Box::new(source),
        });
    }
    result.map_err(|err| error(&e.target, frame, err))
}
fn scalar(t: &mut Track<f32>, v: &[f32]) -> Result<()> {
        ensure(v.len() == 1, "expression must return a scalar")?;
        *t = Track::constant(v[0]);
        Ok(())
    }
fn vec(t: &mut Track<[f32; 3]>, axis: Option<Axis>, f: f64, v: &[f32]) -> Result<()> {
        let mut base = t.sample(f)?;
        if let Some(a) = axis {
            ensure(v.len() == 1, "axis expression must return a scalar")?;
            base[a.index()] = v[0];
        } else {
            ensure(
                v.len() == 3,
                "vector expression must return three components",
            )?;
            base.copy_from_slice(v);
        }
        *t = Track::constant(base);
        Ok(())
    }
fn write_camera(c: &mut crate::Camera, property: Property, axis: Option<Axis>, frame: f64, result: &[f32], frames: Option<u32>) -> Result<()> {
    match property {
        Property::Position => vec(&mut c.position, axis, frame, result)?,
        Property::Target => vec(&mut c.target, axis, frame, result)?,
        Property::Roll => scalar(&mut c.roll, result)?,
        Property::Fov => scalar(&mut c.fov, result)?,
        Property::Radius => scalar(&mut c.radius, result)?,
        Property::Azimuth => scalar(&mut c.azimuth, result)?,
        Property::Elevation => scalar(&mut c.elevation, result)?,
        _ => return Err(Error::Invalid("unsupported camera expression property".into())),
    }
    if let Some(frames) = frames { c.validate(frames) } else { c.validate_local() }
}
fn write_transform(t: &mut crate::Transform, property: Property, axis: Option<Axis>, frame: f64, result: &[f32]) -> Result<()> {
    match property {
        Property::Position => vec(&mut t.position, axis, frame, result)?,
        Property::Rotation => vec(&mut t.rotation, axis, frame, result)?,
        Property::Scale => vec(&mut t.scale, axis, frame, result)?,
        Property::Opacity => {
            ensure(result.len() == 1, "opacity expression must return a scalar")?;
            scalar(&mut t.opacity, &[(result[0] / 100.).clamp(0., 1.)])?;
        }
        _ => return Err(Error::Invalid("unsupported layer expression property".into())),
    }
    t.validate_local()
}
fn write_parameter(p: &mut crate::EffectParam, result: &[f32]) -> Result<()> {
    ensure(result.len() == p.kind.dimensions(), "effect expression has incorrect dimensions")?;
    ensure(result.iter().all(|v| *v >= p.min && *v <= p.max), "effect expression exceeds parameter range")?;
    let mut value = [0.; 4];
    value[..result.len()].copy_from_slice(result);
    p.track = Track::constant(value);
    Ok(())
}
fn write(
    project: &mut Project, target: &ExpressionTarget, frame: f64, result: &[f32],
) -> Result<()> {
    match target {
        ExpressionTarget::Property {
            object,
            property,
            axis,
        } => {
            if *object == 0 || project.layers.iter().any(|l| l.id == *object && l.camera_data().is_some()) {
                let local = project.layers.iter().find(|l| l.id == *object).map_or(frame, |l| l.local_frame(frame));
                let frames = project.frames;
                let c = if *object == 0 { &mut project.camera } else {
                    match &mut project.layer_mut(*object)?.content {
                        crate::Content::Camera { camera } => camera,
                        _ => return Err(Error::Invalid("object is not a camera".into())),
                    }
                };
                write_camera(c, *property, *axis, local, result, (*object == 0).then_some(frames))?;
            } else {
                let l = project.layer_mut(*object)?;
                let f = l.local_frame(frame);
                let t = &mut l.transform;
                write_transform(t, *property, *axis, f, result)?;
            }
        }
        ExpressionTarget::Effect {
            object,
            effect,
            param,
        } => {
            let p = project
                .layer_mut(*object)?
                .effects
                .iter_mut()
                .find(|e| e.id == *effect)
                .and_then(|e| e.params.get_mut(param))
                .ok_or_else(|| {
                    Error::Invalid("expression effect parameter does not exist".into())
                })?;
            write_parameter(p, result)?;
        }
    }
    Ok(())
}
pub trait ProjectExpressions {
    fn evaluated_at(&self, frame: f64) -> Result<Cow<'_, Project>>;
    fn evaluated_at_cancellable(&self, frame: f64, cancel: Arc<AtomicBool>) -> Result<Cow<'_, Project>>;
    fn expression_values(&self, frame: f64) -> Result<Vec<ExpressionValue>>;
}
/// Compile enabled sources on the owning thread before starting a frame's
/// clock. Compilation does not execute user code; the existing frame and
/// execution deadlines still apply to every later invocation.
pub fn prepare_expression_sources(project: &Project) -> Result<()> {
    prepare_expression_sources_at(project, 0., None)
}
fn prepare_expression_sources_at(
    project: &Project,
    frame: f64,
    cancel: Option<&AtomicBool>,
) -> Result<()> {
    for expression in project.expressions.iter().filter(|e| active(project, e)) {
        if cancel.is_some_and(|flag| flag.load(std::sync::atomic::Ordering::Relaxed)) {
            return Err(error(&expression.target, frame,
                Error::Invalid("expression cancelled or frame budget exceeded".into())));
        }
        runtime::compile(&expression.source)
            .map_err(|cause| error(&expression.target, frame, cause))?;
    }
    Ok(())
}
impl ProjectExpressions for Project {
    /// Expression-free frames keep the existing allocation-free animation path.
    fn evaluated_at(&self, frame: f64) -> Result<Cow<'_, Project>> {
        if !self.expressions.iter().any(|e| active(self, e)) {
            return Ok(Cow::Borrowed(self));
        }
        self.evaluated_at_cancellable(frame, Arc::new(AtomicBool::new(false)))
    }
    fn evaluated_at_cancellable(
        &self,
        frame: f64,
        cancel: Arc<AtomicBool>,
    ) -> Result<Cow<'_, Project>> {
        if !self.expressions.iter().any(|e| active(self, e)) {
            return Ok(Cow::Borrowed(self));
        }
        ensure(
            frame.is_finite() && frame >= 0.0 && frame < self.frames as f64,
            "invalid expression frame",
        )?;
        // Direct Project callers need the same cold-source admission as native
        // sessions: trusted compilation must finish before the frame clock.
        // User execution retains the existing 20 ms and 100 ms deadlines.
        prepare_expression_sources_at(self, frame, Some(cancel.as_ref()))?;
        let deadline = Instant::now() + Duration::from_millis(100);
        let session = std::rc::Rc::new(references::Session::new(self.clone()));
        let mut evaluated = self.clone();
        for e in &self.expressions {
            if active(self, e) {
                let result = runtime::evaluate_linked(session.clone(), e, frame, deadline, cancel.clone())?;
                write(&mut evaluated, &e.target, frame, &result)
                    .map_err(|err| error(&e.target, frame, err))?;
            }
        }
        Ok(Cow::Owned(evaluated))
    }
    fn expression_values(&self, frame: f64) -> Result<Vec<ExpressionValue>> {
        let evaluated = self.evaluated_at(frame)?;
        self.expressions
            .iter()
            .filter(|e| active(self, e))
            .map(|e| {
                Ok(ExpressionValue {
                    target: e.target.clone(),
                    value: raw(&evaluated, &e.target)?.sample(if e.target.object() == 0 {
                        frame
                    } else {
                        evaluated
                            .layers
                            .iter()
                            .find(|l| l.id == e.target.object())
                            .ok_or(Error::Missing(e.target.object()))?
                            .local_frame(frame)
                    })?,
                })
            })
            .collect()
    }
}
pub(crate) fn set(project: &mut Project, expression: PropertyExpression, frame: u32) -> Result<()> {
    ensure(
        frame < project.frames,
        "expression edit frame outside composition",
    )?;
    if expression.target.object() != 0 {
        ensure(
            !project.layer_mut(expression.target.object())?.locked,
            "object is locked",
        )?;
    }
    raw(project, &expression.target)?;
    if expression.enabled {
        runtime::compile(&expression.source)
            .map_err(|err| error(&expression.target, frame as f64, err))?;
        // The candidate must participate in dependency resolution. Otherwise
        // replacing B with B -> A would miss the existing A -> B cycle.
        let mut candidate = project.clone();
        if let Some(previous) = candidate.expressions.iter_mut().find(|e| e.target == expression.target) {
            *previous = expression.clone();
        } else { candidate.expressions.push(expression.clone()); }
        candidate.validate()?;
        let result = evaluate(
            &candidate,
            &expression,
            frame as f64,
            Instant::now() + Duration::from_millis(100),
            Arc::new(AtomicBool::new(false)),
        )?;
        let mut check = project.clone();
        write(&mut check, &expression.target, frame as f64, &result)
            .map_err(|err| error(&expression.target, frame as f64, err))?;
    }
    if let Some(e) = project
        .expressions
        .iter_mut()
        .find(|e| e.target == expression.target)
    {
        *e = expression;
    } else {
        project.expressions.push(expression);
    }
    Ok(())
}
pub(crate) fn copy_layer(project: &mut Project, from: u64, to: u64) {
    let copies: Vec<_> = project
        .expressions
        .iter()
        .filter(|e| e.target.object() == from)
        .map(|e| {
            let mut e = e.clone();
            e.target.set_object(to);
            e
        })
        .collect();
    project.expressions.extend(copies);
}

/// The host supplies this evaluator explicitly to the JS-independent renderer.
#[derive(Clone, Copy, Debug, Default)]
pub struct ExpressionEvaluator;
impl motion_model::FrameEvaluator for ExpressionEvaluator {
    fn evaluate<'a>(&self, project: &'a Project, frame: f64) -> Result<Cow<'a, Project>> {
        project.evaluated_at(frame)
    }
}
