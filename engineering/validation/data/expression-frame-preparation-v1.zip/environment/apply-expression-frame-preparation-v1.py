from pathlib import Path
import json

root = Path('E:/Dev/aem')
work = root / '.worktrees/expression-frame-preparation'
out = root / 'artifacts/pr-queue/expression-frame-preparation-before-v1'
report = json.loads((out/'exit.json').read_text())
assert report['status']=='failed_original_outputs_retained' and report['sourceUnchanged']
assert report['results'][0]['exitCode'] != 0
log = (out/'cold-regression.stdout.log').read_text(encoding='utf-8')
assert 'cold_project_compilation_finishes_before_the_frame_clock_starts ... FAILED' in log
assert 'expression cancelled or execution budget exceeded' in log
path = work / 'crates/motion-core/src/expressions/mod.rs'
source = path.read_text()
original = '''pub fn prepare_expression_sources(project: &Project) -> Result<()> {
    for expression in project.expressions.iter().filter(|e| active(project, e)) {
        runtime::compile(&expression.source)
            .map_err(|cause| error(&expression.target, 0., cause))?;
    }
    Ok(())
}'''
replacement = '''pub fn prepare_expression_sources(project: &Project) -> Result<()> {
    prepare_expression_sources_at(project, 0., None)
}
fn prepare_expression_sources_at(
    project: &Project,
    frame: f64,
    cancel: Option<&AtomicBool>,
) -> Result<()> {
    for expression in project.expressions.iter().filter(|e| active(project, e)) {
        if cancel.is_some_and(|flag| flag.load(std::sync::atomic::Ordering::Relaxed)) {
            return Err(error(&expression.target, frame,
                Error::Invalid("expression cancelled or frame budget exceeded".into())));
        }
        runtime::compile(&expression.source)
            .map_err(|cause| error(&expression.target, frame, cause))?;
    }
    Ok(())
}'''
assert source.count(original)==1
source = source.replace(original,replacement)
marker = '        let deadline = Instant::now() + Duration::from_millis(100);'
assert source.count(marker)==1
source = source.replace(marker,'''        // Direct Project callers need the same cold-source admission as native
        // sessions: trusted compilation must finish before the frame clock.
        // User execution retains the existing 20 ms and 100 ms deadlines.
        prepare_expression_sources_at(self, frame, Some(cancel.as_ref()))?;
''' + marker)
path.write_bytes(source.encode())
print('Prepared cold sources before the unchanged frame clock; no panel or budget edit')
