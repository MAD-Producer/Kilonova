from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

root=Path('E:/Dev/aem')
work=root/'.worktrees/expression-frame-preparation'
destination=work/'engineering/validation/data'
destination.mkdir(parents=True,exist_ok=True)
archive=destination/'expression-frame-preparation-v1.zip'
entries={}
runs={}
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for name in ['expression-frame-preparation-before-v1','expression-frame-preparation-after-v1','expression-frame-preparation-contracts-v1']:
    folder=root/'artifacts/pr-queue'/name
    report=json.loads((folder/'exit.json').read_text())
    assert report['sourceUnchanged'] and report.get('completedUtc')
    if 'before' in name:
        assert report['status']=='failed_original_outputs_retained'
        assert report['results'][0]['exitCode']==101
    else:
        assert report['status']=='passed_scoped_regression_final_integration_pending'
        assert all(sha(work/path)==digest for path,digest in report['sources'].items())
    runs[name]={key:value for key,value in report.items() if key!='sources'}
    for path in folder.iterdir():
        if path.is_file(): entries[f'{name}/{path.name}']=path
totals=[0,0,0]
for name,run in runs.items():
    if 'before' not in name:
        for result in run['results']:
            for line in result['summaries']:
                counts=map(int,re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored;',line).groups())
                totals=[a+b for a,b in zip(totals,counts)]
assert totals==[81,0,1],totals
for name in ['mod.rs','runtime.rs','preparation_tests.rs']:
    entries['validated-source/'+name]=work/'crates/motion-core/src/expressions'/name
for name in ['run-expression-frame-preparation-v1.ps1','run-expression-frame-contracts-v1.ps1','apply-expression-frame-preparation-v1.py','publish-expression-frame-preparation-v1.py']:
    entries['environment/'+name]=root/'.tools/issue-closure-review'/name
folder=root/'artifacts/pr-queue/professional-api86-ci-162-v1'
for path in folder.iterdir():
    if path.is_file(): entries['original-ci/'+path.name]=path
limits=[
    'Original Linux PR599 failure is retained; its generic budget error does not identify which original deadline elapsed',
    'The controlled cold-compiler barrier reproduces that error class before the change and passes after it; compilation executes no user expression',
    'Existing execution20ms/frame100ms limits, cache/memory bounds, original assertions and ignore annotations are unchanged',
    'Test-only compile gate is absent from production builds; it blocks once on a fresh owning thread without mocking successful evaluation',
    'Three new tests cover cold preparation, pre-cancelled admission and requested-frame/native-cause retention; existing public preparation and sandbox tests also pass',
    'Independent worktree based on child162edfed plus recorded three-file change; original full GPU/desktop controller61610 remains on unmodified child162edfed',
    'No panel, layout, dependency, asset, Android, worker timeout/restart, final combined-suite or final cross-platform acceptance claim',
]
manifest=dict(status='cold_preparation_fixed_scoped_tests_passed_final_integration_pending',base='162edfed2b90550b69d9ea59b42bb1138369e7a2',passed=81,failed=0,ignored=1,runs=runs,limits=limits,entries={name:dict(bytes=path.stat().st_size,sha256=sha(path)) for name,path in entries.items()})
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    output.writestr('manifest.json',json.dumps(manifest,indent=2))
    for name,path in entries.items():output.write(path,name)
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    for name,value in manifest['entries'].items():
        assert hashlib.sha256(output.read(name)).hexdigest()==value['sha256']
receipt={key:value for key,value in manifest.items() if key not in ['runs','entries']}
receipt.update(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members=len(entries)+1)
with archive.with_suffix('.json').open('x',encoding='utf-8') as output:
    json.dump(receipt,output,indent=2)
    output.write('\n')
doc=work/'engineering/validation/expression-frame-preparation-current.md'
with doc.open('x',encoding='utf-8') as output:
    output.write('''# Expression frame admission: cold source preparation

Status: scoped fix verified; final branch integration, full regression and
cross-platform CI remain pending. This does not close issues 85, 86 or 88.

PR 599 head `162edfed` failed in the Linux Rust/GPU job while the unchanged
`merge_dimensions` expression test first evaluated frame zero. The retained
error is `expression cancelled or execution budget exceeded`. The original log
does not distinguish its expression deadline from the outer frame deadline.

Direct `Project::evaluated_at_cancellable` started its 100 ms frame clock before
the runtime compiled cold source. Native Sessions already prepared source
before evaluating frames. A controlled one-shot barrier on actual cold
compilation reproduces the same error class: hold compilation for 120 ms, then
release it without running any expression while blocked. The original code
fails; the new code evaluates the real expression and samples its result.

The direct project API now shares source preparation before starting the frame
clock. A pre-cancelled request rejects before compilation; preparation errors
retain the requested frame, target and original cause. The public preparation
API retains its existing frame-zero diagnostic context. Expression execution
still has 20 ms, and evaluated frames still have 100 ms. Cache capacity, memory
limits, JS isolation and dependency-cycle checks remain intact.

The compile barrier exists only under cfg(test), on the owning thread, and is
removed from production builds. Three new tests cover cold admission,
cancellation before compilation and native syntax causes at a fractional frame.
The full core unit target and seven existing expression/merge integration
targets pass: 81 tests passed, zero failed, one existing unit test ignored.
Existing assertions, error expectations, budgets and ignore markers are
unchanged. Public preparation tests prove compilation does not execute user
code; sandbox and existing timeout/cancellation tests still reject interrupted
execution and permit later recovery.

The evidence archive and adjacent receipt retain the actual original CI log,
controlled pre-fix failure, post-fix runs, source snapshots and environment
wrappers. Every archive member was read back and SHA-256 checked. Initial and
final source identities remain separate; failed records were not rewritten.

The fix was developed in an independent worktree based on `162edfed` while the
original complete GPU/desktop gate remained source-frozen on that old head.
That running gate does not validate this change. No panel, UI layout, asset,
dependency, Android code, worker timeout or restart changed. Final integration
and CI are required before claiming the original PR check resolved.
''')
print(json.dumps(receipt),flush=True)
