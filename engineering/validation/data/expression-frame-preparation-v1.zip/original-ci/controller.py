from pathlib import Path
import hashlib
import json
import subprocess

root = Path('E:/Dev/aem')
out = root / 'artifacts/pr-queue/professional-api86-ci-162-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
job = 125857754432
actual = json.loads(subprocess.check_output(['gh','api',f'repos/MAD-Producer/Kilonova/actions/jobs/{job}']))
run = json.loads(subprocess.check_output(['gh','api',f'repos/MAD-Producer/Kilonova/actions/runs/{actual["run_id"]}']))
assert actual['status']=='completed' and actual['conclusion']=='failure'
assert run['head_sha']=='162edfed2b90550b69d9ea59b42bb1138369e7a2'
raw = subprocess.check_output(['gh','api',f'repos/MAD-Producer/Kilonova/actions/jobs/{job}/logs'])
(out/'rust-gpu.log').write_bytes(raw)
report = dict(status='actual_ci_failure_retained',number=599,head=run['head_sha'],run=actual['run_id'],job=job,conclusion=actual['conclusion'],steps=[dict(name=step['name'],conclusion=step['conclusion']) for step in actual['steps']],log=dict(path='rust-gpu.log',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
