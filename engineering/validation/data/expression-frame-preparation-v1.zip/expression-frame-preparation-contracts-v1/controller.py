from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/expression-frame-preparation'
stage = sys.argv[1]
assert stage == 'after'
out = root / 'artifacts/pr-queue' / 'expression-frame-preparation-contracts-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
names = subprocess.check_output(['git','ls-files','-z','crates','desktop','Cargo.toml','Cargo.lock'],cwd=work).decode().split('\0')
names += subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z','crates','desktop'],cwd=work).decode().split('\0')
sources = {name:sha(work/name) for name in names if name and (work/name).is_file()}
assert 'crates/motion-core/src/expressions/preparation_tests.rs' in sources
os.environ.pop('MOTION_LOG',None)
commands=[('public-contracts',['cargo','test','-p','motion-core','--test','expression_preparation','--test','expression_sandbox','--test','expression_error_causes','--test','expression_sample_time','--no-fail-fast','--locked','--offline','--','--test-threads=1'])]
report = dict(status='running',stage=stage,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),startedUtc=datetime.now(timezone.utc).isoformat(),scope='Existing public preparation API, sandbox, original-cause and non-finite sampling contracts after changing shared preparation; cover skipped disabled sources, no user execution during compile, cancellation, infinite-loop deadlines and later recovery; independent source tree/target from live full GPU desktop gate. No panel edits, assertion changes, timeout increases or user-code budget changes.',sources=sources,results=[])
save = lambda: (out/'exit.json').write_text(json.dumps(report,indent=2)+'\n')
start = time.monotonic()
save()
try:
    for name,command in commands:
        item = dict(name=name,command=command,status='running')
        report['results'].append(item)
        save()
        began = time.monotonic()
        with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
            process = subprocess.Popen(command,cwd=work,env=os.environ.copy(),stdout=stdout,stderr=stderr)
            item['pid'] = process.pid
            save()
            item['exitCode'] = process.wait()
        item['elapsedSeconds'] = round(time.monotonic()-began,3)
        item['summaries'] = re.findall(r'^test result: .+$',(out/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
        item['status'] = 'passed' if item['exitCode']==0 else 'failed'
        save()
        print(json.dumps(item),flush=True)
        if item['exitCode']!=0:
            break
    report['sourceUnchanged'] = all(sha(work/name)==digest for name,digest in sources.items())
    report['status'] = 'passed_scoped_regression_final_integration_pending' if all(item['status']=='passed' for item in report['results']) and report['sourceUnchanged'] else 'failed_original_outputs_retained'
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-start,3))
    save()
    print(json.dumps({key:value for key,value in report.items() if key!='sources'}),flush=True)
raise SystemExit(0 if report['status']=='passed_scoped_regression_final_integration_pending' else 1)
