from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, time

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-colmap88'
OUT = ROOT / 'artifacts/pr-queue/frame-rate85-settings-native-v2'
OUT.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()
sources = {p: sha(WORK/p) for p in paths if (WORK/p).is_file() and
           (p.startswith(('crates/', 'desktop/')) or p in ('Cargo.toml', 'Cargo.lock'))}
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
(OUT/'changes.patch').write_bytes(subprocess.check_output(['git', 'diff'], cwd=WORK))
for name in ['desktop/app/src/shell/rational_clock_native_tests.rs', 'desktop/app/src/shell/rational_clock_native_tests/settings.rs']:
    dest = OUT/'source'/name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((WORK/name).read_bytes())
env = os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'): env.pop(name, None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT/'target/colmap88-isolated-check'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full', TEMP=str(ROOT/'target/ci-policy-validation-tmp'),
           TMP=str(ROOT/'target/ci-policy-validation-tmp'), LOCALAPPDATA=str(OUT/'profile'),
           MOTION_RATIONAL_SETTINGS_UI_ARTIFACTS=str(OUT/'captures'))
command = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg', '--bin', 'motion-studio',
           '--locked', '--offline',
           'shell::rational_clock_native_tests::settings::rational_rate_settings_native_dropdown_cancel_apply_and_history',
           '--', '--exact', '--test-threads=1', '--nocapture']
report = dict(status='running', source=sources, sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),
              command=command, startedUtc=datetime.now(timezone.utc).isoformat(), targetDirectory=env['CARGO_TARGET_DIR'],
              limits=['New native modal acceptance only; no replacement for the retained failed full regression',
                      'Original product/assertions/stack/backend unchanged; default Info; isolated source target; no OS input injection',
                      'Actual attached native GPU captures require visual review after successful execution'])
def save(): (OUT/'exit.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
save()
started = time.monotonic()
try:
    with (OUT/'stdout.log').open('wb') as stdout, (OUT/'stderr.log').open('wb') as stderr:
        process = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = process.pid
        save()
        report['exitCode'] = process.wait()
    report['sourceUnchanged'] = all(sha(WORK/p) == digest for p,digest in sources.items())
    stdout = (OUT/'stdout.log').read_text(encoding='utf-8', errors='replace')
    report['summaries'] = re.findall(r'^test result:.*$', stdout, re.M)
    report['status'] = 'native_modal_passed_visual_review_pending' if report['exitCode'] == 0 and report['sourceUnchanged'] and any(
        '1 passed; 0 failed; 0 ignored;' in s for s in report['summaries']) else 'failed_original_outputs_retained'
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic()-started,3))
    save()
print(json.dumps({k:v for k,v in report.items() if k != 'source'}))
raise SystemExit(0 if report['status'] == 'native_modal_passed_visual_review_pending' else 1)
