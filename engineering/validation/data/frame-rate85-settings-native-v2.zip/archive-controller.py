from pathlib import Path
import hashlib, json, zipfile
ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/tracking-colmap88'
DEST=WORK/'engineering/validation/data'
sha=lambda data:hashlib.sha256(data).hexdigest()
members={'archive-controller.py':Path(__file__).read_bytes()}
for name in ['frame-rate85-settings-native-v1','frame-rate85-settings-native-v2']:
    folder=ROOT/'artifacts/pr-queue'/name
    for relative in ['exit.json','controller.py','changes.patch','stdout.log','stderr.log']:
        members[name+'/'+relative]=(folder/relative).read_bytes()
    for path in (folder/'source').rglob('*'):
        if path.is_file(): members[name+'/'+str(path.relative_to(folder)).replace('\\','/')]=path.read_bytes()
    for path in (folder/'captures').glob('*'):
        if path.is_file(): members[name+'/captures/'+path.name]=path.read_bytes()
    for language in ['en','zh']:
        path=folder/'captures'/language/'project.json'
        if path.is_file():members[name+'/captures/'+language+'/project.json']=path.read_bytes()
archive=DEST/'frame-rate85-settings-native-v2.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):
        info=zipfile.ZipInfo(name,(2026,11,5,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,data)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members)
    for name,data in members.items(): assert z.read(name)==data and sha(z.read(name))==sha(data),name
receipt=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
             baseline='df3016b2b9d5297fbfabeeca97b7dee3d144e6c5',
             dispositions={'originalNewTest':'FAILED: requested duration clips the retimed full-length layer',
                           'correctedValidRequest':'PASS: both locales/policies, rejection preserved, explicit matching duration',
                           'visualReview':'12 original native captures inspected; existing error clipping/stale draft error retained'},
             limits=['New focused test source only, not a full regression or issue closure',
                     'No product/panels/layout/style/threshold change',
                     'No Android acceptance or new-process reopen proof'],
             members={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())})
archive.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='members'}))
