"""Partition original measured errors by image support; no sample removed from its gate."""
from pathlib import Path
import json,hashlib,zipfile,math,datetime
R=Path('E:/Dev/aem');A=R/'artifacts/pr-queue';O=A/'tracking88-corner-visibility-v1';W=R/'.worktrees/planar-tracker88'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
gt=A/'tracking88-real-planar-acquisition-v1/phone-gt.zip';assert sha(gt)=='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
O.mkdir(exist_ok=False);(O/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='running',scope='Descriptive full original2300-frame corner support partition, not a replacement quality test',originalMaximumBoundPixels=15,truthSha256=sha(gt),rows=[])
with zipfile.ZipFile(gt) as z:
 truth=[]
 for i in range(2300):
  v=[float(x) for x in z.read(f'img_{i+200:05d}.txt').decode('ascii').split()];assert len(v)==8
  truth.append([(v[k+4]-1,v[k]-1) for k in range(4)])
def project(h,p):
 x,y=p;d=h[2][0]*x+h[2][1]*y+h[2][2];assert abs(d)>1e-10
 return ((h[0][0]*x+h[0][1]*y+h[0][2])/d,(h[1][0]*x+h[1][1]*y+h[1][2])/d)
for name,rel,expected in [('original','tracking88-photographed-prototype-v6/periodic-manual-200/tracks.mstrack',21),('window_v3','tracking88-reference-window-phone-v3/periodic-manual-200/tracks.mstrack',10)]:
 p=A/rel;j=json.loads(p.read_text(encoding='utf-8'));assert j['source_pts']==list(range(2300))
 samples=next(t for t in j['tracks'] if t['id']=='plane')['samples']
 row=dict(name=name,inputSha256=sha(p),automaticVisible=0,automaticLost=0,originalFailingSamples=0,failWithInFrameCorner=0,failOnlyWithOutsideCorner=0,inFrameCorners=0,outsideCorners=0,inFrameCornerViolations=0,outsideCornerViolations=0,inFrameCornerMaximum=0.,outsideCornerMaximum=0.,originalMaximum=0.,failedIndices=[])
 details=[]
 for i,sample in enumerate(samples):
  if i==0 or sample['manual_correction']:continue
  if sample['visibility']!='visible':row['automaticLost']+=1;continue
  row['automaticVisible']+=1;h=sample['observation']['matrix'];errors=[];inside=[]
  for k,c in enumerate(truth[i]):
   predicted=project(h,truth[0][k]);error=math.hypot(predicted[0]-c[0],predicted[1]-c[1]);assert math.isfinite(error)
   supported=0<=c[0]<640 and 0<=c[1]<480;errors.append(error);inside.append(supported)
   prefix='inFrame' if supported else 'outside';row[prefix+'Corners']+=1;row[prefix+'CornerViolations']+=int(error>15);row[prefix+'CornerMaximum']=max(row[prefix+'CornerMaximum'],error)
  row['originalMaximum']=max(row['originalMaximum'],max(errors))
  if max(errors)>15:
   row['originalFailingSamples']+=1;row['failedIndices'].append(i)
   row['failWithInFrameCorner' if any(e>15 and v for e,v in zip(errors,inside)) else 'failOnlyWithOutsideCorner']+=1
   details.append(dict(index=i,errors=errors,inFrame=inside))
 assert row['originalFailingSamples']==expected
 assert row['inFrameCorners']+row['outsideCorners']==row['automaticVisible']*4
 row['allOriginalCornersRetained']=True;row['sourceUnchanged']=sha(p)==row['inputSha256'];assert row['sourceUnchanged'];report['rows'].append(row)
 (O/(name+'-failed-detail.json')).write_text(json.dumps(details,indent=2),encoding='utf-8')
report.update(status='complete_partition_not_tracking_or_annotation_qualification',completedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),limits=['All original corners including outside-image annotations remain in original15px gate','In-frame/outside partition is descriptive, not a new acceptance metric','No model selection, annotation validity, physical coplanarity or error cause proven','No tracker, image decode, new CV dependency or changed product source'])
(O/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
