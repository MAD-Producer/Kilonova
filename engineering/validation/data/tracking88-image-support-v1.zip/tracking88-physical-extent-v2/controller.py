"""Sparse original-image geometry observation, never a quality gate or tracker."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time,traceback,zipfile
R=Path('E:/Dev/aem');A=R/'artifacts/pr-queue';W=R/'.worktrees/planar-tracker88';O=A/'tracking88-physical-extent-v2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
video=A/'tracking88-real-planar-acquisition-v1/phone.avi';gt=video.with_name('phone-gt.zip')
assert sha(video)=='c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
assert sha(gt)=='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
request=A/'tracking88-photographed-prototype-v6/periodic-manual-200.request.json'
assert sha(request)=='f88e3951fbaa5a0a1fabf527b85de75826905857ad3ca590da9367f4ad9c2191'
old=A/'tracking88-photographed-prototype-v6/periodic-manual-200/tracks.mstrack'
assert sha(old)=='5dd567b7f1ec994a4120700fe529abdf97fdc27ffd7c10f327751ab91bc68dfa'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert head.startswith('eb9b4825')
state=json.loads((A/'depth75-resume-current.json').read_text(encoding='utf-8'))['versionedCache75']
assert state['activeController'] is None and not state['ownHeavyWorkloads']
O.mkdir(exist_ok=False);(O/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='running',sourceHead=head,inputHashes={str(p):sha(p) for p in (video,gt,request,old)},selectedIndices=[0,1800,1801,1810,1821,1830],rows=[],limits=['Previously diagnosed sparse segment, not a quality sample or new fitted tracker','No source/ROI/annotation/threshold edit; original full gate remains failed','Frames and annotated overlays stay local under original external-use attribution','Image appearance/geometry alone does not measure physical depth or prove annotation validity'])
began=time.monotonic()
def save():
 with (O/'receipt.json').open('w',encoding='utf-8') as f:json.dump(report,f,indent=2);f.flush();os.fsync(f.fileno())
def phase(s):
 report['phase']=s;save()
 with (O/'phases.log').open('a') as f:f.write(f'INFO start {s} elapsed_ms={int((time.monotonic()-began)*1000)}\n');f.flush();os.fsync(f.fileno())
try:
 phase('import_existing_cv_runtime')
 import cv2,numpy as np
 cv2.setNumThreads(1)
 req=json.loads(request.read_text(encoding='utf-8'));asset=json.loads(old.read_text(encoding='utf-8'));samples=next(t for t in asset['tracks'] if t['id']=='plane')['samples']
 x,y,w,h=next(t for t in req['tracks'] if t['kind']=='plane')['roi'];roi=np.array([[x,y],[x+w,y],[x+w,y+h],[x,y+h]],np.float64)
 with zipfile.ZipFile(gt) as z:
  truth={i:np.array([float(v) for v in z.read(f'img_{i+200:05d}.txt').decode().split()]).reshape(2,4)[::-1].T-1 for i in report['selectedIndices']}
 def project(h,p):
  v=np.column_stack((p,np.ones(len(p))))@h.T
  assert np.isfinite(v).all() and np.all(abs(v[:,2])>1e-10)
  return v[:,:2]/v[:,2:]
 ff=R/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
 selection='+'.join('eq(n\\,'+str(i)+')' for i in report['selectedIndices'])
 # One escaping backslash is passed to libavfilter, independently of the shell.
 selection=selection.replace('\\\\','\\')
 cmd=[str(ff),'-v','error','-nostdin','-threads','1','-noautorotate','-copyts','-i',str(video),'-map','0:0','-an','-sn','-dn','-vf','select='+selection,'-fps_mode','passthrough','-threads','1','-f','rawvideo','-pix_fmt','bgr24','pipe:1']
 report.update(decodeCommand=cmd,decoderSha256=sha(ff));phase('decode_fixed_original_source_indices')
 with (O/'decode.stderr.log').open('xb') as f:child=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=f,check=True,timeout=60)
 assert len(child.stdout)==len(truth)*480*640*3
 report['decodedSha256']=hashlib.sha256(child.stdout).hexdigest();images=np.frombuffer(child.stdout,np.uint8).reshape(-1,480,640,3)
 frame_rect=np.array([[0.,0.],[639.,0.],[639.,479.],[0.,479.]],np.float32)
 montage=[]
 for n,index in enumerate(report['selectedIndices']):
  phase('observe_source_index_'+str(index));image=images[n].copy();assert cv2.imwrite(str(O/f'{index:04d}-original.png'),image)
  target=cv2.getPerspectiveTransform(truth[0].astype(np.float32),truth[index].astype(np.float32)).astype(np.float64)
  projected_roi=project(target,roi);corners=truth[index]
  area=abs(cv2.contourArea(projected_roi.astype(np.float32)))
  visible_area,_=cv2.intersectConvexConvex(projected_roi.astype(np.float32),frame_rect)
  row=dict(index=index,annotatedCornersInFrame=int(((corners[:,0]>=0)&(corners[:,0]<640)&(corners[:,1]>=0)&(corners[:,1]<480)).sum()),projectedRoiVisibleAreaFraction=float(visible_area/area),referenceEdit=bool(samples[index]['manual_correction']),originalVisible=samples[index]['visibility']=='visible')
  cv2.polylines(image,[np.rint(corners).astype(np.int32)],True,(0,220,0),2)
  cv2.polylines(image,[np.rint(projected_roi).astype(np.int32)],True,(0,0,230),2)
  if row['originalVisible']:
   predicted=np.array(samples[index]['observation']['matrix']);p=project(predicted,truth[0]);row['cornerMaxPixels']=float(np.linalg.norm(p-corners,axis=1).max())
   cv2.polylines(image,[np.rint(p).astype(np.int32)],True,(240,140,0),2)
  cv2.putText(image,f'index {index}: truth green / ROI red / predicted blue',(8,20),cv2.FONT_HERSHEY_SIMPLEX,.48,(0,0,0),2)
  cv2.putText(image,f'index {index}: truth green / ROI red / predicted blue',(8,20),cv2.FONT_HERSHEY_SIMPLEX,.48,(255,255,255),1)
  assert cv2.imwrite(str(O/f'{index:04d}-overlay.png'),image);montage.append(image);report['rows'].append(row);save()
 assert cv2.imwrite(str(O/'contact.png'),np.concatenate([np.concatenate(montage[:3],axis=1),np.concatenate(montage[3:],axis=1)],axis=0))
 report.update(status='sparse_geometry_observation_complete_not_physical_correspondence_proof',sourceUnchanged=not bool(subprocess.check_output(['git','status','--porcelain'],cwd=W)),inputUnchanged=all(sha(Path(p))==h for p,h in report['inputHashes'].items()))
 assert report['sourceUnchanged'] and report['inputUnchanged']
except BaseException:
 report.update(status='failed',cause=traceback.format_exc());sys.stderr.write('ERROR physical-extent observation failed\n'+report['cause']);raise
finally:
 report['elapsedSeconds']=time.monotonic()-began;save();print(json.dumps({k:report.get(k) for k in ('status','rows','cause')}))
