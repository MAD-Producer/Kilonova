"""Actual host integration, serialized after the existing native validators."""
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT/'.worktrees/tracking88-pose'
OUT = ROOT/'artifacts/pr-queue/tracking88-pose-host-v1'
PARENT = 42416
HEAD = 'cd770f5b'

def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git',*args],cwd=WORK).decode().strip()
def sources():
    return {name:hashlib.sha256((WORK/name).read_bytes()).hexdigest()
        for name in git('ls-files','-z').split('\0')
        if name and name.endswith(('.rs','.toml','.lock','.wgsl','.json','.md','.py','.yml','.yaml'))}

OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='queued', controllerPid=os.getpid(), startedUtc=now(), steps=[],
    limits='Actual motion-host Cargo check and tracking tests only. Freshly verified main8573 baseline, not full workspace, project editing, renderer/footage acceptance or CI. Prior #82 strict P95 failures remain unchanged.')
def save():
    p = OUT/'exit.next.json'
    p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    os.replace(p,OUT/'exit.json')
save()
handle = None
kernel = ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE,wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
try:
    assert git('rev-parse','--short=8','HEAD') == HEAD
    assert not git('status','--porcelain'), 'owned tracking tree must be clean'
    report['head'] = git('rev-parse','HEAD')
    report['source'] = sources()
    handle = kernel.OpenProcess(0x00100000,False,PARENT)
    if not handle: raise ctypes.WinError(ctypes.get_last_error())
    assert kernel.WaitForSingleObject(handle,0) == 258, 'expected exact native phase controller alive'
    report['parent'] = dict(pid=PARENT,handleCapturedLive=True,receipt='tracking88-host-v1')
    save()
    while True:
        result = kernel.WaitForSingleObject(handle,1000)
        if result == 0: break
        if result != 258: raise ctypes.WinError(ctypes.get_last_error())
    kernel.CloseHandle(handle)
    handle = None
    parent = json.loads((ROOT/'artifacts/pr-queue/tracking88-host-v1/exit.json').read_text())
    assert parent.get('completedUtc'), 'predecessor lacks an actual terminal receipt'
    assert parent.get('status') == 'accepted_host_check_and_tracking_tests_not_full_issue', 'base tracking host integration failed; retain and fix original failure first'
    assert git('rev-parse','HEAD') == report['head'] and not git('status','--porcelain')
    assert sources() == report['source'], 'tracking source changed while queued'
    report['parentTerminalStatus'] = parent.get('status')
    report['status'] = 'running'
    save()
    env = os.environ.copy()
    env.pop('MOTION_LOG',None)
    env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),
        CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
        CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',
        CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',
        PYTHONPATH=str(ROOT/'.tools/build-validation-python'))
    for name,command in [
        ('host-check',['cargo','check','-p','motion-host','--locked','--offline']),
        ('tracking-tests',['cargo','test','-p','motion-host','--lib','tracking::','--locked','--offline','--','--test-threads=1']),
    ]:
        step = dict(name=name,command=command,startedUtc=now())
        report['steps'].append(step)
        with (OUT/f'{name}.stdout.log').open('wb') as stdout, (OUT/f'{name}.stderr.log').open('wb') as stderr:
            process = subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
            step['pid'] = process.pid
            save()
            step['exitCode'] = process.wait()
        step['completedUtc'] = now()
        save()
        assert step['exitCode'] == 0, f'{name} actual failure; retained, no retry'
    log = (OUT/'tracking-tests.stdout.log').read_text(encoding='utf-8',errors='replace')
    counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
    assert len(counts) == 1 and tuple(map(int,counts[0])) == (44,0,0), 'expected all 44 tracking tests'
    assert git('rev-parse','HEAD') == report['head'] and not git('status','--porcelain')
    assert sources() == report['source'], 'source/lock changed during actual host validation'
    report['totals'] = dict(passed=44,failed=0,ignored=0)
    report['status'] = 'accepted_host_check_and_tracking_tests_not_full_issue'
except BaseException as cause:
    report['status'] = 'failed'
    report['failure'] = repr(cause)
    raise
finally:
    if handle: kernel.CloseHandle(handle)
    report['completedUtc'] = now()
    save()
