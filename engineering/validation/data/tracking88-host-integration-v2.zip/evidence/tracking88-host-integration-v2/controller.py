"""Rebuild each exact host increment after native validators release the target."""
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking88-pose'
OUT = ROOT / 'artifacts/pr-queue/tracking88-host-integration-v2'
PARENT = 38188
HEAD = 'cd770f5b93c0af2c023db82be2e66809ce6fb8c9'
PLANE = ROOT / 'artifacts/pr-queue/tracking88-plane-condition-v1'
TIME = ROOT / 'artifacts/pr-queue/tracking88-time-mapping-v1'

def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def sources():
    return {n: sha(WORK/n) for n in git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
            if n and n.endswith(('.rs', '.toml', '.lock', '.wgsl', '.json', '.md', '.py', '.yml', '.yaml'))}

OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='queued', controllerPid=os.getpid(), startedUtc=now(), steps=[],
              limits='Old intended44 host gate executed cached35 and correctly rejected coverage; retained unchanged. Force current worktree root timestamps and require44/47/56 actual tests at their respective source stages. No weakened assertion, performance retry or full issue claim. No automatic rollback or commit.')
def save():
    p = OUT / 'exit.next.json'
    p.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    os.replace(p, OUT / 'exit.json')

env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', RUST_BACKTRACE='full',
           PYTHONPATH=str(ROOT / '.tools/build-validation-python'), TEMP=str(ROOT / 'target/ci-policy-validation-tmp'), TMP=str(ROOT / 'target/ci-policy-validation-tmp'))

def step(label, args, expected=None, minimum=None):
    row = dict(name=label, command=args, startedUtc=now())
    report['steps'].append(row)
    save()
    print(json.dumps(dict(start=label)), flush=True)
    with (OUT/f'{label}.stdout.log').open('wb') as stdout, (OUT/f'{label}.stderr.log').open('wb') as stderr:
        child = subprocess.Popen(args, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        row['pid'] = child.pid
        save()
        row['exitCode'] = child.wait()
    row['completedUtc'] = now()
    save()
    assert row['exitCode'] == 0, f'{label} actual failure retained'
    text = (OUT/f'{label}.stdout.log').read_text(encoding='utf-8', errors='replace')
    counts = [tuple(map(int, m)) for m in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)]
    row['counts'] = counts
    save()
    if expected is not None:
        assert counts == [(expected, 0, 0)], f'{label} must execute all {expected} current-source tests, never a cached earlier suite'
    if minimum is not None:
        assert counts and sum(c[0] for c in counts) >= minimum and all(c[1] == 0 for c in counts)
    assert git('rev-parse', 'HEAD') == HEAD and sources() == report['currentSource'], 'source changed during actual host validation'
    row['passed'] = True
    save()

def validate(label, count):
    report.update(status='running_'+label, currentSource=sources())
    # Cargo shares package IDs across these worktrees. A recent binary from the
    # previous source can otherwise satisfy mtime freshness despite missing new
    # modules. Touch only the current host root, preserving its exact bytes.
    original = sha(WORK/'crates/motion-host/src/lib.rs')
    os.utime(WORK/'crates/motion-host/src/lib.rs', None)
    assert sha(WORK/'crates/motion-host/src/lib.rs') == original
    report.setdefault('freshnessControls', []).append(dict(stage=label, root='crates/motion-host/src/lib.rs', sha256=original, appliedUtc=now()))
    save()
    step(label+'-check', ['cargo','check','-p','motion-host','--locked','--offline'])
    step(label+'-tests', ['cargo','test','-p','motion-host','--lib','tracking::','--locked','--offline','--','--test-threads=1'], expected=count)

save()
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
handle = None
try:
    assert git('rev-parse', 'HEAD') == HEAD and not git('status','--porcelain')
    report['beforeSource'] = sources()
    files = [PLANE/'candidate_asset.rs', PLANE/'asset_tests.rs', PLANE/'completion-document.md', TIME/'time.rs', TIME/'time_tests.rs', TIME/'completion-document.md']
    report['proposalHashes'] = {str(p.relative_to(ROOT)):sha(p) for p in files}
    handle = kernel.OpenProcess(0x00100000, False, PARENT)
    if not handle: raise ctypes.WinError(ctypes.get_last_error())
    assert kernel.WaitForSingleObject(handle, 0) == 258
    report['parent'] = dict(pid=PARENT, receipt='prerender-paced-phases-v4', handleCapturedLive=True)
    save()
    print(json.dumps(dict(queuedBehind=PARENT)), flush=True)
    while True:
        state = kernel.WaitForSingleObject(handle, 1000)
        if state == 0: break
        assert state == 258
    kernel.CloseHandle(handle)
    handle = None
    parent = json.loads((ROOT/'artifacts/pr-queue/prerender-paced-phases-v4/exit.json').read_text(encoding='utf-8'))
    assert parent.get('completedUtc') and parent['status']=='collected_native_phase_diagnostic_not_qualification', 'inspect actual preceding failure before later build'
    assert git('rev-parse','HEAD') == HEAD and not git('status','--porcelain') and sources() == report['beforeSource']
    for name, digest in report['proposalHashes'].items(): assert sha(ROOT/name) == digest, name
    validate('pose44', 44)
    assert (PLANE/'original_asset.rs').read_bytes() == (WORK/'crates/motion-host/src/tracking/asset.rs').read_bytes()
    for source, target in [('candidate_asset.rs','asset.rs'),('asset_tests.rs','asset_tests.rs')]:
        (WORK/'crates/motion-host/src/tracking'/target).write_bytes((PLANE/source).read_bytes())
    (WORK/'engineering/validation/tracking88-plane-condition-current.md').write_bytes((PLANE/'completion-document.md').read_bytes())
    validate('plane47', 47)
    for name in ['time.rs','time_tests.rs']:
        destination = WORK/'crates/motion-host/src/tracking'/name
        assert not destination.exists()
        destination.write_bytes((TIME/name).read_bytes())
    module = WORK/'crates/motion-host/src/tracking.rs'
    assert b'pub mod time;' not in module.read_bytes()
    module.write_bytes(module.read_bytes()+b'pub mod time;\n')
    doc = (TIME/'completion-document.md').read_text(encoding='utf-8').replace('tracking88-time-host-v2/exit.json','tracking88-host-integration-v2/exit.json')
    (WORK/'engineering/validation/tracking88-time-mapping-current.md').write_text(doc, encoding='utf-8')
    validate('time56', 56)
    step('host-lib-regression', ['cargo','test','-p','motion-host','--lib','--locked','--offline','--','--test-threads=1'], minimum=56)
    step('whitespace', ['git','diff','--check'])
    report.update(status='accepted_fresh_host_pose_plane_time_and_lib_not_full_issue', source=sources(), totals=dict(trackingPassed=56, trackingFailed=0))
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    if handle: kernel.CloseHandle(handle)
    report['completedUtc'] = now()
    save()
