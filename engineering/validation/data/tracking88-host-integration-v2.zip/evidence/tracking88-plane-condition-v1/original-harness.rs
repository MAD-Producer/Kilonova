#![allow(dead_code)]
mod tracking {
    #[path = "E:/Dev/aem/.worktrees/tracking88-pose/crates/motion-host/src/tracking/plate.rs"]
    pub mod plate;
    #[path = "E:/Dev/aem/artifacts/pr-queue/tracking88-plane-condition-v1/original_asset.rs"]
    pub mod asset;
    #[path = "E:/Dev/aem/.worktrees/tracking88-pose/crates/motion-host/src/tracking/decode.rs"]
    pub mod decode;
    #[path = "E:/Dev/aem/.worktrees/tracking88-pose/crates/motion-host/src/tracking/encode.rs"]
    pub mod encode;
    #[path = "E:/Dev/aem/.worktrees/tracking88-pose/crates/motion-host/src/tracking/pose.rs"]
    pub mod pose;
}
