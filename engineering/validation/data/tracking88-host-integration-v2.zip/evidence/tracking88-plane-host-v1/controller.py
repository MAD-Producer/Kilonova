"""Apply a CPU-proven correction only after the preceding exact source is released."""
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/tracking88-pose'
OUT=ROOT/'artifacts/pr-queue/tracking88-plane-host-v1'
PROPOSAL=ROOT/'artifacts/pr-queue/tracking88-plane-condition-v1'
PARENT=15940
HEAD='cd770f5b93c0af2c023db82be2e66809ce6fb8c9'
def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git',*args],cwd=WORK).decode().strip()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def sources():
    return {name:sha(WORK/name) for name in git('ls-files','--cached','--others','--exclude-standard','-z').split('\0')
        if name and name.endswith(('.rs','.toml','.lock','.wgsl','.json','.md','.py','.yml','.yaml'))}
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='queued',controllerPid=os.getpid(),startedUtc=now(),steps=[],
    limits='Actual original negative and direct candidate47 pass retained. Wait exact predecessor accepted before source correction. Host check/test only, not rendered project/footage or full issue. Original #82 strict failures unchanged.')
def save():
    p=OUT/'exit.next.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(p,OUT/'exit.json')
save()
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.WaitForSingleObject.restype=wintypes.DWORD
kernel.CloseHandle.argtypes=[wintypes.HANDLE]
handle=None
try:
    assert git('rev-parse','HEAD')==HEAD and not git('status','--porcelain')
    report['head']=HEAD;report['beforeSource']=sources()
    proposal=json.loads((PROPOSAL/'receipt.json').read_text())
    assert proposal['status']=='accepted_direct_cpu_candidate_not_applied_or_host_validated'
    assert proposal['baseHead']==HEAD and proposal['originalAssertionsPreserved']
    for name in ['candidate_asset.rs','asset_tests.rs','proposal.patch']:
        assert sha(PROPOSAL/name)==proposal['hashes'][name],name
    report['proposalReceiptSha256']=sha(PROPOSAL/'receipt.json')
    report['proposalDocumentSha256']=sha(PROPOSAL/'completion-document.md')
    handle=kernel.OpenProcess(0x00100000,False,PARENT)
    if not handle: raise ctypes.WinError(ctypes.get_last_error())
    assert kernel.WaitForSingleObject(handle,0)==258,'expected predecessor alive'
    report['parent']=dict(pid=PARENT,handleCapturedLive=True,receipt='tracking88-pose-host-v1');save()
    while True:
        state=kernel.WaitForSingleObject(handle,1000)
        if state==0: break
        if state!=258: raise ctypes.WinError(ctypes.get_last_error())
    kernel.CloseHandle(handle);handle=None
    parent=json.loads((ROOT/'artifacts/pr-queue/tracking88-pose-host-v1/exit.json').read_text())
    assert parent.get('completedUtc') and parent['status']=='accepted_host_check_and_tracking_tests_not_full_issue'
    assert git('rev-parse','HEAD')==HEAD and not git('status','--porcelain') and sources()==report['beforeSource']
    assert sha(PROPOSAL/'receipt.json')==report['proposalReceiptSha256']
    for name in ['candidate_asset.rs','asset_tests.rs','proposal.patch']:
        assert sha(PROPOSAL/name)==proposal['hashes'][name],name
    assert sha(PROPOSAL/'completion-document.md')==report['proposalDocumentSha256']
    assert (PROPOSAL/'original_asset.rs').read_bytes()==(WORK/'crates/motion-host/src/tracking/asset.rs').read_bytes()
    subprocess.run(['git','apply','--check',str(PROPOSAL/'proposal.patch')],cwd=WORK,check=True)
    report['status']='applying';save()
    for name in ['asset.rs','asset_tests.rs']:
        destination=WORK/'crates/motion-host/src/tracking'/name
        (OUT/f'before-{name}').write_bytes(destination.read_bytes())
        destination.write_bytes((PROPOSAL/('candidate_asset.rs' if name=='asset.rs' else name)).read_bytes())
    document=WORK/'engineering/validation/tracking88-plane-condition-current.md'
    assert not document.exists()
    document.write_bytes((PROPOSAL/'completion-document.md').read_bytes())
    report['source']=sources();report['status']='running';save()
    env=os.environ.copy();env.pop('MOTION_LOG',None)
    env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
        CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',
        PYTHONPATH=str(ROOT/'.tools/build-validation-python'))
    for name,command in [
        ('host-check',['cargo','check','-p','motion-host','--locked','--offline']),
        ('tracking-tests',['cargo','test','-p','motion-host','--lib','tracking::','--locked','--offline','--','--test-threads=1']),
    ]:
        step=dict(name=name,command=command,startedUtc=now());report['steps'].append(step)
        with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
            process=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
            step['pid']=process.pid;save();step['exitCode']=process.wait()
        step['completedUtc']=now();save()
        assert step['exitCode']==0,f'{name} actual failure retained; no retry or auto rollback'
    log=(OUT/'tracking-tests.stdout.log').read_text(encoding='utf-8',errors='replace')
    counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
    assert len(counts)==1 and tuple(map(int,counts[0]))==(47,0,0)
    assert git('rev-parse','HEAD')==HEAD and sources()==report['source'],'source changed during real host test'
    subprocess.run(['git','diff','--check'],cwd=WORK,check=True)
    report['totals']=dict(passed=47,failed=0,ignored=0)
    report['status']='accepted_host_plane_condition_correction_not_full_issue'
except BaseException as cause:
    report['status']='failed';report['failure']=repr(cause);raise
finally:
    if handle: kernel.CloseHandle(handle)
    report['completedUtc']=now();save()
