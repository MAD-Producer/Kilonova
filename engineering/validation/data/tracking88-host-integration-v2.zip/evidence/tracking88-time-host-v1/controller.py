"""Integrate exact temporal lookup only after the earlier source is released."""
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking88-pose'
OUT = ROOT / 'artifacts/pr-queue/tracking88-time-host-v1'
PROPOSAL = ROOT / 'artifacts/pr-queue/tracking88-time-mapping-v1'
PARENT = 38588
HEAD = 'cd770f5b93c0af2c023db82be2e66809ce6fb8c9'

def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def sources():
    return {name: sha(WORK / name) for name in git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
            if name and name.endswith(('.rs', '.toml', '.lock', '.wgsl', '.json', '.md', '.py', '.yml', '.yaml'))}

OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='queued', controllerPid=os.getpid(), startedUtc=now(), steps=[],
              limits='Exact source PTS math/lookup only. No project fps, tracking interpolation, rendered footage or full issue acceptance. No original assertion or #82 P95 criterion changes.')
def save():
    p = OUT / 'exit.next.json'
    p.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    os.replace(p, OUT / 'exit.json')

save()
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
handle = None
try:
    assert git('rev-parse', 'HEAD') == HEAD
    proposal = json.loads((PROPOSAL / 'receipt.json').read_text())
    assert proposal['status'] == 'accepted_direct_cpu_time_candidate_not_applied_or_host_validated'
    assert proposal['totals'] == dict(passed=56, failed=0, ignored=0)
    assert proposal['originalTestsUnchanged'] == 47
    report['proposalHashes'] = {name: sha(PROPOSAL / name) for name in
                                ['time.rs', 'time_tests.rs', 'completion-document.md', 'receipt.json', 'proposal.patch']}
    for name in ['time.rs', 'time_tests.rs']:
        assert report['proposalHashes'][name] == proposal['hashes'][name]
        assert not (WORK / 'crates/motion-host/src/tracking' / name).exists()
    report['originalModuleSha256'] = sha(WORK / 'crates/motion-host/src/tracking.rs')
    handle = kernel.OpenProcess(0x00100000, False, PARENT)
    if not handle: raise ctypes.WinError(ctypes.get_last_error())
    assert kernel.WaitForSingleObject(handle, 0) == 258, 'expected preceding process live'
    report['parent'] = dict(pid=PARENT, handleCapturedLive=True, receipt='tracking88-plane-host-v1')
    save()
    print(json.dumps(dict(queuedBehind=PARENT)), flush=True)
    while True:
        state = kernel.WaitForSingleObject(handle, 1000)
        if state == 0: break
        if state != 258: raise ctypes.WinError(ctypes.get_last_error())
    kernel.CloseHandle(handle)
    handle = None
    parent = json.loads((ROOT / 'artifacts/pr-queue/tracking88-plane-host-v1/exit.json').read_text())
    assert parent.get('completedUtc') and parent['status'] == 'accepted_host_plane_condition_correction_not_full_issue'
    assert git('rev-parse', 'HEAD') == HEAD and sources() == parent['source']
    assert sha(WORK / 'crates/motion-host/src/tracking.rs') == report['originalModuleSha256']
    for name, digest in report['proposalHashes'].items():
        assert sha(PROPOSAL / name) == digest, name
    subprocess.run(['git', 'apply', '--check', str(PROPOSAL / 'proposal.patch')], cwd=WORK, check=True)
    report['status'] = 'applying'
    save()
    for name in ['time.rs', 'time_tests.rs']:
        destination = WORK / 'crates/motion-host/src/tracking' / name
        assert not destination.exists()
        destination.write_bytes((PROPOSAL / name).read_bytes())
    module = WORK / 'crates/motion-host/src/tracking.rs'
    (OUT / 'before-tracking.rs').write_bytes(module.read_bytes())
    module.write_bytes(module.read_bytes() + b'pub mod time;\n')
    document = WORK / 'engineering/validation/tracking88-time-mapping-current.md'
    assert not document.exists()
    document.write_bytes((PROPOSAL / 'completion-document.md').read_bytes())
    report.update(status='running', source=sources(), head=HEAD)
    save()
    env = os.environ.copy()
    env.pop('MOTION_LOG', None)
    env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'),
               CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', RUST_BACKTRACE='full',
               PYTHONPATH=str(ROOT / '.tools/build-validation-python'), TEMP=str(ROOT / 'target/ci-policy-validation-tmp'), TMP=str(ROOT / 'target/ci-policy-validation-tmp'))
    for name, command in [
        ('host-check', ['cargo', 'check', '-p', 'motion-host', '--locked', '--offline']),
        ('tracking-tests', ['cargo', 'test', '-p', 'motion-host', '--lib', 'tracking::', '--locked', '--offline', '--', '--test-threads=1']),
    ]:
        step = dict(name=name, command=command, startedUtc=now())
        report['steps'].append(step)
        with (OUT / f'{name}.stdout.log').open('wb') as stdout, (OUT / f'{name}.stderr.log').open('wb') as stderr:
            process = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
            step['pid'] = process.pid
            save()
            step['exitCode'] = process.wait()
        step['completedUtc'] = now()
        save()
        assert step['exitCode'] == 0, f'{name} actual failure retained; no retry or rollback'
    log = (OUT / 'tracking-tests.stdout.log').read_text(encoding='utf-8', errors='replace')
    counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    assert counts == [('56', '0', '0')], counts
    assert git('rev-parse', 'HEAD') == HEAD and sources() == report['source']
    subprocess.run(['git', 'diff', '--check'], cwd=WORK, check=True)
    report.update(totals=dict(passed=56, failed=0, ignored=0), status='accepted_host_time_mapping_not_full_issue')
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    if handle: kernel.CloseHandle(handle)
    report['completedUtc'] = now()
    save()
