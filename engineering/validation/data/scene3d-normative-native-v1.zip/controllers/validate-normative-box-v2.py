from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, shutil

root = Path('E:/Dev/aem')
work = root / '.worktrees/native-camera-dof'
probe = root / '.tools/scene87-normative-render'
fixtures = root / '.tools/gltf-scene87-fixtures'
prior = json.loads((root / 'artifacts/pr-queue/native-camera-dof-regression-v2/accepted.json').read_text(encoding='utf-8'))
assert prior['sourceUnchanged'] and prior['unexecutedIgnored'] == 0
for path, sha in prior['source'].items():
    assert hashlib.sha256((work/path).read_bytes()).hexdigest() == sha, path
out = root / 'artifacts/pr-queue/normative-box-native-v2'
out.mkdir(exist_ok=False)
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1')
env.pop('MOTION_LOG', None)
manifest = json.loads((fixtures/'manifest.json').read_text(encoding='utf-8'))
assert manifest['revision'] == '8f492390ddc7a2ae221a1369ef560589cf8c70fb'
for record in manifest['files']:
    data = (fixtures/record['path']).read_bytes()
    assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
report = dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),
              inheritedSource=prior['source'], fixtureManifest=manifest, steps=[])
paths = [probe/'Cargo.toml', probe/'src/main.rs', probe/'src/skin.rs', root/'.tools/issue-closure-review/check-normative-box-v1.py', Path(__file__)]
report['toolSource'] = {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
def step(name, command):
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as so, (out/(name+'.stderr.log')).open('wb') as se:
        code = subprocess.run(command,cwd=work,env=env,stdout=so,stderr=se).returncode
    row = dict(name=name, command=[str(c) for c in command], exitCode=code)
    report['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    assert code == 0, row
shutil.copyfile(work/'Cargo.lock',probe/'Cargo.lock')
step('lock',['cargo','metadata','--manifest-path',str(probe/'Cargo.toml'),'--format-version','1','--offline'])
report['toolLockSha256'] = hashlib.sha256((probe/'Cargo.lock').read_bytes()).hexdigest()
step('build',['cargo','build','--manifest-path',str(probe/'Cargo.toml'),'--locked','--offline'])
binary = root/'target/gltf-animation87-contract/debug/motion-scene87-normative-render.exe'
report['binarySha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
step('native',[str(binary),str(fixtures/'Models/BoxVertexColors/glTF/BoxVertexColors.gltf'),str(out/'native')])
assert not (out/'native.stdout.log').read_bytes(), 'unexpected stdout'
step('independent-reference',['python',str(root/'.tools/issue-closure-review/check-normative-box-v1.py'),str(out/'native')])
native = json.loads((out/'native/native.json').read_text())
reference = json.loads((out/'native/independent-reference.json').read_text())
assert len(native['formats']) == len(reference['formats']) == 4
assert all(f['frozenPixelsExact'] and f['triangles'] == 12 for f in native['formats'])
for path,sha in prior['source'].items():
    assert hashlib.sha256((work/path).read_bytes()).hexdigest() == sha,path
report.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=True,native=native,reference=reference,
              scope='Unmodified pinned default-metal vertex-colored Box; independent source/coordinate/rough-metal pixels and exact frozen restore, not complete normative skin/alpha acceptance')
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,scope=report['scope'])),flush=True)
