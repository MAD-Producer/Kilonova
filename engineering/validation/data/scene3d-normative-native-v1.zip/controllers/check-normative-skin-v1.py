"""Raw-source two-joint LBS silhouette reference, independent of the importer."""
from pathlib import Path
import hashlib
import json
import math
import struct
import sys

fixtures = Path('E:/Dev/aem/.tools/gltf-scene87-normative-extra')
out = Path(sys.argv[1])
manifest = json.loads((fixtures/'manifest.json').read_text(encoding='utf-8'))
assert manifest['revision'] == '8f492390ddc7a2ae221a1369ef560589cf8c70fb'
for record in manifest['files']:
    data = (fixtures/record['path']).read_bytes()
    assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
folder = fixtures/'Models/SimpleSkin/glTF'
doc = json.loads((folder/'SimpleSkin.gltf').read_text(encoding='utf-8'))
buffers = [(folder/b['uri']).read_bytes() for b in doc['buffers']]

def accessor(index):
    a = doc['accessors'][index]
    v = doc['bufferViews'][a['bufferView']]
    count = {'SCALAR':1,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
    fmt = '<' + {5123:'H',5126:'f'}[a['componentType']] * count
    base = a.get('byteOffset',0) + v.get('byteOffset',0)
    stride = v.get('byteStride',struct.calcsize(fmt))
    return [struct.unpack_from(fmt,buffers[v['buffer']],base+k*stride) for k in range(a['count'])]

primitive = doc['meshes'][0]['primitives'][0]
positions = accessor(primitive['attributes']['POSITION'])
joints = accessor(primitive['attributes']['JOINTS_0'])
weights = accessor(primitive['attributes']['WEIGHTS_0'])
indices = [i[0] for i in accessor(primitive['indices'])]
skin = doc['skins'][0]
assert skin['joints'] == [1,2]
identity = (1.,0.,0.,0.,0.,1.,0.,0.,0.,0.,1.,0.,0.,0.,0.,1.)
inverse = accessor(skin['inverseBindMatrices'])
assert inverse[0] == identity
assert inverse[1] == identity[:13] + (-1.,0.,1.)
assert doc['nodes'] == [{'skin':0,'mesh':0},{'children':[2]},
                        {'translation':[0.,1.,0.],'rotation':[0.,0.,0.,1.]}]
channel = doc['animations'][0]['channels'][0]
assert channel['target'] == {'node':2,'path':'rotation'}
sampler = doc['animations'][0]['samplers'][channel['sampler']]
assert sampler['interpolation'] == 'LINEAR'
times = [v[0] for v in accessor(sampler['input'])]
rotations = accessor(sampler['output'])
assert all(q[0] == q[1] == 0 and q[3] > 0 for q in rotations)
angles = [2*math.atan2(q[2],q[3]) for q in rotations]

def vertices(seconds):
    k = next((i for i in range(len(times)-1) if times[i] <= seconds <= times[i+1]),None)
    assert k is not None
    f = (seconds-times[k])/(times[k+1]-times[k])
    # All source rotations lie on the Z axis within the same quaternion arc.
    # Spherical interpolation is exactly linear interpolation of this angle.
    angle = angles[k]*(1-f) + angles[k+1]*f
    c,s = math.cos(angle),math.sin(angle)
    result=[]
    for p,js,ws in zip(positions,joints,weights):
        assert abs(sum(ws)-1) < 1e-6 and all(j in (0,1) for j in js)
        second = (c*p[0]-s*(p[1]-1),s*p[0]+c*(p[1]-1)+1,p[2])
        result.append(tuple(sum(w*(p if j==0 else second)[ch] for j,w in zip(js,ws))/sum(ws) for ch in range(3)))
    return result

size=129
def silhouette(points):
    result=[]
    for py in range(size):
        y=1+(1-2*(py+0.5)/size)*1.4
        for px in range(size):
            x=(2*(px+0.5)/size-1)*1.4
            hit=False
            for k in range(0,len(indices),3):
                a,b,c=[points[i] for i in indices[k:k+3]]
                cross=lambda p,q,r:(q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
                signs=[cross(a,b,(x,y)),cross(b,c,(x,y)),cross(c,a,(x,y))]
                if all(v>=0 for v in signs) or all(v<=0 for v in signs):
                    hit=True
                    break
            result.append(hit)
    return result

def interior(mask):
    # Exclude exactly two pixel rows around the union silhouette, independently
    # of any GPU output, to avoid the raster top-left edge convention.
    return [y*size+x for y in range(2,size-2) for x in range(2,size-2)
            if all(mask[(y+dy)*size+x+dx] == mask[y*size+x] for dy in range(-2,3) for dx in range(-2,3))]

native=json.loads((out/'native.json').read_text(encoding='utf-8'))
assert native['size']==size and len(native['frames'])==16
bind=silhouette(vertices(0))
report=dict(fixtureRevision=manifest['revision'],oracle='Raw weights, joints, inverse binds and normalized Z-axis quaternion interpolation; independent triangle silhouette',frames=[])
for frame in native['frames']:
    assert frame['triangles']==8 and frame['deformationBytes']>0 and frame['frozenPixelsExact']
    precision=frame['precision']
    data=(out/frame['file']).read_bytes()
    if precision=='Unorm8':
        alpha=[data[k+3]/255 for k in range(0,len(data),4)]
    else:
        code={'Unorm16':'H','Float16':'e','Float32':'f'}[precision]
        alpha=[p[3]/65535 if precision=='Unorm16' else p[3] for p in struct.iter_unpack('<4'+code,data)]
    assert len(alpha)==size*size
    expected=silhouette(vertices(frame['seconds']))
    checked=interior(expected)
    assert sum(expected)>1000 and len(checked)>10000
    errors=[i for i in checked if abs(alpha[i]-int(expected[i]))>1e-6]
    assert not errors,(precision,frame['seconds'],len(errors),errors[:8])
    changed=sum(expected[i]!=bind[i] for i in checked)
    if frame['seconds']:
        assert changed>200,('bind pose negative control failed',frame,changed)
    report['frames'].append(dict(precision=precision,seconds=frame['seconds'],checkedPixels=len(checked),coveredPixels=sum(expected),bindPoseMismatchPixels=changed))
(out/'independent-reference.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report),flush=True)
