"""Fetch only pinned, independently licensed public normative evaluation files."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import urllib.request

root = Path('E:/Dev/aem/.tools/gltf-scene87-normative-extra')
revision = '8f492390ddc7a2ae221a1369ef560589cf8c70fb'
names = {
    'SimpleSkin': ['SimpleSkin.gltf', 'SimpleSkin_animation.bin', 'SimpleSkin_geometry.bin',
                   'SimpleSkin_inverseBindMatrices.bin', 'SimpleSkin_skinningData.bin'],
    'AlphaBlendModeTest': ['AlphaBlendModeTest.gltf', 'AlphaBlendModeTest.bin', 'AlphaBlendLabels.png',
                         'MatBed_baseColor.jpg', 'MatBed_normal.jpg', 'MatBed_occlusionRoughnessMetallic.jpg'],
}
paths = [f'Models/{model}/{name}' for model, files in names.items()
         for name in ['LICENSE.md', 'metadata.json'] + ['glTF/' + n for n in files]]

def download(path):
    url = f'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/{revision}/{path}'
    target = root/path
    if target.exists():
        data = target.read_bytes()
    else:
        with urllib.request.urlopen(url, timeout=60) as response:
            data = response.read(8 << 20)
            assert not response.read(1), 'evaluation file too large'
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    return dict(path=path, url=url, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    records = list(executor.map(download, paths))
manifest = dict(repository='https://github.com/KhronosGroup/glTF-Sample-Assets', revision=revision,
                modification='Unmodified external evaluation only; no source asset copied into product', files=records)
(root/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
for name in names:
    print(name)
    print((root/f'Models/{name}/LICENSE.md').read_text(encoding='utf-8'))
    print((root/f'Models/{name}/metadata.json').read_text(encoding='utf-8'))
