"""Independent source-buffer and closed-form rough-metal oracle, not shader replay."""
from pathlib import Path
import hashlib, json, math, struct, sys

root = Path('E:/Dev/aem')
fixtures = root / '.tools/gltf-scene87-fixtures'
out = Path(sys.argv[1])
manifest = json.loads((fixtures / 'manifest.json').read_text(encoding='utf-8'))
assert manifest['revision'] == '8f492390ddc7a2ae221a1369ef560589cf8c70fb'
for record in manifest['files']:
    data = (fixtures / record['path']).read_bytes()
    assert len(data) == record['bytes']
    assert hashlib.sha256(data).hexdigest() == record['sha256']
folder = fixtures / 'Models/BoxVertexColors/glTF'
doc = json.loads((folder / 'BoxVertexColors.gltf').read_text())
assert doc['nodes'] == [{'mesh': 0}]
assert 'materials' not in doc  # Normative default: base white, metallic=roughness=1.
buffers = [(folder / b['uri']).read_bytes() for b in doc['buffers']]
def accessor(index):
    a = doc['accessors'][index]; v = doc['bufferViews'][a['bufferView']]
    shape = {'SCALAR': 1, 'VEC3': 3}[a['type']]
    code = {5123: 'H', 5126: 'f'}[a['componentType']]
    fmt = '<' + code * shape
    base = a.get('byteOffset', 0) + v.get('byteOffset', 0)
    stride = v.get('byteStride', struct.calcsize(fmt))
    return [struct.unpack_from(fmt, buffers[v['buffer']], base + k * stride) for k in range(a['count'])]
primitive = doc['meshes'][0]['primitives'][0]
positions = accessor(primitive['attributes']['POSITION'])
normals = accessor(primitive['attributes']['NORMAL'])
colors = accessor(primitive['attributes']['COLOR_0'])
indices = [i[0] for i in accessor(primitive['indices'])]
front = []
for k in range(0, len(indices), 3):
    tri = indices[k:k+3]
    if all(positions[i][2] == 1 and normals[i] == (0, 0, 1) for i in tri):
        front.append(tri)
assert len(front) == 2 and len(indices) == 36
size = 129
def source_color(x, y):
    for tri in front:
        a, b, c = [positions[i] for i in tri]
        den = (b[1]-c[1])*(a[0]-c[0]) + (c[0]-b[0])*(a[1]-c[1])
        u = ((b[1]-c[1])*(x-c[0]) + (c[0]-b[0])*(y-c[1])) / den
        v = ((c[1]-a[1])*(x-c[0]) + (a[0]-c[0])*(y-c[1])) / den
        weights = (u, v, 1-u-v)
        if min(weights) > 0.025:
            return [sum(weights[k] * colors[tri[k]][ch] for k in range(3)) for ch in range(3)]
    return None
def oracle(x, y):
    color = source_color(x, y)
    if color is None:
        return None
    # Default metal at maximum roughness, front normal and unit axial light:
    # GGX D=1/pi; correlated Smith V=1/[2(1+Nv)]; no diffuse term.
    view = (0.5-x, 0.5-y, 3.)
    length = math.sqrt(sum(v*v for v in view)); nv = view[2]/length
    vh = math.sqrt((1+nv)/2)
    schlick = (1-vh)**5
    return [(c+(1-c)*schlick)/(2*math.pi*(1+nv)) for c in color] + [1.]
def decode(data, precision):
    if precision == 'Unorm8':
        return [tuple(v/255 if ch == 3 else v/255/12.92 if v/255 <= 0.04045 else ((v/255+0.055)/1.055)**2.4 for ch,v in enumerate(data[k:k+4])) for k in range(0,len(data),4)]
    code = {'Unorm16':'H','Float16':'e','Float32':'f'}[precision]
    values = list(struct.iter_unpack('<4'+code, data))
    return [tuple(v/65535 for v in p) for p in values] if precision == 'Unorm16' else values
report = {'fixtureRevision': manifest['revision'], 'oracle': 'Independent accessor decoding and closed-form maximum-roughness metal reflectance', 'formats': []}
for precision, tolerance in [('Unorm8', 0.002), ('Unorm16', 2e-5), ('Float16', 0.00012), ('Float32', 2e-6)]:
    pixels = decode((out / (precision+'.raw')).read_bytes(), precision)
    assert len(pixels) == size*size
    errors = []; controls = {'swappedChannels': 0, 'flippedY': 0, 'missingMaterial': 0}
    for py in range(size):
        for px in range(size):
            x = 0.5 + ((px+0.5)/size*2-1)*0.8
            y = 0.5 + (1-(py+0.5)/size*2)*0.8
            if not (0.04 < x < 0.96 and 0.04 < y < 0.96):
                continue
            expected = oracle(x,y)
            if expected is None:
                continue
            actual = pixels[py*size+px]
            errors.append(max(abs(a-b) for a,b in zip(actual,expected)))
            controls['swappedChannels'] += max(abs(a-b) for a,b in zip(actual, [expected[2],expected[1],expected[0],1])) > tolerance
            flipped = oracle(x,1-y)
            controls['flippedY'] += flipped is not None and max(abs(a-b) for a,b in zip(actual,flipped)) > tolerance
            controls['missingMaterial'] += max(abs(a) for a in actual[:3]) > tolerance
    assert len(errors) > 4000
    assert max(errors) <= tolerance, (precision, max(errors), tolerance)
    assert all(count > 1000 for count in controls.values()), controls
    # Clear control independently detects viewport, scale and silhouette drift.
    assert all(abs(c) < tolerance for c in pixels[0])
    report['formats'].append(dict(precision=precision, checkedInteriorPixels=len(errors), maxAbsoluteError=max(errors), tolerance=tolerance, rejectingControls=controls))
(out/'independent-reference.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report), flush=True)
