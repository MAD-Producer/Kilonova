"""Reuse the verified Box probe binary for the unmodified SimpleSkin sample."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

root = Path('E:/Dev/aem')
work = root/'.worktrees/native-camera-dof'
fixtures = root/'.tools/gltf-scene87-normative-extra'
prior = json.loads((root/'artifacts/pr-queue/normative-box-native-v2/accepted.json').read_text(encoding='utf-8'))
assert prior['sourceUnchanged']
for path,sha in prior['inheritedSource'].items():
    assert hashlib.sha256((work/path).read_bytes()).hexdigest()==sha,path
for path,sha in prior['toolSource'].items():
    assert hashlib.sha256((root/path).read_bytes()).hexdigest()==sha,path
binary = root/'target/gltf-animation87-contract/debug/motion-scene87-normative-render.exe'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==prior['binarySha256']
manifest = json.loads((fixtures/'manifest.json').read_text(encoding='utf-8'))
for record in manifest['files']:
    data = (fixtures/record['path']).read_bytes()
    assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
out = root/'artifacts/pr-queue/normative-skin-native-v2'
out.mkdir(exist_ok=False)
report = dict(head=prior['head'],binarySha256=prior['binarySha256'],inheritedSource=prior['inheritedSource'],
              inheritedToolSource=prior['toolSource'],fixtureManifest=manifest,steps=[])
oracle = root/'.tools/issue-closure-review/check-normative-skin-v1.py'
report['oracleSha256'] = hashlib.sha256(oracle.read_bytes()).hexdigest()
env = os.environ.copy()
env.pop('MOTION_LOG',None)
for name,command in [
    ('native',[str(binary),str(fixtures/'Models/SimpleSkin/glTF/SimpleSkin.gltf'),str(out/'native')]),
    ('independent-reference',['python',str(oracle),str(out/'native')]),
]:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as so,(out/(name+'.stderr.log')).open('wb') as se:
        code = subprocess.run(command,cwd=work,env=env,stdout=so,stderr=se,timeout=600).returncode
    report['steps'].append(dict(name=name,command=command,exitCode=code))
    (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    assert code==0,report['steps'][-1]
assert not (out/'native.stdout.log').read_bytes()
reference = json.loads((out/'native/independent-reference.json').read_text(encoding='utf-8'))
assert len(reference['frames'])==16
for path,sha in prior['inheritedSource'].items():
    assert hashlib.sha256((work/path).read_bytes()).hexdigest()==sha,path
report.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=True,reference=reference,
              scope='Unmodified pinned SimpleSkin; four times including quaternion interpolation, four native precisions, independent LBS silhouette and exact frozen restore; not full material/alpha comparison')
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,frames=len(reference['frames']))),flush=True)
