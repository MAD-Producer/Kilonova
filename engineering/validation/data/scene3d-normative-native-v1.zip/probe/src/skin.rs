//! Unmodified pinned SimpleSkin, with independent source-based silhouette oracle.
use super::*;
pub fn run(input: &std::path::Path, out: &std::path::Path) {
    let source = fs::read(input).unwrap();
    let context = ImportContext {
        request: 87005,
        source: 87,
    };
    let scene = motion_scene::import(
        context,
        &source,
        &mut DirectoryResolver::new(input.parent().unwrap()).unwrap(),
        &Default::default(),
    )
    .unwrap();
    let frozen = scene.freeze(&source, 128 << 20).unwrap();
    let restored =
        motion_scene::import_frozen(context, &frozen, 128 << 20, &Default::default()).unwrap();
    assert_eq!(scene, restored);
    let eye = Vec3::new(0., 1., 4.);
    let camera = motion_model::CameraPose {
        eye,
        target: Vec3::new(0., 1., 0.),
        projection: motion_model::ProjectionKind::Orthographic,
        view_projection: Mat4::orthographic_rh(-1.4, 1.4, -1.4, 1.4, 0.1, 10.)
            * Mat4::look_at_rh(eye, Vec3::new(0., 1., 0.), Vec3::Y),
    };
    let lights = [SceneLight::Directional {
        direction: [0., 0., -1.],
        color: [1.; 3],
        intensity: 1.,
    }];
    let request = SceneRequest {
        request: 87006,
        source: 87,
    };
    let mut reports = Vec::new();
    use ChannelPrecision::*;
    for precision in [Unorm8, Unorm16, Float16, Float32] {
        let renderer = pollster::block_on(Renderer::headless_with_working_precision(
            precision,
            Default::default(),
        ))
        .unwrap();
        let target = renderer.render_target(SIZE, SIZE).unwrap();
        for seconds in [0., 0.75, 1., 4.] {
            let mut frame = SceneFrame::new(camera, scene.default_scene().unwrap(), 1.);
            frame.lights = &lights;
            frame.ambient = [0.; 3];
            frame.animation = Some(motion_scene::AnimationSample {
                animation: 0,
                seconds,
            });
            let mut original = GpuScene::upload(
                &renderer,
                request,
                Arc::new(scene.clone()),
                Default::default(),
            )
            .unwrap();
            let stats = original.draw(&renderer, request, &target, &frame).unwrap();
            let expected = raw(&renderer, &target, precision);
            drop(original);
            let mut replay = GpuScene::upload(
                &renderer,
                request,
                Arc::new(restored.clone()),
                Default::default(),
            )
            .unwrap();
            replay.draw(&renderer, request, &target, &frame).unwrap();
            let actual = raw(&renderer, &target, precision);
            assert_eq!(
                actual, expected,
                "frozen SimpleSkin pixels changed {precision:?}/{seconds}"
            );
            let name = format!("{precision:?}-{seconds:.2}.raw");
            fs::write(out.join(&name), &actual).unwrap();
            reports.push(serde_json::json!({"precision":format!("{precision:?}"),"seconds":seconds,"file":name,
                "triangles":stats.triangles,"deformationBytes":stats.deformation_bytes,"frozenPixelsExact":true,
                "adapter":format!("{:?}",renderer.adapter_info)}));
        }
    }
    fs::write(
        out.join("native.json"),
        serde_json::to_vec_pretty(
            &serde_json::json!({"size":SIZE,"unmodifiedInput":input,"frames":reports}),
        )
        .unwrap(),
    )
    .unwrap();
    logging::flush();
}
