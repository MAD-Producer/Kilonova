//! External validation only. The unmodified upstream CC0 model is never bundled.
#[path = "../../../.worktrees/native-camera-dof/desktop/app/src/logging.rs"]
mod logging;
// This standalone probe has no Engine or fabricated worker request state.
mod engine {
    pub fn current_command() -> Option<(u64, &'static str, std::time::Duration)> {
        None
    }
}
mod skin;
use glam::{Mat4, Vec3};
use motion_effects::{
    image_contract::{ChannelPrecision, ImageContract, ImageMeaning},
    AlphaMode, WorkingSpace,
};
use motion_render::{
    scene_gpu::{GpuScene, SceneFrame, SceneLight, SceneRequest},
    RenderTarget, Renderer,
};
use motion_scene::{DirectoryResolver, ImportContext};
use std::{
    fs,
    path::PathBuf,
    sync::{mpsc, Arc},
};

const SIZE: u32 = 129;
fn raw(renderer: &Renderer, target: &RenderTarget, precision: ChannelPrecision) -> Vec<u8> {
    let contract = ImageContract::new(
        ImageMeaning::Color {
            space: WorkingSpace::Linear,
            alpha: AlphaMode::Premultiplied,
        },
        precision,
    );
    let row = SIZE * contract.preferred_storage().unwrap().bytes_per_pixel() as u32;
    let stride =
        row.div_ceil(wgpu::COPY_BYTES_PER_ROW_ALIGNMENT) * wgpu::COPY_BYTES_PER_ROW_ALIGNMENT;
    let buffer = renderer
        .allocation_context()
        .buffer(&wgpu::BufferDescriptor {
            label: Some("normative original/frozen format-preserving output"),
            size: u64::from(stride * SIZE),
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        })
        .unwrap();
    let mut encoder = renderer
        .allocation_command_encoder(&Default::default())
        .unwrap();
    encoder.copy_texture_to_buffer(
        target.view.texture().as_image_copy(),
        wgpu::TexelCopyBufferInfo {
            buffer: &buffer,
            layout: wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(stride),
                rows_per_image: Some(SIZE),
            },
        },
        wgpu::Extent3d {
            width: SIZE,
            height: SIZE,
            depth_or_array_layers: 1,
        },
    );
    renderer.submit_allocated(encoder.finish(), |_| {}).unwrap();
    let (send, recv) = mpsc::sync_channel(1);
    buffer.slice(..).map_async(wgpu::MapMode::Read, move |r| {
        send.send(r).unwrap();
    });
    renderer
        .device
        .poll(wgpu::PollType::wait_indefinitely())
        .unwrap();
    recv.recv().unwrap().unwrap();
    let mapped = buffer.slice(..).get_mapped_range().unwrap();
    let bytes = mapped
        .chunks_exact(stride as usize)
        .flat_map(|r| r[..row as usize].iter().copied())
        .collect();
    drop(mapped);
    buffer.unmap();
    bytes
}
fn main() {
    let input = PathBuf::from(std::env::args_os().nth(1).expect("unmodified model path"));
    let out = PathBuf::from(std::env::args_os().nth(2).expect("output path"));
    fs::create_dir_all(&out).unwrap();
    let _guard = logging::init(out.join("logs")).unwrap();
    log::info!("start #87001 normative_render source={}", input.display());
    if input.file_stem().is_some_and(|name| name == "SimpleSkin") {
        skin::run(&input, &out);
        return;
    }
    let source = fs::read(&input).unwrap();
    let context = ImportContext {
        request: 87001,
        source: 87,
    };
    let scene = motion_scene::import(
        context,
        &source,
        &mut DirectoryResolver::new(input.parent().unwrap()).unwrap(),
        &Default::default(),
    )
    .unwrap();
    let frozen = scene.freeze(&source, 128 << 20).unwrap();
    let restored =
        motion_scene::import_frozen(context, &frozen, 128 << 20, &Default::default()).unwrap();
    assert_eq!(scene, restored);
    let eye = Vec3::new(0.5, 0.5, 4.);
    let camera = motion_model::CameraPose {
        eye,
        target: Vec3::new(0.5, 0.5, 0.5),
        projection: motion_model::ProjectionKind::Orthographic,
        view_projection: Mat4::orthographic_rh(-0.8, 0.8, -0.8, 0.8, 0.1, 10.)
            * Mat4::look_at_rh(eye, Vec3::new(0.5, 0.5, 0.5), Vec3::Y),
    };
    let mut reports = Vec::new();
    use ChannelPrecision::*;
    for precision in [Unorm8, Unorm16, Float16, Float32] {
        let renderer = pollster::block_on(Renderer::headless_with_working_precision(
            precision,
            Default::default(),
        ))
        .unwrap();
        let target = renderer.render_target(SIZE, SIZE).unwrap();
        let request = SceneRequest {
            request: 87002,
            source: 87,
        };
        let lights = [SceneLight::Directional {
            direction: [0., 0., -1.],
            color: [1.; 3],
            intensity: 1.,
        }];
        let mut frame = SceneFrame::new(camera, scene.default_scene().unwrap(), 1.);
        frame.lights = &lights;
        frame.ambient = [0.; 3];
        let mut original = GpuScene::upload(
            &renderer,
            request,
            Arc::new(scene.clone()),
            Default::default(),
        )
        .unwrap();
        let stats = original.draw(&renderer, request, &target, &frame).unwrap();
        let expected = raw(&renderer, &target, precision);
        drop(original);
        let mut replay = GpuScene::upload(
            &renderer,
            request,
            Arc::new(restored.clone()),
            Default::default(),
        )
        .unwrap();
        replay.draw(&renderer, request, &target, &frame).unwrap();
        let actual = raw(&renderer, &target, precision);
        assert_eq!(
            actual, expected,
            "frozen normative pixels changed: {precision:?}"
        );
        fs::write(out.join(format!("{precision:?}.raw")), &actual).unwrap();
        reports.push(serde_json::json!({"precision":format!("{precision:?}"),"rawBytes":actual.len(),"draws":stats.draws,"triangles":stats.triangles,"frozenPixelsExact":true,"adapter":format!("{:?}",renderer.adapter_info)}));
    }
    fs::write(
        out.join("native.json"),
        serde_json::to_vec_pretty(
            &serde_json::json!({"size":SIZE,"unmodifiedInput":input,"formats":reports}),
        )
        .unwrap(),
    )
    .unwrap();
    logging::flush();
}
