from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json,os,re,time
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-import88'
out=root/'artifacts/pr-queue/clock85-model-core-current-v3';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
assert git('rev-parse','HEAD')=='2ca4e0a6eb2b3099e368843e98f476c5df9f8d32' and not git('status','--porcelain')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={n:sha(work/n) for n in git('ls-files','crates','desktop','Cargo.toml','Cargo.lock').splitlines() if (work/n).is_file() and n.endswith(('.rs','.wgsl','Cargo.toml','Cargo.lock'))}
metadata=json.loads(subprocess.check_output(['cargo','metadata','--no-deps','--format-version','1','--locked','--offline'],cwd=work))
packages=[p for p in metadata['packages'] if p['name'] in ['motion-model','motion-core']]
(out/'cargo-metadata.json').write_text(json.dumps(packages,indent=2)+'\n',encoding='utf-8')
command=['cargo','test','-p','motion-model','-p','motion-core','--no-fail-fast','--locked','--offline','--','--test-threads=1']
env=os.environ.copy();env.pop('MOTION_LOG',None)
r=dict(status='running',head=git('rev-parse','HEAD'),source=source,command=command,startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Complete model/core targets and doc tests on current parent, original ignores retained, no name filters or budget changes','CPU only, no Android or second GPU run. No claim that earlier CI scheduling failure is fixed'])
save=lambda:(out/'exit.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
try:
 with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
  p=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);r['cargoPid']=p.pid;save();r['exitCode']=p.wait()
 r['summaries']=re.findall(r'^test result: .+$',(out/'stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
 r['invocations']=re.findall(r'^\s*(?:Running|Doc-tests) .+$',(out/'stderr.log').read_text(encoding='utf-8',errors='replace'),re.M)
 r['sourceUnchanged']=all(sha(work/n)==h for n,h in source.items());save()
 assert r['exitCode']==0 and r['sourceUnchanged'] and r['summaries']
 assert all('0 failed;' in s and '0 filtered out;' in s for s in r['summaries'])
 r['status']='complete_selected_model_core_passed_current_parent'
except BaseException as cause:r.update(status='failed_original_outputs_retained',failure=repr(cause));raise
finally:r.update(elapsedSeconds=round(time.monotonic()-began,3),completedUtc=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({k:v for k,v in r.items() if k!='source'}),flush=True)
