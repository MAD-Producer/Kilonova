from pathlib import Path
import hashlib, json, re, zipfile, subprocess

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-import88'
out = root / 'artifacts/pr-queue/clock85-model-core-current-v4'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
r = json.loads((out / 'exit.json').read_text(encoding='utf-8'))
assert r['status'] == 'complete_selected_model_core_passed_current_parent'
assert r['exitCode'] == 0 and r['sourceUnchanged'] and r['completedUtc']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip() == r['head']
assert all(sha(work / n) == h for n, h in r['source'].items())
packages = json.loads((out / 'cargo-metadata.json').read_text(encoding='utf-8'))
expected = []
for p in packages:
    for t in p['targets']:
        if t['test']:
            expected.append((p['name'], t['name'], t['kind'][0]))
    if any(t['doctest'] for t in p['targets']):
        expected.append((p['name'], p['name'].replace('-', '_'), 'doc'))
summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', (out / 'stdout.log').read_text(encoding='utf-8'), re.M)
assert len(expected) == len(r['invocations']) == len(summaries), (len(expected), len(r['invocations']), len(summaries))
for package, name, kind in expected:
    assert any((f'Doc-tests {name}' if kind == 'doc' else f'{name.replace("-", "_")}-') in line for line in r['invocations']), (package, name, kind)
totals = [sum(int(s[i]) for s in summaries) for i in (1, 2, 3, 5)]
assert totals[1] == totals[3] == 0
audit = dict(status='complete_selected_model_core_passed', head=r['head'], passed=totals[0], failed=totals[1], originalIgnored=totals[2], filtered=totals[3], targets=len(expected), elapsedSeconds=r['elapsedSeconds'], command=r['command'], expectedTargets=expected, invocations=r['invocations'], limits=[
    'Complete selected model/core packages on frozen parent 2ca4, not whole workspace or subsequent main e8ea491e',
    'Original 20ms/100ms expression budgets and all assertions/ignores retained; no proof of original CI timeout root cause',
    'Attempt v1 stopped before tests, exit unknown. Attempts v2/v3 failed before tests with LNK1285 corrupt test PDBs; original receipts retained',
    'Specific diagnosed PDB and matching core test PDB family preserved reversibly with before/after hashes on E, no deletion; bulky PDB payloads remain private artifacts, hash manifests included',
    'No Android, GPU or default desktop test compiler acceptance claimed'])
(out / 'independent-target-audit.json').write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
entries = {}
for version in range(1, 5):
    prior = root / f'artifacts/pr-queue/clock85-model-core-current-v{version}'
    for p in prior.iterdir():
        if p.is_file() and p.suffix in ('.json', '.py', '.log'):
            entries[f'attempt-v{version}/{p.name}'] = p
    entries[f'environment/v{version}.ps1'] = root / f'.tools/issue-closure-review/run-clock85-model-core-current-v{version}.ps1'
entries['environment/publish.py'] = Path(__file__)
manifest = dict(audit=audit, entries={n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in entries.items()})
archive = work / 'engineering/validation/data/frame-rate85-model-core-complete-v4.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
    for n, p in entries.items():
        z.write(p, n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n, p in entries.items():
        assert hashlib.sha256(z.read(n)).hexdigest() == sha(p)
receipt = dict(audit=audit, archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=len(entries) + 1)
archive.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
(work / 'engineering/validation/frame-rate85-model-core-complete-current.md').write_text(f'''# Complete model/core runtime regression

Status: all {len(expected)} Cargo targets of the selected model/core packages,
including documentation tests, passed on frozen parent `{r['head']}`.
The actual command completed **{totals[0]} passed, zero failed,
{totals[2]} original ignored, zero filtered** in {r['elapsedSeconds']} seconds.
Actual invocations and summaries were matched against Cargo metadata.

The command was `cargo test -p motion-model -p motion-core --no-fail-fast
--locked --offline -- --test-threads=1`. No assertions, expression deadlines,
ignore declarations or name filters changed. This includes the new expression
interruption observations; one local pass does not identify the original CI
timeout cause or establish its repair. This gate covers neither subsequent
main `e8ea491e`, whole-workspace regression nor desktop default compiler faults.
Android is excluded.

The first attempt stopped before tests with its exit unknown. The second and
third attempts failed before tests with linker LNK1285 errors naming corrupt
test PDB files. Original outputs and receipts are retained without rewriting.
The named PDB and then the matching core test PDB family were moved reversibly
within E, with every before/after SHA-256 checked. No cache files were deleted.
The raw PDBs remain in private artifacts; the archive includes their exact
preservation manifests rather than the multi-gigabyte payloads. The fourth
attempt completed after that specific build-artifact repair, without a source
or test-policy change.

The [archive](data/frame-rate85-model-core-complete-v4.zip) retains all four
attempts, source closure, raw outputs, controllers, environment and target
audit. All members were read back and hash-verified; its
[receipt](data/frame-rate85-model-core-complete-v4.json) records scope and limits.
This is not completion of the 3D route or issues 85/86/88.
''', encoding='utf-8')
print(json.dumps(dict(passed=totals[0], originalIgnored=totals[2], targets=len(expected), archiveSha256=receipt['sha256'], bytes=receipt['bytes'], members=receipt['members'])))
