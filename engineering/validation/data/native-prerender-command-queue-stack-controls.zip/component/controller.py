import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT/'.worktrees/native-prerender-runtime'
OUT = ROOT/'artifacts/pr-queue/prerender-command-queue-stack-v1'
BASE = '380bbbb72eba919b47aaaa71536401687dacb4a9'
PRODUCTION = WORK/'desktop/app/src/engine.rs'
NAME = 'engine::queue_tests::channel_moves_a_compact_item_and_preserves_its_owned_command_reply'

def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()
def sources():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: hashlib.sha256((WORK/name).read_bytes()).hexdigest() for name in names
            if name and name.endswith(('.rs','.toml','.lock','.wgsl','.json','.yml','.yaml','.py','.md'))}

assert git('rev-parse','HEAD') == BASE
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
original = PRODUCTION.read_bytes()
source = sources()
report = dict(status='queued', controllerPid=os.getpid(), base=BASE, source=source, steps=[], startedUtc=now(),
    limits='Actual channel layout negative/positive and unchanged queue/diagnostics controls, followed by actual shared MCP startup. Original strict input P95 and native effect-search access violation remain unresolved. No thread stack increase, existing assertion change, Android, panels or source deletion.')

def save():
    pending = OUT/'exit.next.json'
    pending.write_text(json.dumps(report,indent=2),encoding='utf-8')
    os.replace(pending,OUT/'exit.json')

env = os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT/'owned-profile'), PYTHONPATH=str(ROOT/'.tools/build-validation-python'))
Path(env['LOCALAPPDATA']).mkdir()

def step(name,args,expected=None,negative=False):
    test_env=env.copy()
    test_env['MOTION_PRERENDER_INPUT_COMPLETION_REPORT']=str(OUT/f'{name}.report.json')
    report['activeStep']=dict(name=name,command=args,startedUtc=now());save()
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(args,cwd=WORK,env=test_env,stdout=stdout,stderr=stderr)
        report['activeStep']['pid']=child.pid;save();code=child.wait()
    report['activeStep'].update(exitCode=code,completedUtc=now());save()
    output=(OUT/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace')
    errors=(OUT/f'{name}.stderr.log').read_text(encoding='utf-8',errors='replace')
    counts=re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',output)
    if negative:
        passed=code!=0 and counts==[('0','1','0')] and 'the channel must not copy the large editor command on each mpsc stack frame' in output+errors
    else:
        passed=code==0 and (expected is None or counts==[(str(expected),'0','0')])
        if counts:passed=passed and all(int(c[1])==0 for c in counts) and any(int(c[0])>0 for c in counts)
    row=dict(name=name,command=args,exitCode=code,counts=counts,passed=passed,negativeControl=negative,
        startedUtc=report['activeStep']['startedUtc'],completedUtc=report['activeStep']['completedUtc'])
    report['steps'].append(row);save();print(json.dumps(row),flush=True)
    assert passed,f'{name} failed; inspect actual exit and logs before any later build'
    report.pop('activeStep',None);save()

candidate = PRODUCTION.read_bytes()
negative = subprocess.check_output(['git','show','HEAD:desktop/app/src/engine.rs'],cwd=WORK)
mutated = False
save()
try:
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
    kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.WaitForSingleObject.restype=wintypes.DWORD
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    handle=kernel.OpenProcess(0x100000,False,696)
    assert handle and kernel.WaitForSingleObject(handle,0)==258,'exact preceding native gate must be live'
    report['parent']=dict(pid=696,receipt='prerender-late-input-native-v5',handleCapturedLive=True);save()
    print(json.dumps(dict(queuedBehind=696)),flush=True)
    try:
        while True:
            state=kernel.WaitForSingleObject(handle,1000)
            if state==0:break
            assert state==258
    finally:kernel.CloseHandle(handle)
    previous=json.loads((ROOT/'artifacts/pr-queue/prerender-late-input-native-v5/exit.json').read_text(encoding='utf-8'))
    assert previous.get('completedUtc')
    report['parent']['terminal']={key:previous.get(key) for key in ['status','completedUtc']};save()
    assert previous['status']=='accepted_native_late_input_components_not_p95_acceptance','inspect preceding actual failure before further builds'
    assert git('rev-parse','HEAD')==BASE and sources()==source
    report.update(status='running_queue_stack_component_not_issue_acceptance',releasedUtc=now());save()
    for name in ['crates/motion-model/src/lib.rs','crates/motion-core/src/lib.rs','crates/motion-render/src/lib.rs','crates/motion-host/src/lib.rs','crates/motion-desktop-media/src/lib.rs','desktop/app/src/main.rs']:
        os.utime(WORK/name,None)
    desktop=['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--bin','motion-studio']
    PRODUCTION.write_bytes(negative);mutated=True
    step('original-queue-layout-negative',desktop+[NAME,'--','--exact','--nocapture','--test-threads=1'],negative=True)
    PRODUCTION.write_bytes(candidate);mutated=False
    step('compact-queue-positive',desktop+[NAME,'--','--exact','--nocapture','--test-threads=1'],expected=1)
    step('bounded-queue-regression',desktop+['engine::queue_tests::','--','--test-threads=1'])
    step('blocked-worker-observability',desktop+['diagnostics::tests::in_flight_and_queue_depth_track_a_blocked_worker','--','--exact','--test-threads=1'],expected=1)
    step('dispatch-lock-observability',desktop+['engine::fallback_tests::bounded_dispatch_and_shutdown_emit_after_releasing_the_flight_gate','--','--exact','--test-threads=1'],expected=1)
    step('prerender-runtime-regression',desktop+['engine::prerender::','--','--test-threads=1'])
    step('desktop-build',['cargo','build','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--bin','motion-studio'])
    (OUT/'shared-mcp').mkdir()
    step('shared-mcp',[sys.executable,'-c',"import sys; from pathlib import Path; sys.path.insert(0,'tools'); import ci_desktop; ci_desktop.verify_mcp(Path(sys.argv[1]),Path(sys.argv[2]))",str(ROOT/'target/gltf-animation87-contract/debug/motion-studio.exe'),str(OUT/'shared-mcp')])
    step('provenance',[sys.executable,'tools/validate_provenance.py'])
    step('tool-inventory',[sys.executable,'tools/validation_inventory.py'])
    step('whitespace',['git','diff','--check'])
    assert sources()==source
    report.update(status='accepted_compact_queue_and_native_mcp_component_not_p95_acceptance',completedUtc=now());save()
except BaseException as error:
    if mutated:
        PRODUCTION.write_bytes(candidate)
        report['restoredCandidateAfterNegative']=PRODUCTION.read_bytes()==candidate
    report.update(status='failed',failure=repr(error),completedUtc=now());save();raise
