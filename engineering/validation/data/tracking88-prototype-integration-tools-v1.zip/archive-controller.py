"""Archive the completed exact-source tools gate, including generated inputs."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,zipfile

ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/planar-tracker88'
OUT=ROOT/'artifacts/pr-queue/tracking88-prototype-integration-tools-v1'
DEST=WORK/'engineering/validation/data/tracking88-prototype-integration-tools-v1'
assert not DEST.with_suffix('.zip').exists()
receipt=json.loads((OUT/'exit.json').read_text())
assert receipt['status']=='complete_tools_and_actual_cv_gates_passed' and receipt['sourceUnchanged']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(WORK/name)==digest for name,digest in receipt['source'].items())
sources=[p for p in (WORK/'tools').rglob('*') if p.is_file() and p.suffix=='.py' and '__pycache__' not in p.parts]
sources.extend(WORK/name for name in ['tools/validation_inventory.json','ATTRIBUTION.md','NOTICE','PROVENANCE.md',
 'desktop/app/src/engine/tracking_prototype_surface_tests.rs',
 'desktop/app/src/engine/tracking_prototype_surface_oracle.rs',
 'desktop/app/src/engine/tracking_video_surface_tests.rs',
 'desktop/app/tests/fixtures/tracking-prototype/README.md'])
files={f'execution/{p.relative_to(OUT).as_posix()}':p for p in OUT.rglob('*') if p.is_file()}
files.update({f'sources/{p.relative_to(WORK).as_posix()}':p for p in sources})
files['archive-controller.py']=Path(__file__)
entries={name:dict(bytes=p.stat().st_size,sha256=sha(p)) for name,p in sorted(files.items())}
with zipfile.ZipFile(DEST.with_suffix('.zip'),'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,p in sorted(files.items()):archive.writestr(name,p.read_bytes())
with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
    assert set(archive.namelist())==set(entries)
    for name,row in entries.items():
        payload=archive.read(name)
        assert len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
manifest=dict(status='completed_execution_archived_and_readback_verified',
              createdUtc=datetime.now(timezone.utc).isoformat(),head=receipt['head'],
              main=receipt['main'],archive=DEST.with_suffix('.zip').name,
              bytes=DEST.with_suffix('.zip').stat().st_size,sha256=sha(DEST.with_suffix('.zip')),
              controls=dict(toolsPassed=123,toolsExistingSkipped=1,flowPassed=8),
              entries=entries,limits=receipt['limits']+[
                  'Includes fresh synthetic videos and measured solves; they are authored MIT test outputs, not photographs',
                  'Archived synthetic source has a fresh container identity; it does not replace the original frozen native fixture',
                  'Complete tools sources and native harness delta retained; full repository source is identified by the fixed integration commit',
                  'No native compilation/full workspace/cross-platform completion follows from these tools gates'])
DEST.with_suffix('.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in manifest.items() if k!='entries'}))
