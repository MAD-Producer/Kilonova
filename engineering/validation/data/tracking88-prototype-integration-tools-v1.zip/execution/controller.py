"""Fresh complete tools/CV gates on the fixed current-main integration."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,time,re

ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/planar-tracker88'
OUT=ROOT/'artifacts/pr-queue/tracking88-prototype-integration-tools-v1'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert head.startswith('81ea22aa')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK).strip()
names=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def identity():
    return {name:sha(WORK/name) for name in names if name.endswith(('.rs','.py','Cargo.toml'))
            or name in ('Cargo.lock','tools/validation_inventory.json','ATTRIBUTION.md','PROVENANCE.md','NOTICE')}
source=identity()
env=os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'):env.pop(name,None)
env.update(PYTHONDONTWRITEBYTECODE='1',TEMP=str(ROOT/'target/ci-policy-validation-tmp'),
           TMP=str(ROOT/'target/ci-policy-validation-tmp'))
runtime=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
steps=[
    ('provenance',[sys_executable:=os.sys.executable,'tools/validate_provenance.py']),
    ('inventory',[sys_executable,'tools/validation_inventory.py']),
    ('all-tools',[sys_executable,'-m','unittest','discover','-s','tools','-p','test_*.py','-v']),
    ('all-flow',[sys_executable,'tools/tracking/test_flow.py','-v']),
    ('actual-cli-synthetic',[sys_executable,'tools/tracking/validate_prototype.py',
        '--ffmpeg',str(runtime/'ffmpeg.exe'),'--ffprobe',str(runtime/'ffprobe.exe'),
        '--output',str(OUT/'synthetic')]),
    ('actual-cli-manual-absence',[sys_executable,'tools/tracking/validate_manual_absence.py',
        '--ffmpeg',str(runtime/'ffmpeg.exe'),'--ffprobe',str(runtime/'ffprobe.exe'),
        '--output',str(OUT/'manual-absence')]),
]
report=dict(status='running',head=head,main='26c1d2d2bc83c8073d85a200a7cc78cd6284d4f4',
            source=source,steps=[],startedUtc=datetime.now(timezone.utc).isoformat(),
            limits=['Fresh full tool discovery and complete optional CV controls, not desktop/workspace or real-video quality acceptance',
                    'Original assertions/gates unchanged; no adopted experimental tracker algorithm',
                    'All cache/temp/output remains on E; no source edits while these gates run'])
def save():
    pending=OUT/'exit.pending.json'
    pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    os.replace(pending,OUT/'exit.json')
save()
started=time.monotonic()
try:
    for phase,command in steps:
        row=dict(phase=phase,command=command)
        report['steps'].append(row)
        with (OUT/(phase+'.stdout.log')).open('wb') as stdout,(OUT/(phase+'.stderr.log')).open('wb') as stderr:
            process=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
            row['pid']=process.pid
            save()
            row['exitCode']=process.wait()
        text=(OUT/(phase+'.stderr.log')).read_text(encoding='utf-8',errors='replace')
        row['unittestSummary']=re.findall(r'^Ran \d+ tests? in [^\n]+|^OK[^\n]*|^FAILED[^\n]*',text,re.M)
        save()
        assert row['exitCode']==0,(phase,row['exitCode'])
    report['status']='complete_tools_and_actual_cv_gates_passed'
except BaseException as cause:
    report.update(status='failed_original_outputs_retained',failure=repr(cause))
    raise
finally:
    report.update(sourceUnchanged=identity()==source,elapsedSeconds=round(time.monotonic()-started,3),
                  completedUtc=datetime.now(timezone.utc).isoformat())
    save()
    print(json.dumps({k:v for k,v in report.items() if k!='source'}),flush=True)
assert report['sourceUnchanged']
