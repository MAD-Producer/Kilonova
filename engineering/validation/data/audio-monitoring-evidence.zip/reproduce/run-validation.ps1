$ErrorActionPreference = 'Stop'
. E:/Dev/aem/artifacts/multiple-camera-layers/env.ps1
$env:CARGO_TARGET_DIR = 'E:/Dev/aem/target/host-error-contract-verified'
$env:CARGO_BUILD_JOBS = '1'
$env:MOTION_AUDIO_MONITOR_ERROR_EVIDENCE = 'E:/Dev/aem/artifacts/pr-ci-followups/audio-monitor-frozen-errors'
$env:MOTION_AUDIO_MONITOR_EVIDENCE = 'E:/Dev/aem/artifacts/pr-ci-followups/audio-monitor-frozen-native'
$env:MOTION_AUDIO_PREVIEW_EVIDENCE = 'E:/Dev/aem/artifacts/pr-ci-followups/audio-monitor-frozen-device'
Set-Location E:/Dev/aem/.worktrees/audio-monitoring
$sourceCommit = (& git rev-parse HEAD).Trim()
$stages = @(
 @{Name='model';Args=@('test','-p','motion-core','--test','audio_levels','--locked','--offline')},
 @{Name='wave';Args=@('test','-p','motion-media','--lib','--locked','--offline','waveform_display','--','--nocapture')},
 @{Name='mix';Args=@('test','-p','motion-media','--test','audio_levels','--locked','--offline')},
 @{Name='audio';Args=@('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','audio_','--','--nocapture','--test-threads=1')},
 @{Name='playback';Args=@('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','playback','--','--nocapture','--test-threads=1')},
 @{Name='host';Args=@('test','-p','motion-host','--test','failure_boundaries','--locked','--offline','audio_','--','--nocapture','--test-threads=1')},
 @{Name='native';Args=@('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','native_audio_monitor','--','--ignored','--nocapture','--test-threads=1')},
 @{Name='device';Args=@('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','shell::audio_preview_tests::native::native_audio_preview_menu_and_device_clock_preserve_canvas_and_history','--','--exact','--ignored','--nocapture','--test-threads=1')},
 @{Name='build';Args=@('build','-p','motion-desktop','--features','ffmpeg','--locked','--offline')}
)
$results = @()
foreach ($stage in $stages) {
 if ((& git rev-parse HEAD).Trim() -ne $sourceCommit -or (& git status --porcelain)) { throw 'Frozen source changed during validation' }
 Write-Output ('START '+$stage.Name)
 $began = [DateTime]::UtcNow
 $arguments = $stage.Args
 $file = 'E:/Dev/aem/artifacts/pr-ci-followups/audio-monitor-frozen-'+$stage.Name+'.log'
 & cargo @arguments *> $file
 $code = $LASTEXITCODE
 $results += @{Name=$stage.Name;ExitCode=$code;Log=$file;Started=$began.ToString('o');Finished=[DateTime]::UtcNow.ToString('o');Args=$arguments}
 @{SourceCommit=$sourceCommit;Results=$results} | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 E:/Dev/aem/artifacts/pr-ci-followups/audio-monitor-frozen-results.json
 if ($code -ne 0) { Get-Content -LiteralPath $file -Tail 65; throw ('FAILED '+$stage.Name) }
 Get-Content -LiteralPath $file | Select-String 'test result:|Finished' | ForEach-Object { $_.Line }
}
Copy-Item -LiteralPath E:/Dev/aem/target/host-error-contract-verified/debug/motion-studio.exe -Destination E:/Dev/aem/artifacts/pr-ci-followups/audio-monitor-motion-studio.exe
& E:/Dev/aem/artifacts/pr-ci-followups/audio-monitor-motion-studio.exe --help *> E:/Dev/aem/artifacts/pr-ci-followups/audio-monitor-frozen-launch.log
if ($LASTEXITCODE -ne 0) { throw 'Built executable failed to launch' }
Write-Output 'VALIDATION COMPLETE'
