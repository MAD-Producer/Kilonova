from pathlib import Path
import hashlib, json, subprocess, zipfile, shutil
from PIL import Image, ImageOps, ImageDraw

repo = Path('E:/Dev/aem/.worktrees/audio-monitoring')
root = Path('E:/Dev/aem/artifacts/pr-ci-followups')
source = '4f9bb2fb8cd7baa9a0aea9fa4f5d63432ab3330a'
base = '7a00d1b559966b85ffb4929e5ae3371015eb9a76'
def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args])
def sha(data): return hashlib.sha256(data).hexdigest()
assert git('rev-parse', 'HEAD').decode().strip() == source
assert not git('status', '--porcelain').strip()
results = json.loads((root/'audio-monitor-frozen-results.json').read_text(encoding='utf-8-sig'))
assert results['SourceCommit'] == source
assert len(results['Results']) == 9 and all(r['ExitCode'] == 0 for r in results['Results'])
launch = (root/'audio-monitor-frozen-launch.log').read_text(encoding='utf-8-sig')
assert launch.startswith('Motion Studio') and '--project' in launch
assert 'PASS ' in (root/'audio-monitor-long-probe.log').read_text(encoding='utf-8-sig')
files = git('diff', '--name-only', base, source).decode().splitlines()
sources = {}
entries = {}
for name in files + ['Cargo.lock']:
    data = git('show', f'{source}:{name}')
    blob = git('rev-parse', f'{source}:{name}').decode().strip()
    assert git('hash-object', name).decode().strip() == blob
    entries[f'source/{name}'] = data
    sources[name] = {'blob': blob, 'sha256': sha(data)}
for path in root.glob('audio-monitor-frozen-*.log'):
    entries['final/'+path.name] = path.read_bytes()
entries['final/results.json'] = (root/'audio-monitor-frozen-results.json').read_bytes()
for folder in ['audio-monitor-frozen-native','audio-monitor-frozen-device','audio-monitor-frozen-errors','audio-monitor-af4-attempt']:
    for path in (root/folder).rglob('*'):
        if path.is_file(): entries[folder+'/'+path.relative_to(root/folder).as_posix()] = path.read_bytes()
for path in root.glob('audio-monitor-*.log'):
    if '-frozen-' not in path.name and path.name != 'audio-monitor-long-probe.log':
        entries['development/'+path.name] = path.read_bytes()
entries['long-probe/run.log'] = (root/'audio-monitor-long-probe.log').read_bytes()
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
    entries['long-probe/'+name] = (root/'audio-monitor-long-probe'/name).read_bytes()
entries['reproduce/run-validation.ps1'] = (root/'run-audio-monitor-validation.ps1').read_bytes()
entries['reproduce/package-evidence.py'] = Path(__file__).read_bytes()
binary = root/'audio-monitor-motion-studio.exe'
h = hashlib.sha256()
with binary.open('rb') as f:
    while data := f.read(1024*1024): h.update(data)
captures = sorted((root/'audio-monitor-frozen-native').glob('*.png'))
assert len(captures) == 12
sheet = Image.new('RGB',(1600, 3*350), '#101010')
draw = ImageDraw.Draw(sheet)
for i, path in enumerate(captures):
    image = Image.open(path).convert('RGB')
    # Normalize DPI and crop only empty lower background in this review sheet.
    # Full unmodified captures are retained in the zip and the repository.
    scale = float(path.stem.rsplit('-', 1)[1][:-1])
    logical = image.resize((round(image.width/scale), round(image.height/scale)))
    logical = logical.crop((0, 0, logical.width, min(logical.height, 430)))
    thumb = ImageOps.contain(logical, (395, 320))
    x, y = (i%4)*400, (i//4)*350
    sheet.paste(thumb, (x,y+25))
    draw.text((x+3,y+3),path.stem.replace('audio-monitor-',''),fill='white')
sheet.save(root/'audio-monitor-contact-sheet.png')
entries['review/contact-sheet.png'] = (root/'audio-monitor-contact-sheet.png').read_bytes()
manifest = {
    'issue':273, 'sourceCommit':source, 'baseCommit':base,
    'results':results['Results'], 'sources':sources,
    'binary':{'name':binary.name,'bytes':binary.stat().st_size,'sha256':h.hexdigest(),'ffmpeg':True,'helpLaunchExitCode':0},
    'captures': [{'name':p.name,'sha256':sha(p.read_bytes()),'pixels':Image.open(p).size} for p in captures],
    'checks':{'styleConsumers':True,'diffCheck':True,'blockedTaskSeconds':2.1,'slowWarnings':1,'defaultFileErrorStderrStdoutIsolation':True},
    'longSourceProbe':{'durationSeconds':3600,'sampleRate':192000,'channels':2,'cacheBytes':4320000,'columns':[1,2048],'result':'passed','scope':'display reduction of independently generated prepared cache, not one-hour source decode'},
    'limits':[
        'Meter is post-mix/post-clamp device peak, not pre-limiter overshoot.',
        'Nonzero screenshot meter values use production callback PCM probe, not physical device.',
        'Floating screenshots/input use production floating_chrome route in a native hidden GPU window; no separate OS-window input injection.',
        'Third-party decoder/driver calls are not forcibly interrupted or restarted.',
        'Vulkan loader emits existing missing Epic overlay JSON errors; evidence retains them.',
        'No claim of full DESIGN baseline remediation or every device driver validation.',
    ],
}
manifest['archiveEntries'] = {name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())}
entries['manifest.json'] = json.dumps(manifest,ensure_ascii=False,indent=2).encode()
dest = repo/'engineering/validation'
(dest/'data').mkdir(exist_ok=True)
archive = dest/'data/audio-monitoring-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(entries.items()): z.writestr(name,data)
manifest['archive'] = {'path':'data/'+archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size}
(dest/'audio-monitoring-results.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
capture_dir = dest/'audio-monitoring'
capture_dir.mkdir(exist_ok=True)
for path in captures: shutil.copyfile(path,capture_dir/path.name)
shutil.copyfile(root/'audio-monitor-contact-sheet.png',capture_dir/'contact-sheet.png')
print(json.dumps({'archive':manifest['archive'],'sources':len(sources),'captures':len(captures),'binary':manifest['binary']},ensure_ascii=False))
