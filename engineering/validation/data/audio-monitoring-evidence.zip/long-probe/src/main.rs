use std::{fs::File, io::{BufWriter, Write}, time::Instant};

fn main() {
    let root = std::path::PathBuf::from(std::env::args_os().nth(1).expect("generated output directory"));
    let asset = motion_model::AudioAsset {
        id: 71, path: "assets/long.wav".into(), bytes: 100, mime: "audio/wav".into(),
        track: 0, sample_rate: 192_000, channels: 2, sample_frames: 192_000 * 3600,
        duration_us: 3_600_000_000,
    };
    asset.validate().unwrap();
    let cache = motion_media::cache_path(&root, &asset).unwrap().with_extension("wave");
    std::fs::create_dir_all(cache.parent().unwrap()).unwrap();
    let mut output = BufWriter::new(File::create(&cache).unwrap());
    // Independent constant oracle; a prepared 100 Hz cache, not a fabricated
    // hour of PCM. This probes display reads at the maximum supported duration.
    for _ in 0..360_000 { for value in [-0.75f32, 0.5, 0.25] { output.write_all(&value.to_le_bytes()).unwrap(); } }
    output.flush().unwrap();
    let began = Instant::now();
    for columns in [1, motion_media::MAX_WAVEFORM_COLUMNS] {
        let mut checks = 0;
        let values = motion_media::waveform_view(&root, &asset, 0., 3600., columns, &mut || { checks += 1; Ok(()) }).unwrap();
        assert_eq!(values.len(), columns);
        for value in &values {
            assert_eq!((value.min, value.max), (-0.75, 0.5));
            assert!((value.rms - 0.25).abs() < 1e-5);
        }
        assert!(checks > columns, "cancellation checks occur within reads as well as per column");
        println!("columns={columns} buckets=360000 sample_rate=192000 channels=2 cancellation_checks={checks}");
    }
    let mut checks = 0;
    let error = motion_media::waveform_view(&root, &asset, 0., 3600., 1, &mut || {
        checks += 1;
        if checks == 3 { Err("controlled long-wave cancellation".into()) } else { Ok(()) }
    }).unwrap_err();
    assert_eq!(error.to_string(), "controlled long-wave cancellation");
    assert_eq!(checks, 3);
    println!("PASS elapsed_ms={} source_duration_seconds=3600 cache_bytes={} cancel_checks={checks}", began.elapsed().as_millis(), std::fs::metadata(cache).unwrap().len());
}
