from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile
root=Path("E:/Dev/aem")
work=root/".worktrees/shared-model-catalog"
gate=root/"artifacts/pr-queue/shared-model-catalog-native-v1"
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((gate/"accepted.json").read_text(encoding="utf-8"))
assert r["sourceUnchanged"] and all(sha(work/p)==h for p,h in r["source"].items())
assert all(s["exitCode"]==0 and s["sourceUnchanged"] for s in r["steps"])
native=next(s for s in r["steps"] if s["name"]=="native")
assert native["targets"]==13 and native["totals"]["failed"]==0 and native["totals"]["ignored"]==0
out=root/"artifacts/pr-queue/shared-model-catalog-complete-v1"
out.mkdir(exist_ok=False)
archive=work/"engineering/validation/data/shared-model-catalog-native-v1.zip"
payload={p.relative_to(gate).as_posix():p.read_bytes() for p in gate.rglob("*") if p.is_file()}
payload["completion-controller.py"]=Path(__file__).read_bytes()
payload["source.patch"]=subprocess.check_output(["git","diff","--binary"],cwd=work)
manifest={k:{"bytes":len(v),"sha256":hashlib.sha256(v).hexdigest()} for k,v in payload.items()}
with zipfile.ZipFile(archive,"x",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for k,v in payload.items(): z.writestr(k,v)
 z.writestr("manifest.json",json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(manifest)+1
 for k,v in manifest.items():
  data=z.read(k)
  assert len(data)==v["bytes"] and hashlib.sha256(data).hexdigest()==v["sha256"]
doc=work/"engineering/validation/shared-model-catalog-current.md"
doc.write_text(f"""# Shared CPU model source catalog

## Implemented

`ModelSourceCatalog::prepare` freezes a validated replacement without a GPU.
The immutable catalog map and parsed resource payload use Arc ownership. Clones
and the native renderer share those same parsed scenes. Preparation retains the
existing 320 MiB encoded and 320 MiB retained-payload limits; cache hits are
charged too. These limits apply to each admitted catalog, not process RAM or
concurrent old/new generations. Existing budget assertions remain unchanged.

The renderer can adopt a prepared catalog before asset configuration, and return
a shared read-only catalog to semantic consumers. Asset synchronization still
validates source identity and authored references. No frame-time IO or parsing
is added. Candidate failure does not change the previous catalog. Duplicate
source IDs now fail explicitly rather than overwriting a map entry; this is a
functional validation fix, separate from logging. GPU/source/target invalidation
otherwise keeps the existing installation behavior.

## Acceptance

Source-bound native acceptance: **{native['totals']['passed']} passed, 0 failed,
0 ignored**, 13 targets, plus desktop FFmpeg/AI-depth compilation, provenance
and panel-style checks. Existing assertions are unchanged. Four new tests cover
CPU-only save/reopen, source deletion, cross-thread Arc identity, retained byte
accounting, failed replacement, duplicate ID refusal, empty replacement with
live readers, and actual new-device upload/capture after files are deleted.
The native capture is byte-equal to an independent earlier device capture and
remains unchanged after failed reconfiguration.

No UI/style/panel, dependency or third-party asset changes. Android is retired
and excluded. This is not full-workspace or cross-platform acceptance.

## Remaining camera integration

This checkpoint provides resource ownership, not imported-camera activation.
Saved camera selection, hierarchy and independent animation clocks still need
to feed semantic scene sampling before effects and nested/exposure sampling.
The host's initial no-GPU sampling, replacement, undo and capture/export must
use the shared catalog. Current-frame depth calibration/reprojection/DOF and
intersecting transparency also remain open. Neither #74 nor #87 is closed.

[Source-bound native evidence](data/shared-model-catalog-native-v1.zip), SHA-256
`{sha(archive)}`, {archive.stat().st_size} bytes. Every archived entry is read back
and hash-verified. Counts overlap previous checkpoints and must not be summed.
""",encoding="utf-8",newline="\n")
subprocess.run(["git","diff","--check"],cwd=work,check=True)
subprocess.run(["git","diff","--stat"],cwd=work,check=True)
paths=r["changedSource"]+[doc.relative_to(work).as_posix(),archive.relative_to(work).as_posix()]
assert not any(p.startswith("desktop/app/src/panels/") for p in paths)
subprocess.run(["git","add","--",*paths],cwd=work,check=True)
message=out/"commit-message.txt"
message.write_text("refactor(render): 共享无设备依赖的模型源目录\n\n- 共享受预算约束的解析资源与冻结源身份\n- 支持渲染器接纳目录并拒绝重复源标识\n- 验证源文件删除后的原生上传及失败恢复\n- 归档回归结果并记录摄影机接线的剩余范围\n\nRefs #87\n",encoding="utf-8",newline="\n")
subprocess.run(["git","commit","-F",str(message)],cwd=work,check=True)
subprocess.run(["git","show","--stat","--oneline","HEAD"],cwd=work,check=True)
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=work).decode().strip()
assert not subprocess.check_output(["git","status","--porcelain"],cwd=work).strip()
assert all(sha(work/p)==h for p,h in r["source"].items())
result=dict(head=head,completedUtc=datetime.now(timezone.utc).isoformat(),totals=native["totals"],archiveSha256=sha(archive),published=False)
(out/"completed.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
print(json.dumps(result),flush=True)
