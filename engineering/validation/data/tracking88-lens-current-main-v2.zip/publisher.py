from pathlib import Path
import collections,hashlib,json,re,subprocess,zipfile

root=Path('E:/Dev/aem');work=root/'.worktrees/video-lens-current-main';out=root/'artifacts/pr-queue/tracking586-current-main-v1'
report=json.loads((out/'exit.json').read_text(encoding='utf-8'))
assert report['status']=='latest_main_lens_video_clocks_prefetch_and_native_surface_passed'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=work).decode().strip()
assert git('rev-parse','HEAD')==report['head']=='1170ededa825a100d63131c2aa5255a2e55768a0'
assert not git('status','--porcelain')
assert all(sha((work/p).read_bytes())==h for p,h in report['source'].items())
steps={step['name']:step for step in report['steps']};assert len(steps)==6 and all(s['exitCode']==0 for s in steps.values())
targets=re.findall(r'Running tests[\\/](\w+)\.rs',(out/'render.stderr.log').read_text(encoding='utf-8'))
expected=['tracking_lens','video_yuv','video_lifetime','video_instances','video_allocation_budget','model_layers','layer_time_nested']
assert collections.Counter(targets)==collections.Counter(expected)
assert len(steps['render']['summaries'])==7 and len(steps['host']['summaries'])==1
counts={}
for name in ['render','host','surface','prefetch','mapped']:
    rows=steps[name]['summaries'];assert rows and all(row[0]=='ok' and row[2]=='0' and row[3]=='0' for row in rows)
    counts[name]=dict(passed=sum(int(row[1]) for row in rows),failed=0,ignored=0,filtered=sum(int(row[5]) for row in rows))
assert counts['render']['filtered']==counts['host']['filtered']==0
assert [counts[name]['passed'] for name in ['surface','prefetch','mapped']]==[2,2,1]
for folder in ['surface-camera','surface-bindings']:
    process=json.loads((out/folder/'child-process.json').read_text(encoding='utf-8'));assert process
    assert json.loads((out/folder/'report.json').read_text(encoding='utf-8'))
log=(out/'prefetch-log/motion-studio.log').read_text(encoding='utf-8')
stderr=(out/'prefetch-log/stderr.log').read_text(encoding='utf-8')
stdout=(out/'prefetch-log/stdout.log').read_text(encoding='utf-8')
assert sum('site=video_prefetch_plan ' in line and ' ERROR ' in line and 'count=60 ' in line for line in log.splitlines())==2
assert stderr.count('site=video_prefetch_plan ')==2 and 'site=video_prefetch_plan ' not in stdout
trees={}
for crate in ['motion-model','motion-core','motion-host','motion-media']:
    path='crates/'+crate;a=git('rev-parse','52b26fda:'+path);b=git('rev-parse','HEAD:'+path);assert a==b;trees[path]=a
assert not git('diff','--name-only',report['maintainedMain'],'--','desktop/app/src/panels')
visual=out/'visual-review.json';assert visual.is_file(), 'Inspect actual new native captures first'
entries={'publisher.py':Path(__file__).read_bytes()}
for path in out.rglob('*'):
    if path.is_file() and path.suffix in {'.py','.rs','.json','.log','.png'}:
        entries[path.relative_to(out).as_posix()]=path.read_bytes()
entries['manifest.json']=(json.dumps({n:dict(bytes=len(b),sha256=sha(b)) for n,b in entries.items()},indent=2)+'\n').encode()
dest=work/'engineering/validation/data/tracking88-lens-current-main-v2.zip'
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in entries.items():z.writestr(name,data)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    for name,data in entries.items():assert z.read(name)==data
receipt=dict(status='scoped_current_main_lens_controls_passed_final_ci_pending',head=report['head'],main=report['maintainedMain'],
    parent='52b26fda5295acc9383c6b77ff970a456c40d0cc',unchangedCrateTrees=trees,counts=counts,renderTargets=targets,
    terminalSession=54025,terminalConsumed=True,terminalExitCode=0,rayOracle=report['rayOracle'],steps=report['steps'],
    sourceUnchanged=True,visualReview=json.loads(visual.read_text(encoding='utf-8')),
    archive=dict(path=dest.name,bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),members=len(entries)),
    limits=['Seven complete renderer integration targets and complete host library; filtered desktop controls do not qualify full desktop/workspace',
            'Actual Surface, original clocks and bounded planning-failure logs do not qualify every lens/codec/binding/clock combination',
            'Earlier native crashes and real photographed-tracker quality failures remain unresolved; no Android acceptance'])
dest.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
total=sum(c['passed'] for c in counts.values());maximum=max(row['maximumError'] for row in report['rayOracle'])
rows='\n'.join(f"| {name} | {c['passed']} | 0 / 0 | {c['filtered']} |" for name,c in counts.items())
(work/'engineering/validation/tracking88-lens-current-main-v2.md').write_text(f'''# Nonlinear native video: current-main integration

Source `{report['head']}` integrates parent #584 `52b26fda` and main
`{report['maintainedMain']}` after #583's Chinese squash merge. Synchronization
adds no new product behavior, test assertion, UI, dependency or external asset.
The existing nonlinear-video implementation remains the separately described
functional scope in [the original record](tracking88-native-video-lens-current.md).

## Actual frozen-source execution

The complete host/desktop FFmpeg all-target check passed before these tests.

| Command scope | Passed | Failed / ignored | Filtered |
| --- | ---: | --- | ---: |
{rows}

The seven renderer target names are matched individually against the actual
Cargo invocations and seven summaries. All tests in those targets and the host
library executed, without filtering. The total of {total} passes is restricted
to these commands; it is not a full desktop/workspace count. Existing assertions,
ignore markers, waits, pixel thresholds and allocation budgets were unchanged.

All eight independent queued-video ray checks exceed 250000 stable pixels;
their largest measured channel error is {maximum}, within the original two-byte
threshold and original edge exclusions. The actual Windows Surface controls
retain an attached native device/window through fixed-plate camera, point,
plane and nonlinear-lens replacement, pixel invalidation/reuse, undo/redo and
reopening. New representative before/after captures are individually inspected.
This is native readback, not physical scanout or photographed tracker quality.

Two real FFmpeg prefetch tests cover CFR/VFR authored clocks and actual planning
failure admission/recovery. With MOTION_LOG unset, the failure episode emits
Error at count 60, suppresses repeats, resets on recovery and emits once at the
next count 60. Both Errors appear in file and stderr and are absent from stdout.
Sixty occurrences do not imply a fixed duration. The separate four-case native
original-video control checks stretch, reverse, linear remap and hold against
references through replacement, history and relinking.

The model/core/host/media trees exactly match parent `52b26fda`; their tree IDs
are recorded. Host is actually revalidated here. Historical full model/core
passes are not counted again, and the changed renderer is not claimed identical
to its parent. No panel differs from maintained main.

## Evidence and limits

The [receipt](data/tracking88-lens-current-main-v2.json) and
[archive](data/tracking88-lens-current-main-v2.zip) retain actual commands,
process exits, source identities, native reports/images, default-level failure
logs and a verified per-member manifest. Source hashes match throughout; the
original session 54025 exited zero and was consumed before publication.

The older compiler access violation remains retained by the preceding clock
integration record. The separate local clock-package allocation failure and
earlier native product crashes are not resolved by this scoped pass. No retry
or relaxed assertion is presented as a fix. Fresh final-head CI, full #88/3D
acceptance and photographed tracking quality remain pending. Android is retired
and excluded. No issue closure is implied.
''',encoding='utf-8',newline='\n')
print(json.dumps(dict(counts=counts,total=total,maximumChannelError=maximum,archive=receipt['archive'])))
