from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/video-lens-current-main'
out = root / 'artifacts/pr-queue/tracking586-current-main-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=work, encoding='utf-8').strip()
assert git('branch', '--show-current') == 'codex/video-lens-current-main'
assert git('rev-parse','HEAD')=='1170ededa825a100d63131c2aa5255a2e55768a0'
assert not git('status','--porcelain')
parents = git('show','-s','--format=%P','HEAD').split()
assert len(parents)==2
subprocess.run(['git','merge-base','--is-ancestor','0790404fab0328c99ffcc525ca4b56084a383951','HEAD'],cwd=work,check=True)
paths = git('ls-files', '--cached', '--others', '--exclude-standard').splitlines()
sources = {p: sha(work / p) for p in sorted(set(paths)) if p.endswith(('.rs', '.wgsl', 'Cargo.toml', 'Cargo.lock')) and (work / p).is_file()}
snapshot = git('diff', '--name-only', '90016229', '--', 'crates', 'desktop/app/src').splitlines()
snapshot += ['crates/motion-render/src/scene.rs', 'crates/motion-render/src/renderer.rs',
    'desktop/app/src/engine/tracking_video_surface_tests.rs', 'desktop/app/src/engine/tracking_surface_binding_tests.rs']
for relative in sorted(set(snapshot)):
    if relative.endswith('.rs'):
        target = out / 'source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((work / relative).read_bytes())
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env['LOCALAPPDATA']=str(out/'appdata')
env.update(CARGO_HOME=str(root / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1', RUST_BACKTRACE='full',
    LIBCLANG_PATH=str(root / '.tools/python-libclang/clang/native'),
    TEMP=str(root / 'target/ci-policy-validation-tmp'), TMP=str(root / 'target/ci-policy-validation-tmp'),
    MOTION_LENS_VIDEO_ARTIFACTS=str(out / 'render-native'), MOTION_TRACKED_SURFACE_ARTIFACTS=str(out / 'surface-camera'),
    MOTION_TRACKED_BINDINGS_SURFACE_ARTIFACTS=str(out / 'surface-bindings'), MOTION_TRACKING_VIDEO_CLOCK_DIR=str(out / 'mapped'),
    MOTION_MAPPED_PREFETCH_REPORT=str(out / 'prefetch.json'), MOTION_MAPPED_PREFETCH_LOG_ARTIFACTS=str(out / 'prefetch-log'))
ffmpeg = root / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(FFMPEG_DIR=str(ffmpeg), FFMPEG_INCLUDE_DIR=str(ffmpeg / 'include'), FFMPEG_LIB_DIR=str(ffmpeg / 'lib'))
env['PATH'] = str(ffmpeg / 'bin') + os.pathsep + env['PATH']
common = ['--locked', '--offline']
render = ['cargo', 'test', '-p', 'motion-render'] + common + ['--no-fail-fast']
for target in ['tracking_lens', 'video_yuv', 'video_lifetime', 'video_instances', 'video_allocation_budget', 'model_layers', 'layer_time_nested']:
    render += ['--test', target]
render += ['--', '--test-threads=1']
desktop = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg', '--bin', 'motion-studio'] + common
commands = [
    ('check', ['cargo','check','-p','motion-host','-p','motion-desktop','--features','motion-desktop/ffmpeg','--all-targets'] + common),
    ('render', render),
    ('host', ['cargo', 'test', '-p', 'motion-host'] + common + ['--lib', '--', '--test-threads=1']),
    ('surface', desktop + ['engine::tracking_video_replacement_tests::paired::surface::', '--', '--test-threads=1', '--nocapture']),
    ('prefetch', desktop + ['engine::mapped_video_prefetch_tests::', '--', '--test-threads=1', '--nocapture']),
    ('mapped', desktop + ['engine::tracking_video_replacement_tests::mapped_time::mapped_original_video_keeps_native_picture_and_authored_clock_across_replacement', '--', '--exact', '--test-threads=1', '--nocapture']),
]
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), source=sources, steps=[],
    head=git('rev-parse', 'HEAD'), integratedParents=parents, maintainedMain=git('rev-parse', 'origin/main'))
started = time.monotonic()
def save():
    pending = out / 'exit.pending.json'
    pending.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(pending, out / 'exit.json')
save()
try:
    for name, command in commands:
        step = dict(name=name, command=command, startedUtc=datetime.now(timezone.utc).isoformat())
        report['steps'].append(step)
        save()
        with (out / f'{name}.stdout.log').open('wb') as stdout, (out / f'{name}.stderr.log').open('wb') as stderr:
            child = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
            step['pid'] = child.pid
            save()
            step['exitCode'] = child.wait()
        step['completedUtc'] = datetime.now(timezone.utc).isoformat()
        text = (out / f'{name}.stdout.log').read_text(encoding='utf-8', errors='replace')
        step['summaries'] = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', text)
        save()
        assert step['exitCode'] == 0, step
        if name!='check':
            assert step['summaries'] and all(row[0] == 'ok' and int(row[2]) == 0 for row in step['summaries'])
        print(json.dumps(dict(phase=name,exitCode=step['exitCode'],summaries=step['summaries'])),flush=True)
        expected = {'surface': 2, 'prefetch': 2, 'mapped': 1}.get(name)
        if expected is not None:
            assert sum(int(row[1]) for row in step['summaries']) == expected, 'controls did not execute'
            assert not any(int(row[3]) for row in step['summaries']), 'controls ignored'
        assert all(sha(work / p) == digest for p, digest in sources.items()), 'source changed'
    rays = json.loads((out / 'render-native/video-lens-report.json').read_text(encoding='utf-8'))
    assert len(rays) == 8 and all(row['checked'] > 250000 and row['maximumError'] <= 2 for row in rays)
    report['rayOracle'] = rays
    assert len(json.loads((out / 'mapped/report.json').read_text(encoding='utf-8'))['cases']) == 4
    report['sourceUnchanged'] = True
    report['status'] = 'latest_main_lens_video_clocks_prefetch_and_native_surface_passed'
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - started, 3))
    save()
    print(json.dumps({key: report.get(key) for key in ['status', 'failure', 'elapsedSeconds']}, indent=2), flush=True)
