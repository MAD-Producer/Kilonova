//! Mask keys use composition time and the shared timeline's viewport.
use super::*;

#[cfg(test)]
mod navigation_tests {
    use super::*;

    fn draw(controls: &mut Controls, engine: &motion_core::Engine, frame: u32, index: u8, slot: usize, cancel: bool, readonly: bool) -> Vec<Action> {
        let layer = &engine.project().layers[0];
        let state = serde_json::json!({"root":"fixture", "composition":"main", "project":engine.project(), "frame":frame, "observing":readonly});
        let mut list = PaintList::default();
        let styles = list.styles();
        let p = [styles.metric("padding.panel", 8.) + (slot as f32 + 0.5) * styles.metric("icon.slot", 20.), styles.metric("row.height", 22.) * 0.5];
        let input = Input { mouse:p, pressed:Some((MouseButton::Left,p)), focus_lost:cancel, ..Default::default() };
        let mut out = Vec::new();
        controls.navigation(&mut list, Rect::new(0., 0., 220., styles.metric("row.height", 22.)), &state, Owner::from(layer), &layer.masks[0], index, &input, &mut out);
        out
    }

    #[test]
    fn navigation_buttons_preserve_mask_channels_and_local_path_poses_with_one_undo() {
        for index in mask_path::CHANNELS {
            let mut engine = tests::engine();
            let mut controls = Controls::default();
            let original = engine.project().clone();
            for frame in [12, 42] {
                let actions = draw(&mut controls, &engine, frame, index, 1, false, false);
                assert_eq!(actions.len(), 1);
                tests::apply(&mut engine, actions);
            }
            let before = engine.project().clone();
            for (slot, expected) in [(0, 12.), (2, 42.)] {
                let actions = draw(&mut controls, &engine, 24, index, slot, false, false);
                assert!(matches!(actions.as_slice(), [Action::Seek(frame)] if *frame == expected), "{actions:?}");
                assert_eq!(engine.project(), &before);
            }
            assert!(draw(&mut controls, &engine, 12, index, 0, false, false).is_empty());
            let actions = draw(&mut controls, &engine, 24, index, 1, false, false);
            tests::apply(&mut engine, actions);
            let added = engine.project().clone();
            let mask = &added.layers[0].masks[0];
            assert_eq!(frames(mask, index), vec![0, 12, 30]);
            for other in mask_path::CHANNELS.into_iter().filter(|other| *other != index) {
                assert_eq!(frames(mask, other), frames(&original.layers[0].masks[0], other));
            }
            let folder = tempfile::tempdir().unwrap();
            motion_core::storage::save(folder.path(), &added).unwrap();
            assert_eq!(motion_core::storage::load(folder.path()).unwrap(), added);
            engine.undo().unwrap();
            assert_eq!(engine.project(), &before);
            engine.redo().unwrap();
            assert_eq!(engine.project(), &added);
            let actions = draw(&mut controls, &engine, 24, index, 1, false, false);
            tests::apply(&mut engine, actions);
            assert_eq!(frames(&engine.project().layers[0].masks[0], index), vec![0, 30]);
            for (cancel, readonly) in [(true, false), (false, true)] {
                assert!(draw(&mut controls, &engine, 24, index, 1, cancel, readonly).is_empty());
            }
            engine.apply(Command::Flags { object:7, visible:true, locked:true }).unwrap();
            let locked = engine.project().clone();
            assert!(draw(&mut controls, &engine, 24, index, 1, false, false).is_empty());
            assert_eq!(engine.project(), &locked);
        }
    }
}
use motion_core::{Ease, Easing};
use motion_ui::{
    icons::Icon,
    widgets::{Dropdown, DropdownItem},
};

#[derive(Clone, Copy)]
pub(super) struct Owner {
    pub object: u64,
    pub locked: bool,
    pub offset: i32,
}
impl From<&Layer> for Owner {
    fn from(layer: &Layer) -> Self {
        Self {
            object: layer.id,
            locked: layer.locked,
            offset: layer.timeline.map_or(0, |t| t.offset_frame),
        }
    }
}
#[derive(Clone, PartialEq, Eq)]
struct Channel {
    object: u64,
    mask: u64,
    property: u8,
}
fn property(index: u8) -> MaskProperty {
    match index {
        0 => MaskProperty::Opacity,
        1 => MaskProperty::Feather,
        _ => MaskProperty::Expansion,
    }
}
pub(super) fn frames(mask: &LayerMask, index: u8) -> Vec<i32> {
    match index {
        mask_path::CHANNEL => mask_path::frames(mask),
        0 => mask.opacity.keys.iter().map(|k| k.frame).collect(),
        1 => mask.feather.keys.iter().map(|k| k.frame).collect(),
        _ => mask.expansion.keys.iter().map(|k| k.frame).collect(),
    }
}
pub(super) fn values(mask: &LayerMask, index: u8, local: f64) -> motion_core::Result<Vec<f32>> {
    match index {
        mask_path::CHANNEL => mask_path::values(mask, local),
        0 => Ok(vec![mask.opacity.sample(local)?]),
        1 => Ok(mask.feather.sample(local)?.to_vec()),
        _ => Ok(vec![mask.expansion.sample(local)?]),
    }
}
pub(super) fn animated(mask: &LayerMask, index: u8) -> bool {
    match index {
        mask_path::CHANNEL => mask.path.nodes.iter().any(|n| n.geometry.is_animated()),
        0 => mask.opacity.is_animated(),
        1 => mask.feather.is_animated(),
        _ => mask.expansion.is_animated(),
    }
}
struct Drag {
    channel: Channel,
    from: u32,
    origin: u32,
    start: f32,
    begun: bool,
    copy: bool,
    lane: Rect,
    ppf: f32,
    offset: f32,
}
struct Menu {
    channel: Channel,
    frame: u32,
    anchor: Rect,
    dropdown: Dropdown,
    opened: bool,
    existing: bool,
    can_curve: bool,
    values: Vec<f32>,
    path: Option<(LayerMask, i32)>,
}
#[derive(Default)]
pub(super) struct Controls {
    selection_intent: bool,
    context: Option<(String, String, u64)>,
    active: Option<Channel>,
    selected: Option<(Channel, u32)>,
    drag: Option<Drag>,
    menu: Option<Menu>,
}
fn command(channel: &Channel, action: MaskAction) -> Action {
    Action::Edit(Command::Mask {
        object: channel.object,
        action,
    })
}
fn emit(
    out: &mut Vec<Action>,
    channel: &Channel,
    mask: &LayerMask,
    offset: i32,
    action: MaskAction,
) {
    if channel.property == mask_path::CHANNEL {
        out.extend(mask_path::command(channel.object, mask, offset, action));
    } else {
        out.push(command(channel, action));
    }
}
impl Controls {
    pub(in crate::panels) fn project_key(&mut self, state: &Value, object: u64, mask: u64, property: u8, frame: u32) {
        self.context = Some((state["root"].as_str().unwrap_or("").into(), state["composition"].as_str().unwrap_or("").into(), object));
        let channel=Channel {object,mask,property};
        self.active=Some(channel.clone());
        self.selected=Some((channel,frame));
        self.selection_intent=true;
    }
    pub(in crate::panels) fn clipboard_selection(&self, state: &Value, object: u64) -> Option<crate::panels::keyframe_clipboard::Selection> {
        use crate::panels::keyframe_clipboard as clipboard;
        let c = self.active.as_ref().filter(|c| c.object == object)?;
        if !self.selected_in(state, object, c.mask, c.property) { return None; }
        let layer = clipboard::layer(state, object)?;
        let mask = layer["masks"].as_array()?.iter().find(|m| m["id"] == c.mask)?;
        let track = |property| motion_core::KeyframeTarget::Mask { object, mask: c.mask, property };
        let (targets, mut frames): (Vec<_>, Vec<_>) = if c.property == mask_path::CHANNEL {
            mask["path"]["nodes"].as_array()?.iter().map(|node| Some((track(MaskProperty::Node(node["id"].as_u64()?)), clipboard::json_frames(state, &node["geometry"], clipboard::offset(layer), object)?)))
                .collect::<Option<Vec<_>>>()?.into_iter().unzip()
        } else {
            let name = match c.property { 0 => "opacity", 1 => "feather", _ => "expansion" };
            (vec![track(property(c.property))], vec![clipboard::json_frames(state, &mask[name], clipboard::offset(layer), object)?])
        };
        if let Some((selected, frame)) = &self.selected {
            if selected != c { return None; }
            for frames in &mut frames { frames.retain(|f| f == frame); }
        }
        // A whole-path key is a pose. Include every vertex at the selected pose
        // times; partial authored poses are rejected explicitly by core capture.
        if c.property == mask_path::CHANNEL {
            let mut union: Vec<_> = frames.iter().flatten().copied().collect();
            union.sort_unstable(); union.dedup();
            frames = targets.iter().map(|_| union.clone()).collect();
        }
        Some(clipboard::Selection::new(state, targets, frames, layer["locked"] != true))
    }
    pub(super) fn take_selection_intent(&mut self) -> bool {
        std::mem::take(&mut self.selection_intent)
    }

    pub(super) fn selected_in(&self, state: &Value, object: u64, mask: u64, property: u8) -> bool {
        self.active.as_ref().is_some_and(|channel|
            channel.object == object && channel.mask == mask && channel.property == property)
            && self.context.as_ref().is_some_and(|(root, composition, owner)|
                *owner == object && root == state["root"].as_str().unwrap_or("")
                    && composition == state["composition"].as_str().unwrap_or(""))
    }

    pub(super) fn editing(&self) -> bool {
        self.drag.is_some() || self.menu.is_some()
    }
    pub(super) fn modal(&self) -> bool {
        self.menu.is_some()
    }
    pub(super) fn clear_selection(&mut self) {
        self.selection_intent = false;
        self.active = None;
        self.selected = None;
    }
    pub(super) fn cancel(&mut self) -> bool {
        self.menu = None;
        self.clear_selection();
        self.drag.take().is_some_and(|d| d.begun)
    }
    pub(super) fn owner(&self) -> Option<u64> {
        self.drag
            .as_ref()
            .map(|d| d.channel.object)
            .or_else(|| self.active.as_ref().map(|c| c.object))
    }
    pub(super) fn prepare(
        &mut self,
        state: &Value,
        layer: &Layer,
        input: &Input,
        out: &mut Vec<Action>,
    ) {
        self.prepare_owner(state, Owner::from(layer), &layer.masks, input, out);
    }
    pub(super) fn prepare_owner(
        &mut self,
        state: &Value,
        owner: Owner,
        masks: &[LayerMask],
        input: &Input,
        out: &mut Vec<Action>,
    ) {
        let context = (
            state["root"].as_str().unwrap_or("").into(),
            state["composition"].as_str().unwrap_or("").into(),
            owner.object,
        );
        let key_frames = |channel: &Channel| {
            masks
                .iter()
                .find(|m| m.id == channel.mask)
                .map(|m| frames(m, channel.property))
        };
        let missing = self.drag.as_ref().is_some_and(|d| {
            key_frames(&d.channel).is_none_or(|keys| {
                !keys
                    .iter()
                    .any(|f| i64::from(*f) + i64::from(owner.offset) == i64::from(d.from))
            })
        }) || self.menu.as_ref().is_some_and(|m| {
            m.existing
                && key_frames(&m.channel).is_none_or(|keys| {
                    !keys
                        .iter()
                        .any(|f| i64::from(*f) + i64::from(owner.offset) == i64::from(m.frame))
                })
        });
        let mut sampling_failed = false;
        if let Some(menu) = &mut self.menu {
            if menu.channel.property == mask_path::CHANNEL {
                menu.path = masks
                    .iter()
                    .find(|m| m.id == menu.channel.mask)
                    .map(|m| (m.clone(), owner.offset));
                if let Some((mask, offset)) = &menu.path {
                    match observe!("mask.menu_path_sample",
                        mask_path::values(mask, f64::from(menu.frame) - f64::from(*offset)),
                        "object={} mask={} frame={}", owner.object, mask.id, menu.frame) {
                        Ok(values) => menu.values = values,
                        Err(_) => sampling_failed = true,
                    }
                }
            }
            menu.can_curve = menu.existing
                && key_frames(&menu.channel).is_some_and(|keys| {
                    keys.iter()
                        .any(|f| i64::from(*f) + i64::from(owner.offset) > i64::from(menu.frame))
                });
        }
        if sampling_failed || self.context.as_ref() != Some(&context)
            || owner.locked
            || missing
            || input.focus_lost
            || input.keys.iter().any(|(k, _)| *k == Key::Escape)
        {
            if self.cancel() {
                out.push(Action::History(4));
            }
        }
        self.context = Some(context);
    }
    pub(super) fn choose(
        &mut self,
        state: &Value,
        owner: Owner,
        mask: u64,
        index: u8,
        out: &mut Vec<Action>,
    ) {
        let context = (
            state["root"].as_str().unwrap_or("").into(),
            state["composition"].as_str().unwrap_or("").into(),
            owner.object,
        );
        if self.context.as_ref() != Some(&context) {
            if self.cancel() {
                out.push(Action::History(4));
            }
            self.context = Some(context);
        }
        self.active = Some(Channel {
            object: owner.object,
            mask,
            property: index,
        });
        self.selection_intent = true;
        self.selected = None;
    }
    pub(super) fn navigation(
        &mut self,
        list: &mut PaintList,
        row: Rect,
        state: &Value,
        owner: Owner,
        mask: &LayerMask,
        index: u8,
        input: &Input,
        out: &mut Vec<Action>,
    ) -> bool {
        use crate::panels::key_navigation::{self as navigation, Choice};
        let at = state["frame"].as_f64().unwrap_or(0.);
        let last = crate::panels::last_frame(state);
        let adjacent = navigation::neighbours(frames(mask, index).into_iter()
            .map(|frame| f64::from(frame) + f64::from(owner.offset)), at, last);
        let frame = navigation::editable_frame(at, last);
        let editable = !owner.locked && state["observing"] != true && frame.is_some()
            && (index != mask_path::CHANNEL || !mask.path.nodes.is_empty());
        let rect = navigation::rail(&list.styles(), row);
        let Some(choice) = navigation::draw(list, rect, input, adjacent, editable) else { return false };
        self.choose(state, owner, mask.id, index, out);
        let channel = Channel { object: owner.object, mask: mask.id, property: index };
        match choice {
            Choice::Seek(frame) => {
                self.selected = Some((channel, frame as u32));
                out.push(Action::Seek(frame));
            }
            Choice::Toggle => {
                let Some(frame) = frame.filter(|_| editable) else { return false };
                let action = if adjacent.current {
                    MaskAction::DeleteKey { mask: mask.id, property: property(index), frame }
                } else {
                    MaskAction::Set {
                        mask: mask.id, property: property(index), frame,
                        value: match observe!("mask.key_navigation_sample",
                            values(mask, index, f64::from(frame) - f64::from(owner.offset)),
                            "object={} mask={} channel={index} frame={frame}", owner.object, mask.id) {
                            Ok(values) => values,
                            Err(_) => return true,
                        },
                        animated: Some(true),
                    }
                };
                emit(out, &channel, mask, owner.offset, action);
                self.selected = (!adjacent.current).then_some((channel, frame));
            }
        }
        true
    }
    pub(super) fn watch(
        &mut self,
        list: &mut PaintList,
        rect: Rect,
        state: &Value,
        owner: Owner,
        mask: &LayerMask,
        index: u8,
        input: &Input,
        out: &mut Vec<Action>,
    ) {
        let enabled = !owner.locked && (index != mask_path::CHANNEL || !mask.path.nodes.is_empty());
        crate::panels::timeline::property_icon(
            list,
            rect,
            Icon::Stopwatch,
            animated(mask, index),
            enabled,
        );
        if enabled && click(input, rect) {
            emit(
                out,
                &Channel {
                    object: owner.object,
                    mask: mask.id,
                    property: index,
                },
                mask,
                owner.offset,
                MaskAction::Animate {
                    mask: mask.id,
                    property: property(index),
                    frame: state["frame"].as_f64().unwrap_or(0.).floor().max(0.) as u32,
                    enabled: !animated(mask, index),
                },
            );
        }
    }
    pub(super) fn lane(
        &mut self,
        list: &mut PaintList,
        lane: Rect,
        ppf: f32,
        offset: f32,
        state: &Value,
        owner: Owner,
        mask: &LayerMask,
        index: u8,
        input: &Input,
        out: &mut Vec<Action>,
    ) {
        let channel = Channel {
            object: owner.object,
            mask: mask.id,
            property: index,
        };
        let stored = frames(mask, index);
        let total = state["project"]["frames"].as_u64().unwrap_or(1).max(1) as u32;
        let colors = list.styles().colors();
        let mut keys = list.child();
        let mut hit = None;
        let cy = lane.min[1] + lane.height() * 0.5;
        for local in &stored {
            let time = i64::from(*local) + i64::from(owner.offset);
            if time < 0 || time >= i64::from(total) {
                continue;
            }
            let x = lane.min[0] + (time as f32 - offset) * ppf;
            if x < lane.min[0] || x >= lane.max[0] {
                continue;
            }
            let selected = self
                .selected
                .as_ref()
                .is_some_and(|(c, f)| *c == channel && i64::from(*f) == time);
            let current = (time as f64 - state["frame"].as_f64().unwrap_or(0.)).abs() < 0.001;
            paint::diamond(
                &mut keys,
                [x, cy],
                4.,
                if selected || current {
                    colors.KEYFRAME
                } else {
                    colors.ACCENT
                },
            );
            if distance(input.mouse, [x, cy]) <= 7. {
                hit = Some(time as u32);
            }
        }
        keys.clip_to(lane);
        list.append(keys);
        if let Some((button, point)) = input.pressed.filter(|(_, p)| lane.contains(*p)) {
            self.active = Some(channel.clone());
            self.selection_intent = true;
            if let Some(time) = hit {
                self.selected = Some((channel.clone(), time));
                if button == MouseButton::Left && !owner.locked {
                    self.drag = Some(Drag {
                        channel: channel.clone(),
                        from: time,
                        origin: time,
                        start: point[0],
                        begun: false,
                        copy: index == mask_path::CHANNEL && input.modifiers.control,
                        lane,
                        ppf,
                        offset,
                    });
                    out.push(Action::Seek(f64::from(time)));
                }
            } else {
                self.selected = None;
            }
            if button == MouseButton::Right && !owner.locked {
                let time = hit.unwrap_or_else(|| {
                    (((point[0] - lane.min[0]) / ppf + offset)
                        .round()
                        .clamp(0., (total - 1) as f32)) as u32
                });
                self.menu = Some(Menu {
                    channel,
                    frame: time,
                    anchor: Rect::new(point[0], point[1], 200., 1.),
                    dropdown: Dropdown::default(),
                    opened: true,
                    existing: hit.is_some(),
                    can_curve: hit.is_some()
                        && stored
                            .iter()
                            .any(|f| i64::from(*f) + i64::from(owner.offset) > i64::from(time)),
                    values: match observe!("mask.key_menu_sample",
                        values(mask, index, f64::from(time) - f64::from(owner.offset)),
                        "object={} mask={} channel={index} frame={time}", owner.object, mask.id) {
                        Ok(values) => values,
                        Err(_) => return,
                    },
                    path: (index == mask_path::CHANNEL).then(|| (mask.clone(), owner.offset)),
                });
            }
        }
    }
    pub(super) fn process_drag(
        &mut self,
        state: &Value,
        owner: Owner,
        masks: &[LayerMask],
        body: Rect,
        ppf: f32,
        offset: f32,
        input: &Input,
        out: &mut Vec<Action>,
        threshold: f32,
    ) {
        self.prepare_owner(state, owner, masks, input, out);
        let Some(mut drag) = self.drag.take() else {
            return;
        };
        let Some(mask) = masks.iter().find(|m| m.id == drag.channel.mask) else {
            if drag.begun {
                out.push(Action::History(4));
            }
            return;
        };
        if drag.ppf != ppf
            || drag.offset != offset
            || drag.lane.min[1] < body.min[1]
            || drag.lane.max[1] > body.max[1]
            || !ppf.is_finite()
            || ppf <= 0.
        {
            if drag.begun {
                out.push(Action::History(4));
            }
            return;
        }
        let release = input.released.is_some_and(|(b, _)| b == MouseButton::Left);
        if input.dragging() || release {
            let delta = input.mouse[0] - drag.start;
            let total = state["project"]["frames"].as_u64().unwrap_or(1).max(1) as u32;
            let target = (drag.origin as f32 + delta / ppf)
                .round()
                .clamp(0., (total - 1) as f32) as u32;
            let occupied = frames(mask, drag.channel.property)
                .iter()
                .any(|f| i64::from(*f) + i64::from(owner.offset) == i64::from(target));
            if (drag.begun
                || motion_ui::widgets::numeric_behavior::started(
                    delta,
                    input.pointer_travel,
                    threshold,
                ))
                && target != drag.from
                && !occupied
            {
                let copying = drag.copy && !drag.begun;
                if !drag.begun {
                    out.push(Action::History(2));
                    drag.begun = true;
                }
                let action = if copying {
                    MaskAction::CopyKey {
                        mask: drag.channel.mask,
                        property: property(drag.channel.property),
                        from: drag.from,
                        to: target,
                    }
                } else {
                    MaskAction::MoveKey {
                        mask: drag.channel.mask,
                        property: property(drag.channel.property),
                        from: drag.from,
                        to: target,
                    }
                };
                emit(out, &drag.channel, mask, owner.offset, action);
                drag.from = target;
                self.selected = Some((drag.channel.clone(), target));
            }
        }
        if release {
            if drag.begun {
                out.push(Action::History(3));
            }
        } else {
            self.drag = Some(drag);
        }
    }
    pub(super) fn navigate(
        &mut self,
        state: &Value,
        selected: Option<u64>,
        input: &Input,
        out: &mut Vec<Action>,
    ) -> bool {
        let navigation = input.key_presses().any(|(k, m, _)|
            matches!(k, Key::J | Key::K) && !m.control && !m.alt && !m.shift);
        let Some(channel) = self.active.clone() else {
            return false;
        };
        let valid = self.context.as_ref().is_some_and(|(root, composition, object)|
            root == state["root"].as_str().unwrap_or("")
                && composition == state["composition"].as_str().unwrap_or("")
                && *object == channel.object && selected == Some(channel.object));
        if !valid { return navigation; }
        let Some(layer) = super::layer(state, channel.object) else {
            return navigation;
        };
        let Some(mask) = layer.masks.iter().find(|m| m.id == channel.mask) else {
            return navigation;
        };
        let offset = i64::from(Owner::from(&layer).offset);
        let total = state["project"]["frames"].as_u64().unwrap_or(1) as i64;
        let keys: Vec<_> = frames(mask, channel.property)
            .into_iter()
            .map(|f| i64::from(f) + offset)
            .filter(|f| *f >= 0 && *f < total)
            .collect();
        let mut at = state["frame"].as_f64().unwrap_or(0.);
        let mut consumed = false;
        for (key, mods, _) in input
            .key_presses()
            .filter(|(k, m, _)| matches!(k, Key::J | Key::K) && !m.control && !m.alt && !m.shift)
        {
            let _ = mods;
            consumed = true;
            let adjacent = crate::panels::key_navigation::neighbours(keys.iter().map(|f| *f as f64), at, (total - 1) as f64);
            let target = if key == Key::J { adjacent.previous } else { adjacent.next };
            if let Some(frame) = target {
                at = frame;
                self.selected = Some((channel.clone(), frame as u32));
                self.selection_intent = true;
                out.push(Action::Seek(at));
            }
        }
        consumed
    }
    pub(super) fn delete_selected(
        &mut self,
        state: &Value,
        selected: Option<u64>,
        input: &Input,
        out: &mut Vec<Action>,
    ) -> bool {
        if !input.key_presses().any(|(k, m, repeat)| {
            !repeat && matches!(k, Key::Delete | Key::Backspace) && !m.control && !m.alt && !m.shift
        }) {
            return false;
        }
        let Some((channel, frame)) = self.selected.take() else {
            return false;
        };
        if selected != Some(channel.object) {
            self.clear_selection();
            return true;
        }
        let Some(layer) = super::layer(state, channel.object).filter(|l| !l.locked) else {
            return true;
        };
        let valid = self.context.as_ref()
            == Some(&(
                state["root"].as_str().unwrap_or("").into(),
                state["composition"].as_str().unwrap_or("").into(),
                channel.object,
            ));
        let local = i64::from(frame) - i64::from(Owner::from(&layer).offset);
        if valid
            && layer
                .masks
                .iter()
                .find(|m| m.id == channel.mask)
                .is_some_and(|m| {
                    frames(m, channel.property)
                        .iter()
                        .any(|f| i64::from(*f) == local)
                })
        {
            let mask = layer.masks.iter().find(|m| m.id == channel.mask).unwrap();
            emit(
                out,
                &channel,
                mask,
                Owner::from(&layer).offset,
                MaskAction::DeleteKey {
                    mask: channel.mask,
                    property: property(channel.property),
                    frame,
                },
            );
        }
        true
    }
    pub(super) fn overlay(
        &mut self,
        list: &mut PaintList,
        atlas: &mut TextAtlas,
        area: Rect,
        input: &Input,
        locale: Locale,
        out: &mut Vec<Action>,
    ) {
        let Some(menu) = &mut self.menu else {
            return;
        };
        let labels = if locale == Locale::Zh {
            [
                if menu.existing {
                    "删除关键帧"
                } else {
                    "添加关键帧"
                },
                "线性",
                "保持",
                "缓入",
                "缓出",
                "缓入缓出",
            ]
        } else {
            [
                if menu.existing {
                    "Delete keyframe"
                } else {
                    "Add keyframe"
                },
                "Linear",
                "Hold",
                "Ease in",
                "Ease out",
                "Ease in/out",
            ]
        };
        let items: Vec<_> = labels
            .iter()
            .enumerate()
            .map(|(index, label)| DropdownItem {
                label,
                enabled: index == 0 || menu.can_curve,
            })
            .collect();
        let first = Input {
            mouse: input.mouse,
            pressed: Some((
                MouseButton::Left,
                [menu.anchor.min[0] + 1., menu.anchor.min[1]],
            )),
            ..Default::default()
        };
        let choice = menu.dropdown.draw_grouped(
            list,
            atlas,
            menu.anchor,
            area,
            &items,
            0,
            if menu.opened { &first } else { input },
            true,
            true,
            &[1],
            true,
        );
        menu.opened = false;
        if let Some(index) = choice {
            let action = if index == 0 {
                if menu.existing {
                    MaskAction::DeleteKey {
                        mask: menu.channel.mask,
                        property: property(menu.channel.property),
                        frame: menu.frame,
                    }
                } else {
                    MaskAction::Set {
                        mask: menu.channel.mask,
                        property: property(menu.channel.property),
                        frame: menu.frame,
                        value: menu.values.clone(),
                        animated: Some(true),
                    }
                }
            } else {
                MaskAction::Curve {
                    mask: menu.channel.mask,
                    property: property(menu.channel.property),
                    frame: menu.frame,
                    easing: Easing {
                        ease: [Ease::Linear, Ease::Hold, Ease::In, Ease::Out, Ease::InOut]
                            [index - 1],
                        curve: None,
                    },
                }
            };
            if let Some((mask, offset)) = &menu.path {
                emit(out, &menu.channel, mask, *offset, action);
            } else if menu.channel.property != mask_path::CHANNEL {
                out.push(command(&menu.channel, action));
            }
            self.menu = None;
        } else if !menu.dropdown.open {
            self.menu = None;
        }
    }
}

#[cfg(test)]
impl Controls {
    fn row(
        &mut self,
        list: &mut PaintList,
        area: Rect,
        y: f32,
        state: &Value,
        layer: &Layer,
        mask: &LayerMask,
        index: u8,
        _keys: &[i32],
        _values: &[f32],
        input: &Input,
        out: &mut Vec<Action>,
    ) -> f32 {
        let owner = Owner::from(layer);
        self.watch(
            list,
            Rect::new(area.min[0] + 14., y, 20., 24.),
            state,
            owner,
            mask,
            index,
            input,
            out,
        );
        let total = state["project"]["frames"].as_u64().unwrap_or(1).max(1);
        let lane = Rect::new(
            area.min[0] + 80.,
            y + 24.,
            (area.width() - 96.).max(1.),
            22.,
        );
        let ppf = lane.width() / (total - 1).max(1) as f32;
        self.lane(list, lane, ppf, 0., state, owner, mask, index, input, out);
        self.process_drag(
            state,
            owner,
            &layer.masks,
            area,
            ppf,
            0.,
            input,
            out,
            list.styles().metric("motion.drag_threshold", 3.),
        );
        28.
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    pub(super) fn engine() -> motion_core::Engine {
        let mut project = motion_core::Project::new(640, 360, 30, 120).unwrap();
        let mut layer = Layer::solid(7, "Masked", [100.; 2], [320., 180., 0.], [1.; 4]);
        layer.timeline = Some(motion_core::LayerTimeline {
            in_frame: 12,
            out_frame: 120,
            offset_frame: 12,
        });
        let path = VectorPath {
            id: 1,
            closed: true,
            nodes: [[0., 0.], [100., 0.], [0., 100.]]
                .into_iter()
                .enumerate()
                .map(|(i, p)| PathNode {
                    id: i as u64 + 1,
                    geometry: Track::constant([p[0], p[1], 0., 0., 0., 0.]),
                })
                .collect(),
        };
        let mut mask = LayerMask::new(1, path);
        mask.opacity = Track::constant(50.);
        mask.feather = Track::constant([8., 13.]);
        layer.masks.push(mask);
        project.layers.push(layer);
        motion_core::Engine::new(project).unwrap()
    }
    pub(super) fn apply(engine: &mut motion_core::Engine, actions: Vec<Action>) {
        for action in actions {
            match action {
                Action::Edit(command) => engine.apply(command).unwrap(),
                Action::History(2) => engine.begin_gesture().unwrap(),
                Action::History(3) => engine.end_gesture(true).unwrap(),
                Action::History(4) => engine.end_gesture(false).unwrap(),
                Action::Seek(_) => {}
                _ => panic!("unexpected mask action"),
            }
        }
    }
    pub(super) fn draw(
        controls: &mut Controls,
        engine: &motion_core::Engine,
        frame: u32,
        index: u8,
        input: &Input,
        atlas: &mut TextAtlas,
    ) -> Vec<Action> {
        let layer = &engine.project().layers[0];
        let mask = &layer.masks[0];
        let state = serde_json::json!({"root":"fixture","composition":motion_core::composition::MAIN_COMPOSITION,"project":engine.project(),"frame":frame});
        let local = f64::from(frame) - 12.;
        let keys = frames(mask, index);
        let values = values(mask, index, local).unwrap();
        let mut out = vec![];
        controls.prepare(&state, layer, input, &mut out);
        let modal = controls.modal();
        let neutral = Input::default();
        let mut list = PaintList::default();
        controls.row(
            &mut list,
            Rect::new(0., 0., 400., 300.),
            0.,
            &state,
            layer,
            mask,
            index,
            &keys,
            &values,
            if modal { &neutral } else { input },
            &mut out,
        );
        controls.overlay(
            &mut list,
            atlas,
            Rect::new(0., 0., 400., 300.),
            input,
            Locale::En,
            &mut out,
        );
        out
    }
    pub(super) fn press(button: MouseButton, x: f32, y: f32) -> Input {
        Input {
            mouse: [x, y],
            pressed: Some((button, [x, y])),
            held: Some(button),
            ..Default::default()
        }
    }
    #[test]
    fn mask_ui_animates_all_channels_at_local_time_and_key_toggle_undoes() {
        let mut atlas = TextAtlas::from_system(12.).unwrap();
        for index in 0..3 {
            let mut engine = engine();
            let original = engine.project().clone();
            let mut controls = Controls::default();
            let actions = draw(
                &mut controls,
                &engine,
                21,
                index,
                &press(MouseButton::Left, 24., 12.),
                &mut atlas,
            );
            assert!(matches!(
                &actions[..],
                [Action::Edit(Command::Mask {
                    action: MaskAction::Animate {
                        frame: 21,
                        enabled: true,
                        ..
                    },
                    ..
                })]
            ));
            apply(&mut engine, actions);
            let animated = engine.project().clone();
            let x = 80. + 42. / 119. * 304.;
            assert!(draw(
                &mut controls,
                &engine,
                42,
                index,
                &press(MouseButton::Right, x, 35.),
                &mut atlas
            )
            .is_empty());
            let actions = draw(
                &mut controls,
                &engine,
                42,
                index,
                &Input {
                    keys: vec![(Key::Enter, Default::default())],
                    ..Default::default()
                },
                &mut atlas,
            );
            apply(&mut engine, actions);
            let mask = &engine.project().layers[0].masks[0];
            let frames = match index {
                0 => mask
                    .opacity
                    .keys
                    .iter()
                    .map(|k| k.frame)
                    .collect::<Vec<_>>(),
                1 => mask.feather.keys.iter().map(|k| k.frame).collect(),
                _ => mask.expansion.keys.iter().map(|k| k.frame).collect(),
            };
            assert_eq!(frames, vec![9, 30]);
            engine.undo().unwrap();
            assert_eq!(engine.project(), &animated);
            engine.undo().unwrap();
            assert_eq!(engine.project(), &original);
        }
    }
    #[test]
    fn mask_key_drag_preserves_other_keys_and_easing_and_commits_or_cancels_once() {
        let mut atlas = TextAtlas::from_system(12.).unwrap();
        for cancel in [false, true] {
            let mut engine = engine();
            for frame in [21, 60] {
                engine
                    .apply(Command::Mask {
                        object: 7,
                        action: MaskAction::Set {
                            mask: 1,
                            property: MaskProperty::Feather,
                            frame,
                            value: vec![8., 13.],
                            animated: Some(true),
                        },
                    })
                    .unwrap();
            }
            engine
                .apply(Command::Mask {
                    object: 7,
                    action: MaskAction::Curve {
                        mask: 1,
                        property: MaskProperty::Feather,
                        frame: 21,
                        easing: Easing {
                            ease: Ease::InOut,
                            curve: None,
                        },
                    },
                })
                .unwrap();
            let before = engine.project().clone();
            let mut controls = Controls::default();
            let x = |frame: u32| 80. + frame as f32 / 119. * 304.;
            let actions = draw(
                &mut controls,
                &engine,
                21,
                1,
                &press(MouseButton::Left, x(21) + 2., 35.),
                &mut atlas,
            );
            apply(&mut engine, actions);
            // Pointer-to-key offset must remain stable across intermediate host snapshots.
            for frame in [30, 42] {
                let actions = draw(
                    &mut controls,
                    &engine,
                    21,
                    1,
                    &Input {
                        mouse: [x(frame) + 2., 35.],
                        held: Some(MouseButton::Left),
                        ..Default::default()
                    },
                    &mut atlas,
                );
                apply(&mut engine, actions);
            }
            let actions = draw(
                &mut controls,
                &engine,
                21,
                1,
                &if cancel {
                    Input {
                        focus_lost: true,
                        ..Default::default()
                    }
                } else {
                    Input {
                        mouse: [x(45) + 2., 35.],
                        released: Some((MouseButton::Left, [x(45) + 2., 35.])),
                        ..Default::default()
                    }
                },
                &mut atlas,
            );
            apply(&mut engine, actions);
            if cancel {
                assert_eq!(engine.project(), &before);
            } else {
                let keys = &engine.project().layers[0].masks[0].feather.keys;
                assert_eq!(
                    (keys[0].frame, keys[0].value, keys[0].ease),
                    (33, [8., 13.], Ease::InOut)
                );
                assert_eq!(keys[1], before.layers[0].masks[0].feather.keys[1]);
                engine.undo().unwrap();
                assert_eq!(engine.project(), &before);
            }
            assert!(!controls.editing());
        }
    }
    #[test]
    fn mask_key_context_menu_changes_interpolation_and_delete_is_undoable() {
        let mut engine = engine();
        let mut controls = Controls::default();
        let mut atlas = TextAtlas::from_system(12.).unwrap();
        let actions = draw(
            &mut controls,
            &engine,
            21,
            0,
            &press(MouseButton::Left, 24., 12.),
            &mut atlas,
        );
        apply(&mut engine, actions);
        engine
            .apply(Command::Mask {
                object: 7,
                action: MaskAction::Set {
                    mask: 1,
                    property: MaskProperty::Opacity,
                    frame: 60,
                    value: vec![80.],
                    animated: Some(true),
                },
            })
            .unwrap();
        let x = 80. + 21. / 119. * 304.;
        let actions = draw(
            &mut controls,
            &engine,
            21,
            0,
            &press(MouseButton::Right, x, 35.),
            &mut atlas,
        );
        assert!(actions.is_empty());
        for _ in 0..5 {
            assert!(draw(
                &mut controls,
                &engine,
                21,
                0,
                &Input {
                    keys: vec![(Key::Down, Default::default())],
                    ..Default::default()
                },
                &mut atlas
            )
            .is_empty());
        }
        let actions = draw(
            &mut controls,
            &engine,
            21,
            0,
            &Input {
                keys: vec![(Key::Enter, Default::default())],
                ..Default::default()
            },
            &mut atlas,
        );
        assert!(matches!(
            &actions[..],
            [Action::Edit(Command::Mask {
                action: MaskAction::Curve {
                    easing: Easing {
                        ease: Ease::InOut,
                        ..
                    },
                    ..
                },
                ..
            })]
        ));
        apply(&mut engine, actions);
        let before = engine.project().clone();
        let actions = draw(
            &mut controls,
            &engine,
            21,
            0,
            &press(MouseButton::Right, x, 35.),
            &mut atlas,
        );
        assert!(actions.is_empty());
        let actions = draw(
            &mut controls,
            &engine,
            21,
            0,
            &Input {
                keys: vec![(Key::Enter, Default::default())],
                ..Default::default()
            },
            &mut atlas,
        );
        apply(&mut engine, actions);
        assert_eq!(engine.project().layers[0].masks[0].opacity.keys.len(), 1);
        engine.undo().unwrap();
        assert_eq!(engine.project(), &before);
    }
    #[test]
    fn animated_feather_numeric_drag_preserves_y_and_cancels_when_its_context_changes() {
        let mut atlas = TextAtlas::from_system(12.).unwrap();
        for cancel in ["commit", "composition", "locked", "frame"] {
            let mut engine = engine();
            for frame in [21, 60] {
                engine
                    .apply(Command::Mask {
                        object: 7,
                        action: MaskAction::Set {
                            mask: 1,
                            property: MaskProperty::Feather,
                            frame,
                            value: vec![8., 13.],
                            animated: Some(true),
                        },
                    })
                    .unwrap();
            }
            let before = engine.project().clone();
            let mut controls = crate::panels::path_controls::Controls::default();
            controls.masks_open = true;
            let state = serde_json::json!({"root":"fixture","composition":motion_core::composition::MAIN_COMPOSITION,"project":engine.project(),"frame":33});
            let mut actions = vec![];
            controls.inspector_section(
                false,
                &mut PaintList::default(),
                &mut atlas,
                Rect::new(0., 0., 400., 600.),
                &mut 0.,
                &engine.project().layers[0],
                &state,
                &press(MouseButton::Left, 210., 121.),
                Locale::Zh,
                &mut actions,
            );
            assert!(controls.parameter.is_some());
            apply(&mut engine, actions);
            let mut actions = vec![];
            controls.parameter_input(
                &state,
                &Input {
                    mouse: [230., 121.],
                    held: Some(MouseButton::Left),
                    ..Default::default()
                },
                &mut actions,
                3.,
            );
            apply(&mut engine, actions);
            assert_eq!(
                engine.project().layers[0].masks[0].feather.keys[1].value,
                [28., 13.]
            );
            let mut changed = state.clone();
            match cancel {
                "composition" => changed["composition"] = serde_json::json!("child"),
                "locked" => changed["project"]["layers"][0]["locked"] = serde_json::json!(true),
                "frame" => changed["frame"] = serde_json::json!(34),
                _ => {}
            }
            let mut actions = vec![];
            controls.parameter_input(
                &changed,
                &Input {
                    mouse: [240., 121.],
                    released: Some((MouseButton::Left, [240., 121.])),
                    ..Default::default()
                },
                &mut actions,
                3.,
            );
            apply(&mut engine, actions);
            if cancel == "commit" {
                let keys = &engine.project().layers[0].masks[0].feather.keys;
                assert_eq!((keys[1].frame, keys[1].value), (21, [38., 13.]));
                assert_eq!(keys[0], before.layers[0].masks[0].feather.keys[0]);
                assert_eq!(keys[2], before.layers[0].masks[0].feather.keys[1]);
                engine.undo().unwrap();
            }
            assert_eq!(engine.project(), &before);
            assert!(controls.parameter.is_none());
        }
    }
    #[test]
    fn layer_properties_owns_mask_creation_menus_and_numeric_gestures_in_main_and_floating_windows()
    {
        use motion_ui::dock::{Node, Panel};
        for floating in [false, true] {
            let mut engine = engine();
            let mut panels = crate::panels::Panels::default();
            panels.selected = Some(7);
            panels.focused = Some(Panel::Properties);
            panels.properties.transform_collapsed = true;
            panels.path_controls.masks_open = true;
            let layout = Node::dock(Panel::Properties.dock());
            let mut atlas = TextAtlas::from_system(12.).unwrap();
            let mut render = |engine: &motion_core::Engine,
                              panels: &mut crate::panels::Panels,
                              input: &Input| {
                let state = serde_json::json!({"root":"fixture",
                    "composition":motion_core::composition::MAIN_COMPOSITION,
                    "frame":21,"revision":engine.revision(),"project":engine.project(),
                    "sampledLayers":[{"id":7,"position":[320,180,0],"rotation":[0,0,0],
                        "scale":[100,100,100],"opacity":1}]});
                if floating {
                    crate::panels::floating_chrome(
                        &mut PaintList::default(),
                        &mut atlas,
                        Panel::Properties,
                        [400., 700.],
                        panels,
                        &state,
                        input,
                    )
                } else {
                    crate::panels::chrome(
                        &mut PaintList::default(),
                        &mut atlas,
                        [400., 700.],
                        &layout,
                        panels,
                        &state,
                        input,
                    )
                }
            };
            assert!(render(&engine, &mut panels, &Input::default()).is_empty());
            let add = panels
                .path_controls
                .mask_add_rect(Panel::Properties)
                .unwrap();
            let x = add.min[0] + add.width() * 0.5;
            let y = add.min[1];
            assert!(render(&engine, &mut panels, &press(MouseButton::Left, x, y + 11.)).is_empty());
            assert!(panels.path_controls.add_mask_menu.open);
            // Closing the popup over a stopwatch must not animate the obscured property.
            assert!(render(
                &engine,
                &mut panels,
                &press(MouseButton::Left, 34., y + 77.)
            )
            .is_empty());
            assert!(!panels.path_controls.add_mask_menu.open);
            assert!(!engine.project().layers[0].masks[0].opacity.is_animated());
            render(&engine, &mut panels, &press(MouseButton::Left, x, y + 11.));
            let actions = render(
                &engine,
                &mut panels,
                &press(MouseButton::Left, x, add.max[1] + 33.),
            );
            assert!(matches!(
                &actions[..],
                [Action::Edit(Command::Mask {
                    action: MaskAction::Add { .. },
                    ..
                })]
            ));
            apply(&mut engine, actions);
            assert_eq!(engine.project().layers[0].masks.len(), 2);
            let before_drag = engine.project().clone();
            let fy = y + 121.;
            let styles = PaintList::default().styles();
            let indent = styles.metric("tree.indent", 14.);
            let rect = super::super::mask_inspector::property_row(
                &styles,
                Rect::new(indent, 0., 400. - indent, 700.),
                fy,
                0,
                2,
                Panel::Properties,
            )
            .number;
            let fx = rect.min[0] + rect.width() * 0.5;
            let actions = render(&engine, &mut panels, &press(MouseButton::Left, fx, fy));
            apply(&mut engine, actions);
            assert_eq!(
                panels.path_controls.numeric_owner(),
                Some(Panel::Properties)
            );
            let actions = render(
                &engine,
                &mut panels,
                &Input {
                    mouse: [fx + 20., fy],
                    held: Some(MouseButton::Left),
                    ..Default::default()
                },
            );
            apply(&mut engine, actions);
            let actions = render(
                &engine,
                &mut panels,
                &Input {
                    mouse: [fx + 30., fy],
                    released: Some((MouseButton::Left, [fx + 30., fy])),
                    ..Default::default()
                },
            );
            apply(&mut engine, actions);
            assert_eq!(
                engine.project().layers[0].masks[0].feather.value,
                [38., 13.]
            );
            engine.undo().unwrap();
            assert_eq!(engine.project(), &before_drag);
            engine.undo().unwrap();
            assert_eq!(engine.project().layers[0].masks.len(), 1);
        }
    }
    #[test]
    fn delete_shortcut_in_mask_timeline_deletes_only_the_selected_key_in_main_and_floating_windows()
    {
        use motion_ui::dock::{Node, Panel};
        for (floating, path) in [(false, false), (true, false), (false, true), (true, true)] {
            let mut engine = engine();
            engine
                .apply(Command::Mask {
                    object: 7,
                    action: MaskAction::Animate {
                        mask: 1,
                        property: MaskProperty::Opacity,
                        frame: 21,
                        enabled: true,
                    },
                })
                .unwrap();
            engine
                .apply(Command::Mask {
                    object: 7,
                    action: MaskAction::Set {
                        mask: 1,
                        property: MaskProperty::Opacity,
                        frame: 60,
                        value: vec![80.],
                        animated: None,
                    },
                })
                .unwrap();
            if path {
                let mask = &engine.project().layers[0].masks[0];
                let mask = mask_path::edit(
                    mask,
                    12,
                    MaskAction::Set {
                        mask: 1,
                        property: MaskProperty::Expansion,
                        frame: 21,
                        value: mask_path::values(mask, 9.).unwrap(),
                        animated: Some(true),
                    },
                )
                .unwrap();
                let mask = mask_path::edit(
                    &mask,
                    12,
                    MaskAction::Set {
                        mask: 1,
                        property: MaskProperty::Expansion,
                        frame: 60,
                        value: mask_path::values(&mask, 48.).unwrap(),
                        animated: Some(true),
                    },
                )
                .unwrap();
                engine
                    .apply(Command::Mask {
                        object: 7,
                        action: MaskAction::Replace { mask },
                    })
                    .unwrap();
            }
            let before = engine.project().clone();
            let mut panels = crate::panels::Panels::default();
            panels.selected = Some(7);
            panels.focused = Some(Panel::Timeline);
            panels.timeline.expanded.insert(7);
            panels.timeline.collapsed_transforms.insert(7);
            let mut atlas = TextAtlas::from_system(12.).unwrap();
            let state = serde_json::json!({"root":"fixture","composition":motion_core::composition::MAIN_COMPOSITION,"document_generation":1,"frame":21,"revision":engine.revision(),"project":engine.project()});
            let layout = Node::dock(Panel::Timeline.dock());
            let top = if floating {
                30.
            } else {
                crate::panels::frames(&layout, [1280., 700.])[0].content.min[1]
            };
            let point = [
                640. + 21. / 120. * 632.,
                top + crate::panels::timeline::header_height(&PaintList::default().styles())
                    + (if path { 3.5 } else { 4.5 }) * PaintList::default().styles().metric("row.height", 22.),
            ];
            let mut render = |panels: &mut crate::panels::Panels, input: &Input| {
                if floating {
                    crate::panels::floating_chrome(
                        &mut PaintList::default(),
                        &mut atlas,
                        Panel::Timeline,
                        [1280., 700.],
                        panels,
                        &state,
                        input,
                    )
                } else {
                    crate::panels::chrome(
                        &mut PaintList::default(),
                        &mut atlas,
                        [1280., 700.],
                        &layout,
                        panels,
                        &state,
                        input,
                    )
                }
            };
            apply(
                &mut engine,
                render(&mut panels, &press(MouseButton::Left, point[0], point[1])),
            );
            apply(
                &mut engine,
                render(
                    &mut panels,
                    &Input {
                        mouse: point,
                        released: Some((MouseButton::Left, point)),
                        ..Default::default()
                    },
                ),
            );
            let navigation = render(
                &mut panels,
                &Input {
                    keys: vec![(Key::K, Default::default())],
                    ..Default::default()
                },
            );
            assert!(matches!(&navigation[..],[Action::Seek(frame)] if *frame==60.));
            let actions = render(
                &mut panels,
                &Input {
                    keys: vec![(Key::Delete, Default::default())],
                    ..Default::default()
                },
            );
            assert!(
                matches!(
                    &actions[..],
                    [Action::Edit(Command::Mask {
                        action: MaskAction::DeleteKey { .. } | MaskAction::Path { .. },
                        ..
                    })]
                ),
                "{actions:?}"
            );
            apply(&mut engine, actions);
            assert_eq!(engine.project().layers.len(), 1);
            let mask = &engine.project().layers[0].masks[0];
            if path {
                assert!(mask
                    .path
                    .nodes
                    .iter()
                    .all(|n| n.geometry.keys.len() == 1 && n.geometry.keys[0].frame == 9));
                assert_eq!(mask.opacity, before.layers[0].masks[0].opacity);
            } else {
                assert_eq!(mask.opacity.keys.len(), 1);
                assert_eq!(mask.opacity.keys[0].frame, 9);
            }
            engine.undo().unwrap();
            assert_eq!(engine.project(), &before);
        }
    }
}

#[cfg(test)]
#[path = "mask_path_tests.rs"]
mod path_tests;
