//! SDK 1: host-owned fullscreen vertex, resource bindings and 16-byte parameter slots.
mod identity;
pub use identity::{CompiledCodeIdentity, compiled_code_identity};
use crate::{ensure, Error, Result};
use naga::{
    back::glsl,
    valid::{Capabilities, ValidationFlags, Validator},
    ShaderStage,
};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
mod legacy_select;

pub const UNIFORM_BYTES: usize = 7 * 16 + 32 * 16;
/// Numeric LUT reads use explicit interpolation, independent of F32 filtering.
pub const CURVE_LUT_ABI_VERSION: u32 = 2;
pub const HEADER: &str = r#"
struct EffectUniform {
    size: vec4<f32>, region: vec4<f32>, input_region: vec4<f32>, source_region: vec4<f32>,
    clock: vec4<f32>, mode: vec4<f32>, output_mode: vec4<f32>, params: array<vec4<f32>,32>,
};
@group(0) @binding(0) var<uniform> fx: EffectUniform;
@group(1) @binding(0) var input_image: texture_2d<f32>;
@group(1) @binding(1) var input_sampler: sampler;
@group(1) @binding(2) var source_image: texture_2d<f32>;
@group(1) @binding(3) var source_sampler: sampler;
@group(1) @binding(4) var curve_image: texture_2d<f32>;
@group(1) @binding(5) var curve_sampler: sampler;
@group(2) @binding(0) var resource0: texture_2d<f32>;
@group(2) @binding(1) var resource_sampler0: sampler;
@group(2) @binding(2) var resource1: texture_2d<f32>;
@group(2) @binding(3) var resource_sampler1: sampler;
@group(2) @binding(4) var resource2: texture_2d<f32>;
@group(2) @binding(5) var resource_sampler2: sampler;
@group(2) @binding(6) var resource3: texture_2d<f32>;
@group(2) @binding(7) var resource_sampler3: sampler;
struct EffectVertex { @builtin(position) position: vec4<f32>, @location(0) uv: vec2<f32> };
@vertex fn sdk_vertex(@builtin(vertex_index) index: u32) -> EffectVertex {
    let p = vec2(f32((index << 1u) & 2u)*2.0-1.0,f32(index & 2u)*2.0-1.0); var out: EffectVertex;
    out.position = vec4(p,0.0,1.0); out.uv = vec2(p.x*0.5+0.5,0.5-p.y*0.5); return out;
}
fn edge_uv(uv: vec2<f32>) -> vec2<f32> {
    if fx.mode.x == 2.0 { return fract(uv); }
    if fx.mode.x == 3.0 { return 1.0-abs(fract(uv*0.5)*2.0-1.0); }
    return clamp(uv,vec2(0.0),vec2(1.0));
}
fn sample_input(p: vec2<f32>) -> vec4<f32> {
    let uv = (p-fx.input_region.xy)/fx.input_region.zw;
    var coord=edge_uv(uv);
    if fx.mode.w<0.5 {
        let dimensions=vec2<f32>(textureDimensions(input_image));let pixels=ceil(fx.input_region.zw*fx.output_mode.w);
        coord*=pixels/dimensions;
        if fx.mode.x!=0.0 {coord=clamp(coord,vec2(0.5)/dimensions,(pixels-0.5)/dimensions);}
    }
    let c = textureSampleLevel(input_image,input_sampler,coord,0.0);
    return select(c,vec4(0.0),fx.mode.x == 0.0 && (any(uv < vec2(0.0)) || any(uv > vec2(1.0))));
}
fn sample_source(p: vec2<f32>) -> vec4<f32> {
    let uv = (p-fx.source_region.xy)/fx.source_region.zw;
    var coord=edge_uv(uv);
    if fx.mode.w<0.5 {
        let dimensions=vec2<f32>(textureDimensions(source_image));let pixels=ceil(fx.source_region.zw*fx.output_mode.w);
        coord*=pixels/dimensions;
        if fx.mode.x!=0.0 {coord=clamp(coord,vec2(0.5)/dimensions,(pixels-0.5)/dimensions);}
    }
    let c = textureSampleLevel(source_image,source_sampler,coord,0.0);
    return select(c,vec4(0.0),fx.mode.x == 0.0 && (any(uv < vec2(0.0)) || any(uv > vec2(1.0))));
}
fn curve_lookup_component(value: f32, channel: u32) -> f32 {
    let last=i32(textureDimensions(curve_image).x)-1;
    let position=clamp(value,0.0,1.0)*f32(last);
    let lower=i32(floor(position));let upper=min(lower+1,last);
    let a=textureLoad(curve_image,vec2(lower,0),0)[channel];
    let b=textureLoad(curve_image,vec2(upper,0),0)[channel];
    return a+(b-a)*(position-f32(lower));
}
fn curve_lookup(v: vec4<f32>) -> vec4<f32> {
    return vec4(curve_lookup_component(v.r,0u),curve_lookup_component(v.g,1u),
        curve_lookup_component(v.b,2u),curve_lookup_component(v.a,3u));
}
fn srgb_encode(v: vec3<f32>) -> vec3<f32> {
    return select(1.055*pow(max(v,vec3(0.0)),vec3(1.0/2.4))-0.055,12.92*v,v<=vec3(0.0031308));
}
fn srgb_decode(v: vec3<f32>) -> vec3<f32> {
    return select(pow((max(v,vec3(0.0))+0.055)/1.055,vec3(2.4)),v/12.92,v<=vec3(0.04045));
}
fn straight(c: vec4<f32>) -> vec4<f32> { return vec4(select(vec3(0.0),c.rgb/max(c.a,0.000001),c.a>0.000001),c.a); }
fn convert_pixel(pixel: vec4<f32>, src_mode: vec2<f32>, dst_mode: vec2<f32>) -> vec4<f32> {
    var c=pixel; if src_mode.y == 0.0 { c=straight(c); }
    if src_mode.x != dst_mode.x { if dst_mode.x == 1.0 { c=vec4(srgb_encode(c.rgb),c.a); } else { c=vec4(srgb_decode(c.rgb),c.a); } }
    if dst_mode.y == 0.0 { c=vec4(c.rgb*c.a,c.a); } return c;
}
"#;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct GlslShader {
    pub vertex: String,
    pub fragment: String,
    /// GLSL uniform block name -> SDK (group,binding).
    pub blocks: BTreeMap<String, [u32; 2]>,
    /// Combined sampler name -> SDK texture (group,binding).
    pub textures: BTreeMap<String, [u32; 2]>,
}
#[derive(Clone, Debug)]
pub struct CompiledShader {
    pub wgsl: String,
    pub glsl: GlslShader,
    pub sprite: bool,
    pub additive: bool,
    /// Existing portable-source validation metric; not a texture-sample count.
    pub loop_work: u64,
}

fn portable_source(source: &str) -> Result<u64> {
    ensure(source.len() <= 256 * 1024, "shader source exceeds 256 KiB")?;
    let comments = regex::Regex::new(r"(?s)/\*.*?\*/|//[^\n]*").unwrap();
    let text = comments.replace_all(source, " ");
    let forbidden =
        regex::Regex::new(r"\b(?:while|loop)\b|@(?:group|binding|compute|vertex|fragment)\b")
            .unwrap();
    ensure(
        !forbidden.is_match(&text),
        "shader must use host entry points/bindings and statically bounded for loops",
    )?;
    let loops = regex::Regex::new(r"\bfor\s*\(([^)]*)\)").unwrap();
    let bounds=regex::Regex::new(r"^\s*var\s+(?P<counter>[a-zA-Z_][a-zA-Z0-9_]*)(?:\s*:\s*(?P<type>i32|u32))?\s*=\s*(?P<start>-?\d+)(?P<suffix>[iu])?\s*;\s*(?P<test>[a-zA-Z_][a-zA-Z0-9_]*)\s*(?P<comparison><|<=)\s*(?P<end>-?\d+)[iu]?\s*;\s*(?P<lhs>[a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(?P<rhs>[a-zA-Z_][a-zA-Z0-9_]*)\s*\+\s*1[iu]?\s*$").unwrap();
    let mut work = 1u64;
    let body = loops.replace_all(&text, "");
    for lp in loops.captures_iter(&text) {
        let b = bounds.captures(&lp[1]).ok_or_else(|| {
            Error::Invalid("for loop requires literal bounds and unit increment".into())
        })?;
        ensure(
            b["counter"] == b["test"] && b["counter"] == b["lhs"] && b["counter"] == b["rhs"],
            "inconsistent loop variable",
        )?;
        let writes = regex::Regex::new(&format!(
            r"\b{}\s*(?:=[^=]|[+*/%-]=|\+\+|--)|&\s*\b{}\b",
            &b["counter"], &b["counter"]
        ))
        .unwrap();
        ensure(
            !writes.is_match(&body),
            "loop counters cannot be written or borrowed in loop bodies",
        )?;
        let start: i64 = b["start"]
            .parse()
            .map_err(|_| Error::Invalid("invalid loop bound".into()))?;
        let end: i64 = b["end"]
            .parse()
            .map_err(|_| Error::Invalid("invalid loop bound".into()))?;
        // Untyped integer var initializers materialize as i32, unless suffixed u.
        let unsigned = b.name("type").map_or_else(
            || b.name("suffix").is_some_and(|s| s.as_str() == "u"),
            |ty| ty.as_str() == "u32",
        );
        let count = loop_iterations(start, end, &b["comparison"] == "<=", unsigned)?;
        work = work.saturating_mul(count.max(1));
        ensure(work <= 65536, "shader static loop work exceeds limit")?;
    }
    Ok(work)
}

fn loop_iterations(start: i64, end: i64, inclusive: bool, unsigned: bool) -> Result<u64> {
    let (minimum, maximum) = if unsigned { (0, i64::from(u32::MAX)) }
        else { (i64::from(i32::MIN), i64::from(i32::MAX)) };
    ensure((minimum..=maximum).contains(&start) && (minimum..=maximum).contains(&end),
        "loop bound outside counter's 32-bit range")?;
    // An inclusive maximum would execute a unit increment past the counter's range.
    ensure(!inclusive || end < maximum, "loop counter can overflow at inclusive bound")?;
    let count = end.checked_sub(start).and_then(|n| n.checked_add(i64::from(inclusive)))
        .ok_or_else(|| Error::Invalid("loop iteration count overflow".into()))?.max(0) as u64;
    ensure(count <= 1024, "loop exceeds 1024 iterations")?;
    Ok(count)
}

pub fn compile(source: &str, entry: &str) -> Result<CompiledShader> {
    compile_mode(source, entry, false, false)
}
pub fn compile_mode(
    source: &str,
    entry: &str,
    sprite: bool,
    additive: bool,
) -> Result<CompiledShader> {
    compile_internal(source, entry, sprite, additive, false, false, false)
}
/// SDK 3 rectangles may write directly to the host's composition target.
pub(crate) fn compile_rect_image(source: &str, entry: &str) -> Result<CompiledShader> {
    compile_internal(source, entry, false, false, true, false, false)
}
pub(crate) fn compile_spatial_image(source: &str, entry: &str) -> Result<CompiledShader> {
    compile_internal(source, entry, false, false, true, true, false)
}
pub(crate) fn compile_spatial_v6(source:&str,entry:&str)->Result<CompiledShader> {
    compile_internal(source,entry,false,false,true,true,true)
}
fn compile_internal(
    source: &str,
    entry: &str,
    sprite: bool,
    additive: bool,
    convert_output: bool,
    finite_source: bool,
    coverage_mix: bool,
) -> Result<CompiledShader> {
    let loop_work = portable_source(source)?;
    ensure(
        regex::Regex::new(r"^[a-zA-Z_][a-zA-Z0-9_]*$")
            .unwrap()
            .is_match(entry),
        "invalid shader entry name",
    )?;
    let wgsl = if sprite {
        let start = HEADER.find("struct EffectVertex").unwrap();
        let end = HEADER.find("fn edge_uv").unwrap();
        let header = format!("{}{}{}", &HEADER[..start], SPRITE_VERTEX, &HEADER[end..]);
        format!("{header}\n{source}\n@fragment fn sdk_fragment(input:SpriteVertex)->@location(0) vec4<f32>{{return {entry}(input.uv,input.color,input.style);}}\n")
    } else if convert_output {
        let original = if finite_source {
            "select(sample_source(p),vec4(0.0),any(p<fx.source_region.xy)||any(p>fx.source_region.xy+fx.source_region.zw))"
        } else { "sample_source(p)" };
        let mix=if coverage_mix {
            format!("let original={original};let filtered={entry}(p);var c=mix(original,filtered,fx.output_mode.z);if fx.mode.z>0.5 {{let alpha=c.a;let rgb=mix(original.rgb*original.a,filtered.rgb*filtered.a,fx.output_mode.z);c=vec4(rgb/max(alpha,0.000001),alpha);}}")
        }else{format!("let c=mix({original},{entry}(p),fx.output_mode.z);")};
        format!("{HEADER}\n{source}\n@fragment fn sdk_fragment(input:EffectVertex)->@location(0) vec4<f32>{{let p=fx.region.xy+input.uv*fx.region.zw;{mix}if all(fx.mode.yz==fx.output_mode.xy) {{return c;}} return convert_pixel(c,fx.mode.yz,fx.output_mode.xy);}}\n")
    } else {
        format!("{HEADER}\n{source}\n@fragment fn sdk_fragment(input:EffectVertex)->@location(0) vec4<f32>{{let p=fx.region.xy+input.uv*fx.region.zw;return mix(sample_source(p),{entry}(p),fx.output_mode.z);}}\n")
    };
    let wgsl = legacy_select::normalize(&wgsl).into_owned();
    let module = naga::front::wgsl::parse_str(&wgsl).map_err(|cause| Error::ShaderParse {
        message: cause.emit_to_string(&wgsl),
        cause: Box::new(cause),
    })?;
    ensure(
        module.global_variables.len() == 15,
        "plugin shaders cannot declare additional global bindings",
    )?;
    ensure(
        module
            .functions
            .iter()
            .map(|(_, f)| f.expressions.len())
            .sum::<usize>()
            <= 65536,
        "shader expression budget exceeded",
    )?;
    let info = Validator::new(ValidationFlags::all(), Capabilities::empty())
        .validate(&module)
        .map_err(|cause| Error::ShaderValidation {
            context: "WGSL validation",
            cause: Box::new(cause),
        })?;
    let glsl = host_glsl(&module, &info, "sdk_vertex", "sdk_fragment")?;
    Ok(CompiledShader { wgsl, glsl, sprite, additive, loop_work })
}

/// Host-owned geometry programs use the same Naga reflection and ES compiler.
/// Package shaders still pass through the SDK binding and instruction checks.
pub fn compile_host_program(source: &str, vertex: &str, fragment: &str) -> Result<GlslShader> {
    let module=naga::front::wgsl::parse_str(source).map_err(|cause|Error::ShaderParse {
        message: cause.emit_to_string(source), cause: Box::new(cause),
    })?;
    let info=Validator::new(ValidationFlags::all(),Capabilities::empty()).validate(&module)
        .map_err(|cause|Error::ShaderValidation {
            context: "host WGSL validation", cause: Box::new(cause),
        })?;
    host_glsl(&module,&info,vertex,fragment)
}
fn host_glsl(module: &naga::Module, info: &naga::valid::ModuleInfo, vertex: &str, fragment: &str) -> Result<GlslShader> {
    let options = glsl::Options {
        version: glsl::Version::new_gles(300),
        ..Default::default()
    };
    let mut result = GlslShader {
        vertex: String::new(),
        fragment: String::new(),
        blocks: BTreeMap::new(),
        textures: BTreeMap::new(),
    };
    for (stage, ep) in [
        (ShaderStage::Vertex, vertex),
        (ShaderStage::Fragment, fragment),
    ] {
        let mut output = String::new();
        let pipeline = glsl::PipelineOptions {
            shader_stage: stage,
            entry_point: ep.into(),
            multiview: None,
        };
        let mut writer = glsl::Writer::new(
            &mut output,
            &module,
            &info,
            &options,
            &pipeline,
            naga::proc::BoundsCheckPolicies::default(),
        )
        .map_err(|cause| Error::ShaderGlsl {
            phase: "writer_init", stage,
            cause: Box::new(cause),
        })?;
        let reflection = writer
            .write()
            .map_err(|cause| Error::ShaderGlsl {
                phase: "writer_output", stage,
                cause: Box::new(cause),
            })?;
        for (handle, name) in reflection.uniforms {
            if let Some(b) = &module.global_variables[handle].binding {
                output = output.replace(
                    &format!("uniform {name} {{"),
                    &format!("layout(std140) uniform {name} {{"),
                );
                result.blocks.insert(name, [b.group, b.binding]);
            }
        }
        for (name, mapping) in reflection.texture_mapping {
            if let Some(b) = &module.global_variables[mapping.texture].binding {
                result.textures.insert(name, [b.group, b.binding]);
            }
        }
        if stage == ShaderStage::Vertex {
            result.vertex = output;
        } else {
            result.fragment = output;
        }
    }
    Ok(result)
}

/// Screen-space rectangles projected by the host; 48 bytes per instance.
pub const SPRITE_VERTEX: &str = r#"
struct SpriteVertex {
    @builtin(position) position: vec4<f32>,
    @location(0) uv: vec2<f32>, @location(1) color: vec4<f32>,
    @location(2) @interpolate(flat) style: vec4<f32>,
};
@vertex fn sdk_vertex(@builtin(vertex_index) index: u32,
    @location(0) rect: vec4<f32>, @location(1) color: vec4<f32>, @location(2) style: vec4<f32>) -> SpriteVertex {
    let p=vec2(select(-0.5,0.5,index==2u||index==3u||index==5u),select(-0.5,0.5,index==0u||index==2u||index==3u)); var out:SpriteVertex;
    out.position=vec4(rect.xy+p*rect.zw,0.0,1.0);
    out.uv=vec2(p.x+0.5,0.5-p.y); out.color=color; out.style=style; return out;
}
"#;

#[cfg(test)]
mod loop_bounds_tests {
    use super::*;

    #[test]
    fn extreme_literal_boundaries_never_panic_or_bypass_the_portable_gate() {
        for (ty, suffix, min, max) in [("i32", "i", i64::from(i32::MIN), i64::from(i32::MAX)),
            ("u32", "u", 0, i64::from(u32::MAX))] {
            let values = [i64::MIN, min-1, min, min+1, 0, 1024, max-1, max, max+1, i64::MAX];
            for start in values { for end in values { for inclusive in [false, true] {
                // Independent wide arithmetic oracle for the permitted counter domain.
                let count = (i128::from(end)-i128::from(start)+i128::from(inclusive)).max(0);
                let valid = (min..=max).contains(&start) && (min..=max).contains(&end)
                    && (!inclusive || end < max) && count <= 1024;
                let comparison = if inclusive { "<=" } else { "<" };
                let source = format!("for(var i:{ty}={start}{suffix};i{comparison}{end}{suffix};i=i+1{suffix}){{}}");
                let result = portable_source(&source);
                assert_eq!(result.is_ok(), valid, "{source}: {result:?}");
                if valid { assert_eq!(result.unwrap(), (count as u64).max(1)); }
            } } }
        }
    }

    #[test]
    fn inferred_types_and_counter_wrap_are_checked_before_naga() {
        for source in [
            "for(var i=2147483647;i<=2147483647;i=i+1){}",
            "for(var i=4294967295u;i<=4294967295u;i=i+1u){}",
            "for(var i:u32=0u;i<-1;i=i+1u){}",
            "for(var i:i32=-9223372036854775808;i<=9223372036854775807;i=i+1){}",
            "for(var i=99999999999999999999999999;i<0;i=i+1){}",
        ] { assert!(portable_source(source).is_err(), "{source}"); }
        assert_eq!(portable_source("for(var i=4294967294u;i<4294967295u;i=i+1u){}").unwrap(), 1);
        assert_eq!(portable_source("for(var i:i32=0;i<256;i=i+1){for(var j:i32=0;j<256;j=j+1){}}").unwrap(), 65536);
        assert!(portable_source("for(var i:i32=0;i<257;i=i+1){for(var j:i32=0;j<256;j=j+1){}}").is_err());
    }
}
