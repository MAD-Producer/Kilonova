"""Source-frozen native-annotation ownership regression, separate from G."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, sys
root=Path('E:/Dev/aem');work=root/'.worktrees/render-dag-refinement'
label=sys.argv[1];assert re.fullmatch(r'v[0-9]+',label)
out=root/'artifacts/pr-queue'/('issue78-c1-'+label);out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
 names=set(subprocess.check_output(['git','ls-files','-z'],cwd=work).split(b'\0'))
 names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=work).split(b'\0'))
 return {p.decode():sha(work/p.decode()) for p in sorted(names) if p and (work/p.decode()).is_file() and (p.endswith(b'.rs') or p.endswith(b'Cargo.toml') or p==b'Cargo.lock')}
inputs=sources();env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/ai-depth74-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='1',MOTION_EXECUTION_ARTIFACTS=str(out/'output-artifacts'))
env.pop('MOTION_LOG',None)
commands=[('render-library',['cargo','test','-p','motion-render','--lib','--locked','--offline','--','--test-threads=1']),
 ('native-regression',['cargo','test','-p','motion-render','--locked','--offline','--test','typed_snapshot_execution','--test','runtime_execution_template','--test','pointwise_fusion','--test','typed_group_invalidation','--test','pointwise_extreme_alpha','--','--test-threads=1'])]
receipt=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),source=inputs,controllerPid=os.getpid(),startedUtc=datetime.now(timezone.utc).isoformat(),steps=[])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
for path in inputs:
 if path.startswith('crates/motion-render/src/effect_plan/'):
  dest=out/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((work/path).read_bytes())
for name,cmd in commands:
 stage=out/name;stage.mkdir();item=dict(name=name,command=cmd);receipt['steps'].append(item)
 print(json.dumps(dict(starting=name,output=str(stage))),flush=True)
 with (stage/'stdout.log').open('wb') as stdout,(stage/'stderr.log').open('wb') as stderr:
  child=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr);item['pid']=child.pid
  (out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');code=child.wait()
 item.update(exitCode=code,sourceUnchanged=inputs==sources(),stdoutSha256=sha(stage/'stdout.log'),stderrSha256=sha(stage/'stderr.log'))
 (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
 assert item['sourceUnchanged'],'source changed during gate'
 if code:sys.exit(code)
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (stage/'stdout.log').read_text(encoding='utf-8'))
 assert rows and sum(int(r[0]) for r in rows)>0 and all(int(r[1])==0 and int(r[2])==0 for r in rows)
 item['passes']=sum(int(r[0]) for r in rows)
 print(json.dumps(dict(completed=name,passed=item['passes'])),flush=True)
receipt['completedUtc']=datetime.now(timezone.utc).isoformat()
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,output=str(out))),flush=True)
