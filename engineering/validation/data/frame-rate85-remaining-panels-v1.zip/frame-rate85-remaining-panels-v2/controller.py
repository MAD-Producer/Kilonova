from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root=Path('E:/Dev/aem')
work=root/'.worktrees/tracking-import88'
out=root/'artifacts/pr-queue/frame-rate85-remaining-panels-v2'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files','-z','crates','desktop','Cargo.toml','Cargo.lock'],cwd=work).decode().split('\0')
sources={name:sha(work/name) for name in paths if name and (work/name).is_file()}
dirty=subprocess.check_output(['git','diff','--name-only'],cwd=work).decode().splitlines()
assert len(dirty)==10 and all(name.startswith('desktop/app/src/panels/') for name in dirty)
os.environ.pop('MOTION_LOG',None)
os.environ['LOCALAPPDATA']=str(out/'local-app-data')
Path(os.environ['LOCALAPPDATA']).mkdir()
os.environ['MOTION_PANEL_CLOCK_FAULT_ARTIFACTS']=str(out/'clock-faults')
tests=[
    'panels::helpers::rational_clock_tests::project_clock_is_strict_and_timecode_uses_nominal_labels_without_decimal_rounding',
    'panels::helpers::rational_clock_tests::project_clock_real_faults_emit_default_file_and_stderr_once_per_lifetime_and_reset_per_process',
    'panels::audio::waveform::tests::rational_waveform_request_preserves_subframe_source_time_and_rejects_numeric_clocks',
    'panels::audio::waveform::tests::audio_waveform_request_maps_video_audio_offset_subframe_clip_and_composition_identity',
    'panels::tests::timecodes_step_frames_without_rounding_fractional_time',
]
commands=[('check-tests',['cargo','check','-p','motion-desktop','--tests','--locked','--offline'])]
commands += [(f'test-{i:02}', ['cargo','test','-p','motion-desktop','--bin','motion-studio','--locked','--offline',test,'--','--exact','--test-threads=1']) for i,test in enumerate(tests,1)]
report=dict(status='running',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),branch=subprocess.check_output(['git','branch','--show-current'],cwd=work).decode().strip(),startedUtc=datetime.now(timezone.utc).isoformat(),scope='Ten additional user-approved panel clock files on parent85; compile all desktop tests and run exactly five CPU/model clock/request tests including actual file/stderr/stdout lifetime/process-reset proof. Separate source tree/target from live full renderer; no second GPU workload, full desktop or final acceptance claim.',dirtyFiles=dirty,sources=sources,results=[])
save=lambda:(out/'exit.json').write_bytes((json.dumps(report,indent=2)+'\n').encode('utf-8'))
start=time.monotonic()
save()
try:
    for name,command in commands:
        item=dict(name=name,command=command,status='running',startedUtc=datetime.now(timezone.utc).isoformat())
        report['results'].append(item)
        save()
        began=time.monotonic()
        with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
            child=subprocess.Popen(command,cwd=work,env=os.environ.copy(),stdout=stdout,stderr=stderr)
            item['pid']=child.pid
            save()
            item['exitCode']=child.wait()
        item['elapsedSeconds']=round(time.monotonic()-began,3)
        item['summaries']=re.findall(r'^test result: .+$',(out/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
        item['status']='passed' if item['exitCode']==0 else 'failed'
        if name!='check-tests' and item['exitCode']==0:
            assert len(item['summaries'])==1 and '1 passed; 0 failed; 0 ignored;' in item['summaries'][0]
        save()
        print(json.dumps(item),flush=True)
        if item['exitCode']!=0: break
    report['sourceUnchanged']=all(sha(work/name)==digest for name,digest in sources.items())
    report['status']='passed_focused_acceptance_pending' if len(report['results'])==len(commands) and all(item['status']=='passed' for item in report['results']) and report['sourceUnchanged'] else 'failed_original_results_retained'
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-start,3))
    save()
    print(json.dumps({k:v for k,v in report.items() if k!='sources'}),flush=True)
raise SystemExit(0 if report['status']=='passed_focused_acceptance_pending' else 1)
