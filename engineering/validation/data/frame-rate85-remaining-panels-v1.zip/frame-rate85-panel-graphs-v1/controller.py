from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root=Path('E:/Dev/aem')
work=root/'.worktrees/tracking-import88'
out=root/'artifacts/pr-queue/frame-rate85-panel-graphs-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files','-z','crates','desktop','Cargo.toml','Cargo.lock'],cwd=work).decode().split('\0')
sources={name:sha(work/name) for name in paths if name and (work/name).is_file()}
dirty=subprocess.check_output(['git','diff','--name-only'],cwd=work).decode().splitlines()
assert len(dirty)==10 and all(name.startswith('desktop/app/src/panels/') for name in dirty)
os.environ.pop('MOTION_LOG',None)
os.environ['LOCALAPPDATA']=str(out/'local-app-data')
Path(os.environ['LOCALAPPDATA']).mkdir()
os.environ['MOTION_PANEL_CLOCK_FAULT_ARTIFACTS']=str(out/'clock-faults')
tests=['panels::curve_comparison::tests::local_offsets_physical_units_and_signed_separated_axes_follow_actual_samples', 'panels::curve_comparison::tests::samples_reuse_the_revision_cache_while_visibility_and_graph_modes_leave_the_project_unchanged', 'panels::graph_ranges::tests::comparison::comparison_fit_selection_uses_only_its_unit_group_and_composition_time_without_history', 'panels::graph_ranges::tests::comparison::comparison_axis_locks_are_per_unit_and_automatic_preserves_other_unit_and_legacy_y', 'panels::graph_ranges::tests::effect::effect_range_menu_fits_local_keys_once_and_retains_native_values_and_per_second_speed', 'panels::graph_ranges::tests::effect::effect_locks_survive_playback_wheel_and_main_float_escape_consumes_the_key', 'panels::effect_timeline::graph::tests::stretched_and_reversed_effect_samples_fit_signed_speed_and_keep_jump_neighbors', 'panels::graph_ranges::tests::rational_rate_changes_reset_graph_ranges_but_equivalent_ratios_preserve_navigation']
commands=[('check-tests',['cargo','check','-p','motion-desktop','--tests','--locked','--offline'])]
commands += [(f'test-{i:02}', ['cargo','test','-p','motion-desktop','--bin','motion-studio','--locked','--offline',test,'--','--exact','--test-threads=1']) for i,test in enumerate(tests,1)]
report=dict(status='running',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),branch=subprocess.check_output(['git','branch','--show-current'],cwd=work).decode().strip(),startedUtc=datetime.now(timezone.utc).isoformat(),scope='Ten additional user-approved panel clock files on parent85; compile all desktop tests and run exactly eight existing CPU graph paint/sampling/cache/navigation tests using model Engine, CPU PaintList and TextAtlas; no GPU device or native window. Separate source tree/target from live full renderer; no second GPU workload, full desktop or final acceptance claim.',dirtyFiles=dirty,sources=sources,results=[])
save=lambda:(out/'exit.json').write_bytes((json.dumps(report,indent=2)+'\n').encode('utf-8'))
start=time.monotonic()
save()
try:
    for name,command in commands:
        item=dict(name=name,command=command,status='running',startedUtc=datetime.now(timezone.utc).isoformat())
        report['results'].append(item)
        save()
        began=time.monotonic()
        with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
            child=subprocess.Popen(command,cwd=work,env=os.environ.copy(),stdout=stdout,stderr=stderr)
            item['pid']=child.pid
            save()
            item['exitCode']=child.wait()
        item['elapsedSeconds']=round(time.monotonic()-began,3)
        item['summaries']=re.findall(r'^test result: .+$',(out/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
        item['status']='passed' if item['exitCode']==0 else 'failed'
        if name!='check-tests' and item['exitCode']==0:
            assert len(item['summaries'])==1 and '1 passed; 0 failed; 0 ignored;' in item['summaries'][0]
        save()
        print(json.dumps(item),flush=True)
        if item['exitCode']!=0: break
    report['sourceUnchanged']=all(sha(work/name)==digest for name,digest in sources.items())
    report['status']='passed_focused_acceptance_pending' if len(report['results'])==len(commands) and all(item['status']=='passed' for item in report['results']) and report['sourceUnchanged'] else 'failed_original_results_retained'
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-start,3))
    save()
    print(json.dumps({k:v for k,v in report.items() if k!='sources'}),flush=True)
raise SystemExit(0 if report['status']=='passed_focused_acceptance_pending' else 1)
