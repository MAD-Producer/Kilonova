from pathlib import Path
import hashlib
import json
import zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-import88'
archive = work / 'engineering/validation/data/frame-rate85-remaining-panels-v1.zip'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
entries = {}
runs = {}
unique = set()
names = ['frame-rate85-remaining-panels-v1', 'frame-rate85-remaining-panels-v2', 'frame-rate85-panel-graphs-v1']
for name in names:
    folder = root / 'artifacts/pr-queue' / name
    report = json.loads((folder / 'exit.json').read_text())
    assert report['status'] == 'passed_focused_acceptance_pending' and report['sourceUnchanged']
    if name != names[0]:
        assert all(sha(work / path) == digest for path, digest in report['sources'].items())
    for item in report['results']:
        assert item['status'] == 'passed' and item['exitCode'] == 0
        if item['name'].startswith('test-'):
            unique.add(item['command'][item['command'].index('--offline') + 1])
    runs[name] = {k: v for k, v in report.items() if k != 'sources'}
    for path in folder.rglob('*'):
        if path.is_file():
            entries[f'{name}/{path.relative_to(folder).as_posix()}'] = path
assert len(unique) == 13
for name in report['dirtyFiles']:
    entries[f'validated-source/{name}'] = work / name
proposal = root / 'target/silent-failure-validation/frame-rate85-remaining-panels-v1'
for name in ['proposal.patch', 'proposal.json']:
    entries[f'approved-proposal/{name}'] = proposal / name
for name in ['run-frame-rate85-remaining-panels-v1.ps1', 'run-frame-rate85-remaining-panels-v2.ps1', 'run-frame-rate85-panel-graphs-v1.ps1', 'publish-frame-rate85-remaining-panels-v1.py']:
    entries[f'environment/{name}'] = root / '.tools/issue-closure-review' / name
limits = [
    'Historical v1 validated the initial approved patch; v2 and graph gate validate the final ten-file source on aa4143f3',
    'Thirteen unique CPU tests: three new regressions and ten existing tests; repeated v1/v2 tests count once',
    'All desktop test targets compile; complete desktop runtime, real UI readouts/screenshots and final cross-platform CI remain pending',
    'Observation counters are bounded process-lifetime sites, do not reset on success, and reset in a new process; 60 occurrences do not imply a duration',
    'Actual default-level file/Error-stderr/stdout-isolation faults and healthy suppression were exercised in two fresh processes',
    'No existing assertion, expected value, budget, ignore marker, layout, style, hit area or dependency changed',
    'DESIGN 0.7 baseline retained: timeline coordinates preserved; path_controls/effect_controls untouched; no visual-remediation claim',
    'The separate full renderer/desktop gate is still source-frozen on child162edfed and does not yet include these ten panel changes',
    'Historical native heap corruption and broader issues85/86 acceptance remain unresolved; Android is not maintained or accepted',
]
manifest = dict(status='panel_clock_adoption_focused_passed_final_acceptance_pending', sourceHead='aa4143f379a5aa64c188873e5935fec41a536868', runs=runs, uniqueTests=sorted(unique), limits=limits, entries={name: dict(bytes=path.stat().st_size, sha256=sha(path)) for name, path in entries.items()})
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    output.writestr('manifest.json', json.dumps(manifest, indent=2))
    for name, path in entries.items():
        output.write(path, name)
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    for name, details in manifest['entries'].items():
        assert hashlib.sha256(output.read(name)).hexdigest() == details['sha256']
receipt = dict(status=manifest['status'], archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=len(entries) + 1, uniqueTests=13, failed=0, ignored=0, limits=limits)
with archive.with_suffix('.json').open('x', encoding='utf-8') as output:
    json.dump(receipt, output, indent=2)
    output.write('\n')
print(json.dumps(receipt), flush=True)
