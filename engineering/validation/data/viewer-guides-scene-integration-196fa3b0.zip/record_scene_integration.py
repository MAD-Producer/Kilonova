from pathlib import Path
import json,hashlib,zipfile,subprocess
root=Path('E:/Dev/aem');work=root/'.worktrees/viewer-guides';out=root/'.tools/viewer-guides'
read=lambda path:json.loads((out/path).read_text(encoding='utf8'))
r=read('snap-stage-14/receipt.json');n=read('snap-stage-14/native-verified.json');check=read('model-integration-check-03/receipt.json')
old=read('6587894f-ci-success-receipt.json');cases=read('6587894f-desktop-cases-ci-receipt.json')
assert r['source_unchanged'] and r['build_exit_code']==0 and all(run['exit_code']==0 for run in r['runs'])
assert check['exit_code']==0 and check['source_unchanged'] and n['png_count']==22 and n['export_rgba_equal']
assert old['all_five_success'] and cases['cases_per_job']==130 and len(cases['jobs'])==3
assert r['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
assert all(hashlib.sha256((work/path).read_bytes()).hexdigest()==digest for path,digest in r['sources'].items())
files=[]
for folder in ['snap-stage-14','model-integration-check-03']:
 files.extend(path for path in (out/folder).rglob('*') if path.is_file())
files.extend(out/path for path in ['6587894f-ci-success-receipt.json','6587894f-desktop-cases-ci-receipt.json','verify_snap_stage.py','verify_native_results.py','verify_model_integration.py','record_scene_integration.py'])
files.extend(out/f'ci-job-{job["job"]}.log' for job in old['jobs'])
manifest={str(path.relative_to(out)).replace('\\','/'):hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
archive=work/('engineering/validation/data/viewer-guides-scene-integration-'+r['head'][:8]+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for path in files:z.write(path,str(path.relative_to(out)).replace('\\','/'))
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
record=dict(local_head=r['head'],base_main=r['base_main'],binary_sha256=r['binary_sha256'],targeted=r['runs'],native=n,all_targets=check,
 old_ci=dict(head=old['head'],all_five_success=True,checkout=old['jobs'][0]['checkout'],tree=old['jobs'][0]['tree'],three_desktop_jobs_130_cases_confirmed=True,
 scope='Historical all-five green; excludes later preset/shared-depth main tree as merge authorization.'),
 status='LOCAL_PRESET_SCENE_INTEGRATION_PASSED; new exact-head CI required before merge',
 archive=dict(path='data/'+archive.name,bytes=archive.stat().st_size,entries=len(files)+1,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
(work/'engineering/validation/viewer-guides-scene-integration-results.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
doc=f'''# 参考线接续预设与共享深度的组合验证

#263 功能范围与[完整验收](viewer-guides-completion.md)一致。本次同步主分支 `{r['base_main']}`，包括其他贡献者的预设、导入动画/摄影机与共享深度通道，实际源码提交 `{r['head']}`；没有重做其功能。

旧PR head `{old['head']}` 的五项有效CI全部成功，实际checkout `{old['jobs'][0]['checkout']}`、树 `{old['jobs'][0]['tree']}`。三个桌面原始日志各确认130项参考线相关回归通过，但最新主分支组合树不同，旧结果原样保留为历史证据，不能用于合并新组合。

切换工作树后强制本工作树lib根与main重新编译，完整Rust/WGSL/Cargo/样式源前后哈希一致。程序SHA-256 `{r['binary_sha256']}`。130项定向回归通过；手工原生用例在默认过滤器仍忽略，随后显式单独执行1项通过。中英文主窗/原生浮窗四案例、受控1/1.5/2比例产生22张PNG，最大线心误差 {n['maximum_line_centroid_error_physical_pixels']:.6f} 物理像素，生产PNG导出前后RGBA完全一致。实际worker成功、排队失效与故障，以及默认文件日志/Error stderr/stdout隔离沿用原断言再次运行，未放宽断言。

完整workspace all-targets（既定排除Android）与style consumer检查通过，启用diagnostics、ai-depth、ffmpeg及GPU测试编译。早期模型持久化4项与历史15项/1既有忽略保留原提交证据，不冒称本轮重跑。原生使用隐藏真实窗口与受控Input/比例，没有物理鼠标或系统DPI操作；其他平台新增原生截图、视频编码及整份DESIGN规范不在本轮声明中。12项设计基线处置与来源责任见完整验收；本次未新增依赖或第三方资产。

[原始证据包]({record['archive']['path']})：{record['archive']['entries']}项/{record['archive']['bytes']}字节，SHA-256 `{record['archive']['sha256']}`；[结构化结果](viewer-guides-scene-integration-results.json)。此记录生成时尚未合并，当前head仍须重新通过全部CI。
'''
(work/'engineering/validation/viewer-guides-scene-integration.md').write_text(doc,encoding='utf8')
p=work/'engineering/validation/viewer-guides-completion.md';p.write_text(p.read_text(encoding='utf8')+'\n后续预设与共享深度主分支组合验证、旧CI排除见[场景组合记录](viewer-guides-scene-integration.md)。\n',encoding='utf8')
print(json.dumps(dict(head=r['head'],archive=record['archive'],status=record['status']),ensure_ascii=False))
