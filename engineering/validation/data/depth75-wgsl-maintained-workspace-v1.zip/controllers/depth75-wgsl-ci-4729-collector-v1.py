"""Observe own current-head completed jobs, retaining original failures.

This does not rerun CI. A successful subset never qualifies the failed workflow.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, subprocess

BASE = Path('E:/Dev/aem/artifacts/pr-queue')
WORK = Path('E:/Dev/aem/.worktrees/depth-wgsl-cache75')
OUT = BASE / 'depth75-wgsl-ci-4729-completed-v1'
RUN = 42456771015
HEAD = '4729ab6d1c7c0c535c9715a53bc79497a78970b4'
def api(path):
    return json.loads(subprocess.check_output(['gh', 'api', 'repos/MAD-Producer/Kilonova' + path], encoding='utf-8'))
run = api(f'/actions/runs/{RUN}')
assert run['head_sha'] == HEAD and run['event'] == 'pull_request'
jobs = api(f'/actions/runs/{RUN}/jobs?per_page=100')['jobs']
expected = json.loads((BASE / 'depth75-wgsl-ci-ad4108ee/ubuntu-receipt.json').read_text())
tree = subprocess.check_output(['git', 'rev-parse', HEAD + '^{tree}'], cwd=WORK, text=True).strip()
OUT.mkdir(exist_ok=True)
report = dict(status='collecting_completed_jobs', run=RUN, head=HEAD, observed_utc=datetime.now(timezone.utc).isoformat(), jobs={}, pending=[], failed_jobs=[],
              limits=['Only completed jobs have raw logs and tested-tree qualification',
                      'Original CI failure remains failure even when other platforms pass',
                      'No test rerun, deadline/assertion/ignore changes, or actual learned-model claim'])
for job in jobs:
    if job['status'] != 'completed':
        report['pending'].append(dict(job=job['id'], name=job['name'], status=job['status']))
        continue
    if job['conclusion'] == 'skipped':
        report['jobs'][job['name']] = dict(job=job['id'], conclusion='policy_skipped')
        continue
    assert job['conclusion'] in ('success', 'failure'), 'Inspect a cancelled/timed-out job separately'
    slug = ('rust-gpu' if job['name'] == 'Rust and GPU' else 'ubuntu' if 'ubuntu-' in job['name'] else
            'windows' if 'windows-' in job['name'] else 'macos-intel' if 'macos-' in job['name'] else 'dependency-audit')
    is_build = job['name'].startswith('Desktop build (')
    if is_build: slug += '-build'
    (OUT / (slug + '.job.json')).write_text(json.dumps(job, indent=2), encoding='utf-8')
    log = OUT / (slug + '.log')
    if not log.exists():
        raw = subprocess.check_output(['gh', 'api', f'repos/MAD-Producer/Kilonova/actions/jobs/{job["id"]}/logs'])
        assert 0 < len(raw) <= 32 << 20
        log.write_bytes(raw)
    raw = log.read_bytes(); text = raw.decode('utf-8')
    merge = re.findall(r' log -1 --format=%H\r?\n[^\n]*?\b([0-9a-f]{40})\b', text)
    assert len(merge) == 1, (slug, 'Missing actual checked-out commit')
    tested = api('/git/commits/' + merge[0])
    assert tested['tree']['sha'] == tree, (slug, 'Tested merge tree differs from current branch')
    (OUT / (slug + '.tested-commit.json')).write_text(json.dumps(tested, indent=2), encoding='utf-8')
    totals = [tuple(map(int, m)) for m in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text)]
    failed_names = re.findall(r'test ([^\r\n]+?) \.\.\. FAILED\b', text)
    abnormal = [line for line in text.splitlines() if "process didn't exit successfully:" in line]
    qualified = []
    if job['conclusion'] == 'failure':
        report['failed_jobs'].append(dict(job=job['id'], name=job['name'], tests=failed_names, abnormal_exits=abnormal))
    else:
        assert not failed_names and not abnormal and not any(t[1] for t in totals)
        if is_build:
            assert any(s['name'] == 'Build the desktop shell' and s['conclusion'] == 'success' for s in job['steps'])
        elif job['name'].startswith('Desktop tests ('):
            qualified = expected['host_identity_controls'] + expected['native_admission_controls']
            for name in qualified:
                assert len(re.findall(r'test ' + re.escape(name) + r' \.\.\. ok\b', text)) == 1, (slug, name)
    report['jobs'][job['name']] = dict(job=job['id'], conclusion=job['conclusion'], tested_merge=merge[0], tested_tree=tree, merge_tree_matches_branch=True,
        log_sha256=hashlib.sha256(raw).hexdigest(), observed_summaries=len(totals), observed_passed=sum(t[0] for t in totals),
        observed_failed=sum(t[1] for t in totals), original_ignored=sum(t[2] for t in totals), observed_filtered=sum(t[4] for t in totals),
        qualified_named_controls=qualified, failed_test_names=failed_names)
report['status'] = ('failed_job_observed_workflow_pending' if report['pending'] else 'failed_workflow_original_outputs_retained') if report['failed_jobs'] else ('completed_jobs_source_bound_workflow_pending' if report['pending'] else 'all_completed_jobs_source_bound_success')
report['whole_workflow_passed'] = run['status'] == 'completed' and run['conclusion'] == 'success' and not report['pending'] and not report['failed_jobs']
report['whole_workflow_status'] = run['status']; report['whole_workflow_conclusion'] = run['conclusion']
(OUT / 'receipt.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
