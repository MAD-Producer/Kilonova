"""Preserve source-bound terminal workspace and CI evidence as bounded text."""
from pathlib import Path
import hashlib
import json
import zipfile

BASE = Path('E:/Dev/aem/artifacts/pr-queue')
OUT = BASE / 'depth75-wgsl-maintained-workspace-public-v1'
source = BASE / 'depth75-wgsl-maintained-workspace-v1'
result = json.loads((source / 'receipt.json').read_text())
consumed = json.loads((source / 'session-consumed.json').read_text())
assert result['status'] == 'complete_maintained_workspace_desktop_gpu_ffmpeg_passed'
assert result['source_unchanged'] and result['full_target_coverage']
assert consumed == dict(session=27030, consumed=True, exit_code=0)
assert len(result['named_passes']) == len(result['expected_named_controls']) == 84
assert result['totals'] == dict(passed=5240, failed=0, original_ignored=78,
    filtered=0, summary_count=447, observed_invocations=447, expected_invocations=447)
assert not result['abnormal_target_exits']
files = {}

def put(folder, name):
    path = BASE / folder / name
    raw = path.read_bytes()
    assert path.suffix in ('.json', '.log', '.py') and len(raw) <= 4 << 20
    files[folder + '/' + name] = raw

for name in ('receipt.json', 'session-consumed.json', 'cargo-metadata.json',
             'workspace.stdout.log', 'workspace.stderr.log'):
    put(source.name, name)
for name in ('depth75-wgsl-maintained-workspace-v1-controller.py',
             'depth75-wgsl-ci-4729-collector-v1.py'):
    raw = (BASE / name).read_bytes()
    assert len(raw) <= 256 << 10
    files['controllers/' + name] = raw
ci = json.loads((BASE / 'depth75-wgsl-ci-4729-completed-v1/receipt.json').read_text())
assert ci['whole_workflow_conclusion'] == 'failure'
put('depth75-wgsl-ci-4729-completed-v1', 'receipt.json')
put('depth75-wgsl-ci-4729-failure-v1', 'receipt.json')
files['controllers/archive.py'] = Path(__file__).read_bytes()
manifest = dict(version=1, head=result['head'], status=result['status'],
    totals=result['totals'], named_controls=84,
    members={name: dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
             for name, raw in files.items()}, limits=[
    'Windows local maintained workspace, GPU, FFmpeg and AI-depth at exact4729 source; Android excluded',
    'Original assertions, features, ignores and budgets preserved; no filtered tests or abnormal exits',
    'Separate exact4729 remote workflow failed an original expression frame deadline; not a whole-CI pass',
    'Historical compiler and native crashes remain unresolved and preserved elsewhere',
    'Does not qualify later capability code, photographic quality, sustained load or thermal behavior',
    'Bounded text only; no weights, binaries, media, depth tensors or unbounded environment values'])
OUT.mkdir(exist_ok=False)
archive = OUT / 'depth75-wgsl-maintained-workspace-v1.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in files.items():
        z.writestr(name, raw)
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(files) | {'manifest.json'}
    for name, raw in files.items():
        assert z.read(name) == raw
    assert json.loads(z.read('manifest.json')) == manifest
receipt = dict(status=manifest['status'], head=result['head'], archive=archive.name,
    bytes=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    members_readback_verified=len(files)+1, totals=result['totals'], limits=manifest['limits'])
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps(receipt))
