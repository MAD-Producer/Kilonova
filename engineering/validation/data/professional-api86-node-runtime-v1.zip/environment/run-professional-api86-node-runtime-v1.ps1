$ErrorActionPreference = 'Stop'
. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:CARGO_HOME = 'E:/Dev/aem/.tools/prerender-cargo-home'
$env:CARGO_TARGET_DIR = 'E:/Dev/aem/target/rational-rate85-contract'
$env:CARGO_INCREMENTAL = '0'
$env:CARGO_PROFILE_DEV_DEBUG = '0'
$env:CARGO_PROFILE_TEST_DEBUG = '0'
$env:CARGO_BUILD_JOBS = '1'
$env:TEMP = 'E:/Dev/aem/target/ci-policy-validation-tmp'
$env:TMP = $env:TEMP
$env:LIBCLANG_PATH = 'E:/Dev/aem/.tools/python-libclang/clang/native'
$env:FFMPEG_DIR = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:PATH = "$env:FFMPEG_DIR/bin;$env:PATH"
& E:/Dev/aem/.tools/ai-depth74/venv/Scripts/python.exe E:/Dev/aem/.tools/issue-closure-review/validate-professional-api86-node-runtime-v1.py
exit $LASTEXITCODE
