from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/professional-api86-backend-regression-v2'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = {p.relative_to(work).as_posix():sha(p) for folder in ['crates','desktop'] for p in (work / folder).rglob('*.rs')}
report = dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),sources=sources,results=[],
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),
    scope='Complete model/core/host/desktop-media packages on this exact source, default GPU test features and actual FFmpeg enabled, no fail-fast, serial test execution. Existing ignored manual tests are counted and reported; desktop app/panels and Android excluded. Not complete 3D route or cross-platform acceptance')
save = lambda: (out / 'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
for key, folder in [('MOTION_PROFESSIONAL_API_ARTIFACTS','native-shot'),('MOTION_PROFESSIONAL_SCREEN_ARTIFACTS','screen-shot'),('MOTION_PROFESSIONAL_RELINK_ARTIFACTS','relink-shot'),('MOTION_PROFESSIONAL_MATTE_ARTIFACTS','matte-shot'),('MOTION_NODE_PARAMETER_ARTIFACTS','node-runtime')]:
    os.environ[key] = str(out / folder)
started = time.monotonic()
save()
try:
    commands = [('complete-model-core-host-desktop-media',['cargo','test','-p','motion-model','-p','motion-core','-p','motion-host','-p','motion-desktop-media','--features','motion-desktop-media/ffmpeg','--no-fail-fast','--locked','--offline','--','--test-threads=1'])]
    for name,command in commands:
        item = dict(name=name,command=command,status='running')
        report['results'].append(item)
        save()
        began = time.monotonic()
        with (out / f'{name}.stdout.log').open('wb') as stdout,(out / f'{name}.stderr.log').open('wb') as stderr:
            child = subprocess.Popen(command,cwd=work,env=os.environ.copy(),stdout=stdout,stderr=stderr)
            item['pid'] = child.pid
            save()
            item['exitCode'] = child.wait()
        item['elapsedSeconds'] = round(time.monotonic()-began,3)
        item['summaries'] = re.findall(r'^test result: .+$',(out / f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
        item['status'] = 'passed' if item['exitCode'] == 0 else 'failed'
        save()
        print(json.dumps({key:item[key] for key in ['name','exitCode','status','elapsedSeconds']} | {'summaries':len(item['summaries'])}),flush=True)
    report['sourceUnchanged'] = all(sha(work / path) == digest for path,digest in sources.items())
    assert report['sourceUnchanged'] and all(item['exitCode'] == 0 for item in report['results']), 'host parameter gate failed; original logs retained'
    assert all(len(item['summaries']) > 20 and all('0 failed;' in summary for summary in item['summaries']) for item in report['results'])
    report['status'] = 'complete_backend_regression_passed_full_issue_acceptance_pending'
except BaseException as cause:
    report.update(status='failed',failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-started,3))
    save()
    print(json.dumps({key:report.get(key) for key in ['status','sourceUnchanged','elapsedSeconds','failure']}),flush=True)

