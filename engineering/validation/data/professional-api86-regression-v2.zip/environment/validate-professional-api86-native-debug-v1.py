from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/professional-api86-native-debug-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
helper = root / 'target/ci-policy-validation-tmp/native-test-debugger86.exe'
binary = root / 'target/rational-rate85-contract/debug/deps/professional_screen-edca7f02fca39a46.exe'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = {p.relative_to(work).as_posix(): sha(p) for folder in ['crates', 'desktop', 'tools', '.github'] for p in (work / folder).rglob('*') if p.is_file() and p.suffix in ['.rs', '.wgsl', '.py', '.yml', '.toml']}
sources.update({p: sha(work / p) for p in ['Cargo.toml', 'Cargo.lock']})
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip(), sources=sources, scope='Eight bounded independent process launches under an external Windows debugger to investigate the observed native heap corruption. No retries hiding failures, no product changes, not a stability fix.', binary=str(binary), binarySha256=sha(binary), helperSha256=sha(helper), runs=[])
(out / 'debugger.cpp').write_bytes((root / '.tools/issue-closure-review/native-test-debugger86.cpp').read_bytes())
save = lambda: (out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
save()
start = time.monotonic()
try:
    for index in range(8):
        case = out / f'case-{index + 1}'
        case.mkdir()
        env = os.environ.copy()
        env['MOTION_PROFESSIONAL_SCREEN_ARTIFACTS'] = str(case / 'screen-shot')
        env['WGPU_BACKEND'] = 'vulkan'
        command = [str(helper), str(binary), str(case / 'native-crash.dmp')]
        run = dict(index=index + 1, command=command, startedUtc=datetime.now(timezone.utc).isoformat())
        report['runs'].append(run)
        save()
        with (case / 'stdout.log').open('wb') as stdout, (case / 'stderr.log').open('wb') as stderr:
            child = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
            run['controllerPid'] = child.pid
            save()
            run['exitCode'] = child.wait()
        run['completedUtc'] = datetime.now(timezone.utc).isoformat()
        run['dumpPresent'] = (case / 'native-crash.dmp').is_file()
        text = (case / 'stdout.log').read_text(encoding='utf-8', errors='replace')
        run['oneTestPassed'] = '1 passed; 0 failed; 0 ignored' in text
        save()
        print(json.dumps(run), flush=True)
        if run['exitCode'] != 0 or not run['oneTestPassed']:
            report['status'] = 'failed_native_issue_unresolved'
            break
    else:
        report['status'] = 'not_reproduced_native_issue_unresolved'
    report['sourceUnchanged'] = all(sha(work / p) == digest for p, digest in sources.items())
    assert report['sourceUnchanged']
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - start, 3))
    save()
    print(json.dumps({k:v for k,v in report.items() if k != 'sources'}), flush=True)
if report['status'] == 'failed_native_issue_unresolved':
    raise SystemExit(1)
