from pathlib import Path
import hashlib
import json
import struct

root = Path('E:/Dev/aem')
dump = root / 'target/ci-policy-validation-tmp/native-debugger86-control.dmp'
data = dump.read_bytes()
signature, version, count, directory = struct.unpack_from('<4I', data)
assert signature == 0x504d444d
streams = [struct.unpack_from('<3I', data, directory + i * 12) for i in range(count)]
exception = next(rva for kind, size, rva in streams if kind == 6)
thread_id = struct.unpack_from('<I', data, exception)[0]
code = struct.unpack_from('<I', data, exception + 8)[0]
context_size, context_rva = struct.unpack_from('<2I', data, exception + 160)
assert code == 0xe0860001 and context_size > 0 and context_rva + context_size <= len(data)
thread_stream = next(rva for kind, size, rva in streams if kind == 3)
thread_count = struct.unpack_from('<I', data, thread_stream)[0]
assert thread_count >= 1
out = root / 'artifacts/pr-queue/professional-api86-native-debug-v1'
receipt = dict(scope='Diagnostic launcher self-check only: a separate self-authored control raises an unhandled exception, not a product failure or a heap-corruption reproduction', exceptionCode=hex(code), threadId=thread_id, contextBytes=context_size, threadCount=thread_count, dumpBytes=len(data), dumpSha256=hashlib.sha256(data).hexdigest(), cleanControlDumpAbsent=not (root / 'target/ci-policy-validation-tmp/native-debugger86-clean.dmp').exists(), nativeIssue='unresolved', limitation='The control proves dump capture on an unhandled raised exception. It does not prove every fail-fast, process termination or original heap corruption will yield a dump.')
assert receipt['cleanControlDumpAbsent']
(out / 'capture-control.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
(out / 'capture-control.cpp').write_bytes((root / '.tools/issue-closure-review/native-debugger86-control.cpp').read_bytes())
(out / 'capture-control-parser.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(receipt), flush=True)
