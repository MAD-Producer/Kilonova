from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
folder = root / 'artifacts/pr-queue/frame-rate85-tracking-integration-v1'
failed = root / 'artifacts/pr-queue/professional-api86-combined-main-v1'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
failure = json.loads((failed/'exit.json').read_text(encoding='utf-8'))
assert failure['status']=='failed_original_results_retained' and failure['sourceUnchanged']
assert failure['results'][0]['exitCode']==101
stdout = (folder/'tracking.stdout.log').read_text(encoding='utf-8')
summaries = re.findall(r'^test result: .+$', stdout, re.M)
assert len(summaries)==3
assert all('0 failed; 0 ignored;' in line for line in summaries)
assert sum(int(re.search(r'(\d+) passed;', line).group(1)) for line in summaries)==28
assert 'Finished `dev` profile' in (folder/'check.stderr.log').read_text(encoding='utf-8')
changes = subprocess.check_output(['git','diff','--name-only'], cwd=work).decode().splitlines()
assert len(changes)==6 and all(name.startswith('crates/motion-model/') for name in changes)
entries = {f'combined-main-original/{p.name}':p for p in failed.iterdir() if p.is_file()}
entries.update({f'tracking-integration/{p.name}':p for p in folder.iterdir() if p.is_file()})
entries.update({f'validated-source/{name}':work/name for name in changes})
entries['publisher.py'] = Path(__file__)
archive = work/'engineering/validation/data/frame-rate85-tracking-integration-v1.zip'
receipt = archive.with_suffix('.json')
assert not archive.exists() and not receipt.exists()
archive.parent.mkdir(parents=True,exist_ok=True)
manifest = dict(status='tracking_rational_clock_fixed_combined_regression_pending', head=failure['head'], dirtyFiles=changes, main=failure['main'], projectVersion=37, passed=28, failed=0, ignored=0, summaries=summaries, entries={name:dict(bytes=p.stat().st_size,sha256=sha(p)) for name,p in entries.items()}, limits=['Check passed on the three production edits; all three integration targets then passed with the three added tests', 'Focused shell commands exited zero as observed; the first combined check retained its original exit101 and frozen source report', 'The final clean commit, remaining complete package regressions and final cross-platform CI are not yet accepted', 'No assertions, error thresholds, layout, styles, migration or legacy numeric clock fallback changed'])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
    for name,p in entries.items(): z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,details in manifest['entries'].items(): assert hashlib.sha256(z.read(name)).hexdigest()==details['sha256']
summary={k:v for k,v in manifest.items() if k!='entries'}
summary.update(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members=len(entries)+1)
receipt.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
doc=work/'engineering/validation/frame-rate85-tracking-integration-current.md'
assert not doc.exists()
doc.write_text(f'''# Rational project clocks after tracking integration

Main `{failure['main']}` includes the independently delivered tracking root
PR580. Integrating it with the rational project clock exposed three real
compile errors: point, plane and calibrated-camera sampling still passed
the project FPS object as an integer numerator with denominator 1. The first
combined-source check exited 101; its frozen source report and original
compiler output are preserved in this archive rather than replaced.

All three sampling boundaries now pass the canonical project numerator and
denominator to the existing exact source-PTS clock. No rounded decimal FPS,
whole-frame conversion, source timestamp rewriting or numeric fallback is
introduced. Existing missing-track, visibility, confidence and gap semantics
remain unchanged. The merge keeps both FrameRate and tracking-camera error
variants. The combined current-only project schema is version 37: main was
36, while the unmerged rational branch was 33. No migration is added.

Three new tests sample a physical 1/48 second at 30000/1001, 60000/1001,
2997/100 and 24/1. Independent point/plane midpoint coordinates and calibrated
camera projection verify the original negative-origin VFR source timestamps.
All three complete integration targets passed: camera 8, plane 10, point 10,
total 28 passed, zero failed or ignored. Existing assertions and budgets were
not edited. A desktop cargo check passed after the three production changes.

These shell commands exited zero as observed. The successful check preceded
the three test-only additions; exact changed source files and raw output are
included. Fresh clean-commit model/core, renderer, desktop and cross-platform
acceptance remain pending. The preceding 929-test render gate predates this
integration and is not presented as validation of these combined sources.
Historical native heap corruption is still unresolved. Android remains outside
the maintained scope. No panels or visual behavior change in this increment.

Archive: `data/{archive.name}` ({len(entries)+1} members), SHA-256
`{sha(archive)}`. Every archived member was read back and hash-verified.
''',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['dirtyFiles','summaries']}))
