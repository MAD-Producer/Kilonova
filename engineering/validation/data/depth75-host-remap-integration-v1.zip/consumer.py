"""Seal original session40138's terminal result before releasing source freeze."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-retained-context75'
OUT=ART/'depth75-host-remap-integration-v1';CP=ART/'depth75-resume-current.json'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=read(OUT/'receipt.json');assert r['status']=='actual_host_remap_cache_and_session_passed_unqualified'
assert r['source_unchanged'] and all(c['exit_code']==0 for c in r['commands'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==r['source_head']
for n,h in r['changed_source_sha256'].items():assert sha(WORK/n)==sha(OUT/'frozen-source'/n)==h
c=read(OUT/'cache/evidence.json');s=read(OUT/'session/evidence.json')
assert c['rust_remap'] and c['all_owned_service_directories_removed'] and c['inference_calls']==2
assert s['rust_remap'] and s['owned_worker_workspace_removed'] and not s['qualified'] and s['frame_count']==3
consumed=dict(session=40138,exit_code=0,original_tool_result_consumed=True,original_chunk_id='8d744c',
 source_unchanged=True,observed_utc=datetime.now(timezone.utc).isoformat(),qualified=False,
 original_python_and_broad_regression_failures_retained=True)
write(OUT/'session-consumed.json',consumed)
state=read(CP);v=state['versionedCache75'];assert v['activeController']==str(ART/'depth75-host-remap-integration-v1-controller.py')
v.update(activeController=None,ownHeavyWorkloads=[],hostRemapIntegrationOriginal=consumed,hostRemapIntegrationOutput=str(OUT))
write(CP,state);print(json.dumps(consumed))
