"""First real persistent-cache and Session controls for explicit host remapping."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,time,traceback
ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-retained-context75'
OUT=ART/'depth75-host-remap-integration-v1';TARGET=ROOT/'target/depth-wgsl-cache75-contract'
CP=ART/'depth75-resume-current.json'
FILES={'crates/motion-host/tests/depth_wgsl_retained.rs','crates/motion-host/tests/depth_wgsl_retained/session.rs'}
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=WORK,text=True).strip()
def now():return datetime.now(timezone.utc).isoformat()
def source():
 changed=set(git('diff','--name-only').splitlines());changed.update(git('ls-files','--others','--exclude-standard').splitlines())
 assert changed==FILES
 return {n:sha(WORK/n) for n in sorted(FILES)}
assert shutil.disk_usage(ROOT).free>=10<<30
state=read(CP);v=state['versionedCache75'];assert v['activeController'] is None and not v['ownHeavyWorkloads']
assert read(ART/'depth75-rust-remap-v1/session-consumed.json')['original_tool_result_consumed']
head=git('rev-parse','HEAD');assert head=='042e518e1fcb754e4926ee01fb85dc65f6cde66d'
bindings=source();OUT.mkdir(exist_ok=False);shutil.copyfile(__file__,OUT/'controller.py')
for name in bindings:
 p=OUT/'frozen-source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WORK/name,p)
env=os.environ.copy();env.pop('MOTION_LOG',None)
ff=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='1',
 CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),
 LOCALAPPDATA=str(OUT/'appdata'),RUST_BACKTRACE='full',PYTHONDONTWRITEBYTECODE='1',LIBCLANG_PATH=str(ROOT/'.tools/python-libclang/clang/native'),
 FFMPEG_DIR=str(ff),FFMPEG_INCLUDE_DIR=str(ff/'include'),FFMPEG_LIB_DIR=str(ff/'lib'))
env['PATH']=str(ff/'bin')+os.pathsep+env['PATH'];Path(env['LOCALAPPDATA']).mkdir()
fixture=read(ART/'depth75-live-session-v2/fixture.json');worker=Path(fixture['worker']);worker_hash=sha(worker)
assert worker_hash=='033b161c1789a09011162630a24430e79271b27bcddc3bb64f39986bbdef1158'
report=dict(status='running',source_head=head,changed_source_sha256=bindings,worker_sha256=worker_hash,started_utc=now(),commands=[],
 limits=['Unqualified new-mode integration only; original Python/native and broad regression failures remain',
 'Original cache assertions/Session rendering thresholds retained; old mode wrapper unchanged',
 'No Android, panels, downloads, foreign process changes or automatic retries'])
v.update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(kind='actual Rust-remap cache and Session controls',sourceFrozen=True,output=str(OUT))]);write(CP,state)
def frozen():return git('rev-parse','HEAD')==head and source()==bindings and sha(worker)==worker_hash
def save():write(OUT/'receipt.json',report)
def command(label,args,timeout=None):
 row=dict(label=label,args=args,timeout_seconds=timeout,started_utc=now());report['commands'].append(row);save();t=time.monotonic()
 with (OUT/(label+'.stdout.log')).open('wb') as a,(OUT/(label+'.stderr.log')).open('wb') as b:
  p=subprocess.run(args,cwd=WORK,env=env,stdout=a,stderr=b,timeout=timeout)
 row.update(exit_code=p.returncode,elapsed_seconds=time.monotonic()-t);save();assert p.returncode==0 and frozen(),row
base=['cargo','test','-p','motion-host','--features','ai-depth','--test','depth_wgsl_retained','--locked','--offline']
start=time.monotonic()
try:
 command('compile',base+['--no-run'])
 cases=[('cache','actual_host_remap_cache_reopens_without_inference_and_isolates_cold_execution'),
 ('session','session::actual_host_remap_session_installs_and_freezes_depth_after_worker_exit')]
 for label,test in cases:
  directory=OUT/label;directory.mkdir();f=dict(fixture,scratch=str(directory/'scratch'),evidence=str(directory/'evidence.json'))
  write(directory/'fixture.json',f);env['MOTION_DEPTH_RETAINED_TEST_FIXTURE']=str(directory/'fixture.json')
  command('actual-'+label,base+[test,'--','--ignored','--exact','--test-threads=1'],300)
  evidence=read(directory/'evidence.json');assert evidence['rust_remap'] is True
  if label=='cache':
   assert evidence['status']=='actual_cache_reopen_mode_isolation_and_corruption_refusal_passed'
   assert evidence['inference_calls']==2 and evidence['cache_entries']==2 and evidence['all_owned_service_directories_removed']
   assert evidence['legacy_retained_execution']['runtime_sha256']!=evidence['executions'][0]['runtime_sha256']
   assert evidence['legacy_retained_execution']['plan_sha256']!=evidence['executions'][0]['plan_sha256']
   assert 'content SHA-256 differs' in evidence['original_corruption_cause']
   assert 'content SHA-256 differs' in (OUT/'actual-cache.stderr.log').read_text(encoding='utf-8')
   assert 'content SHA-256 differs' in (directory/'logs/motion-studio.log').read_text(encoding='utf-8')
  else:
   assert evidence['status']=='actual_retained_session_frozen_render_passed' and evidence['qualified'] is False
   assert evidence['owned_worker_workspace_removed'] and evidence['frame_count']==3
   assert evidence['cache_hits']==evidence['cache_misses']==1 and evidence['after_calibration_cache_misses']==2
   assert evidence['after_calibration_native']['completed_inputs']==2
 report['status']='actual_host_remap_cache_and_session_passed_unqualified'
except BaseException:report.update(status='failed_original_outcome_retained',failure=traceback.format_exc())
finally:
 report.update(source_unchanged=frozen(),elapsed_seconds=time.monotonic()-start,completed_utc=now());save()
 print(json.dumps(dict(status=report['status'],commands=report['commands'],source_unchanged=report['source_unchanged'])))
raise SystemExit(0 if report['status']=='actual_host_remap_cache_and_session_passed_unqualified' else 1)
