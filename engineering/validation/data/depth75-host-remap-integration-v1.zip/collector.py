"""Public authored controls; tensor, runtime, project and image payloads remain local."""
from pathlib import Path
import hashlib,json,zipfile,shutil
ART=Path('E:/Dev/aem/artifacts/pr-queue');ROOT=ART/'depth75-host-remap-integration-v1'
OUT=ART/'depth75-host-remap-integration-public-v1';WORK=Path('E:/Dev/aem/.worktrees/depth-retained-context75')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
r=read(ROOT/'receipt.json');c=read(ROOT/'session-consumed.json');assert c['original_tool_result_consumed'] and c['exit_code']==0
members={}
for p in ROOT.rglob('*'):
 rel=p.relative_to(ROOT)
 include=(len(rel.parts)==1 and p.suffix in {'.json','.log','.py'}) or rel.parts[0]=='frozen-source'
 include|=len(rel.parts)==2 and rel.parts[0] in {'cache','session'} and rel.name in {'fixture.json','evidence.json'}
 include|=len(rel.parts)==4 and rel.parts[0] in {'cache','session'} and rel.parts[1:3]==('logs','logs')
 include|=len(rel.parts)==3 and rel.parts[0] in {'cache','session'} and rel.parts[1]=='logs' and p.suffix=='.log'
 if p.is_file() and include:
  assert p.stat().st_size<32<<20;members[rel.as_posix()]=p.read_bytes()
members['consumer.py']=(ART/'depth75-host-remap-integration-v1-consume.py').read_bytes()
members['collector.py']=Path(__file__).read_bytes()
for n,h in r['changed_source_sha256'].items():assert sha((WORK/n).read_bytes())==h
OUT.mkdir(exist_ok=False);archive=OUT/'depth75-host-remap-integration-v1.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
m=dict(schema=1,archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
 scope='Actual explicit host-remap persistent cache and unqualified Session/frozen render; previous native/broad failures retained',
 members={n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(members.items())})
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(members)
 for n,b in members.items():assert z.read(n)==b and sha(z.read(n))==m['members'][n]['sha256']
manifest=OUT/'depth75-host-remap-integration-v1.json';manifest.write_bytes((json.dumps(m,indent=2)+'\n').encode())
for p in [archive,manifest]:shutil.copyfile(p,WORK/'engineering/validation/data'/p.name)
print(json.dumps(dict(bytes=m['bytes'],sha256=m['sha256'],members=len(members))))
