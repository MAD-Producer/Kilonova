"""First fixed32 retained-mode cohort; exact output comparison, no quality/thermal waiver."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,math,os,shutil,subprocess,time,traceback
ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-retained-context75'
OUT=ART/'depth75-retained-cohort-v1';TARGET=ROOT/'target/depth-wgsl-cache75-contract'
INPUTS=ART/'depth75-reference-inputs-v1';COLD=ART/'depth75-sustained-reference-v1/cohort-00'
CP=ART/'depth75-resume-current.json';SOURCE='crates/motion-host/examples/depth_reference.rs'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=WORK,text=True).strip()
def now():return datetime.now(timezone.utc).isoformat()
assert shutil.disk_usage(ROOT).free>=10<<30
state=read(CP);v=state['versionedCache75'];assert v['activeController'] is None and not v['ownHeavyWorkloads']
head=git('rev-parse','HEAD');assert head=='53c3280dd83f6d373bd00897e651f0d05b7da50c'
assert git('diff','--name-only')==SOURCE and not git('ls-files','--others','--exclude-standard')
source_sha=sha(WORK/SOURCE)
fixture=read(ART/'depth75-live-session-v2/fixture.json')
worker=Path(fixture['worker']);worker_sha=sha(worker)
assert worker_sha=='033b161c1789a09011162630a24430e79271b27bcddc3bb64f39986bbdef1158'
assert read(INPUTS/'receipt.json')['inputs_sha256']==sha(INPUTS/'inputs.json')
inputs=read(INPUTS/'inputs.json');cold=read(COLD/'measurements.json')
assert len(inputs)==32 and cold['status']=='completed' and len(cold['samples'])==32
for i,r in enumerate(inputs):
    assert r['index']==i and sha(INPUTS/r['rgb_input']['filename'])==r['rgb_input']['sha256']
    assert sha(COLD/cold['samples'][i]['output']['filename'])==cold['samples'][i]['output']['sha256']
OUT.mkdir(exist_ok=False);shutil.copyfile(__file__,OUT/'controller.py')
dest=OUT/'frozen-source'/SOURCE;dest.parent.mkdir(parents=True);shutil.copyfile(WORK/SOURCE,dest)
env=os.environ.copy();env.pop('MOTION_LOG',None)
ff=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='1',
    CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),
    LOCALAPPDATA=str(OUT/'appdata'),RUST_BACKTRACE='full',PYTHONDONTWRITEBYTECODE='1',
    LIBCLANG_PATH=str(ROOT/'.tools/python-libclang/clang/native'),FFMPEG_DIR=str(ff),FFMPEG_INCLUDE_DIR=str(ff/'include'),FFMPEG_LIB_DIR=str(ff/'lib'))
env['PATH']=str(ff/'bin')+os.pathsep+env['PATH'];Path(env['LOCALAPPDATA']).mkdir()
report=dict(status='running',source_head=head,changed_source=SOURCE,changed_source_sha256=source_sha,
    worker_sha256=worker_sha,input_plan_sha256=sha(INPUTS/'inputs.json'),cold_measurements_sha256=sha(COLD/'measurements.json'),
    started_utc=now(),commands=[],protocol=dict(samples=32,order='original fixed order, no warmup removal or retries',
        comparison='All complete Float32 bytes vs sealed original cold cohort; no depth/quality fit',
        request_wait_seconds=60,performance_scope='one new cohort, not sustained load or thermal qualification',
        resident_peak_sum='unknown for overlapping retained process and transforms',
        limits=['Original local failures and quality/thermal refusals remain unchanged',
            'Historical cold timings are not a controlled speedup comparison',
            'No Android, panels, downloads, third-party inspection or foreign process changes']))
v.update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(kind='actual fixed32 retained depth cohort',output=str(OUT),sourceFrozen=True)])
write(CP,state)
def frozen():return git('rev-parse','HEAD')==head and git('diff','--name-only')==SOURCE and sha(WORK/SOURCE)==source_sha and sha(worker)==worker_sha
def save():write(OUT/'receipt.json',report)
def command(label,args):
    item=dict(label=label,args=[str(a) for a in args],started_utc=now());report['commands'].append(item);save();t=time.monotonic()
    with (OUT/(label+'.stdout.log')).open('wb') as stdout,(OUT/(label+'.stderr.log')).open('wb') as stderr:
        p=subprocess.run(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
    item.update(exit_code=p.returncode,elapsed_seconds=time.monotonic()-t);save()
    assert p.returncode==0 and frozen(),item
def distribution(rows,field):
    values=sorted(r[field]/1e9 for r in rows)
    return dict(minimum=values[0],median=(values[15]+values[16])/2,p95_nearest_rank=values[math.ceil(.95*32)-1],maximum=values[-1])
start=time.monotonic()
try:
    command('example-tests',['cargo','test','-p','motion-host','--features','ai-depth','--example','depth_reference','--locked','--offline','--','--test-threads=1'])
    command('example-build',['cargo','build','-p','motion-host','--features','ai-depth','--example','depth_reference','--locked','--offline'])
    driver=TARGET/'debug/examples/depth_reference.exe';report['driver_sha256']=sha(driver)
    model=ART/'depth75-resolution-models-v1/518/export/depth_anything_v2_vits_518.onnx'
    command('actual-cohort',[str(driver),'wgsl-retained',fixture['python'],str(model),fixture['program'],str(worker),str(INPUTS),str(OUT/'cohort')])
    measured=read(OUT/'cohort/measurements.json');assert measured['status']=='completed' and len(measured['samples'])==32
    summary=measured['summary'];assert summary['submitted']==summary['completed']==32
    assert all(summary[k]==0 for k in ('failed','canceled','cache_hits','cache_misses','restored'))
    assert not (OUT/'actual-cohort.stdout.log').read_bytes()
    pids=set();pairs=[]
    for i,row in enumerate(measured['samples']):
        assert row['index']==i and row['split']==inputs[i]['split']
        output=OUT/'cohort'/row['output']['filename'];assert output.stat().st_size==640*480*4
        assert sha(output)==row['output']['sha256']==cold['samples'][i]['output']['sha256']
        memory=row['process_memory'];assert memory['children']['backend']=='wgsl_retained'
        assert row['observed_resident_sum_bytes'] is None and row['retained_gpu_buffer_capacity_bytes']==227968156
        pid=memory['children']['inference']['pid'];pids.add(pid)
        assert memory['host']['pid']!=pid and memory['children']['inference']['status']=='observed'
        assert row['worker_total_ns']>=row['resolve_ns']>0
        pairs.append(dict(index=i,sha256=row['output']['sha256'],exact=True,worker_seconds=row['worker_total_ns']/1e9))
    assert len(pids)==1 and not list((OUT/'cohort/scratch').iterdir())
    report.update(status='complete_retained32_exact_output_passed_not_qualified',native_pids=sorted(pids),
        complete_output_pairs=pairs,worker_seconds=distribution(measured['samples'],'worker_total_ns'),
        inference_seconds=distribution(measured['samples'],'inference_ns'),
        historical_cold_worker_seconds=distribution(cold['samples'],'worker_total_ns'),
        measurements_sha256=sha(OUT/'cohort/measurements.json'),all_owned_service_directories_removed=True)
except BaseException:
    report.update(status='failed_original_outcome_retained',failure=traceback.format_exc())
finally:
    report.update(source_unchanged=frozen(),elapsed_seconds=time.monotonic()-start,completed_utc=now());save()
    print(json.dumps(dict(status=report['status'],commands=report['commands'],source_unchanged=report['source_unchanged'])))
raise SystemExit(0 if report['status']=='complete_retained32_exact_output_passed_not_qualified' else 1)
