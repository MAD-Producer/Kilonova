"""Consume the failed cohort and inspect sealed completed outputs without a retry."""
from pathlib import Path
import hashlib,json
from datetime import datetime,timezone
ART=Path('E:/Dev/aem/artifacts/pr-queue');OUT=ART/'depth75-retained-cohort-v1'
WORK=Path('E:/Dev/aem/.worktrees/depth-retained-context75');COLD=ART/'depth75-sustained-reference-v1/cohort-00'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=read(OUT/'receipt.json');assert r['status']=='failed_original_outcome_retained' and r['source_unchanged']
assert r['commands'][-1]['exit_code']==1 and sha(WORK/r['changed_source'])==r['changed_source_sha256']
assert not (OUT/'session-consumed.json').exists()
write(OUT/'session-consumed.json',dict(session=84735,consumed=True,exit_code=1,source_unchanged=True,
    observed_utc=datetime.now(timezone.utc).isoformat(),original_command_exit_code=1,
    cause='request28 asset750027 remap Python child24168 exited3221225477; actual fatal stack retained',
    completed_samples=27,full_cohort_passed=False))
m=read(OUT/'cohort/measurements.json');cold=read(COLD/'measurements.json')
assert m['status']=='failed' and len(m['samples'])==27 and m['summary'] is None
raw=(OUT/'actual-cohort.stderr.log').read_text(encoding='utf-8')
file_log=(OUT/'cohort/logs/motion-studio.log').read_text(encoding='utf-8')
for text in [raw,file_log]:
    assert all(token in text for token in ['Windows fatal exception: access violation','pid=24168','typing.py',
        'numpy\\_typing\\_char_codes.py','phase=remap','asset=750027','3221225477'])
assert not (OUT/'actual-cohort.stdout.log').read_bytes()
pairs=[];pids=set()
for i,sample in enumerate(m['samples']):
    digest=sha(OUT/'cohort'/sample['output']['filename'])
    reference=cold['samples'][i]['output']
    assert sample['index']==i and digest==sample['output']['sha256']==reference['sha256']
    assert sha(COLD/reference['filename'])==digest
    memory=sample['process_memory'];assert memory['children']['backend']=='wgsl_retained'
    pids.add(memory['children']['inference']['pid'])
    assert sample['observed_resident_sum_bytes'] is None
    pairs.append(dict(index=i,sha256=digest,exact=True,worker_seconds=sample['worker_total_ns']/1e9))
assert len(pids)==1 and not list((OUT/'cohort/scratch').iterdir())
write(OUT/'completed-prefix-audit.json',dict(status='failed_full_cohort_completed_prefix_audited_no_inference_rerun',
    full_cohort_passed=False,planned_samples=32,completed_samples=27,failed_request=28,remaining_samples_not_run=4,
    full_output_pairs=pairs,native_pids=sorted(pids),worker_workspace_removed=True,
    default_file_and_stderr_fatal_stack_present=True,protocol_stdout_empty=True,
    limits=['No native root cause proven, no full-cohort percentile or thermal/quality qualification',
        'No source or package/overlay inspection, inference retry or error suppression']))
s=read(ART/'depth75-resume-current.json');v=s['versionedCache75']
assert v['activeController']==str(ART/'depth75-retained-cohort-v1-controller.py')
v.update(activeController=None,ownHeavyWorkloads=[],retainedCohortOriginal=dict(path=str(OUT),session=84735,consumed=True,
    exitCode=1,completedSamples=27,plannedSamples=32,failedRequest=28,fatalPythonPid=24168,failedPhase='remap',
    nativeFaultFixed=False,originalFailureRetained=True,defaultFileAndStderrStackVerified=True))
write(ART/'depth75-resume-current.json',s)
print('84735 consumed exit 1; 27 sealed output pairs exact; failed request28 retained with real fatal stack; no retry')
