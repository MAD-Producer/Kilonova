"""Publish actual fatal diagnostics and prefix equality, never a completed cohort claim."""
from pathlib import Path
import hashlib,json,zipfile
ART=Path('E:/Dev/aem/artifacts/pr-queue');ROOT=ART/'depth75-retained-cohort-v1'
OUT=ART/'depth75-retained-cohort-public-v1';WORK=Path('E:/Dev/aem/.worktrees/depth-retained-context75')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
c=read(ROOT/'session-consumed.json');r=read(ROOT/'receipt.json');a=read(ROOT/'completed-prefix-audit.json')
assert c['session']==84735 and c['consumed'] and c['exit_code']==1
assert r['source_unchanged'] and r['status']=='failed_original_outcome_retained'
assert not a['full_cohort_passed'] and len(a['full_output_pairs'])==27
assert sha((WORK/r['changed_source']).read_bytes())==r['changed_source_sha256']
members={}
for p in ROOT.rglob('*'):
    rel=p.relative_to(ROOT)
    if p.is_file() and p.suffix in {'.json','.log','.rs','.py'} and not any(
        part in {'scratch','appdata'} for part in rel.parts):
        assert p.stat().st_size<32<<20
        members[rel.as_posix()]=p.read_bytes()
members['consumer.py']=(ART/'depth75-retained-cohort-v1-consume.py').read_bytes()
members['collector.py']=Path(__file__).read_bytes()
OUT.mkdir(exist_ok=False);archive=OUT/'depth75-retained-cohort-v1.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(members.items()):z.writestr(n,b)
m=dict(schema=1,archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
    scope='Failed fixed32 retained run, actual access-violation stack and 27 exact completed outputs; no retry or complete-cohort acceptance',
    members={n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(members.items())})
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for n,b in members.items():assert z.read(n)==b and sha(z.read(n))==m['members'][n]['sha256']
(OUT/'depth75-retained-cohort-v1.json').write_bytes((json.dumps(m,indent=2)+'\n').encode())
print(json.dumps(dict(bytes=m['bytes'],sha256=m['sha256'],members=len(members))))
