from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
from PIL import Image
from cpu_affinity_support import run_native
root=Path('E:/Dev/aem');out=root/'.tools/curve-view-ranges';base,current=sys.argv[1:3]
sequence=[(base,'run-a'),(current,'run-a'),(current,'run-b'),(base,'run-b')]
required_mask=0xc000;receipts={};frozen={}
def freeze(work):
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=work,text=True).splitlines()
    paths=[p for p in paths if p.startswith(('crates/','desktop/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']]
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
for name in [base,current]:
    r=json.loads((out/name/'receipt.json').read_text(encoding='utf8'));assert r['build_exit_code']==0 and r['source_unchanged'] and r['run'] is None
    work=root/'.worktrees'/('curve-performance-baseline' if r['label']=='baseline' else 'curve-view-ranges')
    assert freeze(work)==r['sources'];assert hashlib.sha256(Path(r['binary']).read_bytes()).hexdigest()==r['binary_sha256']
    for item in r['runtime_dlls']:assert hashlib.sha256((out/name/item['name']).read_bytes()).hexdigest()==item['sha256']
    receipts[name]=r;frozen[name]=work
assert receipts[base]['base_main']==receipts[current]['base_main']
assert receipts[base]['sources']['desktop/app/src/panels/graph_native_performance_tests.rs']==receipts[current]['sources']['desktop/app/src/panels/graph_native_performance_tests.rs']
completed=[];overall=time.monotonic()
for name,tag in sequence:
    folder=out/name;r=receipts[name];work=frozen[name];dest=folder/tag;dest.mkdir(exist_ok=False)
    env=os.environ.copy();env.pop('MOTION_LOG',None);env['MOTION_GRAPH_PERFORMANCE_CHILD']=str(dest);env['PATH']=str(folder)+os.pathsep+env.get('PATH','')
    command=[r['binary'],'--exact','panels::graph_native_performance_tests::actual_native_graph_costs_match_info_counters','--ignored','--nocapture','--test-threads=1']
    print('Contiguous paired measurement '+name+'/'+tag+' started.',flush=True);began=time.monotonic()
    with (dest/'driver-stdout.log').open('w',encoding='utf8') as stdout,(dest/'driver-stderr.log').open('w',encoding='utf8') as stderr:
        result,affinity=run_native(command,cwd=work,env=env,stdout=stdout,stderr=stderr,timeout=1800,required_mask=required_mask)
    record=dict(label=r['label'],compiled_head=r['head'],binary_sha256=r['binary_sha256'],exit_code=result.returncode,seconds=round(time.monotonic()-began,2),
        affinity=affinity,source_unchanged=freeze(work)==r['sources'],validated=False)
    (dest/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8')
    assert result.returncode==0 and record['source_unchanged']
    summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',(dest/'driver-stdout.log').read_text(encoding='utf8'));assert summary==[('ok','1','0','0')]
    data=json.loads((dest/'result.json').read_text(encoding='utf8'));assert data['schema'] in [5,6] and len(data['cases'])==28 and data['projectUnchanged'] and data['revisionUnchanged']
    for c in data['cases']:
        seek=c['phase']=='seek';assert len(c['frames'])==60 and len(c['warmup'])==5 and (c['renders'],c['reuses'])==((60,0) if seek else (0,60))
        previous=c['info_before']
        for f in c['frames']:
            assert f['sought']==seek and f['effective_timeline_zoom']==c['timeline_zoom'] and f['ui_thread_cpu_100ns']>=0 and f['ui_thread_cycles']>0
            p=f['paint_work'];assert all(isinstance(v,int) and v>=0 for v in p.values())
            assert p['draw_commands_us']+p['metrics_collect_us']+p['atlas_prepare_us']<=f['ui_build_and_atlas_us']
            assert p['shape_commands']>0 and p['glyphs']>0
            assert len(f['panel_costs'])==f['present_polls']
            for costs in f['panel_costs']:
                assert all(costs[k]['calls']==1 and costs[k]['thread_cycles']>0 for k in ['graph','info','composition'])
                assert costs['other']['calls']==0
            assert sum(costs[k]['wall_us'] for costs in f['panel_costs'] for k in ['graph','info','composition','other'])<=p['draw_commands_us']
            if data['schema']>=6:
                for costs in f['panel_costs']:
                    assert all(isinstance(costs[k][field],int) and costs[k][field]>=0 for k in ['graph','info','composition'] for field in ['glyphs','shapes'])
                    assert costs['graph']['glyphs']>0 and costs['graph']['shapes']>0
                    assert sum(costs[k]['wall_us'] for k in ['adaptive_sample','adaptive_extrema'])<=costs['graph']['wall_us']
                    if r['label']=='baseline' or c['kind']=='mini':
                        assert costs['adaptive_sample']['calls']==costs['adaptive_extrema']['calls']==0
            assert tuple(f['info'][k]-previous[k] for k in ['compositionRenders','compositionReuses'])==((1,0) if seek else (0,1))
            previous=f['info']
    pngs=[]
    for p in sorted(dest.glob('*.png')):
        with Image.open(p) as im:assert im.size==(1280,800) and any(a!=b for a,b in im.convert('RGB').getextrema())
        pngs.append(dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    assert len(pngs)==28
    record.update(validated=True,summary=summary,cases=28,measured_frames=1680,warmup_frames=140,pngs=pngs,
        project_sha256=hashlib.sha256((dest/'project/project.json').read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256((dest/'fixture.msfx').read_bytes()).hexdigest())
    (dest/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8')
    if tag=='run-a':
        build_receipt=folder/'compile-only-receipt.json';build_receipt.write_text(json.dumps(r,indent=2),encoding='utf8')
        r.update(run=record,affinity=affinity)
        (folder/'receipt.json').write_text(json.dumps(r,indent=2),encoding='utf8')
    completed.append(dict(folder=name,tag=tag,seconds=record['seconds'],affinity=affinity['selected_mask']))
    print(json.dumps(completed[-1]),flush=True)
assert len({json.loads((out/name/tag/'receipt.json').read_text())['project_sha256'] for name,tag in sequence})==1
assert len({json.loads((out/name/tag/'receipt.json').read_text())['fixture_sha256'] for name,tag in sequence})==1
(out/'profile-sequence.json').write_text(json.dumps(dict(sequence=completed,seconds=round(time.monotonic()-overall,2),
    scope='Both compilations completed before four contiguous native processes; no deliberate inter-run pause, no timing-based retries. Same base, fixture, mask and harness verified. Census overhead is measured and included; capacities are not allocations/RSS. Background/thermal/SMT interference is not controlled.'),indent=2),encoding='utf8')
