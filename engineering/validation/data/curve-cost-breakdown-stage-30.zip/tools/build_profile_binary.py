from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
root=Path('E:/Dev/aem');out=root/'.tools/curve-view-ranges';label,attempt,reference=sys.argv[1:4]
assert label in ['baseline','current']
work=root/'.worktrees'/('curve-performance-baseline' if label=='baseline' else 'curve-view-ranges')
folder=out/('performance-'+label+'-'+attempt);folder.mkdir(exist_ok=False)
def freeze():
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=work,text=True).splitlines()
    paths=[p for p in paths if p.startswith(('crates/','desktop/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']]
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
sources=freeze();shared={p:h for p,h in sources.items() if p.startswith(('crates/','desktop/ui/')) or p.endswith('Cargo.toml') or p=='Cargo.lock'}
old=json.loads((out/reference/'receipt.json').read_text(encoding='utf8'));assert old['build_exit_code']==0 and old['source_unchanged']
changed=[p for p in sorted(set(shared)|set(old['shared_sources'])) if shared.get(p)!=old['shared_sources'].get(p)]
roots={'desktop/app/src/main.rs'}
if any(p in ['Cargo.lock','Cargo.toml'] for p in changed):roots.update(p for p in sources if p.endswith('/src/lib.rs'))
else:
    for p in changed:
        if p.startswith('crates/'):owner='/'.join(p.split('/')[:2])
        elif p.startswith('desktop/ui/'):owner='desktop/ui'
        else:raise AssertionError(('Unclassified shared build input',p))
        path=owner+'/src/lib.rs';assert path in sources;roots.add(path)
for p in roots:(work/p).touch()
command=old['command'];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
print('Frozen '+label+' panel-stage profiling build started; no measurement during either compilation.',flush=True);start=time.monotonic()
with (folder/'build.log').open('w',encoding='utf8') as sink:build=subprocess.run(command,cwd=work,stdout=sink,stderr=subprocess.STDOUT)
binary=None;digest=None;runtime=[];loader=None
if build.returncode==0:
    original=Path(re.search(r'Executable unittests[^\n]*\(([^\n]+\.exe)\)',(folder/'build.log').read_text(encoding='utf8')).group(1))
    binary=folder/'motion-studio-tests.exe';shutil.copyfile(original,binary);digest=hashlib.sha256(binary.read_bytes()).hexdigest()
    for name in ['avcodec-62.dll','avformat-62.dll','avutil-60.dll','swscale-9.dll','swresample-6.dll']:
        source=Path(os.environ['FFMPEG_DIR'])/'bin'/name;target=folder/name;shutil.copyfile(source,target)
        h=hashlib.sha256(source.read_bytes()).hexdigest();assert hashlib.sha256(target.read_bytes()).hexdigest()==h
        runtime.append(dict(name=name,sha256=h,bytes=source.stat().st_size))
    smoke=subprocess.run([str(binary),'--list'],cwd=work,capture_output=True,timeout=20)
    loader=dict(exit_code=smoke.returncode,registered=b'actual_native_graph_costs_match_info_counters' in smoke.stdout)
    (folder/'loader-smoke.json').write_text(json.dumps(loader,indent=2),encoding='utf8')
r=dict(label=label,head=head,base_main=subprocess.check_output(['git','merge-base','HEAD','origin/main'],cwd=work,text=True).strip(),command=command,
    build_exit_code=build.returncode,binary=str(binary) if binary else None,binary_sha256=digest,sources=sources,shared_sources=shared,
    source_unchanged=freeze()==sources,runtime_dlls=runtime,run=None,affinity=None,loader=loader,seconds=round(time.monotonic()-start,2),
    forced_roots=sorted(roots),library_reference=reference,changed_shared_sources=changed,
    scope='Compilation and loader verification only. Explicit contiguous paired measurements must run after both binaries are built. No accepted performance result inferred from this receipt.')
(folder/'receipt.json').write_text(json.dumps(r,indent=2),encoding='utf8')
print(json.dumps({k:r[k] for k in ['label','head','base_main','build_exit_code','binary_sha256','source_unchanged','loader','seconds']}),flush=True)
raise SystemExit(0 if build.returncode==0 and r['source_unchanged'] and loader and loader['exit_code']==0 and loader['registered'] else 1)
