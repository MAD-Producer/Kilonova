"""Diagnostic own-child affinity only; independently authored Windows ABI calls.
API contracts: Microsoft Learn GetSystemCpuSetInformation,
SYSTEM_CPU_SET_INFORMATION, GetProcessAffinityMask, SetProcessAffinityMask.
No application code or other process affinity/priority is changed.
"""
import ctypes,datetime,struct,subprocess,sys,time
from ctypes import wintypes
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.GetCurrentProcess.argtypes=[];k.GetCurrentProcess.restype=wintypes.HANDLE
k.GetProcessAffinityMask.argtypes=[wintypes.HANDLE,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)];k.GetProcessAffinityMask.restype=wintypes.BOOL
k.SetProcessAffinityMask.argtypes=[wintypes.HANDLE,ctypes.c_size_t];k.SetProcessAffinityMask.restype=wintypes.BOOL
k.GetSystemCpuSetInformation.argtypes=[ctypes.c_void_p,wintypes.ULONG,ctypes.POINTER(wintypes.ULONG),wintypes.HANDLE,wintypes.ULONG];k.GetSystemCpuSetInformation.restype=wintypes.BOOL
def mask(handle):
    own=ctypes.c_size_t();system=ctypes.c_size_t()
    assert k.GetProcessAffinityMask(handle,ctypes.byref(own),ctypes.byref(system)),ctypes.get_last_error()
    assert own.value and system.value
    return own.value,system.value
def topology():
    needed=wintypes.ULONG();first=k.GetSystemCpuSetInformation(None,0,ctypes.byref(needed),k.GetCurrentProcess(),0)
    assert not first and ctypes.get_last_error()==122 and needed.value>0
    buffer=ctypes.create_string_buffer(needed.value)
    assert k.GetSystemCpuSetInformation(buffer,len(buffer),ctypes.byref(needed),k.GetCurrentProcess(),0),ctypes.get_last_error()
    rows=[];offset=0;data=buffer.raw[:needed.value]
    while offset<len(data):
        size,kind=struct.unpack_from('<II',data,offset);assert size>=8 and offset+size<=len(data)
        if kind==0:
            assert size>=32
            ident,group,index,core,cache,numa,efficiency,flags=struct.unpack_from('<IHBBBBBB',data,offset+8)
            rows.append(dict(id=ident,group=group,logical_processor=index,core=core,cache=cache,numa=numa,efficiency_class=efficiency,flags=flags))
        offset+=size
    assert offset==len(data) and rows and all(x['group']==0 for x in rows),'Diagnostic supports this single-group host only'
    return rows
def run_native(command,*,cwd,env,stdout,stderr,timeout,required_mask=None):
    parent=k.GetCurrentProcess();original,system=mask(parent);rows=topology()
    available=[r for r in rows if original&(1<<r['logical_processor']) and not(r['flags']&2 and not r['flags']&4)]
    assert available
    if required_mask is None:
        awake=[r for r in available if not r['flags']&1];assert awake
        efficiency=max(r['efficiency_class'] for r in awake)
        core=max(r['core'] for r in awake if r['efficiency_class']==efficiency)
        chosen=[r for r in available if r['core']==core and r['efficiency_class']==efficiency]
        selected=sum(1<<r['logical_processor'] for r in chosen)
    else:
        selected=required_mask;chosen=[r for r in available if selected&(1<<r['logical_processor'])]
        assert selected and sum(1<<r['logical_processor'] for r in chosen)==selected
        assert len({(r['group'],r['core'],r['efficiency_class']) for r in chosen})==1
    assert selected&original==selected
    record=dict(original_parent_mask=hex(original),system_mask=hex(system),selected_mask=hex(selected),selected_cpu_sets=chosen,cpu_sets=rows,
        priority_changed=False,scope='Diagnostic restricts only this supervisor and its native child to the same reported physical core; parent mask restored afterward. Other workloads/thermals/SMT interference remain uncontrolled. Not default scheduling or shipping FPS.')
    assert k.SetProcessAffinityMask(parent,selected),ctypes.get_last_error()
    try:
        assert mask(parent)[0]==selected
        with subprocess.Popen(command,cwd=cwd,env=env,stdout=stdout,stderr=stderr) as child:
            record.update(child_pid=child.pid,observed_child_mask=hex(mask(wintypes.HANDLE(int(child._handle)))[0]),child_mask_observed_seconds=time.monotonic(),child_mask_observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
            assert record['observed_child_mask']==hex(selected)
            try:code=child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                child.kill();child.wait();raise
            result=subprocess.CompletedProcess(command,code)
    finally:
        primary=sys.exc_info()[1]
        try:
            if not k.SetProcessAffinityMask(parent,original):raise OSError(ctypes.get_last_error(),'restore own supervisor processor mask failed')
            record['parent_mask_restored']=mask(parent)[0]==original
            assert record['parent_mask_restored']
        except BaseException as cleanup:
            record['parent_mask_restored']=False
            if primary is None:raise
            primary.add_note('Affinity cleanup also failed: '+type(cleanup).__name__+': '+str(cleanup))
    return result,record
