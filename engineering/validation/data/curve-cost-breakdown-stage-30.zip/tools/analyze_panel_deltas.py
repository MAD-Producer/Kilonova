from pathlib import Path
import json,statistics
out=Path('E:/Dev/aem/.tools/curve-view-ranges')
report=json.loads((out/'performance-comparison.json').read_text(encoding='utf8'));assert report['schema']>=5
variants={}
for label in ['baseline','current']:
    folder=out/report['builds'][label]['folder']
    variants[label]=[json.loads((folder/tag/'result.json').read_text(encoding='utf8')) for tag in ['run-a','run-b']]
def values(rows,panel,field):return [sum(c[panel][field] for c in row['panel_costs']) for row in rows]
def summarize(rows):
    result={p:{f:statistics.median(values(rows,p,f)) for f in ['wall_us','thread_cycles']} for p in ['graph','info','composition']}
    result['outside_panels_wall_us']=statistics.median(row['paint_work']['draw_commands_us']-sum(c[p]['wall_us'] for c in row['panel_costs'] for p in ['graph','info','composition','other']) for row in rows)
    if report['schema']>=6:
        for panel in ['graph','info','composition']:
            result[panel].update({field:statistics.median(values(rows,panel,field)) for field in ['shapes','glyphs']})
        result['adaptive']={panel:{field:statistics.median(values(rows,panel,field)) for field in ['calls','wall_us','thread_cycles']} for panel in ['adaptive_sample','adaptive_extrema']}
        graph=values(rows,'graph','thread_cycles');info=values(rows,'info','thread_cycles')
        glyphs=values(rows,'graph','glyphs');info_glyphs=values(rows,'info','glyphs')
        adaptive=[a+b for a,b in zip(values(rows,'adaptive_sample','thread_cycles'),values(rows,'adaptive_extrema','thread_cycles'))]
        assert all(g>=a and n>0 and m>0 for g,a,n,m in zip(graph,adaptive,glyphs,info_glyphs))
        result['graph_to_info_per_glyph_cycle_ratio']=statistics.median((g/n)/(i/m) for g,i,n,m in zip(graph,info,glyphs,info_glyphs))
        result['graph_excluding_new_adaptive_to_info_cycle_ratio']=statistics.median((g-a)/i for g,a,i in zip(graph,adaptive,info))
    for control in ['info','composition']:
        result['graph_to_'+control+'_cycle_ratio']=statistics.median(a/b for a,b in zip(values(rows,'graph','thread_cycles'),values(rows,control,'thread_cycles')))
    return result
cases=[]
for case in variants['baseline'][0]['cases']:
    name=case['case'];entry=dict(case=name)
    for label,runs in variants.items():
        rows=[next(c for c in run['cases'] if c['case']==name)['frames'] for run in runs]
        entry[label]=summarize([r for batch in rows for r in batch]);entry[label]['separate_runs']=[summarize(batch) for batch in rows]
    for control in ['info','composition']:
        key='graph_to_'+control+'_cycle_ratio'
        entry[key+'_delta_percent']=100*(entry['current'][key]/entry['baseline'][key]-1)
    if report['schema']>=6:
        for key in ['graph_to_info_per_glyph_cycle_ratio','graph_excluding_new_adaptive_to_info_cycle_ratio']:
            entry[key+'_delta_percent']=100*(entry['current'][key]/entry['baseline'][key]-1)
    cases.append(entry)
result=dict(status='DIAGNOSTIC_NOT_A_PERFORMANCE_ACCEPTANCE',builds=report['builds'],cases=cases,
    limits='Ratios use each real frame and retain both runs; unchanged Info and Composition code act as controls but their displayed counters/text vary. CPU affinity does not control background work, thermals or SMT. Ratio normalization does not remove every confound and is not a substitute for absolute wall/CPU costs. No timing-based retries or shipping-FPS claim.')
(out/('panel-deltas-schema'+str(report['schema'])+'.json')).write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(dict(largest_graph_to_info_ratio_deltas=sorted([dict(case=c['case'],percent=round(c['graph_to_info_cycle_ratio_delta_percent'],2),composition_ratio_delta=round(c['graph_to_composition_cycle_ratio_delta_percent'],2),baseline_graph_us=c['baseline']['graph']['wall_us'],current_graph_us=c['current']['graph']['wall_us']) for c in cases],key=lambda c:c['percent'],reverse=True)[:10])))
