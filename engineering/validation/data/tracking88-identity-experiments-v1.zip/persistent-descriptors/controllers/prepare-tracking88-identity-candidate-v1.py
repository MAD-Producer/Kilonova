from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-identity-candidate-v1'
SRC = OUT / 'candidate/tools/tracking'
SRC.mkdir(parents=True, exist_ok=False)
BASE = '147ced69e08189b73d53760873c9ed72bc34fa36'
for name in ['plate_contract.py', 'plate_flow.py', 'track_plate.py', 'test_flow.py', 'validate_prototype.py']:
    (SRC / name).write_bytes(subprocess.check_output(['git', 'show', f'{BASE}:tools/tracking/{name}'], cwd=WORK))

identity = '''"""Bounded manually enrolled identity; only initializes original LK measurements.

No ground truth, automatic descriptor enrollment, or visible output is produced.
The initial reference and three recent manual references survive a local reset.
"""
import cv2
import numpy as np
from plate_flow import LIMITS, transform, plane_matrix


def descriptors(gray, mask=None, maximum=800):
    keypoints, values = cv2.SIFT_create(nfeatures=maximum).detectAndCompute(gray, mask)
    if values is None:
        return np.empty((0, 2)), np.empty((0, 128), np.float32)
    return np.asarray([point.pt for point in keypoints]), values


def matches(left, right):
    if len(left) < 2 or len(right) < 2:
        return []
    matcher = cv2.BFMatcher(cv2.NORM_L2)
    forward = matcher.knnMatch(left, right, k=2)
    backward = matcher.knnMatch(right, left, k=2)
    reverse = {pair[0].queryIdx: pair[0].trainIdx for pair in backward
               if len(pair) == 2 and pair[0].distance < .7 * pair[1].distance}
    return [(pair[0].queryIdx, pair[0].trainIdx) for pair in forward
            if len(pair) == 2 and pair[0].distance < .7 * pair[1].distance
            and reverse.get(pair[0].trainIdx) == pair[0].queryIdx]


class Identity:
    def __init__(self, roi):
        self.roi = roi
        self.references = []
        self.verified = None

    def enroll(self, gray, matrix, mask):
        # Existing references are checked against this explicit user input
        # BEFORE the new appearance is allowed into the bounded reference bank.
        points, values = descriptors(gray)
        original, retained, locations = [], [], []
        for reference, previous in reversed(self.references):
            expected = transform(matrix, reference)
            for left, right in matches(previous, values):
                if np.linalg.norm(expected[left] - points[right]) > LIMITS['heldOutMaxPixels']:
                    continue
                if any(np.linalg.norm(points[right] - other) < 3. for other in locations):
                    continue
                original.append(reference[left])
                retained.append(previous[left])
                locations.append(points[right])
                if len(original) == 400:
                    break
            if len(original) == 400:
                break
        self.verified = (np.asarray(original).reshape(-1, 2),
                         np.asarray(retained, np.float32).reshape(-1, 128))
        points, values = descriptors(gray, mask, 400)
        reference = transform(np.linalg.inv(matrix), points)
        x, y, w, h = self.roi
        inside = ((reference[:, 0] >= x) & (reference[:, 0] <= x+w)
                  & (reference[:, 1] >= y) & (reference[:, 1] <= y+h))
        self.references.append((reference[inside], values[inside]))
        if len(self.references) > 4:
            self.references.pop(1)

    def predict(self, current):
        if self.verified is None or len(self.verified[0]) < 4:
            return None
        reference, values = self.verified
        points, current_values = descriptors(current)
        pairs = matches(values, current_values)
        if len(pairs) < 4:
            return None
        original = np.asarray([reference[left] for left, _ in pairs])
        measured = np.asarray([points[right] for _, right in pairs])
        matrix, inliers = cv2.findHomography(original, measured, cv2.RANSAC,
            LIMITS['planeFitPixels'], maxIters=2000, confidence=.995)
        if matrix is None or inliers is None or int(inliers.sum()) < 4 or float(inliers.mean()) < .7:
            return None
        try:
            # Four points suffice ONLY for an optional initialization, never
            # for publication. Original 16/12 + held-out guards still execute.
            return plane_matrix(matrix, self.roi)
        except ValueError:
            return None
'''
(SRC / 'plate_identity.py').write_text(identity, encoding='utf-8')
flow = SRC / 'plate_flow.py'
before = flow.read_text(encoding='utf-8')
needle = '        self.holdout = np.arange(len(self.points)) % 4 == 0'
assert before.count(needle) == 1
after = before.replace(needle, needle + '''
        from plate_identity import Identity
        if not hasattr(self, 'identity'):
            self.identity = Identity(self.seed['roi'])
        self.identity.enroll(gray, matrix, mask)
        self.previous_matrix = matrix.copy()
''')
needle = '        moved, valid, scores = flow(previous, current, self.points)'
assert after.count(needle) == 1
after = after.replace(needle, '''        initial = None
        if self.seed['kind'] == 'plane':
            prediction = self.identity.predict(current)
            if prediction is not None:
                initial = transform(prediction @ np.linalg.inv(self.previous_matrix), self.points)
        moved, valid, scores = flow(previous, current, self.points, initial=initial)''')
needle = "        return dict(kind='plane', matrix=matrix.tolist()), ratio*math.exp(-rms)"
assert after.count(needle) == 1
after = after.replace(needle, '        self.previous_matrix = matrix.copy()\n' + needle)
flow.write_text(after, encoding='utf-8')

tests = '''"""Independent analytic identity controls; original flow assertions unchanged."""
import unittest
import cv2
import numpy as np
from plate_identity import Identity
from plate_flow import prepare, transform


class IdentityControls(unittest.TestCase):
    def setUp(self):
        cv2.setNumThreads(1)
        rng = np.random.default_rng(883314)
        self.image = prepare(rng.integers(0, 256, (256, 320), np.uint8))
        self.roi = [40., 40., 240., 176.]
        self.mask = np.zeros(self.image.shape, np.uint8)
        self.mask[40:216, 40:280] = 255

    def test_manual_reference_retains_original_identity_and_predicts_unseen_motion(self):
        identity = Identity(self.roi)
        identity.enroll(self.image, np.eye(3), self.mask)
        first = identity.references[0][1].copy()
        reset = np.array([[1., 0., 4.], [0., 1., 3.], [0., 0., 1.]])
        image = cv2.warpPerspective(self.image, reset, (320, 256))
        identity.enroll(image, reset, cv2.warpPerspective(self.mask, reset, (320, 256)))
        self.assertGreaterEqual(len(identity.verified[0]), 16)
        unseen = np.array([[1., -.003, 6.], [.003, 1., 5.], [.00001, -.00002, 1.]])
        prediction = identity.predict(cv2.warpPerspective(self.image, unseen, (320, 256)))
        self.assertIsNotNone(prediction)
        probes = [[40., 40.], [280., 40.], [280., 216.], [40., 216.]]
        self.assertLess(float(np.linalg.norm(transform(prediction, probes)-transform(unseen, probes), axis=1).max()), .5)
        for _ in range(8):
            identity.enroll(image, reset, cv2.warpPerspective(self.mask, reset, (320, 256)))
        self.assertEqual(len(identity.references), 4)
        self.assertTrue(np.array_equal(identity.references[0][1], first))
        self.assertLessEqual(sum(len(values) for _, values in identity.references), 1600)
        self.assertLessEqual(len(identity.verified[0]), 400)

    def test_missing_or_unrelated_identity_does_not_invent_prediction(self):
        identity = Identity(self.roi)
        identity.enroll(self.image, np.eye(3), self.mask)
        self.assertIsNone(identity.predict(self.image))
        unrelated = prepare(np.random.default_rng(12).integers(0, 256, self.image.shape, np.uint8))
        identity.enroll(unrelated, np.eye(3), self.mask)
        self.assertIsNone(identity.predict(np.zeros_like(self.image)))
        empty = Identity(self.roi)
        empty.enroll(np.zeros_like(self.image), np.eye(3), self.mask)
        self.assertIsNone(empty.predict(self.image))


if __name__ == '__main__':
    unittest.main()
'''
(SRC / 'test_identity.py').write_text(tests, encoding='utf-8')
proposal = dict(status='external_blind_candidate_not_adopted', base=BASE,
    purpose='Preserve identity across manual resets as optional LK initialization; no changed publication guards',
    files={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in SRC.glob('*.py')})
(OUT / 'proposal.json').write_text(json.dumps(proposal, indent=2), encoding='utf-8')
print(json.dumps(proposal, indent=2))
