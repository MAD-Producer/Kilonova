from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-identity-candidate-v1'
CAND = OUT / 'candidate'
SRC = CAND / 'tools/tracking'
assert (OUT / 'proposal.json').is_file()
assert not (OUT / 'exit.json').exists()
(OUT / 'experiment-controller.py').write_bytes(Path(__file__).read_bytes())
original = (ROOT / '.tools/issue-closure-review/measure-tracking88-photographed-v5.py').read_text(encoding='utf-8')
needle = "WORK=ROOT/'.worktrees/tracking-import88'"
assert original.count(needle) == 1
real = original.replace(needle, 'WORK=Path(' + repr(CAND.as_posix()) + ')').replace(
    'photographed-prototype-v5', 'photographed-identity-v1')
(OUT / 'real-controller.py').write_text(real, encoding='utf-8')
names = ['plate_contract.py', 'plate_flow.py', 'track_plate.py', 'test_flow.py', 'validate_prototype.py', 'plate_identity.py', 'test_identity.py']
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(),
              source={name: sha(SRC / name) for name in names}, steps=[])
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env['PYTHONDONTWRITEBYTECODE'] = '1'
runtime = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
steps = [
    ('identity-controls', [sys.executable, str(SRC / 'test_identity.py'), '-v']),
    ('controls', [sys.executable, str(SRC / 'test_flow.py'), '-v']),
    ('synthetic', [sys.executable, str(SRC / 'validate_prototype.py'),
                   '--ffmpeg', str(runtime / 'ffmpeg.exe'), '--ffprobe', str(runtime / 'ffprobe.exe'),
                   '--output', str(OUT / 'synthetic')]),
    ('full-real', [sys.executable, str(OUT / 'real-controller.py')]),
]


def save():
    temporary = OUT / 'exit.pending.json'
    temporary.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(temporary, OUT / 'exit.json')


save()
try:
    for phase, command in steps:
        with (OUT / (phase + '.stdout.log')).open('wb') as stdout, (OUT / (phase + '.stderr.log')).open('wb') as stderr:
            child = subprocess.Popen(command, cwd=CAND, env=env, stdout=stdout, stderr=stderr)
            row = dict(phase=phase, command=command, pid=child.pid)
            report['steps'].append(row)
            save()
            row['exitCode'] = child.wait()
            save()
        assert all(sha(SRC / name) == digest for name, digest in report['source'].items()), 'candidate source changed'
        assert row['exitCode'] == 0, (phase, row['exitCode'])
    report['status'] = 'candidate_controls_synthetic_and_full_real_measured_not_adopted'
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps({key: report.get(key) for key in ['status', 'steps', 'failure']}, indent=2), flush=True)

