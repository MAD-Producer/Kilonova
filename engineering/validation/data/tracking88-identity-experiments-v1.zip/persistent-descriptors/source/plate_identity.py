"""Bounded manually enrolled identity; only initializes original LK measurements.

No ground truth, automatic descriptor enrollment, or visible output is produced.
The initial reference and three recent manual references survive a local reset.
"""
import cv2
import numpy as np
from plate_flow import LIMITS, transform, plane_matrix


def descriptors(gray, mask=None, maximum=800):
    keypoints, values = cv2.SIFT_create(nfeatures=maximum).detectAndCompute(gray, mask)
    if values is None:
        return np.empty((0, 2)), np.empty((0, 128), np.float32)
    return np.asarray([point.pt for point in keypoints]), values


def matches(left, right):
    if len(left) < 2 or len(right) < 2:
        return []
    matcher = cv2.BFMatcher(cv2.NORM_L2)
    forward = matcher.knnMatch(left, right, k=2)
    backward = matcher.knnMatch(right, left, k=2)
    reverse = {pair[0].queryIdx: pair[0].trainIdx for pair in backward
               if len(pair) == 2 and pair[0].distance < .7 * pair[1].distance}
    return [(pair[0].queryIdx, pair[0].trainIdx) for pair in forward
            if len(pair) == 2 and pair[0].distance < .7 * pair[1].distance
            and reverse.get(pair[0].trainIdx) == pair[0].queryIdx]


class Identity:
    def __init__(self, roi):
        self.roi = roi
        self.references = []
        self.verified = None

    def enroll(self, gray, matrix, mask):
        # Existing references are checked against this explicit user input
        # BEFORE the new appearance is allowed into the bounded reference bank.
        points, values = descriptors(gray)
        original, retained, locations = [], [], []
        for reference, previous in reversed(self.references):
            expected = transform(matrix, reference)
            for left, right in matches(previous, values):
                if np.linalg.norm(expected[left] - points[right]) > LIMITS['heldOutMaxPixels']:
                    continue
                if any(np.linalg.norm(points[right] - other) < 3. for other in locations):
                    continue
                original.append(reference[left])
                retained.append(previous[left])
                locations.append(points[right])
                if len(original) == 400:
                    break
            if len(original) == 400:
                break
        self.verified = (np.asarray(original).reshape(-1, 2),
                         np.asarray(retained, np.float32).reshape(-1, 128))
        points, values = descriptors(gray, mask, 400)
        reference = transform(np.linalg.inv(matrix), points)
        x, y, w, h = self.roi
        inside = ((reference[:, 0] >= x) & (reference[:, 0] <= x+w)
                  & (reference[:, 1] >= y) & (reference[:, 1] <= y+h))
        self.references.append((reference[inside], values[inside]))
        if len(self.references) > 4:
            self.references.pop(1)

    def predict(self, current):
        if self.verified is None or len(self.verified[0]) < 4:
            return None
        reference, values = self.verified
        points, current_values = descriptors(current)
        pairs = matches(values, current_values)
        if len(pairs) < 4:
            return None
        original = np.asarray([reference[left] for left, _ in pairs])
        measured = np.asarray([points[right] for _, right in pairs])
        matrix, inliers = cv2.findHomography(original, measured, cv2.RANSAC,
            LIMITS['planeFitPixels'], maxIters=2000, confidence=.995)
        if matrix is None or inliers is None or int(inliers.sum()) < 4 or float(inliers.mean()) < .7:
            return None
        try:
            # Four points suffice ONLY for an optional initialization, never
            # for publication. Original 16/12 + held-out guards still execute.
            return plane_matrix(matrix, self.roi)
        except ValueError:
            return None
