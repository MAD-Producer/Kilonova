"""Independent analytic identity controls; original flow assertions unchanged."""
import unittest
import cv2
import numpy as np
from plate_identity import Identity
from plate_flow import prepare, transform


class IdentityControls(unittest.TestCase):
    def setUp(self):
        cv2.setNumThreads(1)
        rng = np.random.default_rng(883314)
        self.image = prepare(rng.integers(0, 256, (256, 320), np.uint8))
        self.roi = [40., 40., 240., 176.]
        self.mask = np.zeros(self.image.shape, np.uint8)
        self.mask[40:216, 40:280] = 255

    def test_manual_reference_retains_original_identity_and_predicts_unseen_motion(self):
        identity = Identity(self.roi)
        identity.enroll(self.image, np.eye(3), self.mask)
        first = identity.references[0][1].copy()
        reset = np.array([[1., 0., 4.], [0., 1., 3.], [0., 0., 1.]])
        image = cv2.warpPerspective(self.image, reset, (320, 256))
        identity.enroll(image, reset, cv2.warpPerspective(self.mask, reset, (320, 256)))
        self.assertGreaterEqual(len(identity.verified[0]), 16)
        unseen = np.array([[1., -.003, 6.], [.003, 1., 5.], [.00001, -.00002, 1.]])
        prediction = identity.predict(cv2.warpPerspective(self.image, unseen, (320, 256)))
        self.assertIsNotNone(prediction)
        probes = [[40., 40.], [280., 40.], [280., 216.], [40., 216.]]
        self.assertLess(float(np.linalg.norm(transform(prediction, probes)-transform(unseen, probes), axis=1).max()), .5)
        for _ in range(8):
            identity.enroll(image, reset, cv2.warpPerspective(self.mask, reset, (320, 256)))
        self.assertEqual(len(identity.references), 4)
        self.assertTrue(np.array_equal(identity.references[0][1], first))
        self.assertLessEqual(sum(len(values) for _, values in identity.references), 1600)
        self.assertLessEqual(len(identity.verified[0]), 400)

    def test_missing_or_unrelated_identity_does_not_invent_prediction(self):
        identity = Identity(self.roi)
        identity.enroll(self.image, np.eye(3), self.mask)
        self.assertIsNone(identity.predict(self.image))
        unrelated = prepare(np.random.default_rng(12).integers(0, 256, self.image.shape, np.uint8))
        identity.enroll(unrelated, np.eye(3), self.mask)
        self.assertIsNone(identity.predict(np.zeros_like(self.image)))
        empty = Identity(self.roi)
        empty.enroll(np.zeros_like(self.image), np.eye(3), self.mask)
        self.assertIsNone(empty.predict(self.image))


if __name__ == '__main__':
    unittest.main()
