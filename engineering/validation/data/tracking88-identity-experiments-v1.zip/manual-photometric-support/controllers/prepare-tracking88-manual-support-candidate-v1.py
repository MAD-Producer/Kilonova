from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-manual-support-candidate-v1'
SRC = OUT / 'candidate/tools/tracking'
SRC.mkdir(parents=True, exist_ok=False)
BASE = '147ced69e08189b73d53760873c9ed72bc34fa36'
for name in ['plate_contract.py', 'plate_flow.py', 'track_plate.py', 'test_flow.py', 'validate_prototype.py']:
    (SRC / name).write_bytes(subprocess.check_output(['git', 'show', f'{BASE}:tools/tracking/{name}'], cwd=WORK))

(SRC / 'plate_manual_support.py').write_text('''"""Manual-only reference bank selects real plane-consistent source features.

No automatic enrollment, ground truth, or additional visible observations.
"""
import cv2
import numpy as np
from plate_flow import flow, LIMITS


class ManualSupport:
    def __init__(self):
        self.references = []
        self.last_supported = 0
        self.last_selected = False

    def select(self, gray, matrix, points):
        consistent = np.zeros(len(points), bool)
        extent = (gray.shape[1], gray.shape[0])
        nearest = np.rint(points).astype(np.int32)
        nearest[:, 0] = np.clip(nearest[:, 0], 0, extent[0]-1)
        nearest[:, 1] = np.clip(nearest[:, 1], 0, extent[1]-1)
        for reference, original_matrix in reversed(self.references):
            warp = matrix @ np.linalg.inv(original_matrix)
            aligned = cv2.warpPerspective(reference, warp, extent)
            support = cv2.warpPerspective(np.full(reference.shape, 255, np.uint8), warp, extent)
            support = cv2.erode(support, np.ones((23, 23), np.uint8),
                borderType=cv2.BORDER_CONSTANT, borderValue=0)
            measured, valid, _ = flow(gray, aligned, points, initial=points)
            consistent |= (valid & (np.linalg.norm(measured-points, axis=1) <= LIMITS['referenceAgreementPixels'])
                           & (support[nearest[:, 1], nearest[:, 0]] == 255))
        self.last_supported = int(consistent.sum())
        self.last_selected = self.last_supported >= LIMITS['minimumFeatures']
        # No reference evidence is not proof that a feature is background.
        # When support is insufficient this initializer preserves the original
        # measurement path and all original publication checks.
        selected = points[consistent] if self.last_selected else points
        self.references.append((gray, matrix.copy()))
        if len(self.references) > 4:
            self.references.pop(1)
        return selected
''', encoding='utf-8')
path = SRC / 'plate_flow.py'
before = path.read_text(encoding='utf-8')
needle = '        reference = transform(np.linalg.inv(matrix), points)'
assert before.count(needle) == 1
after = before.replace(needle, '''        from plate_manual_support import ManualSupport
        if not hasattr(self, 'manual_support'):
            self.manual_support = ManualSupport()
        points = self.manual_support.select(gray, matrix, points)
''' + needle)
path.write_text(after, encoding='utf-8')

(SRC / 'test_manual_support.py').write_text('''"""Analytic two-motion control, independent of production fit estimates."""
import unittest
import cv2
import numpy as np
from plate_manual_support import ManualSupport
from plate_flow import prepare


class SupportControls(unittest.TestCase):
    def test_manual_plane_motion_selects_target_and_rejects_stationary_background(self):
        cv2.setNumThreads(1)
        image = prepare(np.random.default_rng(887722).integers(0, 256, (240, 320), np.uint8))
        mask = np.zeros(image.shape, np.uint8)
        mask[48:192, 48:272] = 255
        seed = cv2.goodFeaturesToTrack(image, 160, .01, 7, mask=mask).reshape(-1, 2)
        support = ManualSupport()
        support.select(image, np.eye(3), seed)
        initial_image = support.references[0][0].copy()
        manual = np.array([[1., 0., 12.], [0., 1., 8.], [0., 0., 1.]])
        shifted = cv2.warpPerspective(image, manual, (320, 240))
        # Only the left half moves with the explicitly authored plane.
        current = image.copy()
        current[:, :160] = shifted[:, :160]
        points = cv2.goodFeaturesToTrack(current, 160, .01, 7, mask=mask).reshape(-1, 2)
        selected = support.select(current, manual, points)
        self.assertTrue(support.last_selected)
        self.assertGreaterEqual(len(selected), 16)
        self.assertGreater(np.count_nonzero(points[:, 0] > 190), 20)
        self.assertLess(np.count_nonzero(selected[:, 0] > 190), 3)
        for _ in range(7):
            support.select(current, manual, points)
        self.assertEqual(len(support.references), 4)
        self.assertTrue(np.array_equal(support.references[0][0], initial_image))


if __name__ == '__main__':
    unittest.main()
''', encoding='utf-8')
(OUT / 'proposal.json').write_text(json.dumps(dict(status='external_blind_candidate_not_adopted', base=BASE,
    files={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in SRC.glob('*.py')}), indent=2), encoding='utf-8')
print(OUT)
