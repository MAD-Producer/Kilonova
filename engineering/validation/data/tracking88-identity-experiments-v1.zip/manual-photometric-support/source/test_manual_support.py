"""Analytic two-motion control, independent of production fit estimates."""
import unittest
import cv2
import numpy as np
from plate_manual_support import ManualSupport
from plate_flow import prepare


class SupportControls(unittest.TestCase):
    def test_manual_plane_motion_selects_target_and_rejects_stationary_background(self):
        cv2.setNumThreads(1)
        image = prepare(np.random.default_rng(887722).integers(0, 256, (240, 320), np.uint8))
        mask = np.zeros(image.shape, np.uint8)
        mask[48:192, 48:272] = 255
        seed = cv2.goodFeaturesToTrack(image, 160, .01, 7, mask=mask).reshape(-1, 2)
        support = ManualSupport()
        support.select(image, np.eye(3), seed)
        initial_image = support.references[0][0].copy()
        manual = np.array([[1., 0., 12.], [0., 1., 8.], [0., 0., 1.]])
        shifted = cv2.warpPerspective(image, manual, (320, 240))
        # Only the left half moves with the explicitly authored plane.
        current = image.copy()
        current[:, :160] = shifted[:, :160]
        points = cv2.goodFeaturesToTrack(current, 160, .01, 7, mask=mask).reshape(-1, 2)
        selected = support.select(current, manual, points)
        self.assertTrue(support.last_selected)
        self.assertGreaterEqual(len(selected), 16)
        self.assertGreater(np.count_nonzero(points[:, 0] > 190), 20)
        self.assertLess(np.count_nonzero(selected[:, 0] > 190), 3)
        for _ in range(7):
            support.select(current, manual, points)
        self.assertEqual(len(support.references), 4)
        self.assertTrue(np.array_equal(support.references[0][0], initial_image))


if __name__ == '__main__':
    unittest.main()
