"""Manual-only reference bank selects real plane-consistent source features.

No automatic enrollment, ground truth, or additional visible observations.
"""
import cv2
import numpy as np
from plate_flow import flow, LIMITS


class ManualSupport:
    def __init__(self):
        self.references = []
        self.last_supported = 0
        self.last_selected = False

    def select(self, gray, matrix, points):
        consistent = np.zeros(len(points), bool)
        extent = (gray.shape[1], gray.shape[0])
        nearest = np.rint(points).astype(np.int32)
        nearest[:, 0] = np.clip(nearest[:, 0], 0, extent[0]-1)
        nearest[:, 1] = np.clip(nearest[:, 1], 0, extent[1]-1)
        for reference, original_matrix in reversed(self.references):
            warp = matrix @ np.linalg.inv(original_matrix)
            aligned = cv2.warpPerspective(reference, warp, extent)
            support = cv2.warpPerspective(np.full(reference.shape, 255, np.uint8), warp, extent)
            support = cv2.erode(support, np.ones((23, 23), np.uint8),
                borderType=cv2.BORDER_CONSTANT, borderValue=0)
            measured, valid, _ = flow(gray, aligned, points, initial=points)
            consistent |= (valid & (np.linalg.norm(measured-points, axis=1) <= LIMITS['referenceAgreementPixels'])
                           & (support[nearest[:, 1], nearest[:, 0]] == 255))
        self.last_supported = int(consistent.sum())
        self.last_selected = self.last_supported >= LIMITS['minimumFeatures']
        # No reference evidence is not proof that a feature is background.
        # When support is insufficient this initializer preserves the original
        # measurement path and all original publication checks.
        selected = points[consistent] if self.last_selected else points
        self.references.append((gray, matrix.copy()))
        if len(self.references) > 4:
            self.references.pop(1)
        return selected
