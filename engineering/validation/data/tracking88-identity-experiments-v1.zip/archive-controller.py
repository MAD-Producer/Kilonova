from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
OUT = ART / 'tracking88-identity-review-v1'
OUT.mkdir(exist_ok=False)
members = {}
variants = []
sha = lambda data: hashlib.sha256(data).hexdigest()
baseline_path = ART / 'tracking88-photographed-prototype-v6/measurement.json'
baseline = json.loads(baseline_path.read_text(encoding='utf-8'))
plane = lambda report: next(t for t in next(r for r in report['runs'] if r['mode'] == 'periodic-manual-200')['tracks'] if t['track'] == 'plane')
baseline_plane = plane(baseline)
assert baseline_plane['automaticVisible'] == 915 and baseline_plane['automaticOver15Pixels'] == 21
members['baseline/measurement.json'] = baseline_path.read_bytes()
original_request = json.loads((ART / 'tracking88-photographed-descriptor-v1/periodic-manual-200.request.json').read_text(encoding='utf-8'))

for label, stem, controls in [('persistent-descriptors', 'identity', 'identity-controls'),
                              ('manual-photometric-support', 'manual-support', 'support-controls')]:
    candidate = ART / f'tracking88-{stem}-candidate-v1'
    measurement = ART / f'tracking88-photographed-{stem}-v1'
    execution = json.loads((candidate / 'exit.json').read_text(encoding='utf-8'))
    assert execution['status'] == 'candidate_controls_synthetic_and_full_real_measured_not_adopted'
    assert len(execution['steps']) == 4 and all(step['exitCode'] == 0 for step in execution['steps'])
    report = json.loads((measurement / 'measurement.json').read_text(encoding='utf-8'))
    request = json.loads((measurement / 'periodic-manual-200.request.json').read_text(encoding='utf-8'))
    assert request == original_request, 'original request, ROI or edits changed'
    assert report['sourceSha256'] == baseline['sourceSha256']
    assert report['annotationSha256'] == baseline['annotationSha256']
    result = plane(report)
    assert result['automaticOver15Pixels'] == 21 and result['automaticVisible'] < baseline_plane['automaticVisible']
    assert (candidate / 'candidate/tools/tracking/test_flow.py').read_bytes() == (ART / 'tracking88-descriptor-candidate-v1/candidate/tools/tracking/test_flow.py').read_bytes()
    for name, digest in execution['source'].items():
        data = (candidate / 'candidate/tools/tracking' / name).read_bytes()
        assert sha(data) == digest, name
        members[f'{label}/source/{name}'] = data
    for name in ['exit.json', 'proposal.json', 'experiment-controller.py', 'real-controller.py',
                 controls+'.stdout.log', controls+'.stderr.log', 'controls.stdout.log', 'controls.stderr.log',
                 'synthetic.stdout.log', 'synthetic.stderr.log', 'full-real.stdout.log', 'full-real.stderr.log',
                 'synthetic/evaluation.json']:
        members[f'{label}/{name}'] = (candidate / name).read_bytes()
    members[f'{label}/measurement.json'] = (measurement / 'measurement.json').read_bytes()
    for name in ['periodic-manual-200.stdout.log', 'periodic-manual-200.stderr.log',
                 'no-corrections.stdout.log', 'no-corrections.stderr.log']:
        members[f'{label}/real/{name}'] = (measurement / name).read_bytes()
    for name in [f'prepare-tracking88-{stem}-candidate-v1.py', f'experiment-tracking88-{stem}-v1.py']:
        members[f'{label}/controllers/{name}'] = (ROOT / '.tools/issue-closure-review' / name).read_bytes()
    variants.append(dict(candidate=label, decision='rejected_not_adopted', plane=result,
        originalRequestCanonicalSha256=sha(json.dumps(request, sort_keys=True).encode()),
        reason='All 21 over-15-pixel failures remain and automatic coverage is lower. Analytic control success does not qualify photographed motion.'))

for stem in ['tracking88-descriptor-review-v1/tracking88-descriptor-rejected-v1',
             'tracking88-reference-identity-review-v1/tracking88-reference-identity-v1']:
    for suffix in ['.json', '.zip']:
        path = ART / (stem + suffix)
        members['preceding/' + path.name] = path.read_bytes()
members['archive-controller.py'] = Path(__file__).read_bytes()
archive = OUT / 'tracking88-identity-experiments-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted(members.items()):
        bundle.writestr(name, data)
with zipfile.ZipFile(archive) as bundle:
    assert set(bundle.namelist()) == set(members)
    assert all(bundle.read(name) == data for name, data in members.items())
result = dict(status='two_failed_blind_identity_candidates_archived_not_adopted',
    base='147ced69e08189b73d53760873c9ed72bc34fa36', baseline=baseline_plane, variants=variants,
    scope='Original 2300 frames, source/timeline/truth/ROI/corrections and all existing assertions unchanged. No native, Surface, CI or full-issue acceptance follows.',
    exclusion='No third-party video, photographs, derived captures, annotations, original requests containing annotations, or per-frame observation payloads redistributed.',
    nextBoundary='Initialization and manual support selection alone did not resolve the common-mode residual failure. Investigate correspondence/model uncertainty before more initializer variants; do not tune confidence or loss suppression against this sequence.',
    archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
        members={name: dict(bytes=len(data), sha256=sha(data)) for name, data in sorted(members.items())}))
(OUT / 'tracking88-identity-experiments-v1.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps({key: result[key] for key in ['status', 'baseline', 'variants']}, indent=2))
print('Verified archive:', archive.stat().st_size, 'bytes;', len(members), 'members')
