"""Read-only assertions over the ordinary desktop process receipts."""
import json
from pathlib import Path

BASE = Path(__file__).parent


def states(folder, ids):
    return {i: json.loads((folder / f'reply-{i}.json').read_text('utf-8'))['state'] for i in ids}


zh = BASE / 'keyframe-selection-os-main-zh-fixed'
s = states(zh, [4, 6, 8, 15, 17, 32, 34, 36])
p = {i: v['project'] for i, v in s.items()}
zh_result = {
    'f9Changed': p[4] != p[6],
    'f9UndoExact': p[4] == p[8],
    'summaryDeleteAllKeys': not p[15]['layers'][0]['transform']['position']['keys']
    and all(not a['keys'] for a in p[15]['layers'][1]['transform']['position']['axes'].values()),
    'summaryUndoExact': p[4] == p[17],
    'graphEscapeAndLateReleaseUnchanged': p[4] == p[32],
    'graphDeleteSelectedChannel': not p[34]['layers'][0]['transform']['position']['keys'],
    'graphKeepsUnselectedLayer': p[4]['layers'][1] == p[34]['layers'][1],
    'graphUndoExact': p[4] == p[36],
    'oneUndoItem': s[34]['history']['undoEntries'] == 1,
}
assert all(zh_result.values()), zh_result
(zh / 'native-project-results.json').write_text(json.dumps(zh_result, indent=2), 'utf-8')

en = BASE / 'keyframe-selection-os-float-en'
s = states(en, [11, 13, 15, 18, 20, 26, 28, 37, 39, 41, 43])
p = {i: v['project'] for i, v in s.items()}
en_result = {
    'f9Changed': p[11] != p[13],
    'f9UndoExact': p[11] == p[15],
    'toggleDeletesExactlyFirstKey': p[18]['layers'][0]['transform']['position']['keys']
    == [p[11]['layers'][0]['transform']['position']['keys'][1]],
    'toggleKeepsOtherLayer': p[11]['layers'][1] == p[18]['layers'][1],
    'toggleUndoExact': p[11] == p[20],
    'summaryDeleteAllKeys': not p[26]['layers'][0]['transform']['position']['keys']
    and all(not a['keys'] for a in p[26]['layers'][1]['transform']['position']['axes'].values()),
    'summaryUndoExact': p[11] == p[28],
    'graphDeleteSelectedChannel': not p[37]['layers'][0]['transform']['position']['keys'],
    'graphKeepsUnselectedLayer': p[11]['layers'][1] == p[37]['layers'][1],
    'graphUndoExact': p[11] == p[39],
    'graphRedoExact': p[37] == p[41],
    'saveSnapshotExact': p[41] == p[43],
    'oneUndoItem': s[37]['history']['undoEntries'] == 1,
    'redoOneItem': s[41]['history']['undoEntries'] == 1 and s[41]['history']['redoEntries'] == 0,
}
assert all(en_result.values()), en_result
(en / 'native-project-results.json').write_text(json.dumps(en_result, indent=2), 'utf-8')

reopen = BASE / 'keyframe-selection-os-reopen-zh'
fresh = states(reopen, [1])[1]
old_pid = json.loads((en / 'ready.json').read_text('utf-8'))['pid']
new_pid = json.loads((reopen / 'ready.json').read_text('utf-8'))['pid']
reopen_result = {
    'fullProjectExact': fresh['project'] == p[43],
    'freshHistoryEmpty': fresh['history']['undoEntries'] == 0 and fresh['history']['redoEntries'] == 0,
    'differentOSProcess': old_pid != new_pid,
}
assert all(reopen_result.values()), reopen_result
(reopen / 'reopen-results.json').write_text(json.dumps(reopen_result, indent=2), 'utf-8')

# JSON-RPC stdout must remain machine-readable at the default logging level.
for folder in [zh, en, reopen]:
    records = [json.loads(line) for line in (folder / 'stdout.jsonl').read_text('utf-8').splitlines() if line]
    assert records and all(record.get('jsonrpc') == '2.0' for record in records)
    assert json.loads((folder / ('reply-41.json' if folder == zh else 'reply-44.json' if folder == en else 'reply-2.json')).read_text('utf-8'))['exit'] == 0

final_results = {}
for name in ['main-en-final', 'float-zh-final']:
    folder = BASE / ('keyframe-selection-os-' + name)
    s = states(folder, [5, 7, 9, 15, 17, 19, 21, 23])
    p = {i: v['project'] for i, v in s.items()}
    remaining = p[17]['layers'][0]['transform']['position']['keys']
    axes = p[17]['layers'][1]['transform']['position']['axes']
    result = {
        'f9Changed': p[5] != p[7],
        'f9UndoExact': p[5] == p[9],
        'escapeAndLateReleaseExact': p[5] == p[15],
        'deleteExactFirstKey': remaining == [p[5]['layers'][0]['transform']['position']['keys'][1]],
        'deleteExactSeparatedKeys': all(axis['keys'] == [p[5]['layers'][1]['transform']['position']['axes'][k]['keys'][1]] for k, axis in axes.items()),
        'deleteUndoExact': p[5] == p[19],
        'deleteRedoExact': p[17] == p[21],
        'saveSnapshotExact': p[17] == p[23],
        'oneUndoItem': s[17]['history']['undoEntries'] == 1,
        'cleanExit': json.loads((folder / 'reply-24.json').read_text('utf-8'))['exit'] == 0,
        'stdoutIsolated': all(json.loads(line).get('jsonrpc') == '2.0' for line in (folder / 'stdout.jsonl').read_text('utf-8').splitlines() if line),
    }
    (folder / 'native-project-results.json').write_text(json.dumps(result, indent=2), 'utf-8')
    assert all(result.values()), (name, result)
    final_results[name] = result

print(json.dumps({'zh_main': zh_result, 'en_float': en_result, 'independent_reopen': reopen_result, 'final_build': final_results}, indent=2))
