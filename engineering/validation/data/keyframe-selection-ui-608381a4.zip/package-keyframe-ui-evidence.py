"""Archive completed raw evidence without copying runtimes or foreign assets."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

ART = Path(__file__).parent
WT = Path('E:/Dev/aem/.worktrees/layer-clipboard')
OUT = WT / 'engineering/validation'
SOURCE = '608381a4'

final = (ART / 'keyframe-selection-panel-regressions-final.log').read_text('utf-8')
matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;.*?finished in ([\d.]+)s', final)
assert matches and int(matches[-1][1]) == 0 and int(matches[-1][0]) >= 531, matches

captures = {
    'zh-summary-selection.png': 'keyframe-selection-os-main-zh-fixed/main-zh-selected-summary-keys.png',
    'zh-summary-marquee.png': 'keyframe-selection-os-main-zh-fixed/main-zh-marquee.png',
    'zh-graph-selection.png': 'keyframe-selection-os-main-zh-fixed/main-zh-graph-selected.png',
    'en-float-cross-layer-selection.png': 'keyframe-selection-os-float-en/float-en-cross-layer-selection.png',
    'en-float-summary-marquee.png': 'keyframe-selection-os-float-en/float-en-marquee.png',
    'en-float-graph-selection.png': 'keyframe-selection-os-float-en/float-en-graph-selected.png',
}
capture_dir = OUT / 'keyframe-selection-ui'
capture_dir.mkdir(exist_ok=True)
for name, relative in captures.items():
    shutil.copy2(ART / relative, capture_dir / name)

files = set()
for file in ART.glob('keyframe-selection-*'):
    if file.is_file() and file.suffix in {'.log', '.json', '.py'}:
        files.add(file)
for name in ['keyframe-selection-os-main-zh', 'keyframe-selection-os-main-zh-fixed',
             'keyframe-selection-os-float-en', 'keyframe-selection-os-reopen-zh',
             'keyframe-selection-os-main-en-final', 'keyframe-selection-os-float-zh-final',
             'keyframe-selection-ui-faults-first']:
    for file in (ART / name).rglob('*'):
        if file.is_file() and file.suffix in {'.log', '.json', '.jsonl', '.png'}:
            files.add(file)
files.update(ART / name for name in ['prepare-keyframe-selection-os-driver.py',
    'drive-keyframe-os-actions.py', 'verify-keyframe-native-results.py', Path(__file__).name])
archive = OUT / 'data' / f'keyframe-selection-ui-{SOURCE}.zip'
archive.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for file in sorted(files):
        z.write(file, file.relative_to(ART).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None

sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
results = {
    'issue': 216,
    'sourceCommit': SOURCE,
    'initialScreenshotCommit': '322182b9',
    'platform': 'Windows x86_64; ordinary FFmpeg debug desktop build, native Vulkan, 96 DPI',
    'tests': {
        'panelFinal': {'passed': int(matches[-1][0]), 'failed': 0, 'seconds': float(matches[-1][2])},
        'panelFirst': {'passed': 519, 'failed': 11, 'seconds': 462.43, 'retained': True},
        'panelSecond': {'passed': 530, 'failed': 1, 'seconds': 425.71, 'retained': True},
        'navigationFocusFix': {'passed': 9, 'seconds': 8.27, 'includedInPanelFinal': True},
        'keySelectionFinalTargeted': {'passed': 24, 'seconds': 9.50, 'includedInPanelFinal': True},
        'coreFoundation': {'passed': 26, 'reference': 'keyframe-selection-foundation-results.json'},
        'noSummedUniquePassClaim': True,
    },
    'ordinaryOSInput': {
        'zhMain': json.loads((ART / 'keyframe-selection-os-main-zh-fixed/native-project-results.json').read_text('utf-8')),
        'enNativeFloating': json.loads((ART / 'keyframe-selection-os-float-en/native-project-results.json').read_text('utf-8')),
        'freshProcessReopenZh': json.loads((ART / 'keyframe-selection-os-reopen-zh/reopen-results.json').read_text('utf-8')),
        'finalBuildMainEn': json.loads((ART / 'keyframe-selection-os-main-en-final/native-project-results.json').read_text('utf-8')),
        'finalBuildFloatZh': json.loads((ART / 'keyframe-selection-os-float-zh-final/native-project-results.json').read_text('utf-8')),
        'inputMechanism': 'OS mouse and keyboard events with HWND ownership assertions; MCP only reads state; no editor input hooks',
        'screenshotMechanism': 'ImageGrab of actual owning native window, original pixels; geometry JSON retained',
        'fullFourLocaleHostMatrix': 'ordinary OS processes exercise selection, F9, Delete, cancellation, undo/redo in all four combinations; native graph exercised in zh main and en float; actual chrome tests cover the full graph/host/locale matrix',
    },
    'defaultFailureChannels': {
        'actualEditorActionFailures': 'See foundation results: six actual typed edit failures; unchanged project/revision and successful recovery.',
        'actualUICaptureFailure': 'Original authored key array missing cause, localized UI message, file and Error stderr; unchanged selection.',
        'scopeMissing': '120 actual chrome presses; old controllers blocked; first Warn, Error at 60, later suppression; healthy selection recovers.',
        'stdoutIsolated': True,
        'normalCancellationAndMissNotFaults': True,
        'counterScope': 'process lifetime per static site, no one-second or consecutive-reset claim',
    },
    'limitsAndRetainedFailures': [
        'First OS fixture had axes plus coupled value/keys; strict TrackRepresentation rejected it. Fixture fixed; original logs retained.',
        'The first zh plan used Ctrl+Y for redo, which creates a null layer by current defaults. Correct Ctrl+Shift+Z verified in en float; initial failed receipts retained.',
        'Raw saved JSON serializes f32 shortest decimal forms while snapshot JSON expands f32 to f64. Full authoritative project equality verified after actual independent-process reopen, not raw text equality.',
        'First toggle verifier incorrectly expected both original keys deleted although one was toggled off; exact remaining frame/value assertion replaces that artifact-script mistake.',
        'A physical Shift+F3 attempt did not toggle the view. The actual toolbar button was used; no native keyboard graph-toggle acceptance claim.',
        'Floating window initially showed an unpainted surface until real click; original startup/probe captures retained. Initial floating exposure is outside this selection change.',
        'Existing Epic Vulkan layer registration errors, platform memory probe warning, and synthetic-atlas missing glyph records retained; no clean global log claim.',
        'No multi-key dragging (#217), interpolation dialog (#218), new right-click actions, asset, dependency, or native cross-platform acceptance added.',
    ],
    'captures': {name: {'origin': relative, 'sha256': sha(capture_dir / name)} for name, relative in captures.items()},
    'archive': {'path': 'data/' + archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive), 'members': len(files), 'crcVerified': True},
    'rawFiles': {p.relative_to(ART).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(files)},
}
(OUT / 'keyframe-selection-ui-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n', 'utf-8')
print(json.dumps({'tests': results['tests'], 'archive': results['archive']}, indent=2))
