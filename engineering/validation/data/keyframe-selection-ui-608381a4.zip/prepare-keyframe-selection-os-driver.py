from pathlib import Path

folder=Path('E:/Dev/aem/artifacts/pr-ci-followups')
script=(folder/'clipboard-pointer-entry-settled-driver.py').read_text('utf-8')
script=script.replace('MOTION_ANIMATION_OS_','MOTION_KEYFRAME_OS_')
script=script.replace('clipboard-pointer-entry-runtime','keyframe-selection-ui-runtime')
script=script.replace('animation-os-main','keyframe-selection-os-main-zh')
script=script.replace("'sourceCommit':'d3074562ccbb85a185bcc886a3971aa6e314fccd'", "'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd='E:/Dev/aem/.worktrees/layer-clipboard',text=True).strip()")
start=script.index('p[\'layers\']=[first,second,controller]')
end=script.index("(project / 'project.json').write_text",start)
script=script[:start]+'''p['layers']=[first,second]
p['width']=640; p['height']=360; p['frames']=120
for layer,offset,name in zip(p['layers'],[7,40],['Position study','Separated axes']):
    layer['id']=7 if offset==7 else 9
    layer['name']=name
    layer['timeline']={'in_frame':offset,'out_frame':110,'offset_frame':offset}
    layer['transform']['position']={'value':[0.,0.,0.], 'keys':[
        {'frame':frame,'value':[float(frame),20.,0.],'ease':'linear'} for frame in [3,13]]}
    if offset==40:
        layer['transform']['position']={'axes':{
            axis:{'value':0.,'keys':[{'frame':f,'value':float(f) if axis=='x' else (20. if axis=='y' else 0.),'ease':'linear'} for f in [3,13]]}
            for axis in ['x','y','z']}}
''' + script[end:]
# On-screen captures are accompanied by geometry so all input coordinates can
# be traced back to the owning physical client, without exposing editor hooks.
script=script.replace("ImageGrab.grab(bbox=(r.left, r.top, r.right, r.bottom)).save(BASE / (name + '.png'))", "ImageGrab.grab(bbox=(r.left, r.top, r.right, r.bottom)).save(BASE / (name + '.png'))\n    (BASE / (name + '-geometry.json')).write_text(json.dumps({'windowRect':[r.left,r.top,r.right,r.bottom],'windows':windows(),'hwnd':hwnd},indent=2),'utf-8')")
start=script.index("project = BASE / 'project'")
end=script.index("settings = json.loads", start)
fixture=script[start:end]
script=script[:start]+"""existing_project = os.environ.get('MOTION_KEYFRAME_OS_PROJECT')
if existing_project:
    project = Path(existing_project)
    assert (project / 'project.json').is_file(), project
else:
"""+''.join('    '+line+'\n' for line in fixture.splitlines())+script[end:]

target=folder/'keyframe-selection-os-driver.py'
target.write_text(script,'utf-8')
compile(script,str(target),'exec')
print(target)
