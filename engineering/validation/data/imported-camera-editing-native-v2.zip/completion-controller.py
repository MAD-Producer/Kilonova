from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

root=Path('E:/Dev/aem')
work=root/'.worktrees/camera-source-editing'
gate=root/'artifacts/pr-queue/camera-source-editing-native-v2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=work).decode().strip()
r=json.loads((gate/'accepted.json').read_text(encoding='utf-8'))
assert git('rev-parse','HEAD')==r['head'] and not git('status','--porcelain')
assert all(sha(work/p)==h for p,h in r['source'].items())
assert all(s['exitCode']==0 and s['sourceUnchanged'] for s in r['steps'])
counts={s['name']:s['totals'] for s in r['steps'] if 'totals' in s}
assert sum(v['passed'] for v in counts.values())==748
assert all(v['failed']==0 and v['ignored']==0 for v in counts.values())
out=root/'artifacts/pr-queue/imported-camera-editing-complete-v1'
out.mkdir(exist_ok=False)
archive=work/'engineering/validation/data/imported-camera-editing-native-v2.zip'
payload={}
for directory in sorted((root/'artifacts/pr-queue').glob('camera-source-editing-*')):
    for p in directory.rglob('*'):
        if p.is_file(): payload[directory.name+'/'+p.relative_to(directory).as_posix()]=p.read_bytes()
payload['completion-controller.py']=Path(__file__).read_bytes()
payload['source.patch']=subprocess.check_output(['git','diff','--binary',r['base'],r['head']],cwd=work)
manifest={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in payload.items()}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for k,v in payload.items():z.writestr(k,v)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(manifest)+1
    for k,v in manifest.items():
        data=z.read(k)
        assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
doc=work/'engineering/validation/imported-camera-editing-current.md'
text=doc.read_text(encoding='utf-8')
old='''Four new focused tests pass: two renderer/semantic tests and two actual host
operation tests. A source-bound affected regression gate is pending. This is not
full-workspace, cross-platform or final issue acceptance.'''
assert old in text
text=text.replace(old,'''The frozen local regression gate passes **748 tests, 0 failed, 0 ignored**:
93 model tests across 23 targets, 80 affected core tests across 15 targets,
450 native renderer tests across 18 targets, and 125 host tests across seven
targets. Desktop FFmpeg/AI-depth compilation, provenance and panel-style checks
also pass. Four new tests (two renderer/semantic and two actual host operation
tests) are included in those totals. This is selected affected regression, not
full-workspace, cross-platform or final issue acceptance. Prior checkpoint
counts overlap and are not additional coverage.

The gate ran against main `7dfab923a1b4005e2c8b31460bbe766738f78a10`,
dependency head `8b1610282864e4738c7fe245f1ab9e9644c5f0f4` and source head
`e92635a68037b924de725e662311ef4ecc1684af`. Every source hash was verified
after each step. The completion amendment changes only this document and the
evidence archive. No existing assertions, tolerances, timeouts, budgets or skips
were changed.

The first full gate caught an existing missing-source regression: early catalog
validation had dropped the original missing-source cause and required node
context. Product code now preserves both. The unchanged existing regression test
passes in v2. Its failed v1 output and all initial focused fixture corrections
are retained alongside the successful gate.''')
text+=f'''\n[Source-bound evidence](data/imported-camera-editing-native-v2.zip), SHA-256
`{sha(archive)}`, {archive.stat().st_size} bytes. It retains changed source,
the dependency-relative patch, exact commands, raw logs, exit receipts and prior
failed attempts. Every archive entry was read back and SHA-256 verified.\n'''
doc.write_text(text,encoding='utf-8',newline='\n')
subprocess.run(['git','diff','--check'],cwd=work,check=True)
subprocess.run(['git','add','--',str(doc.relative_to(work)),str(archive.relative_to(work))],cwd=work,check=True)
subprocess.run(['git','commit','--amend','--no-edit'],cwd=work,check=True)
subprocess.run(['git','show','--stat','--oneline','HEAD'],cwd=work,check=True)
assert not git('status','--porcelain') and all(sha(work/p)==h for p,h in r['source'].items())
result=dict(head=git('rev-parse','HEAD'),testedHead=r['head'],base=r['base'],
    completedUtc=datetime.now(timezone.utc).isoformat(),totals=counts,archiveSha256=sha(archive),published=False)
(out/'completed.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
