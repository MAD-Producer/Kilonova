from pathlib import Path
import hashlib, json, subprocess, zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
old = root / 'artifacts/pr-queue/clock85-aligned-runtime-v1'
new = root / 'artifacts/pr-queue/clock85-aligned-runtime-v2'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
v1 = json.loads((old / 'exit.json').read_text(encoding='utf-8'))
v2 = json.loads((new / 'exit.json').read_text(encoding='utf-8'))
assert v1['status'] == 'failed_original_outputs_retained'
assert v2['status'] == 'aligned_main_complete_desktop_ui_passed_with_documented_codegen_overrides'
assert v1['head'] == v2['head'] and v1['main'] == v2['main']
assert v1['source'] == v2['source'] and v1['sourceUnchanged'] and v2['sourceUnchanged']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip() == v2['head']
assert all(sha(work / n) == h for n, h in v2['source'].items())
assert len(v1['steps']) == 4 and v1['steps'][-1]['exitCode'] != 0
assert v1['steps'][-1]['summaries'] == []
assert len(v2['steps']) == 1
accepted = v1['steps'][:3] + v2['steps']
assert all(s['exitCode'] == 0 for s in accepted)
totals = {}
for step in accepted:
    if step['name'] == 'check':
        continue
    assert len(step['summaries']) == len(step['invocations'])
    count = [sum(int(s[i]) for s in step['summaries']) for i in (1, 2, 3, 5)]
    assert count[1] == count[3] == 0
    totals[step['name']] = dict(passed=count[0], failed=0, originalIgnored=count[2], filtered=0, targets=len(step['summaries']))
assert len(v2['steps'][0]['expectedTargets']) == totals['desktop-ui']['targets']
audit = dict(status='same_source_check_render_host_and_complete_desktop_ui_passed_with_documented_codegen_overrides', head=v2['head'], main=v2['main'], totals=totals, limits=v2['limits'], preservedOriginalFailure=dict(status=v1['status'], command=v1['steps'][-1]['command'], exitCode=v1['steps'][-1]['exitCode'], testsExecuted=0))
(new / 'independent-summary.json').write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
entries = {}
for label, directory in [('aligned-v1', old), ('aligned-v2', new), ('compiler-observer-v1', root / 'artifacts/pr-queue/clock85-ui-compiler-v1'), ('compiler-v2', root / 'artifacts/pr-queue/clock85-ui-compiler-v2')]:
    for p in directory.iterdir():
        if p.is_file() and p.suffix in ('.py', '.json', '.log', '.txt'):
            entries[f'{label}/{p.name}'] = p
for version in (1, 2):
    entries[f'environment/runtime-v{version}.ps1'] = root / f'.tools/issue-closure-review/run-clock85-aligned-runtime-v{version}.ps1'
entries['environment/publish.py'] = Path(__file__)
manifest = dict(audit=audit, entries={n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n,p in entries.items()})
archive = work / 'engineering/validation/data/frame-rate85-aligned-runtime-v2.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
    for n,p in entries.items():
        z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n,p in entries.items():
        assert hashlib.sha256(z.read(n)).hexdigest() == sha(p)
receipt = dict(audit=audit, archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=len(entries)+1)
archive.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
(work / 'engineering/validation/frame-rate85-aligned-runtime-current.md').write_text(f'''# Runtime regression after current main integration

Frozen combined source `{v2['head']}`, including main `{v2['main']}`, passed
desktop/FFmpeg check, seven selected render targets, host unit tests and complete
desktop/UI tests including UI documentation tests. Accepted commands exited zero
and every captured source hash remained unchanged.

| Actual scope | Passed | Failed | Original ignored | Filtered | Targets |
| --- | ---: | ---: | ---: | ---: | ---: |
''' + ''.join(f"| {name} | {t['passed']} | 0 | {t['originalIgnored']} | 0 | {t['targets']} |\n" for name,t in totals.items()) + f'''
Check/render/host results come from the first attempt on exactly the same source.
Its subsequent desktop/UI compilation failed: the UI `path_antialiasing` rustc
process exited one without a specific diagnostic, before any runtime test.
The raw failure is retained, not described as a source error or an established
compiler crash. An initial diagnostic observer then failed before compiler
launch because of its own text decoding. A separate exact-command experiment
with UI test `codegen-units=4` compiled successfully; no runtime acceptance is
claimed for that diagnostic alone.

The complete desktop/UI second attempt uses test-only `codegen-units=4` for
both desktop and UI. Cargo invocations were matched against metadata. No
assertion, execution deadline, original ignore, stack, adapter, backend or
production compiler profile changed. Earlier check/render/host counts are
included once, and historical parent model/core counts are not added.

All controlled caches and temporary files used E, with default Info and adapter
selection. One own GPU workload executed. A later CPU-only camera-adapter
conversion/check ran against a separate source worktree while the static
desktop test binary continued; no second GPU test was launched. It does not
change this captured source closure or establish freedom from machine load.

This evidence covers main integration source, including video lens rendering
and node geometry. It does not prove repair of historical compiler/native
failures, original CI expression admission timing, photographic quality or the
entire 3D route. Android is excluded. Final exact-head cross-platform CI and
remaining issue-level acceptance stay separate requirements.

The [archive](data/frame-rate85-aligned-runtime-v2.zip) retains both attempts,
diagnostic records, source hashes, metadata and raw output. Every member was
read back and hash-verified; the
[receipt](data/frame-rate85-aligned-runtime-v2.json) binds scope and limits.
''', encoding='utf-8')
print(json.dumps(dict(totals=totals, bytes=receipt['bytes'], sha256=receipt['sha256'], members=receipt['members'])), flush=True)
