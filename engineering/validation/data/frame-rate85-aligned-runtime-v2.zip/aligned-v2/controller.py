from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/clock85-aligned-runtime-v2'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
git = lambda *a: subprocess.check_output(['git', *a], cwd=work).decode().strip()
assert git('rev-parse', 'HEAD') == '2927799f1fd2f3af06f9f5eb83c52323b91a00f2'
assert not git('status', '--porcelain')
main = git('rev-parse', 'origin/main')
assert main.startswith('351d09b2')
subprocess.run(['git', 'merge-base', '--is-ancestor', main, 'HEAD'], cwd=work, check=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = {n: sha(work / n) for n in git('ls-files', 'crates', 'desktop', 'Cargo.toml', 'Cargo.lock').splitlines() if (work / n).is_file() and n.endswith(('.rs', '.wgsl', 'Cargo.toml', 'Cargo.lock'))}
metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--no-deps', '--format-version', '1', '--locked', '--offline'], cwd=work))
(out / 'cargo-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
env = os.environ.copy()
env.pop('MOTION_LOG', None)
for key in list(env):
    if key.startswith('MOTION_'):
        env.pop(key, None)
env['LOCALAPPDATA'] = str(out / 'appdata')
common = ['--locked', '--offline']
render = ['cargo', 'test', '-p', 'motion-render', '--no-fail-fast', *common]
for target in ['tracking_lens', 'video_yuv', 'video_lifetime', 'video_instances', 'video_allocation_budget', 'model_layers', 'layer_time_nested']:
    render += ['--test', target]
render += ['--', '--test-threads=1']
commands = [
    ('check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg', *common]),
    ('render', render),
    ('host', ['cargo', 'test', '-p', 'motion-host', '--lib', *common, '--', '--test-threads=1']),
    ('desktop-ui', ['cargo', 'test', '-p', 'motion-desktop', '-p', 'motion-ui', '--features', 'motion-desktop/ffmpeg', '--no-fail-fast', *common, '--config', 'profile.test.package.motion-desktop.codegen-units=4', '--config', 'profile.test.package.motion-ui.codegen-units=4', '--', '--test-threads=1'])
]
commands = commands[-1:]
r = dict(status='running', head=git('rev-parse', 'HEAD'), main=main, source=sources, steps=[], startedUtc=datetime.now(timezone.utc).isoformat(), limits=[
    'Actual latest main351d09b2 includes own lens-video586 and node geometry604; no review or takeover of other PRs',
    'Complete selected desktop/UI plus selected render targets and host unit target; not whole workspace or Android',
    'Desktop and UI test-only codegen-units4 overrides; earlier UI compiler exit1 also unresolved; original default compiler fault and old native failures remain separate unresolved records',
    'All assertions, budgets and original ignores retained, one own GPU workload, default adapter and Info, caches/temp on E'])
def save():
    pending = out / 'exit.pending.json'
    pending.write_text(json.dumps(r, indent=2) + '\n', encoding='utf-8')
    os.replace(pending, out / 'exit.json')
save()
began = time.monotonic()
try:
    for name, command in commands:
        step = dict(name=name, command=command, startedUtc=datetime.now(timezone.utc).isoformat())
        r['steps'].append(step)
        save()
        with (out / f'{name}.stdout.log').open('wb') as stdout, (out / f'{name}.stderr.log').open('wb') as stderr:
            p = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
            step['pid'] = p.pid
            save()
            step['exitCode'] = p.wait()
        step['completedUtc'] = datetime.now(timezone.utc).isoformat()
        step['summaries'] = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', (out / f'{name}.stdout.log').read_text(encoding='utf-8', errors='replace'), re.M)
        step['invocations'] = re.findall(r'^\s*(?:Running|Doc-tests) .+$', (out / f'{name}.stderr.log').read_text(encoding='utf-8', errors='replace'), re.M)
        r['sourceUnchanged'] = all(sha(work / n) == h for n, h in sources.items())
        save()
        assert step['exitCode'] == 0 and r['sourceUnchanged'], name
        if name != 'check':
            assert step['summaries'] and all(s[0] == 'ok' and s[2] == s[5] == '0' for s in step['summaries']), name
            assert len(step['summaries']) == len(step['invocations']), name
        if name == 'desktop-ui':
            expected = []
            for package in metadata['packages']:
                if package['name'] not in ['motion-desktop', 'motion-ui']:
                    continue
                for target in package['targets']:
                    if target['test']:
                        expected.append((target['name'], target['kind'][0]))
                if any(t['doctest'] for t in package['targets']):
                    expected.append((package['name'].replace('-', '_'), 'doc'))
            assert len(expected) == len(step['invocations'])
            for target, kind in expected:
                assert any((f'Doc-tests {target}' if kind == 'doc' else f'{target.replace("-", "_")}-') in line for line in step['invocations'])
            step['expectedTargets'] = expected
            save()
    r['status'] = 'aligned_main_complete_desktop_ui_passed_with_documented_codegen_overrides'
except BaseException as cause:
    r.update(status='failed_original_outputs_retained', failure=repr(cause))
    raise
finally:
    r.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - began, 3))
    save()
print(json.dumps({k: v for k, v in r.items() if k not in ['source', 'steps']}, indent=2), flush=True)
