from pathlib import Path
from datetime import datetime, timezone
import ctypes, hashlib, json, os, re, subprocess, time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
prior = root / 'artifacts/pr-queue/clock85-aligned-runtime-v1'
out = root / 'artifacts/pr-queue/clock85-ui-compiler-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = json.loads((prior / 'exit.json').read_text())
assert report['status'] == 'failed_original_outputs_retained'
assert report['steps'][-1]['exitCode'] == 101 and report['sourceUnchanged']
raw = (prior / 'desktop-ui.stderr.log').read_text()
original = re.search(r"process didn't exit successfully: `(.*?)` \(exit code: 1\)", raw).group(1)
shell = ctypes.WinDLL('shell32', use_last_error=True)
shell.CommandLineToArgvW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
shell.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.LocalFree.argtypes = [ctypes.c_void_p]
kernel.LocalFree.restype = ctypes.c_void_p
count = ctypes.c_int()
pointer = shell.CommandLineToArgvW(original, ctypes.byref(count))
assert pointer
try:
    args = [pointer[i] for i in range(count.value)]
finally:
    kernel.LocalFree(pointer)
assert args[args.index('--crate-name') + 1] == 'path_antialiasing' and '--test' in args
assert args[args.index('--out-dir') + 1].replace('\\', '/').endswith('target/rational-rate85-contract/debug/deps')
assert '--cfg' in args and 'feature="gpu-tests"' in args
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(work / n) == h for n, h in report['source'].items())
inputs = {n: sha(Path(n)) for n in [a.split('=', 1)[1] for i, a in enumerate(args) if i > 0 and args[i-1] == '--extern']}
(out / 'input-dependencies.json').write_text(json.dumps(inputs, indent=2) + '\n', encoding='utf-8')
version = subprocess.check_output([args[0], '-vV'])
(out / 'rustc-version.txt').write_bytes(version)
modified = args.copy()
modified[modified.index('--out-dir') + 1] = str(out)
modified += ['-C', 'codegen-units=4']
r = dict(status='running_isolated_codegen_diagnostic', startedUtc=datetime.now(timezone.utc).isoformat(), head=report['head'], originalCommand=original, command=modified, compilerSha256=sha(Path(args[0])), limits=['Compiler diagnostic only, separate output directory and test-only codegen-units4; original exit1 and full-gate failure preserved', 'No source/assertion/budget/ignore changes, no cache deletion or identical failed test rerun', 'A later successful diagnostic does not identify the original compiler exit1 cause or establish a complete regression pass'])
save = lambda: (out / 'receipt.json').write_text(json.dumps(r, indent=2) + '\n', encoding='utf-8')
save()
began = time.monotonic()
try:
    with (out / 'rustc.stdout.log').open('wb') as stdout, (out / 'rustc.stderr.log').open('wb') as stderr:
        p = subprocess.Popen(modified, cwd=work, env=os.environ.copy(), stdout=stdout, stderr=stderr)
        r['pid'] = p.pid
        save()
        r['exitCode'] = p.wait()
    r['sourceUnchanged'] = all(sha(work / n) == h for n, h in report['source'].items())
    r['dependencyInputsUnchanged'] = all(sha(Path(n)) == h for n, h in inputs.items())
    r['outputExecutables'] = [dict(path=p.name, bytes=p.stat().st_size, sha256=sha(p)) for p in out.glob('*.exe')]
    r['status'] = 'isolated_compile_passed_not_root_cause_or_test_acceptance' if r['exitCode'] == 0 else 'isolated_compile_failed_original_outputs_retained'
finally:
    r.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - began, 3))
    save()
print(json.dumps(r, indent=2), flush=True)
raise SystemExit(r['exitCode'])
