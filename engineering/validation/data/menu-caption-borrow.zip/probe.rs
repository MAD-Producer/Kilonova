use super::*;
use widgets::menu::{self,Entry,Metrics};
#[path="E:/Dev/aem/artifacts/menu-caption-borrow/allocator.rs"]
mod allocator;

#[test]
fn actual_menu_output_and_allocations() {
    let root=std::path::PathBuf::from(std::env::var_os("MOTION_MENU_PROBE").expect("explicit probe output"));
    std::fs::create_dir_all(&root).unwrap();
    let mut records=vec![];
    for chinese in [false,true] { for width in [80.,160.,220.,480.] {
        for ratio in [1.,1.5,2.] { for count in [1usize,8,24] {
            let mut atlas=TextAtlas::from_system_language(12.,chinese).unwrap();
            atlas.set_pixel_ratio(ratio);
            let entries=(0..count).map(|i| {
                let label=if chinese {format!("复制蒙版为矢量路径 e\u{301} 👩\u{200d}💻 {i}")} else {format!("Copy mask as vector path e\u{301} 👩\u{200d}💻 {i}")};
                let mut entry=Entry::new(label,i,i%3!=1);
                entry.hint=if i%2==0 {"Ctrl+Shift+Y".into()} else {String::new()};
                entry.checked=i%4==0;entry.submenu=i%4==2;entry.divider_after=i%5==0;entry
            }).collect::<Vec<_>>();
            let mut requests=0;let mut bytes=0;let mut snapshot=String::new();
            for step in 0..11 {
                let mut paint=PaintList::default();let metrics=Metrics::context(&paint.styles());
                let card=Rect::new(0.,0.,width,600.);let mut highlighted=0;let mut scroll=0;
                let mut response=None;
                let (a,b)=allocator::measure(|| {response=Some(menu::draw(&mut paint,&mut atlas,card,metrics,&entries,&Input::default(),true,false,&mut highlighted,&mut scroll));});
                let r=response.unwrap();
                assert!(r.chosen.is_none() && r.hovered.is_none());
                if step>=3 {requests+=a;bytes+=b;}
                if step==3 {snapshot=format!("{:?}\n{:?}\n{:?}\n{:?}\n{:?}\n{highlighted} {scroll}",paint.shapes,paint.glyphs,paint.colors,paint.images,paint.order);}
            }
            let name=format!("zh{chinese}-w{width}-r{ratio}-n{count}");
            std::fs::write(root.join(format!("{name}.txt")),snapshot).unwrap();
            records.push(serde_json::json!({"name":name,"chinese":chinese,"width":width,"ratio":ratio,"rows":count,"frames":8,"allocation_requests":requests,"requested_bytes":bytes}));
        } }
    } }
    std::fs::write(root.join("records.json"),serde_json::to_vec_pretty(&records).unwrap()).unwrap();
}
