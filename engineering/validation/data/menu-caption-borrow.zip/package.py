import pathlib,json,hashlib,zipfile,subprocess
r=pathlib.Path('E:/Dev/aem/artifacts/menu-caption-borrow')
repo=pathlib.Path('E:/Dev/aem/.worktrees/menu-caption-borrow')
sha=lambda b:hashlib.sha256(b).hexdigest()
a=json.loads((r/'before/records.json').read_text(encoding='utf-8'));b=json.loads((r/'after/records.json').read_text(encoding='utf-8'))
assert len(a)==len(b)==72
objects={};manifest=[]
for stage,rows in [('before',a),('after',b)]:
 for row in rows:
  data=(r/stage/(row['name']+'.txt')).read_bytes();digest=sha(data);objects[digest]=data
  manifest.append({'stage':stage,'name':row['name'],'sha256':digest,'bytes':len(data)})
for old,new in zip(a,b):
 assert old['name']==new['name']
 assert (r/'before'/(old['name']+'.txt')).read_bytes()==(r/'after'/(new['name']+'.txt')).read_bytes()
 assert new['allocation_requests']<old['allocation_requests'] and new['requested_bytes']<old['requested_bytes']
results={'baseline':'2a2f67f7600b056543eba3cd16e8888240990b7e','scenarios':72,'measured_frames_per_scenario':8,'warmup_frames_per_scenario':3,'identical_snapshots':72,'before':a,'after':b,'ui_no_gpu':{'passed':169,'failed':0,'ignored':27},'gpu_text_bounds':{'passed':9,'failed':0,'ignored':0},'executables':{}}
for stage in ['before','after']:
 p=r/(stage+'-runtime/acceptance.exe');results['executables'][stage]=sha(p.read_bytes())
(r/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
out=repo/'engineering/validation/data/menu-caption-borrow.zip'
out.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in r.glob('*.log'):z.write(p,'logs/'+p.name)
 for f in ['probe.rs','allocator.rs','package.py','results.json']:z.write(r/f,f)
 z.writestr('snapshot-manifest.json',json.dumps(manifest,indent=2))
 for digest,data in objects.items():z.writestr('objects/'+digest+'.txt',data)
 for name in ['desktop/ui/src/widgets/menu.rs','desktop/ui/src/ui.rs','desktop/ui/src/text.rs','desktop/ui/src/style.rs','desktop/ui/styles/dark.json']:
  z.write(repo/name,'final-source/'+name)
  z.writestr('baseline/'+name,subprocess.check_output(['git','show','HEAD:'+name],cwd=repo))
print(json.dumps({'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'objects':len(objects)}))
