"""Single serial validator; raw failures and source identity are retained."""
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess
from pathlib import Path
ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-import-v1'
def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git',*args],cwd=WORK).decode().strip()
def sources():
    return {p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in git('ls-files','--cached','--others','--exclude-standard','-z').split('\0') if p and p.endswith(('.rs','.toml','.lock','.wgsl','.json','.py','.yml','.yaml'))}
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='running',controllerPid=os.getpid(),startedUtc=now(),head=git('rev-parse','HEAD'),main=git('rev-parse','origin/main'),source=sources(),steps=[])
def save():
    p=OUT/'exit.next.json';p.write_text(json.dumps(report,indent=2),encoding='utf-8');os.replace(p,OUT/'exit.json')
env=os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',PYTHONPATH=str(ROOT/'.tools/build-validation-python'),TEMP=str(ROOT/'target/ci-policy-validation-tmp'),TMP=str(ROOT/'target/ci-policy-validation-tmp'))
def step(name,args,count=None):
    row=dict(name=name,command=args,startedUtc=now());report['steps'].append(row);save()
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();row['exitCode']=child.wait()
    row['completedUtc']=now();save()
    assert row['exitCode']==0,f'{name}: retained failure, no unchanged retry'
    output=(OUT/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace')
    row['counts']=[tuple(map(int,x)) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',output)]
    save()
    if count is not None: assert row['counts']==[(count,0,0)],f'{name}: exact expected coverage required'
    assert report['head']==git('rev-parse','HEAD') and report['source']==sources(),'source changed during owned validation'
    row['passed']=True;save()
save()
try:
    root=WORK/'crates/motion-host/src/lib.rs';before=root.read_bytes();os.utime(root,None);assert root.read_bytes()==before
    step('desktop-check',['cargo','check','-p','motion-desktop','--locked','--offline'])
    step('tracking90',['cargo','test','-p','motion-host','--lib','tracking::','--locked','--offline','--','--test-threads=1'],90)
    step('mcp-tracking',['cargo','test','-p','motion-desktop','mcp::tracking_tests::','--locked','--offline','--','--test-threads=1'],2)
    step('host203',['cargo','test','-p','motion-host','--lib','--locked','--offline','--','--test-threads=1'],203)
    step('whitespace',['git','diff','--check'])
    report['status']='accepted_import_increment_not_full_issue'
except BaseException as error:
    report.update(status='failed',failure=repr(error));raise
finally:
    report['completedUtc']=now();save()
