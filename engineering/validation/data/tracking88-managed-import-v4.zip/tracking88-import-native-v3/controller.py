"""Serialized native MCP acceptance after the exact source unit gate finishes."""
from datetime import datetime,timezone
import hashlib,json,os,re,struct,subprocess,zlib
from pathlib import Path
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
UNIT=ROOT/'artifacts/pr-queue/tracking88-import-v3'
OUT=ROOT/'artifacts/pr-queue/tracking88-import-native-v3'
def now():return datetime.now(timezone.utc).isoformat()
unit=json.loads((UNIT/'exit.json').read_text())
assert unit.get('completedUtc') and unit['status']=='failed'
assert unit['failure']=="AssertionError('mcp-tracking: exact expected coverage required')"
assert [s['name'] for s in unit['steps']]==['desktop-check','tracking90','mcp-tracking']
assert all(s['exitCode']==0 and s.get('completedUtc') for s in unit['steps'])
assert unit['steps'][1]['counts']==[[90,0,0]]
assert unit['steps'][2]['counts']==[[3,0,0]]+[[0,0,0]]*5
def identity():
    for name,digest in unit['source'].items():
        assert hashlib.sha256((WORK/name).read_bytes()).hexdigest()==digest,name
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='running',controllerPid=os.getpid(),startedUtc=now(),unitEvidence=str(UNIT),
    unitControllerDisposition='Prior controller rejected five additional zero-selected integration targets after the actual 3/0/0 MCP unit result. All three child commands exited 0; original failed controller and exact counts are retained. No product assertion or output was changed. Broaden MCP coverage to its six existing unit tests using the explicit binary target.',steps=[])
def save():
    p=OUT/'exit.next.json';p.write_text(json.dumps(report,indent=2),encoding='utf-8');os.replace(p,OUT/'exit.json')
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',PYTHONPATH=str(ROOT/'.tools/build-validation-python'),TEMP=str(ROOT/'target/ci-policy-validation-tmp'),TMP=str(ROOT/'target/ci-policy-validation-tmp'),LOCALAPPDATA=str(OUT/'local-appdata'))
def step(name,args,count=None):
    identity();row=dict(name=name,command=args,startedUtc=now());report['steps'].append(row);save();print(json.dumps(dict(start=name)),flush=True)
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        p=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait()
    row['completedUtc']=now();save();assert row['exitCode']==0,name
    if count is not None:
        counts=[tuple(map(int,x)) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (OUT/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace'))]
        row['counts']=counts;save();assert counts==[(count,0,0)],name
    identity();row['passed']=True;save()
EXE=ROOT/'target/gltf-animation87-contract/debug/motion-studio.exe'
project_root=OUT/'project'
class Rpc:
    def __init__(self,name,read_only=False):
        identity();self.name=name;self.inputs=[];self.outputs=[];self.next_id=0
        args=[str(EXE),'--mcp','--project',str(project_root)]
        if read_only:args+=['--mcp-read-only']
        self.row=dict(name=name,command=args,startedUtc=now());report['steps'].append(self.row);save()
        self.stderr=(OUT/f'{name}.stderr.log').open('wb')
        self.p=subprocess.Popen(args,cwd=WORK,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr,text=True,encoding='utf-8')
        self.row['pid']=self.p.pid;save()
        self.request('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='owned-tracking-native-proof',version='1')))
        self.send(dict(jsonrpc='2.0',method='notifications/initialized'))
    def send(self,message):
        self.inputs.append(message);self.p.stdin.write(json.dumps(message)+'\n');self.p.stdin.flush()
    def request(self,method,params):
        self.next_id+=1;self.send(dict(jsonrpc='2.0',id=self.next_id,method=method,params=params))
        line=self.p.stdout.readline();assert line,f'{self.name}: native stdout closed'
        reply=json.loads(line);self.outputs.append(reply)
        assert reply['jsonrpc']=='2.0' and reply['id']==self.next_id
        assert 'error' not in reply,reply
        return reply['result']
    def call(self,name,args):return self.request('tools/call',dict(name=name,arguments=args))
    def state(self):
        result=self.call('motion_state',{});assert not result['isError'];return result['structuredContent']
    def close(self):
        self.p.stdin.close();trailing=self.p.stdout.read();assert not trailing,repr(trailing)
        self.row['exitCode']=self.p.wait();self.stderr.close();self.row['completedUtc']=now()
        (OUT/f'{self.name}.stdin.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in self.inputs),encoding='utf-8')
        (OUT/f'{self.name}.stdout.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in self.outputs),encoding='utf-8')
        save();assert self.row['exitCode']==0,self.name
        self.row['passed']=True;save()
save()
try:
    step('host203',['cargo','test','-p','motion-host','--lib','--locked','--offline','--','--test-threads=1'],203)
    step('all-mcp9',['cargo','test','-p','motion-desktop','--bin','motion-studio','mcp::','--locked','--offline','--','--test-threads=1'],9)
    step('native-build',['cargo','build','-p','motion-desktop','--bin','motion-studio','--locked','--offline'])
    report['exeSha256']=hashlib.sha256(EXE.read_bytes()).hexdigest();save()
    bootstrap=Rpc('bootstrap');project=bootstrap.state()['project'];bootstrap.close()
    assets=project_root/'assets';assets.mkdir(exist_ok=True)
    def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
    pixels=b''.join(b'\0'+b''.join(bytes([x*29,y*37,83,255]) for x in range(8)) for y in range(6))
    png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',8,6,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(pixels))+chunk(b'IEND',b'')
    (assets/'original.png').write_bytes(png)
    project['assets']=[dict(id=1,path='assets/original.png',width=8,height=6)]
    (project_root/'project.json').write_text(json.dumps(project),encoding='utf-8')
    solve=dict(version=1,source_id='independently generated native source',source_sha256=hashlib.sha256(png).hexdigest(),source_extent=[8,6],coordinates='right_down_forward',ticks_per_second=90000,nominal_rate=[30000,1001],source_pts=[-3003],meters_per_world_unit=None,tracks=[dict(id='manual native point',kind='point',reference_index=None,samples=[dict(source_index=0,visibility='visible',confidence=0.8123456789012345,manual_correction=True,observation=dict(kind='point',pixels=[2.5,3.125]))])])
    original=b' \n\t'+json.dumps(solve,indent=2).encode()+b'\r\n '
    external=OUT/'external-original.json';external.write_bytes(original)
    live=Rpc('native-import');before=live.state()
    args=dict(path=str(external),source=dict(kind='image',id=1),expectedRevision=before['revision'],expectedDocumentGeneration=before['document_generation'])
    missing=dict(args,path=str(OUT/'missing-original.json'))
    failed=live.call('import_tracking',missing);assert failed['isError'] and 'open_document' in failed['content'][0]['text']
    result=live.call('import_tracking',args);assert not result['isError'],result
    imported=result['structuredContent'];flags=imported['trackingImport']
    assert flags['originalPreserved'] and flags['encodedSourceVerified'] and not flags['decodedTimelineVerified'] and not flags['poseApplied']
    descriptor=imported['project']['tracking_assets'][0];managed=project_root/descriptor['path'];assert managed.read_bytes()==original
    assert json.loads((project_root/'project.json').read_text())['tracking_assets']==[descriptor]
    assert live.call('import_tracking',args)['isError']
    undo=live.call('motion_history',dict(operation='undo'));assert not undo['isError'] and undo['structuredContent']['project']==before['project']
    assert not undo['structuredContent']['canUndo'] and managed.read_bytes()==original
    external.unlink()
    redo=live.call('motion_history',dict(operation='redo'));assert not redo['isError'] and redo['structuredContent']['project']==imported['project']
    assert not live.call('motion_save',{})['isError'];live.close()
    log=(OUT/'local-appdata/MotionStudio/logs/motion-studio.log').read_bytes();(OUT/'native-import.file.log').write_bytes(log)
    stderr=(OUT/'native-import.stderr.log').read_text(encoding='utf-8',errors='replace')
    for sink in [log.decode('utf-8'),stderr]:
        assert 'tracking import failed request=' in sink and 'phase=open_document' in sink and 'source=Image:1' in sink and 'elapsed_ms=' in sink
    assert ' INFO ' in log.decode() and re.search(r'start #\d+ import_tracking',log.decode())
    readonly=Rpc('reopen-readonly',True);reopened=readonly.state()
    assert reopened['project']==imported['project'] and managed.read_bytes()==original
    denied=readonly.call('import_tracking',dict(args,expectedRevision=reopened['revision'],expectedDocumentGeneration=reopened['document_generation']))
    assert denied['isError'] and 'disabled' in denied['content'][0]['text'];readonly.close()
    identity();report.update(status='accepted_native_import_increment_not_full_issue',sourceSha256=solve['source_sha256'],originalSha256=hashlib.sha256(original).hexdigest(),managedPath=descriptor['path'],scope='Canonical original attachment only; no camera/plane/point pose application, decoded video PTS proof, solver or Android acceptance')
except BaseException as error:
    report.update(status='failed',failure=repr(error));raise
finally:
    report['completedUtc']=now();save()
