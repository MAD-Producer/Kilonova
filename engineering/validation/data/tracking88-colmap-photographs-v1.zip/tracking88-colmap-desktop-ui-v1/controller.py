"""Complete desktop/UI regression on the photographed-lens source closure."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, time, traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-colmap88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-colmap-desktop-ui-v1'
proof = json.loads((ROOT / 'artifacts/pr-queue/tracking88-colmap-lens-regression-v2/exit.json').read_text(encoding='utf-8'))
assert proof['status'] == 'model_core_selected_native_render_host_lib_and_normal_dev_build_passed'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def identity():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == proof['baseCommit']
    for name, digest in proof['source'].items():
        assert sha(WORK / name) == digest, name
identity()
env = os.environ.copy()
for key in list(env):
    if key.startswith('MOTION_'):
        env.pop(key, None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
    CARGO_TARGET_DIR=str(ROOT / 'target/rational-rate85-contract'), CARGO_INCREMENTAL='0',
    CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full', PYTHONUTF8='1', LOCALAPPDATA=str(OUT / 'appdata'),
    TEMP=str(ROOT / 'target/ci-policy-validation-tmp'), TMP=str(ROOT / 'target/ci-policy-validation-tmp'))
metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--no-deps', '--format-version', '1', '--locked', '--offline'], cwd=WORK, env=env))
(OUT / 'cargo-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
command = ['cargo', 'test', '-p', 'motion-desktop', '-p', 'motion-ui', '--features', 'motion-desktop/ffmpeg',
    '--no-fail-fast', '--locked', '--offline', '--config', 'profile.test.package.motion-desktop.codegen-units=4',
    '--config', 'profile.test.package.motion-ui.codegen-units=4', '--', '--test-threads=1']
report = dict(status='running', controllerPid=os.getpid(), baseCommit=proof['baseCommit'],
    source=proof['source'], startedUtc=datetime.now(timezone.utc).isoformat(), command=command,
    limits=['Complete desktop/UI targets, not complete workspace or Android',
        'Same previously documented desktop/UI test-only codegen-units4; no assertion, time budget, ignore, stack, adapter or production-profile changes',
        'One own GPU workload, default Info and adapter, all controlled cache/temp on E',
        'Earlier compiler/native failures remain retained and unresolved; this run does not establish their root cause'])
def save():
    temp = OUT / 'exit.pending.json'
    temp.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    os.replace(temp, OUT / 'exit.json')
began = time.monotonic()
save()
try:
    with (OUT / 'desktop-ui.stdout.log').open('wb') as stdout, (OUT / 'desktop-ui.stderr.log').open('wb') as stderr:
        p = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = p.pid
        save()
        report['exitCode'] = p.wait()
    report['summaries'] = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', (OUT / 'desktop-ui.stdout.log').read_text(encoding='utf-8', errors='replace'), re.M)
    report['invocations'] = re.findall(r'^\s*(?:Running|Doc-tests) .+$', (OUT / 'desktop-ui.stderr.log').read_text(encoding='utf-8', errors='replace'), re.M)
    identity()
    report['sourceUnchanged'] = True
    save()
    assert report['exitCode'] == 0
    assert report['summaries'] and all(s[0] == 'ok' and s[2] == s[5] == '0' for s in report['summaries'])
    assert len(report['summaries']) == len(report['invocations'])
    expected = []
    for package in metadata['packages']:
        if package['name'] not in ('motion-desktop', 'motion-ui'):
            continue
        for target in package['targets']:
            if target['test']:
                expected.append((target['name'], target['kind'][0]))
        if any(t['doctest'] for t in package['targets']):
            expected.append((package['name'].replace('-', '_'), 'doc'))
    report['expectedTargets'] = expected
    assert len(expected) == len(report['invocations'])
    for target, kind in expected:
        assert any((f'Doc-tests {target}' if kind == 'doc' else f'{target.replace("-", "_")}-') in line for line in report['invocations']), target
    report['totals'] = dict(passed=sum(int(s[1]) for s in report['summaries']), failed=0,
        originalIgnored=sum(int(s[3]) for s in report['summaries']), filtered=0, targets=len(expected))
    report['status'] = 'complete_desktop_ui_passed_with_documented_codegen_overrides'
except BaseException as cause:
    report.update(status='failed_original_outputs_retained', failure=repr(cause), traceback=traceback.format_exc())
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic()-began, 3))
    save()
print(json.dumps({k: report[k] for k in ('status', 'totals', 'elapsedSeconds')}), flush=True)
