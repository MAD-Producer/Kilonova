from pathlib import Path
import subprocess,json,hashlib,os,time,datetime
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-colmap88';out=root/'artifacts/pr-queue/tracking88-toolbar-native-diagnostic-v1';out.mkdir(exist_ok=False)
proof=json.loads((root/'artifacts/pr-queue/tracking88-colmap-desktop-ui-v2/exit.json').read_text(encoding='utf-8'))
assert proof['status']=='failed_original_outputs_retained' and proof['exitCode']==101 and proof['sourceUnchanged']
for name,digest in proof['source'].items():assert hashlib.sha256((work/name).read_bytes()).hexdigest()==digest,name
binary=root/'target/rational-rate85-contract/debug/deps/motion_studio-bf2b19e5f63dee2d.exe'
name='panels::toolbar_style::tests::native::native_toolbar_controls_capture_real_preview_and_cancel_at_float_boundary'
command=[str(binary),'--exact',name,'--nocapture','--test-threads=1']
env=os.environ.copy()
for key in list(env):
 if key.startswith('MOTION_'):env.pop(key,None)
env.update(MOTION_TOOLBAR_NATIVE_CHILD=str(out/'native'),LOCALAPPDATA=str(out/'appdata'),TEMP=str(root/'target/ci-policy-validation-tmp'),TMP=str(root/'target/ci-policy-validation-tmp'),RUST_BACKTRACE='full')
(out/'native').mkdir();start=time.monotonic()
report=dict(status='running',command=command,source=proof['source'],baseCommit=proof['baseCommit'],binarySha256=hashlib.sha256(binary.read_bytes()).hexdigest(),startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),limits=['Single direct child diagnostic, not a rerun or pass of complete desktop/UI','Original test body and assertions, default Info/backend/stack/time budgets unchanged'])
(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 p=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);report['pid']=p.pid;code=p.wait()
for n,d in proof['source'].items():assert hashlib.sha256((work/n).read_bytes()).hexdigest()==d,n
report.update(status='direct_original_native_child_completed',exitCode=code,windowsExitHex=hex(code&0xffffffff),elapsedSeconds=round(time.monotonic()-start,3),sourceUnchanged=True)
(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k not in ('source',)}))
