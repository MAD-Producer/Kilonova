"""Archive native photographic evidence, including failed attempts, without binaries."""
from pathlib import Path
import hashlib, json, re, subprocess, zipfile

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-colmap88'
BASE = ROOT / 'artifacts/pr-queue'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda name: json.loads((BASE / name / 'exit.json').read_text(encoding='utf-8'))
gate = load('tracking88-colmap-lens-regression-v2')
native = load('tracking88-colmap-photographs-native-v4')
desktop = load('tracking88-colmap-desktop-ui-v2')
assert gate['status'] == 'model_core_selected_native_render_host_lib_and_normal_dev_build_passed'
assert native['status'] == 'photographed_colmap_syntax_native_import_binding_pixels_and_reopen_passed'
assert desktop['status'] == 'failed_original_outputs_retained' and desktop['exitCode'] == 101
assert desktop['sourceUnchanged']
assert len(desktop['summaries']) == len(desktop['invocations']) == 31
assert sum(int(v[2]) for v in desktop['summaries']) == 1
assert all(v[5] == '0' for v in desktop['summaries'])
failed = [v for v in desktop['summaries'] if v[0] == 'FAILED']
assert len(failed) == 1 and failed[0][1:4] == ['1746', '1', '72']
desktop['totals'] = dict(passed=sum(int(v[1]) for v in desktop['summaries']), failed=1,
    originalIgnored=sum(int(v[3]) for v in desktop['summaries']), filtered=0, targets=31)
diagnostic=load('tracking88-toolbar-native-diagnostic-v1')
assert diagnostic['exitCode'] == 0 and diagnostic['sourceUnchanged']
assert diagnostic['source'] == desktop['source'] and diagnostic['baseCommit'] == desktop['baseCommit']
assert gate['source'] == native['source'] == desktop['source']
assert gate['baseCommit'] == native['baseCommit'] == desktop['baseCommit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == gate['baseCommit']
for name, digest in gate['source'].items():
    assert sha(WORK / name) == digest, name
assert gate['binarySha256'] == native['binarySha256']
assert len(native['views']) == 3 and len(native['processes']) == 7
assert all(p['exitCode'] == 0 for p in native['processes'])
assert all(s['exitCode'] == 0 for s in gate['steps'])

totals = {}
for step in gate['steps']:
    if step['label'] in ('desktop-check', 'normal-dev-build'):
        continue
    directory = BASE / 'tracking88-colmap-lens-regression-v2'
    summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', (directory / (step['label'] + '.stdout.log')).read_text(encoding='utf-8', errors='replace'), re.M)
    invocations = re.findall(r'^\s*(?:Running|Doc-tests) .+$', (directory / (step['label'] + '.stderr.log')).read_text(encoding='utf-8', errors='replace'), re.M)
    assert summaries and len(summaries) == len(invocations), step['label']
    assert all(s[0] == 'ok' and s[2] == s[5] == '0' for s in summaries)
    totals[step['label']] = dict(passed=sum(int(s[1]) for s in summaries), failed=0,
        originalIgnored=sum(int(s[3]) for s in summaries), filtered=0, targets=len(summaries))
totals['desktop-ui'] = desktop['totals']
rows = json.loads((BASE / 'tracking88-colmap-lens-regression-v2/lens-artifacts/strong-lens-precision.json').read_text(encoding='utf-8'))
assert len(rows) == 16
assert len({(r['rotation'], r['precision']) for r in rows}) == 16
assert all(r['inverseStep'] > 1 and r['contractionBound'] < .45 for r in rows)

entries = {}
for label in ('tracking88-colmap-lens-regression-v1', 'tracking88-colmap-lens-regression-v2',
        'tracking88-colmap-photographs-calibration-v1', 'tracking88-colmap-photographs-native-v1',
        'tracking88-colmap-photographs-native-v2', 'tracking88-colmap-photographs-native-v3',
        'tracking88-colmap-photographs-native-v4',
        'tracking88-colmap-desktop-ui-v1', 'tracking88-colmap-desktop-ui-v2',
        'tracking88-toolbar-native-diagnostic-v1'):
    directory = BASE / label
    for path in sorted(directory.rglob('*')):
        if not path.is_file() or 'appdata' in path.relative_to(directory).parts:
            continue
        assert path.suffix.lower() not in ('.exe', '.dll', '.pdb', '.obj', '.lib'), path
        entries[f'{label}/{path.relative_to(directory).as_posix()}'] = path
photos = BASE / 'tracking88-photographs-probe-v3'
for name in [f'left{i:02}.jpg' for i in (*range(1, 10), *range(11, 15))] + ['LICENSE', 'COPYRIGHT', 'report.json']:
    assert (photos / name).is_file(), name
    entries[f'upstream-photographs/{name}'] = photos / name
entries['historical-calibration-source/calibration.json'] = BASE / 'tracking88-photographs-calibration-v3/calibration.json'
changed = ['crates/motion-model/src/tracking/lens.rs', 'crates/motion-model/src/tracking/lens/certificate.rs',
    'crates/motion-render/src/lens_output.rs', 'crates/motion-render/src/lens_output.wgsl',
    'crates/motion-render/tests/tracking_lens.rs', 'crates/motion-model/tests/fixtures/tracking-opencv-inverse.json',
    'crates/motion-model/tests/tracking_lens_relaxation.rs', 'crates/motion-render/tests/tracking_lens/relaxation.rs']
for name in changed + ['ATTRIBUTION.md', 'PROVENANCE.md', 'NOTICE']:
    entries['accepted-source/' + name] = WORK / name
for name in ('prepare-colmap88-inverse-oracle-v1.py', 'calibrate-colmap88-photographs-v1.py',
        'run-colmap88-lens-v2.ps1', 'run-colmap88-desktop-ui-v1.ps1', 'run-colmap88-desktop-ui-v2.ps1',
        'prepare-colmap88-photographs-native-v4.py', 'run-colmap88-photographs-followup-v2.ps1',
        'diagnose-colmap88-toolbar-native-v1.py'):
    entries['environment/' + name] = ROOT / '.tools/issue-closure-review' / name
entries['environment/publish.py'] = Path(__file__)
assert sum(p.stat().st_size for p in entries.values()) < 100 * 1024 * 1024
audit = dict(status='photographed_native_lens_passed_complete_desktop_ui_has_one_native_child_failure',
    baseCommit=gate['baseCommit'], binarySha256=gate['binarySha256'], totals=totals,
    views=native['views'], precisionRotations=rows,
    limits=native['limits'] + desktop['limits'] + [
        'Focused lens six tests also occur in the complete model package; do not double-count',
        'Ten selected render targets and complete host lib, not complete render/workspace runtime',
        'Original null-fixture error, real inverse-certificate rejection, first conservative-certificate failure and XYZ/XY observer failure retained',
        'The first desktop/UI observer disappeared during compilation without a terminal receipt or tests; its logs and additive interruption observation remain unchanged',
        'Complete desktop/UI has one native toolbar child failure; a same-source direct child passed separately without explaining the original exit',
        'Final exact-head cross-platform CI remains separate; neither issue88 nor the full 3D route is closed'])
manifest = dict(audit=audit, entries={name: dict(bytes=p.stat().st_size, sha256=sha(p)) for name, p in entries.items()})
data = WORK / 'engineering/validation/data'
assert data.is_dir(), 'Materialize the existing engineering sparse-checkout paths after all source-bound tests finish'
archive = data / 'tracking88-colmap-photographs-v1.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
    for name, p in entries.items():
        z.write(p, name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, p in entries.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == sha(p), name
receipt = dict(audit=audit, archive=archive.name, bytes=archive.stat().st_size,
    sha256=sha(archive), members=len(entries) + 1)
archive.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
doc = WORK / 'engineering/validation/tracking88-colmap-photographs-current.md'
doc.write_text(f'''# Issue 88: photographed external camera import and certified lens inversion

Three independently calibrated photographed board poses pass actual vendor import,
binding, native pixels, undo/redo, save and fresh read-only reopen. This is an
OpenCV-calibrated COLMAP text-format interchange test, not execution of a COLMAP
multi-view solver or continuous camera-motion acceptance. A board square defines
one source unit; the physical square size and surveyed metric scale are unknown.
Android remains excluded and issue 88 stays open.

## Calibration and functional fix

The same pinned thirteen Apache-2.0 OpenCV photographs are used: ten calibration
views and three held-out poses. The eight-parameter OPENCV profile is independently
re-estimated with k3 fixed to zero during fitting; an existing three-radial fit is
not truncated. For each held-out pose, 27 measured corners fit extrinsics and the
other 27 measure error. OpenCV centre-origin coordinates become COLMAP edge-origin
coordinates by adding 0.5 to principal points and observations. Original image
bytes, detected measurements, options, tool versions and licenses are retained.

The first native fixture supplied null where the current track schema requires
an absent optional key. Correcting that private fixture exposed a real product
failure: the previous unit-step fixed-point certificate rejected the unchanged
photographed lens. After the fix, the next observer incorrectly compared a
projected XYZ anchor to OpenCV XY; its correction selects XY by the same object
ID and additionally checks finite XYZ and normalized depth. All original
assertions, including the 0.0003-pixel threshold, remain. These original failed
observers and the actual product failure/default Error records are retained.

The functional fix certifies q <- q + step*(d-F(q)) on a complete enclosing disk,
using directed interval arithmetic for contraction and self-mapping. Cubic
Bernstein control hulls enclose radial intervals for relaxed steps. Step one
keeps the existing algorithm. CPU and shader share an exactly representable
binary-fraction step; overscan includes the corresponding inverse-Lipschitz
factor. The contraction limit remains 0.45, iteration count 48, enclosing radius
at most twice the distorted-domain radius, and final residual limit unchanged.
Folded or uncertified domains remain errors. An earlier conservative interval
attempt failed and is retained with exact source snapshots.

## Executed scope

| Gate | Passed | Failed | Original ignored | Filtered | Targets |
| --- | ---: | ---: | ---: | ---: | ---: |
''' + ''.join(f"| {name} | {t['passed']} | {t['failed']} | {t['originalIgnored']} | 0 | {t['targets']} |\n" for name, t in totals.items()) + '''
The focused six lens tests are included in complete model totals and must not
be added twice. Model controls check 63 independently generated OpenCV inverse
rays, four rotations, unaltered calibration, exact shared step, ordinary lenses
and folded-domain refusal. Actual nonconstant GPU output uses an independent
analytic-Jacobian Newton oracle and checks all sixteen precision/rotation pairs.
Float paths retain negative/HDR values and alpha. Their per-pair errors and
unchanged numerical thresholds are in the receipt.

The first desktop/UI attempt stopped during compilation without a terminal
receipt: on resumption its original tool handle, controller and Cargo process
were absent, stdout was empty and no tests had run. Its unchanged running
receipt and raw output are retained beside an additive observation; the cause
of interruption is unknown. The second attempt uses the same source and command
in a new output directory. It finished all 31 target invocations in 2700.765
seconds with 1976 passed, one failed, 72 original ignores and no filters. The
failure is the native toolbar screenshot parent's assertion that its child
exited successfully; the captured child output names no underlying cause.
A subsequent direct execution of that exact child and unchanged test body
passed in 16.25 seconds, preserving its logs and native captures. This does
not turn the failed full run into a pass or establish its cause. Complete
desktop/UI regression remains an unmet gate. Desktop/UI execution uses the previously
documented test-only codegen-units=4 overrides. No original assertion, time budget, ignore, stack,
adapter, production profile, panel, layout, style, interaction or dependency was
changed for acceptance. The executable uses the normal dev/FFmpeg build without
those test overrides. Earlier failures remain separately recorded; the passing native photographic
workflow and direct toolbar diagnostic do not establish their root causes.

## Actual native photographic comparison

| Held-out photo | RMS px | Maximum px | Stable pixels | Native/oracle max byte error |
| --- | ---: | ---: | ---: | ---: |
''' + ''.join(f"| {v['name']} | {v['heldOutRms']:.6f} | {v['heldOutMax']:.6f} | {v['checkedStablePixels']} | {v['maxByteError']} |\n" for v in native['views']) + f'''
Seven fresh processes execute the real stdio MCP protocol. Import preserves the
original text/map/options and authored camera, import and binding have separate
undo/redo checks, bad binding is atomic, and deleting the external original does
not affect managed bytes on fresh reopen. Independently projected anchors must
agree within 0.0003 pixel. Dense independent ray/plane pixels use the original
two-pixel edge exclusion and two-byte RGBA/alpha limits; black and white linear
composites are separately checked. This qualification covers native Unorm8
preview, not all-precision photographed final export.

At default Info the actual file contains non-Present starts. Original bad-track
causes occur in both file and stderr; every stdout line parses as JSON-RPC.
Executable SHA-256: `{native['binarySha256']}`.

The [archive](data/tracking88-colmap-photographs-v1.zip) and
[receipt](data/tracking88-colmap-photographs-v1.json) contain exact accepted and
failed sources, controllers, raw outputs, source closures, calibrated data,
unchanged photographed originals and licenses, actual projects, managed vendor
bytes, captures and comparison image. Every member was read back and hash-checked.
The frozen base is `{gate['baseCommit']}` plus the archived lens change; this is
not evidence for any later product change. Final exact-head cross-platform CI,
real continuous tracking quality, cache/reconnection completion and issue-level
closure remain separate requirements.
''', encoding='utf-8')
print(json.dumps(dict(totals=totals, bytes=receipt['bytes'], members=receipt['members'], sha256=receipt['sha256'])), flush=True)
