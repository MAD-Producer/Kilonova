$ErrorActionPreference='Stop'
. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:LIBCLANG_PATH='E:/Dev/aem/.tools/python-libclang/clang/native'
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:FFMPEG_INCLUDE_DIR=Join-Path $env:FFMPEG_DIR 'include'
$env:FFMPEG_LIB_DIR=Join-Path $env:FFMPEG_DIR 'lib'
$env:PATH=(Join-Path $env:FFMPEG_DIR 'bin')+';'+$env:PATH
$env:PYTHONUTF8='1'
& E:/Dev/aem/.tools/ai-depth74/venv/Scripts/python.exe E:/Dev/aem/.tools/issue-closure-review/validate-colmap88-desktop-ui-v1.py
exit $LASTEXITCODE
