from pathlib import Path
import hashlib,json
import cv2,numpy as np
root=Path('E:/Dev/aem');cal=root/'artifacts/pr-queue/tracking88-colmap-photographs-calibration-v1/calibration.json'
r=json.loads(cal.read_text(encoding='utf-8'));assert r['status']=='held_out_photographed_opencv_calibration_passed_native_import_pending'
K=np.array(r['K']);dist=np.array(r['distortion'])
points=np.array([[640*x/8,480*y/6] for y in range(7) for x in range(9)],np.float64)
q=cv2.undistortPoints(points.reshape(-1,1,2),K,dist,criteria=(cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER,100,1e-13)).reshape(-1,2)
ideal=q*np.diag(K)[:2]+K[:2,2]
fixture={'source':'Pinned OpenCV sample photographs; ATTRIBUTION.md external photographed camera calibration entry',
 'upstreamRevision':r['sourceManifest']['revision'],'calibrationSha256':hashlib.sha256(cal.read_bytes()).hexdigest(),
 'opencv':cv2.__version__,'numpy':np.__version__,'model':r['model'],'coordinateConvention':r['coordinates'],
 'extent':[640,480],'focal':[K[0,0],K[1,1]],'principal':[K[0,2],K[1,2]],'radial':[dist[0],dist[1],dist[4]],'tangential':[dist[2],dist[3]],
 'oracle':'OpenCV undistortPoints, 100 iterations, 1e-13 epsilon; independent of production inverse and certificate',
 'samples':[{'distorted':p.tolist(),'undistorted':u.tolist()} for p,u in zip(points,ideal)]}
p=root/'.worktrees/tracking-colmap88/crates/motion-model/tests/fixtures/tracking-opencv-inverse.json'
p.write_text(json.dumps(fixture,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'fixture':str(p),'samples':len(points),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
