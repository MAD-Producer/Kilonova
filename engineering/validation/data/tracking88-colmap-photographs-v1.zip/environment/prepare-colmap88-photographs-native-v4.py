"""Correct only the observer's XYZ/XY shape interpretation; keep pixel assertions."""
from pathlib import Path
import ast, hashlib, json
root=Path('E:/Dev/aem')
directory=root/'.tools/issue-closure-review'
old=directory/'validate-colmap88-photographs-native-v3.py'
new=directory/'validate-colmap88-photographs-native-v4.py'
assert not new.exists()
text=old.read_text(encoding='utf-8')
before='  max_anchor=max(float(np.linalg.norm(np.array(anchors[100+i])-q)) for i,q in enumerate(expected_anchors))'
after='  assert all(len(anchors[100+i])==3 and np.isfinite(anchors[100+i]).all() and 0.<=anchors[100+i][2]<=1. for i in range(40))\n  max_anchor=max(float(np.linalg.norm(np.array(anchors[100+i][:2])-q)) for i,q in enumerate(expected_anchors))'
assert text.count(before)==1
result=text.replace('tracking88-colmap-photographs-native-v3', 'tracking88-colmap-photographs-native-v4').replace(before,after)
assertions=lambda s:[ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(s)) if isinstance(n,ast.Assert)]
prior=assertions(text)
current=assertions(result)
assert len(current)==len(prior)+1 and all(a in current for a in prior)
new.write_text(result,encoding='utf-8',newline='\n')
diagnosis=dict(status='observer_shape_failure_not_product_rejection',
    originalControllerSha256=hashlib.sha256(old.read_bytes()).hexdigest(),
    replacementControllerSha256=hashlib.sha256(new.read_bytes()).hexdigest(),
    cause='projectedLayers anchor is [pixel_x,pixel_y,normalized_depth]; OpenCV projectPoints returns pixel XY only',
    change='Compare the same object ID pixel XY only, add XYZ shape/finite/0..1 depth checks',
    originalAssertionsRetained=len(prior), additionalAssertions=1,
    unchangedPixelThreshold=.0003,
    limits='Original native-v3 failed and is retained; saved first-view ID-matched pixel errors alone do not certify the complete new workflow')
(root/'artifacts/pr-queue/tracking88-colmap-photographs-native-v3/observer-shape-diagnosis.json').write_text(json.dumps(diagnosis,indent=2)+'\n',encoding='utf-8')
print(json.dumps(diagnosis))
