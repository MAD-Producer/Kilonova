"""Independent photographed OPENCV calibration, not a COLMAP reconstruction."""
from pathlib import Path
import datetime,hashlib,json,math,traceback
import cv2
import numpy as np

ROOT=Path('E:/Dev/aem');INPUT=ROOT/'artifacts/pr-queue/tracking88-photographs-probe-v3'
OLD=ROOT/'artifacts/pr-queue/tracking88-photographs-calibration-v3/calibration.json'
OUT=ROOT/'artifacts/pr-queue/tracking88-colmap-photographs-calibration-v1'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
old=json.loads(OLD.read_text(encoding='utf-8'));manifest=old['sourceManifest']
report={'status':'running','startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'sourceManifest':manifest,'sourceManifestHash':hashlib.sha256(OLD.read_bytes()).hexdigest(),
 'implementation':{'opencv':cv2.__version__,'numpy':np.__version__},
 'scope':'Separate photographed board poses, independently calibrated and exported in COLMAP text syntax; no COLMAP executable, multi-view reconstruction, continuous motion or measured physical scale',
 'model':'OPENCV with CALIB_FIX_K3, estimated anew from unchanged training photographs, never truncating the older three-radial fit',
 'coordinates':'OpenCV pixel-centre integer observations and principal point translated +0.5 to the COLMAP corner-origin pixel convention; extrinsics unchanged',
 'scaleConvention':old['scaleConvention'],'thresholds':old['limits'],'views':[]}
def save():(OUT/'calibration.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
try:
 cv2.setNumThreads(1)
 for f in manifest['files']:
  p=INPUT/f['name'];assert p.is_file() and len(p.read_bytes())==f['bytes']
  assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'],f['name']
 names=old['trainingViews']+old['heldOutViews'];corners={}
 obj=np.zeros((54,3),np.float32);obj[:,:2]=np.mgrid[0:9,0:6].T.reshape(-1,2)
 for name in names:
  image=cv2.imread(str(INPUT/name),cv2.IMREAD_GRAYSCALE);assert image.shape==(480,640)
  found,p=cv2.findChessboardCorners(image,(9,6));assert found,name
  corners[name]=cv2.cornerSubPix(image,p,(11,11),(-1,-1),(cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER,100,1e-5))
 train=old['trainingViews'];held=old['heldOutViews']
 rms,K,dist,_,_=cv2.calibrateCamera([obj]*len(train),[corners[n] for n in train],(640,480),None,None,flags=cv2.CALIB_FIX_K3)
 assert dist.shape==(1,5) or dist.shape==(5,1)
 assert float(dist.flatten()[4])==0.,dist
 Kedge=K.copy();Kedge[:2,2]+=.5
 report.update(trainingViews=train,heldOutViews=held,trainingRms=float(rms),KOpenCV=K.tolist(),K=Kedge.tolist(),distortion=dist.flatten().tolist(),objectPoints=obj.tolist(),measuredCorners={n:(p.reshape(-1,2).astype(float)+.5).tolist() for n,p in corners.items()})
 fit=np.array([(x+y)%2==0 for y in range(6) for x in range(9)])
 k1,k2,p1,p2,k3=dist.flatten()
 camera='# Independent OpenCV calibration of pinned real photographs; not a COLMAP solve\r\n'
 camera+='7 OPENCV 640 480 '+' '.join(format(float(v),'.17g') for v in [Kedge[0,0],Kedge[1,1],Kedge[0,2],Kedge[1,2],k1,k2,p1,p2])+'\r\n'
 (OUT/'cameras.txt').write_bytes(camera.encode('utf-8'))
 for i,name in enumerate(held):
  ok,rvec,tvec=cv2.solvePnP(obj[fit],corners[name][fit],K,dist,flags=cv2.SOLVEPNP_ITERATIVE);assert ok,name
  projected,_=cv2.projectPoints(obj,rvec,tvec,K,dist)
  errors=np.linalg.norm(projected.reshape(-1,2)-corners[name].reshape(-1,2),axis=1);e=errors[~fit]
  R=cv2.Rodrigues(rvec)[0]
  # Rodrigues axis-angle -> Hamilton quaternion; no production matrix helper.
  angle=float(np.linalg.norm(rvec));axis=rvec.flatten()/angle
  quat=[math.cos(angle/2),*(axis*math.sin(angle/2)).tolist()]
  row={'name':name,'worldToCameraRotation':R.tolist(),'worldToCameraTranslation':tvec.flatten().tolist(),
   'worldToCameraQuaternionWxyz':quat,'poseFitIndices':np.flatnonzero(fit).tolist(),
   'validationIndices':np.flatnonzero(~fit).tolist(),'heldOutRms':float(np.sqrt(np.mean(e*e))),
   'heldOutMax':float(e.max()),'heldOutP95':float(np.percentile(e,95)),
   'independentProjectedCorners':(projected.reshape(-1,2).astype(float)+.5).tolist()}
  report['views'].append(row);save()
  assert row['heldOutRms']<old['limits']['heldOutRmsPixels'],row
  assert row['heldOutMax']<old['limits']['heldOutMaxPixels'],row
  # Real measured features retained as POINTS2D, unassociated IDs explicitly -1.
  pose=' '.join(format(float(v),'.17g') for v in quat+tvec.flatten().tolist())
  pixels=' '.join(f'{p[0]:.17g} {p[1]:.17g} -1' for p in report['measuredCorners'][name])
  text=f'# Independent calibration interchange, no reconstructed point cloud\n{83+i} {pose} 7 {name}\n{pixels}\n'
  (OUT/(name+'.images.txt')).write_bytes(text.encode('utf-8'))
 report['status']='held_out_photographed_opencv_calibration_passed_native_import_pending'
except BaseException as e:
 report.update(status='failed',failure=repr(e),traceback=traceback.format_exc());raise
finally:
 report['completedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({'status':report['status'],'trainingRms':report['trainingRms'],
 'views':[{k:v[k] for k in ('name','heldOutRms','heldOutMax')} for v in report['views']]}))
