"""Source-bound real photographed COLMAP-syntax import/binding/native pixels."""
from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,json,os,queue,re,shutil,subprocess,threading,time,traceback
import cv2
import numpy as np

ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-colmap88'
CAL=ROOT/'artifacts/pr-queue/tracking88-colmap-photographs-calibration-v1'
PHOTO=ROOT/'artifacts/pr-queue/tracking88-photographs-probe-v3'
OUT=ROOT/'artifacts/pr-queue/tracking88-colmap-photographs-native-v4'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
proof=json.loads((ROOT/'artifacts/pr-queue/tracking88-colmap-lens-regression-v2/exit.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binary=Path(proof['binary']);assert proof['status']=='model_core_selected_native_render_host_lib_and_normal_dev_build_passed'
assert sha(binary)==proof['binarySha256']
def identity():
 for n,h in proof['source'].items():assert sha(WORK/n)==h,n
 assert sha(binary)==proof['binarySha256']
identity();measured=json.loads((CAL/'calibration.json').read_text(encoding='utf-8'))
assert measured['status']=='held_out_photographed_opencv_calibration_passed_native_import_pending'
env=os.environ.copy()
for k in list(env):
 if k.startswith('MOTION_'):env.pop(k,None)
env.update(LOCALAPPDATA=str(OUT/'appdata'),TEMP=str(ROOT/'target/ci-policy-validation-tmp'),TMP=str(ROOT/'target/ci-policy-validation-tmp'))
env['PATH']=str(ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')+os.pathsep+env['PATH']
report={'status':'running','startedUtc':datetime.now(timezone.utc).isoformat(),'binarySha256':sha(binary),'source':proof['source'],
 'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),
 'calibrationSha256':sha(CAL/'calibration.json'),'processes':[],'views':[],
 'limits':['Independent OpenCV calibration exported in COLMAP text syntax, not COLMAP multi-view reconstruction',
 'Three separate photographed poses, not continuous motion or surveyed metric scale',
 'Native Unorm8 preview plus fresh reopen; all-precision, final export and source-bound CI separate']}
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
active=[];project=OUT/'bootstrap'
class Client:
 def __init__(self,label,readonly=False):
  identity();self.label=label;self.ident=0;self.raw=[];self.inputs=[];self.lines=queue.Queue()
  self.stderr=(OUT/(label+'.stderr.log')).open('wb')
  command=[str(binary),'--project',str(project),'--mcp']+(['--mcp-read-only'] if readonly else [])
  self.p=subprocess.Popen(command,cwd=WORK,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr)
  self.row={'label':label,'command':command,'pid':self.p.pid,'startedUtc':datetime.now(timezone.utc).isoformat()}
  report['processes'].append(self.row);active.append(self);save()
  def reader():
   for line in self.p.stdout:self.raw.append(line);self.lines.put(line)
   self.lines.put(None)
  self.thread=threading.Thread(target=reader,daemon=True);self.thread.start()
  self.rpc('initialize',{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'photographed-colmap-format-proof','version':'1'}})
  self.send({'jsonrpc':'2.0','method':'notifications/initialized'})
 def send(self,msg):
  self.inputs.append(msg);self.p.stdin.write((json.dumps(msg)+'\n').encode());self.p.stdin.flush()
 def rpc(self,method,params):
  self.ident+=1;ident=self.ident;self.send({'jsonrpc':'2.0','id':ident,'method':method,'params':params})
  line=self.lines.get(timeout=90);assert line is not None,'process stdout closed'
  msg=json.loads(line);assert msg.get('id')==ident and 'error' not in msg,msg
  return msg['result']
 def tool(self,name,args,error=None):
  r=self.rpc('tools/call',{'name':name,'arguments':args})
  if error:
   assert r.get('isError') and error in r['content'][0]['text'],r
   return r
  assert not r.get('isError'),r
  return r['structuredContent']
 def state(self):return self.tool('motion_state',{})
 def close(self):
  if not self.p.stdin.closed:self.p.stdin.close()
  code=self.p.wait(timeout=30);self.thread.join(timeout=5);self.stderr.close()
  (OUT/(self.label+'.stdin.jsonl')).write_text(''.join(json.dumps(v)+'\n' for v in self.inputs),encoding='utf-8')
  (OUT/(self.label+'.stdout.jsonl')).write_bytes(b''.join(self.raw))
  log=OUT/'appdata/MotionStudio/logs/motion-studio.log'
  if log.exists():(OUT/(self.label+'.file.log')).write_bytes(log.read_bytes())
  self.row.update(exitCode=code,replies=len(self.raw),completedUtc=datetime.now(timezone.utc).isoformat());active.remove(self);save()
  assert code==0,(self.label,code)
  for line in self.raw:assert json.loads(line)['jsonrpc']=='2.0'

def track(v):return {'value':v,'keys':[]}
def layer(x,y):
 return {'id':100+y*8+x,'name':f'Independent board cell {x},{y}',
  'content':{'kind':'solid','color':[0.,1.,0.,1.] if (x+y)%2==0 else [1.,0.,1.,1.]},'size':[100.,100.],
  'transform':{'position':track([320.+100.*(x+.5),240.+100.*(y+.5),0.]),'rotation':track([0.,0.,0.]),'scale':track([100.,100.,100.]),'opacity':track(1.),'anchor':[.5,.5]},
  'visible':True,'locked':False,'solo':False,'effects_enabled':True,'shy':False,'three_d':True,
  'sampling':{'frame_blend':'hold','motion_blur':None,'continuous_rasterization':False},
  'rotation_order':'local_xyz','parent':None,'effects':[],'blend':{'mode':'normal','space':'linear'},
  'audio_markers':[],'audio_source_channel':'stereo'}

save();began=time.monotonic()
try:
 bootstrap=Client('bootstrap');base=bootstrap.state()['project'];bootstrap.close()
 K=np.array(measured['K']);dist=np.array(measured['distortion']);assert dist[-1]==0.
 yy,xx=np.mgrid[:480,:640].astype(np.float64)
 pixels=np.stack([xx+.5,yy+.5],-1).reshape(-1,1,2)
 ideal=cv2.undistortPoints(pixels,K,dist,criteria=(cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER,100,1e-13)).reshape(480,640,2)
 rays=np.concatenate([ideal,np.ones((480,640,1))],axis=-1);panels=[]
 for view in measured['views']:
  name=view['name'];label=name.removesuffix('.jpg');project=OUT/label;(project/'assets').mkdir(parents=True)
  original=(PHOTO/name).read_bytes();assert sha(PHOTO/name)==next(f['sha256'] for f in measured['sourceManifest']['files'] if f['name']==name)
  (project/'assets'/name).write_bytes(original)
  p=copy.deepcopy(base);p.update(width=640,height=480,fps={'numerator':24,'denominator':1},frames=96,work_area={'in_frame':0,'out_frame':96},background=[0.,0.,0.,0.],layers=[],video_assets=[],tracking_assets=[],assets=[{'id':1,'path':'assets/'+name,'width':640,'height':480}])
  p['camera']['created']=True;(project/'project.json').write_text(json.dumps(p),encoding='utf-8',newline='\n')
  vendor={'format':'colmap-cameras-images-text-v1','cameras':(CAL/'cameras.txt').read_bytes().decode('utf-8'),'images':(CAL/(name+'.images.txt')).read_bytes().decode('utf-8'),
   'source':{'id':'Independent OpenCV photographed board '+name,'sha256':list(hashlib.sha256(original).digest()),'extent':[640,480],'ticks_per_second':24000,'nominal_rate':[24,1],'pts':[0]},
   'frames':[{'source_index':0,'image_name':name,'confidence':1.}],
   'options':{'track_id':'photographed-board','world_basis':[1,2,3],'source_meters_per_unit':1.,'target_meters_per_unit':1.,'target_origin':[0.,0.,0.]}}
  document=OUT/(label+'.mstrack');document.write_text(json.dumps(vendor,indent=2)+'\n',encoding='utf-8',newline='\n');document_bytes=document.read_bytes()
  client=Client(label+'-edit');before=client.state()
  imported=client.tool('import_tracking',{'path':str(document),'source':{'kind':'image','id':1},'expectedRevision':before['revision'],'expectedDocumentGeneration':before['document_generation']})
  assert imported['trackingImport']['format']=='colmap_camera_text_v1' and imported['trackingImport']['decodedSourceVerified']
  assert imported['project']['camera']==before['project']['camera']
  descriptor=imported['project']['tracking_assets'][-1];assetid=descriptor['id']
  assert (project/descriptor['path']).read_bytes()==document_bytes
  import_undo=client.tool('motion_history',{'operation':'undo'})
  assert import_undo['project']==before['project']
  import_redo=client.tool('motion_history',{'operation':'redo'})
  assert import_redo['project']==imported['project']
  def edit(commands):return client.tool('command_batch',{'commands':commands,'expectedRevision':client.state()['revision']})
  edit([{'op':'add','layer':layer(x,y)} for y in range(5) for x in range(8)])
  camera=client.state()['project']['camera'];pos=camera['position']['value']
  binding={'asset':assetid,'track':'photographed-board','anchor_local_frame':0,'source_anchor_pts':0,'speed_numerator':1,'speed_denominator':1,
   'world_basis':[1,-2,-3],'target_meters_per_unit':.01,'target_origin':[0.,0.,0.],
   'correction_reference':{'world':{'position':[pos[0]-320.,240.-pos[1],-pos[2]],'orientation_xyzw':[0.,0.,0.,1.]},'vertical_fov_degrees':camera['fov']['value']},
   'crop':[0.,0.,640.,480.],'rotation':'none','near':.5,'far':100000.,'interpolation':'linear','max_gap_ticks':0,'minimum_confidence':.8,'missing':'error'}
  goodstate=client.state();bad=copy.deepcopy(binding);bad['track']='absent'
  client.tool('command_batch',{'commands':[{'op':'set_tracking_camera','object':0,'binding':bad}],'expectedRevision':goodstate['revision']},error='track=absent')
  assert client.state()['project']==goodstate['project']
  bound=edit([{'op':'set_tracking_camera','object':0,'binding':binding}])
  state=client.tool('motion_seek',{'frame':0.});anchors={l['id']:l['anchor'] for l in state['projectedLayers']}
  R=np.array(view['worldToCameraRotation']);t=np.array(view['worldToCameraTranslation']);rvec=cv2.Rodrigues(R)[0]
  cells=np.array([[x+.5,y+.5,0.] for y in range(5) for x in range(8)],np.float64)
  expected_anchors=cv2.projectPoints(cells,rvec,t,K,dist)[0].reshape(-1,2)
  assert all(len(anchors[100+i])==3 and np.isfinite(anchors[100+i]).all() and 0.<=anchors[100+i][2]<=1. for i in range(40))
  max_anchor=max(float(np.linalg.norm(np.array(anchors[100+i][:2])-q)) for i,q in enumerate(expected_anchors))
  assert max_anchor<.0003,(name,max_anchor)
  capture=client.tool('render_preview',{'frame':0.});dest=OUT/(label+'-native.png');shutil.copyfile(capture['path'],dest)
  undo=client.tool('motion_history',{'operation':'undo'});assert undo['project']['camera'].get('tracking') is None
  redo=client.tool('motion_history',{'operation':'redo'});assert redo['project']==bound['project']
  client.tool('motion_save',{});document.unlink();client.close()
  client=Client(label+'-reopen',True);assert client.state()['project']==bound['project'];client.close()
  stored=(project/descriptor['path']).read_bytes();assert stored==document_bytes
  assert json.loads(stored)['cameras']==vendor['cameras'] and json.loads(stored)['images']==vendor['images']
  origin=-R.T@t;ray=rays@R;distance=-origin[2]/ray[:,:,2];world=origin+distance[:,:,None]*ray
  wx,wy=world[:,:,0],world[:,:,1];inside=(distance>0)&(wx>=0)&(wx<8)&(wy>=0)&(wy<5)
  odd=(np.floor(wx).astype(int)+np.floor(wy).astype(int))%2==1
  expected=np.zeros((480,640,4),np.uint8);expected[inside&~odd]=[0,255,0,255];expected[inside&odd]=[255,0,255,255]
  cv2.imwrite(str(OUT/(label+'-independent.png')),expected[:,:,[2,1,0,3]])
  actual=cv2.imread(str(dest),cv2.IMREAD_UNCHANGED)[:,:,[2,1,0,3]];assert actual.shape==expected.shape
  stable=np.ones((480,640),bool)
  for dy in [-2,0,2]:
   for dx in [-2,0,2]:stable&=np.all(expected==np.roll(expected,(dy,dx),(0,1)),axis=2)
  stable[:2]=False;stable[-2:]=False;stable[:,:2]=False;stable[:,-2:]=False
  alpha_error=int(np.abs(actual[:,:,3].astype(int)-expected[:,:,3].astype(int))[stable].max())
  a=actual.copy();b=expected.copy();transparent=(a[:,:,3]==0)&(b[:,:,3]==0);a[transparent,:3]=0;b[transparent,:3]=0
  maximum=int(np.abs(a.astype(int)-b.astype(int))[stable].max());checked=int(stable.sum())
  assert checked>200000 and int((stable&inside).sum())>3000 and alpha_error<=2 and maximum<=2,(name,checked,alpha_error,maximum)
  def linear(v):
   x=v[:,:,:3].astype(float)/255.;return np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)
  aa=actual[:,:,3:4].astype(float)/255.;ba=expected[:,:,3:4].astype(float)/255.;composite=[]
  for bg in [0.,1.]:
   err=float(np.abs(linear(actual)*aa+bg*(1-aa)-linear(expected)*ba-bg*(1-ba))[stable].max())*255.;assert err<=2.,(name,bg,err);composite.append(err)
  log=(OUT/(label+'-edit.file.log')).read_text(encoding='utf-8');stderr=(OUT/(label+'-edit.stderr.log')).read_text(encoding='utf-8',errors='replace')
  assert re.search(r'start #\d+ import_tracking',log)
  for sink in [log,stderr]:assert 'track=absent' in sink and re.search(r'error #\d+',sink)
  photo=cv2.imread(str(PHOTO/name));alpha=actual[:,:,3:4].astype(float)/255.*.6
  overlay=(photo*(1-alpha)+actual[:,:,[2,1,0]]*alpha).round().astype(np.uint8)
  for idx in view['validationIndices']:
   q=measured['measuredCorners'][name][idx];cv2.circle(overlay,tuple(int(round(v-.5)) for v in q),2,(0,200,255),1,cv2.LINE_AA)
  left=cv2.copyMakeBorder(photo,28,0,0,0,cv2.BORDER_CONSTANT,value=(25,25,25));right=cv2.copyMakeBorder(overlay,28,0,0,0,cv2.BORDER_CONSTANT,value=(25,25,25))
  cv2.putText(left,name+' | original',(8,19),cv2.FONT_HERSHEY_SIMPLEX,.5,(240,240,240),1,cv2.LINE_AA)
  cv2.putText(right,f'Native import | held-out RMS {view["heldOutRms"]:.3f} px',(8,19),cv2.FONT_HERSHEY_SIMPLEX,.5,(240,240,240),1,cv2.LINE_AA)
  panels.append(np.concatenate([left,right],axis=1))
  report['views'].append({'name':name,'heldOutRms':view['heldOutRms'],'heldOutMax':view['heldOutMax'],
   'maxAnchorErrorPixels':max_anchor,'checkedStablePixels':checked,'interiorStablePixels':int((stable&inside).sum()),
   'maxByteError':maximum,'maxAlphaByteError':alpha_error,'blackWhiteCompositeByteErrors':composite,
   'photoSha256':sha(PHOTO/name),'captureSha256':sha(dest),'originalDocumentSha256':hashlib.sha256(document_bytes).hexdigest(),
   'undoRedoReopen':True,'defaultErrorFileAndStderr':True});save()
 identity();cv2.imwrite(str(OUT/'comparison.png'),np.concatenate(panels,axis=0))
 report.update(status='photographed_colmap_syntax_native_import_binding_pixels_and_reopen_passed',sourceUnchanged=True,elapsedSeconds=round(time.monotonic()-began,3))
except BaseException as e:report.update(status='failed',failure=repr(e),traceback=traceback.format_exc());raise
finally:
 for c in list(active):
  try:c.close()
  except BaseException as secondary:report.setdefault('cleanupFailures',[]).append(repr(secondary))
 report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({'status':report['status'],'views':report['views'],'elapsedSeconds':report['elapsedSeconds']}))
