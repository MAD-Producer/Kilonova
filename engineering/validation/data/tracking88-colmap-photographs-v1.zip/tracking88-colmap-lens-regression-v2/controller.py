"""One frozen-source serial model/core/native-render/host/build regression."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,time,traceback
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-colmap88'
OUT=ROOT/'artifacts/pr-queue/tracking88-colmap-lens-regression-v2'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines())
sources={n:sha(WORK/n) for n in sorted(paths) if (WORK/n).is_file() and
 (n in ('Cargo.toml','Cargo.lock','ATTRIBUTION.md','PROVENANCE.md','NOTICE') or n.startswith(('crates/','desktop/','tools/')) and Path(n).suffix in ('.rs','.wgsl','.toml','.json','.py'))}
report={'status':'running','controllerPid':os.getpid(),'startedUtc':datetime.now(timezone.utc).isoformat(),
 'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),'source':sources,
 'steps':[],'scope':'Full model/core targets, selected native render targets, complete host lib, desktop FFmpeg check and normal dev executable. Full desktop/UI and final CI separate.'}
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def identity():
 for n,h in sources.items():assert sha(WORK/n)==h,n
env=os.environ.copy()
for key in list(env):
 if key.startswith('MOTION_'):env.pop(key,None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/rational-rate85-contract'),
 CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',PYTHONUTF8='1',
 TEMP=str(ROOT/'target/ci-policy-validation-tmp'),TMP=str(ROOT/'target/ci-policy-validation-tmp'),MOTION_LENS_ARTIFACTS=str(OUT/'lens-artifacts'))
steps=[('focused-lens',['cargo','test','-p','motion-model','--test','tracking_lens','--test','tracking_lens_relaxation','--locked','--offline','--','--test-threads=1'])]
for package in ('motion-model','motion-core'):
 steps.append((package,['cargo','test','-p',package,'--locked','--offline','--','--test-threads=1']))
render=['cargo','test','-p','motion-render']
for name in ('tracking_lens','working_precision','viewer_views','viewer_frame_views','multiple_camera_compositions','scene_gpu','model_layers','image_capture','exposure_scenes','nested_exposure'):
 render+=['--test',name]
steps+=[('native-render',render+['--locked','--offline','--','--test-threads=1']),
 ('host-lib',['cargo','test','-p','motion-host','--lib','--locked','--offline','--','--test-threads=1']),
 ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg','--locked','--offline']),
 ('normal-dev-build',['cargo','build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline'])]
save();began=time.monotonic()
try:
 for label,args in steps:
  identity();row={'label':label,'command':args,'startedUtc':datetime.now(timezone.utc).isoformat()};report['steps'].append(row);save()
  start=time.monotonic()
  with (OUT/(label+'.stdout.log')).open('wb') as stdout,(OUT/(label+'.stderr.log')).open('wb') as stderr:
   p=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait()
  row.update(elapsedSeconds=round(time.monotonic()-start,3),completedUtc=datetime.now(timezone.utc).isoformat());save()
  assert row['exitCode']==0,(label,row['exitCode'])
 identity();binary=ROOT/'target/rational-rate85-contract/debug/motion-studio.exe'
 report.update(status='model_core_selected_native_render_host_lib_and_normal_dev_build_passed',sourceUnchanged=True,
  binary=str(binary),binarySha256=sha(binary),binaryBytes=binary.stat().st_size,elapsedSeconds=round(time.monotonic()-began,3))
except BaseException as e:report.update(status='failed',failure=repr(e),traceback=traceback.format_exc());raise
finally:report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({'status':report['status'],'seconds':report['elapsedSeconds'],'steps':[(s['label'],s['exitCode']) for s in report['steps']]}))
