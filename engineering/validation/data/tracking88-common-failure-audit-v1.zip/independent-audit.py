"""Recompute retained plane errors without tracking, decoding or tuning limits."""
from pathlib import Path
import hashlib,json,math,statistics,zipfile
BASE=Path('E:/Dev/aem/artifacts/pr-queue');OUT=BASE/'tracking88-common-failure-audit-v1'
truth=BASE/'tracking88-real-planar-acquisition-v1/phone-gt.zip'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(truth)=='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
with zipfile.ZipFile(truth) as bundle:
 names=sorted(i.filename for i in bundle.infolist() if not i.is_dir())
 assert names==[f'img_{i:05d}.txt' for i in range(200,2500)]
 quads=[]
 for name in names:
  assert bundle.getinfo(name).file_size<=1024
  values=list(map(float,bundle.read(name).decode('ascii').split()))
  assert len(values)==8 and all(map(math.isfinite,values))
  quads.append([(values[4+i]-1,values[i]-1) for i in range(4)])
def project(matrix,point):
 x,y=point;v=[row[0]*x+row[1]*y+row[2] for row in matrix]
 assert all(map(math.isfinite,v)) and abs(v[2])>1e-10
 return v[0]/v[2],v[1]/v[2]
def stats(values):return dict(count=len(values),minimum=min(values),median=statistics.median(values),maximum=max(values))
variants=[('original','tracking88-photographed-prototype-v6',915),('persistent-descriptors','tracking88-photographed-identity-v1',890),('manual-photometric-support','tracking88-photographed-manual-support-v1',836)]
report=dict(status='retained_observations_recomputed_not_new_tracker_acceptance',annotation_sha256=digest(truth),variants=[],limits=['No source video decoding, model/tracker rerun or production edit','Independent numeric read of retained outputs against pinned annotations; no new useful-coverage or uncertainty qualification','Confidence ranges are descriptive; no threshold tuned or acceptance weakened','Third-party annotations, requests and per-frame payloads stay local and are not redistributed'])
sets=[];reference_request=None
for label,folder,expected in variants:
 root=BASE/folder;request=json.loads((root/'periodic-manual-200.request.json').read_text(encoding='utf-8'))
 if reference_request is None:reference_request=request
 else:assert request==reference_request
 asset_path=root/'periodic-manual-200/tracks.mstrack';asset=json.loads(asset_path.read_text(encoding='utf-8'))
 assert asset['source_sha256']=='c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
 assert asset['source_pts']==list(range(2300))
 track=next(t for t in asset['tracks'] if t['kind']=='plane');errors=[];bad=[];good_conf=[];bad_conf=[]
 for i,sample in enumerate(track['samples']):
  assert sample['source_index']==i
  if i==0 or sample['manual_correction'] or sample['visibility']!='visible':continue
  actual=[project(sample['observation']['matrix'],p) for p in quads[0]]
  error=max(math.dist(p,q) for p,q in zip(actual,quads[i]));errors.append(error)
  if error>15:bad.append(i);bad_conf.append(sample['confidence'])
  else:good_conf.append(sample['confidence'])
 assert len(errors)==expected and len(bad)==21
 sets.append(set(bad))
 report['variants'].append(dict(name=label,raw_output_sha256=digest(asset_path),automatic_visible=len(errors),over_15_pixels=len(bad),maximum_error=max(errors),rms_error=math.sqrt(statistics.mean(x*x for x in errors)),bad_confidence=stats(bad_conf),other_visible_confidence=stats(good_conf),bad_source_indices=bad))
common=set.intersection(*sets);union=set.union(*sets)
report.update(common_bad_count=len(common),union_bad_count=len(union),identical_bad_indices=all(s==sets[0] for s in sets),common_source_indices=sorted(common),source_mutated=False)
(OUT/'receipt.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
