from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess
root=Path('E:/Dev/aem');work=root/'.worktrees/gltf-morph-targets'
out=root/'artifacts/pr-queue/issue87-morph-cpu-v1';out.mkdir(exist_ok=False)
def source():
 paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z'],cwd=work).decode().split('\0')
 return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if p and (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
before=source();env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',TEMP=str(root/'target/ci-policy-validation-tmp'),TMP=str(root/'target/ci-policy-validation-tmp'))
receipt=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),source=before,startedUtc=datetime.now(timezone.utc).isoformat(),controllerPid=os.getpid(),steps=[])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
for name,cmd in [('scene-cpu',['cargo','test','-p','motion-scene','--locked','--offline','--','--test-threads=1']),('scene-clippy',['cargo','clippy','-p','motion-scene','--all-targets','--locked','--offline','--','-D','warnings'])]:
 print(json.dumps(dict(start=name)),flush=True)
 with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
  p=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr);code=p.wait()
 row=dict(name=name,command=cmd,exitCode=code,sourceUnchanged=before==source())
 for stream in ('stdout','stderr'):row[stream+'Sha256']=hashlib.sha256((out/(name+'.'+stream+'.log')).read_bytes()).hexdigest()
 totals=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (out/(name+'.stdout.log')).read_text(encoding='utf-8'))
 if totals:row['totals']=dict(zip(('passed','failed','ignored'),(sum(int(v[i]) for v in totals) for i in range(3))))
 receipt['steps'].append(row);(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(row),flush=True)
 assert code==0 and row['sourceUnchanged']
 if totals:assert row['totals']==dict(passed=73,failed=0,ignored=0)
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
