from pathlib import Path
import hashlib, json, zipfile

root=Path('E:/Dev/aem')
work=root/'.worktrees/professional-green86'
base=root/'artifacts/pr-queue'
entries={}
sha=lambda b:hashlib.sha256(b).hexdigest()
for folder in ('professional86-screen-photo-link-v1','professional86-screen-photo-native-v1'):
    for p in (base/folder).rglob('*'):
        if p.is_file():
            assert p.suffix.lower() not in ('.exe','.dll','.pdb')
            entries['runs/'+p.relative_to(base).as_posix()]=p.read_bytes()
for name in ('crates/motion-desktop-media/tests/professional_screen_photo.rs',
             'crates/motion-desktop-media/tests/fixtures/professional-screen/source.json',
             'crates/motion-desktop-media/tests/fixtures/professional-screen/README.md',
             'ATTRIBUTION.md','PROVENANCE.md','NOTICE'):
    entries['source/'+name]=(work/name).read_bytes()
entries['prepare-controller.py']=(root/'.tools/issue-closure-review/prepare-professional86-screen-photo-v1.py').read_bytes()
entries['archive-controller.py']=Path(__file__).read_bytes()
manifest={p:dict(bytes=len(b),sha256=sha(b)) for p,b in sorted(entries.items())}
entries['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=work/'engineering/validation/data/professional86-screen-photo-v1.zip'
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,b in sorted(entries.items()):z.writestr(p,b)
with zipfile.ZipFile(dest) as z:
    assert set(z.namelist())==set(entries)
    for p,b in entries.items():assert z.read(p)==b
report=dict(archive=dest.name,bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),
            members=len(entries),everyMemberReadBack=True,manifest=manifest,
            limits=['Photograph remains subject to credited NASA media-use guidelines, not repository MIT license',
                    'Static authored quad/opacity, not automatic tracking, movie or antialiased-edge acceptance'])
dest.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='manifest'}))
