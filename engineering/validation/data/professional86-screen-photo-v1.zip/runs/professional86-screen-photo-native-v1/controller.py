from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, time

root = Path('E:/Dev/aem')
work = root / '.worktrees/professional-green86'
out = root / 'artifacts/pr-queue/professional86-screen-photo-native-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def identity():
    names = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=work,text=True).splitlines()
    return {p: sha(work / p) for p in names if (work / p).is_file() and
            (p.startswith(('crates/','desktop/','sdk/')) or p in ('Cargo.toml','Cargo.lock','ATTRIBUTION.md','PROVENANCE.md','NOTICE'))}

before = identity()
link_path = root / 'artifacts/pr-queue/professional86-screen-photo-link-v1/exit.json'
link = json.loads(link_path.read_text(encoding='utf-8'))
assert link['status'] == 'linked_not_executed' and link['sourceUnchanged']
assert link['source'] == before
exe = Path(link['executable']['path'])
assert sha(exe) == link['executable']['sha256']
env = os.environ.copy()
for key in list(env):
    if key.startswith('MOTION_'):
        env.pop(key,None)
env.update(LOCALAPPDATA=str(out / 'appdata'), RUST_BACKTRACE='full',
           TEMP=str(root / 'target/ci-policy-validation-tmp'),TMP=str(root / 'target/ci-policy-validation-tmp'),
           MOTION_PHOTOGRAPHED_SCREEN_ARTIFACTS=str(out / 'native'))
report = dict(status='running',source=before,baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
              linkedExecutable=link['executable'],linkReceiptSha256=sha(link_path),command=[str(exe),'--test-threads=1','--nocapture'],
              startedUtc=datetime.now(timezone.utc).isoformat(),
              limits=['One native photographed static-screen control, not full regression or complete issue86',
                      'Original three-byte channel budget, two-pixel edge exclusion, minimum1500 checked insert pixels',
                      'Default Info, original backend/stack, one own GPU workload, controlled E temp/cache'])
def save():
    (out / 'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
started = time.monotonic()
save()
try:
    with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(report['command'],cwd=work,env=env,stdout=stdout,stderr=stderr)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    report['sourceUnchanged'] = before == identity()
    assert report['sourceUnchanged'] and sha(exe) == link['executable']['sha256']
    if report['exitCode'] == 0:
        text = (out / 'stdout.log').read_text(encoding='utf-8')
        assert re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text,re.M) == [('ok','1','0','0','0','0')]
        result = json.loads((out / 'native/result.json').read_text(encoding='utf-8'))
        assert result['actualNativeGpu'] and result['historyAndReopen'] and result['frozenAfterOwnersAndSourcesRemoved']
        report.update(status='native_photographed_screen_passed_visual_review_pending',result=result)
    else:
        report['status'] = 'failed_original_outputs_retained'
except BaseException as error:
    report.update(status='failed_original_outputs_retained',failure=repr(error))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-started)
    save()
print(json.dumps({k:v for k,v in report.items() if k!='source'}))
raise SystemExit(report['exitCode'])
