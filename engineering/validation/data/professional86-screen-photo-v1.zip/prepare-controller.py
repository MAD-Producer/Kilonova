from pathlib import Path
import hashlib, json
from PIL import Image
import PIL

root = Path('E:/Dev/aem')
original = root / '.tools/ai-depth74/natural-domain/interior.jpg'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(original) == '2efb4c28adab8e70ed026856ed0d6e4472ea7de4d0576f37a87150775fdf8c5f'
dest = root / '.worktrees/professional-green86/crates/motion-desktop-media/tests/fixtures/professional-screen'
dest.mkdir(exist_ok=False)
image = Image.open(original)
assert image.size == (3032, 2064)
image.convert('RGB').resize((960, 654), Image.Resampling.LANCZOS).save(dest / 'destiny-screen.png')
record = dict(author='NASA / Expedition 7 ISS crew; individual photographer unspecified',
              source='https://images-assets.nasa.gov/image/iss007e11800/iss007e11800~orig.jpg',
              revision='ISS007-E-11800, 2003-08-03',
              license='NASA informational/factual technical-evaluation media-use guidelines, no endorsement',
              licenseSource='https://www.nasa.gov/nasa-brand-center/images-and-media/',
              originalSha256=sha(original), derivativeSha256=sha(dest / 'destiny-screen.png'),
              modification='Interpret untagged SDR JPEG as sRGB, decode RGB8 and Lanczos resize 3032x2064 to 960x654',
              tool='Pillow ' + PIL.__version__,
              screenQuad=[[168,60],[219,74],[205,116],[154,106]],
              quadAuthor='Motion Studio contributors, manually authored from photograph before native execution',
              evaluation=dict(channelBudget=3, edgeExclusionPixels=2, minimumCheckedInsertPixels=1500),
              limits=['Static photograph, not automatic tracking or temporal footage',
                      'Independent authored insert, not a recovered original screen image',
                      'Technical test fixture only; no product/release artwork or NASA endorsement'])
(dest / 'source.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
(dest / 'README.md').write_text('''# Photographed screen API fixture

Credit: NASA / Expedition 7 ISS crew, ISS007-E-11800, 2003-08-03.
The individual photographer is unspecified. See `source.json` for the original
source URL, both hashes, exact modification and tools. This is a resized RGB
derivative for factual technical evaluation under the
[NASA media-use guidelines](https://www.nasa.gov/nasa-brand-center/images-and-media/),
not NASA endorsement, product artwork or a repository-MIT-licensed photograph.

The screen quad and replacement gradient are independently authored MIT test
data. Static image registration does not establish automatic tracking,
photometric matching or real-footage temporal quality. Neither the photograph
nor its derivative is referenced by product resources or release packaging.
''', encoding='utf-8')
print(json.dumps(record))
