"""Serial formal product-package cache qualification through maintained examples."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess, traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/depth-wgsl-cache75'
BASE = ROOT / 'artifacts/pr-queue'
OUT = BASE / 'depth75-wgsl-workspace-proofs-v1'
TARGET = ROOT / 'target/depth-wgsl-cache75-contract'
RESOURCES = BASE / 'depth75-wgsl-cache-resources-v2'
PYTHON = ROOT / '.tools/ai-depth74/venv/Scripts/python.exe'
MODEL = BASE / 'depth75-resolution-models-v1/518/export/depth_anything_v2_vits_518.onnx'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
old = json.loads((BASE / 'depth75-wgsl-product-proofs-v1/session-consumed.json').read_text())
assert old['consumed'] and old['exit_code'] == 1
assert not {'RUST_MIN_STACK', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'PYTHONPATH'} & os.environ.keys()
assert shutil.disk_usage(ROOT).free >= 10 << 30
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert head.startswith('4729ab6d')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
paths = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()
def hashes(): return {p: sha(WORK / p) for p in paths}
OUT.mkdir(exist_ok=False)
report = dict(status='running', head=head, source_sha256=hashes(), stages=[], started_utc=datetime.now(timezone.utc).isoformat(), limits=[
    'Real root-workspace dependency graph and pinned lockfile; no standalone fixture manifest',
    'Previous standalone rustc crash retained with unresolved cause; not an unchanged retry',
    'All original model/cache/numerical/publication assertions and deadlines retained; extra ownership guards added',
    'One synthetic 12x8 RGB input; not video quality, measured automatic profile selection, sustained load or thermal qualification',
    'One own heavy workload; E-only runtime/cache/output; no Android, panels, cache deletion, process memory or global changes',
    'Previous complete174 changed-crate gate remains source-bound to d853; current complete workspace and cross-platform CI remain separate'])
def save():
    pending = OUT / 'receipt.pending.json'
    pending.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(pending, OUT / 'receipt.json')
env = {k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', TEMP=str(TARGET/'tmp'), TMP=str(TARGET/'tmp'), LOCALAPPDATA=str(OUT/'appdata'), RUST_BACKTRACE='full')
def run(name, command):
    assert shutil.disk_usage(ROOT).free >= 10 << 30
    row = dict(name=name, command=[str(v) for v in command]); report['stages'].append(row); save()
    print('start ' + name, flush=True)
    with (OUT/(name+'.stdout.log')).open('wb') as output, (OUT/(name+'.stderr.log')).open('wb') as errors:
        child = subprocess.Popen(row['command'], cwd=WORK, env=env, stdout=output, stderr=errors)
        row['pid'] = child.pid; save(); row['exit_code'] = child.wait()
    save(); print('done ' + name + ' exit=' + str(row['exit_code']), flush=True)
    assert row['exit_code'] == 0, name + ' failed; original output retained'
def observed(name, expected_status, error_cause):
    raw = (OUT/(name+'.stdout.log')).read_text(encoding='utf-8')
    assert len(raw.splitlines()) == 1
    result = json.loads(raw); assert result['status'] == expected_status
    errors = (OUT/(name+'.stderr.log')).read_text(encoding='utf-8')
    assert 'ERROR ' in errors and error_cause in errors
    assert ' INFO ' not in errors and ' DEBUG ' not in errors
    logs = (OUT/name/'execution/logs/motion-studio.log').read_text(encoding='utf-8')
    assert ' INFO ' in logs and ' ERROR ' in logs and error_cause in logs
    report[name] = result; save(); return result
save()
try:
    manifest = json.loads(MODEL.with_name('model.json').read_text())
    assert sha(MODEL) == manifest['sha256']
    run('workspace-product-build', ['cargo', 'build', '--locked', '--offline', '-p', 'motion-desktop', '-p', 'motion-host', '--bin', 'motion-depth-wgsl', '--example', 'wgsl_depth_cache', '--example', 'wgsl_depth_cache_boundaries', '--example', 'wgsl_depth_cache_identity', '--features', 'motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth'])
    native = TARGET/'debug/motion-depth-wgsl.exe'
    product = json.loads((BASE/'depth75-wgsl-cache-product-v2/receipt.json').read_text())
    runtime = {Path(r['source']).name:r for r in product['validation_runtime']}
    assert len(runtime) == 7
    for directory in (TARGET/'debug', TARGET/'debug/examples'):
        directory.mkdir(exist_ok=True)
        for filename, row in runtime.items():
            src = Path(row['source']); assert sha(src) == row['sha256']
            dst = directory/filename
            if not dst.exists(): shutil.copy2(src,dst)
            assert sha(dst) == row['sha256']
    report['worker_sha256'] = sha(native)
    report['example_sha256'] = {name:sha(TARGET/'debug/examples'/f'{name}.exe') for name in ('wgsl_depth_cache', 'wgsl_depth_cache_boundaries', 'wgsl_depth_cache_identity')}
    report['model'] = {k:manifest[k] for k in ('id','revision','sha256','processing','license')};save()
    cold = OUT/'cold';cold.mkdir()
    run('cold', [TARGET/'debug/examples/wgsl_depth_cache.exe', cold/'execution', PYTHON, MODEL, RESOURCES/'program.json', native])
    result = observed('cold', 'actual_wgsl_cache_reopened_without_inference_and_default_error_channels_passed', 'content SHA-256 differs')
    assert result['inferenceCalls'] == 1 and result['pixels'] == 96 and result['provider'].startswith('WGSL:Vulkan:')
    boundary = OUT/'boundaries';(boundary/'execution').mkdir(parents=True)
    resources = boundary/'execution/resources';shutil.copytree(RESOURCES/'weights',resources/'weights')
    shutil.copy2(RESOURCES/'program.json',resources/'program.json')
    shutil.copytree(cold/'execution/cache',boundary/'execution/cache')
    entries = list((boundary/'execution/cache').glob('*.depth'));assert len(entries)==1
    value = bytearray(entries[0].read_bytes());value[-33]^=1;entries[0].write_bytes(value)
    selected = json.loads((BASE/'depth75-wgsl-cache-boundaries-v1/resource-selection.json').read_text())
    run('boundaries', [TARGET/'debug/examples/wgsl_depth_cache_boundaries.exe', boundary/'execution', PYTHON, MODEL, resources/'program.json', native, cold, resources/selected['file']])
    result = observed('boundaries', 'actual_cached_wgsl_alignment_generation_resource_refusal_recovery_and_cancel_passed', 'length, digest or finite-value check failed')
    assert result['inferenceCalls']==0 and result['cacheHits']==3 and result['pixels']==96
    assert result['normalizedMaximum']<=0.0002 and result['normalizedMean']<=0.00002
    assert sha(resources/selected['file'])==selected['sha256']
    mutation=OUT/'identity';owned=mutation/'execution/owned-worker';owned.mkdir(parents=True)
    worker=owned/native.name;shutil.copy2(native,worker);assert sha(worker)==report['worker_sha256']
    for filename,row in runtime.items():
        shutil.copy2(Path(row['source']),owned/filename);assert sha(owned/filename)==row['sha256']
    run('identity',[TARGET/'debug/examples/wgsl_depth_cache_identity.exe',mutation/'execution',PYTHON,MODEL,RESOURCES/'program.json',worker])
    result=observed('identity','actual_product_worker_change_between_resolution_and_inference_refused_then_recovered','WGSL worker changed since cache resolution')
    assert result['backendInferEntries']==1 and result['cacheHits']==0 and result['encodedModelInferenceStarted'] is False
    assert 'phase=native_inference start' not in (mutation/'execution/logs/motion-studio.log').read_text(encoding='utf-8')
    assert sha(worker)==report['worker_sha256']
    report['status']='actual_workspace_product_cache_boundaries_and_worker_identity_passed'
except BaseException as cause:
    report.update(status='failed_original_outputs_retained',cause=repr(cause),traceback=traceback.format_exc())
finally:
    report.update(source_unchanged=hashes()==report['source_sha256'],completed_utc=datetime.now(timezone.utc).isoformat())
    report['logs']={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in OUT.glob('*.log')};save()
print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'}),flush=True)
raise SystemExit(0 if report['status']=='actual_workspace_product_cache_boundaries_and_worker_identity_passed' and report['source_unchanged'] else 1)
