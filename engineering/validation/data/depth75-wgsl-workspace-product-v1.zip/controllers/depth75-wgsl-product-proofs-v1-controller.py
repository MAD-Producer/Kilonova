"""Serial actual product-worker proofs after a consumed complete native gate."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,traceback
ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
PRODUCT=BASE/'depth75-wgsl-cache-product-v2';OUT=BASE/'depth75-wgsl-product-proofs-v1'
product=json.loads((PRODUCT/'receipt.json').read_text(encoding='utf-8'))
assert product['status']!='running' and product['source_unchanged']
assert json.loads((PRODUCT/'session-consumed.json').read_text(encoding='utf-8'))['consumed']
assert all(next(s for s in product['stages'] if s['name']==name)['exit_code']==0 for name in ('desktop-check','product-worker-build'))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==product['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
OUT.mkdir(exist_ok=False)
paths=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def hashes():return {p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in paths}
report=dict(status='running',product_head=product['head'],product_regression_status=product['status'],source_sha256=hashes(),stages=[],started_utc=datetime.now(timezone.utc).isoformat(),limits=['Actual GPU and resource/runtime cache admission on one synthetic input, not video quality or sustained/thermal acceptance','One directly owned native/Cargo/model/GPU workload at a time; no retry of failed native regression','Child exit markers are written only after Popen.wait returns its actual exit, separate from the outer tool-session receipt'])
def save():
 p=OUT/'receipt.pending.json';p.write_text(json.dumps(report,indent=2),encoding='utf-8');os.replace(p,OUT/'receipt.json')
def run(name,controller,result_root=None):
 assert shutil.disk_usage(ROOT).free>=10<<30
 row=dict(name=name,controller=str(controller));report['stages'].append(row);save()
 print('start '+name,flush=True)
 with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
  child=subprocess.Popen(['python','-B',str(controller)],cwd=WORK,stdout=stdout,stderr=stderr)
  row['pid']=child.pid;save();row['exit_code']=child.wait()
 save()
 if result_root is not None:
  marker=dict(consumed=True,exit_code=row['exit_code'],pid=child.pid,observer='directly owning serial controller Popen.wait',parent_receipt=str(OUT/'receipt.json'),observed_utc=datetime.now(timezone.utc).isoformat())
  (result_root/'session-consumed.json').write_text(json.dumps(marker,indent=2),encoding='utf-8')
 print('done '+name+' exit='+str(row['exit_code']),flush=True)
 return row['exit_code']
save()
try:
 a=run('product-hardware-cache',BASE/'depth75-wgsl-cache-product-actual-v1-controller.py',BASE/'depth75-wgsl-cache-product-actual-v1')
 assert a==0,'Actual product hardware cache proof failed; dependent cache controls not launched'
 b=run('product-cache-boundaries',BASE/'depth75-wgsl-cache-product-boundaries-v1.py',BASE/'depth75-wgsl-cache-product-boundaries-v1')
 c=run('product-execution-mutation',BASE/'depth75-wgsl-cache-product-mutation-v1-controller.py',BASE/'depth75-wgsl-cache-product-mutation-v1')
 assert b==0 and c==0,'One or more independent product controls failed; original output retained'
 assert run('archive-current-product-proofs',BASE/'archive-depth75-wgsl-product-v1.py')==0,'Text evidence archive verification failed'
 report['status']='actual_product_cache_boundary_and_execution_mutation_controls_passed'
except BaseException as cause:
 report.update(status='failed_original_outputs_retained',cause=repr(cause),traceback=traceback.format_exc())
finally:
 report.update(source_unchanged=hashes()==report['source_sha256'],completed_utc=datetime.now(timezone.utc).isoformat())
 report['logs']={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in OUT.glob('*.log')};save()
print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'}),flush=True)
raise SystemExit(0 if report['status']=='actual_product_cache_boundary_and_execution_mutation_controls_passed' and report['source_unchanged'] else 1)
