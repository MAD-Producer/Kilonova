"""Run the actual WGSL cache fixture with current source and pinned resources.

The isolated harness does not replace a product-package or full regression build.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import tomllib
import traceback

ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/depth-wgsl-cache75'
BASE=ROOT/'artifacts/pr-queue'
OUT=BASE/'depth75-wgsl-cache-product-actual-v1'
PROBE=OUT/'source'
PRODUCT=BASE/'depth75-wgsl-cache-product-v2'
TARGET=ROOT/'target/depth-wgsl-cache75-contract'
RESOURCES=BASE/'depth75-wgsl-cache-resources-v2'
assert json.loads((RESOURCES/'receipt.json').read_text())['status']=='pinned_blueprint_and_all_actual_model_resources_restored_without_inference'
assert shutil.disk_usage(ROOT).free >= 10 << 30
assert not {'RUST_MIN_STACK','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','PYTHONPATH'} & os.environ.keys()
assert not (OUT/'receipt.json').exists()
product=json.loads((PRODUCT/'receipt.json').read_text(encoding='utf-8'))
assert product['status']!='running' and product['source_unchanged']
assert json.loads((PRODUCT/'session-consumed.json').read_text(encoding='utf-8'))['consumed']
assert next(s for s in product['stages'] if s['name']=='desktop-check')['exit_code']==0
assert next(s for s in product['stages'] if s['name']=='product-worker-build')['exit_code']==0
assert __import__('subprocess').check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==product['head']

def hashes():
    paths=[WORK/'tools/ai_depth_onnx.py',WORK/'tools/depth_tensor.py',WORK/'desktop/app/src/logging/sink.rs',WORK/'crates/motion-host/src/depth/wgsl.rs']
    paths+=sorted((WORK/'crates/motion-host/src/depth/wgsl').rglob('*.rs'))
    paths+=sorted((WORK/'desktop/app/src/depth_worker').rglob('*.rs'))
    paths+=sorted((WORK/'desktop/app/src/depth_worker').rglob('*.wgsl'))
    paths += [WORK/relative for relative in product['source_sha256']]
    paths += [PROBE/'Cargo.toml', PROBE/'src/main.rs']
    return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}

env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),
 CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
 TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),LOCALAPPDATA=str(OUT/'appdata'))
report=dict(status='running',source_sha256=hashes(),stages=[],started_utc=datetime.now(timezone.utc).isoformat(),
 limits=['Actual worker built by motion-desktop product package with FFmpeg and AI-depth features; host fixture remains an isolated lockfile-only harness',
 'One synthetic input on local explicit Vulkan hardware; not video quality or sustained performance qualification',
 'Original full regression failures remain unresolved'])
def save(): (OUT/'receipt.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def run(name,command):
    assert shutil.disk_usage(ROOT).free>=10<<30
    row=dict(name=name,command=command);report['stages'].append(row);save()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        row['pid']=child.pid;save();row['exit_code']=child.wait()
    save();assert row['exit_code']==0,name+' failed; original output retained'
save()
try:
    run('metadata',['cargo','metadata','--offline','--format-version','1','--manifest-path',str(PROBE/'Cargo.toml')])
    known={(p['name'],p['version'],p.get('source')):p.get('checksum') for p in tomllib.loads((WORK/'Cargo.lock').read_text())['package']}
    for p in tomllib.loads((PROBE/'Cargo.lock').read_text())['package']:
        if p.get('source'):assert known[p['name'],p['version'],p['source']]==p.get('checksum')
    run('probe-build',['cargo','build','--offline','--locked','--manifest-path',str(PROBE/'Cargo.toml')])
    worker=TARGET/'debug/motion-depth-wgsl.exe'
    model=BASE/'depth75-resolution-models-v1/518/export/depth_anything_v2_vits_518.onnx'
    manifest=json.loads(model.with_name('model.json').read_text())
    assert hashlib.sha256(model.read_bytes()).hexdigest()==manifest['sha256']
    report['worker_sha256']=hashlib.sha256(worker.read_bytes()).hexdigest()
    report['fixture_executable_sha256']=hashlib.sha256((TARGET/'debug/motion-depth75-wgsl-cache-probe.exe').read_bytes()).hexdigest()
    report['resolved_fixture_lock_sha256']=hashlib.sha256((PROBE/'Cargo.lock').read_bytes()).hexdigest()
    report['model']={k:manifest[k] for k in ('id','revision','sha256','processing','license')};save()
    run('actual',[str(TARGET/'debug/motion-depth75-wgsl-cache-probe.exe'),str(OUT/'execution'),str(ROOT/'.tools/ai-depth74/venv/Scripts/python.exe'),str(model),str(RESOURCES/'program.json'),str(worker)])
    stdout=(OUT/'actual.stdout.log').read_text(encoding='utf-8');stderr=(OUT/'actual.stderr.log').read_text(encoding='utf-8')
    assert len(stdout.splitlines())==1
    actual=json.loads(stdout)
    assert actual['status']=='actual_wgsl_cache_reopened_without_inference_and_default_error_channels_passed'
    assert actual['inferenceCalls']==1 and actual['pixels']==96 and actual['provider'].startswith('WGSL:Vulkan:')
    assert 'ERROR ' in stderr and 'stage=cache_read' in stderr and 'content SHA-256 differs' in stderr
    assert ' INFO ' not in stderr and ' DEBUG ' not in stderr
    file=(OUT/'execution/logs/motion-studio.log').read_text(encoding='utf-8')
    for text in [' INFO ','phase=cache_resolve','phase=resolve_native','phase=prepare','phase=native','phase=remap',' ERROR ']:assert text in file,text
    report.update(status='actual_wgsl_model_and_fresh_worker_cache_passed',result=actual,product_head=product['head'],product_main=product['main'],product_regression_status=product['status'])
except BaseException as cause:
    report.update(status='failed_original_outputs_retained',cause=repr(cause),traceback=traceback.format_exc())
finally:
    report.update(source_unchanged=hashes()==report['source_sha256'],completed_utc=datetime.now(timezone.utc).isoformat())
    report['logs']={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in OUT.glob('*.log')};save()
print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'}))
raise SystemExit(0 if report['status']=='actual_wgsl_model_and_fresh_worker_cache_passed' and report['source_unchanged'] else 1)
