"""Archive bounded text evidence; never include weights, binaries or tensors."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile

BASE=Path('E:/Dev/aem/artifacts/pr-queue')
OUT=BASE/'depth75-wgsl-workspace-public-v1'
proof=BASE/'depth75-wgsl-workspace-proofs-v1'
result=json.loads((proof/'receipt.json').read_text(encoding='utf-8'))
assert result['status']=='actual_workspace_product_cache_boundaries_and_worker_identity_passed' and result['source_unchanged']
assert json.loads((proof/'session-consumed.json').read_text())['exit_code']==0
files={}
def put(folder,relative):
    p=BASE/folder/relative
    assert p.is_file() and p.suffix in ('.json','.log','.py')
    raw=p.read_bytes(); assert len(raw)<=4<<20
    key=folder+'/'+relative;assert key not in files;files[key]=raw
def normal(folder):
    for relative in ('receipt.json','session-consumed.json'):put(folder,relative)
    for p in sorted((BASE/folder).glob('*.log')):put(folder,p.name)
normal(proof.name)
for name in ('cold','boundaries','identity'):
    put(proof.name,name+'/execution/logs/motion-studio.log')
normal('depth75-wgsl-cache-product-v2')
normal('depth75-wgsl-cache-product-actual-v1')
normal('depth75-wgsl-product-proofs-v1')
for name in ('depth75-wgsl-workspace-proofs-v1-controller.py','depth75-wgsl-cache-product-v2-controller.py','depth75-wgsl-cache-product-actual-v1-controller.py','depth75-wgsl-product-proofs-v1-controller.py','depth75-wgsl-product-driver-origin-v1.json','depth75-wgsl-product-boundary-drivers-origin-v1.json'):
    raw=(BASE/name).read_bytes();assert len(raw)<=256<<10;files['controllers/'+name]=raw
files['controllers/archive.py']=Path(__file__).read_bytes()
OUT.mkdir(exist_ok=False)
archive=OUT/'depth75-wgsl-workspace-product-v1.zip'
manifest=dict(version=1,status='actual_workspace_product_cache_qualification_archived',head=result['head'],observed_utc=datetime.now(timezone.utc).isoformat(),members={p:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for p,raw in files.items()},limits=result['limits']+[
    'Complete174 changed-crate pass belongs to earlier d853 source, not the later example commit',
    'Failed standalone fixture compilation and unresolved native-crash cause are included',
    'Archive contains no model weights, program resource payloads, executable, DLL, RGB image or depth tensor',
    'Complete maintained-workspace/desktop and exact-final-head remote CI are not qualified by this archive'])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in files.items():z.writestr(name,raw)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(files)|{'manifest.json'}
    for name,raw in files.items():assert z.read(name)==raw
    assert json.loads(z.read('manifest.json'))==manifest
report=dict(status=manifest['status'],head=result['head'],archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members_readback_verified=len(files)+1,limits=manifest['limits'])
(OUT/'receipt.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
