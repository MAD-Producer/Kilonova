"""Serial component gate: fileless closures do not allocate an OS watch backend."""
from pathlib import Path
from datetime import datetime, timezone
from ctypes import wintypes as w
import ctypes
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/prerender-input-priority'
OUT = ROOT / 'artifacts/pr-queue/procedural-source-watch-v3'
PATCH = ROOT / '.tools/issue-closure-review/procedural-source-watch-fix.patch'
PRIOR = ROOT / 'artifacts/pr-queue/prerender-source-fault-order-v2/exit.json'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode('utf-8').strip()

def sources():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {p: hashlib.sha256((WORK / p).read_bytes()).hexdigest() for p in names
            if p and (p.endswith(('.rs', '.toml', '.wgsl', '.py', '.json', '.yml', '.yaml', '.md'))
                      or p in ('Cargo.lock', 'NOTICE'))}

head = git('rev-parse', 'HEAD')
assert head == '510484160fde38d18b177ba8c69baf19af1730dc'
assert git('branch', '--show-current') == 'perf/82-procedural-source-watch'
original = sources()
test_files = {p: h for p, h in original.items() if '/tests/' in p or p.endswith('/tests.rs')}
patch = PATCH.read_bytes()
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'controller.py')
(OUT / 'fix.patch').write_bytes(patch)
report = dict(status='queued', priorController='v2 rejected zero tests; v3 keeps source/test/patch bytes and counts, refreshes package mtimes, verifies actual test inventory', head=head, source=original, steps=[], waitingForOwner=79012,
              startedUtc=datetime.now(timezone.utc).isoformat(),
              limits='Only source-watch resource admission and lifecycle, not P95, full workspace, source-fault ordering integration or native-crash causality. Existing failed performance/native results remain failures. No UI or assertion thresholds changed.')

def save():
    (OUT / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

save()
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
kernel.OpenProcess.restype = w.HANDLE
kernel.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]
kernel.WaitForSingleObject.restype = w.DWORD
kernel.CloseHandle.argtypes = [w.HANDLE]
kernel.CloseHandle.restype = w.BOOL
owner = kernel.OpenProcess(0x100000, False, 79012)
print(json.dumps(dict(waitingForOwner=79012, sourceFiles=len(original))), flush=True)
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0', RUST_BACKTRACE='full',
           LOCALAPPDATA=str(OUT / 'owned-profile'),
           MOTION_SOURCE_WATCH_LOG_ARTIFACTS=str(OUT / 'default-logs'))
fixed = original

def step(name, args, counts=None, negative=None):
    print(json.dumps(dict(start=name)), flush=True)
    began = datetime.now(timezone.utc).isoformat()
    with (OUT / (name + '.stdout.log')).open('wb') as out, (OUT / (name + '.stderr.log')).open('wb') as err:
        code = subprocess.run(args, cwd=WORK, env=env, stdout=out, stderr=err).returncode
    stdout = (OUT / (name + '.stdout.log')).read_text(encoding='utf-8')
    stderr = (OUT / (name + '.stderr.log')).read_text(encoding='utf-8')
    actual = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored', stdout)
    unchanged = sources() == fixed and git('rev-parse', 'HEAD') == head
    if negative:
        passed = code == 101 and actual == [('0', '1', '0')] and negative in stdout + stderr and unchanged
    else:
        passed = code == 0 and unchanged and (counts is None or actual == counts)
    row = dict(name=name, command=args, exitCode=code, counts=actual, passed=passed,
               sourceUnchanged=unchanged, expectedNegative=negative, startedUtc=began,
               completedUtc=datetime.now(timezone.utc).isoformat())
    report['steps'].append(row)
    save()
    print(json.dumps(row), flush=True)
    assert passed, name

try:
    if owner:
        try:
            while True:
                result = kernel.WaitForSingleObject(owner, 10000)
                if result == 0:
                    break
                assert result == 258, f'owner wait failed: {result}'
        finally:
            kernel.CloseHandle(owner)
    prior = json.loads(PRIOR.read_text(encoding='utf-8'))
    assert prior.get('completedUtc') and prior['status'] not in ('running', 'queued')
    assert sources() == original and PATCH.read_bytes() == patch
    report.update(status='running', priorFaultOrderStatus=prior['status'])
    save()
    media = ['cargo', 'test', '-p', 'motion-desktop-media', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--lib']
    # Cross-worktree shared-target dep-info is relative. Refresh package roots'
    # mtimes only; source hashes and all existing assertions remain unchanged.
    touched = []
    for relative in ['crates/motion-desktop-media/src/lib.rs', 'desktop/app/src/main.rs']:
        path = WORK / relative
        old_time = path.stat().st_mtime_ns
        os.utime(path, None)
        touched.append(dict(path=relative, beforeMtimeNs=old_time, afterMtimeNs=path.stat().st_mtime_ns))
    assert sources() == original
    report['timestampOnlyBuildRefresh'] = touched
    save()
    empty = 'movie::prerender::source_watch::tests::procedural_sources_do_not_require_an_os_watcher_and_keep_real_job_lifetimes'
    visual = 'movie::prerender::source_watch::tests::visual_sources_still_require_the_backend_and_preserve_its_original_failure'
    step('source-test-inventory', [*media, '--', '--list'])
    inventory = (OUT / 'source-test-inventory.stdout.log').read_text(encoding='utf-8')
    assert empty + ': test' in inventory and visual + ': test' in inventory
    assert 'a_normal_change_cannot_hide_a_later_watcher_fault_before_retirement: test' not in inventory
    report['exactSourceTestInventoryConfirmed'] = True
    save()
    step('negative-empty', [*media, empty, '--', '--exact', '--test-threads=1'],
         negative='procedural sources must not depend on a native watcher')
    step('nonempty-before', [*media, visual, '--', '--exact', '--test-threads=1'], counts=[('1', '0', '0')])
    report['negativeControlConfirmed'] = True
    p = 'crates/motion-desktop-media/src/movie/prerender/source_watch.rs'
    (OUT / 'source_watch.before.rs').write_bytes((WORK / p).read_bytes())
    subprocess.run(['git', 'apply', '--check', str(PATCH)], cwd=WORK, check=True)
    subprocess.run(['git', 'apply', str(PATCH)], cwd=WORK, check=True)
    fixed = sources()
    assert all(fixed[p] == h for p, h in test_files.items()), 'regression tests changed'
    assert {p for p in fixed if fixed[p] != original[p]} == {'crates/motion-desktop-media/src/movie/prerender/source_watch.rs'}
    report['fixedSource'] = fixed
    save()
    for label, test in [('empty', empty), ('nonempty', visual)]:
        step('fixed-' + label, [*media, test, '--', '--exact', '--test-threads=1'], counts=[('1', '0', '0')])
    step('all-source-watch', [*media, 'movie::prerender::source_watch::', '--', '--test-threads=1'], counts=[('10', '0', '0')])
    step('media-prerender-regression', [*media, 'movie::prerender::', '--', '--test-threads=1'], counts=[('42', '0', '1')])
    step('default-source-logs', ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--bin', 'motion-studio', 'engine::pending_video_tests::prerender_logging::source_watch_records_default_info_and_setup_error_without_stdout_pollution', '--', '--exact', '--test-threads=1'], counts=[('1', '0', '0')])
    step('provenance', [sys.executable, 'tools/validate_provenance.py'])
    step('tool-inventory', [sys.executable, 'tools/validation_inventory.py'])
    report.update(status='accepted_procedural_source_watch_component_only', completedUtc=datetime.now(timezone.utc).isoformat())
    save()
    print(json.dumps(dict(status=report['status'])), flush=True)
except BaseException:
    report.update(status='failed_not_accepted', completedUtc=datetime.now(timezone.utc).isoformat())
    save()
    raise
