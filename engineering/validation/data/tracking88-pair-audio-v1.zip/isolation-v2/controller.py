from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88';OUT=ROOT/'artifacts/pr-queue/tracking88-pair-regression-isolation-v2'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
source={p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in set(paths) if p.endswith('.rs') and (WORK/p).is_file()}
tests=[('precision','shell::project_precision_tests::project_precision_menu_apply_cancel_history_and_gpu_screens_cover_locales_sizes_and_ratios')]
r=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),source=source,results=[])
def save():(OUT/'exit.json').write_text(json.dumps(r,indent=2))
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full')
save()
try:
    for label,test in tests:
        command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','--',test,'--exact','--test-threads=1','--nocapture']
        with (OUT/f'{label}.stdout.log').open('wb') as stdout,(OUT/f'{label}.stderr.log').open('wb') as stderr:
            child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);r.update(phase=label,childPid=child.pid);save();code=child.wait()
        r['results'].append(dict(phase=label,test=test,command=command,exitCode=code));save()
        assert all(hashlib.sha256((WORK/p).read_bytes()).hexdigest()==h for p,h in source.items()),'source changed during isolation'
    r['status']='terminal_isolated_failure_reproduction' if any(a['exitCode'] for a in r['results']) else 'terminal_isolated_tests_passed_full_failure_not_erased'
except BaseException as cause:r.update(status='controller_failed',failure=repr(cause));raise
finally:r['completedUtc']=datetime.now(timezone.utc).isoformat();save()
