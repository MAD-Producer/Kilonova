from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88';OUT=ROOT/'artifacts/pr-queue/tracking88-pair-regression-v1'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
source={p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in set(paths) if p.endswith('.rs') and (WORK/p).is_file()}
commands=[('host',['cargo','test','-p','motion-host','--lib','--locked','--offline','--','--test-threads=1']),('desktop',['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','--','--test-threads=1'])]
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),source=source,commands=commands,results=[])
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2))
env=os.environ.copy();env.pop('MOTION_LOG',None)
for key in ['MOTION_TRACKED_PAIR_NATIVE_DIR','MOTION_TRACKED_PAIR_AUDIO_DIR']:env.pop(key,None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full')
save()
try:
    for label,command in commands:
        with (OUT/f'{label}.stdout.log').open('wb') as stdout,(OUT/f'{label}.stderr.log').open('wb') as stderr:
            child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);report.update(phase=label,childPid=child.pid);save();code=child.wait()
        summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored', (OUT/f'{label}.stdout.log').read_text(encoding='utf-8',errors='replace'))
        report['results'].append(dict(phase=label,exitCode=code,summaries=summaries));save()
        assert all(hashlib.sha256((WORK/p).read_bytes()).hexdigest()==h for p,h in source.items()),'source changed during validation'
        assert code==0,(label,code)
        assert summaries and summaries[-1][0]=='ok' and int(summaries[-1][1])>100 and summaries[-1][2]=='0',summaries
    report['status']='passed_full_host_library_and_ffmpeg_desktop_binary_regressions'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
