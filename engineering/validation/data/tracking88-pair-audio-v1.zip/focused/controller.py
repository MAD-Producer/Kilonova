from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88';OUT=ROOT/'artifacts/pr-queue/tracking88-pair-audio-v4'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
source={p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in set(paths) if p.endswith('.rs') and (WORK/p).is_file()}
commands=[('candidate',['cargo','test','-p','motion-media','--lib','video::candidate::tests::','--locked','--offline','--','--test-threads=1']),('view',['cargo','test','-p','motion-host','--lib','ops::media::tracked_replacement::tests::','--locked','--offline','--','--test-threads=1']),('native',['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','--','engine::tracking_video_replacement_tests::paired::audio::native_audio_and_tracking_replace_rollback_undo_redo_and_reopen_together','--exact','--test-threads=1','--nocapture'])]
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),source=source,commands=commands,results=[])
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2))
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',MOTION_TRACKED_PAIR_AUDIO_DIR=str(OUT))
save()
try:
    for label,command in commands:
        with (OUT/f'{label}.stdout.log').open('wb') as stdout,(OUT/f'{label}.stderr.log').open('wb') as stderr:
            child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);report.update(phase=label,childPid=child.pid);save();code=child.wait()
        report['results'].append(dict(phase=label,exitCode=code));save()
        assert all(hashlib.sha256((WORK/p).read_bytes()).hexdigest()==h for p,h in source.items()),'source changed during validation'
        assert code==0,(label,code)
        count={'candidate':3,'view':5,'native':1}[label]
        assert f'{count} passed; 0 failed' in (OUT/f'{label}.stdout.log').read_text(encoding='utf-8')
    logs=(OUT/'logs/motion-studio.log').read_text(encoding='utf-8');stderr=(OUT/'native.stderr.log').read_text(encoding='utf-8')
    for request in ['pair-audio-binding','pair-audio-save']:
        assert f'tracked video replacement start request={request}' in logs
        assert f'tracked video replacement failed request={request}' in logs
        assert f'tracked video replacement failed request={request}' in stderr
    report['status']='passed_nine_candidate_view_and_native_audio_pcm_gpu_rollback_history_reopen_controls'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
