from pathlib import Path
import ast,hashlib,json,zipfile

root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-colmap88'
new=root/'artifacts/pr-queue/tracking88-document-wire-v2';old=root/'artifacts/pr-queue/tracking88-document-wire-v1';build=root/'artifacts/pr-queue/tracking88-document-native-build-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((new/'exit.json').read_text(encoding='utf-8'));before=json.loads((old/'exit.json').read_text(encoding='utf-8'));b=json.loads((build/'exit.json').read_text(encoding='utf-8'))
assert r['status']=='native_stdio_vendor_import_default_channels_history_and_reopen_passed' and r['sourceUnchanged']
assert before['status']=='failed_original_outputs_retained' and b['status']=='normal_dev_binary_built'
assert r['source']==b['source'] and all(sha(work/n)==h for n,h in r['source'].items())
assert sha(Path(b['binary']))==r['binarySha256']==b['binarySha256']
assert r['editReplyCount']==15 and r['readonlyReplyCount']==3 and len(r['checks'])==6
asserts=lambda p:[ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(p.read_text(encoding='utf-8'))) if isinstance(n,ast.Assert)]
assert asserts(old/'controller.py')==asserts(new/'controller.py')
for label,count in [('edit',15),('readonly-reopen',3)]:
    lines=(new/f'{label}.stdout.jsonl').read_bytes().splitlines();assert len(lines)==count
    assert all(json.loads(line)['jsonrpc']=='2.0' for line in lines)
project=new/'project';data=json.loads((project/'project.json').read_bytes());a=data['tracking_assets'][-1]
raw=(project/a['path']).read_bytes();assert sha(project/a['path'])==a['sha256']
assert a['format']=='colmap_camera_text_v1'
audit=dict(status=r['status'],sourceBase=b['head'],binarySha256=b['binarySha256'],normalDevBuildExit=b['exitCode'],normalDevBuildSeconds=b['elapsedSeconds'],runtimeSeconds=r['elapsedSeconds'],actualReplyCount=18,checks=r['checks'],originalObserverExit=1,originalObserverCause='Windows CRLF fixture write compared against reconstructed LF bytes; v2 explicitly writes LF and retains all 40 original observer assertions',limits=r['limits'])
(new/'independent-summary.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
entries={}
for label,directory in [('failed-observer-v1',old),('native-v2',new),('normal-dev-build',build)]:
    for p in directory.rglob('*'):
        if p.is_file() and p.suffix in ('.py','.json','.jsonl','.log','.png','.mstrack'):
            entries[f'{label}/{p.relative_to(directory).as_posix()}']=p
entries['environment/build.ps1']=root/'.tools/issue-closure-review/build-tracking88-document-native-v1.ps1'
entries['environment/prepare-v2.py']=root/'.tools/issue-closure-review/prepare-tracking88-document-wire-v2.py'
entries['environment/publish.py']=Path(__file__)
entries['source/desktop/app/src/mcp.rs']=work/'desktop/app/src/mcp.rs'
manifest=dict(audit=audit,entries={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in entries.items()})
archive=work/'engineering/validation/data/tracking88-colmap-native-v2.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
    for n,p in entries.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n,p in entries.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(p)
receipt=dict(audit=audit,archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members=len(entries)+1)
archive.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2),flush=True)
