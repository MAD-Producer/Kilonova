from pathlib import Path
import ast,hashlib,json
root=Path('E:/Dev/aem');scripts=root/'.tools/issue-closure-review'
old=scripts/'validate-tracking88-document-wire-v1.py'
new=scripts/'validate-tracking88-document-wire-v2.py'
source=old.read_text(encoding='utf-8')
assertions=lambda s:[ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(s)) if isinstance(n,ast.Assert)]
replacement=source.replace("out=root/'artifacts/pr-queue/tracking88-document-wire-v1'","out=root/'artifacts/pr-queue/tracking88-document-wire-v2'")
needle="path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\\n',encoding='utf-8')"
assert replacement.count(needle)==1
replacement=replacement.replace(needle,"path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\\n',encoding='utf-8',newline='\\n')")
assert assertions(source)==assertions(replacement)
original=root/'artifacts/pr-queue/tracking88-document-wire-v1'
r=json.loads((original/'exit.json').read_text(encoding='utf-8'))
assert r['status']=='failed_original_outputs_retained' and r['failure']=='AssertionError()'
project=original/'project';data=json.loads((project/'project.json').read_bytes());descriptor=data['tracking_assets'][-1]
raw=(project/descriptor['path']).read_bytes();value=json.loads(raw)
lf=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
assert raw!=lf and raw==lf.replace(b'\n',b'\r\n')
assert hashlib.sha256(raw).hexdigest()==descriptor['sha256']
diagnosis=dict(originalExit=1,originalStatus=r['status'],cause='observer fixture write_text used Windows CRLF but final reconstructed bytes assumed LF',actualBytes=len(raw),sha256=descriptor['sha256'],exactCRLFFixtureVerified=True,sourceAndProductionAssertionsChanged=False,unchangedObserverAssertions=len(assertions(source)),newFixture='explicit LF UTF-8 write, same numeric/vendor content, all original observer assertions retained',priorChecks=r['checks'])
(original/'newline-diagnosis.json').write_text(json.dumps(diagnosis,indent=2)+'\n',encoding='utf-8')
new.write_text(replacement,encoding='utf-8',newline='\n')
print(json.dumps(diagnosis,indent=2),flush=True)
