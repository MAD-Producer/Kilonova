from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,time
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-colmap88';out=root/'artifacts/pr-queue/tracking88-document-native-build-v1'
out.mkdir(exist_ok=False);(out/'controller.py').write_bytes(Path(__file__).read_bytes())
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[n for n in git('ls-files','--cached','--others','--exclude-standard','crates','desktop','Cargo.toml','Cargo.lock').splitlines() if n.endswith(('.rs','.wgsl','Cargo.toml','Cargo.lock')) and (work/n).is_file()]
r=dict(status='running',head=git('rev-parse','HEAD'),source={n:sha(work/n) for n in paths},startedUtc=datetime.now(timezone.utc).isoformat())
(out/'exit.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
command=['cargo','build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline'];r['command']=command
start=time.monotonic()
with (out/'build.stdout.log').open('wb') as stdout,(out/'build.stderr.log').open('wb') as stderr:
    p=subprocess.Popen(command,cwd=work,stdout=stdout,stderr=stderr);r['pid']=p.pid
    (out/'exit.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');r['exitCode']=p.wait()
r['sourceUnchanged']=all(sha(work/n)==h for n,h in r['source'].items())
binary=root/'target/rational-rate85-contract/debug/motion-studio.exe'
if r['exitCode']==0 and r['sourceUnchanged']:
    r.update(status='normal_dev_binary_built',binary=str(binary),binarySha256=sha(binary),binaryBytes=binary.stat().st_size)
else:r['status']='failed_original_outputs_retained'
r.update(elapsedSeconds=round(time.monotonic()-start,3),completedUtc=datetime.now(timezone.utc).isoformat())
(out/'exit.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in r.items() if k!='source'},indent=2),flush=True)
assert r['status']=='normal_dev_binary_built'
