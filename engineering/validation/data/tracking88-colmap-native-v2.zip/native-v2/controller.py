from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,queue,struct,subprocess,threading,time,zlib

root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-colmap88'
build=root/'artifacts/pr-queue/tracking88-document-native-build-v1'
proof=json.loads((build/'exit.json').read_text(encoding='utf-8'))
assert proof['status']=='normal_dev_binary_built' and proof['sourceUnchanged']
full=json.loads((root/'artifacts/pr-queue/clock85-aligned-runtime-v2/exit.json').read_text(encoding='utf-8'))
assert full['status']=='aligned_main_complete_desktop_ui_passed_with_documented_codegen_overrides'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(work/n)==h for n,h in proof['source'].items())
binary=Path(proof['binary']);assert sha(binary)==proof['binarySha256']
out=root/'artifacts/pr-queue/tracking88-document-wire-v2';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
project=out/'project';(project/'assets').mkdir(parents=True)
def chunk(name,payload):return struct.pack('>I',len(payload))+name+payload+struct.pack('>I',zlib.crc32(name+payload)&0xffffffff)
pixels=(b'\x00'+bytes([17,83,129,255])*8)*6
png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',8,6,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(pixels))+chunk(b'IEND',b'')
plate=project/'assets/colmap-plate.png';plate.write_bytes(png)
secret='private-payload-sentinel-do-not-log'
cameras=f'# {secret}\r\n7 OPENCV 8 6 7.500 7.25 4 3 0.01 -0.003 0.002 -0.001\r\n'
images='83 1 0 0 0 -1 -2 -3 7 plate.png\n\n'
vendor=dict(format='colmap-cameras-images-text-v1',cameras=cameras,images=images,
 source=dict(id='native authored plate',sha256=list(hashlib.sha256(png).digest()),extent=[8,6],ticks_per_second=90000,nominal_rate=[30000,1001],pts=[-3003]),
 frames=[dict(source_index=0,image_name='plate.png',confidence=.8)],
 options=dict(track_id='external camera',world_basis=[1,-2,-3],source_meters_per_unit=.01,target_meters_per_unit=.1,target_origin=[1,2,3]))
def write(name,value):
    path=out/name;path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');return path
good=write('original.vendor.json',vendor)
bad=json.loads(json.dumps(vendor));bad['images']='83 0 0 0 0 -1 -2 -3 7 plate.png\n\n';bad_pose=write('bad-pose.vendor.json',bad)
bad=json.loads(json.dumps(vendor));bad['source']['sha256'][0]^=255;bad_source=write('wrong-source.vendor.json',bad)
env=os.environ.copy()
for key in list(env):
    if key.startswith('MOTION_'):env.pop(key,None)
env.update(LOCALAPPDATA=str(out/'appdata'),TEMP=str(root/'target/ci-policy-validation-tmp'),TMP=str(root/'target/ci-policy-validation-tmp'))
ffmpeg=root/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
env['PATH']=str(ffmpeg)+os.pathsep+env['PATH']
r=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),binarySha256=proof['binarySha256'],source=proof['source'],checks=[],limits=['Actual executable stdio and original synthetic image only; no photographed reconstruction, motion solve or pixel-quality claim','No automatic camera binding or ordinary camera-key baking','Android excluded; source-bound CI and remaining issue acceptance separate'])
def save():(out/'exit.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
def checked(name):r['checks'].append(name);save()
class Client:
    def __init__(self,label,read_only=False):
        self.label=label;self.id=0;self.raw=[];self.lines=queue.Queue()
        self.stderr=(out/f'{label}.stderr.log').open('wb')
        command=[str(binary),'--project',str(project),'--mcp']+(['--mcp-read-only'] if read_only else [])
        self.child=subprocess.Popen(command,cwd=work,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr)
        r.update(childPid=self.child.pid,phase=label);save()
        def reader():
            for line in self.child.stdout:self.raw.append(line);self.lines.put(line)
            self.lines.put(None)
        self.thread=threading.Thread(target=reader,daemon=True);self.thread.start()
        self.rpc('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='colmap-original-wire-acceptance',version='1')))
        self.send(dict(jsonrpc='2.0',method='notifications/initialized'))
    def send(self,message):self.child.stdin.write((json.dumps(message)+'\n').encode());self.child.stdin.flush()
    def rpc(self,method,params):
        self.id+=1;expected=self.id
        self.send(dict(jsonrpc='2.0',id=expected,method=method,params=params))
        line=self.lines.get(timeout=45);assert line is not None,'unexpected process EOF'
        reply=json.loads(line);assert reply.get('id')==expected,reply
        assert 'error' not in reply,reply
        return reply['result']
    def tool(self,name,args,error=None):
        value=self.rpc('tools/call',dict(name=name,arguments=args))
        if error:
            assert value.get('isError'),value
            assert error in value['content'][0]['text'],value
            return value
        assert not value.get('isError'),value
        return value['structuredContent']
    def close(self):
        if not self.child.stdin.closed:self.child.stdin.close()
        code=self.child.wait(timeout=30);self.thread.join(timeout=5);self.stderr.close()
        (out/f'{self.label}.stdout.jsonl').write_bytes(b''.join(self.raw))
        assert code==0,(self.label,code)
        for line in self.raw:assert json.loads(line)['jsonrpc']=='2.0'
        return len(self.raw)
save();client=None;began=time.monotonic()
try:
    client=Client('edit')
    tool=next(t for t in client.rpc('tools/list',{})['tools'] if t['name']=='import_tracking')
    assert 'colmap-cameras-images-text-v1' in tool['description'];checked('actual_tool_catalogue_describes_vendor_envelope')
    state=client.tool('motion_state',{})
    used=[a['id'] for key in ['assets','audio_assets','video_assets','model_assets','tracking_assets'] for a in state['project'].get(key,[])]
    asset_id=max(used+[0])+1
    registered=client.tool('command_batch',dict(commands=[dict(op='register_asset',asset=dict(id=asset_id,path='assets/colmap-plate.png',width=8,height=6))],expectedRevision=state['revision']))
    before=client.tool('motion_state',{});client.tool('motion_save',{})
    disk=(project/'project.json').read_bytes()
    def args(path):return dict(path=str(path),source=dict(kind='image',id=asset_id),expectedRevision=before['revision'],expectedDocumentGeneration=before['document_generation'])
    client.tool('import_tracking',args(bad_pose),error='Quaternion')
    assert client.tool('motion_state',{})['project']==before['project'] and (project/'project.json').read_bytes()==disk
    client.tool('import_tracking',args(bad_source),error='content differs')
    assert client.tool('motion_state',{})['project']==before['project'] and (project/'project.json').read_bytes()==disk
    assert not (project/'assets/tracking').exists();checked('actual_nonunit_pose_and_wrong_encoded_source_refuse_without_author_or_disk_publication')
    imported=client.tool('import_tracking',args(good))
    info=imported['trackingImport'];assert info['format']=='colmap_camera_text_v1'
    assert info['encodedSourceVerified'] and info['decodedSourceVerified'] and not info['poseApplied']
    assert imported['revision']==before['revision']+1
    assert imported['project']['camera']==before['project']['camera']
    attachment=imported['project']['tracking_assets'][-1]
    managed=project/attachment['path'];assert managed.read_bytes()==good.read_bytes()
    normalized=attachment['data'];assert normalized['source_pts']==[-3003] and normalized['nominal_rate']==[30000,1001]
    observed=normalized['tracks'][0]['samples'][0]
    assert observed['visibility']=='visible' and observed['confidence']==.8 and not observed['manual_correction']
    geometry=observed['observation'];assert geometry['kind']=='camera'
    actual_position=geometry['camera_to_world']['position']
    assert all(abs(a-b)<1e-12 for a,b in zip(actual_position,[1.1,1.8,2.7]))
    assert geometry['calibration']['radial']==[.01,-.003,0.]
    assert geometry['calibration']['tangential']==[.002,-.001]
    checked('native_import_verifies_plate_preserves_vendor_bytes_exact_clock_and_leaves_camera_authorship_untouched')
    client.tool('import_tracking',args(good),error='superseded')
    undone=client.tool('motion_history',dict(operation='undo'));assert undone['project']==before['project']
    redone=client.tool('motion_history',dict(operation='redo'));assert redone['project']==imported['project']
    client.tool('motion_save',{});good.unlink();assert managed.is_file()
    checked('one_undo_redo_and_saved_original_survive_external_document_removal')
    r['editReplyCount']=client.close();client=None
    log=out/'appdata/MotionStudio/logs/motion-studio.log';logs=log.read_text(encoding='utf-8');(out/'edit.motion-studio.log').write_text(logs,encoding='utf-8')
    stderr=(out/'edit.stderr.log').read_text(encoding='utf-8')
    assert any(' INFO ' in line and 'start #' in line and 'import_tracking' in line for line in logs.splitlines())
    for cause in ['Quaternion','content differs']:
        assert any(' ERROR ' in line and 'tracking import failed' in line and cause in line for line in logs.splitlines())
        assert any('tracking import failed' in line and cause in line for line in stderr.splitlines())
    assert secret not in logs and secret not in stderr
    assert not any(' ERROR ' in line and 'superseded' in line for line in logs.splitlines())
    checked('default_info_start_and_original_error_file_stderr_are_visible_without_payload_leak_or_non_json_stdout')
    client=Client('readonly-reopen',True)
    reopened=client.tool('motion_state',{});assert reopened['project']==imported['project']
    client.tool('import_tracking',args(bad_pose),error='disabled')
    assert managed.read_bytes()==json.dumps(vendor,ensure_ascii=False,indent=2).encode()+b'\n'
    recovered=json.loads(managed.read_bytes());assert recovered['cameras']==cameras and recovered['images']==images
    assert recovered['frames']==vendor['frames'] and recovered['options']==vendor['options']
    r['readonlyReplyCount']=client.close();client=None
    checked('fresh_readonly_process_reopens_normalized_pose_and_exact_original_vendor_text_mapping_and_options')
    assert sha(binary)==proof['binarySha256'] and all(sha(work/n)==h for n,h in proof['source'].items())
    r.update(status='native_stdio_vendor_import_default_channels_history_and_reopen_passed',sourceUnchanged=True)
except BaseException as cause:
    r.update(status='failed_original_outputs_retained',failure=repr(cause));raise
finally:
    if client is not None:
        try:client.close()
        except BaseException as secondary:
            r['cleanupFailure']=repr(secondary)
            if client.child.poll() is None:
                client.child.terminate()
                try:client.child.wait(timeout=10)
                except BaseException as third:r['terminateFailure']=repr(third)
            (out/f'{client.label}.stdout.jsonl').write_bytes(b''.join(client.raw))
    r.update(elapsedSeconds=round(time.monotonic()-began,3),completedUtc=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({k:v for k,v in r.items() if k!='source'},indent=2),flush=True)
