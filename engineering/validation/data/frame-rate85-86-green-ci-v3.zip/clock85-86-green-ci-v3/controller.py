from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess

root=Path('E:/Dev/aem');out=root/'artifacts/pr-queue/clock85-86-green-ci-v3';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='collecting',startedUtc=datetime.now(timezone.utc).isoformat(),prs=[])
save=lambda:(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
try:
    for number,head in [(597,'757f060760301efc9dd0595993ebf78de7072946'),(599,'b38e4275828ffc0377ffe305b2cab05a68032fbe')]:
        metadata=json.loads(subprocess.check_output(['gh','pr','view',str(number),'--json','headRefOid,baseRefName,isDraft,statusCheckRollup'],cwd=root))
        assert metadata['headRefOid']==head
        checks=metadata['statusCheckRollup'];assert all(c['status']=='COMPLETED' and c['conclusion'] in ['SUCCESS','SKIPPED','NEUTRAL'] for c in checks)
        successful=[c for c in checks if c['conclusion']=='SUCCESS'];assert len(successful)==5
        row=dict(number=number,head=head,metadata=metadata,jobs=[]);report['prs'].append(row);save()
        for check in successful:
            run,job=re.search(r'/runs/(\d+)/job/(\d+)',check['detailsUrl']).groups()
            details=json.loads(subprocess.check_output(['gh','api',f'repos/MAD-Producer/Kilonova/actions/jobs/{job}'],cwd=root));assert details['conclusion']=='success'
            prior=root/'artifacts/pr-queue/clock85-86-green-ci-v2'/f'{number}-{job}.log'
            log=prior.read_bytes() if prior.is_file() else subprocess.check_output(['gh','api',f'repos/MAD-Producer/Kilonova/actions/jobs/{job}/logs'],cwd=root)
            name=f'{number}-{job}';(out/(name+'.log')).write_bytes(log)
            (out/(name+'.job.json')).write_text(json.dumps(details,indent=2),encoding='utf-8')
            text=re.sub(r'\x1b\[[0-9;]*m','',log.decode('utf-8',errors='replace'))
            summaries=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)
            assert all(s[0]=='ok' and s[2]=='0' for s in summaries)
            row['jobs'].append(dict(name=check['name'],run=run,job=job,logFile=name+'.log',sha256=hashlib.sha256(log).hexdigest(),bytes=len(log),summaries=summaries,steps=details['steps']))
            save();print(json.dumps(dict(pr=number,check=check['name'],summaries=len(summaries))),flush=True)
    report['status']='five_actual_green_checks_and_original_logs_verified_for_each_recorded_head'
except BaseException as cause:
    report.update(status='failed_retained_outputs',failure=repr(cause));raise
finally:
    report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
