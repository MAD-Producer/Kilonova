"""Correct the new reference's alpha domain; keep production and bounds fixed."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

root=Path('E:/Dev/aem');work=root/'.worktrees/model-exposure'
prior_dir=root/'artifacts/pr-queue/model-exposure-green-v2'
prior=json.loads((prior_dir/'exit.json').read_text(encoding='utf-8'))
native=next(s for s in prior['steps'] if s['name']=='native')
assert native['sourceUnchanged'] and native['exitCode']==101 and native['targets']==14
assert native['totals']==dict(passed=358,failed=1,ignored=0)
prior_text=(prior_dir/'native.stdout.log').read_text(encoding='utf-8')
index=prior_text.index('test exposure::cold_model_receivers_materialize_each_pose_and_keep_earlier_snapshots ... ok')
model_result=re.search(r'test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored;',prior_text[index:])
assert model_result and model_result.groups()==('9','1','0')
assert 'test exposure::model_receiver_shutter_matches_independent_native_sample_average ... FAILED' in prior_text
assert prior_text.count(' ... FAILED')==1
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={p:sha(work/p) for p in prior['source']}
test='crates/motion-render/tests/model_layers/exposure.rs'
assert all(source[p]==h for p,h in prior['source'].items() if p!=test)
old=(prior_dir/'source'/test).read_text(encoding='utf-8');new=(work/test).read_text(encoding='utf-8')
begin='    let expected: Vec<_> = (0..actual.len())'
end='    pixels_within_one(&actual, &expected);'
assert old.count(begin)==new.count(begin)==old.count(end)==new.count(end)==1
assert old.split(begin)[0]==new.split(begin)[0]
assert old.split(end)[1]==new.split(end)[1]
changed=new.split(begin)[1].split(end)[0]
assert 'assert' not in changed and '255.' in changed and '0.04045' in changed and '0.0031308' in changed
assert old.split(begin)[1].split(end)[0]!=changed

out=root/'artifacts/pr-queue/model-exposure-green-v3';out.mkdir(exist_ok=False)
for p in source:
    dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/p,dest)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
receipt=dict(startedUtc=datetime.now(timezone.utc).isoformat(),base=prior['base'],source=source,steps=[],
    referenceCorrection=dict(onlyNewReferenceMathChanged=True,productionSourceUnchanged=True,allAssertionsUnchanged=True,
        reason='PNG read_target returns straight-alpha sRGB; raw RGBA averaging is invalid. Independent linear premultiplied mean then straight-alpha sRGB conversion preserves the original one-byte bound',
        prior=str(prior_dir/'exit.json'),priorSha256=sha(prior_dir/'exit.json')),
    retainedCoverage=dict(passed=native['totals']['passed']-9,failed=0,ignored=0,targets=13,
        scope='The 13 non-model targets already succeeded against these exact production bytes; the model target is rerun in full below, never added twice'))
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-scene87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG',None)
steps=[('native-model',['cargo','test','-p','motion-render','--features','gpu-tests','--test','model_layers','--locked','--offline','--','--test-threads=1']),
    ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'])]
for name,cmd in steps:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as so,(out/(name+'.stderr.log')).open('wb') as se:
        code=subprocess.run(cmd,cwd=work,env=env,stdout=so,stderr=se).returncode
    step=dict(name=name,command=cmd,exitCode=code,sourceUnchanged=all(sha(work/p)==h for p,h in source.items()))
    for stream in ('stdout','stderr'):step[stream+'Sha256']=sha(out/(name+'.'+stream+'.log'))
    if name=='native-model':
        text=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
        matches=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
        assert len(matches)==1
        step['totals']=dict(zip(('passed','failed','ignored'),map(int,matches[0])))
    receipt['steps'].append(step)
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(step),flush=True)
    assert code==0 and step['sourceUnchanged'],name
    if name=='native-model':
        assert step['totals']==dict(passed=10,failed=0,ignored=0)
        for testname in ('cold_model_receivers_materialize_each_pose_and_keep_earlier_snapshots','model_receiver_shutter_matches_independent_native_sample_average'):
            assert 'test exposure::'+testname+' ... ok' in text,testname
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=True,
    acceptedCoverage=dict(passed=receipt['retainedCoverage']['passed']+10,failed=0,ignored=0,targets=14))
assert receipt['acceptedCoverage']==dict(passed=359,failed=0,ignored=0,targets=14)
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,coverage=receipt['acceptedCoverage'])),flush=True)
