"""Real native retained/exposure regression after the reproduced cold-source bug."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

root=Path('E:/Dev/aem');work=root/'.worktrees/model-exposure'
out=root/'artifacts/pr-queue/model-exposure-green-v1';out.mkdir(exist_ok=False)
red=json.loads((root/'artifacts/pr-queue/model-exposure-red-v2/reproduced.json').read_text(encoding='utf-8'))
assert red['expectedRegressionFailure'] and red['gpuExecuted']
paths=('crates/motion-render/src/renderer/layer_raster.rs','crates/motion-render/tests/model_layers.rs','crates/motion-render/tests/model_layers/exposure.rs')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={p:sha(work/p) for p in paths}
assert all(source[p]==red['source'][p] for p in paths[1:]), 'do not change regression assertions to pass'
assert source[paths[0]]!=red['source'][paths[0]]
for p in paths:
    dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/p,dest)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-scene87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG',None)
receipt=dict(source=source,base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),startedUtc=datetime.now(timezone.utc).isoformat(),steps=[],redReproduction=str(root/'artifacts/pr-queue/model-exposure-red-v2/reproduced.json'))
native=['cargo','test','-p','motion-render','--features','gpu-tests','--locked','--offline']
for target in ('model_layers','exposure_frame','exposure_allocation_budget','exposure_accumulation','nested_exposure','exposure_sdr','exposure_scenes'):
    native+=['--test',target]
native+=['--no-fail-fast','--','--test-threads=1']
steps=[('provenance',[sys.executable,'tools/validate_provenance.py']),
    ('panel-style',[sys.executable,'-c',"import runpy; runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
    ('native',native),
    ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'])]
for name,cmd in steps:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as so,(out/(name+'.stderr.log')).open('wb') as se:
        code=subprocess.run(cmd,cwd=work,env=env,stdout=so,stderr=se).returncode
    step=dict(name=name,command=cmd,exitCode=code,sourceUnchanged=all(sha(work/p)==h for p,h in source.items()))
    for stream in ('stdout','stderr'):step[stream+'Sha256']=sha(out/(name+'.'+stream+'.log'))
    if name=='native':
        text=(out/'native.stdout.log').read_text(encoding='utf-8')
        rows=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
        step['totals']=dict(zip(('passed','failed','ignored'),[sum(int(row[i]) for row in rows) for i in range(3)]))
        step['targets']=len(rows)
    receipt['steps'].append(step)
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(step),flush=True)
    assert code==0 and step['sourceUnchanged'],name
    if name=='native':
        assert len(rows)==7 and step['totals']['failed']==step['totals']['ignored']==0
        for test in ('cold_model_receivers_materialize_each_pose_and_keep_earlier_snapshots','model_receiver_shutter_matches_independent_native_sample_average'):
            assert 'test exposure::'+test+' ... ok' in text,test
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=True,regressionAssertionsUnchanged=True)
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,totals=receipt['steps'][2]['totals'])),flush=True)
