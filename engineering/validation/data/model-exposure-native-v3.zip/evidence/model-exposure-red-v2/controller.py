"""Compile regression fixtures, then reproduce against the unchanged parent."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, time

root = Path('E:/Dev/aem')
work = root / '.worktrees/model-exposure'
full = root / 'artifacts/pr-queue/issue87-skin-main-full-v2'
actual = root / 'artifacts/pr-queue/depth-calibration-actual-v3'
out = root / 'artifacts/pr-queue/model-exposure-red-v2'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
target = root / 'target/gltf-scene87-contract'
git = lambda *args: subprocess.check_output(['git', *args], cwd=work).decode().strip()
assert git('rev-parse', 'HEAD') == '9ffe5ea529e0671ccc922d1dba7115521ecd3916'
assert not git('diff', '--name-only', 'HEAD', '--', 'crates/motion-render/src')
source = {p: hashlib.sha256((work / p).read_bytes()).hexdigest() for p in
          ('crates/motion-render/src/renderer/layer_raster.rs',
           'crates/motion-render/tests/model_layers.rs',
           'crates/motion-render/tests/model_layers/exposure.rs')}
for p in source:
    dest = out / 'source' / p
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(work / p, dest)
receipt = dict(startedUtc=datetime.now(timezone.utc).isoformat(), source=source,
               base=git('rev-parse', 'HEAD'), controllerPid=os.getpid(), gpuExecuted=False)
(out / 'started.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
while not (full / 'accepted.json').is_file():
    time.sleep(2)
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
           CARGO_NET_OFFLINE='true', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
env.pop('MOTION_LOG', None)
command = ['cargo', 'test', '-p', 'motion-render', '--features', 'gpu-tests', '--test',
           'model_layers', '--no-run', '--message-format=json', '--locked', '--offline']
with (out / 'build.stdout.log').open('wb') as so, (out / 'build.stderr.log').open('wb') as se:
    build = subprocess.run(command, cwd=work, env=env, stdout=so, stderr=se)
receipt['buildExitCode'] = build.returncode
(out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
assert build.returncode == 0
executables = []
for line in (out / 'build.stdout.log').read_text(encoding='utf-8').splitlines():
    try:
        row = json.loads(line)
    except ValueError:
        continue
    if row.get('reason') == 'compiler-artifact' and row.get('executable') and row['profile']['test']:
        executables.append(row['executable'])
assert len(executables) == 1
receipt.update(state='compiled; waiting for real calibrated inference gate before GPU execution', executable=executables[0])
(out / 'state.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(compiled=True, waitingFor=str(actual / 'accepted.json'))), flush=True)
while not (actual / 'accepted.json').is_file():
    time.sleep(2)
assert all(hashlib.sha256((work / p).read_bytes()).hexdigest() == h for p, h in source.items())
receipt['gpuExecuted'] = True
with (out / 'native.stdout.log').open('wb') as so, (out / 'native.stderr.log').open('wb') as se:
    run = subprocess.run([executables[0], 'exposure::', '--test-threads=1'], cwd=work, env=env, stdout=so, stderr=se)
receipt.update(exitCode=run.returncode, completedUtc=datetime.now(timezone.utc).isoformat())
(out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
text = (out / 'native.stdout.log').read_text(encoding='utf-8')
assert run.returncode == 101, 'regression must fail against the unchanged parent implementation'
assert re.search(r'test result: FAILED\. 0 passed; 2 failed; 0 ignored;', text), text[-2000:]
for test in ('cold_model_receivers_materialize_each_pose_and_keep_earlier_snapshots',
             'model_receiver_shutter_matches_independent_native_sample_average'):
    assert 'test exposure::' + test + ' ... FAILED' in text, test
receipt.update(expectedRegressionFailure=True, sourceUnchanged=True)
(out / 'reproduced.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(reproduced=True, failed=2, unchangedParent=True)), flush=True)
