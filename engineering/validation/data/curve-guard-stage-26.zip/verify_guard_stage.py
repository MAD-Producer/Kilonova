from pathlib import Path
import hashlib, json, os, re, subprocess, sys, time
root=Path('E:/Dev/aem'); work=root/'.worktrees/curve-view-ranges'; out=root/'.tools/curve-view-ranges'
stage=sys.argv[1]; folder=out/('guard-stage-'+stage); folder.mkdir(exist_ok=False)
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','*.rs','*.wgsl','*.toml','Cargo.lock','desktop/ui/styles/dark.json'],cwd=work,text=True).splitlines()
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
sources=freeze(); (work/'desktop/app/src/main.rs').touch()
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1','--no-run']
started=time.monotonic(); print('Frozen desktop readout and Mini guard build started.',flush=True)
with (folder/'build.log').open('w',encoding='utf8') as sink:build=subprocess.run(command,cwd=work,stdout=sink,stderr=subprocess.STDOUT)
runs=[];digest=None
if build.returncode==0:
    binary=Path(re.search(r'Executable unittests[^\n]*\(([^\n]+\.exe)\)',(folder/'build.log').read_text(encoding='utf8')).group(1))
    digest=hashlib.sha256(binary.read_bytes()).hexdigest()
    env=os.environ.copy()
    for key,path in dict(MOTION_CURVE_READOUT_FAULT_ARTIFACTS='readout-default-info',MOTION_MINI_ADAPTIVE_GUARD_ARTIFACTS='mini-guard-default-info',MOTION_CURVE_MINI_FAULT_ARTIFACTS='mini-default-info').items():env[key]=str(folder/path)
    for name,pattern in [('readout','panels::graph_ranges::tests::faults::effect_and_comparison_readout_overflow_reports_the_real_hover_without_poisoning_the_curve'),('mini','panels::animation_controls::'),('effects','panels::effect_timeline::')]:
        began=time.monotonic()
        with (folder/(name+'.log')).open('w',encoding='utf8') as sink:result=subprocess.run([str(binary),pattern,'--nocapture','--test-threads=1'],cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT)
        summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',(folder/(name+'.log')).read_text(encoding='utf8'))
        item=dict(name=name,filter=pattern,exit_code=result.returncode,seconds=round(time.monotonic()-began,2),summary=summaries);runs.append(item);print(json.dumps(item),flush=True)
receipt=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),build_exit_code=build.returncode,command=command,
    sources=sources,source_unchanged=freeze()==sources,binary_sha256=digest,runs=runs,seconds=round(time.monotonic()-started,2),
    scope='Focused real hover readout overflow, Mini frozen geometry and normalized finite boundary tests, existing Mini/effect regressions. Not full portable/native/current-main or issue259 completion proof.')
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['sources','command']}),flush=True)
raise SystemExit(0 if build.returncode==0 and len(runs)==3 and all(x['exit_code']==0 for x in runs) and receipt['source_unchanged'] else 1)
