from pathlib import Path
import hashlib, json, os, re, subprocess, sys, time
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges';out=root/'.tools/curve-view-ranges'
attempt,reference=sys.argv[1:3];folder=out/('app-stage-'+attempt);folder.mkdir(exist_ok=False)
guard=out/('guard-stage-'+reference);built=json.loads((guard/'receipt.json').read_text(encoding='utf8'))
assert built['build_exit_code']==0 and built['source_unchanged'] and all(x['exit_code']==0 for x in built['runs'])
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','*.rs','*.wgsl','*.toml','Cargo.lock','desktop/ui/styles/dark.json'],cwd=work,text=True).splitlines()
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
sources=freeze();assert sources==built['sources'],'Cannot reuse a binary after source changed'
binary=Path(re.search(r'Executable unittests[^\n]*\(([^\n]+\.exe)\)',(guard/'build.log').read_text(encoding='utf8')).group(1))
assert hashlib.sha256(binary.read_bytes()).hexdigest()==built['binary_sha256'],'Compiled binary replaced'
env=os.environ.copy()
for key,name in dict(MOTION_CURVE_MINI_FAULT_ARTIFACTS='mini-default-info',MOTION_CURVE_RANGE_FAULT_ARTIFACTS='range-default-info',MOTION_CURVE_READOUT_FAULT_ARTIFACTS='readout-default-info',MOTION_MINI_ADAPTIVE_GUARD_ARTIFACTS='mini-guard-default-info').items():env[key]=str(folder/name)
targets=[('adaptive','panels::graph_adaptive::'),('sampling','panels::graph_sampling::'),('timeline','panels::timeline_shortcuts_tests::'),('handles','panels::graph_handles::'),('ranges','panels::graph_ranges::'),('axes','panels::graph_view::'),('effects','panels::effect_timeline::'),('comparison','panels::curve_comparison::'),('mini','panels::animation_controls::')]
started=time.monotonic();runs=[]
for name,pattern in targets:
    began=time.monotonic()
    with (folder/(name+'.log')).open('w',encoding='utf8') as sink:result=subprocess.run([str(binary),pattern,'--nocapture','--test-threads=1'],cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT)
    summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',(folder/(name+'.log')).read_text(encoding='utf8'))
    item=dict(name=name,filter=pattern,exit_code=result.returncode,seconds=round(time.monotonic()-began,2),summary=summaries);runs.append(item);print(json.dumps(item),flush=True)
receipt=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),build_exit_code=0,
    build_reused_from=str(guard/'receipt.json'),build_command=built['command'],sources=sources,source_unchanged=freeze()==sources,
    binary_sha256=built['binary_sha256'],runs=runs,seconds=round(time.monotonic()-started,2),
    scope='Full nine portable graph/Mini/timeline/effect suites using the exact already-compiled current-source binary; source set, all hashes and binary digest checked before reuse. Does not claim native/main integration/PR acceptance complete.')
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['sources','build_command']}),flush=True)
raise SystemExit(0 if len(runs)==9 and all(x['exit_code']==0 for x in runs) and receipt['source_unchanged'] else 1)
