from pathlib import Path
import hashlib, json, re, subprocess, sys, zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges';out=root/'.tools/curve-view-ranges'
stage=sys.argv[1];folder=out/('app-stage-'+stage)
r=json.loads((folder/'receipt.json').read_text(encoding='utf8'))
assert r['build_exit_code']==0 and r['source_unchanged'] and len(r['runs'])==9
assert all(run['exit_code']==0 and run['summary'][-1][0]=='ok' and run['summary'][-1][2]=='0' for run in r['runs'])
assert all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in r['sources'].items())
counts={run['name']:int(run['summary'][-1][1]) for run in r['runs']}
assert sum(counts.values())==136 and counts['ranges']==24 and counts['mini']==12
specs=[('range-default-info',12),('mini-default-info',4),('readout-default-info',2),('mini-guard-default-info',1)]
verified=set();evidence=[]
for family,expected in specs:
    for process in ['first-process','reset-process']:
        child=folder/family/process
        result=json.loads((child/'result.json').read_text(encoding='utf8'))
        sites=result['sites'];assert len(sites)==expected
        stderr=(child/'stderr.log').read_text(encoding='utf8').splitlines()
        stdout=(child/'stdout.log').read_text(encoding='utf8')
        file=(child/'motion-studio.log').read_text(encoding='utf8')
        assert len(stderr)==expected and all('ERROR' in line for line in stderr)
        assert 'panel degradation' not in stdout and 'ERROR' not in stdout
        for site in sites:
            lines=[line for line in file.splitlines() if f'site={site} ' in line]
            assert len(lines)==2 and 'WARN' in lines[0] and 'count=1 ' in lines[0]
            assert 'ERROR' in lines[1] and 'count=60 ' in lines[1]
            assert all('generation=Some(1)' in line and 'revision=Some(' in line for line in lines),(site,lines)
            assert sum(f'site={site} ' in line for line in stderr)==1
        verified.update(sites)
        if family=='mini-guard-default-info':
            assert result['validEasingCases']==22 and result['finiteNormalizedSamples']==22550
            assert result['validActualHoverQuiet'] and result['malformedEasingRejectedBeforeHover']
            assert 'site=curve.mini.normalized_readout ' not in file
        evidence.append(dict(family=family,process=process,result=result))
assert len(verified)==19
guarded={'curve.mini.normalized_readout'}
inventory_path=out/'graph-observation-inventory.json'
inventory=json.loads(inventory_path.read_text(encoding='utf8'))
for item in inventory['sites']:
    source=(work/item['path']).read_text(encoding='utf8')
    match=re.search(r'observe!\(\s*"'+re.escape(item['site'])+r'"',source);assert match
    item['line']=source[:match.start()].count('\n')+1
    if item['site'] in verified:item['disposition']='new observation: actual default channels and generation/revision context verified'
    elif item['site'] in guarded:item['disposition']='guarded boundary: valid finite normalized Core samples; actual healthy hover and malformed-fit preemption verified; no injected guard failure claimed'
all_new={x['site'] for x in inventory['sites'] if x['new_in_issue259']}
assert all_new==verified|guarded
inventory.update(head=r['head'],verified_new_sites=sorted(verified),guarded_new_sites=sorted(guarded),pending_new_sites=[],
    limits='19 new sites have actual default-channel failure evidence. One normalized-readout guard has a source-derived finite-domain disposition plus actual healthy/preempted evidence; it is not counted as an injected failure or a fixed defect. Full issue259/performance/native final-main/PR acceptance remains incomplete.')
inventory_path.write_text(json.dumps(inventory,indent=2),encoding='utf8')
failed=json.loads((out/'guard-stage-24/receipt.json').read_text(encoding='utf8'))
focused=json.loads((out/'guard-stage-25/receipt.json').read_text(encoding='utf8'))
assert failed['build_exit_code']==0 and failed['runs'][0]['exit_code']!=0
assert all(x['exit_code']==0 for x in focused['runs']) and focused['binary_sha256']==r['binary_sha256']
failure=(out/'guard-stage-24/readout-default-info/first-process/stderr.log').read_text(encoding='utf8')
assert 'left: 0' in failure and 'right: 1' in failure
base=subprocess.check_output(['git','merge-base','HEAD','origin/main'],cwd=work,text=True).strip()
files={p.relative_to(out).as_posix():p for directory in ['guard-stage-24','guard-stage-25','app-stage-'+stage]
       for p in (out/directory).rglob('*') if p.is_file()}
for name in ['verify_guard_stage.py','verify_full_from_guard.py','record_guard_completion_stage.py','graph-observation-inventory.json']:
    files[name]=out/name
manifest={name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for name,p in files.items()}
archive=work/('engineering/validation/data/curve-guard-stage-'+stage+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(files.items()):z.write(p,name)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
receipt=dict(head=r['head'],compiled_base_main=base,binary_sha256=r['binary_sha256'],source_unchanged=True,
    portable_passed=136,portable_ignored=1,counts=counts,verified_new_sites=sorted(verified),
    guarded_new_sites=sorted(guarded),pending_new_sites=[],evidence=evidence,
    archive=dict(path='data/'+archive.name,bytes=archive.stat().st_size,entries=len(files)+1,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),
    remaining=['Performance including actual Info/native counters and current baseline comparison',
        'Final formatting/all-targets/latest-main integration and native revalidation',
        'Full DESIGN12 disposition, own259 PR and all five current-composed-tree CI gates; do not close259 yet'])
(work/'engineering/validation/curve-guard-progress-results.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
prior=(work/'engineering/validation/curve-range-faults-progress.md').read_text(encoding='utf8')
baseline=prior[prior.index('| 基线 |'):prior.index('性能、最终格式')].strip()
doc=f'''# 曲线读数与防御边界验证（#259，仍未完成）

接续[十二处故障阶段](curve-range-faults-progress.md)。编译源码 `{r['head']}`，合并基线 `{base}`，二进制 SHA-256 `{r['binary_sha256']}`。Guard25实际编译并通过29项定向用例；App{stage}逐文件/文件集合/二进制哈希核对后复用这份完全相同的编译产物，运行九组完整filter，136项通过、1项原生明确ignored。没有为同一源码无故重复编译，也没有把ignored或旧原生截图重标成当前验收。

## 功能修正与日志补充分别说明

效果图的悬停入口此前只处理Err；真实速度采样可以返回Ok(∞)。短composition视口的曲线采样被末帧截断，而鼠标悬停可落在其后尚可见的 authored interval；一个fps1e308的退化provider快照即可使实际导数转f32时溢出。旧入口没有报告失败，仍把非有限数值交给读数绘制。新增检查只在悬停读数入口拒绝非有限结果并进入既有observe，不改Core sampler、参数值、曲线采样语义或历史。原始Err通过and_then原样保留，原16项效果回归（包括原NonFinite及原始错误断言）全部通过。

Guard24先运行原入口，新回归在首次故障期望的1条记录处得到0条而失败；Mini12项和效果16项仍通过。Guard25补上述有限值检查后同一回归通过。保留真实失败日志，不修改旧断言或把失败改为ignore。该案例明确是非法fps/缩短composition的退化provider边界，不声称合法保存工程会生成此快照。

独立的日志改动为普通/效果/对比图全部14个新增站点补document generation和revision。完整App{stage}验证原12站点、新2读数站点均实际输出这些上下文，同时保留phase、对象/效果/参数或单位组、原始原因及已有耗时。其他Mini站点原本已有这两个字段。健康Present绘制仍不新增日志、文件IO或start/done记录。

## 最后四个观察站点的精确处置

| 站点 | 证据与结论 |
|---|---|
| effect.graph_readout | 真实效果图悬停、Core物理导数的f32溢出，19个实际故障站点之一；不改变原采样失败返回 |
| curve.comparison.readout | 同一真实效果轨道加入对比图；可用曲线和悬停失败同时存在，恢复fps后恢复健康读数 |
| curve.mini.adaptive | View::draw接受的正有限冻结Y范围0..1e-310导致pixels/unit溢出，实际adaptive拒绝；重复几何负缓存，恢复普通范围后重新采样；是注入的表示层快照，不声称普通滚轮能产生 |
| curve.mini.normalized_readout | **防御边界处置**，不是新复现/修复缺陷。依据以下有限域约束、22个边界合法Easing/22550次实际Core采样、实际健康悬停及畸形数据在fit阶段被先行拒绝；没有伪造一个不可能的错误回调来冒算覆盖 |

读数2站点、Mini adaptive1站点均在两个独立子进程中验证首次Warn、第59次仍仅Warn、第60次Error、第120次抑制，Error只再复制到stderr，Warn仅文件，stdout无诊断。穿插健康调用不重置既有process-lifetime Counter；新进程重新计数。Mini adaptive同一失败范围额外重复120帧，仍只有第一次观察；变化/恢复时按实际几何重新采样。所有步骤不改作者数据或undo/redo。

## normalized_readout有限域依据与限制

核对生产`mini.rs`的View::draw：读数仅在time属于闭区间0..1、automatic成功、无冻结/菜单时运行。核对`crates/motion-model/src/curve.rs`：无Curve的五种Ease将t夹在0..1；Bezier控制X在0..1、Y及端点绝对值≤8，progress端点固定0/1，逆解最多24步并把非有限Newton候选退回有界二分，u保持0..1，因此多项式系数及求值有限。Velocity Bezier area绝对值≥0.05，definition_scale与归一化定义的除法不除零；系数和积分均有界。Progress速度另有现存分母下界/±1e6上限，但该progress模式读数使用progress。

Elastic的w=2π·oscillations，oscillations属于0.5..8、damping属于0.5..20。归一化分母是`1-exp(-d)*(cos(w)+(d/w)*sin(w))`；绝对振幅不超过`exp(-d)*sqrt(1+(d/π)^2)`，在d≥0.5单调递减，最大值<0.615，故分母>0.385。所有三角、指数、系数及归一化结果有限。Velocity Elastic的definition_scale保留1，结论同样成立。

这些是当前有效模型契约的源码依据。22例/22550样本不是对全部浮点输入的穷举；畸形Easing用NaN控制点实际先在fit被拒绝，不声称覆盖所有未来契约变化、任意坏provider或新CurveShape。保留normalized_readout的观察作为防御，不计为实际错误注入通过，不删除检查、不吞错误。

合计：新增20站点中19站点取得真实默认故障信道证据，1站点有上述防御边界处置；不称20个缺陷被修复。既有站点只算回归证据。精确ID/位置/处置在ZIP内inventory；每个实际站点均核对generation/revision、Error stderr/file及stdout隔离。原Counter有界进程生命周期范围保持不变，60是次数不是时长。

## DESIGN §0.7逐项责任边界

没有增加依赖、资产、token、属性行或UI颜色/尺寸；仅一个非法读数的显示边界功能修正，另有故障上下文和测试改动。以下既有12处逐项保留，不冒称整改完成。

{baseline}

性能、最终格式/all-targets/最新main组合、最终原生复验、完整DESIGN12处置及自身PR/CI仍待完成；本阶段不关闭#259。当前编译仍是72d基线，不能代替已更新main的组合验证。

[结构化结果](curve-guard-progress-results.json) · [原始证据包]({receipt['archive']['path']})：{receipt['archive']['entries']}项/{receipt['archive']['bytes']}字节，SHA-256 `{receipt['archive']['sha256']}`。
'''
(work/'engineering/validation/curve-guard-progress.md').write_text(doc,encoding='utf8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['evidence']},ensure_ascii=False))
