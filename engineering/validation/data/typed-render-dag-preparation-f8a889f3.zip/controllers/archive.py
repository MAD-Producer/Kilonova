"""Verify retained initial effect-preparation source and actual regression logs."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile
ROOT=Path('E:/Dev/aem'); WORK=ROOT/'.worktrees/render-dag'
label=sys.argv[1]; assert re.fullmatch(r'preparation-v[0-9]+',label)
out=ROOT/'artifacts/pr-queue'/('issue78-numeric-'+label)
accepted=json.loads((out/'accepted.json').read_text())
sha=lambda data:hashlib.sha256(data).hexdigest()
def source():
 names=set()
 for args in [('diff','--name-only','-z','302a15bfb0a69b52df89c69da63bd7bbd25e3e1e'),('ls-files','--others','--exclude-standard','-z')]:
  names.update(p.decode() for p in subprocess.check_output(['git',*args],cwd=WORK).split(b'\0') if p)
 return {p:sha((WORK/p).read_bytes()) for p in sorted(names) if (WORK/p).is_file() and (p.endswith('.rs') or p.endswith('Cargo.toml') or p=='Cargo.lock')}
assert accepted['sourceUnchanged'] and source()==accepted['source']
assert [s['name'] for s in accepted['steps']]==['render-preparation','render-ir','desktop-check','render-library','render-native','ir-default-output','private-numeric']
for s in accepted['steps']:
 assert s['sourceUnchanged'] and s['exitCode']==0
 for stream in ['stdout','stderr']:
  assert sha((out/s['name']/(stream+'.log')).read_bytes())==s[stream+'Sha256']
 if s.get('totals'):assert s['totals']['failed']==s['totals']['ignored']==0
# Focused preparation tests and the earlier IR scope also belong to the complete library
# scope, so count each test only once.
distinct=sum(s['totals']['passed'] for s in accepted['steps'] if s['name'] in ['render-library','render-native','ir-default-output','private-numeric'])
companion=ROOT/'artifacts/pr-queue/issue78-numeric-preparation-v3'
precision=json.loads((companion/'accepted.json').read_text())
assert precision['source']==accepted['source'] and precision['sourceUnchanged']
assert len(precision['steps'])==1 and precision['steps'][0]['name']=='private-precision'
for step in precision['steps']:
 assert step['exitCode']==0 and step['totals']['failed']==step['totals']['ignored']==0
 for stream in ['stdout','stderr']:
  assert sha((companion/step['name']/(stream+'.log')).read_bytes())==step[stream+'Sha256']
distinct+=precision['steps'][0]['totals']['passed']
private=json.loads((companion/'output-artifacts/private-instance-four-precision.json').read_text())
assert len(private['updates'])==16 and len(private['cases'])==8
fault=out/'output-artifacts/default-ir-faults'
receipt=json.loads((fault/'receipt.json').read_text())
assert receipt['recoveries']==6 and receipt['same_renderer'] and receipt['healthy_pixels_equal']
assert receipt['pipeline_builds_added']==0 and len(receipt['failures'])==6
for path,count in [('logs/motion-studio.log',6),('stderr.log',6),('stdout.log',0)]:
 text=(fault/path).read_text()
 assert sum('error #' in line and 'phase=effect_ir_check' in line for line in text.splitlines())==count
files={};attempts=[]
for folder in sorted((ROOT/'artifacts/pr-queue').glob('issue78-numeric-preparation-v*')):
 receipt=json.loads((folder/'exit.json').read_text());success=(folder/'accepted.json').exists()
 assert success or receipt['steps'][-1]['exitCode']!=0
 assert all(s['sourceUnchanged'] for s in receipt['steps'])
 attempts.append(dict(label=folder.name,accepted=success,lastExitCode=receipt['steps'][-1]['exitCode']))
 for path in sorted(folder.rglob('*')):
  if path.is_file() and path.name!='archive-verification.json':
   files['attempts/'+folder.name+'/'+path.relative_to(folder).as_posix()]=path.read_bytes()
files['controllers/archive.py']=Path(__file__).read_bytes()
files['patch/tracked.patch']=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=WORK)
assert not subprocess.check_output(['git','diff','--name-only',accepted['head'],'--','desktop/app/src/panels','android'],cwd=WORK).strip()
subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--check','crates/motion-render/src/effect_plan/preparation.rs','crates/motion-render/src/effect_plan/preparation/tests.rs'],cwd=WORK,check=True,capture_output=True)
manifest=dict(head=accepted['head'],source=accepted['source'],distinctPasses=distinct,attempts=attempts,
 scope='Sampled parameter/private-layout validation and typed image-input bindings drive native lowering; cycle refusal precedes vector/mask/generator CPU work; targeted checkpoint, not G',
 limitations=['Full typed producer/value/ROI ownership before native proposals and typed package/LUT/mask/private imports remain pending','Mask/generator preparation remains serial','No speedup, process RSS or GPU driver peak measurement is established','Final integrated cross-platform desktop CI remains pending','Android implementation and acceptance excluded'],
 files={p:sha(data) for p,data in sorted(files.items())})
archive=WORK/'engineering/validation/data/typed-render-dag-preparation-f8a889f3.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)|{'manifest.json'}
 assert all(sha(z.read(name))==digest for name,digest in manifest['files'].items())
assert source()==accepted['source']
proof=dict(archive=str(archive),sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,files=len(files),sourcesVerified=len(accepted['source']),distinctPasses=distinct)
(out/'archive-verification.json').write_text(json.dumps(proof,indent=2))
print(json.dumps(proof))
