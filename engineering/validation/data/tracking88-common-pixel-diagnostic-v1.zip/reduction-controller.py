"""Independent scalar reduction; raw image/annotation/per-frame payloads stay local."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import statistics
import zipfile

root = Path('E:/Dev/aem')
art = root / 'artifacts/pr-queue'
actual = art / 'tracking88-common-pixel-diagnostic-v1'
out = art / 'tracking88-common-pixel-public-v1'
receipt_path = actual / 'receipt.json'
receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
assert receipt['status'] == 'paired_common_pixel_observation_complete_not_tracking_acceptance'
assert receipt['source_and_inputs_unchanged'] is True
assert receipt['measured_frames'] == 30 and receipt['missing_measurement_frames'] == 0
assert receipt['original_full_quality'] == dict(automatic_visible=915, automatic_lost=1373,
    above_original_15px=21, maximum_pixels=56.6400304460409)
rows = receipt['rows']
assert [row['source_index'] for row in rows] == list(range(1801, 1831))
groups = {}
for name, selected in (
    ('all30_selected_frames', rows),
    ('original_above15px', [row for row in rows if row['original_corner_max_pixels'] > 15]),
    ('original_at_or_below15px', [row for row in rows if row['original_corner_max_pixels'] <= 15]),
):
    group = dict(frames=len(selected), methods={})
    for method in ('raw', 'existing_filtered'):
        predicted, annotated = [], []
        for row in selected:
            comparison = row['comparisons'][method]
            assert comparison['predicted']['count'] == comparison['annotated_homography']['count'] == row['common_template_pixels']
            predicted.append(comparison['predicted']['mae'])
            annotated.append(comparison['annotated_homography']['mae'])
        group['methods'][method] = dict(equal_frame_mean_mae_predicted=statistics.mean(predicted),
            equal_frame_mean_mae_annotated_homography=statistics.mean(annotated),
            predicted_lower_mae_frames=sum(a < b for a, b in zip(predicted, annotated)))
    groups[name] = group
assert groups['original_above15px']['frames'] == 21
assert groups['original_at_or_below15px']['frames'] == 9
summary = dict(status='paired_image_disagreement_confirmed_not_a_quality_fix',
    source_head=receipt['source_head'], controller_sha256=receipt['controller_sha256'],
    private_receipt_sha256=hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
    input_sha256=receipt['input_sha256'], source_sha256=receipt['source_sha256'],
    decode_command=receipt['decode_command'], decoder_sha256=receipt['decoder_sha256'],
    decoded_grayscale_sha256=receipt['decoded_grayscale_sha256'],
    protocol=receipt['protocol'], authored_controls=receipt['authored_controls'],
    original_full_quality=receipt['original_full_quality'],
    selected_frames=30, measured_frames=30, missing_measurement_frames=0,
    enrolled_template_pixels=receipt['enrolled_template_pixels'],
    per_frame_common_pixel_count_min=min(row['common_template_pixels'] for row in rows),
    per_frame_common_pixel_count_max=max(row['common_template_pixels'] for row in rows),
    aggregate_weighting='Equal weight per measured frame, raw 0..255 grayscale absolute intensity error; no gain/bias fit or residual trimming',
    groups=groups,
    representative_first_frame=dict(source_index=rows[0]['source_index'],
        common_template_pixels=rows[0]['common_template_pixels'],
        original_corner_max_pixels=rows[0]['original_corner_max_pixels'], comparisons=rows[0]['comparisons']),
    source_and_inputs_unchanged=True, elapsed_seconds=receipt['elapsed_seconds'],
    limits=receipt['limits'] + ['Only aggregate/representative scalar evidence distributed; full per-frame receipt remains local'])
out.mkdir(exist_ok=False)
(out / 'observation-controller.py').write_bytes((actual / 'controller.py').read_bytes())
(out / 'reduction-controller.py').write_bytes(Path(__file__).read_bytes())
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
members = {}
for path in sorted(out.iterdir()):
    members[path.name] = dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
archive = out / 'tracking88-common-pixel-diagnostic-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
    for name in members:
        target.write(out / name, name)
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(members)
    for name, expected in members.items():
        data = target.read(name)
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
manifest = dict(archive=archive.name, bytes=archive.stat().st_size,
    sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), members=members,
    readback='Every member CRC, length and SHA-256 verified')
(out / 'tracking88-common-pixel-diagnostic-v1.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
marker = actual / 'command-consumed.json'
assert not marker.exists()
consumed = dict(consumed=True, original_transport='exec_command', original_chunk_id='481638',
    original_exit_code=0, session_created=False, source_and_inputs_unchanged=True,
    observed_utc=datetime.now(timezone.utc).isoformat(),
    status=receipt['status'])
marker.write_text(json.dumps(consumed, indent=2) + '\n', encoding='utf-8')
checkpoint = art / 'depth75-resume-current.json'
state = json.loads(checkpoint.read_text(encoding='utf-8-sig'))
state['versionedCache75'].update(activeController=None, ownHeavyWorkloads=[])
state['commonPixelTracker88'] = dict(status=summary['status'], originalConsumed=consumed,
    publicArchive=str(archive), archiveSha256=manifest['sha256'],
    privateReceipt=str(receipt_path), originalAbove15px=21, qualityFixed=False)
state['updatedUtc'] = consumed['observed_utc']
checkpoint.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status=summary['status'], groups=groups,
    common_pixel_min=summary['per_frame_common_pixel_count_min'], common_pixel_max=summary['per_frame_common_pixel_count_max'],
    archive_bytes=manifest['bytes'], archive_sha256=manifest['sha256'])))
