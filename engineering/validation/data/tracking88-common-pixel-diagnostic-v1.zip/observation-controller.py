"""Paired image evidence on identical template pixels; never a tracking-quality waiver."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import logging
import os
import subprocess
import sys
import time
import traceback
import zipfile

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/planar-tracker88'
OUT = ART / 'tracking88-common-pixel-diagnostic-v1'
INPUTS = {
    ART / 'tracking88-real-planar-acquisition-v1/phone.avi': 'c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9',
    ART / 'tracking88-real-planar-acquisition-v1/phone-gt.zip': 'd4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886',
    ART / 'tracking88-photographed-prototype-v6/periodic-manual-200/tracks.mstrack': '5dd567b7f1ec994a4120700fe529abdf97fdc27ffd7c10f327751ab91bc68dfa',
    ART / 'tracking88-photographed-prototype-v6/periodic-manual-200.request.json': 'f88e3951fbaa5a0a1fabf527b85de75826905857ad3ca590da9367f4ad9c2191',
}
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for path, expected in INPUTS.items():
    assert sha(path) == expected
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == 'd245edec44959b733a34fef635263edd7a5d00cb'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
checkpoint = ART / 'depth75-resume-current.json'
state = json.loads(checkpoint.read_text(encoding='utf-8-sig'))
assert state['versionedCache75']['activeController'] is None
assert not state['versionedCache75']['ownHeavyWorkloads']
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
os.environ.update(TEMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'),
    TMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'),
    LOCALAPPDATA=str(OUT / 'appdata'), OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
(OUT / 'appdata').mkdir()
logger = logging.getLogger('tracking88.common_pixels')
logger.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
file_handler = logging.FileHandler(OUT / 'observation.log', encoding='utf-8')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)
error_handler = logging.StreamHandler(sys.stderr)
error_handler.setLevel(logging.ERROR)
error_handler.setFormatter(formatter)
logger.addHandler(error_handler)
source_names = ['plate_flow.py', 'plate_contract.py', 'track_plate.py']
source_hashes = {name: sha(WORK / 'tools/tracking' / name) for name in source_names}
report = dict(status='running', started_utc=datetime.now(timezone.utc).isoformat(),
    input_sha256={str(path): digest for path, digest in INPUTS.items()},
    source_head='d245edec44959b733a34fef635263edd7a5d00cb', source_sha256=source_hashes,
    controller_sha256=sha(OUT / 'controller.py'), selected_source_indices=list(range(1801, 1831)),
    template_source_index=1800, rows=[], in_flight=None,
    protocol=dict(common_population='All integer pixels in the projected original ROI with full support under both hypotheses',
        boundary_margin=3, pixel_sampling='Independent float64 bilinear, identical common template pixel IDs',
        observations=['raw grayscale', 'fixed existing5x5 sigma1 grayscale'],
        intensity_fit=False, photometric_trimming=False, selection='Previously diagnosed30-frame segment, diagnostic only'),
    limits=['No tracker execution, candidate, source/ROI/annotation/output edit or original threshold change',
        'Full2300-frame original15px gate remains authoritative including missing/offscreen observations',
        'Image agreement does not establish target identity, rigidity, label correctness or a quality fix',
        'Per-frame common visibility is reported; missing pixels are not zero error',
        'One owned CV workload, no foreign process changes or third-party acquisition'])
state['versionedCache75'].update(activeController=str(Path(__file__)), ownHeavyWorkloads=[dict(
    kind='paired common-template-pixel CV diagnostic', output=str(OUT), sourceFrozen=True)])
checkpoint.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
began = time.monotonic()
def save():
    pending = OUT / 'receipt.pending.json'
    pending.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    os.replace(pending, OUT / 'receipt.json')
def start(request, operation):
    report['in_flight'] = dict(request=request, operation=operation,
        started_utc=datetime.now(timezone.utc).isoformat())
    save()
    logger.info('start #%s %s', request, operation)
    file_handler.flush()
try:
    start(0, 'import_existing_cv_runtime')
    import cv2
    import numpy as np
    cv2.setNumThreads(1)
    def project(matrix, points):
        value = np.column_stack((points, np.ones(len(points)))) @ matrix.T
        valid = np.isfinite(value).all(axis=1) & (np.abs(value[:, 2]) > 1e-10)
        result = np.full((len(points), 2), np.nan)
        result[valid] = value[valid, :2] / value[valid, 2, None]
        return result, valid
    def supported(points, width, height, margin=3):
        return np.isfinite(points).all(axis=1) & (points[:, 0] >= margin) & (points[:, 1] >= margin) & (points[:, 0] < width - margin) & (points[:, 1] < height - margin)
    def sample(image, points):
        assert supported(points, image.shape[1], image.shape[0], 0).all()
        x, y = points[:, 0], points[:, 1]
        ix, iy = np.floor(x).astype(int), np.floor(y).astype(int)
        assert (ix + 1 < image.shape[1]).all() and (iy + 1 < image.shape[0]).all()
        fx, fy = x - ix, y - iy
        return ((1 - fx) * (1 - fy) * image[iy, ix] + fx * (1 - fy) * image[iy, ix + 1]
            + (1 - fx) * fy * image[iy + 1, ix] + fx * fy * image[iy + 1, ix + 1])
    def metrics(errors):
        assert len(errors) > 0 and np.isfinite(errors).all()
        return dict(count=len(errors), mae=float(np.mean(np.abs(errors))),
            rms=float(np.sqrt(np.mean(errors * errors))), median_absolute=float(np.median(np.abs(errors))),
            maximum_absolute=float(np.max(np.abs(errors))))
    start(1, 'authored_bilinear_population_and_transform_controls')
    gy, gx = np.mgrid[:16, :20]
    linear = 3.0 * gx + 2.0 * gy + 1.0
    points = np.array([[4.25, 3.5], [8.75, 7.125], [12.5, 10.75]])
    assert np.max(np.abs(sample(linear, points) - (3 * points[:, 0] + 2 * points[:, 1] + 1))) < 1e-10
    translation = np.array([[1., 0., 2.], [0., 1., 1.], [0., 0., 1.]])
    moved, valid = project(translation, points)
    assert valid.all()
    shifted = 3.0 * (gx - 2) + 2.0 * (gy - 1) + 1
    source_values = sample(linear, points)
    assert np.max(np.abs(sample(shifted, moved) - source_values)) < 1e-10
    assert np.max(np.abs(np.abs(sample(shifted, points) - source_values) - 8.0)) < 1e-10
    boundary = np.array([[0., 3.], [3., 3.], [16.999, 12.999], [17., 13.]])
    assert supported(boundary, 20, 16).tolist() == [False, True, True, False]
    report['authored_controls'] = dict(bilinear_linear_ramp=True, independent_known_translation=True,
        deliberately_wrong_warp_error=8.0, boundary_mask=True)
    paths = list(INPUTS)
    video, truth_path, track_path, request_path = paths
    asset = json.loads(track_path.read_text(encoding='utf-8'))
    request = json.loads(request_path.read_text(encoding='utf-8'))
    assert asset['source_pts'] == list(range(2300))
    samples = next(track for track in asset['tracks'] if track['id'] == 'plane')['samples']
    seed = next(track for track in request['tracks'] if track['id'] == 'plane')
    assert seed['roi'] == [160, 180, 340, 210]
    edit = next(edit for edit in request['corrections'] if edit['track'] == 'plane' and edit['source_index'] == 1800)
    manual = np.asarray(edit['observation']['matrix'], np.float64)
    ffmpeg = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
    command = [str(ffmpeg), '-v', 'error', '-nostdin', '-threads', '1', '-noautorotate', '-copyts',
        '-i', str(video), '-map', '0:0', '-an', '-sn', '-dn', '-vf', r'select=between(n\,1800\,1830)',
        '-fps_mode', 'passthrough', '-threads', '1', '-f', 'rawvideo', '-pix_fmt', 'gray', 'pipe:1']
    report.update(decode_command=command, decoder_sha256=sha(ffmpeg))
    start(2, 'decode_original_contiguous_reference_and_thirty_images')
    with (OUT / 'decode.stderr.log').open('wb') as stderr:
        decoded = subprocess.run(command, stdout=subprocess.PIPE, stderr=stderr, check=True, timeout=60)
    assert len(decoded.stdout) == 31 * 640 * 480
    report['decoded_grayscale_sha256'] = hashlib.sha256(decoded.stdout).hexdigest()
    images = np.frombuffer(decoded.stdout, np.uint8).reshape(31, 480, 640)
    with zipfile.ZipFile(truth_path) as archive:
        truth = []
        for index in range(2300):
            values = np.array([float(v) for v in archive.read(f'img_{index + 200:05d}.txt').decode('ascii').split()]).reshape(2, 4)
            truth.append(np.column_stack((values[1] - 1, values[0] - 1)))
    anchor, valid = project(manual, truth[0])
    assert valid.all() and float(np.linalg.norm(anchor - truth[1800], axis=1).max()) < 1e-3
    errors = []
    lost = 0
    for index, observation in enumerate(samples):
        if index == 0 or observation['manual_correction']:
            continue
        if observation['visibility'] != 'visible':
            lost += 1
            continue
        projected, valid = project(np.asarray(observation['observation']['matrix']), truth[0])
        assert valid.all()
        errors.append((index, float(np.linalg.norm(projected - truth[index], axis=1).max())))
    report['original_full_quality'] = dict(automatic_visible=len(errors), automatic_lost=lost,
        above_original_15px=sum(error > 15 for _, error in errors), maximum_pixels=max(error for _, error in errors))
    assert len(errors) == 915 and lost == 1373 and report['original_full_quality']['above_original_15px'] == 21
    gy, gx = np.mgrid[:480, :640]
    grid = np.column_stack((gx.ravel(), gy.ravel())).astype(np.float64)
    canonical, finite = project(np.linalg.inv(manual), grid)
    mask = (finite & supported(grid, 640, 480) & (canonical[:, 0] >= 160) & (canonical[:, 0] <= 500)
        & (canonical[:, 1] >= 180) & (canonical[:, 1] <= 390))
    template = grid[mask]
    template_ids = np.flatnonzero(mask)
    assert len(template) > 0
    report['enrolled_template_pixels'] = len(template)
    reference_raw = images[0].astype(np.float64)
    reference_filtered = cv2.GaussianBlur(images[0], (5, 5), 1.0).astype(np.float64)
    error_by_index = dict(errors)
    for offset in range(1, 31):
        index = 1800 + offset
        start(index, 'paired_same_template_pixel_hypotheses')
        observation = samples[index]
        row = dict(source_index=index, original_corner_max_pixels=error_by_index.get(index),
            original_prediction_visible=observation['visibility'] == 'visible')
        if not row['original_prediction_visible']:
            row.update(status='missing_original_prediction', common_template_pixels=None, comparisons=None)
            report['rows'].append(row)
            continue
        predicted = np.asarray(observation['observation']['matrix'], np.float64) @ np.linalg.inv(manual)
        target = cv2.getPerspectiveTransform(truth[0].astype(np.float32), truth[index].astype(np.float32)) @ np.linalg.inv(manual)
        predicted_points, pv = project(predicted, template)
        truth_points, tv = project(target, template)
        pred_supported = pv & supported(predicted_points, 640, 480)
        truth_supported = tv & supported(truth_points, 640, 480)
        common = pred_supported & truth_supported
        count = int(common.sum())
        row.update(common_template_pixels=count, predicted_supported_pixels=int(pred_supported.sum()),
            truth_supported_pixels=int(truth_supported.sum()),
            common_population_sha256=hashlib.sha256(template_ids[common].astype('<u4').tobytes()).hexdigest())
        if not count:
            row.update(status='no_common_observable_pixels', comparisons=None)
        else:
            selected = template[common].astype(int)
            raw = images[offset].astype(np.float64)
            filtered = cv2.GaussianBlur(images[offset], (5, 5), 1.0).astype(np.float64)
            comparisons = {}
            for name, current, reference in (('raw', raw, reference_raw), ('existing_filtered', filtered, reference_filtered)):
                reference_values = reference[selected[:, 1], selected[:, 0]]
                comparisons[name] = dict(predicted=metrics(sample(current, predicted_points[common]) - reference_values),
                    annotated_homography=metrics(sample(current, truth_points[common]) - reference_values))
                assert comparisons[name]['predicted']['count'] == comparisons[name]['annotated_homography']['count'] == count
            row.update(status='paired_common_population_measured', comparisons=comparisons)
        report['rows'].append(row)
    assert len(report['rows']) == 30
    report.update(status='paired_common_pixel_observation_complete_not_tracking_acceptance',
        measured_frames=sum(row['comparisons'] is not None for row in report['rows']),
        missing_measurement_frames=sum(row['comparisons'] is None for row in report['rows']))
except BaseException:
    report.update(status='failed_original_outputs_retained', cause=traceback.format_exc())
    logger.error('common-pixel diagnostic failed cause=%s', report['cause'])
finally:
    try:
        report['source_and_inputs_unchanged'] = all(sha(path) == expected for path, expected in INPUTS.items()) and all(
            sha(WORK / 'tools/tracking' / name) == expected for name, expected in source_hashes.items())
    except BaseException:
        report['source_and_inputs_unchanged'] = False
        report['verification_failure'] = traceback.format_exc()
    report.update(completed_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - began,
        in_flight=None)
    save()
    for handler in logger.handlers:
        handler.flush()
print(json.dumps({key:report.get(key) for key in ('status', 'cause', 'original_full_quality', 'measured_frames', 'missing_measurement_frames', 'source_and_inputs_unchanged', 'elapsed_seconds')}))
raise SystemExit(0 if report['status'] == 'paired_common_pixel_observation_complete_not_tracking_acceptance' and report['source_and_inputs_unchanged'] else 1)
