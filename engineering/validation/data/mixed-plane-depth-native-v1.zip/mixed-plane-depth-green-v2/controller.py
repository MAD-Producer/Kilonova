"""Execute unchanged real mesh/plane regressions after native integration."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess
root = Path('E:/Dev/aem'); work = root / '.worktrees/mixed-plane-depth'
out = root / 'artifacts/pr-queue/mixed-plane-depth-green-v2'; out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
red = json.loads((root / 'artifacts/pr-queue/mixed-plane-depth-red-v1/reproduced.json').read_text(encoding='utf-8'))
parent_test = 'crates/motion-render/tests/model_layers/project_shared.rs'
new_test = 'crates/motion-render/tests/model_layers/mixed_planes.rs'
assert sha(work / new_test) == red['source'][new_test]
paths = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard', '-z'], cwd=work).decode().split('\0')
source = {p: sha(work / p) for p in sorted(set(paths)) if p and (p.endswith(('.rs', '.py', '.toml', '.wgsl', '.json')) or p == 'Cargo.lock')}
for p in [parent_test, new_test, 'crates/motion-render/src/renderer/model_layers/shared.rs', 'crates/motion-render/src/scene_gpu/render/shared.rs', 'crates/motion-render/src/scene_gpu/render/planes.rs', 'crates/motion-render/src/scene_gpu/render/planes.wgsl', 'crates/motion-render/src/scene_gpu/render.rs', 'crates/motion-render/src/scene_gpu/mod.rs']:
    dest = out / 'source' / p; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(work / p, dest)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy(); env.update(CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG', None)
cmd = ['cargo', 'test', '-p', 'motion-render', '--features', 'gpu-tests', '--test', 'model_layers', '--locked', '--offline', '--', 'mixed_plane_', '--test-threads=1']
receipt = dict(startedUtc=datetime.now(timezone.utc).isoformat(), source=source, parent='1bb6a1650b17ab72d8f09c53c0d542495488dbe7', command=cmd)
with (out / 'stdout.log').open('wb') as so, (out / 'stderr.log').open('wb') as se:
    receipt['exitCode'] = subprocess.run(cmd, cwd=work, env=env, stdout=so, stderr=se).returncode
text = (out / 'stdout.log').read_text(encoding='utf-8')
results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
if results: receipt['totals'] = dict(zip(('passed', 'failed', 'ignored'), map(int, results[0])))
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=all(sha(work / p) == h for p, h in source.items()))
(out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
assert len(results) == 1 and receipt['sourceUnchanged'] and receipt['exitCode'] == 0
assert receipt['totals'] == dict(passed=2, failed=0, ignored=0)
assert 'mixed_plane_mesh_intersections_use_fragment_depth_in_both_authored_orders ... ok' in text
assert 'mixed_plane_camera_and_parent_depth_match_independent_world_ray_intersections ... ok' in text
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True, totals=receipt['totals'])), flush=True)
