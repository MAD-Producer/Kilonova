"""Actual mixed plane/mesh depth regression, with frozen source and retained failures."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

root = Path('E:/Dev/aem')
work = root / '.worktrees/mixed-plane-depth'
out = root / 'artifacts/pr-queue/mixed-plane-depth-native-v1'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
test = 'crates/motion-render/tests/model_layers/mixed_planes.rs'
earlier = (root / 'artifacts/pr-queue/mixed-plane-depth-green-v2/source' / test).read_text(encoding='utf-8')
assert (work / test).read_text(encoding='utf-8').startswith(earlier.rstrip() + '\n')
out.mkdir(exist_ok=False)
paths = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard', '-z'], cwd=work).decode().split('\0')
source = {p: sha(work / p) for p in sorted(set(paths)) if p and (p.endswith(('.rs', '.py', '.toml', '.wgsl', '.json')) or p == 'Cargo.lock')}
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=work).decode().splitlines()
changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=work).decode().splitlines()
for p in changed:
    dest = out / 'source' / p
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(work / p, dest)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG', None)
receipt = dict(startedUtc=datetime.now(timezone.utc).isoformat(), source=source, changedSource=changed,
               originalRedAssertionsUnchanged=True, steps=[], scope='Actual opaque solid 3D plane and mesh fragment depth; common camera, precision, immutable frames and budget recovery')
targets = ['model_layers', 'scene_gpu', 'layer_compositing', 'layer_rasters', 'layer_masks', 'scene_effects', 'exposure_frame', 'spatial_effects', 'compositions', 'multiple_camera_compositions']
native = ['cargo', 'test', '-p', 'motion-render', '--features', 'gpu-tests', '--lib']
for target in targets:
    native.extend(['--test', target])
native.extend(['--locked', '--offline', '--no-fail-fast', '--', '--test-threads=1'])
steps = [('provenance', [sys.executable, 'tools/validate_provenance.py']),
         ('panel-style', [sys.executable, '-c', "import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
         ('native', native),
         ('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline'])]
for name, cmd in steps:
    print(json.dumps(dict(start=name)), flush=True)
    with (out / (name + '.stdout.log')).open('wb') as so, (out / (name + '.stderr.log')).open('wb') as se:
        code = subprocess.run(cmd, cwd=work, env=env, stdout=so, stderr=se).returncode
    row = dict(name=name, command=cmd, exitCode=code, sourceUnchanged=all(sha(work / p) == h for p, h in source.items()))
    text = (out / (name + '.stdout.log')).read_text(encoding='utf-8')
    if name == 'native':
        results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
        row.update(targets=len(results), totals=dict(zip(('passed', 'failed', 'ignored'), [sum(int(v[i]) for v in results) for i in range(3)])))
    receipt['steps'].append(row)
    (out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], name
    if name == 'native':
        assert row['targets'] == len(targets) + 1 and row['totals'] == dict(passed=397, failed=0, ignored=0)
        assert len(re.findall(r'test project_shared::mixed_planes::mixed_plane_.* \.\.\. ok', text)) == 5
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=True)
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True, totals=next(s['totals'] for s in receipt['steps'] if s['name'] == 'native'))), flush=True)
