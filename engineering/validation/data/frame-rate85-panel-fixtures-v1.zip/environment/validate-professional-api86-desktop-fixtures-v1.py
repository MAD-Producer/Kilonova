from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/professional-api86-desktop-fixtures-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = {p.relative_to(work).as_posix(): sha(p) for folder in ['crates', 'desktop', 'tools', '.github'] for p in (work / folder).rglob('*') if p.is_file() and p.suffix in ['.rs', '.wgsl', '.py', '.yml', '.toml']}
sources.update({p: sha(work / p) for p in ['Cargo.toml', 'Cargo.lock']})
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip(), sources=sources, scope='Approved five fixture initializer corrections only; complete motion-desktop default GPU tests, cargo check, build helper check and actual native smoke. No runtime panel clock adoption, assertion changes, ignore changes or Android acceptance.', results=[])
save = lambda: (out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
commands = [
    ('check', ['cargo', 'check', '-p', 'motion-desktop', '--locked', '--offline']),
    ('desktop-tests', ['cargo', 'test', '-p', 'motion-desktop', '--no-fail-fast', '--locked', '--offline', '--', '--test-threads=1']),
    ('helper-check', [sys.executable, 'tools/build_desktop.py', '--task', 'check', '--debug', '--target-dir', os.environ['CARGO_TARGET_DIR'], '--', '--offline']),
    ('build', ['cargo', 'build', '-p', 'motion-desktop', '--locked', '--offline']),
    ('native-ui', [sys.executable, 'tools/ci_desktop.py', '--binary', str(Path(os.environ['CARGO_TARGET_DIR']) / 'debug/motion-studio.exe'), '--output', str(out / 'native-ui')]),
]
started = time.monotonic()
save()
try:
    for name, command in commands:
        if name == 'native-ui' and next(r for r in report['results'] if r['name'] == 'build')['exitCode'] != 0:
            report['results'].append(dict(name=name, status='not_run', reason='The required executable build failed; no stale executable accepted'))
            continue
        item = dict(name=name, command=command, status='running', startedUtc=datetime.now(timezone.utc).isoformat())
        report['results'].append(item)
        save()
        began = time.monotonic()
        with (out / f'{name}.stdout.log').open('wb') as stdout, (out / f'{name}.stderr.log').open('wb') as stderr:
            child = subprocess.Popen(command, cwd=work, env=os.environ.copy(), stdout=stdout, stderr=stderr)
            item['pid'] = child.pid
            save()
            item['exitCode'] = child.wait()
        item['elapsedSeconds'] = round(time.monotonic() - began, 3)
        item['summaries'] = re.findall(r'^test result: .+$', (out / f'{name}.stdout.log').read_text(encoding='utf-8', errors='replace'), re.M)
        item['status'] = 'passed' if item['exitCode'] == 0 else 'failed'
        save()
        print(json.dumps(item), flush=True)
    report['sourceUnchanged'] = all(sha(work / p) == digest for p, digest in sources.items())
    assert report['sourceUnchanged']
    report['status'] = 'passed_scope_acceptance_pending' if all(r['status'] == 'passed' for r in report['results']) else 'failed_original_results_retained'
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - started, 3))
    save()
    print(json.dumps({k:v for k,v in report.items() if k != 'sources'}), flush=True)
if report['status'] != 'passed_scope_acceptance_pending':
    raise SystemExit(1)
