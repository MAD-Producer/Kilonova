from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,shutil
root=Path('E:/Dev/aem');work=root/'.worktrees/depth-frozen-outputs';out=root/'artifacts/pr-queue/frozen-depth-native-v1';out.mkdir(exist_ok=False)
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
assert git('status','--porcelain')=='', 'Regression must run on a committed tree'
base='72f1037aea7a71047f1920347756d63dedf3e41b'
paths=git('ls-files','-z').split('\0')
source={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json')) or p=='Cargo.lock')}
for p in git('diff','--name-only',base,'HEAD').splitlines():
 if p in source:
  dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/p,dest)
shutil.copyfile(__file__,out/'controller.py')
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true',MOTION_FROZEN_DEPTH_ARTIFACTS=str(out/'renders'),MOTION_IMPORTED_CAMERA_OUTPUT_ARTIFACTS=str(out/'camera-renders'));env.pop('MOTION_LOG',None)
steps=[('provenance',['python','tools/validate_provenance.py']),('style',['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),('host',['cargo','test','-p','motion-host','--lib','--tests','--features','gpu-tests,ai-depth','--locked','--offline','--no-fail-fast','--','--test-threads=1']),('media-ffmpeg',['cargo','test','-p','motion-desktop-media','--lib','--features','ffmpeg,gpu-tests,ai-depth','--locked','--offline','--no-fail-fast','--','--test-threads=1','--include-ignored']),('png-without-ffmpeg',['cargo','test','-p','motion-desktop-media','--lib','--features','ai-depth,gpu-tests','--locked','--offline','movie::depth_tests::actual_png_keeps_calibrated_geometry_after_seek_close_and_original_source_removal','--','--test-threads=1']),('host-without-depth',['cargo','test','-p','motion-host','--lib','--no-default-features','--locked','--offline','depth_snapshot::','--','--test-threads=1']),('media-without-depth',['cargo','check','-p','motion-desktop-media','--no-default-features','--locked','--offline']),('desktop',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'])]
r=dict(head=git('rev-parse','HEAD'),main=base,startedUtc=datetime.now(timezone.utc).isoformat(),source=source,steps=[],scope='Full affected host/media regression after latest main integration, actual four-precision calibrated-image PNG and restored MP4 outputs; not calibrated video, exposure, DOF or final workspace acceptance')
for name,cmd in steps:
 print(json.dumps(dict(start=name)),flush=True)
 with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr: code=subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
 row=dict(name=name,command=cmd,exitCode=code,sourceUnchanged=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in source.items()))
 if name in ['host','media-ffmpeg','png-without-ffmpeg','host-without-depth']:
  text=(out/(name+'.stdout.log')).read_text(encoding='utf-8');results=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);row['results']=results
 r['steps'].append(row);(out/'exit.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(row),flush=True)
 assert code==0 and row['sourceUnchanged'],name
 if name in ['host','media-ffmpeg','png-without-ffmpeg','host-without-depth']:
  assert results and all(f==i=='0' for p,f,i in results)
  if name=='host': assert len(results)>=10 and sum(int(p) for p,f,i in results)>=169
  if name=='media-ffmpeg': assert results==[('56','0','0')]
  if name in ['png-without-ffmpeg','host-without-depth']: assert results==[('1','0','0')]
for folder in ['renders','camera-renders']:
 assert len(list((out/folder).rglob('*.mp4')))==4
 assert len(list((out/folder).rglob('comparison.json')))==8
r['completedUtc']=datetime.now(timezone.utc).isoformat();(out/'accepted.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print('accepted',flush=True)
