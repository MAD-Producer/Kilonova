from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/frame-rate85-runtime-contract-v2'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
packages = ['motion-model', 'motion-core', 'motion-render', 'motion-host', 'motion-media', 'motion-desktop-media']
sources = {path.relative_to(work).as_posix(): sha(path)
           for name in packages for path in (work / 'crates' / name).rglob('*.rs')}
sources.update({path.relative_to(work).as_posix(): sha(path)
                for path in (work / 'desktop' / 'app').rglob('*.rs')})
commands = [
    ('host', ['cargo', 'test', '-p', 'motion-host', '--test', 'layer_time_mapping',
              '--test', 'failure_boundaries', '--no-default-features', '--locked', '--offline', '--', '--test-threads=1']),
    ('render-clock', ['cargo', 'test', '-p', 'motion-render', '--test', 'rational_frame_clock',
                     '--test', 'composition_bundle_boundaries', '--no-default-features', '--locked', '--offline', '--', '--test-threads=1']),
    ('media', ['cargo', 'test', '-p', 'motion-media', '--no-default-features', '--locked', '--offline',
               '--no-fail-fast', '--', '--test-threads=1']),
    ('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg',
                       '--no-default-features', '--locked', '--offline']),
]
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), sources=sources,
    base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip(), results=[],
    scope='Selected real host/bundle/native+packed shader clocks, complete motion-media package, and FFmpeg desktop compile; desktop tests/UI/full rendering/workspace/CI pending')
save = lambda: (out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
started = time.monotonic()
save()
try:
    for name, command in commands:
        item = dict(name=name, command=command, status='running')
        report['results'].append(item)
        save()
        began = time.monotonic()
        with (out / f'{name}.stdout.log').open('wb') as stdout, (out / f'{name}.stderr.log').open('wb') as stderr:
            child = subprocess.Popen(command, cwd=work, env=os.environ.copy(), stdout=stdout, stderr=stderr)
            item['pid'] = child.pid
            save()
            item['exitCode'] = child.wait()
        item['elapsedSeconds'] = round(time.monotonic() - began, 3)
        item['summaries'] = re.findall(r'^test result: .+$',
            (out / f'{name}.stdout.log').read_text(encoding='utf-8', errors='replace'), re.M)
        item['status'] = 'passed' if item['exitCode'] == 0 else 'failed'
        save()
        print(json.dumps(item), flush=True)
    report['sourceUnchanged'] = all(sha(work / path) == digest for path, digest in sources.items())
    assert report['sourceUnchanged'], 'frozen source changed during runtime validation'
    assert all(item['exitCode'] == 0 for item in report['results']), 'runtime contract gate failed; original logs retained'
    assert all(item['summaries'] for item in report['results'] if item['name'] != 'desktop-check')
    report['status'] = 'selected_runtime_media_package_and_desktop_compile_passed_full_acceptance_pending'
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - started, 3))
    save()
    print(json.dumps({key: report.get(key) for key in ['status', 'sourceUnchanged', 'elapsedSeconds', 'failure']}), flush=True)
