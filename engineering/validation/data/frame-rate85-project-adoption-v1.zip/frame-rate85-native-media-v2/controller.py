from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/frame-rate85-native-media-v2'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sources = {path.relative_to(work).as_posix(): sha(path)
           for name in ['motion-model', 'motion-core', 'motion-render', 'motion-host', 'motion-media', 'motion-desktop-media']
           for path in (work / 'crates' / name).rglob('*.rs')}
command = ['cargo', 'test', '-p', 'motion-desktop-media', '--features', 'ffmpeg,gpu-tests',
           '--no-default-features', '--locked', '--offline', '--test', 'libav',
           '--test', 'layer_time_video', '--test', 'layer_time_audio', '--test', 'rational_export_clock',
           '--', '--test-threads=1']
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(),
    command=command, sources=sources,
    scope='Real native decoder, VFR/subframe source clocks, selected frozen GPU/PCM exports and MP4 mux clocks; not full desktop or full rendering acceptance')
save = lambda: (out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
env = os.environ.copy()
env['MOTION_RATE_CLOCK_EVIDENCE_DIR'] = str(out / 'encoded')
started = time.monotonic()
save()
try:
    with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    report['sourceUnchanged'] = all(sha(work / path) == digest for path, digest in sources.items())
    assert report['exitCode'] == 0, 'native media gate failed; original logs retained'
    assert report['sourceUnchanged'], 'test inputs changed during native validation'
    summaries = [line for line in (out / 'stdout.log').read_text(encoding='utf-8').splitlines()
                 if line.startswith('test result:')]
    report['summaries'] = summaries
    assert len(summaries) == 4 and all('0 failed; 0 ignored' in line for line in summaries), summaries
    report['encoded'] = {path.relative_to(out).as_posix(): {'sha256':sha(path),'bytes':path.stat().st_size}
                         for path in (out / 'encoded').iterdir()}
    assert len(report['encoded']) == 8
    report['status'] = 'native_media_and_exact_export_clocks_passed_desktop_gpu_and_protocol_gates_pending'
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic()-started, 3))
    save()
    print(json.dumps({key:report.get(key) for key in ['status','exitCode','sourceUnchanged','elapsedSeconds','failure']}), flush=True)
