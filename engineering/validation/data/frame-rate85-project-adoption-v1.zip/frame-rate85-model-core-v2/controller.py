from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/frame-rate85-model-core-v2'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sources = {path.relative_to(work).as_posix():sha(path)
           for package in ['motion-model','motion-core','motion-render']
           for path in (work / 'crates' / package).rglob('*') if path.is_file()}
command = ['cargo','test','-p','motion-model','-p','motion-core','--locked','--offline',
           '--no-fail-fast','--','--test-threads=1']
report = dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),command=command,
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),sources=sources,
    scope='Complete motion-model and motion-core packages on the unfinished rational project port; not final workspace/desktop acceptance')
save = lambda: (out / 'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
started = time.monotonic()
save()
try:
    with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command,cwd=work,env=os.environ.copy(),stdout=stdout,stderr=stderr)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    report['sourceUnchanged'] = all(sha(work / path) == digest for path,digest in sources.items())
    log = (out / 'stdout.log').read_text(encoding='utf-8',errors='replace')
    report['summaries'] = re.findall(r'^test result: .+$',log,re.M)
    assert report['exitCode'] == 0, 'model/core package gate failed; original logs retained'
    assert report['sourceUnchanged'], 'test sources changed during full package run'
    assert report['summaries'] and all('test result: ok.' in line for line in report['summaries'])
    report['status'] = 'complete_model_and_core_packages_passed_desktop_and_protocol_gates_pending'
except BaseException as cause:
    report.update(status='failed',failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-started,3))
    save()
    print(json.dumps({key:report.get(key) for key in ['status','exitCode','sourceUnchanged','elapsedSeconds','failure']}),flush=True)
