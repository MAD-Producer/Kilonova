from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-main-time-v4'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()
source = {path: sha(WORK / path) for path in sorted(set(paths)) if path.endswith(('.rs', 'Cargo.toml', 'Cargo.lock')) and (WORK / path).is_file()}
owned = ['crates/motion-core/src/command_registry.rs', 'crates/motion-core/src/history_accounting.rs',
    'crates/motion-model/src/commands.rs', 'crates/motion-model/src/lib.rs', 'crates/motion-model/src/model.rs',
    'crates/motion-model/tests/tracking_point.rs', 'crates/motion-model/tests/tracking_plane.rs',
    'crates/motion-model/tests/tracking_camera.rs', 'crates/motion-core/tests/tracking_replacement.rs',
    'crates/motion-model/tests/tracking_layer_time/point.rs', 'crates/motion-model/tests/tracking_layer_time/plane.rs',
    'crates/motion-model/tests/tracking_layer_time/camera.rs', 'crates/motion-core/tests/tracking_replacement/layer_time.rs']
for relative in owned:
    target = OUT / 'source' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((WORK / relative).read_bytes())
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1', RUST_BACKTRACE='full')
command = ['cargo', 'test', '-p', 'motion-model', '-p', 'motion-core', '--locked', '--offline', '--no-fail-fast', '--', '--test-threads=1']
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), command=command, source=source,
    head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip(),
    integratedMain=subprocess.check_output(['git', 'rev-parse', 'MERGE_HEAD'], cwd=WORK, text=True).strip())
started = time.monotonic()
def save():
    pending = OUT / 'exit.pending.json'
    pending.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(pending, OUT / 'exit.json')
save()
try:
    with (OUT / 'stdout.log').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    report['sourceUnchanged'] = all(sha(WORK / path) == digest for path, digest in source.items())
    assert report['sourceUnchanged'], 'source changed during validation'
    assert report['exitCode'] == 0, report['exitCode']
    report['status'] = 'complete_model_and_core_packages_on_integrated_main_passed'
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - started, 3))
    save()
    print(json.dumps({key: report.get(key) for key in ['status', 'exitCode', 'failure', 'elapsedSeconds']}, indent=2), flush=True)



