"""Frozen >=30-minute ordered learned workload; every original attempt retained."""
from pathlib import Path
from datetime import datetime, timezone
import array,csv,hashlib,json,math,os,platform,shutil,subprocess,sys,time,traceback

ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
TARGET=ROOT/'target/depth-wgsl-cache75-contract';OUT=BASE/'depth75-sustained-reference-v1'
INPUTS=BASE/'depth75-reference-inputs-v1'
assert not OUT.exists() and shutil.disk_usage(ROOT).free>=10<<30
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip();assert head.startswith('ad799f2f')
assert not subprocess.check_output(['git','diff','--name-only','54a4707d',head,'--','crates','desktop','tools','Cargo.toml','Cargo.lock'],cwd=WORK)
subprocess.check_call(['git','merge-base','--is-ancestor','origin/main','HEAD'],cwd=WORK)
assert json.loads((BASE/'depth75-phase-process-memory-v1/session-consumed.json').read_text())==dict(session=74546,consumed=True,exit_code=0)
checkpoint=BASE/'depth75-resume-current.json';state=json.loads(checkpoint.read_text(encoding='utf-8'))
assert state['versionedCache75']['activeController'] is None and not state['versionedCache75']['ownHeavyWorkloads']
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
paths=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def sources():return {p:sha(WORK/p) for p in paths}
protocol_path=WORK/'engineering/validation/depth75-sustained-reference-protocol.md'
FIELDS=['uuid','name','driver_version','temperature.gpu','memory.used','memory.total','power.draw','power.limit',
 'clocks.current.graphics','clocks.current.memory','utilization.gpu','clocks_event_reasons.hw_thermal_slowdown','clocks_event_reasons.sw_thermal_slowdown']
sensor=Path('C:/Windows/System32/nvidia-smi.exe')
protocol=dict(version=1,document_sha256=sha(protocol_path),minimum_workload_seconds=1800,maximum_cohorts=6,frames_per_cohort=32,
 maximum_retained_readings=4500,requested_query_gap_seconds=1,maximum_sampling_gap_seconds=5,sensor_query_deadline_seconds=10,
 fields=FIELDS,reference_fit='first8 of first cohort only; fixed fit for held-out8..31 in every cohort',
 maximum_original_request_wait_seconds=60,no_retry_or_removed_samples=True,
 limits=['Cold child-process product route; finite repeated source, not an isolated shader stress or warm-runtime benchmark',
 'Whole-device sampled sensors include unrelated activity; not process-attributed heat, power, device allocation peak or CPU temperature',
 'Query-time lifetime OS peaks omit final serialization/exit, descendants and other Jobs; no full-memory certificate',
 'Loop resets are explicit; this is not continuous-video tier transition or general domain qualification',
 'One owned heavy workload, source frozen until original controller/child terminal and consumed; no Android/panels/cleanup/downloads'])
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',
 CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),
 LOCALAPPDATA=str(OUT/'appdata'),PYTHONDONTWRITEBYTECODE='1',RUST_BACKTRACE='full')
env['PATH']=str(ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')+';'+env['PATH']
report=dict(status='running',head=head,source_sha256=sources(),started_utc=now(),protocol=protocol,
 protocol_sha256=hashlib.sha256(json.dumps(protocol,sort_keys=True,separators=(',',':')).encode()).hexdigest(),stages=[],cohorts=[],readings_count=0)
def save():
 p=OUT/'receipt.pending.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(p,OUT/'receipt.json')
def event(phase,**values):
 with (OUT/'events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(utc=now(),monotonic_ns=time.monotonic_ns(),phase=phase,**values))+'\n')
def build():
 command=['cargo','build','--locked','--offline','-p','motion-host','-p','motion-desktop','--example','depth_reference','--bin','motion-depth-wgsl',
  '--features','motion-desktop/ffmpeg,motion-host/ai-depth']
 row=dict(name='actual-build',command=command);report['stages'].append(row);event('build_start');save()
 with (OUT/'build.stdout.log').open('wb') as stdout,(OUT/'build.stderr.log').open('wb') as stderr:
  child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();row['exit_code']=child.wait()
 save();assert row['exit_code']==0,'Original build failure retained; no model workload started'
def number(value):
 try:
  n=float(value);return n if math.isfinite(n) else None
 except (TypeError,ValueError):return None
readings=[]
def reading():
 assert len(readings)<4500,'Sample bound reached; no observations may be evicted'
 start=time.monotonic_ns();command=[str(sensor),'--query-gpu='+','.join(FIELDS),'--format=csv,noheader,nounits']
 event('sensor_query_start',cohort=report.get('active_cohort'),sample=len(readings))
 try:
  result=subprocess.run(command,capture_output=True,text=True,env=env,timeout=10)
  raw=dict(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
 except subprocess.TimeoutExpired as error:
  def text(value):return value.decode('utf-8',errors='replace') if isinstance(value,bytes) else value
  raw=dict(timeout=True,stdout=text(error.stdout),stderr=text(error.stderr))
 row=dict(start_monotonic_ns=start,end_monotonic_ns=time.monotonic_ns(),utc=now(),raw=raw)
 with (OUT/'readings.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
 readings.append(row);report['readings_count']=len(readings)
 assert raw.get('returncode')==0 and not raw['stderr'],'Original sensor error/timeout retained; no retry'
 assert len(raw['stdout'])<=4096,'Sensor output exceeded original bound'
 values=list(csv.reader(raw['stdout'].splitlines(),skipinitialspace=True));assert len(values)==1 and len(values[0])==len(FIELDS)
 row['values']=dict(zip(FIELDS,[v.strip() for v in values[0]]))
 assert row['values']['name']=='NVIDIA GeForce RTX 4070 Laptop GPU'
 if 'environment' in report:
  assert all(row['values'][k]==report['environment']['gpu'][k] for k in ('uuid','name','driver_version'))
 temperature=number(row['values']['temperature.gpu'])
 assert temperature is None or -273.15<=temperature<=200
 return row
state['versionedCache75'].update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(kind='build then sustained ordered GPU workload',head=head,output=str(OUT))],localUnpublishedHead=head)
state['updatedUtc']=now();checkpoint.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8');save()
child=None
try:
 build()
 preparation=json.loads((INPUTS/'receipt.json').read_text());assert preparation['source_unchanged']
 assert sha(INPUTS/'inputs.json')==preparation['inputs_sha256']
 inputs=json.loads((INPUTS/'inputs.json').read_text());assert len(inputs)==32
 for item in inputs:
  for kind in ('rgb','depth'):
   record=item[kind+'_input'];assert sha(INPUTS/record['filename'])==record['sha256']
 driver=TARGET/'debug/examples/depth_reference.exe';worker=TARGET/'debug/motion-depth-wgsl.exe'
 model=BASE/'depth75-resolution-models-v1/518/export/depth_anything_v2_vits_518.onnx'
 program=BASE/'depth75-wgsl-cache-resources-v2/program.json';python=ROOT/'.tools/ai-depth74/venv/Scripts/python.exe'
 assert sha(model)==json.loads(model.with_name('model.json').read_text())['sha256']
 assert sha(program)=='2ec1d8012905198cfd5af1430f88d1770edbf752531fe817dfcc65e1477fef6a'
 bindings={str(p):sha(p) for p in (driver,worker,model,program,python,INPUTS/'inputs.json')}
 report['identities']=bindings;save()
 initial=reading()
 environment=dict(os=platform.platform(),machine=platform.machine(),gpu={k:initial['values'][k] for k in ('uuid','name','driver_version')})
 report['environment']=environment;report['environment_sha256']=hashlib.sha256(json.dumps(environment,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 started=time.monotonic_ns();report['workload_started_monotonic_ns']=started;save()
 for batch in range(6):
  if batch and (time.monotonic_ns()-started)/1e9>=1800:break
  assert shutil.disk_usage(ROOT).free>=10<<30
  assert all(sha(Path(p))==digest for p,digest in bindings.items())
  report['active_cohort']=batch
  output=OUT/f'cohort-{batch:02}'
  command=[str(v) for v in (driver,'wgsl',python,model,program,worker,INPUTS,output)]
  record=dict(index=batch,command=command,started_monotonic_ns=time.monotonic_ns());report['cohorts'].append(record)
  event('cohort_start',cohort=batch);save()
  with (OUT/f'cohort-{batch:02}.stdout.log').open('wb') as stdout,(OUT/f'cohort-{batch:02}.stderr.log').open('wb') as stderr:
   child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);record['pid']=child.pid;save()
   while child.poll() is None:
    reading();time.sleep(1)
   record.update(exit_code=child.wait(),finished_monotonic_ns=time.monotonic_ns());save()
  reading();assert record['exit_code']==0,'Original failed cohort retained; no retry'
  assert not (OUT/f'cohort-{batch:02}.stdout.log').read_bytes(),'Unexpected stdout in reference protocol'
  measured=json.loads((output/'measurements.json').read_text());assert measured['status']=='completed' and len(measured['samples'])==32
  summary=measured['summary'];assert summary['samples']==summary['submitted']==summary['completed']==32
  assert all(summary[k]==0 for k in ('failed','canceled','cache_hits','cache_misses','restored'))
  assert initial['values']['name'] in summary['execution']['provider'] and summary['execution']['backend']=='wgsl'
  for index,(sample,source) in enumerate(zip(measured['samples'],inputs)):
   assert sample['index']==index and sample['split']==source['split'] and sample['worker_total_ns']>=sample['resolve_ns']>0
   out=sample['output'];assert out['filename']==f'{index:02}.relative.f32le' and out['bytes']==640*480*4
   assert sha(output/out['filename'])==out['sha256']
   memory=sample['process_memory'];assert memory['host']['status']=='observed' and memory['host']['pid']==record['pid']
   stages=memory['children'];assert stages['backend']=='wgsl'
   for phase in ('resolution_transform','resolution_native','prepare','inference','remap'):
    assert stages[phase]['status']=='observed' and stages[phase]['peak_resident_bytes']>0
   assert sample['observed_resident_sum_bytes']>0 and sample['retained_gpu_buffer_capacity_bytes']==227968156
  record.update(summary=summary,measurements_sha256=sha(output/'measurements.json'));event('cohort_complete',cohort=batch);save()
 report.update(workload_duration_ns=time.monotonic_ns()-started,active_cohort=None);reading();save()
 report['duration_gate']=report['workload_duration_ns']>=1800*10**9
 gaps=[(b['start_monotonic_ns']-a['end_monotonic_ns'])/1e9 for a,b in zip(readings,readings[1:])]
 alltemps=[number(r['values']['temperature.gpu']) for r in readings];temps=[v for v in alltemps if v is not None]
 flag_fields=('clocks_event_reasons.hw_thermal_slowdown','clocks_event_reasons.sw_thermal_slowdown')
 flags=[r['values'][k] for r in readings for k in flag_fields]
 known_flags=[s for s in flags if s in ('Active','Not Active')]
 memories=[number(r['values']['memory.used']) for r in readings];known_memories=[v for v in memories if v is not None]
 report['sampled_summary']=dict(readings=len(readings),maximum_observation_gap_seconds=max(gaps),sampling_coverage_gate=max(gaps)<=5,
  usable_temperature_samples=len(temps),minimum_temperature_celsius=min(temps) if temps else None,maximum_temperature_celsius=max(temps) if temps else None,
  first_temperature_celsius=alltemps[0],last_temperature_celsius=alltemps[-1],known_thermal_flag_values=len(known_flags),
  thermal_slowdown_observed=any(s=='Active' for s in known_flags) if known_flags else None,
  maximum_whole_device_memory_observed_mib=max(known_memories) if known_memories else None)
 save();event('reference_reduction_start')
 sys.path.insert(0,str(WORK/'tools'));import depth_reference_metrics as metrics
 def pair(batch,index):
  prediction=array.array('f');prediction.frombytes((OUT/f'cohort-{batch:02}'/f'{index:02}.relative.f32le').read_bytes())
  sensor_depth=array.array('H');sensor_depth.frombytes((INPUTS/inputs[index]['depth_input']['filename']).read_bytes())
  if sys.byteorder!='little':prediction.byteswap();sensor_depth.byteswap()
  assert len(prediction)==len(sensor_depth)==640*480
  return prediction,sensor_depth
 fitted=metrics.fit(pair(0,i) for i in range(8));assert fitted.reference_scale_inverse_metres==1.0
 quality=[]
 for batch in range(len(report['cohorts'])):
  evaluated=[]
  for i in range(8,32):
   prediction,depth=pair(batch,i);row=metrics.score(fitted,prediction,depth);row['index']=i;evaluated.append(row)
  quality.append(dict(cohort=batch,frames=evaluated,aggregate=metrics.summarize(evaluated,fitted)))
 (OUT/'fixed-fit-sensor-residuals.json').write_text(json.dumps(dict(calibration=fitted.__dict__,cohorts=quality,maximum_additional_transition_jump=None),indent=2)+'\n',encoding='utf-8')
 report.update(total_completed_requests=32*len(report['cohorts']),fixed_fit_residuals_sha256=sha(OUT/'fixed-fit-sensor-residuals.json'))
 assert report['duration_gate'],'Predeclared duration not reached after allowed cohorts; no added cohort or retry'
 assert report['sampled_summary']['sampling_coverage_gate'],'Predeclared observation gap exceeded; no interpolation or retry'
 report['status']='complete_declared_sustained_ordered_reference_observation'
except BaseException:
 report.update(status='failed_original_outputs_retained',cause=traceback.format_exc());save();raise
finally:
 if child is not None and child.poll() is None:
  event('await_original_child_after_observation_failure',pid=child.pid);report['original_child_exit_code']=child.wait()
 report.update(source_unchanged=sources()==report['source_sha256'],completed_utc=now())
 report['retained_logs']={str(p.relative_to(OUT)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in OUT.glob('*.log')}
 save();assert report['source_unchanged'],'Source changed during original workload'
print(json.dumps({k:report.get(k) for k in ('status','total_completed_requests','workload_duration_ns','sampled_summary')}))
