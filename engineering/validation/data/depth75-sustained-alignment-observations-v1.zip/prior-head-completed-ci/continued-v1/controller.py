"""Continue log collection after correcting one observer's test module name.

The original collector failure stays retained; no CI test or assertion changes.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, traceback

BASE=Path('E:/Dev/aem/artifacts/pr-queue/depth75-ci-b65a016f')
OUT=BASE/'continued-v1'
assert not OUT.exists()
OUT.mkdir()
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='running',run=42547547754,head='b65a016f34ca91786e24f05ef1da15bf51fb24c8',
            prior_collection='failed observer used onnx::tests instead of source module onnx::profile_tests; original log proves passing test',
            observed_utc=datetime.now(timezone.utc).isoformat(),jobs=[])
def api(endpoint):
    result=subprocess.run(['gh','api',endpoint],capture_output=True,timeout=60)
    assert result.returncode==0,result.stderr.decode(errors='replace')
    return result.stdout
try:
    raw=api('repos/MAD-Producer/Kilonova/actions/runs/42547547754')
    (OUT/'run.json').write_bytes(raw)
    run=json.loads(raw);assert run['head_sha']==report['head']
    report['workflow_status']=run['status'];report['workflow_conclusion']=run['conclusion']
    raw=api('repos/MAD-Producer/Kilonova/actions/runs/42547547754/jobs?per_page=100')
    (OUT/'jobs.json').write_bytes(raw)
    jobs=json.loads(raw)['jobs'];assert len(jobs)<100
    names=['depth::capability::memory::tests::peak_formats_keep_missing_platform_counters_unknown',
           'depth::capability::memory::tests::unavailable_retains_bounded_cause_instead_of_zero_usage',
           'depth::onnx::profile_tests::memory_report_retains_unavailable_and_rejects_inconsistent_counters']
    for job in jobs:
        if job['status']!='completed' or job['conclusion']=='skipped':continue
        assert job['conclusion']=='success',job
        filename=f"job-{job['id']}.log"
        path=BASE/filename
        if not path.exists():
            path=OUT/filename
            path.write_bytes(api(f"repos/MAD-Producer/Kilonova/actions/jobs/{job['id']}/logs"))
        raw=path.read_bytes();text=raw.decode('utf-8',errors='replace')
        row=dict(id=job['id'],name=job['name'],conclusion=job['conclusion'],
                 path=str(path.relative_to(BASE)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
        if job['name'].startswith('Desktop tests ('):
            row['named_memory_controls']={name:sum(f'test {name} ... ok' in line for line in text.splitlines()) for name in names}
            assert all(value==1 for value in row['named_memory_controls'].values()),row
        report['jobs'].append(row)
    assert sum(row['name'].startswith('Desktop tests (') for row in report['jobs'])==3
    report['status']='three_platform_test_logs_and_all_currently_completed_jobs_verified'
except BaseException:
    report.update(status='failed_original_outputs_retained',cause=traceback.format_exc());raise
finally:
    (OUT/'collection.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report.get(k) for k in ('status','workflow_status','workflow_conclusion')}))
