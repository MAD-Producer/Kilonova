"""Retain completed own-PR jobs without claiming a running workflow passed."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import traceback

ROOT=Path('E:/Dev/aem/artifacts/pr-queue/depth75-ci-b65a016f')
RUN=42547547754
HEAD='b65a016f34ca91786e24f05ef1da15bf51fb24c8'
assert not ROOT.exists()
ROOT.mkdir()
(ROOT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='collecting_completed_jobs_only', run=RUN, head=HEAD,
            observed_utc=datetime.now(timezone.utc).isoformat(), files={}, jobs=[])
def api(endpoint):
    result=subprocess.run(['gh','api',endpoint],capture_output=True,timeout=60)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace'))
    return result.stdout
def save():
    (ROOT/'collection.json').write_text(json.dumps(report,indent=2)+'\n')
try:
    raw=api(f'repos/MAD-Producer/Kilonova/actions/runs/{RUN}')
    (ROOT/'run-at-test-collection.json').write_bytes(raw)
    run=json.loads(raw)
    assert run['head_sha']==HEAD and run['head_branch']=='feat/75-wgsl-cache-attestation'
    report['workflow_status_at_collection']=run['status']
    raw=api(f'repos/MAD-Producer/Kilonova/actions/runs/{RUN}/jobs?per_page=100')
    (ROOT/'jobs-at-test-collection.json').write_bytes(raw)
    jobs=json.loads(raw)['jobs']
    assert len(jobs)<100
    names=['depth::capability::memory::tests::peak_formats_keep_missing_platform_counters_unknown',
           'depth::capability::memory::tests::unavailable_retains_bounded_cause_instead_of_zero_usage',
           'depth::onnx::tests::memory_report_retains_unavailable_and_rejects_inconsistent_counters']
    for job in jobs:
        if job['status']!='completed' or job['conclusion']=='skipped':
            continue
        assert job['conclusion']=='success'
        raw=api(f"repos/MAD-Producer/Kilonova/actions/jobs/{job['id']}/logs")
        path=ROOT/f"job-{job['id']}.log"
        path.write_bytes(raw)
        text=raw.decode('utf-8',errors='replace')
        record=dict(id=job['id'],name=job['name'],conclusion=job['conclusion'],
                    bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
        if job['name'].startswith('Desktop tests ('):
            record['named_memory_controls']={name:sum(f'test {name} ... ok' in line for line in text.splitlines()) for name in names}
            assert all(value==1 for value in record['named_memory_controls'].values()), record
        report['jobs'].append(record)
        save()
    assert sum(job['name'].startswith('Desktop tests (') for job in report['jobs'])==3
    report['status']='completed_three_platform_test_logs_collected_workflow_builds_separate'
except BaseException:
    report.update(status='failed_original_outputs_retained',cause=traceback.format_exc())
    raise
finally:
    for path in ROOT.iterdir():
        if path.is_file() and path.name!='collection.json':
            report['files'][path.name]=dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    save()
print(json.dumps({k:report[k] for k in ('status','run','head','workflow_status_at_collection')}))
