"""Archive completed observations, excluding learned planes and third-party assets."""
from pathlib import Path
from datetime import datetime,timezone
import csv,hashlib,json,subprocess,zipfile

ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
OUT=BASE/'depth75-sustained-alignment-public-v1';assert not OUT.exists();OUT.mkdir()
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
sensor=BASE/'depth75-sustained-reference-v1';alignment=BASE/'depth75-continuous-alignment-v1'
for folder,session in ((sensor,65993),(alignment,21284)):
    assert json.loads((folder/'session-consumed.json').read_text())==dict(session=session,consumed=True,exit_code=0)
s=json.loads((sensor/'receipt.json').read_text());a=json.loads((alignment/'receipt.json').read_text())
assert s['source_unchanged'] and a['source_unchanged'] and s['head']==a['head']
fields=s['protocol']['fields'];active=[]
for index,line in enumerate((sensor/'readings.jsonl').read_text().splitlines()):
    reading=json.loads(line);rows=list(csv.reader(reading['raw']['stdout'].splitlines(),skipinitialspace=True))
    values=dict(zip(fields,[v.strip() for v in rows[0]]))
    if any(values[k]=='Active' for k in fields if k.startswith('clocks_event_reasons.')):
        active.append(dict(sample_index=index,utc=reading['utc'],start_monotonic_ns=reading['start_monotonic_ns'],
                           end_monotonic_ns=reading['end_monotonic_ns'],values=values))
assert len(active)==3
baseline=json.loads((sensor/'cohort-00/measurements.json').read_text())['samples']
repeated=[]
for batch in range(1,4):
    measured=json.loads((sensor/f'cohort-{batch:02}/measurements.json').read_text())['samples']
    assert len(measured)==len(baseline)==32
    equal=[i for i,(r,c) in enumerate(zip(baseline,measured)) if r['output']['sha256']==c['output']['sha256']]
    repeated.append(dict(cohort=batch,bit_identical_to_first_cohort=len(equal),compared=32))
supplement=dict(status='posthoc_reduction_no_new_gate_or_retry',head=s['head'],
    active_thermal_observations=active,repeated_source_output_digests=repeated,
    limits=['Thermal flags and sampled heat describe the whole GPU, including unrelated activity; no attribution to this model',
            'Three Active readings are not an exact slowdown duration; no interpolation or causal latency claim',
            'Digest equality covers repeated original source outputs, not general domain accuracy or independent new frames',
            'All cross-resolution refusals retained; no actual Session/video switch or automatic tier qualification'])
(OUT/'supplement.json').write_text(json.dumps(supplement,indent=2)+'\n')
members={}
def add(name,path):
    assert name not in members and path.is_file();members[name]=path
for label,folder in [('sustained-reference',sensor),('current-product-alignment',alignment)]:
    for path in folder.rglob('*'):
        if path.is_file() and path.suffix in ('.json','.jsonl','.log','.py','.md') and not path.name.endswith('.pending.json'):
            add(label+'/'+path.relative_to(folder).as_posix(),path)
for path in (BASE/'depth75-continuous-alignment-v1-fixture').rglob('*'):
    if path.is_file() and path.suffix in ('.rs','.toml','.lock','.json','.md'):
        add('alignment-fixture/'+path.relative_to(BASE/'depth75-continuous-alignment-v1-fixture').as_posix(),path)
for name in ('depth75-sustained-reference-v1-review.py','depth75-sustained-reference-first-cohort-review.py',
             'depth75-continuous-alignment-freeze.py'):
    add('observers/'+name,BASE/name)
for path in (BASE/'depth75-ci-b65a016f').rglob('*'):
    if path.is_file() and 'final-v1' not in path.parts and path.suffix in ('.json','.log','.py'):
        add('prior-head-completed-ci/'+path.relative_to(BASE/'depth75-ci-b65a016f').as_posix(),path)
changed=set()
for revision in ('b388ada3','54a4707d'):
    changed.update(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',revision],cwd=WORK,text=True).splitlines())
changed.update(['desktop/app/src/logging/sink.rs','engineering/validation/depth75-sustained-reference-protocol.md'])
for name in sorted(changed):
    path=WORK/name
    if path.suffix in ('.rs','.py','.toml','.lock','.md') or name=='NOTICE':
        assert sha(path.read_bytes())==s['source_sha256'][name]
        add('selected-source/'+name,path)
add('observer/controller.py',OUT/'controller.py');add('observer/supplement.json',OUT/'supplement.json')
assert not any(name.endswith(('.f32le','.onnx','.exe','.dll','.pdb','.rgb','.png','.mp4','.u16le')) for name in members)
archive=OUT/'depth75-sustained-alignment-observations-v1.zip'
manifest=dict(status='readback_verified_observations_not_issue_completion',head=s['head'],
              created_utc=datetime.now(timezone.utc).isoformat(),members={},
              source_scope='Selected source snapshots plus original all-tracked-file hash manifests; not the whole repository source tree',
              exclusions='No learned/reference arrays, RGB/sensor pixels, photographs, video, weight/model binaries, runtime binaries or executable files',
              source_sustained_result=s['status'],source_alignment_result=a['status'],
              cross_resolution_quality_qualified=False,thermal_qualified=False,full_workspace_qualified=False)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as bundle:
    for name,path in sorted(members.items()):
        raw=path.read_bytes();manifest['members'][name]=dict(bytes=len(raw),sha256=sha(raw));bundle.writestr(name,raw)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None and set(bundle.namelist())==set(manifest['members'])
    for name,record in manifest['members'].items():
        raw=bundle.read(name);assert len(raw)==record['bytes'] and sha(raw)==record['sha256']
manifest.update(archive_bytes=archive.stat().st_size,archive_sha256=sha(archive.read_bytes()))
(OUT/'depth75-sustained-alignment-observations-v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('status','head','archive_bytes','archive_sha256')}))
