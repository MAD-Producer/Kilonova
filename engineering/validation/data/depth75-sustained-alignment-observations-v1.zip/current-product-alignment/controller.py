"""Execute frozen current-product alignment over retained photographic outputs."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,shutil,subprocess,traceback

ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
FIXTURE=BASE/'depth75-continuous-alignment-v1-fixture';OUT=BASE/'depth75-continuous-alignment-v1'
TARGET=ROOT/'target/depth-wgsl-cache75-contract'
consumed=json.loads((BASE/'depth75-sustained-reference-v1/session-consumed.json').read_text())
assert consumed['session']==65993 and consumed['consumed'] is True
assert not OUT.exists() and shutil.disk_usage(ROOT).free>=10<<30
checkpoint=BASE/'depth75-resume-current.json';state=json.loads(checkpoint.read_text(encoding='utf-8'))
assert state['versionedCache75']['activeController'] is None and not state['versionedCache75']['ownHeavyWorkloads']
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
frozen=json.loads((FIXTURE/'frozen-inputs.json').read_text())
assert all(sha(FIXTURE/name)==value for name,value in frozen['fixture'].items())
for record in frozen['cohorts'].values():assert sha(Path(record['root'])/'measurements.json')==record['measurements_sha256']
paths=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def sources():return {name:sha(WORK/name) for name in paths}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
report=dict(status='running',head=head,source_sha256=sources(),fixture=frozen,stages=[])
def save():(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
state['versionedCache75'].update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(kind='native alignment observer build and actual retained-output controls',head=head,output=str(OUT))])
checkpoint.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8');save()
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),RUST_BACKTRACE='full')
def run(name,command,expected_success=True):
    row=dict(name=name,command=[str(v) for v in command],started_utc=datetime.now(timezone.utc).isoformat());report['stages'].append(row);save()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(row['command'],cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();row['exit_code']=child.wait()
    row['completed_utc']=datetime.now(timezone.utc).isoformat();save()
    assert (row['exit_code']==0)==expected_success,row
    return row
try:
    # Reuse the workspace's exact already-installed versions; no downloads.
    assert not (FIXTURE/'Cargo.lock').exists()
    shutil.copyfile(WORK/'Cargo.lock',FIXTURE/'Cargo.lock')
    run('actual-build',['cargo','build','--offline','--manifest-path',FIXTURE/'Cargo.toml'])
    import tomllib
    original=tomllib.loads((WORK/'Cargo.lock').read_text())['package']
    actual=tomllib.loads((FIXTURE/'Cargo.lock').read_text())['package']
    pinned={(v['name'],v['version'],v.get('checksum')) for v in original}
    assert all(not v.get('source') or (v['name'],v['version'],v.get('checksum')) in pinned for v in actual)
    binary=TARGET/'debug/depth75-continuous-alignment-observer.exe';report['executable_sha256']=sha(binary);save()
    reference=Path(frozen['cohorts']['cpu518']['root'])
    summaries=[]
    for name in ('cpu266','cpu392','wgsl518'):
        candidate=Path(frozen['cohorts'][name]['root']);output=OUT/name
        run(name,[binary,reference,candidate,output])
        assert not (OUT/(name+'.stdout.log')).read_bytes()
        measured=json.loads((output/'observations.json').read_text());assert measured['status']=='complete_observation_not_tier_qualification'
        rows=measured['frames'];assert len(rows)==32 and [v['index'] for v in rows]==list(range(32))
        assert measured['reference_measurements_sha256']==frozen['cohorts']['cpu518']['measurements_sha256']
        assert measured['candidate_measurements_sha256']==frozen['cohorts'][name]['measurements_sha256']
        accepted=[v for v in rows if v['status']=='accepted_under_research_limits']
        rejected=[v for v in rows if v['status']=='rejected']
        assert len(accepted)+len(rejected)==32
        text=(output/'logs/motion-studio.log').read_text()
        assert 'phase=fit index=0' in text and 'phase=fit index=31' in text
        summaries.append(dict(route=name,inspected=32,accepted=len(accepted),rejected=len(rejected),
                              adjacent_accepted_pairs=sum(v['additional_source_grid_change'] is not None for v in rows)))
    # Preserve separately authored malformed metadata; original inputs untouched.
    for name in ('corrupt-plane-digest','different-prepared-input'):
        candidate=OUT/(name+'-input');candidate.mkdir()
        original_root=Path(frozen['cohorts']['cpu266']['root'])
        plan=json.loads((original_root/'measurements.json').read_text())
        if name=='corrupt-plane-digest':
            plan['samples'][0]['output']['sha256']='0'*64
            shutil.copyfile(original_root/'00.relative.f32le',candidate/'00.relative.f32le')
            expected='plane size/digest differs'
        else:
            plan['samples'][0]['input']['rgb_sha256'][0]^=1
            expected='different source, geometry or prepared RGB'
        (candidate/'measurements.json').write_text(json.dumps(plan))
        output=OUT/name
        run(name,[binary,reference,candidate,output],False)
        assert not (OUT/(name+'.stdout.log')).read_bytes()
        text=(output/'logs/motion-studio.log').read_text()
        stderr=(OUT/(name+'.stderr.log')).read_text()
        assert expected in text and expected in stderr and 'ERROR' in text and 'ERROR' in stderr
        assert 'phase=fit' not in text and not (output/'observations.json').exists()
    report.update(status='actual_current_alignment_observation_and_error_controls_complete_not_tier_qualification',summaries=summaries)
except BaseException:
    report.update(status='failed_original_outputs_retained',cause=traceback.format_exc());save();raise
finally:
    report.update(source_unchanged=sources()==report['source_sha256'],completed_utc=datetime.now(timezone.utc).isoformat())
    save();assert report['source_unchanged']
print(json.dumps({k:report.get(k) for k in ('status','summaries','cause')}))
