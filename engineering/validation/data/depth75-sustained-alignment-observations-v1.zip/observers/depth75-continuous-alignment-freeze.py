"""Freeze existing source-coordinate cohorts and the next native observer."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

BASE = Path('E:/Dev/aem/artifacts/pr-queue')
fixture = BASE / 'depth75-continuous-alignment-v1-fixture'
target = fixture / 'frozen-inputs.json'
assert not target.exists()
roots = dict(
    cpu266=BASE / 'depth75-reference-onnx266-v2/onnx266',
    cpu392=BASE / 'depth75-reference-remaining-v1/onnx392',
    cpu518=BASE / 'depth75-reference-remaining-v1/onnx518',
    wgsl518=BASE / 'depth75-reference-remaining-v1/wgsl518',
)
report = dict(status='prepared_only_no_native_build_or_run',
              observed_utc=datetime.now(timezone.utc).isoformat(),
              required_predecessor=dict(session=65993, terminal_and_consumed=True),
              fixture={}, cohorts={}, acceptance=False)
for name in ('Cargo.toml', 'protocol.md', 'src/main.rs'):
    report['fixture'][name] = hashlib.sha256((fixture / name).read_bytes()).hexdigest()
expected = None
for name, root in roots.items():
    raw = (root / 'measurements.json').read_bytes()
    data = json.loads(raw)
    assert data['status'] == 'completed' and len(data['samples']) == 32
    source_identity = [(v['index'], v['key']['source'], v['key']['geometry'], v['input'])
                       for v in data['samples']]
    assert [v[0] for v in source_identity] == list(range(32))
    if expected is None:
        expected = source_identity
    assert source_identity == expected
    report['cohorts'][name] = dict(root=str(root), measurements_sha256=hashlib.sha256(raw).hexdigest(),
                                   model=data['summary']['model'], execution=data['summary']['execution'],
                                   outputs=[v['output'] for v in data['samples']])
report['source_span_nanoseconds'] = expected[-1][1]['pts']['ticks'] - expected[0][1]['pts']['ticks']
target.write_text(json.dumps(report, indent=2) + '\n')
checkpoint = BASE / 'depth75-resume-current.json'
state = json.loads(checkpoint.read_text(encoding='utf-8'))
state['versionedCache75']['preparedContinuousAlignmentObservation'] = dict(
    fixture=str(fixture), frozen_inputs=str(target),
    status=report['status'], precursor_session=65993,
    source_span_nanoseconds=report['source_span_nanoseconds'],
    limitations='Existing photographic predecoded frame outputs; not actual Session switching, decoder, current inference runtime, quality-tier admission or full #75 acceptance')
state['updatedUtc'] = report['observed_utc']
checkpoint.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status=report['status'], bound_routes=len(roots),
                     bound_source_coordinates=len(expected), span_ns=report['source_span_nanoseconds'])))
