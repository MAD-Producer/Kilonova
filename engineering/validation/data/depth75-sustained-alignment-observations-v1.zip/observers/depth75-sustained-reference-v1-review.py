"""Independently summarize retained observations, only after original termination.

This does not rerun inference or turn a failed original controller into a pass.
Raw arrays and third-party reference assets remain outside distributable evidence.
"""
from pathlib import Path
import csv
import hashlib
import json
import math
import subprocess

BASE = Path('E:/Dev/aem/artifacts/pr-queue')
OUT = BASE / 'depth75-sustained-reference-v1'
WORK = Path('E:/Dev/aem/.worktrees/depth-wgsl-cache75')
PHASES = ('resolution_transform', 'resolution_native', 'prepare', 'inference', 'remap')


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def numeric(value):
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def distribution(values):
    values = sorted(values)
    if not values:
        return dict(count=0, minimum=None, p50=None, p95=None, maximum=None)
    return dict(count=len(values), minimum=values[0],
                p50=values[math.ceil(.50 * len(values)) - 1],
                p95=values[math.ceil(.95 * len(values)) - 1], maximum=values[-1])


def memory_summary(samples):
    result = {}
    for phase in ('host', *PHASES):
        observations = []
        for sample in samples:
            memory = sample.get('process_memory') or {}
            row = memory.get('host') if phase == 'host' else memory.get('children', {}).get(phase)
            observations.append(row or {})
        observed = [r for r in observations if r.get('status') == 'observed']
        result[phase] = dict(total=len(samples), observed=len(observed),
                            unavailable_or_missing=len(samples) - len(observed),
                            resident_bytes=distribution([r['peak_resident_bytes'] for r in observed]),
                            private_commit_bytes=distribution([r['peak_private_commit_bytes'] for r in observed
                                                               if r.get('peak_private_commit_bytes') is not None]))
    return result


def main():
    consumed = json.loads((OUT / 'session-consumed.json').read_text())
    assert consumed['session'] == 65993 and consumed['consumed'] is True
    receipt = json.loads((OUT / 'receipt.json').read_text())
    assert receipt['status'] != 'running' and receipt.get('completed_utc')
    # Always retain the original terminal state, including failures.
    result = dict(original_status=receipt['status'], original_exit_code=consumed['exit_code'],
                  original_cause=receipt.get('cause'), head=receipt['head'],
                  original_duration_gate=receipt.get('duration_gate'),
                  original_sampling_summary=receipt.get('sampled_summary'),
                  workload_duration_seconds=receipt.get('workload_duration_ns', 0) / 1e9,
                  percentile_convention='nearest rank; no removed warm-up, slow or loop-boundary samples',
                  limits=receipt['protocol']['limits'], raw_evidence={})
    fields = receipt['protocol']['fields']
    readings = [json.loads(line) for line in (OUT / 'readings.jsonl').read_text().splitlines()]
    assert 0 < len(readings) <= receipt['protocol']['maximum_retained_readings']
    usable, invalid = [], []
    for index, reading in enumerate(readings):
        raw = reading['raw']
        if raw.get('returncode') != 0 or raw.get('stderr') or raw.get('timeout'):
            invalid.append(dict(index=index, raw=raw))
            continue
        rows = list(csv.reader(raw['stdout'].splitlines(), skipinitialspace=True))
        assert len(rows) == 1 and len(rows[0]) == len(fields)
        values = dict(zip(fields, [v.strip() for v in rows[0]]))
        assert all(values[k] == receipt['environment']['gpu'][k] for k in ('uuid', 'name', 'driver_version'))
        usable.append(values)
    gaps = [(b['start_monotonic_ns'] - a['end_monotonic_ns']) / 1e9
            for a, b in zip(readings, readings[1:])]
    completed_gaps = [(b['end_monotonic_ns'] - a['end_monotonic_ns']) / 1e9
                      for a, b in zip(readings, readings[1:])]
    assert all(b['end_monotonic_ns'] >= b['start_monotonic_ns'] for b in readings)
    assert all(v >= 0 for v in gaps)
    result['sampling_audit'] = dict(
        total=len(readings), usable=len(usable), failed_queries=invalid,
        controller_gap_definition='next query start minus preceding query end',
        query_duration_seconds=distribution([(r['end_monotonic_ns'] - r['start_monotonic_ns']) / 1e9 for r in readings]),
        query_idle_gap_seconds=distribution(gaps),
        independent_completed_reading_gap_seconds=distribution(completed_gaps),
        independent_completed_reading_gap_within_original_five_seconds=(
            bool(completed_gaps) and max(completed_gaps) <= receipt['protocol']['maximum_sampling_gap_seconds']),
        note='Completed-reading gaps also include sensor query duration; this audit never rewrites the original outcome.')
    numeric_fields = [f for f in fields if f not in ('uuid', 'name', 'driver_version') and not f.startswith('clocks_event_reasons.')]
    result['whole_device_numeric_samples'] = {
        field: dict(available=distribution([value for row in usable if (value := numeric(row[field])) is not None]),
                    unavailable=sum(numeric(row[field]) is None for row in usable)) for field in numeric_fields}
    result['whole_device_slowdown_flags'] = {
        field: {state: sum(row[field] == state for row in usable) for state in sorted({row[field] for row in usable})}
        for field in fields if field.startswith('clocks_event_reasons.')}
    samples = []
    cohorts = []
    for record in receipt['cohorts']:
        folder = OUT / f"cohort-{record['index']:02}"
        measurements_path = folder / 'measurements.json'
        measured = json.loads(measurements_path.read_text()) if measurements_path.exists() else {}
        rows = measured.get('samples', [])
        cohorts.append(dict(index=record['index'], exit_code=record.get('exit_code'),
                            status=measured.get('status'), original_cause=measured.get('cause'),
                            completed=len(rows), measurements_sha256=digest(measurements_path) if measurements_path.exists() else None))
        for row in rows:
            output = row['output']
            path = folder / output['filename']
            assert path.stat().st_size == output['bytes'] and digest(path) == output['sha256']
            memory = row['process_memory']
            assert memory['host']['pid'] == record['pid']
            children = memory['children']
            assert children['backend'] == 'wgsl'
            expected = memory['host']['peak_resident_bytes'] + max(children[p]['peak_resident_bytes'] for p in PHASES)
            assert row['observed_resident_sum_bytes'] == expected
        samples.extend(rows)
        result['raw_evidence'][str(measurements_path.relative_to(OUT))] = digest(measurements_path) if measurements_path.exists() else None
    result['cohorts'] = cohorts
    result['completed_request_count'] = len(samples)
    timing_fields = sorted({key for row in samples for key in row if key.endswith('_ns')})
    result['request_timings_seconds'] = {
        key: distribution([row[key] / 1e9 for row in samples if key in row]) for key in timing_fields}
    result['host_and_sequential_child_memory'] = memory_summary(samples)
    result['observed_resident_sum_bytes'] = distribution([r['observed_resident_sum_bytes'] for r in samples])
    result['source_hashes_unchanged'] = all(digest(WORK / name) == value for name, value in receipt['source_sha256'].items())
    result['bound_files_unchanged'] = {name: digest(Path(name)) == value for name, value in receipt['identities'].items()}
    assert result['source_hashes_unchanged'] and all(result['bound_files_unchanged'].values())
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
    assert head == receipt['head']
    for name in ('receipt.json', 'readings.jsonl', 'events.jsonl', 'controller.py', 'session-consumed.json', 'fixed-fit-sensor-residuals.json'):
        path = OUT / name
        if path.exists():
            result['raw_evidence'][name] = digest(path)
    (OUT / 'independent-review.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('original_status', 'original_exit_code', 'completed_request_count', 'sampling_audit')}))


if __name__ == '__main__':
    main()
