"""Seal one completed cohort while the original longer workload continues."""
from pathlib import Path
from datetime import datetime, timezone
import csv
import hashlib
import json
import runpy

BASE = Path('E:/Dev/aem/artifacts/pr-queue')
OUT = BASE / 'depth75-sustained-reference-v1'
helper = BASE / 'depth75-sustained-reference-v1-review.py'
functions = runpy.run_path(str(helper))
digest, distribution = functions['digest'], functions['distribution']
destination = OUT / 'first-cohort-review.json'
assert not destination.exists(), 'Do not overwrite an original observation'
receipt = json.loads((OUT / 'receipt.json').read_text())
record = receipt['cohorts'][0]
assert record['index'] == 0 and record['exit_code'] == 0
measured_path = OUT / 'cohort-00/measurements.json'
measured = json.loads(measured_path.read_text())
assert measured['status'] == 'completed' and len(measured['samples']) == 32
rows = measured['samples']
assert [row['index'] for row in rows] == list(range(32))
assert all(row['process_memory']['host']['pid'] == record['pid'] for row in rows)
for row in rows:
    output = row['output']
    path = OUT / 'cohort-00' / output['filename']
    assert path.stat().st_size == output['bytes'] and digest(path) == output['sha256']
    memory = row['process_memory']
    assert memory['host']['status'] == 'observed' and memory['children']['backend'] == 'wgsl'
    assert all(memory['children'][p]['status'] == 'observed' for p in functions['PHASES'])
    total = memory['host']['peak_resident_bytes'] + max(memory['children'][p]['peak_resident_bytes'] for p in functions['PHASES'])
    assert row['observed_resident_sum_bytes'] == total
assert not (OUT / 'cohort-00.stdout.log').read_bytes()
raw = (OUT / 'readings.jsonl').read_bytes()
assert raw.endswith(b'\n')
readings = [json.loads(line) for line in raw.splitlines()]
fields = receipt['protocol']['fields']
values = []
for reading in readings:
    result = reading['raw']
    assert result.get('returncode') == 0 and not result['stderr']
    csv_rows = list(csv.reader(result['stdout'].splitlines(), skipinitialspace=True))
    assert len(csv_rows) == 1 and len(csv_rows[0]) == len(fields)
    value = dict(zip(fields, [v.strip() for v in csv_rows[0]]))
    assert all(value[k] == receipt['environment']['gpu'][k] for k in ('uuid', 'name', 'driver_version'))
    values.append(value)
gaps = [(b['end_monotonic_ns'] - a['end_monotonic_ns']) / 1e9 for a, b in zip(readings, readings[1:])]
temps = [functions['numeric'](v['temperature.gpu']) for v in values]
report = dict(
    status='one_complete_cohort_verified_original_sustained_workload_still_pending',
    observed_utc=datetime.now(timezone.utc).isoformat(), head=receipt['head'],
    original_controller_session=65993, original_controller_consumed=False,
    first_cohort_exit_code=0, requests=32, host_and_child_observations=192,
    measurements_sha256=digest(measured_path), review_helper_sha256=digest(helper),
    preserved_readings_prefix_sha256=hashlib.sha256(raw).hexdigest(),
    preserved_readings_prefix_bytes=len(raw), prefix_readings=len(readings),
    whole_device_temperature_celsius=distribution([t for t in temps if t is not None]),
    completed_reading_gap_seconds=distribution(gaps),
    request_timings_seconds={key: distribution([row[key] / 1e9 for row in rows])
                             for key in sorted(rows[0]) if key.endswith('_ns')},
    host_and_sequential_child_memory=functions['memory_summary'](rows),
    observed_resident_sum_bytes=distribution([row['observed_resident_sum_bytes'] for row in rows]),
    limits=receipt['protocol']['limits'],
    duration_gate=None, complete_sustained_acceptance=False,
    source_freeze_remains=True,
)
destination.write_text(json.dumps(report, indent=2) + '\n')
checkpoint = BASE / 'depth75-resume-current.json'
state = json.loads(checkpoint.read_text(encoding='utf-8'))
state['versionedCache75']['sustainedReferenceValidation'].update(
    first_cohort_review=str(destination), first_cohort_requests=32,
    first_cohort_observations=192, review_helper=str(helper),
    no_second_heavy_workload=True)
state['updatedUtc'] = report['observed_utc']
state['lastGoalTurnClassification'] = 'progress: original65993 still running, first complete32-request cohort independently verified with192 actual host/child observations; no second workload or source mutation; terminal review helper prepared and control-checked; original sustained duration remains pending'
checkpoint.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: report[k] for k in ('status', 'requests', 'host_and_child_observations', 'request_timings_seconds', 'completed_reading_gap_seconds')}))
