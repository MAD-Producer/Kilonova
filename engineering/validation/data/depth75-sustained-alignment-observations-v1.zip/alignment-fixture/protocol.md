# Continuous source-coordinate alignment observation

Freeze this protocol and fixture hashes before executing it. Wait for original
sustained controller 65993 and its actual child to terminate and consume the
original handle before starting this build or native calculation. One owned
heavy workload only. All output and compilation stay on E.

Use all existing 32 consecutive photographed RGB source coordinates, spanning
1.032 seconds in their original source clock. Reuse the sealed actual CPU266,
CPU392, CPU518 and WGSL518 outputs; do not infer again, change source pixels,
resolutions, prepared fingerprints, model identities or clocks. These are
retained predecoded photographic-frame results, not a new decoder or current
inference-runtime qualification. Bind every original measurement and plane hash.

CPU518 is the declared reference. Evaluate CPU266 and CPU392 independently and
use same-weight WGSL518 as a separate backend control. A resolution is not a
quality tier. Do not fit neighboring or future frames together. Call the actual
current Rust Alignment::fit and bind its proof to those exact reconstructed
resource instances. Before the call, verify exact source/geometry/prepared RGB
identity, complete index order, output size, digest and finite scalar values.

The explicit research limits are: minimum 1,024 fitting pairs, 10,000 held-out
pairs, full paired coverage, no confidence claim, reference standard deviation
at least 1e-8, positive scale in [0.1, 10], normalized RMS at most 0.01 and maximum
at most 0.05. Residual normalization is the product implementation's fitting
reference standard deviation. These are predeclared research ceilings, not
independently qualified user/application quality limits. Do not change them,
retry a failed execution, remove rejected frames, or advertise accepted affine
fits as independently qualified model quality.

Retain every actual typed rejection, fitted coefficient and successful-fit
statistics. For adjacent accepted frames only, also report change in aligned
candidate-minus-reference residual at the same scalar coordinates, normalized
by the current reference fitting standard deviation. A rejected frame breaks
the adjacency: do not bridge it. This is additional source-grid temporal change
relative to the complete CPU518 baseline, not scene-flow correspondence, sensor
truth, an accepted transition-jump budget or actual Session switching.

Successful tool execution means all source records were inspected, including
rejections. It does not mean cross-resolution transitions passed. Preserve raw
logs and failures; default Info starts precede reads/alignment, Error goes to
file and stderr, stdout remains empty. Do not publish learned planes, model
weights, third-party photographs or executable binaries. Android, panels,
automatic tier selection, product behavior and original thresholds are unchanged.
