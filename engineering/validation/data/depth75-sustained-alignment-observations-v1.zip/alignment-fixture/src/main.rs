use motion_host::depth::{
    alignment::{Alignment, Limits},
    Key,
};
use motion_model::depth::{DepthDescriptor, DepthMeasure, DepthResource, NearDirection};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    error::Error,
    fs,
    io::Read,
    path::{Path, PathBuf},
    time::Instant,
};

#[path = "E:/Dev/aem/.worktrees/depth-wgsl-cache75/desktop/app/src/logging/sink.rs"]
mod logging;
mod engine {
    pub fn current_command() -> Option<(u64, &'static str, std::time::Duration)> {
        None
    }
}
type Result<T> = std::result::Result<T, Box<dyn Error>>;
const PIXELS: usize = 640 * 480;

fn require(value: bool, cause: &'static str) -> Result<()> {
    if value {
        Ok(())
    } else {
        Err(cause.into())
    }
}
fn read(path: &Path, maximum: usize) -> Result<Vec<u8>> {
    let mut bytes = Vec::new();
    fs::File::open(path)?
        .take(maximum as u64 + 1)
        .read_to_end(&mut bytes)?;
    require(bytes.len() <= maximum, "bounded input exceeded")?;
    Ok(bytes)
}
fn hex(bytes: &[u8]) -> String {
    bytes.iter().map(|v| format!("{v:02x}")).collect()
}
fn plan(root: &Path) -> Result<Value> {
    let bytes = read(&root.join("measurements.json"), 4 << 20)?;
    let value: Value = serde_json::from_slice(&bytes)?;
    require(
        value["status"] == "completed",
        "original inference not completed",
    )?;
    let rows = value["samples"].as_array().ok_or("missing samples")?;
    require(rows.len() == 32, "complete original32 cohort required")?;
    for (index, row) in rows.iter().enumerate() {
        require(
            row["index"].as_u64() == Some(index as u64),
            "original source order differs",
        )?;
        let key: Key = serde_json::from_value(row["key"].clone())?;
        if index > 0 {
            let previous: Key = serde_json::from_value(rows[index - 1]["key"].clone())?;
            require(
                key.source.pts.ticks > previous.source.pts.ticks
                    && key.source.pts.timescale == previous.source.pts.timescale,
                "original source clock not ordered",
            )?;
        }
    }
    Ok(value)
}
fn resource(root: &Path, row: &Value) -> Result<DepthResource> {
    let key: Key = serde_json::from_value(row["key"].clone())?;
    let index = row["index"].as_u64().ok_or("index required")?;
    let name = format!("{index:02}.relative.f32le");
    require(
        row["output"]["filename"] == name && row["output"]["bytes"] == (PIXELS * 4) as u64,
        "original plane contract differs",
    )?;
    let bytes = read(&root.join(name), PIXELS * 4)?;
    require(
        bytes.len() == PIXELS * 4 && row["output"]["sha256"] == hex(&Sha256::digest(&bytes)),
        "plane size/digest differs",
    )?;
    let values: Vec<f32> = bytes
        .chunks_exact(4)
        .map(|v| f32::from_le_bytes([v[0], v[1], v[2], v[3]]))
        .collect();
    DepthResource::new(
        DepthDescriptor {
            size: [640, 480],
            source: key.source,
            geometry: key.geometry,
            model: key.model,
            measure: DepthMeasure::Relative {
                near: NearDirection::Increasing,
            },
            scale: 1.,
            offset: 0.,
            valid_range: None,
        },
        values,
        None,
        None,
    )
    .map_err(Into::into)
}
fn limits() -> Limits {
    Limits {
        minimum_fit_pairs: 1024,
        minimum_validation_pairs: 10_000,
        minimum_pair_fraction: 1.,
        minimum_confidence: None,
        minimum_reference_stddev: 1e-8,
        scale_bounds: [0.1, 10.],
        maximum_normalized_rms: 0.01,
        maximum_normalized_error: 0.05,
    }
}
fn evaluate(reference_root: &Path, candidate_root: &Path, output: &Path) -> Result<()> {
    log::info!("start operation=continuous_alignment phase=read_plans");
    log::logger().flush();
    let reference_plan = plan(reference_root)?;
    let candidate_plan = plan(candidate_root)?;
    let mut rows = Vec::new();
    let mut preceding_residual: Option<Vec<f64>> = None;
    for index in 0..32 {
        let began = Instant::now();
        log::info!(
            "start #{} operation=continuous_alignment phase=read_planes index={index}",
            index + 1
        );
        log::logger().flush();
        let r = &reference_plan["samples"][index];
        let c = &candidate_plan["samples"][index];
        require(
            r["key"]["source"] == c["key"]["source"]
                && r["key"]["geometry"] == c["key"]["geometry"]
                && r["input"] == c["input"],
            "different source, geometry or prepared RGB",
        )?;
        let reference = resource(reference_root, r)?;
        let candidate = resource(candidate_root, c)?;
        log::info!(
            "start #{} operation=continuous_alignment phase=fit index={index}",
            index + 1
        );
        log::logger().flush();
        let mut row = json!({"index":index,"source":r["key"]["source"],
            "reference_output":r["output"],"candidate_output":c["output"],
            "additional_source_grid_change":null});
        match Alignment::fit(&reference, &candidate, limits(), || false) {
            Ok(proof) => {
                let aligned = proof.bind(&reference, &candidate)?;
                let stats = proof.statistics();
                let residual: Vec<f64> = (0..PIXELS)
                    .map(|i| -> Result<f64> {
                        Ok(aligned.sample(i)?.ok_or("missing aligned scalar")?
                            - reference.sample(i).ok_or("missing reference scalar")?)
                    })
                    .collect::<Result<_>>()?;
                if let Some(previous) = preceding_residual.take() {
                    let mut square = 0.;
                    let mut maximum = 0f64;
                    for (a, b) in residual.iter().zip(previous) {
                        let delta = (a - b) / stats.reference_stddev;
                        square += delta * delta;
                        maximum = maximum.max(delta.abs());
                    }
                    require(
                        square.is_finite() && maximum.is_finite(),
                        "nonfinite temporal residual",
                    )?;
                    row["additional_source_grid_change"] = json!({"pairs":PIXELS,
                        "normalized_rms":(square/PIXELS as f64).sqrt(),"normalized_maximum":maximum});
                }
                row["status"] = "accepted_under_research_limits".into();
                row["coefficients"] = json!(proof.coefficients());
                row["statistics"] = json!({"pixels":stats.pixels,"fit_pairs":stats.fit_pairs,
                    "validation_pairs":stats.validation_pairs,"skipped_pairs":stats.skipped_pairs,
                    "reference_stddev":stats.reference_stddev,"fit_normalized_rms":stats.fit_normalized_rms,
                    "fit_normalized_maximum":stats.fit_normalized_maximum,
                    "validation_normalized_rms":stats.validation_normalized_rms,
                    "validation_normalized_maximum":stats.validation_normalized_maximum});
                preceding_residual = Some(residual);
            }
            Err(cause) => {
                log::warn!("operation=continuous_alignment index={index} phase=fit cause={cause}");
                row["status"] = "rejected".into();
                row["cause"] = cause.to_string().into();
                row["typed_rejection"] = format!("{cause:?}").into();
                preceding_residual = None;
            }
        }
        row["elapsed_ns"] = json!(began.elapsed().as_nanos());
        rows.push(row);
        let report = json!({"status":if index==31 {"complete_observation_not_tier_qualification"} else {"running"},
            "limits":limits(),"frames":rows,"reference_root":reference_root,"candidate_root":candidate_root,
            "reference_measurements_sha256":hex(&Sha256::digest(read(&reference_root.join("measurements.json"),4<<20)?)),
            "candidate_measurements_sha256":hex(&Sha256::digest(read(&candidate_root.join("measurements.json"),4<<20)?))});
        fs::write(
            output.join("observations.json"),
            serde_json::to_vec_pretty(&report)?,
        )?;
    }
    Ok(())
}
fn main() -> Result<()> {
    let args: Vec<PathBuf> = std::env::args_os().skip(1).map(PathBuf::from).collect();
    require(
        args.len() == 3 && args.iter().all(|p| p.is_absolute()),
        "usage: absolute REFERENCE_DIRECTORY CANDIDATE_DIRECTORY OUTPUT_DIRECTORY",
    )?;
    fs::create_dir(&args[2])?;
    let _guard = logging::init(args[2].join("logs"))?;
    if let Err(primary) = evaluate(&args[0], &args[1], &args[2]) {
        log::error!("operation=continuous_alignment phase=observe cause={primary}");
        return Err(primary);
    }
    log::info!(
        "operation=continuous_alignment phase=complete inspected32=true qualification=false"
    );
    log::logger().flush();
    Ok(())
}
