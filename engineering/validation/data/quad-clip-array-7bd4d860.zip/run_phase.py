from pathlib import Path
import hashlib,json,os,subprocess,sys,time
out=Path(__file__).resolve().parent; work=Path.cwd(); phase=sys.argv[1]
assert work==Path('E:/Dev/aem/.worktrees/quad-clip-array') and phase in ['before','after']
assert not (out/(phase+'-receipt.json')).exists()
source=work/'desktop/ui/src/paint.rs'; source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
example=work/'desktop/ui/examples/quad_clip_comparison.rs'
if not example.exists():example.write_bytes((out/'comparison.rs').read_bytes())
assert example.read_bytes()==(out/'comparison.rs').read_bytes()
commands=[['cargo','run','-p','motion-ui','--example','quad_clip_comparison','--no-default-features','--locked','--offline','-j1','--',str(out/(phase+'.json'))]]
if phase=='after':commands.append(['cargo','test','-p','motion-ui','--locked','--offline','-j1','--','--test-threads=1'])
env=os.environ.copy();env['CARGO_TERM_COLOR']='never';records=[]
for i,cmd in enumerate(commands):
    path=out/(phase+('-comparison' if i==0 else '-regressions')+'.log');start=time.monotonic()
    with path.open('w',encoding='utf-8') as log:result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    record=dict(command=cmd,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),log_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    records.append(record)
    (out/(phase+'-receipt.json')).write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_sha256=source_hash,source_unchanged=hashlib.sha256(source.read_bytes()).hexdigest()==source_hash,commands=records),indent=2),encoding='utf-8')
    assert result.returncode==0,record
    print(json.dumps(record),flush=True)
