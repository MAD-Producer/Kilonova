from pathlib import Path
import hashlib,json,re,subprocess,zipfile
out=Path(__file__).resolve().parent;work=Path('E:/Dev/aem/.worktrees/quad-clip-array');dest=work/'engineering/validation'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads((out/p).read_text(encoding='utf-8'))
before=read('before-receipt.json');after=read('after-receipt.json');comparison=read('comparison.json')
assert before['source_unchanged'] and after['source_unchanged'] and len(after['commands'])==2
assert all(c['exit_code']==0 for r in [before,after] for c in r['commands'])
assert digest(work/'desktop/ui/src/paint.rs')==after['source_sha256']
old=(out/'before-paint.rs').read_text(encoding='utf-8');new=(work/'desktop/ui/src/paint.rs').read_text(encoding='utf-8')
assert old.count('Shape::Quad { points } => expand_quad(*points).to_vec(),')==1
assert new==old.replace('Shape::Quad { points } => expand_quad(*points).to_vec(),','Shape::Quad { points } => expand_quad(*points),')
log=(out/'after-regressions.log').read_text(encoding='utf-8');chunks=re.split(r'(?m)^((?: {5}Running | {3}Doc-tests )[^\r\n]+)',log)
targets=[]
for i in range(1,len(chunks),2):
    rows=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',chunks[i+1],re.M)
    assert len(rows)==1,(chunks[i],rows)
    state,passed,failed,ignored=rows[0];assert state=='ok' and failed==ignored=='0'
    targets.append(dict(target=chunks[i].strip(),passed=int(passed),failed=0,ignored=0))
assert len(targets)>=21
total=sum(t['passed'] for t in targets)
items=['comparison.rs','run_phase.py','package_evidence.py','before-paint.rs','before.json','after.json','comparison.json','before-receipt.json','after-receipt.json','before-comparison.log','after-comparison.log','after-regressions.log']
archive=dest/'data/quad-clip-array-7bd4d860.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in items:z.write(out/name,name)
record=dict(issue=129,base=before['head'],before=before,after=after,comparison=comparison,targets=targets,
            total_passed=total,archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=digest(archive)))
(dest/'quad-clip-array-results.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rows='\n'.join(f"| {r['case']} | {r['before']} | {r['after']} |" for r in comparison['cases'])
doc=f'''# 四边形裁剪临时数组验收

2026-10-25，基线 `7bd4d86003b21dd02483e73cbccac730df7036a7`，关联 #129。本次只删除 `expand_quad` 后的一次 `to_vec()`；六个展开顶点改用定长数组，继续借用为切片交给原来的裁剪函数。输出三角形仍按原逻辑分配，不改变算法、几何、颜色、顺序或 API，不宣称裁剪零分配。

开始前检查 412 个引用、120 个工作树及 4 个相关裁剪版本，并复核 #129 timeline 与开放 PR。既有 #475 仅为完全可见的三角形提供快路，#487 复用索引表；没有本次方案。其他两个工作树中的 paint.rs 改动均未修改此处。随后开放的 #492 是 motion-render 重绘列表，与本批文件不同。

## 实际对照

相同独立临时程序分别在未改与修改后的源码运行，每组 64 个新建四边形，夹具、断言与序列化在计数区间外；线程局部 System 分配计数器只覆盖一次实际 `PaintList::clip_to`。记录为 Rust alloc / alloc_zeroed / realloc 请求，不是全桌面帧率或全部原生分配。

| 场景 | 原请求数 | 修改后请求数 |
| --- | --- | --- |
{rows}

四种需要进入裁剪分支的场景各减少 64 次请求，即每个四边形少一次临时分配。完全在内和恰好接触最大边界的两组对照原本已为零，保持零。六组的全部顶点、颜色及绘制顺序逐项完全相同；检查裁剪顶点有限且位于矩形内。完整输入/输出和计数见 [结果记录](quad-clip-array-results.json)。

## 回归与范围

完整 `motion-ui` 默认启用 GPU 测试，在 Windows 本机串行执行：{len(targets)} 个目标或文档测试入口，{total} 通过、0 失败、0 忽略；既有断言不变，包含 8 项裁剪、文字边界、描边 DPI、实际绘制、图集和失败观察。该回归是已有覆盖的复验，未新增永久测试；也不将现有 GPU 像素回归冒充本轮前后截图对照。前后源码散列、命令、退出码和完整日志见 [原始材料](data/{archive.name})，SHA-256 `{digest(archive)}`。

| ID | 分类与处置 |
| --- | --- |
| QCA-01 | 新增局部优化：移除每个需裁剪四边形的一次临时堆分配；最终三角形输出的分配保留。 |
| QCA-02 | 既有覆盖：原裁剪算法、可见快路、绘制顺序和 GPU 绘制回归复验，不计为本次新功能。 |
| QCA-03 | 错误与正常分支保持：无日志、错误结构、重试、panic 捕获、线程或返回值改动；没有认领新的默认级别观测修复。 |
| QCA-04 | 设计范围保持：不改 panels、token、尺寸、属性行或命中区；DESIGN §0.7 各行 retained with reason，改动不涉及其文件。§12 全产品视觉验收未由本轮完成。 |
| QCA-05 | 待后续：#129 的文字 shaping、其他分配与平台边界仍开放，不关闭合集。 |

没有新增依赖、第三方资产或兼容名称。归档仅含独立夹具、自产数据、源码与日志，无可执行文件、DLL 或 Adobe 资源。
'''
(dest/'quad-clip-array-completed.md').write_text(doc,encoding='utf-8')
body=f'''四边形进入裁剪分支时，直接使用展开后的定长数组，省去一次临时堆分配。保持原裁剪算法、输出顶点、颜色与绘制顺序。

验证：六组各 64 个四边形的前后对照，需裁剪的四组均少 64 次分配请求，全部几何与顺序一致；两个已有零分配快路保持零。完整 motion-ui：{total} 通过、0 失败、0 忽略，包括实际 GPU 绘制与 8 项裁剪回归，已有断言不变。

原始报告与日志见 engineering/validation/quad-clip-array-completed.md。不添加依赖、素材、样式或交互修改；最终输出分配仍保留，不关闭合集。

Refs #129
'''
(out/'pr-body.md').write_text(body,encoding='utf-8')
print(json.dumps(dict(passed=total,targets=len(targets),cases=comparison['cases'],archive=record['archive']),ensure_ascii=False))
