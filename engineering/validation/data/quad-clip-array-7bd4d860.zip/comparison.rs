use motion_ui::{paint::{PaintList, PaintOp, Shape}, Color, Rect};
use std::{alloc::{GlobalAlloc, Layout, System}, cell::Cell};
thread_local! { static COUNT: Cell<Option<usize>> = const { Cell::new(None) }; }
struct Allocator;
fn note() { let _=COUNT.try_with(|c| if let Some(n)=c.get() { c.set(Some(n.saturating_add(1))); }); }
unsafe impl GlobalAlloc for Allocator {
    unsafe fn alloc(&self,l:Layout)->*mut u8 {let p=unsafe{System.alloc(l)};if !p.is_null(){note();}p}
    unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8 {let p=unsafe{System.alloc_zeroed(l)};if !p.is_null(){note();}p}
    unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {let p=unsafe{System.realloc(p,l,n)};if !p.is_null(){note();}p}
    unsafe fn dealloc(&self,p:*mut u8,l:Layout){unsafe{System.dealloc(p,l)}}
}
#[global_allocator] static ALLOCATOR:Allocator=Allocator;
fn main() {
    let out=std::path::PathBuf::from(std::env::args_os().nth(1).expect("output"));
    let mut result=Vec::new();
    for (name,points) in [
        ("left",[[-2.,2.],[4.,2.],[4.,6.],[-2.,6.]]),
        ("corner",[[-2.,-2.],[4.,-2.],[4.,4.],[-2.,4.]]),
        ("outside",[[-5.,2.],[-1.,2.],[-1.,6.],[-5.,6.]]),
        ("rotated",[[5.,-2.],[12.,5.],[5.,12.],[-2.,5.]]),
        ("contained",[[2.,2.],[6.,2.],[6.,6.],[2.,6.]]),
        ("max_edge",[[2.,2.],[10.,2.],[10.,6.],[2.,6.]]),
    ] {
        let mut list=PaintList::default();
        for _ in 0..64 {list.push_shape(Shape::Quad{points},Color::grey(120));}
        COUNT.with(|c|c.set(Some(0)));
        std::hint::black_box(&mut list).clip_to(Rect::new(0.,0.,10.,10.));
        let count=COUNT.with(|c|c.replace(None).unwrap());
        let shapes:Vec<_>=list.shapes.iter().map(|s|match s {
            Shape::Quad{points}=>serde_json::json!({"quad":points}),
            Shape::Triangles{points}=>{
                assert!(points.iter().all(|p|p.iter().all(|v|v.is_finite()) && p[0]>=0. && p[0]<=10. && p[1]>=0. && p[1]<=10.));
                serde_json::json!({"triangles":points})
            }, _=>panic!("unexpected geometry"),
        }).collect();
        let order:Vec<_>=list.order.iter().map(|o|match o {PaintOp::Shape(i)=>*i,_=>panic!("unexpected glyph")}).collect();
        assert_eq!(list.colors.len(),list.shapes.len());
        assert_eq!(order,(0..list.shapes.len()).collect::<Vec<_>>());
        result.push(serde_json::json!({"case":name,"input_quads":64,"allocations":count,"shapes":shapes,"order":order,"colors":format!("{:?}",list.colors)}));
    }
    std::fs::write(out,serde_json::to_vec_pretty(&result).unwrap()).unwrap();
}
