"""Consume original session73737 after its terminal tool result, without inference."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,subprocess
ROOT=Path('E:/Dev/aem'); ART=ROOT/'artifacts/pr-queue'; OUT=ART/'depth75-rust-remap-v1'
WORK=ROOT/'.worktrees/depth-retained-context75'; CP=ART/'depth75-resume-current.json'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=read(OUT/'receipt.json'); assert r['status']=='host_remap_fixed32_exact_output_passed_not_qualified'
assert all(c['exit_code']==0 for c in r['commands']) and r['source_unchanged']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==r['source_head']
for n,h in r['changed_source_sha256'].items():assert sha(WORK/n)==sha(OUT/'frozen-source'/n)==h
m=read(OUT/'cohort/measurements.json'); cold=ART/'depth75-sustained-reference-v1/cohort-00'
c=read(cold/'measurements.json'); assert len(m['samples'])==len(c['samples'])==32
for a,b in zip(m['samples'],c['samples']):
 p=OUT/'cohort'/a['output']['filename']; q=cold/b['output']['filename']
 assert sha(p)==a['output']['sha256']==b['output']['sha256'] and p.read_bytes()==q.read_bytes()
assert not (OUT/'actual-cohort.stdout.log').read_bytes()
assert not list((OUT/'cohort/scratch').iterdir())
consumed=dict(session=73737,exit_code=0,original_tool_result_consumed=True,
 original_chunk_id='8a7c49',source_unchanged=True,complete_float32_byte_pairs=32,
 observed_utc=datetime.now(timezone.utc).isoformat(),qualified=False,original_python_failure_retained=True)
write(OUT/'session-consumed.json',consumed)
state=read(CP);v=state['versionedCache75']
assert v['activeController']==str(ART/'depth75-rust-remap-v1-controller.py')
v.update(activeController=None,ownHeavyWorkloads=[],rustRemapOriginal=consumed,
 rustRemapOutput=str(OUT),nativeFaultFixed=False)
write(CP,state)
print(json.dumps(consumed))
