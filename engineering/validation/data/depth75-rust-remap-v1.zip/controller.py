"""Original controls for the explicit host-remap mode; no retry of the old Python mode."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,math,os,shutil,subprocess,time,traceback
ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-retained-context75'
OUT=ART/'depth75-rust-remap-v1';TARGET=ROOT/'target/depth-wgsl-cache75-contract'
INPUTS=ART/'depth75-reference-inputs-v1';COLD=ART/'depth75-sustained-reference-v1/cohort-00'
CP=ART/'depth75-resume-current.json'
FILES={'crates/motion-host/examples/depth_reference.rs','crates/motion-host/src/depth/wgsl.rs',
 'crates/motion-host/src/depth/wgsl/identity.rs','crates/motion-host/src/depth/wgsl/rust_remap.rs',
 'crates/motion-host/src/process_memory.rs'}
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=WORK,text=True).strip()
def now():return datetime.now(timezone.utc).isoformat()
def source():
    changed=set(git('diff','--name-only').splitlines())
    changed.update(git('ls-files','--others','--exclude-standard').splitlines())
    assert changed==FILES
    return {n:sha(WORK/n) for n in sorted(FILES)}
assert shutil.disk_usage(ROOT).free>=10<<30
state=read(CP);v=state['versionedCache75'];assert v['activeController'] is None and not v['ownHeavyWorkloads']
assert read(ART/'depth75-retained-cohort-v1/session-consumed.json')['exit_code']==1
head=git('rev-parse','HEAD');assert head=='870693eb95e1d637a7388e51a522e03164e58e11'
bindings=source();fixture=read(ART/'depth75-live-session-v2/fixture.json')
worker=Path(fixture['worker']);worker_sha=sha(worker)
assert worker_sha=='033b161c1789a09011162630a24430e79271b27bcddc3bb64f39986bbdef1158'
assert read(INPUTS/'receipt.json')['inputs_sha256']==sha(INPUTS/'inputs.json')
inputs=read(INPUTS/'inputs.json');cold=read(COLD/'measurements.json')
assert len(inputs)==32 and cold['status']=='completed' and len(cold['samples'])==32
for i,row in enumerate(inputs):
    assert row['index']==i and sha(INPUTS/row['rgb_input']['filename'])==row['rgb_input']['sha256']
    assert sha(COLD/cold['samples'][i]['output']['filename'])==cold['samples'][i]['output']['sha256']
OUT.mkdir(exist_ok=False);shutil.copyfile(__file__,OUT/'controller.py')
for name in FILES:
    dest=OUT/'frozen-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WORK/name,dest)
env=os.environ.copy();env.pop('MOTION_LOG',None)
ff=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='1',
    CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),
    LOCALAPPDATA=str(OUT/'appdata'),RUST_BACKTRACE='full',PYTHONDONTWRITEBYTECODE='1',
    LIBCLANG_PATH=str(ROOT/'.tools/python-libclang/clang/native'),FFMPEG_DIR=str(ff),FFMPEG_INCLUDE_DIR=str(ff/'include'),FFMPEG_LIB_DIR=str(ff/'lib'))
env['PATH']=str(ff/'bin')+os.pathsep+env['PATH'];Path(env['LOCALAPPDATA']).mkdir()
report=dict(status='running',source_head=head,changed_source_sha256=bindings,worker_sha256=worker_sha,
    input_plan_sha256=sha(INPUTS/'inputs.json'),cold_measurements_sha256=sha(COLD/'measurements.json'),
    started_utc=now(),commands=[],protocol=dict(samples=32,order='original fixed32, no warmup deletion or retries',
        output_comparison='every complete float32 output must match sealed cold bytes exactly',request_wait_seconds=60,
        selected_mode='explicit retained GPU plus Rust host remap; Python preparation still active',
        limits=['Original Python-mode request28 fatal access violation remains failed and is not rerun',
            'Successful changed-mode controls cannot diagnose or waive the original native root cause',
            'No qualified device/tier, complete memory, sustained/thermal or cross-quality promise',
            'No Android, panels, downloads, third-party inspection or foreign process changes']))
v.update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(kind='host-remap source controls and actual fixed32',output=str(OUT),sourceFrozen=True)])
write(CP,state)
def frozen():return git('rev-parse','HEAD')==head and source()==bindings and sha(worker)==worker_sha
def save():write(OUT/'receipt.json',report)
def command(label,args):
    item=dict(label=label,args=[str(a) for a in args],started_utc=now());report['commands'].append(item);save();t=time.monotonic()
    with (OUT/(label+'.stdout.log')).open('wb') as stdout,(OUT/(label+'.stderr.log')).open('wb') as stderr:
        p=subprocess.run(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
    item.update(exit_code=p.returncode,elapsed_seconds=time.monotonic()-t);save()
    assert p.returncode==0 and frozen(),item
def distribution(rows,field):
    n=sorted(r[field]/1e9 for r in rows)
    return dict(minimum=n[0],median=(n[15]+n[16])/2,p95_nearest_rank=n[math.ceil(.95*32)-1],maximum=n[-1])
start=time.monotonic()
try:
    for label,selection in [('wgsl-components','depth::wgsl::'),('memory-components','process_memory::')]:
        command(label,['cargo','test','-p','motion-host','--features','ai-depth','--lib',selection,'--locked','--offline','--','--test-threads=1'])
    command('example-tests',['cargo','test','-p','motion-host','--features','ai-depth','--example','depth_reference','--locked','--offline','--','--test-threads=1'])
    command('example-build',['cargo','build','-p','motion-host','--features','ai-depth','--example','depth_reference','--locked','--offline'])
    driver=TARGET/'debug/examples/depth_reference.exe';report['driver_sha256']=sha(driver)
    model=ART/'depth75-resolution-models-v1/518/export/depth_anything_v2_vits_518.onnx'
    command('actual-cohort',[str(driver),'wgsl-retained-rust-remap',fixture['python'],str(model),fixture['program'],str(worker),str(INPUTS),str(OUT/'cohort')])
    measured=read(OUT/'cohort/measurements.json');assert measured['status']=='completed' and len(measured['samples'])==32
    summary=measured['summary'];assert summary['submitted']==summary['completed']==32
    assert all(summary[k]==0 for k in ('failed','canceled','cache_hits','cache_misses','restored'))
    assert not (OUT/'actual-cohort.stdout.log').read_bytes()
    rows=measured['samples'];pids=set();pairs=[]
    for i,row in enumerate(rows):
        assert row['index']==i and row['split']==inputs[i]['split']
        output=OUT/'cohort'/row['output']['filename'];assert output.stat().st_size==640*480*4
        assert sha(output)==row['output']['sha256']==cold['samples'][i]['output']['sha256']
        memory=row['process_memory'];assert memory['children']['backend']=='wgsl_retained_host_remap'
        assert row['observed_resident_sum_bytes'] is None and row['retained_gpu_buffer_capacity_bytes']==227968156
        child=memory['children'];pids.add(child['inference']['pid'])
        assert child['host_remap']['pid']==memory['host']['pid']!=child['inference']['pid']
        assert 'remap' not in child and row['worker_total_ns']>=row['resolve_ns']>0
        pairs.append(dict(index=i,sha256=row['output']['sha256'],exact=True))
    log=(OUT/'cohort/logs/motion-studio.log').read_text(encoding='utf-8')
    assert log.count('phase=remap_rust start')==32 and 'phase=remap start' not in log
    assert len(pids)==1 and not list((OUT/'cohort/scratch').iterdir())
    report.update(status='host_remap_fixed32_exact_output_passed_not_qualified',native_pids=sorted(pids),
        complete_output_pairs=pairs,worker_seconds=distribution(rows,'worker_total_ns'),remap_seconds=distribution(rows,'postprocess_ns'),
        inference_seconds=distribution(rows,'inference_ns'),measurements_sha256=sha(OUT/'cohort/measurements.json'),
        all_owned_service_directories_removed=True)
except BaseException:
    report.update(status='failed_original_outcome_retained',failure=traceback.format_exc())
finally:
    report.update(source_unchanged=frozen(),elapsed_seconds=time.monotonic()-start,completed_utc=now());save()
    print(json.dumps(dict(status=report['status'],commands=report['commands'],source_unchanged=report['source_unchanged'])))
raise SystemExit(0 if report['status']=='host_remap_fixed32_exact_output_passed_not_qualified' else 1)
