from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/shared-model-catalog'
gate = root / 'artifacts/pr-queue/imported-camera-activation-native-v1'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
r = json.loads((gate/'accepted.json').read_text(encoding='utf-8'))
assert r['sourceUnchanged'] and all(sha(work/p) == h for p,h in r['source'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip() == r['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work).strip()
assert all(s['exitCode'] == 0 and s['sourceUnchanged'] for s in r['steps'])
counts = {s['name']:s['totals'] for s in r['steps'] if 'totals' in s}
assert all(v['failed'] == 0 and v['ignored'] == 0 for v in counts.values())
assert sum(v['passed'] for v in counts.values()) == 646
out = root/'artifacts/pr-queue/imported-camera-activation-complete-v1'
out.mkdir(exist_ok=False)
archive = work/'engineering/validation/data/imported-camera-activation-native-v1.zip'
payload = {p.relative_to(gate).as_posix():p.read_bytes() for p in gate.rglob('*') if p.is_file()}
payload['completion-controller.py'] = Path(__file__).read_bytes()
payload['source.patch'] = subprocess.check_output(['git','diff','--binary',r['main'],r['head']],cwd=work)
manifest = {k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in payload.items()}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for k,v in payload.items(): z.writestr(k,v)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(manifest)+1
    for k,v in manifest.items():
        data = z.read(k)
        assert len(data) == v['bytes'] and hashlib.sha256(data).hexdigest() == v['sha256']
doc = work/'engineering/validation/imported-camera-activation-current.md'
text = doc.read_text(encoding='utf-8')
old = '''New controlled CPU and real GPU tests have passed initial focused runs. A frozen
source gate against the current main baseline is pending. Initial runs are not a
full-workspace, cross-platform or final issue acceptance claim.'''
assert old in text
text = text.replace(old,'''Source-bound local acceptance has **646 passed, 0 failed, 0 ignored**:
93 motion-model tests across 23 targets (including doc tests), 80 affected core
tests across 15 targets, 448 native renderer tests across 18 targets, and 25 host
tests across six targets. Desktop FFmpeg/AI-depth compilation, provenance and
panel-style checks also pass. Eleven new tests comprise three core, six native
and two host tests. These are selected affected suites, not full-workspace,
cross-platform or final issue acceptance. Earlier checkpoint counts overlap and
must not be summed as additional coverage.

The gate ran against main `7dfab923a1b4005e2c8b31460bbe766738f78a10`
and source head `1df5b06dc6eb4998431cbcc03b934286295fb0d7`, verifying all
tracked source hashes after every step. The later commit amendment changes only
this document and its evidence archive. Existing assertions, thresholds, skips,
timeouts and budgets are unchanged. Initial fixture/oracle corrections are
described below; the archive contains the complete frozen successful run.''')
text += f'''\n[Source-bound acceptance](data/imported-camera-activation-native-v1.zip), SHA-256
`{sha(archive)}`, {archive.stat().st_size} bytes. The archive retains exact
changed source, the patch against the tested main baseline, commands, raw logs
and exit receipts. Every entry is read back and SHA-256 verified.\n'''
doc.write_text(text,encoding='utf-8',newline='\n')
subprocess.run(['git','diff','--check'],cwd=work,check=True)
subprocess.run(['git','add','--',doc.relative_to(work).as_posix(),archive.relative_to(work).as_posix()],cwd=work,check=True)
subprocess.run(['git','commit','--amend','--no-edit'],cwd=work,check=True)
subprocess.run(['git','show','--stat','--oneline','HEAD'],cwd=work,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work).strip()
assert all(sha(work/p) == h for p,h in r['source'].items())
result = dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),
    completedUtc=datetime.now(timezone.utc).isoformat(),totals=counts,archiveSha256=sha(archive),published=False)
(out/'completed.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
