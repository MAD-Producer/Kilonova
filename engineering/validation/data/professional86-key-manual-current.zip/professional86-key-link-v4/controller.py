"""Compile/link the two controls without starting a second GPU workload."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, time, traceback
ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/professional-green86'
OUT = ROOT / 'artifacts/pr-queue/professional86-key-link-v4'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def identity():
    names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()
    return {n: sha(WORK / n) for n in names if (WORK / n).is_file() and (n.startswith(('crates/', 'desktop/', 'sdk/')) or n in ('Cargo.toml', 'Cargo.lock', 'ATTRIBUTION.md', 'PROVENANCE.md', 'NOTICE'))}

before = identity()
env = os.environ.copy()
for key in list(env):
    if key.startswith('MOTION_'):
        env.pop(key, None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT / 'target/professional86-key-isolated'), CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', TEMP=str(ROOT / 'target/ci-policy-validation-tmp'), TMP=str(ROOT / 'target/ci-policy-validation-tmp'))
command = ['cargo', 'test', '-p', 'motion-desktop-media', '--test', 'professional_key', '--no-run', '--message-format=json', '--features', 'ffmpeg', '--locked', '--offline']
report = dict(status='running', source=before, command=command, startedUtc=datetime.now(timezone.utc).isoformat(), limits=['Compile/link only; the test executable is never started', 'One compiler job, no second GPU workload, controlled caches/temp E; dedicated target only for professional-green86; no cross-worktree cache reuse', 'Explicit transparent-background fixtures; original native-v1 failures retained; all numerical and core budgets unchanged'])

def save():
    pending = OUT / 'exit.pending.json'
    pending.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    os.replace(pending, OUT / 'exit.json')

save()
began = time.monotonic()
try:
    with (OUT / 'stdout.jsonl').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = child.pid
        save()
        code = child.wait()
    assert identity() == before, 'Green sample source changed during linking'
    report.update(exitCode=code, sourceUnchanged=True)
    if code == 0:
        messages = [json.loads(line) for line in (OUT / 'stdout.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
        artifacts = [m for m in messages if m.get('reason') == 'compiler-artifact' and m['target']['name'] == 'professional_key' and m.get('executable')]
        assert len(artifacts) == 1, artifacts
        executable = Path(artifacts[0]['executable'])
        report.update(status='linked_not_executed', executable=dict(path=str(executable), bytes=executable.stat().st_size, sha256=sha(executable)))
    else:
        report['status'] = 'failed_original_outputs_retained'
except BaseException:
    report.update(status='observer_failed_original_outputs_retained', traceback=traceback.format_exc())
    raise
finally:
    report.update(elapsedSeconds=round(time.monotonic() - began, 3), completedUtc=datetime.now(timezone.utc).isoformat())
    save()
print(json.dumps({k: v for k, v in report.items() if k != 'source'}))
raise SystemExit(code)
