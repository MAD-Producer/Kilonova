"""Run both new native key controls, after consuming the earlier full gate."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, time, traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/professional-green86'
OUT = ROOT / 'artifacts/pr-queue/professional86-key-native-v3'
prior = json.loads((ROOT / 'artifacts/pr-queue/tracking88-integration-final-v1/exit.json').read_text(encoding='utf-8'))
assert prior['status'] != 'running' and prior.get('completedUtc'), 'Earlier serial GPU gate is still live'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def identity():
    paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()
    return {p: sha(WORK / p) for p in paths if (WORK / p).is_file() and
            (p.startswith(('crates/', 'desktop/', 'sdk/')) or p in ('Cargo.toml', 'Cargo.lock', 'ATTRIBUTION.md', 'PROVENANCE.md', 'NOTICE'))}

before = identity()
link_path = ROOT / 'artifacts/pr-queue/professional86-key-link-v3/exit.json'
link = json.loads(link_path.read_text(encoding='utf-8'))
assert link['status'] == 'linked_not_executed' and link['sourceUnchanged']
assert link['source'] == before, 'Linked control source differs from current source'
executable = Path(link['executable']['path'])
assert sha(executable) == link['executable']['sha256'], 'Linked executable was replaced'
env = os.environ.copy()
for key in list(env):
    if key.startswith('MOTION_'):
        env.pop(key, None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT / 'target/professional86-key-isolated'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT / 'appdata'),
           TEMP=str(ROOT / 'target/ci-policy-validation-tmp'),
           TMP=str(ROOT / 'target/ci-policy-validation-tmp'),
           MOTION_PROFESSIONAL_KEY_ARTIFACTS=str(OUT / 'native'))
cmd = [str(executable), '--test-threads=1']
report = dict(status='running', source=before,
              baseCommit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip(),
              command=cmd, linkedExecutable=link['executable'], linkReceiptSha256=sha(link_path),
              startedUtc=datetime.now(timezone.utc).isoformat(),
              limits=['Two actual GPU controls, not the full package suite or full issue 86',
                      'Original fixed numerical and opaque core-region budgets; no physical edge-alpha truth',
                      'Three SDR derivatives; source capture FPS and PTS unknown; authored demo clock only',
                      'Default Info, original backend/stack, one serial own GPU workload, controlled caches/temp on E',
                      'Runs the exact source-hashed linked binary directly; no Cargo rebuild or shared-cache freshness assumption',
                      'Link used Cargo default test codegen units; dev/test debug0, no incremental, one build job; product profiles unchanged'])

def save():
    pending = OUT / 'exit.pending.json'
    pending.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    os.replace(pending, OUT / 'exit.json')

save()
began = time.monotonic()
try:
    with (OUT / 'stdout.log').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(cmd, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = child.pid
        save()
        code = child.wait()
    report['exitCode'] = code
    assert identity() == before, 'Source changed during native execution'
    assert sha(executable) == link['executable']['sha256'], 'Executable changed during native execution'
    report['sourceUnchanged'] = True
    if code == 0:
        stdout = (OUT / 'stdout.log').read_text(encoding='utf-8', errors='replace')
        summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', stdout, re.M)
        assert summaries == [('ok', '2', '0', '0', '0', '0')], summaries
        for name in ['chroma_sample_public_api_preserves_alpha_local_animation_history_reopen_and_frozen_output',
                     'footage::photographed_key_core_regions_history_reopen_and_frozen_png_keep_fixed_controls']:
            assert f'test {name} ... ok' in stdout, name
        for file in ['frozen.png', 'frozen-receipt.json', 'photographed/frozen.png',
                     'photographed/frozen-receipt.json', 'photographed/core-regions.json']:
            assert (OUT / 'native' / file).is_file(), file
        report['artifacts'] = {p.relative_to(OUT).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                               for p in (OUT / 'native').rglob('*') if p.is_file()}
        report['status'] = 'two_native_controls_passed_visual_review_pending'
    else:
        report['status'] = 'failed_original_outputs_retained'
except BaseException:
    report.update(status='observer_failed_original_outputs_retained', traceback=traceback.format_exc())
    raise
finally:
    report.update(elapsedSeconds=round(time.monotonic() - began, 3), completedUtc=datetime.now(timezone.utc).isoformat())
    save()
print(json.dumps({k: v for k, v in report.items() if k not in ('source', 'artifacts')}))
raise SystemExit(code)
