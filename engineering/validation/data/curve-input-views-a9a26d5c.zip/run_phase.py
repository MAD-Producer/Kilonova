from pathlib import Path
import json,hashlib,subprocess,time,sys,os,shutil
root=Path('E:/Dev/aem');out=root/'.tools/curve-input-views';work=root/'.worktrees/curve-input-views';phase=sys.argv[1];assert phase in ['before','after']
source=work/'desktop/app/src/panels/curve_comparison/tests.rs';toolbar=work/'desktop/app/src/panels/curve_comparison/toolbar.rs';marker=b'\n#[path = "E:/Dev/aem/.tools/curve-input-views/probe.rs"]\nmod input_borrow_probe;\n'
if phase=='before':
 assert subprocess.check_output(['git','status','--porcelain'],cwd=work,encoding='utf8').strip()==''
 for p in [source,toolbar]:shutil.copyfile(p,out/('original-'+p.name))
 shutil.copyfile(root/'.tools/node-card-height/allocator.rs',out/'allocator.rs');source.write_bytes(source.read_bytes()+marker)
assert source.read_bytes()==(out/'original-tests.rs').read_bytes()+marker
(work/'desktop/app/src/main.rs').touch()
paths=[source,toolbar,out/'probe.rs',out/'allocator.rs'];freeze=lambda:{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};frozen=freeze()
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1','panels::curve_comparison::tests::input_borrow_probe::record_real_window_frames_and_input_allocations','--','--exact','--test-threads=1']
env=os.environ.copy();env['MOTION_CURVE_INPUT_PROBE_OUT']=str(out/phase);start=time.monotonic();log=out/(phase+'.log');assert not log.exists()
with log.open('w',encoding='utf8') as sink:result=subprocess.run(command,cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT)
text=log.read_text(encoding='utf8');receipt=dict(phase=phase,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,encoding='utf8').strip(),command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),sources=frozen,source_unchanged=freeze()==frozen,actual_desktop_compile=any('Compiling motion-desktop ' in l and str(work).replace('\\','/').casefold() in l.replace('\\','/').casefold() for l in text.splitlines()))
(out/(phase+'-receipt.json')).write_text(json.dumps(receipt,indent=2),encoding='utf8');assert result.returncode==0 and receipt['source_unchanged'] and receipt['actual_desktop_compile'] and '1 passed; 0 failed; 0 ignored' in text
print(json.dumps({k:v for k,v in receipt.items() if k!='sources'}),flush=True)
