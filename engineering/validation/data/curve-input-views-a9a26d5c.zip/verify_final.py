from pathlib import Path
import subprocess,hashlib,json,time,os,re
root=Path('E:/Dev/aem');out=root/'.tools/curve-input-views';work=root/'.worktrees/curve-input-views';sources=json.loads((out/'production-source.json').read_text(encoding='utf8'))
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sources}
assert freeze()==sources
(work/'desktop/app/src/main.rs').touch()
common=['cargo','test','-p','motion-desktop','--bin','motion-studio','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1']
records=[]
for label,args in [('curve-regressions',['curve_comparison','--','--test-threads=1']),('native-final',['shell::curve_comparison_tests::curve_comparison_native_main_and_float_pixels_preserve_authored_project','--','--exact','--ignored','--test-threads=1'])]:
 env=os.environ.copy();env['MOTION_CURVE_COMPARISON_GPU_ARTIFACTS']=str(out/'native-final');env.pop('MOTION_LOG',None);command=common+args
 print(label+' started',flush=True);start=time.monotonic();log=out/(label+'.log');assert not log.exists()
 with log.open('w',encoding='utf8') as sink:r=subprocess.run(command,cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT)
 text=log.read_text(encoding='utf8');summary=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 record=dict(label=label,command=command,exit_code=r.returncode,seconds=round(time.monotonic()-start,2),sources=sources,source_unchanged=freeze()==sources,binary_sha256=hashlib.sha256((root/'target/debug/deps/motion_studio-d5bd28a41c2d0117.exe').read_bytes()).hexdigest())
 records.append(record);(out/'final-validation.json').write_text(json.dumps(records,indent=2),encoding='utf8');assert r.returncode==0 and summary and record['source_unchanged']
 passed,failed,ignored=map(int,summary.groups());assert failed==0
 if label=='curve-regressions':
  assert passed>=10 and ignored==1 and 'input_borrow_probe::' not in text
  assert any('Compiling motion-desktop ' in line and str(work).replace('\\','/').casefold() in line.replace('\\','/').casefold() for line in text.splitlines())
 else:assert passed==1 and ignored==0 and len(list((out/'native-final').glob('*.png')))>=13 and record['binary_sha256']==records[0]['binary_sha256']
 record.update(passed=passed,failed=failed,ignored=ignored);(out/'final-validation.json').write_text(json.dumps(records,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in record.items() if k!='sources'}),flush=True)
