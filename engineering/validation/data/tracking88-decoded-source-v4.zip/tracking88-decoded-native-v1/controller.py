"""One owner, serial builds and actual stdio executables; no GUI/GPU capture."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,struct,subprocess
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
PRIOR=ROOT/'artifacts/pr-queue/tracking88-decoded-v4/exit.json'
prior=json.loads(PRIOR.read_text());assert prior['status']=='failed'
assert prior['failure']=="AssertionError('host-full')"
assert prior['steps'][-1]['name']=='host-full' and prior['steps'][-1]['exitCode']==101
full_log=(PRIOR.parent/'host-full.stdout.log').read_text(encoding='utf-8',errors='replace')
assert '212 passed; 2 failed; 0 ignored;' in full_log
OUT=ROOT/'artifacts/pr-queue/tracking88-decoded-native-v1';OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
sources=prior['source']
def now():return datetime.now(timezone.utc).isoformat()
report=dict(status='running',controllerPid=os.getpid(),startedUtc=now(),source=sources,unitEvidence=str(PRIOR),fullHostRegression='FAILED 212/2/0; two native child failures retained with exact EXE/PDB/WER and read-only symbol lookup. This independent native admission gate does not repair or supersede that failure.',steps=[])
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def identity():
    for name,digest in sources.items():assert hashlib.sha256((WORK/name).read_bytes()).hexdigest()==digest,name
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'local-appdata'))
def step(name,args,count=None):
    identity();row=dict(name=name,command=args,startedUtc=now());report['steps'].append(row);save()
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        p=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait()
    row['completedUtc']=now();save();assert row['exitCode']==0,name
    if count is not None:
        output=(OUT/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace')
        row['counts']=[list(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',output)]
        save();assert row['counts']==[[count,0,0]],name
    identity()
EXE=ROOT/'target/gltf-animation87-contract/debug/motion-studio.exe'
project_root=OUT/'project'
active=[]
class Rpc:
    def __init__(self,name,readonly=False):
        identity();self.name=name;self.inputs=[];self.outputs=[];self.raw=[];self.next_id=0
        args=[str(EXE),'--mcp','--project',str(project_root)]
        if readonly:args+=['--mcp-read-only']
        self.row=dict(name=name,command=args,startedUtc=now(),exeSha256=hashlib.sha256(EXE.read_bytes()).hexdigest());report['steps'].append(self.row);save()
        self.stderr=(OUT/f'{name}.stderr.log').open('wb')
        self.p=subprocess.Popen(args,cwd=WORK,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr,text=True,encoding='utf-8')
        active.append(self)
        self.row['pid']=self.p.pid;save()
        self.request('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='owned-decoded-source-proof',version='1')))
        self.send(dict(jsonrpc='2.0',method='notifications/initialized'))
    def send(self,message):
        self.inputs.append(message);self.p.stdin.write(json.dumps(message)+'\n');self.p.stdin.flush()
    def request(self,method,params):
        self.next_id+=1;self.send(dict(jsonrpc='2.0',id=self.next_id,method=method,params=params))
        line=self.p.stdout.readline();self.raw.append(line);assert line,f'{self.name}: stdout closed'
        reply=json.loads(line);self.outputs.append(reply)
        assert reply['jsonrpc']=='2.0' and reply['id']==self.next_id and 'error' not in reply,reply
        return reply['result']
    def call(self,name,args):return self.request('tools/call',dict(name=name,arguments=args))
    def state(self):
        result=self.call('motion_state',{});assert not result['isError'];return result['structuredContent']
    def close(self):
        self.p.stdin.close();trailing=self.p.stdout.read();assert not trailing,repr(trailing)
        self.row['exitCode']=self.p.wait();self.stderr.close();self.row['completedUtc']=now()
        (OUT/f'{self.name}.stdin.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in self.inputs),encoding='utf-8')
        (OUT/f'{self.name}.stdout.jsonl').write_text(''.join(self.raw),encoding='utf-8')
        # Text transport normalizes OS newlines. Each original JSON line is
        # retained before parsing; no reserialization of responses is substituted.
        log=OUT/'local-appdata/MotionStudio/logs/motion-studio.log'
        if log.exists():(OUT/f'{self.name}.file.log').write_bytes(log.read_bytes())
        save();assert self.row['exitCode']==0,self.name
        active.remove(self)
save()
try:
    step('portable-mcp',['cargo','test','-p','motion-desktop','--bin','motion-studio','mcp::','--locked','--offline','--','--test-threads=1'],9)
    step('portable-build',['cargo','build','-p','motion-desktop','--bin','motion-studio','--locked','--offline'])
    bootstrap=Rpc('bootstrap');project=bootstrap.state()['project'];bootstrap.close()
    name='video-ctts.mp4';folder=WORK/'crates/motion-media/tests/fixtures/video'
    timing=json.loads((folder/'native-timing.json').read_text())[name];ticks=timing['timescale']
    pts=sorted(s[0] for s in timing['samples']);assert ticks==1_000_000 and len(pts)==72
    source=project_root/'assets/plate.mp4';source.parent.mkdir(exist_ok=True);shutil.copyfile(folder/name,source)
    end=max(s[0]+s[1] for s in timing['samples'])
    video=dict(id=1,path='assets/plate.mp4',bytes=source.stat().st_size,mime='video/avc',track=0,width=256,height=144,rotation=0,display_width=256,display_height=144,video_start_us=pts[0],video_end_us=end,duration_us=end,frame_count=len(pts),variable_frame_rate=True,nominal_frame_rate=24.,color_standard=1,color_range=2,audio_asset=None)
    project['video_assets']=[video]
    (project_root/'project.json').write_text(json.dumps(project),encoding='utf-8')
    cache=project_root/'cache/video-v2/plate/index.pts';cache.parent.mkdir(parents=True)
    cache.write_bytes(b'MSVID001'+struct.pack('<Q',video['bytes'])+b''.join(struct.pack('<Q',v) for v in pts))
    solve=dict(version=1,source_id='owned original VFR B-frame control',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),source_extent=[256,144],coordinates='right_down_forward',ticks_per_second=900_000_000,nominal_rate=[24,1],source_pts=[v*900 for v in pts],meters_per_world_unit=None,tracks=[dict(id='authored point',kind='point',reference_index=None,samples=[dict(source_index=0,visibility='visible',confidence=1.,manual_correction=False,observation=dict(kind='point',pixels=[2.,3.]))])])
    original=b' \n'+json.dumps(solve,indent=2).encode()+b'\r\n';document=OUT/'original.json';document.write_bytes(original)
    def args(state,path=document):return dict(path=str(path),source=dict(kind='video',id=1),expectedRevision=state['revision'],expectedDocumentGeneration=state['document_generation'])
    portable=Rpc('portable-missing-decoder');before=portable.state()
    failed=portable.call('import_tracking',args(before));assert failed['isError'] and 'cannot verify original decoded tracking video' in failed['content'][0]['text'],failed
    assert portable.state()['project']==before['project'] and not (project_root/'assets/tracking').exists();portable.close()
    step('ffmpeg-mcp',['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','mcp::','--locked','--offline','--','--test-threads=1'],9)
    step('ffmpeg-build',['cargo','build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline'])
    live=Rpc('decoded-video-import');before=live.state()
    wrong=json.loads(json.dumps(solve));wrong['source_pts'][1]+=1
    bad=OUT/'submicrosecond-mismatch.json';bad.write_text(json.dumps(wrong),encoding='utf-8')
    failed=live.call('import_tracking',args(before,bad));assert failed['isError'],failed
    text=failed['content'][0]['text'];assert 'frame=1' in text and f"expected={wrong['source_pts'][1]}/900000000" in text,text
    rejected=live.state();assert rejected['project']==before['project'] and rejected['revision']==before['revision']
    assert not (project_root/'assets/tracking').exists()
    result=live.call('import_tracking',args(before));assert not result['isError'],result
    imported=result['structuredContent'];flags=imported['trackingImport']
    assert all(flags[k] is True for k in ['originalPreserved','encodedSourceVerified','decodedSourceVerified','decodedTimelineVerified']) and flags['poseApplied'] is False,flags
    descriptor=imported['project']['tracking_assets'][0];managed=project_root/descriptor['path'];assert managed.read_bytes()==original
    assert json.loads((project_root/'project.json').read_text())['tracking_assets']==[descriptor]
    undo=live.call('motion_history',dict(operation='undo'));assert not undo['isError'] and undo['structuredContent']['project']==before['project']
    assert not undo['structuredContent']['canUndo'];document.unlink()
    redo=live.call('motion_history',dict(operation='redo'));assert not redo['isError'] and redo['structuredContent']['project']==imported['project']
    assert not live.call('motion_save',{})['isError'];live.close()
    log=(OUT/'decoded-video-import.file.log').read_text(encoding='utf-8');stderr=(OUT/'decoded-video-import.stderr.log').read_text(encoding='utf-8',errors='replace')
    for sink in [log,stderr]:
        assert 'tracking import failed request=' in sink and 'phase=decode_source' in sink and 'source=Video:1' in sink and 'elapsed_ms=' in sink and 'frame=1' in sink,sink[-3000:]
    assert ' INFO ' in log and re.search(r'start #\d+ import_tracking',log)
    assert 'phase=decode source=Video:1' in log
    readonly=Rpc('decoded-reopen-readonly',True);assert readonly.state()['project']==imported['project'];readonly.close()
    identity();report.update(status='accepted_native_decoded_increment_not_full_issue',sourceSha256=solve['source_sha256'],originalSha256=hashlib.sha256(original).hexdigest(),frames=len(pts),scope='Original decoded dimensions and exact PTS admission; no pose application, relink lease, GUI or Android acceptance')
except BaseException as error:
    report.update(status='failed',failure=repr(error));raise
finally:
    for rpc in list(active):
        try:rpc.close()
        except BaseException as secondary:report.setdefault('cleanupFailures',[]).append(repr(secondary))
    report['completedUtc']=now();save()
