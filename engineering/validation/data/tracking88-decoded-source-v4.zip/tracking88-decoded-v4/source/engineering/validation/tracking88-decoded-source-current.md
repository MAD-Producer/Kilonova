# Original decoded tracking source admission

Issue #88 remains open. This increment extends the
[managed original import](tracking88-managed-import-current.md), on main baseline
`8573d9975cf70d2c8fe05605102ec9d744816070` and import checkpoint
`54ef14bb5a6e879d211ff9a2ec89b13c5c27b08d`. It verifies acquired original media;
it does not apply tracking observations to a camera, layer or parent.

## Product boundary

`Prepared::read`, reached by the existing desktop/MCP `import_tracking` operation,
now fully decodes an image from the same open file used for its encoded SHA-256.
The decoded dimensions must match the solve. A correct digest and mutually
consistent project/solve metadata cannot admit invalid pixels or a different
actual size. Decoding is bounded to the declared extent and a 512 MiB image
allocation limit. Sixteen-bit PNG originals are accepted without substituting an
eight-bit image. No decoded pixel conversion is needed for this check.

Video import requires a platform capable of verifying the original source. The
portable default rejects this operation explicitly; it never reports decoded
verification after an unsupported backend returns. The libav adapter opens the
selected original stream, checks its raw dimensions, codec, rotation and square
pixel aspect, and sequentially decodes every presentation frame through EOF.
Missing original PTS or disagreement with a decoder-inferred timestamp is an
error. The adapter neither seeks through the preview index nor converts pixels.

Each actual signed frame PTS and the native rational clock are compared against
the declared source clock using checked `i128` products:

```text
declared_pts * native_denominator
    == native_pts * native_numerator * declared_ticks_per_second
```

There is no source-FPS inference, floating-point comparison, microsecond
rounding, frame sorting, duplicate removal or timestamp repair in this path.
Every decoded frame must match in order, including VFR gaps and nonzero origins;
missing or extra frames reject the import. A failed comparison permanently
invalidates that acquisition, even if a caller attempts to continue feeding it.

The selected managed path is reopened and fully hashed again after decoding.
The held source handle's size and modification metadata are checked around the
operation. Encoded identity, actual decoded dimensions and exact video PTS must
all succeed before a managed tracking original is staged. Existing revision,
generation, saved transaction, rollback and undo/redo protections remain active.
Image decoding, native decoding and source hashes stay outside the session lock.

Successful responses add `decodedSourceVerified: true`. Video responses report
`decodedTimelineVerified: true`; image responses keep that field false because a
still image has no intrinsic video presentation timeline. `poseApplied` remains
false. These are admission results for this acquisition, not persisted promises
that an external file will remain unchanged. The MCP schema states this scope.

## Controls and receipts

Two actual-file negative controls were run before implementing decoded admission.
The old implementation accepted both an 8x6 PNG declared as 7x6 in the project
and solve, and an invalid image payload with a matching recomputed source digest.
The controlled run exited 101 with **0 passed, 2 failed, 0 ignored** and the two
intended assertion markers. Those test bodies remain unchanged by the fix.

The first positive attempt passed desktop check, but the new clock tests did not
compile because two glob imports made `Error` ambiguous. Explicit asset imports
fixed this test-source error without changing any assertion. The next attempt
passed **100 tracking tests** but failed four new native controls in fixture setup:
the product MP4 encoder rejects a movie with no audio samples. The fixture now
authors exactly 0.2 seconds of silence alongside six independently authored 30 fps
frames. Its existing admission and PTS assertions remain intact. Both failed
receipts and exact source snapshots are retained.

The corrected native controls pass **5/5**, including real decoding, managed
publication/save/undo/redo, a one-tick discrepancy at 900,000,000 ticks/second,
frame-count/dimension/stream mismatches and cancellation inside native decoding.
Two existing independently generated video fixtures add B-frame, nonzero-origin
and variable-interval coverage using their raw packet timing tables as the oracle.
Only the test oracle sorts packet decode order into presentation order; production
never sorts imported observations or actual decoded frames.

The complete host library gate passes **213 passed, 0 failed, 0 ignored**.
MCP, actual executable and static closeout evidence will be recorded after their
owned validators reach terminal status. Compilation alone is not acceptance.

## Remaining boundaries

This does not persist a decoded proof or bind observations into evaluated scene
poses. Runtime camera/object/parent bindings, original-asset relink and cache
invalidation, #85/#86 project-clock integration, explicit gap/manual policies and
rendered synthetic plus calibrated real-footage/lens-replacement acceptance remain
required. Current full workspace/desktop and exact-head cross-platform CI are not
established by this increment. Android remains excluded by user instruction.

The source checks are acquisition evidence, not a filesystem lease against an
external A-to-B-to-A replacement between decoder opens. Cooperative checks cannot
interrupt a blocked native read or an image decoder inside its library call. This
cold operation still occupies the existing serial engine worker; Info start and
in-flight state precede it. No per-command restart or thread timeout was added.

The canonical clock comparator supports signed origins, but the existing managed
video model/index still uses unsigned microseconds. Files whose negative preroll
was excluded from the managed frame count are explicitly rejected when the full
original decode disagrees; they are not silently repaired. Clock-model integration
is still needed before advertising arbitrary negative-preroll import.

The earlier original-source host gate's native `0xc0000005` remains unexplained;
later changed-source successes do not fix it. Its exact private binary/PDB/events
remain retained. Original #82 strict P95 failures also remain failed. No unchanged
performance gate was rerun, assertion weakened, sample reduced or cached GPU
coverage presented as complete by this increment.
