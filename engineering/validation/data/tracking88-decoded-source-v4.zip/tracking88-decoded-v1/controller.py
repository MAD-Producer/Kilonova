from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess

ROOT=Path('E:/Dev/aem'); WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-decoded-v1'
OUT.mkdir(exist_ok=False)
paths=set(subprocess.check_output(['git','diff','--name-only'],cwd=WORK,text=True).splitlines())
paths.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=WORK,text=True).splitlines())
sources={p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in sorted(paths)}
for p in paths:
    dst=OUT/'source'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((WORK/p).read_bytes())
(OUT/'delta.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=WORK))
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full')
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),controllerPid=os.getpid(),source=sources,steps=[])
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def identity():
    for p,d in sources.items():assert hashlib.sha256((WORK/p).read_bytes()).hexdigest()==d,p
def step(name,cmd,minimum=0):
    identity();row=dict(name=name,command=cmd,startedUtc=datetime.now(timezone.utc).isoformat());report['steps'].append(row);save()
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        p=subprocess.Popen(cmd,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait()
    row['completedUtc']=datetime.now(timezone.utc).isoformat();save()
    assert row['exitCode']==0,name
    if minimum:
        output=(OUT/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace')
        row['counts']=[list(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',output)]
        save();assert sum(c[0] for c in row['counts'])>=minimum and all(c[1:]==[0,0] for c in row['counts']),name
    identity()
save()
try:
    step('desktop-check',['cargo','check','-p','motion-desktop','--locked','--offline'])
    step('tracking',['cargo','test','-p','motion-host','--lib','tracking::','--locked','--offline','--','--test-threads=1'],99)
    step('native-tracking',['cargo','test','-p','motion-desktop-media','--lib','--features','ffmpeg','av::tracking::tests::','--locked','--offline','--','--test-threads=1'],5)
    step('host-full',['cargo','test','-p','motion-host','--lib','--locked','--offline','--','--test-threads=1'],212)
    step('mcp',['cargo','test','-p','motion-desktop','--bin','motion-studio','mcp::','--locked','--offline','--','--test-threads=1'],9)
    report['status']='accepted_decoded_increment_not_full_issue'
except BaseException as error:
    report.update(status='failed',failure=repr(error));raise
finally:
    report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps(report))
