"""Prepared only: qualify the new router after consumed serial predecessors."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, re, shutil, subprocess

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-transition75'
OUT = BASE / 'depth75-routed-native-v1'
assert shutil.disk_usage(ROOT).free >= 10 << 30
full = json.loads((BASE / 'depth75-backend-workspace-v8/receipt.json').read_text(encoding='utf-8'))
consumed = json.loads((BASE / 'depth75-backend-workspace-v8/session-consumed.json').read_text(encoding='utf-8'))
assert full['status'] == 'complete_maintained_workspace_passed' and full['sourceUnchanged']
assert consumed['session'] == 91059 and consumed['exitCode'] == 0
for directory, status in (
    ('depth75-restored-runtime-qualification-v2', 'nine_frozen_reference_comparisons_and_three_profile_refusals_passed'),
    ('tracking88-restored-analytic-v2', 'all_unchanged_original_analytic_controls_passed'),
    ('tracking88-backward-identity-resume-v2', 'measured_not_accepted_product_unchanged'),
):
    prior = BASE / directory
    prior_report = json.loads((prior / 'receipt.json').read_text(encoding='utf-8'))
    assert prior_report['status'] == status and prior_report['sourceUnchanged']
    if directory == 'tracking88-backward-identity-resume-v2':
        assert prior_report['originalInputsUnchanged']
    assert json.loads((prior / 'session-consumed.json').read_text(encoding='utf-8'))['exitCode'] == 0
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert head == '7cf9c23c7f090fc640c12e6a9a4a64ef6b25309a'
assert subprocess.check_output(['git', 'diff', '--name-only'], cwd=WORK, text=True).splitlines() == ['crates/motion-host/src/depth.rs']
extra = ['crates/motion-host/src/depth/routing.rs', 'crates/motion-host/tests/depth_routing.rs']
assert sorted(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()) == extra
names = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines() + extra
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity = lambda: {name: sha(WORK / name) for name in names}
source = identity()
targets = ['depth_alignment', 'depth_transition', 'depth_transition_jobs', 'depth_routing']
expected = []
for target in targets:
    raw = (WORK / 'crates/motion-host/tests' / (target + '.rs')).read_text(encoding='utf-8')
    expected.extend(re.findall(r'#\[test\]\s*fn (\w+)\(', raw))
assert len(expected) == len(set(expected)) == 36
placement = json.loads((BASE / 'depth75-runtime-placement-v1/receipt.json').read_text(encoding='utf-8'))
assert len(placement['placements']) == 14
for row in placement['placements']: assert sha(Path(row['path'])) == row['sha256']
env = {k: v for k, v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT / 'target/colmap88-isolated-check'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT / 'appdata'),
           TEMP=str(ROOT / 'target/colmap88-isolated-check/tmp'), TMP=str(ROOT / 'target/colmap88-isolated-check/tmp'),
           PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1')
command = ['cargo', 'test', '--locked', '-p', 'motion-host', '--features', 'ai-depth']
for target in targets: command.extend(['--test', target])
command.extend(['--', '--test-threads=1'])
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='running', sourceCommitBefore=head, source=source, expectedTests=expected, command=command,
              startedUtc=datetime.now(timezone.utc).isoformat(),
              limits=['Exact uncommitted router delta and unchanged original30 controls; no old CI coverage inferred',
                      'Controlled backend routing, errors and cancellation only; no real-model/quality/export qualification',
                      'Original features, GPU/backend selection, assertions, ignores and10GiB gate retained'])
def save(): (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
save()
try:
    with (OUT / 'stdout.log').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = child.pid; save()
        report['exitCode'] = child.wait(); save()
    output = (OUT / 'stdout.log').read_text(encoding='utf-8', errors='replace')
    report['namedPasses'] = re.findall(r'^test (\w+) \.\.\. ok$', output, re.M)
    report['summaries'] = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out', output, re.M)
    assert report['exitCode'] == 0
    assert sorted(report['namedPasses']) == sorted(expected)
    assert sorted(tuple(map(int, row)) for row in report['summaries']) == [(6,0,0,0),(7,0,0,0),(9,0,0,0),(14,0,0,0)]
    report['status'] = 'all36_native_alignment_admission_binding_routing_controls_passed'
except BaseException as error:
    report.update(status='failed_original_outputs_retained', cause=repr(error))
finally:
    report.update(sourceUnchanged=identity() == source,
                  completedUtc=datetime.now(timezone.utc).isoformat())
    save()
print(json.dumps({k: v for k, v in report.items() if k not in ('source', 'namedPasses', 'expectedTests')}))
raise SystemExit(0 if report['status'].startswith('all36_native') and report['sourceUnchanged'] else 1)
