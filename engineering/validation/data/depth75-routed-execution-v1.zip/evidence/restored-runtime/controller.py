"""Prepared, serial qualification of the restored interpreter against frozen references.

Do not run until the original complete native workload is terminal and consumed.
No new upstream model/reference export, temporal or quality-tier claim is made.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import shutil
import subprocess
import time
import zipfile

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/reference-depth76'
OUT = BASE / 'depth75-restored-runtime-qualification-v2'
PYTHON = ROOT / '.tools/ai-depth74/venv/Scripts/python.exe'
OLD = BASE / 'depth75-resolution-models-v1'
assert shutil.disk_usage(ROOT).free >= 10 << 30
full = json.loads((BASE / 'depth75-backend-workspace-v8/receipt.json').read_text(encoding='utf-8'))
consumed = json.loads((BASE / 'depth75-backend-workspace-v8/session-consumed.json').read_text(encoding='utf-8'))
assert consumed['session'] == 91059 and consumed['exitCode'] == 0
assert full['status'] == 'complete_maintained_workspace_passed' and full['sourceUnchanged']
assert json.loads((BASE / 'depth75-restore-cv-runtime-v1/session-consumed.json').read_text(encoding='utf-8'))['exitCode'] == 0
assert Path(__import__('sys').executable).resolve() == PYTHON.resolve()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = {name: sha(WORK / name) for name in full['source']}
assert source == full['source']
archive = WORK / 'engineering/validation/data/depth75-resolution-qualification-v1.zip'
assert sha(archive) == full['source'][archive.relative_to(WORK).as_posix()]
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='qualifying_restored_runtime', sourceCommit=full['baseCommit'],
              startedUtc=datetime.now(timezone.utc).isoformat(), stages=[], results=[],
              referenceArchiveSha256=sha(archive),
              gates=dict(maxNormalized=2e-4, meanNormalized=2e-5),
              limits=['Frozen independent official-reference outputs and exact original input/model hashes',
                      'Unchanged absolute-reference-amplitude normalization; no fitting or output normalization',
                      'New interpreter identity; original model export and previous failures retained',
                      'CPU numerical/profile admission only; no native Jobs, video, quality tier or thermal proof'])
env = {k: v for k, v in os.environ.items() if not k.startswith('MOTION_')}
env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1',
           TEMP=str(OUT / 'tmp'), TMP=str(OUT / 'tmp'))
Path(env['TEMP']).mkdir()
os.environ.update(TEMP=env['TEMP'], TMP=env['TMP'])

def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

def run_case(directory, request, expected_exit):
    (directory / 'request.json').write_text(json.dumps(request) + '\n', encoding='utf-8')
    row = dict(case=directory.name, processing=request['processing'], modelSha256=request['sha256'],
               expectedExit=expected_exit, startedUtc=datetime.now(timezone.utc).isoformat())
    report['stages'].append(row)
    save()
    began = time.perf_counter_ns()
    with (directory / 'stdout.log').open('wb') as stdout, (directory / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen([str(PYTHON), '-I', '-B', str(WORK / 'tools/ai_depth_onnx.py'), str(directory)],
                                 cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        row['pid'] = child.pid
        save()
        row['exitCode'] = child.wait()
    row['wallNs'] = time.perf_counter_ns() - began
    save()
    assert row['exitCode'] == expected_exit, row
    return json.loads((directory / 'stdout.log').read_text(encoding='utf-8'))

save()
try:
    packages = {name: importlib.metadata.version(name) for name in ('numpy', 'opencv-python-headless', 'onnxruntime')}
    assert packages == {'numpy': '2.4.6', 'opencv-python-headless': '5.0.0.93', 'onnxruntime': '1.31.0'}
    report['packages'] = packages
    save()
    import numpy as np
    with zipfile.ZipFile(archive) as z:
        original = json.loads(z.read('manifest.json'))
        assert original['gates'] == report['gates']
        for side in (266, 392, 518):
            model_bytes = z.read(f'evidence/models/{side}/model.json')
            reference_bytes = z.read(f'evidence/models/{side}/references.json')
            assert model_bytes == (OLD / str(side) / 'export/model.json').read_bytes()
            assert reference_bytes == (OLD / str(side) / 'references.json').read_bytes()
            model = json.loads(model_bytes)
            model_path = OLD / str(side) / 'export' / model['file']
            assert model_path.stat().st_size == model['bytes'] and sha(model_path) == model['sha256']
            for reference in json.loads(reference_bytes):
                width, height = reference['size']
                old_case = OLD / str(side) / f'{width}x{height}'
                assert sha(old_case / 'input.rgb') == reference['inputSha256']
                assert sha(old_case / 'official-reference.f32') == reference['referenceSha256']
                directory = OUT / f'{side}-{width}x{height}'
                directory.mkdir()
                (directory / 'input.rgb').write_bytes((old_case / 'input.rgb').read_bytes())
                request = dict(schema=1, model=str(model_path), sha256=model['sha256'],
                               processing=model['processing'], width=width, height=height,
                               provider='CPUExecutionProvider')
                actual = run_case(directory, request, 0)
                assert actual['providers'] == ['CPUExecutionProvider'] and not actual['cpu_fallback']
                assert actual['sha256'] == model['sha256'] and actual['processing'] == model['processing']
                assert [actual['width'], actual['height']] == [width, height]
                assert actual['letterbox'] == reference['rectangle']
                assert actual['input_host_copy_bytes'] == 3 * side * side * 4
                assert actual['output_host_copy_bytes'] == side * side * 4
                assert actual['resource_bytes'] == width * height * 4
                expected = np.fromfile(old_case / 'official-reference.f32', dtype='<f4')
                result = np.fromfile(directory / 'output.f32', dtype='<f4')
                assert expected.shape == result.shape == (width * height,)
                assert np.isfinite(expected).all() and np.isfinite(result).all()
                difference = np.abs(result.astype(np.float64) - expected.astype(np.float64))
                amplitude = max(float(np.abs(expected).max()), 1e-6)
                maximum, mean = float(difference.max()) / amplitude, float(difference.mean()) / amplitude
                assert maximum <= 2e-4 and mean <= 2e-5, (side, width, height, maximum, mean)
                report['results'].append(dict(side=side, size=[width, height], maxNormalized=maximum,
                                             meanNormalized=mean, outputSha256=sha(directory / 'output.f32'), report=actual))
                save()
            bad = OUT / f'{side}-wrong-profile'
            bad.mkdir()
            (bad / 'input.rgb').write_bytes((old_case / 'input.rgb').read_bytes())
            request['processing'] = 'dav2-small-rgb8-letterbox' + ('392' if side == 266 else '266') + '-align-corners-relative-v1'
            refusal = run_case(bad, request, 1)
            assert 'phase=session' in refusal['error'] and 'input' in refusal['error']
            assert not (bad / 'output.f32').exists()
    assert len(report['results']) == 9 and len(report['stages']) == 12
    report['status'] = 'nine_frozen_reference_comparisons_and_three_profile_refusals_passed'
except BaseException as error:
    report.update(status='failed_original_outputs_retained', cause=repr(error))
finally:
    report.update(sourceUnchanged=all(sha(WORK / name) == digest for name, digest in source.items()),
                  completedUtc=datetime.now(timezone.utc).isoformat())
    save()
print(json.dumps({k: v for k, v in report.items() if k not in ('results', 'stages')}))
raise SystemExit(0 if report['status'].startswith('nine_frozen_reference') and report['sourceUnchanged'] else 1)
