"""Publish only source-bound routed execution evidence; exclude tensor/model data."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, zipfile

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-transition75'
OUT = BASE / 'depth75-routed-public-v1'
NATIVE = BASE / 'depth75-routed-native-v1'
MODEL = BASE / 'depth75-routed-model-v1'
QUAL = BASE / 'depth75-restored-runtime-qualification-v2'
PROBE = BASE / 'depth75-routed-model-source'
native = json.loads((NATIVE / 'receipt.json').read_text(encoding='utf-8'))
model = json.loads((MODEL / 'receipt.json').read_text(encoding='utf-8'))
qual = json.loads((QUAL / 'receipt.json').read_text(encoding='utf-8'))
assert native['status'] == 'all36_native_alignment_admission_binding_routing_controls_passed'
assert model['status'] == 'actual_serial_two_profile_routes_match_frozen_references_and_default_refusal_channels'
assert qual['status'] == 'nine_frozen_reference_comparisons_and_three_profile_refusals_passed'
for directory, session in ((NATIVE,56909),(MODEL,30205),(QUAL,12301)):
    consumed = json.loads((directory / 'session-consumed.json').read_text(encoding='utf-8'))
    assert consumed['exitCode'] == 0 and consumed['session'] == session
assert native['sourceUnchanged'] and model['sourceUnchanged'] and model['probeSourceUnchanged'] and qual['sourceUnchanged']
assert native['source'] == model['source']
assert len(native['namedPasses']) == len(set(native['namedPasses'])) == 36
assert len(model['results']) == 3 and len(qual['results']) == 9
sha = lambda raw: hashlib.sha256(raw).hexdigest()
members = {}
def add(directory, files, prefix):
    for name in files: members[prefix + '/' + name] = (directory / name).read_bytes()
for directory,prefix in ((NATIVE,'evidence/native36'),(MODEL,'evidence/actual-routes')):
    add(directory,('controller.py','receipt.json','session-consumed.json'),prefix)
add(NATIVE,('stdout.log','stderr.log'),'evidence/native36')
add(MODEL,('metadata.stdout.log','metadata.stderr.log','build.stdout.log','build.stderr.log',
           'actual.stdout.log','actual.stderr.log','request.json'),'evidence/actual-routes')
add(MODEL / 'execution',('receipt.json','logs/motion-studio.log'),'evidence/actual-routes/execution')
add(QUAL,('controller.py','receipt.json','session-consumed.json'),'evidence/restored-runtime')
for name in ('Cargo.toml','Cargo.lock','src/main.rs'):
    raw = (PROBE / name).read_bytes()
    if name in model['probeSource']: assert sha(raw) == model['probeSource'][name]
    members['fixture/' + name] = raw
delta = ('crates/motion-host/src/depth.rs','crates/motion-host/src/depth/routing.rs',
         'crates/motion-host/tests/depth_routing.rs')
for name in delta:
    raw = (WORK / name).read_bytes()
    assert sha(raw) == native['source'][name], name
    members['source/' + name] = raw
members['archive-controller.py'] = Path(__file__).read_bytes()
manifest = dict(schema=1, sourceCommitBefore=native['sourceCommitBefore'],
    sourceDelta={name:native['source'][name] for name in delta},
    observedUtc=datetime.now(timezone.utc).isoformat(),
    status='actual36_native_controls_and_real_two_profile_routes_passed',
    nativeNamedPasses=36, actualRoutes=[0,1,0], refusedRequest=4,
    maxNormalized=max(row['maxNormalized'] for row in model['results']),
    meanNormalized=max(row['meanNormalized'] for row in model['results']),
    originalNumericalGates=model['gates'],
    limits=['Actual qualified source delta over exact7cf; Git commit before includes unchanged alignment/admission/Jobs',
            'One production worker, two actual hash-bound ONNX CPU profiles, three independent frozen-reference comparisons',
            'Actual default Info starts observed before outputs; original refusal in file and stderr, one JSON stdout',
            'No measured quality ranking, WGSL combination, real-video transition, automatic installation/cache/export or thermal claim',
            'Parent full5002 run is separate exact5fb evidence and does not cover the new router',
            'No models/weights, RGB/images, scalar tensors, native binaries, symbols or dumps included'],
    members={name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in members.items()})
OUT.mkdir(exist_ok=False)
archive = OUT / 'depth75-routed-execution-v1.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
    for name,raw in members.items(): z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == {'manifest.json',*members}
    assert json.loads(z.read('manifest.json')) == manifest
    for name,item in manifest['members'].items():
        raw = z.read(name)
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256'], name
manifest['archive'] = dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),verifiedMembers=len(members)+1)
(OUT / 'depth75-routed-execution-v1.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:manifest[key] for key in ('status','nativeNamedPasses','actualRoutes','maxNormalized','meanNormalized','archive')}))
