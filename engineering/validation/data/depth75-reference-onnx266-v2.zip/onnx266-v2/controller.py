"""Source-corrected actual model cohort and held-out sensor-depth reduction; no retry."""
from pathlib import Path
from datetime import datetime, timezone
import array, hashlib, json, math, os, shutil, subprocess, sys, traceback

ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
INPUTS=BASE/'depth75-reference-inputs-v1';NATIVE=BASE/'depth75-reference-probe-native-v2'
CLI=BASE/'depth75-reference-probe-cli-v2';OUT=BASE/'depth75-reference-onnx266-v2'
TARGET=ROOT/'target/depth-wgsl-cache75-contract'
assert json.loads((NATIVE/'session-consumed.json').read_text())==dict(session=86270,consumed=True,exit_code=0)
native=json.loads((NATIVE/'receipt.json').read_text())
assert native['source_unchanged'] and native['status']=='three_controls_actual_build_and_default_cli_source_refusal_passed'
assert all(v['exit_code']==v['expected_exit'] for v in native['stages'])
assert json.loads((BASE/'depth75-reference-onnx266-v1/session-consumed.json').read_text())==dict(session=22317,consumed=True,exit_code=1)
assert not json.loads((BASE/'depth75-resume-current.json').read_text())['versionedCache75']['ownHeavyWorkloads']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
assert shutil.disk_usage(ROOT).free>=10<<30 and not OUT.exists()
# One batched source comparison replaces thousands of per-path Git processes.
assert not subprocess.check_output(['git','diff','--name-only',native['head'],'HEAD','--',
 'crates','desktop','vendor','Cargo.toml','Cargo.lock','tools'],cwd=WORK)



def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


paths=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def hashes():return {name:sha(WORK/name) for name in paths}
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(TEMP=str(OUT),TMP=str(OUT),LOCALAPPDATA=str(OUT/'appdata'),PYTHONDONTWRITEBYTECODE='1')
env['PATH']=str(ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')+';'+env['PATH']
report=dict(status='running',phase='input_identity',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),
 source_sha256=hashes(),started_utc=datetime.now(timezone.utc).isoformat(),
 limits=['First planned CPU266 cohort; original32 source pairs and first8/next24 division unchanged',
 'All actual cold/resolution/transport work retained; no cache/retry, frame replacement, per-frame fit, clipping or residual trimming',
 'Sensor measurements are not exact geometric truth or arbitrary-domain/temporal/thermal/memory certification',
 'Transition-jump qualification remains explicitly unknown, not filled with zero',
 'No new model/asset/dependency acquisition, source/panel changes, cleanup or concurrent own heavy workload'])
def save():
 p=OUT/'receipt.pending.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(p,OUT/'receipt.json')
save()
try:
 preparation=json.loads((INPUTS/'receipt.json').read_text());assert preparation['source_unchanged']
 assert sha(INPUTS/'inputs.json')==preparation['inputs_sha256']
 inputs=json.loads((INPUTS/'inputs.json').read_text());assert len(inputs)==32
 for row in inputs:
  for kind in ('rgb','depth'):
   identity=row[kind+'_input'];assert sha(INPUTS/identity['filename'])==identity['sha256']
 driver=TARGET/'debug/examples/depth_reference.exe';assert sha(driver)==native['driver_sha256']
 model=BASE/'depth75-resolution-models-v1/266/export/depth_anything_v2_vits_266.onnx'
 model_manifest=json.loads(model.with_name('model.json').read_text())
 assert sha(model)==model_manifest['sha256']
 assert model_manifest['processing']=='dav2-small-rgb8-letterbox266-align-corners-relative-v1'
 report.update(driver_sha256=sha(driver),model_sha256=sha(model),model_manifest_sha256=sha(model.with_name('model.json')),
   inputs_sha256=preparation['inputs_sha256'],phase='actual_inference');save()
 command=[driver,'onnx',ROOT/'.tools/ai-depth74/venv/Scripts/python.exe',model,
 BASE/'depth75-wgsl-cache-resources-v2/program.json',TARGET/'debug/motion-depth-wgsl.exe',INPUTS,OUT/'onnx266']
 report['command']=[str(v) for v in command];save()
 with (OUT/'actual.stdout.log').open('wb') as stdout,(OUT/'actual.stderr.log').open('wb') as stderr:
  child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);report['pid']=child.pid;save();report['exit_code']=child.wait()
 save();assert report['exit_code']==0,'Original actual inference failure retained; no retry'
 assert not (OUT/'actual.stdout.log').read_bytes()
 measured=json.loads((OUT/'onnx266/measurements.json').read_text());assert measured['status']=='completed'
 rows=measured['samples'];assert len(rows)==32
 summary=measured['summary'];assert summary['samples']==summary['submitted']==summary['completed']==32
 assert all(summary[name]==0 for name in ('failed','canceled','cache_hits','cache_misses','restored'))
 for i,(actual,source) in enumerate(zip(rows,inputs)):
  assert actual['index']==i and actual['split']==source['split']
  assert actual['key']['source']==dict(asset=750000+i,revision=1,pts=dict(ticks=source['rgb_ns'],timescale=1000000000))
  expected=hashlib.sha256(b'MotionStudio/depth/rgb8-srgb-opaque/v1\0'+(640).to_bytes(4,'little')+(480).to_bytes(4,'little')+(INPUTS/source['rgb_input']['filename']).read_bytes()).hexdigest()
  assert actual['input']['rgb_size']==[640,480] and bytes(actual['input']['rgb_sha256']).hex()==expected
  assert actual['execution']['backend']=='onnx' and actual['execution']['provider']=='CPUExecutionProvider'
  assert actual['execution']['precision']=='float32' and any(actual['execution']['runtime_sha256']) and any(actual['execution']['plan_sha256'])
  assert actual['execution']==summary['execution']
  output=actual['output'];assert output['filename']==f'{i:02}.relative.f32le'
  assert output['bytes']==640*480*4 and sha(OUT/'onnx266'/output['filename'])==output['sha256']
  assert actual['worker_total_ns']>=actual['resolve_ns']>0
 report.update(phase='held_out_reduction',actual_summary=summary,measurements_sha256=sha(OUT/'onnx266/measurements.json'));save()
 sys.path.insert(0,str(WORK/'tools'))
 import depth_reference_metrics as metrics
 def pair(index):
  prediction=array.array('f');prediction.frombytes((OUT/'onnx266'/rows[index]['output']['filename']).read_bytes())
  sensor=array.array('H');sensor.frombytes((INPUTS/inputs[index]['depth_input']['filename']).read_bytes())
  assert prediction.itemsize==4 and sensor.itemsize==2
  if sys.byteorder!='little':prediction.byteswap();sensor.byteswap()
  assert len(prediction)==len(sensor)==640*480
  return prediction,sensor
 calibration=metrics.fit(pair(i) for i in range(8))
 assert calibration.reference_scale_inverse_metres==1.0
 evaluated=[]
 for i in range(8,32):
  prediction,sensor=pair(i);row=metrics.score(calibration,prediction,sensor);row['index']=i;evaluated.append(row)
 total=metrics.summarize(evaluated,calibration)
 assert total['frames']==24 and total['valid']+total['missing']==24*640*480
 quality=dict(status='initial_independent_sensor_measurement_not_a_qualification',
  model=model_manifest,execution=summary['execution'],calibration=calibration.__dict__,
  evaluation=evaluated,aggregate=total,maximum_additional_transition_jump=None,
  normalization='Exactly one inverse metre; fixed across all models/backends/frames',
  reference_sha256='e983d6830916e66dc4a46a71368046b149b283de87769690e7aa4e0b9483530c',
  limits=report['limits'])
 (OUT/'quality.json').write_text(json.dumps(quality,indent=2,allow_nan=False)+'\n',encoding='utf-8')
 assert sha(driver)==report['driver_sha256']
 report.update(status='actual32_onnx266_measurements_and24_held_out_sensor_reduction_completed',phase='completed',
  quality_sha256=sha(OUT/'quality.json'),quality_aggregate=total,calibration=calibration.__dict__);save()
except BaseException:
 report['status']='failed_original_outputs_retained';report['cause']=traceback.format_exc();save();raise
finally:
 report['source_unchanged']=hashes()==report['source_sha256'];report['finished_utc']=datetime.now(timezone.utc).isoformat();save()
 assert report['source_unchanged'],'Source changed during original real-model reference measurement'
