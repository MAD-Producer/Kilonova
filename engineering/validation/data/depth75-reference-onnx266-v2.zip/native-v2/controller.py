"""Validate corrected caller fingerprint semantics and original source refusal.
Prior original native driver and model cohort failures remain failed.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, traceback

ROOT = Path('E:/Dev/aem'); BASE = ROOT/'artifacts/pr-queue'
WORK = ROOT/'.worktrees/depth-wgsl-cache75'; TARGET = ROOT/'target/depth-wgsl-cache75-contract'
INPUTS = BASE/'depth75-reference-inputs-v1'; OUT = BASE/'depth75-reference-probe-native-v2'
assert json.loads((INPUTS/'session-consumed.json').read_text()) == dict(session=50754, consumed=True, exit_code=0)
assert not json.loads((BASE/'depth75-resume-current.json').read_text())['versionedCache75']['ownHeavyWorkloads']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
assert shutil.disk_usage(ROOT).free >= 10 << 30 and not OUT.exists()
assert not {'RUST_MIN_STACK','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'} & os.environ.keys()
OUT.mkdir(); (OUT/'controller.py').write_bytes(Path(__file__).read_bytes())


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


paths = subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def hashes(): return {name:sha(WORK/name) for name in paths}
env = {k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(TARGET),
 CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
 TEMP=str(TARGET/'tmp'), TMP=str(TARGET/'tmp'), LOCALAPPDATA=str(OUT/'appdata'), RUST_BACKTRACE='full',
 PYTHONDONTWRITEBYTECODE='1')
runtime = ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
env['PATH'] = str(runtime)+';'+env['PATH']
report = dict(status='running', head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),
 source_sha256=hashes(), stages=[], started_utc=datetime.now(timezone.utc).isoformat(),
 limits=['No learned-model inference or GPU experiment; actual CLI must refuse changed RGB before submitting work',
         'Original32 selected inputs and prepared hashes preserved; only an explicit separate negative copy changes',
         'Exact three new analytic controls, actual executable build and default file/stderr/empty-stdout control',
         'One original command per stage; failures retained; no retry, weakened assertion, panel edit or cleanup'])


def save():
    pending=OUT/'receipt.pending.json'; pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    os.replace(pending,OUT/'receipt.json')


def run(name, command, expected=0):
    row=dict(name=name,command=[str(v) for v in command],expected_exit=expected)
    report['stages'].append(row); save()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        row['pid']=child.pid; save(); row['exit_code']=child.wait()
    save(); assert row['exit_code']==expected,(name,'original failure retained')


save()
try:
    prepared=json.loads((INPUTS/'receipt.json').read_text())
    assert prepared['source_unchanged'] and sha(INPUTS/'inputs.json')==prepared['inputs_sha256']
    identities=json.loads((INPUTS/'inputs.json').read_text())
    for row in identities:
        for kind in ('rgb','depth'):
            identity=row[kind+'_input']; assert sha(INPUTS/identity['filename'])==identity['sha256']
    colocated=json.loads((BASE/'depth75-qualified-runtime-binding-v1/receipt.json').read_text())['runtime_colocation']
    for item in colocated: assert sha(Path(item['path']))==item['sha256']
    run('probe-unit-tests',['cargo','test','--locked','--offline','-p','motion-host','--example','depth_reference',
                          '--features','ai-depth','--','--test-threads=1'])
    text=(OUT/'probe-unit-tests.stdout.log').read_text()
    assert re.search(r'^test result: ok\. 3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out',text,re.M)
    for name in ('cohort_rejects_changed_role_order_extent_path_or_digest',
                 'source_byte_replacement_at_the_same_path_cannot_enter_the_cohort',
                 'prepared_identity_matches_worker_and_separates_bytes_and_dimensions'):
        assert len(re.findall(r'^test tests::'+name+r' \.\.\. ok$',text,re.M))==1
    run('probe-product-build',['cargo','build','--locked','--offline','-p','motion-host','--example','depth_reference','--features','ai-depth'])
    tampered=OUT/'tampered-input'; tampered.mkdir(); (tampered/'inputs.json').write_bytes((INPUTS/'inputs.json').read_bytes())
    source=bytearray((INPUTS/'00.rgb').read_bytes()); source[0]^=1; (tampered/'00.rgb').write_bytes(source)
    model=BASE/'depth75-resolution-models-v1/266/export/depth_anything_v2_vits_266.onnx'
    assert model.is_file() and model.with_name('model.json').is_file()
    driver=TARGET/'debug/examples/depth_reference.exe'
    report['driver_sha256']=sha(driver); save()
    run('changed-rgb-before-inference',[driver,'onnx',ROOT/'.tools/ai-depth74/venv/Scripts/python.exe',model,
        BASE/'depth75-wgsl-cache-resources-v2/program.json',TARGET/'debug/motion-depth-wgsl.exe',tampered,OUT/'refused'],expected=1)
    cause='reference RGB differs from frozen preparation identity'
    assert not (OUT/'changed-rgb-before-inference.stdout.log').read_bytes()
    console=(OUT/'changed-rgb-before-inference.stderr.log').read_text()
    logs=(OUT/'refused/logs/motion-studio.log').read_text()
    partial=json.loads((OUT/'refused/measurements.json').read_text())
    assert partial['status']=='failed' and partial['samples']==[] and partial['cause']==cause
    assert 'logging initialized level=INFO' in logs and 'start operation=depth_reference phase=source_plan' in logs
    assert 'ERROR' in logs and cause in logs and 'ERROR depth_reference:' in console and cause in console
    assert 'start #' not in logs
    assert sha(INPUTS/'00.rgb')==identities[0]['rgb_input']['sha256']
    report.update(status='three_controls_actual_build_and_default_cli_source_refusal_passed',
      unit_tests=dict(passed=3,failed=0,ignored=0,filtered=0),
      actual_failure=dict(cause=cause,file=True,stderr=True,stdout_bytes=0,samples=0,submitted_worker_start_records=0),
      retained_private_output_files=['refused/measurements.json','refused/logs/motion-studio.log'])
    save()
except BaseException:
    report['status']='failed_original_outputs_retained';report['cause']=traceback.format_exc();save();raise
finally:
    report['source_unchanged']=hashes()==report['source_sha256'];report['finished_utc']=datetime.now(timezone.utc).isoformat();save()
    assert report['source_unchanged'],'Source changed during original native probe qualification'
