"""Archive completed native correction and actual sensor comparison without pixels."""
from pathlib import Path
import hashlib, json, subprocess, zipfile
ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
NATIVE=BASE/'depth75-reference-probe-native-v2';ACTUAL=BASE/'depth75-reference-onnx266-v2'
assert json.loads((NATIVE/'session-consumed.json').read_text())==dict(session=86270,consumed=True,exit_code=0)
assert json.loads((ACTUAL/'session-consumed.json').read_text())==dict(session=76813,consumed=True,exit_code=0)
a=json.loads((NATIVE/'receipt.json').read_text());b=json.loads((ACTUAL/'receipt.json').read_text())
assert a['status']=='three_controls_actual_build_and_default_cli_source_refusal_passed' and a['source_unchanged']
assert b['status']=='actual32_onnx266_measurements_and24_held_out_sensor_reduction_completed' and b['source_unchanged']
assert a['head']==b['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert a['source_sha256']==b['source_sha256']
def sha(raw):return hashlib.sha256(raw).hexdigest()
for name,digest in b['source_sha256'].items():assert sha((WORK/name).read_bytes())==digest,name
assert not (ACTUAL/'actual.stdout.log').read_bytes()
measure=json.loads((ACTUAL/'onnx266/measurements.json').read_text());assert len(measure['samples'])==32
for row in measure['samples']:
 raw=(ACTUAL/'onnx266'/row['output']['filename']).read_bytes()
 assert len(raw)==row['output']['bytes']==640*480*4 and sha(raw)==row['output']['sha256']
members={}
for label,folder,names in (
 ('native-v2',NATIVE,('controller.py','receipt.json','session-consumed.json','probe-unit-tests.stdout.log',
 'probe-unit-tests.stderr.log','probe-product-build.stdout.log','probe-product-build.stderr.log',
 'changed-rgb-before-inference.stdout.log','changed-rgb-before-inference.stderr.log',
 'refused/measurements.json','refused/logs/motion-studio.log')),
 ('onnx266-v2',ACTUAL,('controller.py','receipt.json','session-consumed.json','actual.stdout.log','actual.stderr.log',
 'quality.json','onnx266/measurements.json','onnx266/logs/motion-studio.log'))):
 for name in names:members[label+'/'+name]=(folder/name).read_bytes()
for name in ('crates/motion-host/examples/depth_reference.rs','tools/depth_reference_metrics.py'):
 members['source/'+name]=(WORK/name).read_bytes()
members['archive-controller.py']=Path(__file__).read_bytes()
data=WORK/'engineering/validation/data';archive=data/'depth75-reference-onnx266-v2.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(members.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
 assert sorted(z.namelist())==sorted(members)
 for name,raw in members.items():assert z.read(name)==raw
manifest=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),head=b['head'],
 native_tests=dict(passed=3,failed=0,ignored=0,filtered=0),actual_product_build='passed',
 actual_cohort=dict(samples=32,calibration_frames=8,evaluation_frames=24,summary=b['actual_summary'],
 quality=b['quality_aggregate'],calibration=b['calibration']),
 limits=['One independently sensed indoor sequence, not domain certification or quality-tier admission',
 'Original native-v1 driver and model-cohort-v1 failures remain failed in separate archives',
 'Cold worker wall times include resolution/inference/transport and all32 observations; not real-time claims',
 'Transition jump remains unknown; complete memory/long thermal qualification remains pending',
 'No model, RGB/sensor image, learned prediction array or executable redistributed'],
 members=[dict(path=name,bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(members.items())])
(data/'depth75-reference-onnx266-v2.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:manifest[k] for k in ('archive','bytes','sha256')}))
