from pathlib import Path
import hashlib,json,subprocess,urllib.request

root=Path('E:/Dev/aem/.tools/gltf-scene87-fixtures')
root.mkdir(exist_ok=True)
repo='KhronosGroup/glTF-Sample-Assets'
token=subprocess.check_output(['gh','auth','token','--hostname','github.com'],text=True).strip()
def get(url,limit=24<<20):
    headers={'User-Agent':'Motion-Studio-scene-validation'}
    if url.startswith('https://api.github.com/'):
        headers['Authorization']='Bearer '+token
    request=urllib.request.Request(url,headers=headers)
    with urllib.request.urlopen(request,timeout=60) as response:
        value=response.read(limit+1)
    assert len(value)<=limit
    return value
revision=json.loads(get('https://api.github.com/repos/'+repo+'/commits/main'))['sha']
files=[]
for model in ['Avocado','BoxVertexColors']:
    for relative in ['README.md','LICENSE.md','metadata.json','glTF','glTF-Binary']:
        path='Models/'+model+'/'+relative
        paths=[path]
        if relative.startswith('glTF'):
            rows=json.loads(get('https://api.github.com/repos/'+repo+'/contents/'+path+'?ref='+revision))
            paths=[row['path'] for row in rows if row['type']=='file' and row['name'].endswith(('.gltf','.glb','.bin','.png','.jpg','.jpeg'))]
        for path in paths:
            url='https://raw.githubusercontent.com/'+repo+'/'+revision+'/'+path
            data=get(url);target=root/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
            files.append(dict(path=path,url=url,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
manifest=dict(repository='https://github.com/'+repo,revision=revision,files=files,
    purpose='External CPU import/freeze validation only; no assets enter the product or example library',
    authors={'Avocado':'Microsoft; Public 2017; CC0-1.0','BoxVertexColors':'Marco Hutter; Public 2023; CC0-1.0'},
    modificationScope='Unmodified pinned downloads; owned bundles are generated only for local roundtrip validation')
(root/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps(dict(revision=revision,files=len(files),bytes=sum(f['bytes'] for f in files))),flush=True)
