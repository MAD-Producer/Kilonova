from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/gltf-scene';folder=root/'.tools/issue-closure-review'
rust=root/'artifacts/pr-queue/issue87-rust-v3';official=root/'artifacts/pr-queue/issue87-official-v2';fixture=root/'.tools/gltf-scene87-fixtures'
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((rust/'accepted.json').read_text(encoding='utf-8'));o=json.loads((official/'accepted.json').read_text(encoding='utf-8'))
assert r['tests']==dict(passed=25,failed=0,ignored=0) and r['sourceUnchanged'] and o['sourceUnchanged'] and len(o['cases'])==4
for path,digest in r['source'].items():assert sha((work/path).read_bytes())==digest,path
for path,digest in o['sources'].items():assert sha((root/path).read_bytes())==digest,path
payload={}
def add(name,path):
    assert name not in payload and path.stat().st_size<16<<20
    assert path.suffix not in ['.mscn','.glb','.gltf','.png','.bin','.exe','.dll']
    payload[name]=path.read_bytes()
for label,run in [('rust',rust),('official',official)]:
    for path in sorted(run.rglob('*')):
        if path.is_file() and path.suffix not in ['.mscn','.gltf']:add(label+'/'+path.relative_to(run).as_posix(),path)
for path in sorted((work/'crates/motion-scene').rglob('*')):
    if path.is_file():add('source/'+path.relative_to(work).as_posix(),path)
for name in ['Cargo.lock','Cargo.toml','ATTRIBUTION.md','PROVENANCE.md','NOTICE','desktop/app/src/logging.rs','engineering/host-api/scene-ingestion.md']:
    add('source/'+name,work/name)
for model in ['Avocado','BoxVertexColors']:
    for name in ['README.md','LICENSE.md','metadata.json']:add('provenance/'+model+'/'+name,fixture/'Models'/model/name)
add('provenance/manifest.json',fixture/'manifest.json')
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:add('external-probe/'+name,root/'.tools/gltf-scene87-probe'/name)
for name in ['prepare-issue87-official-fixtures.py','validate-issue87-official.py','validate-issue87-rust-frozen.py']:
    add('controllers/'+name,folder/name)
add('controllers/archive.py',Path(__file__))
manifest=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
    scope='CPU ingestion and frozen resource foundation only; no GPU/PBR/animation/UI/Android acceptance; external CC0 models and encoded bundles are not redistributed',
    files={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(payload.items())})
payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=work/'engineering/validation/data/gltf-ingestion-3e19a47d.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(payload.items()):archive.writestr(name,data)
with zipfile.ZipFile(dest) as archive:
    assert set(archive.namelist())==set(payload)
    for name,data in payload.items():assert sha(archive.read(name))==sha(data),name
result=dict(file=dest.name,bytes=dest.stat().st_size,files=len(payload),sha256=sha(dest.read_bytes()))
(root/'artifacts/pr-queue/issue87-ingestion-archive.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
