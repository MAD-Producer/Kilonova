#[path = "../../../.worktrees/gltf-scene/desktop/app/src/logging.rs"]
mod logging;
// This external CPU probe has no desktop Engine. Do not fabricate worker context.
mod engine {
    pub fn current_command()->Option<(u64,&'static str,std::time::Duration)> { None }
}
use motion_scene::{import, import_frozen, DirectoryResolver, ImportContext, ImportLimits};
use std::{fs,io::Read,path::PathBuf};

fn run(input:PathBuf,out:PathBuf)->Result<(),Box<dyn std::error::Error>> {
    let limits=ImportLimits::default();
    let mut source=Vec::new();
    fs::File::open(&input)?.take(limits.max_source_bytes as u64+1).read_to_end(&mut source)?;
    let mut resolver=DirectoryResolver::new(input.parent().ok_or("source has no directory")?)?;
    let scene=import(ImportContext{request:8701,source:87},&source,&mut resolver,&limits)?;
    let frozen=scene.freeze(&source,128<<20)?;
    fs::write(out.join("scene.mscn"),&frozen)?;
    let restored=import_frozen(ImportContext{request:8702,source:87},&frozen,128<<20,&limits)?;
    if restored!=scene {return Err("frozen scene differs from original import".into());}
    let instances=scene.default_scene().map(|id|scene.instances(id,100.)).transpose()?.unwrap_or_default();
    let meshes:Vec<_>=scene.meshes().iter().map(|m|m.primitives.iter().map(|p|serde_json::json!({
        "positions":p.positions,"indices":p.indices,"normals":p.normals,"tangents":p.tangents,
        "texcoords":p.texcoords,"colors":p.colors,"material":p.material
    })).collect::<Vec<_>>()).collect();
    let report=serde_json::json!({"sourceSha256":scene.source_sha256(),"meshes":meshes,
        "materials":scene.materials(),"textures":scene.textures(),"samplers":scene.samplers(),
        "images":scene.images().iter().map(|i|serde_json::json!({"sha256":i.resource.sha256,"bytes":i.resource.bytes.len(),"mime":i.mime_type})).collect::<Vec<_>>(),
        "instances":instances.iter().map(|(mesh,matrix)|serde_json::json!({"mesh":mesh,"matrix":matrix.to_cols_array()})).collect::<Vec<_>>(),
        "retainedBytes":scene.retained_bytes(),"frozenBytes":frozen.len(),"frozenRoundtripEqual":true});
    fs::write(out.join("report.json"),serde_json::to_vec_pretty(&report)?)?;
    Ok(())
}

fn main() {
    let args:Vec<_>=std::env::args_os().collect();
    assert_eq!(args.len(),3,"input path and output directory required");
    let input=PathBuf::from(&args[1]);let out=PathBuf::from(&args[2]);
    fs::create_dir_all(&out).expect("create probe output");
    let _guard=logging::init(out.join("logs")).expect("initialize actual desktop file logger");
    if let Err(error)=run(input,out.clone()) {
        let cause:String=error.to_string().chars().take(1024).collect();
        log::error!("scene_probe request=8701 source=87 cause={}",cause);
        fs::write(out.join("error.json"),serde_json::to_vec_pretty(&serde_json::json!({"cause":cause})).expect("encode error")).expect("write error");
        logging::flush(); std::process::exit(2);
    }
    logging::flush();
}
