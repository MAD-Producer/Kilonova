"""One complete maintained-workspace regression after actual memory/load proof."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,os,re,shutil,subprocess,time,traceback

ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
OUT=BASE/'depth75-memory-current-workspace-v1';TARGET=ROOT/'target/depth-wgsl-cache75-contract'
assert not OUT.exists() and shutil.disk_usage(ROOT).free>=10<<30
for folder,session in [('depth75-sustained-reference-v1',65993),('depth75-continuous-alignment-v1',21284)]:
    marker=json.loads((BASE/folder/'session-consumed.json').read_text())
    assert marker==dict(session=session,consumed=True,exit_code=0)
checkpoint=BASE/'depth75-resume-current.json';state=json.loads(checkpoint.read_text(encoding='utf-8'))
assert state['versionedCache75']['activeController'] is None and not state['versionedCache75']['ownHeavyWorkloads']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
main=subprocess.check_output(['git','rev-parse','origin/main'],cwd=WORK,text=True).strip()
assert head=='ad799f2f634b5a3897c7df2e06053216db9e86a4' and main=='ac65d279c57626d7aa7e28061a1a7fdf7889c68a'
subprocess.check_call(['git','merge-base','--is-ancestor',main,head],cwd=WORK)
names=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def sources():return {name:sha(WORK/name) for name in names}
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),
           CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'appdata'),TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'))
env['PATH']=str(ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')+';'+env['PATH']
command=['cargo','test','--workspace','--exclude','motion-android','--features',
         'motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth',
         '--no-fail-fast','--locked','--offline','--','--test-threads=1']
report=dict(status='running',head=head,main=main,source_sha256=sources(),command=command,
            started_utc=datetime.now(timezone.utc).isoformat(),free_bytes_before=shutil.disk_usage(ROOT).free,
            limits=['Complete maintained workspace, Android excluded by user',
                    'Original features, assertions, ignores, deadlines, default backend/stack and10GiB admission unchanged',
                    'One owned heavy workload; no foreign process stopped or cache removed',
                    'Earlier failed runs keep their original source/environment-specific outcomes',
                    'Exact source frozen through original command and child termination and consumed handle',
                    'Native target/accounting completeness required; missing targets or abnormal exits cannot pass'])
def save():
    pending=OUT/'receipt.pending.json';pending.write_text(json.dumps(report,indent=2)+'\n');os.replace(pending,OUT/'receipt.json')
state['versionedCache75'].update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(kind='complete maintained-workspace native regression',head=head,output=str(OUT))])
checkpoint.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8');save();began=time.monotonic()
try:
    result=subprocess.run(['cargo','metadata','--no-deps','--format-version','1','--locked','--offline'],cwd=WORK,env=env,capture_output=True)
    (OUT/'metadata.stderr.log').write_bytes(result.stderr);(OUT/'cargo-metadata.json').write_bytes(result.stdout)
    assert result.returncode==0,'Original metadata failure; no test command started'
    metadata=json.loads(result.stdout)
    with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);report['pid']=child.pid;save();report['exit_code']=child.wait()
    stdout=(OUT/'stdout.log').read_text(errors='replace');stderr=(OUT/'stderr.log').read_text(errors='replace')
    summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
    executables=re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)',stderr,re.M)
    docs=re.findall(r'^\s*Doc-tests (\S+)\s*$',stderr,re.M)
    expected=[];by_name={};doc_owners={}
    for package in metadata['packages']:
        if package['id'] not in metadata['workspace_members'] or package['name']=='motion-android':continue
        for target in package['targets']:
            if not target['test']:continue
            relative=Path(target['src_path']).relative_to(WORK).as_posix();key=package['name']+'::'+target['kind'][0]+'::'+relative
            expected.append(key);by_name.setdefault(target['name'].replace('-','_'),[]).append((relative,key))
        if any(target['doctest'] for target in package['targets']):
            key='doc::'+package['name'];expected.append(key);doc_owners[package['name'].replace('-','_')]=key
    observed=[];bound=[]
    for executable in executables:
        path=Path(executable);raw=path.with_suffix('.d').read_bytes()
        line=raw.decode().splitlines()[0].split(': ',1)[1].replace('\\','/')
        name=re.sub(r'-[a-f0-9]+$','',path.stem)
        owners=[key for relative,key in by_name[name] if re.search(r'(?<!\S)'+re.escape(relative)+r'(?!\S)',line)]
        assert len(owners)==1,(executable,owners)
        observed.extend(owners);bound.append(dict(executable=executable,target=owners[0],dep_info_sha256=hashlib.sha256(raw).hexdigest()))
    observed.extend(doc_owners[name] for name in docs)
    report.update(totals=dict(passed=sum(int(v[1]) for v in summaries),failed=sum(int(v[2]) for v in summaries),
        original_ignored=sum(int(v[3]) for v in summaries),filtered=sum(int(v[5]) for v in summaries),
        summary_count=len(summaries),observed_invocations=len(observed),expected_invocations=len(expected)),
        source_bound_invocations=bound,missing_source_targets=dict(Counter(expected)-Counter(observed)),
        unexpected_source_targets=dict(Counter(observed)-Counter(expected)),
        complete_target_accounting=Counter(expected)==Counter(observed) and len(summaries)==len(observed),
        abnormal_target_exits=[line for line in stderr.splitlines() if "process didn't exit successfully:" in line],
        failed_test_names=re.findall(r'^test ([^\r\n]+?) \.\.\. FAILED\s*$',stdout,re.M))
    report['status']='complete_maintained_workspace_passed' if report['exit_code']==0 and report['complete_target_accounting'] and not report['totals']['failed'] and not report['totals']['filtered'] and not report['abnormal_target_exits'] else 'failed_original_outputs_retained'
except BaseException:
    report.update(status='observer_failed_original_outputs_retained',cause=traceback.format_exc())
finally:
    report.update(source_unchanged=sources()==report['source_sha256'] and subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,
                  completed_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-began,free_bytes_after=shutil.disk_usage(ROOT).free)
    save()
print(json.dumps({k:report.get(k) for k in ('status','exit_code','totals','abnormal_target_exits','failed_test_names','cause','source_unchanged')}))
raise SystemExit(0 if report['status']=='complete_maintained_workspace_passed' and report['source_unchanged'] else 1)
