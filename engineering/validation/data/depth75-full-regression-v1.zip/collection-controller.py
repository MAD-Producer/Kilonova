"""Archive the original failed broad regression; no native commands or retries."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess
import zipfile

root = Path('E:/Dev/aem')
art = root / 'artifacts/pr-queue'
source = art / 'depth75-memory-current-workspace-v1'
out = art / 'depth75-full-regression-public-v1'
work = root / '.worktrees/depth-wgsl-cache75'
report = json.loads((source / 'receipt.json').read_text())
consumed = json.loads((source / 'session-consumed.json').read_text())
assert consumed['session'] == 87729 and consumed['consumed'] is True and consumed['exit_code'] == 1
assert consumed['cargo_exit_code'] == report['exit_code'] == 101
assert report['status'] == 'failed_original_outputs_retained'
assert report['source_unchanged'] is True and report['completed_utc']
assert report['totals']['expected_invocations'] == report['totals']['observed_invocations'] == 449
assert report['totals']['summary_count'] == 447
assert report['totals']['passed'] == 5274 and report['totals']['failed'] == 2
assert report['totals']['original_ignored'] == 78 and report['totals']['filtered'] == 0
assert not report['missing_source_targets'] and not report['unexpected_source_targets']
assert len(report['abnormal_target_exits']) == len(report['failed_test_names']) == 2
assert report['complete_target_accounting'] is False
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=work)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip() == report['head']
out.mkdir(exist_ok=False)
shutil.copyfile(Path(__file__), out / 'collection-controller.py')
for name in ('controller.py', 'receipt.json', 'cargo-metadata.json', 'metadata.stderr.log',
    'stdout.log', 'stderr.log', 'session-consumed.json', 'desktop-failure-assessment.json',
    'abnormal-target-interim.json'):
    shutil.copyfile(source / name, out / name)
selected = [
    'desktop/app/src/engine/sampling_playback_tests.rs',
    'desktop/app/src/engine/failure/composition_tests/accumulator_admission.rs',
    'crates/motion-effects/tests/packages.rs',
    'crates/motion-render/tests/pointwise_fusion.rs',
]
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
bindings = {}
for name in selected:
    path = work / name
    assert sha(path) == report['source_sha256'][name]
    target = out / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    bindings[name] = sha(target)
collection = dict(status='failed_original_complete_command_preserved_not_acceptance',
    source_head=report['head'], baseline_main=report['main'], original_session=87729,
    original_controller_exit=1, original_cargo_exit=101,
    totals=report['totals'], all_expected_invocations_observed=True,
    normal_summary_completeness=False, source_unchanged=True,
    failed_tests=report['failed_test_names'], abnormal_targets=report['abnormal_target_exits'],
    selected_source_sha256=bindings,
    observed_utc=datetime.now(timezone.utc).isoformat(),
    limits=['All449 invocations were observed but two native targets lack normal test summaries',
        '5274 is the sum of completed target summaries; partial crashed-target successes are not inferred',
        'No ignored original tests reclassified as passes; zero filtered tests',
        'Remote CI success cannot replace this failed local command',
        'Coincident loader warnings do not establish fault causation',
        'No native workload, model acquisition, retry, backend/stack/deadline change or assertion edit',
        'Selected source snapshots and complete tracked hashes are not a complete source archive'])
(out / 'collection.json').write_text(json.dumps(collection, indent=2) + '\n')
members = {}
for path in sorted(out.rglob('*')):
    if path.is_file():
        members[path.relative_to(out).as_posix()] = dict(bytes=path.stat().st_size, sha256=sha(path))
archive = out / 'depth75-full-regression-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
    for name in members:
        target.write(out / name, name)
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(members)
    for name, expected in members.items():
        data = target.read(name)
        assert len(data) == expected['bytes']
        assert hashlib.sha256(data).hexdigest() == expected['sha256']
manifest = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=members,
    readback='Every member CRC, byte length and SHA-256 verified',
    acceptance='Original failed command retained; not a complete regression pass')
(out / 'depth75-full-regression-v1.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({key: manifest[key] for key in ('archive', 'bytes', 'sha256', 'acceptance')}))
