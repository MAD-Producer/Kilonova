from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-import88'
out = root / 'artifacts/pr-queue/tracking88-pair-clock-integration-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=work, encoding='utf-8').splitlines()
sources = {p: sha(work / p) for p in sorted(set(paths)) if p.endswith(('.rs', '.wgsl', 'Cargo.toml', 'Cargo.lock')) and (work / p).is_file()}
owned = ['crates/motion-model/src/commands.rs', 'crates/motion-core/tests/tracking_replacement.rs',
    'crates/motion-core/tests/tracking_replacement/layer_time.rs']
for relative in owned:
    target = out / 'source' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((work / relative).read_bytes())
env = os.environ.copy()
for name in ['MOTION_LOG', 'MOTION_TRACKED_PAIR_NATIVE_DIR', 'MOTION_TRACKED_PAIR_AUDIO_DIR',
             'MOTION_TRACKING_VIDEO_NATIVE_DIR', 'MOTION_TRACKING_VIDEO_CLOCK_DIR']:
    env.pop(name, None)
env.update(CARGO_HOME=str(root / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1', RUST_BACKTRACE='full',
    LIBCLANG_PATH=str(root / '.tools/python-libclang/clang/native'),
    TEMP=str(root / 'target/ci-policy-validation-tmp'), TMP=str(root / 'target/ci-policy-validation-tmp'))
ffmpeg = root / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(FFMPEG_DIR=str(ffmpeg), FFMPEG_INCLUDE_DIR=str(ffmpeg / 'include'), FFMPEG_LIB_DIR=str(ffmpeg / 'lib'))
env['PATH'] = str(ffmpeg / 'bin') + os.pathsep + env['PATH']
common = ['--locked', '--offline']
desktop = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg', '--bin', 'motion-studio'] + common
commands = [
    ('model-core', ['cargo', 'test', '-p', 'motion-model', '-p', 'motion-core'] + common + ['--no-fail-fast', '--', '--test-threads=1'], {}),
    ('host-lib', ['cargo', 'test', '-p', 'motion-host'] + common + ['--lib', '--', '--test-threads=1'], {}),
    ('host-integration', ['cargo', 'test', '-p', 'motion-host'] + common + ['--test', 'tracking_relink', '--test', 'asset_registration', '--no-fail-fast', '--', '--test-threads=1'], {}),
    ('media-video', ['cargo', 'test', '-p', 'motion-media'] + common + ['--lib', 'video::', '--', '--test-threads=1'], {}),
    ('paired-native', desktop + ['engine::tracking_video_replacement_tests::paired::fresh_plate_and_solve_are_atomic_native_verified_undoable_and_reopenable', '--', '--exact', '--test-threads=1', '--nocapture'], {'MOTION_TRACKED_PAIR_NATIVE_DIR': str(out / 'paired')}),
    ('audio-native', desktop + ['engine::tracking_video_replacement_tests::paired::audio::native_audio_and_tracking_replace_rollback_undo_redo_and_reopen_together', '--', '--exact', '--test-threads=1', '--nocapture'], {'MOTION_TRACKED_PAIR_AUDIO_DIR': str(out / 'audio')}),
    ('mapped-native', desktop + ['engine::tracking_video_replacement_tests::mapped_time::mapped_original_video_keeps_native_picture_and_authored_clock_across_replacement', '--', '--exact', '--test-threads=1', '--nocapture'], {'MOTION_TRACKING_VIDEO_CLOCK_DIR': str(out / 'mapped')}),
]
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), source=sources, steps=[],
    head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, encoding='utf-8').strip(),
    integratedParent=subprocess.check_output(['git', 'rev-parse', 'MERGE_HEAD'], cwd=work, encoding='utf-8').strip())
started = time.monotonic()
def save():
    pending = out / 'exit.pending.json'
    pending.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(pending, out / 'exit.json')
save()
try:
    for name, command, extra in commands:
        step = dict(name=name, command=command, startedUtc=datetime.now(timezone.utc).isoformat())
        report['steps'].append(step)
        save()
        with (out / f'{name}.stdout.log').open('wb') as stdout, (out / f'{name}.stderr.log').open('wb') as stderr:
            child = subprocess.Popen(command, cwd=work, env={**env, **extra}, stdout=stdout, stderr=stderr)
            step['pid'] = child.pid
            save()
            step['exitCode'] = child.wait()
        step['completedUtc'] = datetime.now(timezone.utc).isoformat()
        log = (out / f'{name}.stdout.log').read_text(encoding='utf-8', errors='replace')
        step['summaries'] = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', log)
        save()
        assert step['exitCode'] == 0, step
        assert step['summaries'] and sum(int(s[1]) for s in step['summaries']) > 0, 'test did not execute'
        assert all(sha(work / p) == digest for p, digest in sources.items()), 'source changed'
    assert len(json.loads((out / 'mapped/report.json').read_text(encoding='utf-8'))['cases']) == 4
    for mode, label, requests in [('paired', 'paired-native', ['pair-fresh']),
            ('audio', 'audio-native', ['pair-audio-binding', 'pair-audio-save'])]:
        log = (out / mode / 'logs/motion-studio.log').read_text(encoding='utf-8')
        stderr = (out / f'{label}.stderr.log').read_text(encoding='utf-8', errors='replace')
        stdout = (out / f'{label}.stdout.log').read_text(encoding='utf-8', errors='replace')
        for request in requests:
            assert f'tracked video replacement start request={request}' in log
            for sink in [log, stderr]:
                assert f'tracked video replacement failed request={request}' in sink
        assert 'tracked video replacement failed request=' not in stdout
    report['sourceUnchanged'] = all(sha(work / p) == digest for p, digest in sources.items())
    assert report['sourceUnchanged']
    report['status'] = 'paired_replacement_clock_integration_and_native_controls_passed'
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - started, 3))
    save()
    print(json.dumps({key: report.get(key) for key in ['status', 'failure', 'elapsedSeconds']}, indent=2), flush=True)
