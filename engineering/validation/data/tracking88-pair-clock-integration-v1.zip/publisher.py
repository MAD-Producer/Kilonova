from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-import88'
helper = root / '.tools/issue-closure-review'
out = root / 'artifacts/pr-queue/tracking88-pair-clock-integration-v1'
sha = lambda content: hashlib.sha256(content).hexdigest()
report = json.loads((out / 'exit.json').read_text(encoding='utf-8'))
assert report['status'] == 'paired_replacement_clock_integration_and_native_controls_passed'
assert report['sourceUnchanged'] and all(step['exitCode'] == 0 for step in report['steps'])
assert all(sha((work / path).read_bytes()) == digest for path, digest in report['source'].items())
assert not subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=U'], cwd=work)
for base in ['origin/main', report['integratedParent']]:
    assert not subprocess.check_output(['git', 'diff', '--name-only', base, '--', 'desktop/app/src/panels'], cwd=work)
counts = {}
for step in report['steps']:
    rows = step['summaries']
    assert rows and all(row[0] == 'ok' and int(row[2]) == 0 for row in rows)
    counts[step['name']] = dict(passed=sum(int(row[1]) for row in rows), failed=0,
        ignored=sum(int(row[3]) for row in rows), targets=len(rows),
        filtered=sum(int(row[5]) for row in rows))
for name in ['paired-native', 'audio-native', 'mapped-native']:
    assert counts[name]['passed'] == 1
for directory, request in [('paired', 'pair-fresh'), ('audio', 'pair-audio-new')]:
    lines = (out / directory / 'logs/motion-studio.log').read_text(encoding='utf-8').splitlines()
    assert any(' INFO ' in line and f'tracked video replacement start request={request}' in line for line in lines)
    assert any(' ERROR ' in line and 'tracked video replacement failed request=' in line for line in lines)
members = {'publisher.py': Path(__file__).read_bytes()}
for path in out.rglob('*'):
    if path.is_file() and path.suffix in {'.json', '.log', '.rs', '.py', '.png'}:
        members[path.relative_to(out).as_posix()] = path.read_bytes()
source = {}
for path in (out / 'source').rglob('*.rs'):
    relative = path.relative_to(out / 'source').as_posix()
    current = (work / relative).read_bytes()
    staged = subprocess.check_output(['git', 'show', ':' + relative], cwd=work)
    assert current == path.read_bytes() and staged == current.replace(b'\r\n', b'\n'), relative
    source[relative] = dict(rawSha256=sha(current), gitLfSha256=sha(staged))
archive = work / 'engineering/validation/data/tracking88-pair-clock-integration-v1.zip'
receipt_path = archive.with_suffix('.json')
assert not archive.exists() and not receipt_path.exists()
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, content in sorted(members.items()):
        zipped.writestr(name, content)
with zipfile.ZipFile(archive) as zipped:
    assert set(zipped.namelist()) == set(members)
    for name, content in members.items():
        assert zipped.read(name) == content, name
limits = ['No fresh complete desktop package or workspace regression',
    'Final-head cross-platform CI remains required',
    'Native controls capture offscreen GPU output, not a retained native Surface',
    'Mapped footage and paired publication are separate native controls; their combination is covered at the core history boundary',
    'Photographed planar tracker quality, prerequisites #85/#86 and full 3D route remain separate incomplete acceptance',
    'Android is retired and excluded']
receipt = dict(status=report['status'], head=report['head'], integratedParent=report['integratedParent'],
    counts=counts, source=source, steps=report['steps'], elapsedSeconds=report['elapsedSeconds'], limits=limits,
    archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
        members={name: dict(bytes=len(content), sha256=sha(content)) for name, content in sorted(members.items())}))
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
lines = '\n'.join(f"- {name}: {value['passed']} passed, {value['failed']} failed, {value['ignored']} ignored; {value['targets']} summaries, {value['filtered']} filtered" for name, value in counts.items())
document = f'''# #88 paired replacement on the integrated layer-time baseline

PR #583 integrates parent #581 `{report['integratedParent']}`, including maintained
main `9d085c0f` and its layer stretch/reverse/source mapping. The only textual
conflict is in `Command::composition_transaction`: continuous spatial, local
curve and handle edits retain main's early-return policy, while
`ReplaceTrackedVideo` retains its atomic composition transaction. Both command
families and current-only project schema 36 remain present.

The new core control is reused unchanged from PR #587's combination proof. It
stretches a real video layer's property clock by 3/2, then replaces its original
video and camera solve. It verifies preserved authored layers, a changed camera
track, distinct revisions, exact full-project undo/redo through both edits, and
current-schema serialization/reopening. No existing assertion is changed. This
is a core authoring/history proof, not a native video timing proof by itself.

## Executed gates on frozen integrated source

{lines}

The paired native control crosses actual FFmpeg import, original-source SHA and
PTS validation, GPU capture, real staged-resource rollback, successful atomic
publication, undo/redo and reopening. The audio control additionally verifies the
native linked audio/PCM/waveform resources and independently timed audible
pulses. The inherited mapped-video control independently compares four explicit
clocks (stretch, reverse, linear source remap and hold) to native reference images.
Their combined mapped-pair boundary is proven by the core control; no claim is
made that these separate native tests exercise every mapped-pair combination.

MOTION_LOG is unset for all commands. Native paired and audio file logs contain
Info admission starts, and actual failure records appear in both file and
stderr, with those records absent from test stdout. This is test-process stdout
isolation, not an MCP JSON-RPC transport proof. Each native test executes in its
own process because the logger initializes once. All native commands explicitly
enable ffmpeg; their filtered test counts are not counted as passes.

The [receipt](data/tracking88-pair-clock-integration-v1.json) and
[read-back verified archive](data/tracking88-pair-clock-integration-v1.zip) retain
the executed commands, all relevant source hashes, merge resolution/new-control
snapshots, raw output and generated native images. Source remained unchanged
throughout execution; snapshots are checked against staged LF-normalized blobs.
Existing manual ignores are retained and reported, with no new ignore added.

No panel differs from maintained main or the integrated parent. No dependency,
asset, UI, layout, interaction, retry or worker timeout is authored here. The
large merge stat mostly inherits main's independently authored layer-time work.

## Remaining acceptance

This result does not establish a fresh complete desktop package or workspace
regression. Historical desktop package results on a different source revision
remain historical, including the earlier native crashes whose root cause is
still undetermined. Final-head cross-platform CI, retained native Surface
acceptance on this source, the photographed tracker quality gate, prerequisites
#85/#86 and full #88/3D-route acceptance remain separate work. Android is retired
and excluded. This PR is already formal; these bounded checks do not close #88.
'''
(work / 'engineering/validation/tracking88-pair-clock-integration-current.md').write_text(document, encoding='utf-8')
existing = work / 'engineering/validation/tracking88-paired-replacement-current.md'
text = existing.read_text(encoding='utf-8')
old = 'The PR remains a draft pending the unresolved full-regression gate and final-head\ncross-platform checks.'
assert old in text
text = text.replace(old, 'At the time of this recorded run the PR remained a draft pending the unresolved\nfull-regression gate and final-head cross-platform checks.')
text += '''\n\n## Current integrated-source follow-up\n\nPR #583 is now formal. The [layer-time integration record](tracking88-pair-clock-integration-current.md)\nand its source-bound evidence describe the latest parent/main synchronization,\ncomplete model/core and host-library regressions, actual paired video/audio\ncontrols, and exact remaining acceptance boundaries. Earlier results and failed\nruns above retain their original source and scope; they are not final-head claims.\n'''
existing.write_text(text, encoding='utf-8')
total = sum(value['passed'] for value in counts.values())
body = f'''替换已绑定跟踪解算的视频时，普通命令批次会先用旧解算校验新原片，无法安全完成联合替换。本 PR 增加一次提交新原片、全部原始解算及显式绑定变更的事务，保留资源 ID、原始文件和整组撤销历史；同时修正临时校验视图混用新视频与旧音轨元数据而拒绝有效替换的问题。

基于 #581，关联 #88，不关闭该 issue。#582 的跟踪原型独立处理；#584 提供本事务的 MCP 操作及实际预览缓存验收。

- 在发布前校验原片 SHA、真实解码尺寸及原始 PTS，拒绝不完整解算、过期候选及非法绑定
- 同步验证准备任务的视频和音轨元数据，保留既有资源身份及一次修订边界
- 验证原片、解算、PCM、波形及缓存的失败回滚，以及撤销重做和保存重开
- 覆盖工程已发布后的确认失败及 panic，保留被工程引用的资源和原始原因
- 保留原生测试子进程 PID、启动时间、耗时及原始退出码，成功条件不变

### 图层时钟基线整合

同步父 PR #581 `{report['integratedParent'][:8]}`，包含主分支图层时钟；保留连续手势事务策略和原片、解算联合替换原子性。

- 复用 #587 的组合测试，验证 3/2 变速与联合替换的独立修订、完整撤销重做及保存重开
- 当前整合源码累计 {total} 项通过；模型与核心完整包 {counts['model-core']['passed']} 项、host 完整库 {counts['host-lib']['passed']} 项，既有 ignored 单独列明
- 实际 FFmpeg/GPU 联合替换、音轨回滚与 PCM、四种图层时钟原片比较各 1 项通过
- 核验默认 Info 文件日志、实际 Error 文件与 stderr，以及测试 stdout 隔离

验收记录：[当前源码整合](https://github.com/MAD-Producer/Kilonova/blob/feat/88-atomic-plate-solve/engineering/validation/tracking88-pair-clock-integration-current.md)、[事务及历史失败](https://github.com/MAD-Producer/Kilonova/blob/feat/88-atomic-plate-solve/engineering/validation/tracking88-paired-replacement-current.md)。

本轮未重跑完整 desktop/workspace，最新提交跨平台 CI 待完成。历史源码 `52ce7ebf` 的 FFmpeg 桌面 package 回归为 1542 通过、0 失败、50 项既有 ignored，属于 #584 合并源码，不能替代本次最终源码回归。此前 binary-only 回归的三项原生子进程崩溃仍缺根因；受控发布故障注入不能替代原生编解码或 worker 关闭整链验证。映射视频与联合发布分别完成原生验收，其组合在核心历史边界验证，不宣称所有组合均有原生测试。

未新增 panels、布局、交互、依赖或资产。Android 停维，不在验收范围。外部文件并发写入不是永久租约，实拍 tracker 质量及 #88、完整 3D 路线仍未完成。
'''
(helper / 'tracking88-pair-clock-integration-pr-body.md').write_text(body, encoding='utf-8')
(helper / 'tracking88-pair-clock-integration-commit.txt').write_text('''test(tracking): 整合图层时钟并验证联合替换历史

- 保留连续手势事务策略与原片解算替换原子性
- 验证变速及联合替换的独立撤销重做和重开
- 复核实际视频音轨发布回滚与默认错误输出
- 归档冻结源码回归结果及剩余验收边界
''', encoding='utf-8')
print(json.dumps(dict(status=receipt['status'], counts=counts, totalPassed=total,
    archiveBytes=archive.stat().st_size, members=len(members)), indent=2), flush=True)
