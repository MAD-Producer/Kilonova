from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import time

root=Path('E:/Dev/aem')
work=root/'.worktrees/rational-frame-rates85'
out=root/'artifacts/pr-queue/professional-api86-screen-family-v2'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={p.relative_to(work).as_posix():sha(p) for folder in ['crates','desktop','tools','.github'] for p in (work/folder).rglob('*') if p.is_file() and p.suffix in ['.rs','.wgsl','.py','.yml','.toml']}
sources.update({p:sha(work/p) for p in ['Cargo.toml','Cargo.lock']})
command=['cargo','test','-p','motion-host','-p','motion-desktop-media']
for target in ['professional_screen','professional_relink','professional_mattes','node_parameter_animation','professional_compositing','layer_time_mapping']:
    command+=['--test',target]
command+=['--no-default-features','--features','motion-desktop-media/gpu-tests,motion-desktop-media/ffmpeg','--locked','--offline','--','--test-threads=1','--nocapture']
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),scope='All five native issue86 compositing examples plus eight original host integration tests with FFmpeg enabled; targeted family, not full workspace/desktop',base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),sources=sources,command=command)
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
save()
for key,folder in [('MOTION_PROFESSIONAL_SCREEN_ARTIFACTS','screen-shot'),('MOTION_PROFESSIONAL_RELINK_ARTIFACTS','relink-shot'),('MOTION_PROFESSIONAL_MATTE_ARTIFACTS','matte-shot'),('MOTION_NODE_PARAMETER_ARTIFACTS','node-runtime'),('MOTION_PROFESSIONAL_API_ARTIFACTS','camera-shot')]:
    os.environ[key]=str(out/folder)
started=time.monotonic()
try:
    with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=work,env=os.environ.copy(),stdout=stdout,stderr=stderr)
        report['pid']=child.pid
        save()
        report['exitCode']=child.wait()
    report['summaries']=re.findall(r'^test result: .+$',(out/'stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
    report['sourceUnchanged']=all(sha(work/p)==digest for p,digest in sources.items())
    assert report['exitCode']==0 and report['sourceUnchanged']
    assert len(report['summaries'])==6 and all('0 failed; 0 ignored' in s for s in report['summaries'])
    report['status']='passed_full_issue_acceptance_pending'
except BaseException as cause:
    report.update(status='failed',failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-started,3))
    save()
    print(json.dumps({k:v for k,v in report.items() if k!='sources'}),flush=True)
