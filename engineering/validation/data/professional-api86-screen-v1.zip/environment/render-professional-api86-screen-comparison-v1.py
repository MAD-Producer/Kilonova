from pathlib import Path
from PIL import Image, ImageDraw

folder=Path('E:/Dev/aem/artifacts/pr-queue/professional-api86-screen-family-v2/screen-shot')
path=folder/'comparison.png'
assert not path.exists()
canvas=Image.new('RGB',(810,660),'#1e2228')
draw=ImageDraw.Draw(canvas)
for col,label in enumerate(['Native headless PNG','Independent f64 homography','Frozen after source deletion']):
    draw.text((10+270*col,10),label,fill='white')
for row,frame in enumerate(['5','7.5','15']):
    top=30+row*210
    draw.text((10,top),f'Composition frame {frame}',fill='white')
    for col,name in enumerate([f'native-{frame}.png',f'golden-{frame}.png',f'frozen-{frame}.png']):
        image=Image.open(folder/name).convert('RGB').resize((256,192),Image.Resampling.NEAREST)
        canvas.paste(image,(10+270*col,top+16))
canvas.save(path)
print(path)
