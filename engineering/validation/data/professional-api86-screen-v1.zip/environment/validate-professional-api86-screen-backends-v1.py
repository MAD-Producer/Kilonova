from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root=Path('E:/Dev/aem')
work=root/'.worktrees/rational-frame-rates85'
out=root/'artifacts/pr-queue/professional-api86-screen-backends-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((root/'artifacts/pr-queue/professional-api86-screen-family-v2/exit.json').read_text())
sources=prior['sources']
assert all(sha(work/p)==digest for p,digest in sources.items())
report=dict(status='running',scope='Final screen source on explicit Vulkan without FFmpeg and DX12 with FFmpeg; original screen-family-v1 native heap corruption remains unexplained, not claimed fixed',base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),sources=sources,results=[])
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
started=time.monotonic()
save()
try:
    for backend,feature,name,expected in [('vulkan','motion-desktop-media/gpu-tests','vulkan-noffmpeg','Vulkan'),('dx12','motion-desktop-media/gpu-tests,motion-desktop-media/ffmpeg','dx12-ffmpeg','Dx12')]:
        folder=out/name
        folder.mkdir()
        command=['cargo','test','-p','motion-host','-p','motion-desktop-media','--test','professional_screen','--test','layer_time_mapping','--no-default-features','--features',feature,'--locked','--offline','--','--test-threads=1','--nocapture']
        env=os.environ.copy()
        env['WGPU_BACKEND']=backend
        env['MOTION_PROFESSIONAL_SCREEN_ARTIFACTS']=str(folder/'screen-shot')
        began=time.monotonic()
        with (folder/'stdout.log').open('wb') as stdout,(folder/'stderr.log').open('wb') as stderr:
            code=subprocess.call(command,cwd=work,env=env,stdout=stdout,stderr=stderr)
        summaries=re.findall(r'^test result: .+$',(folder/'stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
        result=dict(name=name,command=command,backendEnvironment=backend,exitCode=code,summaries=summaries,elapsedSeconds=round(time.monotonic()-began,3))
        report['results'].append(result)
        save()
        assert code==0 and len(summaries)==2 and all('0 failed; 0 ignored' in s for s in summaries)
        result['actualAdapter']=json.loads((folder/'screen-shot/result.json').read_text())['adapter']
        assert result['actualAdapter']['backend']==expected
        save()
        print(json.dumps(result),flush=True)
    report['sourceUnchanged']=all(sha(work/p)==digest for p,digest in sources.items())
    assert report['sourceUnchanged']
    report['status']='passed_full_issue_acceptance_pending'
except BaseException as cause:
    report.update(status='failed',failure=repr(cause))
    raise
finally:
    report['elapsedSeconds']=round(time.monotonic()-started,3)
    report['sourceUnchanged']=all(sha(work/p)==digest for p,digest in sources.items())
    save()
    print(json.dumps({k:v for k,v in report.items() if k!='sources'}),flush=True)
