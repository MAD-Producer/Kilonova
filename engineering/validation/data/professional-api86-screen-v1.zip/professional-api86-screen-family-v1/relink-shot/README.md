# Replaying the PNG relink example

All images are repository-authored MIT fixtures; no external assets.

Copy initial-project.json to project.json in this artifact directory and open that project. The assets directory includes both initial and recovered sources. requests.json retains the actual initial successful protocol batch. For a new run, replace its two candidate paths with absolute paths to replacement-0.png and replacement-1.png here, and bind revision/document_generation from a fresh missing_media_assets response. Poll media_status until ready before finish_asset_relink; release afterward. Staging must leave pixels unchanged; one undo restores both original plates. recovered-project.json can be opened directly with the preserved assets.

The Rust integration test is the complete executable scenario, including malformed input, external source deletion, recovery, fresh-session reopen and independently frozen old/new PNGs. These are headless PNG outputs, not desktop screenshots or photographic footage. Undo of a healthy replacement is verified; undo cannot recreate externally deleted file contents.
