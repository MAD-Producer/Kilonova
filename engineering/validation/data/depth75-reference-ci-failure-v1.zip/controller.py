"""Run the actual CI-discovered tools after measured-source freeze is released."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, sys, traceback
ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
OUT=BASE/'depth75-reference-ci-v1'
assert json.loads((BASE/'depth75-reference-remaining-v1/session-consumed.json').read_text())==dict(session=42461,consumed=True,exit_code=0)
assert (WORK/'engineering/validation/data/depth75-reference-remaining-v1.json').is_file()
assert not json.loads((BASE/'depth75-resume-current.json').read_text())['versionedCache75']['ownHeavyWorkloads']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK) and not OUT.exists()
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
paths=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def hashes():return {name:hashlib.sha256((WORK/name).read_bytes()).hexdigest() for name in paths}
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',TEMP=str(OUT),TMP=str(OUT))
report=dict(status='running',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),
 started_utc=datetime.now(timezone.utc).isoformat(),source_sha256=hashes(),stages=[],
 limits=['Actual source CI discovery and inventory; original numeric conditions, assertions and skip/deadline policies preserved',
 'No learned inference, native build, GPU or Android device run; photographed and native acceptance remain separately scoped'])
def save():(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
try:
 for name,pattern in (('reference-controls','test_ci_depth_reference*.py'),('complete-tools','test_ci_*.py')):
  command=[sys.executable,'-B','-m','unittest','discover','-s','tools','-p',pattern,'-v']
  stage=dict(name=name,command=command);report['stages'].append(stage);save()
  with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
   child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);stage['pid']=child.pid;save();stage['exit_code']=child.wait()
  save();assert stage['exit_code']==0,(name,'original failing tools output retained')
  text=(OUT/(name+'.stderr.log')).read_text(encoding='utf-8')
  matches=re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$',text,re.M);assert len(matches)==1
  stage.update(tests=int(matches[0][0]),elapsed_seconds=float(matches[0][1]));save()
 assert report['stages'][0]['tests']==11
 report['status']='actual11_reference_controls_and_complete_ci_tools_passed';save()
except BaseException:
 report['status']='failed_original_outputs_retained';report['cause']=traceback.format_exc();save();raise
finally:
 report['source_unchanged']=hashes()==report['source_sha256'];report['finished_utc']=datetime.now(timezone.utc).isoformat();save()
 assert report['source_unchanged']
