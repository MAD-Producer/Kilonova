from pathlib import Path
import subprocess, json, hashlib, time, sys
root=Path('E:/Dev/aem');out=root/'.tools/effect-instance-identifiers';work=root/'.worktrees/effect-instance-identifiers';phase=sys.argv[1]
assert phase in ['before','after-focused','after']
paths=['desktop/app/src/panels/effect_controls.rs','desktop/app/src/panels/effect_controls/identity_tests.rs','desktop/app/src/panels/effects.rs','desktop/app/src/panels/observation.rs','desktop/app/src/logging.rs','Cargo.lock']
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
sources=freeze()
binary=root/'target/debug/deps/motion_studio-d5bd28a41c2d0117.exe'
if phase=='after':
    prior=json.loads((out/'after-focused-receipt.json').read_text(encoding='utf8'));assert prior['exit_code']==0 and prior['sources']==sources and prior['binary_sha256']==hashlib.sha256(binary.read_bytes()).hexdigest()
else:(work/'desktop/app/src/main.rs').touch()
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1','panels::' if phase=='after' else 'panels::effect_controls::identity_tests::','--','--test-threads=1']
start=time.monotonic();log=out/(phase+'.log');assert not log.exists()
with log.open('w',encoding='utf8') as sink:result=subprocess.run(command,cwd=work,stdout=sink,stderr=subprocess.STDOUT)
text=log.read_text(encoding='utf8');record=dict(phase=phase,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,encoding='utf8').strip(),command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),sources=sources,source_unchanged=freeze()==sources,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),actual_desktop_compile=any('Compiling motion-desktop ' in line and str(work).replace('\\','/').casefold() in line.replace('\\','/').casefold() for line in text.splitlines()))
(out/(phase+'-receipt.json')).write_text(json.dumps(record,indent=2),encoding='utf8');assert record['source_unchanged'] and (record['actual_desktop_compile'] or phase=='after' and record['binary_sha256']==prior['binary_sha256'])
if phase=='before':
    assert result.returncode!=0 and '3 failed' in text and 'panicked at' in text and 'could not compile' not in text
elif phase=='after-focused':
    assert result.returncode==0 and '3 passed; 0 failed; 0 ignored' in text
else:
    assert result.returncode==0 and '0 failed; 1 ignored' in text
print(json.dumps({k:v for k,v in record.items() if k!='sources'}),flush=True)
