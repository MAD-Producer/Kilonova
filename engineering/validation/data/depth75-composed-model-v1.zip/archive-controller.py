"""Publish the frozen index/composed qualification; never learned payloads."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, subprocess

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
OUT = ART / 'depth75-composed-archive-v1'
TREE = ROOT / '.worktrees/reference-depth76'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
index = read(ART / 'depth75-index-operators-v1/receipt.json')
composed = read(ART / 'depth75-composed-v1/receipt.json')
old = read(ART / 'depth75-operators-v4/receipt.json')
assert index['sourceUnchanged'] and composed['sourceUnchanged']
assert index['source'] == composed['source']
assert composed['status'] == 'standalone_composed_gpu_numerics_passed_product_integration_pending'
assert index['status'] == 'selected_operator_tests_and_numerics_passed'
assert composed['comparison']['passed'] and len(composed['faults']) == 6
assert len(index['failureObservations']) == 8
unchanged = [name for name, digest in old['source'].items()
             if name in composed['source'] and composed['source'][name] == digest]
assert set(old['source']) - set(unchanged) == {'Cargo.toml'}
for name, digest in composed['source'].items():
    assert sha(ART / 'depth75-composed-v1/frozen-source' / name) == digest
    assert sha(ART / 'depth75-index-operators-v1/frozen-source' / name) == digest
OUT.mkdir(exist_ok=False)
files = {'archive-controller.py': Path(__file__)}
for name in composed['source']:
    files['source/' + name] = ART / 'depth75-composed-v1/frozen-source' / name

# Explicit extension AND directory allow-list. Learned floats, external models,
# executables, runtimes, source snapshots duplicated under execution, and faulty
# resource roots never enter this public evidence package.
for directory in ('depth75-index-operators-v1', 'depth75-composed-v1',
                  'depth75-dataflow-v1', 'depth75-storage-plan-v1',
                  'depth75-storage-plan-v2', 'depth75-storage-plan-v3',
                  'depth75-static-program-v1', 'depth75-index-fixtures-v1'):
    for path in (ART / directory).rglob('*'):
        if not path.is_file() or path.suffix not in ('.json', '.log', '.py'):
            continue
        relative = path.relative_to(ART / directory)
        if any(part in ('weights', 'tensors', 'retained-binary', 'frozen-source',
                        'appdata', 'resource-root') for part in relative.parts):
            continue
        # A fault's trusted program is identical metadata but need not be copied
        # six times; preserve only its original observed request and receipt.
        if path.name == 'program.json' and directory != 'depth75-static-program-v1':
            continue
        files['evidence/' + directory + '/' + relative.as_posix()] = path
for name in ('storage_plan.py', 'test_storage_plan.py'):
    files['planner-v3/' + name] = ART / 'depth75-storage-plan-v3' / name
for name in ('compare-depth75-index-outputs-v1.py',
             'inspect-depth75-dataflow-v1.py',
             'export-depth75-static-program-v1.py'):
    files['controllers/' + name] = ROOT / '.tools/issue-closure-review' / name
files['previous-seven-family-manifest.json'] = ART / 'depth75-operators-archive-v4/manifest.json'
entries = {name: dict(bytes=p.stat().st_size, sha256=sha(p)) for name, p in sorted(files.items())}
archive = OUT / 'depth75-composed-model-v1.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(files.items()):
        z.writestr(name, path.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(entries)
    for name, row in entries.items():
        payload = z.read(name)
        assert len(payload) == row['bytes'] and hashlib.sha256(payload).hexdigest() == row['sha256']
manifest = dict(status='standalone_composed_qualification_archived_readback_verified',
    createdUtc=datetime.now(timezone.utc).isoformat(), archive=archive.name,
    bytes=archive.stat().st_size, sha256=sha(archive), entries=entries,
    priorSourceFilesUnchanged=unchanged, indexNumerics=55, hostTests=31,
    composedComparison=composed['comparison'], indexActualFaults=8, composedActualFaults=6,
    actualGpuReceipt=read(ART / 'depth75-composed-v1/gpu/receipt.json'),
    limits=['One authored normalized RGB input and hardware adapter; no video/photographic domain quality claim',
            'Research executable and strict typed IR only, not an installed backend or product capability',
            'Raw model, learned resources, input/intermediate/final tensors, executables and runtimes excluded',
            'Retained buffer capacity is not physical VRAM, driver memory or editor peak memory',
            'Single wall observation excludes preprocessing, remapping, transport and sustained/thermal qualification',
            'Local controllers require separately installed pinned model/environment and recorded path routing',
            'Both refused planner attempts retained; historical evidence remains scoped to its original execution',
            'Separate original workspace regression failed two tests; this qualification does not replace it'])
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
dest = TREE / 'engineering/validation/data'
for source, name in ((archive, archive.name), (OUT / 'manifest.json', 'depth75-composed-model-v1.json')):
    target = dest / name
    assert not target.exists()
    target.write_bytes(source.read_bytes())
    assert sha(target) == sha(source)
print(json.dumps({k: v for k, v in manifest.items() if k not in ('entries', 'actualGpuReceipt')}))
