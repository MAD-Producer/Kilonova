"""Real same-weight Conv/ConvTranspose/Erf fixtures, with all earlier controls."""
from pathlib import Path
from datetime import datetime, timezone
import copy
import hashlib
import json
import logging
import math
import os
import shutil
import sys
import time
import traceback

ROOT=Path('E:/Dev/aem')
ART=ROOT/'artifacts/pr-queue'
MODEL=ROOT/'.tools/ai-depth74/models/depth_anything_v2_vits_518.onnx'
OUT=ART/'depth75-index-fixtures-v1'
OLD=ART/'depth75-operator-fixtures-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((ART/'depth75-operators-v3/receipt.json').read_text())
assert previous['status']=='selected_operator_tests_and_numerics_passed' and previous['sourceUnchanged']
request=json.loads((OLD/'request.json').read_text())
assert sha(MODEL)==request['model_sha256']
full=json.loads((ART/'tracking88-prototype-workspace-integration-v4/exit.json').read_text())
assert full['status']!='running' and full['sourceUnchanged'] and 'completedUtc' in full, 'Keep same full native gate undisturbed'
request['cases']=[]
OUT.mkdir(exist_ok=False);(OUT/'tensors').mkdir()
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
logger=logging.getLogger('depth75-index-fixtures');logger.setLevel(logging.INFO)
sink=logging.FileHandler(OUT/'research.log',encoding='utf-8')
sink.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'));logger.addHandler(sink)
errors=logging.StreamHandler(sys.stderr);errors.setLevel(logging.ERROR);errors.setFormatter(sink.formatter);logger.addHandler(errors)
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),pid=os.getpid(),phases=[],
            modelSha256=request['model_sha256'],
            limits=['Selected real operators plus independent controls; no composed WGSL inference',
                    'Original model, prior case bytes and numerical tolerances unchanged',
                    'No model, weight or tensor payload is published'])
def phase(name):
    report['phase']=name;report['phases'].append(dict(name=name,utc=datetime.now(timezone.utc).isoformat()))
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    logger.info('start request=75 operation=%s',name);sink.flush()
began=time.monotonic()
try:
    phase('load_explicit_existing_cpu_reference')
    os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='')
    import numpy as np
    import onnx
    import onnxruntime as ort
    model=onnx.load(str(MODEL),load_external_data=False)
    initializers={t.name:t for t in model.graph.initializer}
    inventory=json.loads((ART/'depth75-static-model-audit-v3/tensor-inventory.json').read_text())
    metadata={row['name']:row for node in inventory for row in node['outputs']}
    dataflow=json.loads((ART/'depth75-dataflow-v1/static-dataflow.json').read_text())
    assert dataflow['modelSha256']==request['model_sha256']
    by_index={s['index']:s for s in dataflow['steps']}
    heavy={'Conv','ConvTranspose','MatMul','Softmax','LayerNormalization','Erf','Resize'}
    representatives={}; fields=('operation','outputShape','permutation','axis','indices','sliceMapping')
    for row in dataflow['steps']:
        if row['phase']!='materialize_float_gpu_pending' or row['operation'] in heavy:continue
        key=json.dumps({'inputs':[dataflow['tensors'][n]['shape'] for n in row['inputs']],
                        **{k:row[k] for k in fields if k in row}},sort_keys=True)
        representatives.setdefault(key,row)
    selected=[(row['index'],model.graph.node[row['index']]) for row in representatives.values()]
    assert len(selected)==31
    needed={name for index,node in selected for name in by_index[index]['inputs']+list(node.output)
            if name and name not in initializers and name!='rgb'}
    augmented=copy.deepcopy(model)
    existing={o.name for o in augmented.graph.output}
    for name in sorted(needed-existing):
        d=metadata[name];assert d['dtype']=='FLOAT' and len(d['shape'])<=5
        augmented.graph.output.append(onnx.helper.make_tensor_value_info(name,onnx.TensorProto.FLOAT,d['shape']))
    onnx.checker.check_model(augmented)
    rng=np.random.default_rng(75);y,x=np.indices((518,518),dtype=np.float32)
    rgb=np.stack((x/517.,y/517.,(x+y)/1034.),axis=-1)
    rgb=np.clip(rgb+rng.uniform(-.03,.03,rgb.shape).astype(np.float32),0.,1.)
    image=((rgb-np.array([.485,.456,.406],np.float32))/np.array([.229,.224,.225],np.float32)).transpose(2,0,1)[None].copy()
    prior=json.loads((OLD/'receipt.json').read_text())
    assert hashlib.sha256(image.astype('<f4').tobytes()).hexdigest()==prior['authoredInputSha256']
    phase('create_cpu_session_and_run_original_same_weight_model')
    options=ort.SessionOptions();options.intra_op_num_threads=1;options.inter_op_num_threads=1
    options.log_severity_level=3;options.graph_optimization_level=ort.GraphOptimizationLevel.ORT_DISABLE_ALL
    session=ort.InferenceSession(augmented.SerializeToString(),sess_options=options,providers=['CPUExecutionProvider'])
    assert session.get_providers()==['CPUExecutionProvider']
    names=sorted(needed|existing)
    values=dict(zip(names,session.run(names,{'rgb':image})));values['rgb']=image
    assert all(v.dtype==np.float32 and np.isfinite(v).all() for v in values.values())
    assert hashlib.sha256(values['relative_inverse_depth'].astype('<f4').tobytes()).hexdigest()==prior['finalDepthSha256']
    report.update(providers=session.get_providers(),versions=dict(numpy=np.__version__,onnx=onnx.__version__,onnxruntime=ort.__version__),
                  authoredInputSha256=prior['authoredInputSha256'],finalDepthSha256=prior['finalDepthSha256'])
    phase('retain_real_operator_inputs_weights_references')
    for c in request['cases']:
        for t in c['inputs']+[c['expected']]:
            src=OLD/t['file'];dst=OUT/t['file']
            assert sha(src)==t['sha256']
            if not dst.exists():shutil.copyfile(src,dst)
            assert sha(dst)==t['sha256']
    def write(name,array):
        array=np.asarray(array,dtype=np.float32);assert array.ndim<=5 and np.isfinite(array).all()
        raw=np.ascontiguousarray(array,dtype='<f4').tobytes();digest=hashlib.sha256(raw).hexdigest()
        p=OUT/'tensors'/(digest+'.f32')
        if not p.exists():p.write_bytes(raw)
        assert sha(p)==digest
        return dict(name=name,dtype='float32',shape=list(array.shape),file=p.relative_to(OUT).as_posix(),sha256=digest)
    def tensor(name):return write(name,onnx.numpy_helper.to_array(initializers[name]) if name in initializers else values[name])
    for index,node in selected:
        row=by_index[index];operation=dict(kind=node.op_type)
        if node.op_type=='Transpose':operation['permutation']=row['permutation']
        elif node.op_type=='Gather':
            assert len(row['indices'])==1 and len(row['outputShape'])==len(dataflow['tensors'][row['inputs'][0]]['shape'])-1
            operation=dict(kind='GatherScalar',axis=row['axis'],index=row['indices'][0])
        elif node.op_type=='Slice':
            mapping=row['sliceMapping']
            operation.update(starts=[x['start'] for x in mapping],
                ends=[-(1<<63) if x['step']<0 and x['end']==-1 else x['end'] for x in mapping],
                axes=[x['axis'] for x in mapping],steps=[x['step'] for x in mapping])
        elif node.op_type=='Concat':operation['axis']=row['axis']
        request['cases'].append(dict(id=f'model-{index}-{node.op_type.lower()}',origin='same_model_intermediate',source_node=node.name,
            operation=operation,inputs=[tensor(n) for n in row['inputs']],expected=tensor(node.output[0])))
    phase('author_independent_index_and_broadcast_controls')
    def control(name,op,arrays,reference):
        request['cases'].append(dict(id=name,origin='authored_control',source_node=None,operation=op,
            inputs=[write(f'{name}-input-{i}',a) for i,a in enumerate(arrays)],expected=write(name+'-reference',reference)))
    for name,shape,perm in [('odd',(2,3,5),(2,0,1)),('rank5',(2,3,2,5,3),(4,0,2,1,3)),('scalar',(),())]:
        a=rng.uniform(-2,2,shape).astype(np.float32)
        control('control-transpose-'+name,dict(kind='Transpose',permutation=list(perm)),[a],np.transpose(a,perm))
    for op in ('Add','Mul','Div'):
        for name,left,right in [('interleaved',(2,1,3),(1,4,1)),('scalar',(2,3,5),()),('equal',(2,3,5),(2,3,5))]:
            a=rng.uniform(-2,2,left).astype(np.float32);b=rng.uniform(.25,2,right).astype(np.float32)
            aa=a.astype(np.float64);bb=b.astype(np.float64)
            reference=aa+bb if op=='Add' else aa*bb if op=='Mul' else aa/bb
            control('control-'+op.lower()+'-'+name,dict(kind=op),[a,b],reference)
    for name,shape,axis,index in [('middle',(2,3,5),1,-2),('scalar',(5,),-1,-1)]:
        a=rng.uniform(-2,2,shape).astype(np.float32)
        control('control-gather-'+name,dict(kind='GatherScalar',axis=axis,index=index),[a],np.take(a,index,axis=axis))
    for name,starts,ends,axes,steps in [('positive',[-100,1],[100,5],[0,2],[1,2]),
            ('reverse',[2,4],[-4,-(1<<63)],[1,2],[-1,-2]),
            ('singleton',[4],[-(1<<63)],[2],[-100])]:
        a=rng.uniform(-2,2,(2,3,5)).astype(np.float32);selectors=[slice(None)]*3
        for axis,start,end,step in zip(axes,starts,ends,steps):selectors[axis]=slice(start,end,step)
        control('control-slice-'+name,dict(kind='Slice',starts=starts,ends=ends,axes=axes,steps=steps),[a],a[tuple(selectors)])
    for name,shape,output in [('axes',(1,3,1),(2,3,5)),('scalar',(),(2,1,3,2,5))]:
        a=rng.uniform(-2,2,shape).astype(np.float32)
        control('control-expand-'+name,dict(kind='Expand'),[a],np.broadcast_to(a,output))
    for name,shapes,axis in [('three',[(2,1,3),(2,2,3),(2,1,3)],-2),('two',[(3,),(5,)],0)]:
        arrays=[rng.uniform(-2,2,shape).astype(np.float32) for shape in shapes]
        control('control-concat-'+name,dict(kind='Concat',axis=axis),arrays,np.concatenate(arrays,axis=axis))
    for name,shape in [('scalar',()),('partial',(129,)),('rank5',(2,1,3,2,5))]:
        a=rng.uniform(-2,2,shape).astype(np.float32)
        control('control-relu-'+name,dict(kind='Relu'),[a],np.maximum(a,0.))
    assert len(request['cases'])==55 and len({c['id'] for c in request['cases']})==55
    (OUT/'request.json').write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8')
    report.update(status='same_weight_reference_fixtures_generated_wgsl_comparison_pending',requestSha256=sha(OUT/'request.json'),
        selectedNodes=[dict(index=i,name=n.name,operation=n.op_type) for i,n in selected],
        outputCounts=dict(cases=55,sameModelCases=31,authoredControls=24,rawFiles=len(list((OUT/'tensors').glob('*.f32')))),
        declaredComparisonBounds=prior['declaredComparisonBounds'],
        modelUnchanged=sha(MODEL)==request['model_sha256'],
        elapsedSeconds=round(time.monotonic()-began,3),completedUtc=datetime.now(timezone.utc).isoformat())
    assert report['modelUnchanged'];phase('completed')
except BaseException as cause:
    report.update(status='reference_fixture_generation_failed_original_cause_retained',failure=repr(cause),traceback=traceback.format_exc(),completedUtc=datetime.now(timezone.utc).isoformat())
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    logger.error('reference fixture generation failed phase=%s cause=%s',report.get('phase'),repr(cause)[:4096]);raise
