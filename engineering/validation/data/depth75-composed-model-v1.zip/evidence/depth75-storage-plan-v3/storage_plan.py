"""Bounded buffer-capacity planning, not an actual GPU memory measurement.

All live read owners stay distinct from the current write. Aliases extend the
canonical owner's last use. Pool buffers remain owned through a single ordered
submission and its completion; the next job cannot reuse the pool early.
"""
from collections import defaultdict

class AdmissionError(ValueError):
    pass

def require(value,cause):
    if not value:raise AdmissionError(cause)

def plan(graph,*,budget_bytes,alignment=256,upload_staging_bytes=8<<20):
    require(graph['version']==1,'unsupported static dataflow version')
    require(isinstance(budget_bytes,int) and 0<budget_bytes<=512<<20,'explicit bounded capacity budget required')
    require(isinstance(alignment,int) and 0<alignment<=65536 and alignment&(alignment-1)==0,'invalid buffer alignment')
    require(isinstance(upload_staging_bytes,int) and 0<=upload_staging_bytes<=16<<20,'bounded upload staging required')
    steps=graph['steps'];intervals=graph['ownerIntervals'];persistent=graph['persistentFloatResources']
    require(len(steps)<=1024 and len(intervals)<=1025 and len(persistent)<=1024,'plan count bounds exceeded')
    require([s['index'] for s in steps]==list(range(len(steps))),'node order is not complete and contiguous')
    require(not(set(intervals)&set(persistent)),'persistent and dynamic owners overlap')
    def aligned(n):
        require(isinstance(n,int) and 0<n<=128<<20,'owner size outside storage binding contract')
        return (n+alignment-1)//alignment*alignment
    resources={name:aligned(row['bytes']) for name,row in persistent.items()}
    owners={name:dict(created=row['created'],lastUse=row['lastUse'],bytes=row['bytes'],capacity=aligned(row['bytes']))
            for name,row in intervals.items()}
    for name,row in owners.items():
        require(-1<=row['created']<=row['lastUse']<=len(steps),f'invalid owner interval: {name}')
    created=defaultdict(list);retired=defaultdict(list)
    for name,row in owners.items():created[row['created']].append(name);retired[row['lastUse']].append(name)
    # A bounded parameter ring retains distinct immutable uniforms for every
    # encoded operation. One later queue write must not overwrite all operators.
    operations=sum(s['phase']=='materialize_float_gpu_pending' for s in steps)
    uniform_ring_bytes=operations*256
    readback_bytes=sum(graph['tensors'][n]['bytes'] for n in graph['outputs'])
    require(0<readback_bytes<=128<<20,'readback exceeds declared contract')
    reserved=sum(resources.values())+uniform_ring_bytes+readback_bytes+upload_staging_bytes+12
    require(reserved<=budget_bytes,'persistent/staging/uniform/readback capacity exhausts budget')
    # Assign largest lifetimes first, so a short early tensor cannot determine
    # an undersized slot and force another retained attention buffer later.
    # These are offline interval colors, not live buffer reallocations.
    slots=[];members=[];assignment={}
    for name,row in sorted(owners.items(),key=lambda item:(-item[1]['capacity'],item[1]['created'],item[0])):
        candidates=[]
        for slot,occupancy in enumerate(members):
            if slots[slot]>=row['capacity'] and all(row['lastUse']<owners[other]['created']
                    or owners[other]['lastUse']<row['created'] for other in occupancy):
                candidates.append(slot)
        if candidates:slot=min(candidates,key=lambda i:(slots[i],i))
        else:
            slot=len(slots);slots.append(row['capacity']);members.append([])
            require(reserved+sum(slots)<=budget_bytes,
                    f'offline interval buffer capacity exhausted owner={name} requested={row["capacity"]}')
        members[slot].append(name);assignment[name]=slot
    free=set(range(len(slots)));active={};trace=[];peak_live=0
    for at in range(-1,len(steps)+1):
        for name in sorted(created[at]):
            slot=assignment[name]
            require(slot in free,'offline slot assignment overlaps a live owner');free.remove(slot)
            require(name not in active and slot not in active.values(),'pool owner collision')
            active[name]=slot;trace.append(dict(node=at,action='allocate',owner=name,slot=slot))
        peak_live=max(peak_live,sum(owners[n]['bytes'] for n in active))
        for name in sorted(retired[at]):
            require(name in active,f'retirement without allocation: {name}')
            slot=active.pop(name);free.add(slot);trace.append(dict(node=at,action='retire',owner=name,slot=slot))
    require(not active,'dynamic owners remain beyond final output readback')
    return dict(version=1,status='static_buffer_capacity_admitted_execution_pending',budgetBytes=budget_bytes,
        alignment=alignment,persistentCapacities=resources,poolSlotCapacities=slots,
        uniformRingBytes=uniform_ring_bytes,readbackBytes=readback_bytes,uploadStagingBytes=upload_staging_bytes,
        dummyBindingBytes=12,plannedRetainedBufferCapacityBytes=reserved+sum(slots),
        peakLogicalActiveOwnerBytes=peak_live,trace=trace,
        allocationContract='Allocate every final slot capacity upfront; trace assigns owners without runtime resize',
        planningStrategy='Descending-capacity interval coloring with inclusive read/write lifetimes',
        orderingContract='Separate ordered compute passes in one submission; retain pool until completion before next-job reuse',
        limits=['Static capacity only, not a physical allocation/driver/latency/thermal measurement',
                'Actual binding limits, alias hazards, queue order and GPU sentinels still require execution',
                'No submitted buffer destruction, unbounded uploads or overlapping-job pool reuse is authorized'])

def audit(graph,planned):
    """Independent event replay against graph reads, not planner retirement rules."""
    require(planned['version']==1,'unsupported buffer plan version')
    events=defaultdict(list)
    for event in planned['trace']:events[event['node']].append(event)
    persistent=set(graph['persistentFloatResources']);active={};occupants={}
    slots=planned['poolSlotCapacities'];seen=set();read_count=0
    for at in range(-1,len(graph['steps'])+1):
        actions=events[at]
        for e in actions:
            if e['action']!='allocate':continue
            name=e['owner'];slot=e['slot']
            require(name not in seen and name in graph['ownerIntervals'],'duplicate or unknown allocation')
            require(isinstance(slot,int) and 0<=slot<len(slots) and slot not in occupants,'live owners share a slot')
            require(slots[slot]>=graph['ownerIntervals'][name]['bytes'],'slot is too short')
            active[name]=slot;occupants[slot]=name;seen.add(name)
        if 0<=at<len(graph['steps']):
            node=graph['steps'][at];reads=node.get('inputOwners',[])
            for name in reads:
                require(name in persistent or name in active,f'read after owner retirement: node={at} owner={name}')
                if name not in persistent:require(occupants[active[name]]==name,'buffer epoch overwritten before read')
                read_count+=1
            if node['phase']=='materialize_float_gpu_pending':
                target=node['owner'];require(target in active,'output owner missing before dispatch')
                require(all(name in persistent or active[name]!=active[target] for name in reads),
                        'current write aliases a live read buffer')
        if at==len(graph['steps']):
            for output in graph['outputs']:
                physical=graph['aliases'].get(output,output)
                require(physical in active or physical in persistent,'final output retired before readback')
        for e in actions:
            require(e['action'] in ('allocate','retire'),'unknown storage event')
            if e['action']!='retire':continue
            name=e['owner'];slot=e['slot'];require(active.get(name)==slot and occupants.get(slot)==name,'wrong-owner retirement')
            del active[name];del occupants[slot]
    require(not active and not occupants and seen==set(graph['ownerIntervals']),'incomplete allocation history')
    total=sum(planned['persistentCapacities'].values())+sum(slots)+planned['uniformRingBytes']+planned['readbackBytes']+planned['uploadStagingBytes']+planned['dummyBindingBytes']
    require(total==planned['plannedRetainedBufferCapacityBytes'] and total<=planned['budgetBytes'],'capacity accounting mismatch')
    return dict(status='static_slot_ownership_audit_passed',graphReadsChecked=read_count,
                ownersChecked=len(seen),eventsChecked=sum(map(len,events.values())),
                actualGpuExecution=False,physicalMemoryMeasured=False)
