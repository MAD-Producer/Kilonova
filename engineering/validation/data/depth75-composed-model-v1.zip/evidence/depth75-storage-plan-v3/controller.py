"""Pure-Python capacity planning while the separate native gate remains untouched."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time
import traceback

ROOT=Path('E:/Dev/aem');WORK=ROOT/'.tools/ai-depth75'
OUT=ROOT/'artifacts/pr-queue/depth75-storage-plan-v3'
DATA=ROOT/'artifacts/pr-queue/depth75-dataflow-v1/static-dataflow.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(priorRefusedAttempts=['depth75-storage-plan-v1: online smallest-fitting retained slots exhausted budget', 'depth75-storage-plan-v2: future enlargement of greedy slots still exhausted budget'],status='running_pure_python_static_capacity_audit',startedUtc=datetime.now(timezone.utc).isoformat(),
            dataflowSha256=sha(DATA),gpuExecuted=False,inferenceExecuted=False,
            limits=['Static buffer capacities and owner lifetimes only; no actual allocation or submitted GPU work',
                    'Original native full regression is not restarted, modified or waived by these controls',
                    'Driver allocations, physical memory, real staging, completion and latency still require execution'])
def save():(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
began=time.monotonic();save()
try:
    env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
    for name in ('storage_plan.py','test_storage_plan.py'):
        (OUT/name).write_bytes((WORK/name).read_bytes())
    with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
        code=subprocess.run([sys.executable,'-B','-m','unittest','-v','test_storage_plan'],cwd=WORK,env=env,stdout=stdout,stderr=stderr).returncode
    report['hostControlExitCode']=code;save();assert code==0
    spec=importlib.util.spec_from_file_location('depth75_storage_plan',WORK/'storage_plan.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    graph=json.loads(DATA.read_text())
    # Original 256MiB operator-research capacity budget, declared before this
    # pool is measured. A refusal remains a refusal, never an implicit increase.
    budget=256<<20
    planned=module.plan(graph,budget_bytes=budget,alignment=256,upload_staging_bytes=8<<20)
    checked=module.audit(graph,planned)
    (OUT/'buffer-plan.json').write_text(json.dumps(planned,indent=2)+'\n',encoding='utf-8')
    (OUT/'independent-audit.json').write_text(json.dumps(checked,indent=2)+'\n',encoding='utf-8')
    report.update(status='static_capacity_and_owner_audit_passed_execution_pending',hostControls=7,
        budgetBytes=budget,plannedRetainedBufferCapacityBytes=planned['plannedRetainedBufferCapacityBytes'],
        persistentBufferCapacityBytes=sum(planned['persistentCapacities'].values()),poolCapacityBytes=sum(planned['poolSlotCapacities']),
        poolSlots=len(planned['poolSlotCapacities']),uniformRingBytes=planned['uniformRingBytes'],
        readbackBytes=planned['readbackBytes'],uploadStagingBytes=planned['uploadStagingBytes'],
        peakLogicalActiveOwnerBytes=planned['peakLogicalActiveOwnerBytes'],independentAudit=checked,
        bufferPlanSha256=sha(OUT/'buffer-plan.json'),sources={n:sha(WORK/n) for n in ('storage_plan.py','test_storage_plan.py')})
except BaseException as cause:
    report.update(status='static_capacity_failed_original_cause_retained',failure=repr(cause),traceback=traceback.format_exc());raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3));save()
print(json.dumps(report))
