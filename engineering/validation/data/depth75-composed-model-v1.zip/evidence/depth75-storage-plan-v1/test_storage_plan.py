import copy
import unittest
from storage_plan import AdmissionError, audit, plan

def graph():
    # Alias x stays needed after y is retired. A new output must never recycle
    # x early even though its original tensor name stopped being read.
    return dict(version=1,persistentFloatResources={},outputs=['w'],aliases={'alias':'x'},
        tensors={'w':dict(bytes=16)},ownerIntervals={
            'x':dict(created=-1,lastUse=2,bytes=16),'y':dict(created=1,lastUse=1,bytes=16),
            'z':dict(created=2,lastUse=3,bytes=16),'w':dict(created=3,lastUse=4,bytes=16)},
        steps=[dict(index=0,phase='contiguous_alias',owner='x',inputOwners=['x']),
               dict(index=1,phase='materialize_float_gpu_pending',owner='y',inputOwners=['x']),
               dict(index=2,phase='materialize_float_gpu_pending',owner='z',inputOwners=['x']),
               dict(index=3,phase='materialize_float_gpu_pending',owner='w',inputOwners=['z'])])

class StoragePlanTests(unittest.TestCase):
    def test_alias_survives_until_its_final_consumer_and_outputs_allocate_before_reads_retire(self):
        g=graph();p=plan(g,budget_bytes=1308,upload_staging_bytes=0)
        assignments={e['owner']:e['slot'] for e in p['trace'] if e['action']=='allocate'}
        self.assertNotEqual(assignments['x'],assignments['z'])
        self.assertEqual(assignments['y'],assignments['z'])
        self.assertEqual(assignments['x'],assignments['w'])
        self.assertEqual(p['peakLogicalActiveOwnerBytes'],32)
        self.assertEqual(p['uniformRingBytes'],3*256)
        self.assertEqual(p['plannedRetainedBufferCapacityBytes'],1308)
        self.assertEqual(audit(g,p)['graphReadsChecked'],4)
    def test_one_byte_insufficient_capacity_is_rejected_with_the_original_budget(self):
        with self.assertRaisesRegex(AdmissionError,'capacity exhausted'):
            plan(graph(),budget_bytes=1307,upload_staging_bytes=0)
    def test_graph_read_replay_catches_a_forged_short_alias_lifetime(self):
        g=graph();g['ownerIntervals']['x']['lastUse']=1
        p=plan(g,budget_bytes=4096,upload_staging_bytes=0)
        with self.assertRaisesRegex(AdmissionError,'read after owner retirement'):
            audit(g,p)
    def test_same_buffer_for_a_live_read_and_new_write_cannot_be_hidden_in_the_trace(self):
        g=graph();p=plan(g,budget_bytes=4096,upload_staging_bytes=0)
        x=next(e['slot'] for e in p['trace'] if e['action']=='allocate' and e['owner']=='x')
        next(e for e in p['trace'] if e['action']=='allocate' and e['owner']=='z')['slot']=x
        with self.assertRaisesRegex(AdmissionError,'live owners share a slot'):
            audit(g,p)
    def test_final_readback_and_capacity_totals_are_independently_checked(self):
        g=graph();p=plan(g,budget_bytes=4096,upload_staging_bytes=0)
        altered=copy.deepcopy(p);altered['plannedRetainedBufferCapacityBytes']-=1
        with self.assertRaisesRegex(AdmissionError,'accounting mismatch'):audit(g,altered)
        altered=copy.deepcopy(p)
        next(e for e in altered['trace'] if e['action']=='retire' and e['owner']=='w')['node']=3
        with self.assertRaisesRegex(AdmissionError,'final output retired'):audit(g,altered)
    def test_too_small_buffers_and_unknown_plan_versions_are_refused(self):
        g=graph();p=plan(g,budget_bytes=4096,upload_staging_bytes=0)
        p['poolSlotCapacities'][0]=4
        with self.assertRaisesRegex(AdmissionError,'slot is too short'):audit(g,p)
        g['version']=0
        with self.assertRaisesRegex(AdmissionError,'unsupported'):plan(g,budget_bytes=4096,upload_staging_bytes=0)

if __name__=='__main__':unittest.main()
