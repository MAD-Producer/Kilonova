"""Deferred real composed-model GPU qualification; never overwrites an attempt."""
from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,json,os,shutil,subprocess,time,traceback
ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue';WORK=ROOT/'.tools/ai-depth75/operator-probe'
OUT=ART/'depth75-composed-v1';PROGRAM=ART/'depth75-static-program-v1/program.json'
FIXTURES=ART/'depth75-convolution-fixtures-v1';INDEX=ART/'depth75-index-operators-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
native=json.loads((ART/'tracking88-prototype-workspace-integration-v4/exit.json').read_text())
assert native['status']!='running' and 'completedUtc' in native and native['sourceUnchanged'], 'Preserve original full session until terminal and consumed'
index=json.loads((INDEX/'receipt.json').read_text())
assert index['status']=='selected_operator_tests_and_numerics_passed' and index['sourceUnchanged'] and 'completedUtc' in index
assert shutil.disk_usage(ROOT).free>=10<<30,'Original 10GiB admission, no local cleanup'
assert sha(PROGRAM)=='2ec1d8012905198cfd5af1430f88d1770edbf752531fe817dfcc65e1477fef6a'
assert not OUT.exists(),'All previous attempts must be retained'
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'):env.pop(name)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/depth75-operators'),
    CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
    TEMP=str(ROOT/'target/depth75-operators/tmp'),TMP=str(ROOT/'target/depth75-operators/tmp'),
    PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',RUST_BACKTRACE='full')
Path(env['TEMP']).mkdir(parents=True,exist_ok=True)
report=dict(status='running_composed_gpu_qualification',startedUtc=datetime.now(timezone.utc).isoformat(),pid=os.getpid(),stages=[],
    nativeStatus=native['status'],programSha256=sha(PROGRAM),originalMaxNormalized=.0002,originalMeanNormalized=.00002,
    limits=['Standalone composed GPU research, not an installed product backend or video quality qualification',
        'Same unchanged Small-model weights and previously retained authored RGB/final CPU depth; no CPU reference execution here',
        'Entire graph executes on the requested hardware GPU; no intermediate CPU outputs may be injected',
        'Actual retained buffer capacities are checked; driver/internal pipeline memory is not measured',
        'One cold whole-model wall observation is not sustained latency, cross-platform or thermal evidence'])
def save():
    pending=OUT/'receipt.pending.json';pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(pending,OUT/'receipt.json')
def sources():
    paths=list((WORK/'src').glob('*'))+list((WORK/'tests').glob('*'))+[WORK/'Cargo.toml',WORK/'Cargo.lock']
    return {p.relative_to(WORK).as_posix():sha(p) for p in paths if p.is_file()}
def run(name,command,expected=0):
    row=dict(name=name,command=list(map(str,command)),status='running');report['stages'].append(row);save();began=time.monotonic()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(row['command'],cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();code=child.wait()
    row.update(exitCode=code,elapsedSeconds=round(time.monotonic()-began,3),status='expected_result' if code==expected else 'unexpected_result');save()
    assert code==expected,(name,code,expected)
began=time.monotonic();save()
try:
    before=sources();report['source']=before;save()
    for name,digest in before.items():
        destination=OUT/'frozen-source'/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes((WORK/name).read_bytes());assert sha(destination)==digest
    # Index qualification has already compiled all current host controls. Reuse
    # that evidence only if these exact inputs are unchanged, rather than rerun.
    assert index['source']==before,'Compile/host evidence must match the exact current source'
    report['hostQualificationReceiptSha256']=sha(INDEX/'receipt.json')
    run('build',['cargo','build','--offline','--locked','--bin','motion-depth-graph-probe'])
    original=Path(env['CARGO_TARGET_DIR'])/'debug/motion-depth-graph-probe.exe'
    binary=OUT/'retained-binary'/original.name;binary.parent.mkdir();shutil.copyfile(original,binary);assert sha(original)==sha(binary)
    report['binarySha256']=sha(binary);save()
    # The GPU binary sees only the input, resources and static program. It is
    # never given the final reference file or any CPU intermediate tensor.
    fixture=json.loads((FIXTURES/'receipt.json').read_text())
    input_sha=fixture['authoredInputSha256'];reference_sha=fixture['finalDepthSha256']
    input_path=FIXTURES/'tensors'/(input_sha+'.f32');reference_path=FIXTURES/'tensors'/(reference_sha+'.f32')
    assert sha(input_path)==input_sha and input_path.stat().st_size==1*3*518*518*4
    assert sha(reference_path)==reference_sha and reference_path.stat().st_size==1*518*518*4
    request_root=OUT/'request';request_root.mkdir();shutil.copyfile(input_path,request_root/'rgb.f32')
    request=dict(version=1,program=str(PROGRAM),program_sha256=sha(PROGRAM),requested_backend='vulkan',
        input=dict(name='rgb',dtype='float32',shape=[1,3,518,518],file='rgb.f32',sha256=input_sha))
    request_path=request_root/'request.json';request_path.write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8')
    run('actual-gpu',[binary,request_path,OUT/'gpu'])
    assert not (OUT/'actual-gpu.stdout.log').read_bytes(),'No product logs may enter stdout'
    gpu=json.loads((OUT/'gpu/receipt.json').read_text());info=(OUT/'gpu/logs/motion-studio.log').read_text(encoding='utf-8')
    assert gpu['status']=='actual_complete_gpu_output_written_independent_comparison_pending'
    assert 'start #0 complete_model_probe' in info and gpu['encoded_operations']==429 and gpu['final_readbacks']==1
    assert not gpu['per_node_cpu_injection'] and gpu['pool_retained_through_completion']
    assert gpu['actual_retained_buffer_capacity_bytes']==227968156
    # Independent post-process comparison, retaining the original same-model
    # gates and forbidding affine fitting, normalization or threshold tuning.
    import numpy as np
    reference=np.frombuffer(reference_path.read_bytes(),dtype='<f4').astype(np.float64)
    output=OUT/'gpu/relative_inverse_depth.f32';raw=output.read_bytes();assert sha(output)==gpu['output_sha256']
    actual=np.frombuffer(raw,dtype='<f4').astype(np.float64)
    assert actual.shape==reference.shape and np.isfinite(actual).all() and np.isfinite(reference).all()
    scale=max(float(np.abs(reference).max()),1e-6);error=np.abs(reference-actual)
    comparison=dict(referenceSha256=reference_sha,actualSha256=sha(output),elements=int(actual.size),normalizationScale=scale,
        maxAbsolute=float(error.max()),meanAbsolute=float(error.mean()),maxNormalized=float(error.max())/scale,
        meanNormalized=float(error.mean())/scale,worstFlatIndex=int(error.argmax()))
    comparison['passed']=comparison['maxNormalized']<=.0002 and comparison['meanNormalized']<=.00002
    report['comparison']=comparison;save()
    assert comparison['passed'],'Composed GPU did not meet the original end-to-end bounds'
    report['faults']=[]
    for fault in ['program-identity','input-hash','input-nonfinite','backend','resource-hash','resource-missing']:
        case=OUT/('fault-'+fault);case.mkdir();bad=copy.deepcopy(request);shutil.copyfile(input_path,case/'rgb.f32')
        if fault=='program-identity':bad['program_sha256']='0'*64
        elif fault=='input-hash':bad['input']['sha256']='0'*64
        elif fault=='input-nonfinite':
            path=case/'rgb.f32';data=bytearray(path.read_bytes());data[:4]=bytes.fromhex('0000c07f');path.write_bytes(data);bad['input']['sha256']=sha(path)
        elif fault=='backend':bad['requested_backend']='fallback'
        elif fault in ('resource-hash','resource-missing'):
            # Byte-identical trusted program, isolated payload root. Corrupt or
            # omit the lexically first resource; do not mutate original weights
            # or provide later files that could hide this admission failure.
            isolated=case/'program';isolated.mkdir();shutil.copyfile(PROGRAM,isolated/'program.json')
            blueprint=json.loads(PROGRAM.read_text());name=sorted(blueprint['resources'])[0]
            resource=blueprint['resources'][name];bad['program']=str(isolated/'program.json')
            if fault=='resource-hash':
                path=isolated/resource['file'];path.parent.mkdir(parents=True,exist_ok=True)
                data=bytearray((PROGRAM.parent/resource['file']).read_bytes());data[0]^=1;path.write_bytes(data)
                assert sha(path)!=resource['sha256']
        path=case/'request.json';path.write_text(json.dumps(bad,indent=2)+'\n',encoding='utf-8')
        run('fault-'+fault,[binary,path,case/'observed'],expected=1)
        observed=json.loads((case/'observed/receipt.json').read_text())
        stderr=(OUT/('fault-'+fault+'.stderr.log')).read_text(encoding='utf-8',errors='replace')
        file_log=(case/'observed/logs/motion-studio.log').read_text(encoding='utf-8')
        assert not (OUT/('fault-'+fault+'.stdout.log')).read_bytes()
        assert observed['failure'] in stderr and observed['failure'] in file_log
        report['faults'].append(dict(fault=fault,cause=observed['failure'],fileError=True,stderrError=True,stdoutEmpty=True));save()
    assert before==sources();report.update(status='standalone_composed_gpu_numerics_passed_product_integration_pending',sourceUnchanged=True,
        gpuReceiptSha256=sha(OUT/'gpu/receipt.json'),defaultInfoStartVisible=True,stdoutEmpty=True)
except BaseException as cause:
    report.update(status='composed_gpu_qualification_failed_original_outputs_retained',failure=repr(cause),traceback=traceback.format_exc())
    if 'before' in locals():report['sourceUnchanged']=sources()==before
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3));save()
print(json.dumps({k:v for k,v in report.items() if k!='source'}))
raise SystemExit(0 if report['status']=='standalone_composed_gpu_numerics_passed_product_integration_pending' else 1)
