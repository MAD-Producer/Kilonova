"""Static dataflow partition and alias lifetimes; no learned evaluation/device."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
import time
import traceback

os.environ.setdefault('OMP_NUM_THREADS','1');os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import numpy as np
import onnx

ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue'
MODEL=ROOT/'.tools/ai-depth74/models/depth_anything_v2_vits_518.onnx'
OUT=ART/'depth75-dataflow-v1'
EXPECTED='274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(MODEL)==EXPECTED
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='running_static_dataflow_partition',startedUtc=datetime.now(timezone.utc).isoformat(),
            modelSha256=EXPECTED,inferenceExecuted=False,gpuExecuted=False,
            limits=['Static metadata/integer control evaluation only; learned activations and weights are not evaluated',
                    'Materialized data operations are planned boundaries, not shader capability or complete inference',
                    'Aliases preserve actual contiguous physical ownership; transpose/gather/slice remain materialization',
                    'Logical lifetimes are not actual allocator, pending-submission or device-memory measurements'])
def save(): (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
try:
    model=onnx.load(str(MODEL),load_external_data=False)
    assert len(model.graph.node)==598 and not model.functions
    assert len(model.graph.input)==1 and model.graph.input[0].name=='rgb'
    inventory_path=ART/'depth75-static-model-audit-v3/tensor-inventory.json'
    inventory=json.loads(inventory_path.read_text())
    assert len(inventory)==598
    descriptions={row['name']:dict(dtype=row['dtype'],shape=row['shape'],bytes=row['bytes'])
                  for node in inventory for row in node['outputs']}
    descriptions['rgb']=dict(dtype='FLOAT',shape=[1,3,518,518],bytes=1*3*518*518*4)
    integer={};resources={};owner={'rgb':'rgb'};created={'rgb':-1};steps=[]
    initializers={t.name:t for t in model.graph.initializer}
    def resource(name,tensor):
        assert tensor.data_type==onnx.TensorProto.FLOAT
        array=onnx.numpy_helper.to_array(tensor)
        shape=list(array.shape)
        assert len(shape)<=5 and array.dtype==np.float32 and np.isfinite(array).all()
        raw=np.ascontiguousarray(array,dtype='<f4').tobytes()
        descriptions[name]=dict(dtype='FLOAT',shape=shape,bytes=len(raw))
        resources[name]=dict(shape=shape,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
        owner[name]=name;created[name]=-1
    for name,t in initializers.items():resource(name,t)
    def control(name,array):
        array=np.asarray(array)
        assert array.dtype in (np.dtype('int64'),np.dtype('bool')) and array.size<=64
        d=descriptions[name]
        assert list(array.shape)==d['shape']
        assert d['dtype']==('BOOL' if array.dtype==np.bool_ else 'INT64')
        integer[name]=array
    def axes(values,rank):
        normalized=[int(x)+rank if int(x)<0 else int(x) for x in values]
        assert len(set(normalized))==len(normalized) and all(0<=x<rank for x in normalized)
        return normalized
    def reshape_dimensions(input_shape,requested):
        requested=[int(x) for x in requested];assert len(requested)<=5 and requested.count(-1)<=1
        assert all(x>=-1 for x in requested)
        result=[input_shape[i] if v==0 else v for i,v in enumerate(requested)]
        if -1 in result:
            i=result.index(-1);known=math.prod(v for v in result if v!=-1)
            assert known>0 and math.prod(input_shape)%known==0
            result[i]=math.prod(input_shape)//known
        assert math.prod(result)==math.prod(input_shape)
        return result
    def slice_spec(node):
        shape=descriptions[node.input[0]]['shape'];rank=len(shape)
        starts=integer[node.input[1]].reshape(-1).tolist();ends=integer[node.input[2]].reshape(-1).tolist()
        chosen=integer[node.input[3]].reshape(-1).tolist() if len(node.input)>3 and node.input[3] else list(range(len(starts)))
        strides=integer[node.input[4]].reshape(-1).tolist() if len(node.input)>4 and node.input[4] else [1]*len(starts)
        chosen=axes(chosen,rank);assert len(starts)==len(ends)==len(chosen)==len(strides)
        slices=[slice(None)]*rank;mapping=[]
        for axis,start,end,stride in zip(chosen,starts,ends,strides):
            assert stride!=0
            selector=slice(int(start),int(end),int(stride));slices[axis]=selector
            normalized=selector.indices(shape[axis]);mapping.append(dict(axis=axis,start=normalized[0],end=normalized[1],step=normalized[2]))
        result=[len(range(*selector.indices(d))) for selector,d in zip(slices,shape)]
        return slices,result,mapping
    for index,node in enumerate(model.graph.node):
        assert not node.domain and len(node.output)==1
        name=node.output[0];d=descriptions[name]
        assert len(d['shape'])<=5 and all(isinstance(n,int) and n>=0 for n in d['shape'])
        attrs={a.name:onnx.helper.get_attribute_value(a) for a in node.attribute}
        row=dict(index=index,name=node.name,operation=node.op_type,output=name,outputShape=d['shape'])
        if node.op_type=='Constant':
            assert set(attrs)=={'value'}
            t=attrs['value']
            if d['dtype']=='FLOAT':resource(name,t);row['phase']='persistent_float_constant'
            else:control(name,onnx.numpy_helper.to_array(t));row['phase']='folded_integer_control'
        elif d['dtype']!='FLOAT':
            op=node.op_type
            if op=='Shape':
                shape=descriptions[node.input[0]]['shape'];start=attrs.get('start',0);end=attrs.get('end',len(shape))
                result=np.asarray(shape[start:end],np.int64)
            else:
                args=[integer[n] for n in node.input if n]
                if op=='Slice': selectors,_,_=slice_spec(node);result=args[0][tuple(selectors)]
                elif op=='Concat': result=np.concatenate(args,axis=attrs['axis'])
                elif op=='ConstantOfShape':
                    value=onnx.numpy_helper.to_array(attrs['value']);assert value.dtype==np.int64 and value.size==1
                    shape=tuple(int(n) for n in args[0].reshape(-1));assert math.prod(shape)<=64 and all(n>=0 for n in shape)
                    result=np.full(shape,int(value.reshape(-1)[0]),dtype=np.int64)
                elif op=='Mul': result=np.multiply(args[0],args[1])
                elif op=='Equal': result=np.equal(args[0],args[1])
                elif op=='Where': result=np.where(args[0],args[1],args[2])
                elif op=='Gather': result=np.take(args[0],args[1],axis=attrs.get('axis',0))
                elif op=='Reshape': result=args[0].reshape(reshape_dimensions(list(args[0].shape),args[1].reshape(-1)))
                elif op=='Squeeze': result=np.squeeze(args[0],axis=tuple(axes(args[1].reshape(-1),args[0].ndim)))
                else: raise AssertionError(('Unimplemented integer control operation',index,op))
            control(name,result);row['phase']='folded_integer_control'
        else:
            assert d['bytes']>0 and math.prod(d['shape'])*4==d['bytes']
            float_inputs=[n for n in node.input if n and descriptions[n]['dtype']=='FLOAT']
            if node.op_type=='Resize':float_inputs=[node.input[0]]
            assert float_inputs and len(float_inputs)<=3 and all(n in owner for n in float_inputs)
            row['inputs']=float_inputs
            if node.op_type in ('Reshape','Squeeze'):
                source=node.input[0];shape=descriptions[source]['shape']
                if node.op_type=='Reshape':
                    assert attrs=={'allowzero':0}
                    result=reshape_dimensions(shape,integer[node.input[1]].reshape(-1))
                else:
                    selected_axes=axes(integer[node.input[1]].reshape(-1),len(shape))
                    assert all(shape[a]==1 for a in selected_axes)
                    result=[n for i,n in enumerate(shape) if i not in selected_axes]
                assert result==d['shape'] and descriptions[source]['bytes']==d['bytes']
                owner[name]=owner[source];row.update(phase='contiguous_alias',owner=owner[name])
            else:
                op=node.op_type
                if op=='Transpose':
                    shape=descriptions[node.input[0]]['shape'];perm=attrs['perm']
                    assert sorted(perm)==list(range(len(shape))) and [shape[i] for i in perm]==d['shape']
                    row['permutation']=perm
                elif op=='Gather':
                    shape=descriptions[node.input[0]]['shape'];axis=axes([attrs.get('axis',0)],len(shape))[0]
                    indices=integer[node.input[1]];assert indices.size<=64
                    assert np.all(indices>=-shape[axis]) and np.all(indices<shape[axis])
                    assert shape[:axis]+list(indices.shape)+shape[axis+1:]==d['shape']
                    row.update(axis=axis,indices=np.where(indices<0,indices+shape[axis],indices).reshape(-1).tolist())
                elif op=='Slice':
                    _,shape,mapping=slice_spec(node);assert shape==d['shape'];row['sliceMapping']=mapping
                elif op=='Expand':
                    target=[int(n) for n in integer[node.input[1]].reshape(-1)]
                    assert list(np.broadcast_shapes(tuple(descriptions[node.input[0]]['shape']),tuple(target)))==d['shape']
                elif op=='Concat':
                    shapes=[descriptions[n]['shape'] for n in float_inputs];axis=axes([attrs['axis']],len(shapes[0]))[0]
                    shape=shapes[0].copy();shape[axis]=sum(s[axis] for s in shapes)
                    assert all(len(s)==len(shape) and all(v==shape[i] for i,v in enumerate(s) if i!=axis) for s in shapes)
                    assert shape==d['shape'];row['axis']=axis
                elif op in ('Add','Mul','Div'):
                    assert len(float_inputs)==2
                    assert list(np.broadcast_shapes(*(tuple(descriptions[n]['shape']) for n in float_inputs)))==d['shape']
                elif op=='Relu':assert len(float_inputs)==1 and descriptions[float_inputs[0]]['shape']==d['shape']
                else:assert op in ('Conv','ConvTranspose','MatMul','Softmax','LayerNormalization','Erf','Resize')
                row['phase']='materialize_float_gpu_pending'
                owner[name]=name;created[name]=index
            row['inputOwners']=[owner[n] for n in float_inputs]
            row['owner']=owner[name]
        steps.append(row)
    outputs=[v.name for v in model.graph.output];assert outputs==['relative_inverse_depth']
    used_resources={n for s in steps for n in s.get('inputs',[]) if n in resources}
    last={name:at for name,at in created.items()}
    for s in steps:
        for name in s.get('inputs',[]):last[owner[name]]=max(last[owner[name]],s['index'])
    for name in outputs:last[owner[name]]=len(steps)
    # Enumerate all physical owner intervals independently of traversal release.
    dynamic={name:dict(created=at,lastUse=last[name],bytes=descriptions[name]['bytes'])
             for name,at in created.items() if name not in resources}
    peak=max((sum(v['bytes'] for v in dynamic.values() if v['created']<=i<=v['lastUse']),i)
             for i in range(-1,len(steps)+1))
    aliases={name:physical for name,physical in owner.items() if name!=physical}
    artifact=dict(version=1,modelSha256=EXPECTED,steps=steps,tensors=descriptions,
                  persistentFloatResources={n:resources[n] for n in sorted(used_resources)},
                  aliases=aliases,ownerIntervals=dynamic,outputs=outputs,
                  capability='static_partition_only_not_executable')
    path=OUT/'static-dataflow.json';path.write_text(json.dumps(artifact,indent=2)+'\n',encoding='utf-8')
    report.update(status='static_dataflow_partitioned_execution_pending',phases=dict(Counter(s['phase'] for s in steps)),
                  materializedKinds=dict(Counter(s['operation'] for s in steps if s['phase']=='materialize_float_gpu_pending')),
                  nodes=len(steps),integerControlTensors=len(integer),aliasCount=len(aliases),
                  maximumRank=max(len(d['shape']) for d in descriptions.values()),
                  logicalOwnerPeakBytes=peak[0],logicalOwnerPeakNode=peak[1],
                  persistentUsedFloatBytes=sum(resources[n]['bytes'] for n in used_resources),
                  dataflowSha256=sha(path),inventorySha256=sha(inventory_path),
                  modelUnchanged=sha(MODEL)==EXPECTED,elapsedSeconds=round(time.monotonic()-began,3),
                  completedUtc=datetime.now(timezone.utc).isoformat())
    assert report['modelUnchanged'];save()
    print(json.dumps({k:v for k,v in report.items() if k!='limits'}))
except BaseException as cause:
    report.update(status='static_dataflow_failed_original_cause_retained',failure=repr(cause),traceback=traceback.format_exc(),completedUtc=datetime.now(timezone.utc).isoformat());save();raise
