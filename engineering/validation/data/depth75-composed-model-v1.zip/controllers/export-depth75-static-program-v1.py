"""Static model/weight export for future execution; evaluates no learned node."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import time
import traceback

os.environ.setdefault('OMP_NUM_THREADS','1');os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import numpy as np
import onnx

ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue'
MODEL=ROOT/'.tools/ai-depth74/models/depth_anything_v2_vits_518.onnx'
OUT=ART/'depth75-static-program-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert shutil.disk_usage(ROOT).free>=10<<30,'Original build-space threshold preserved; no cleanup performed'
data_path=ART/'depth75-dataflow-v1/static-dataflow.json';data=json.loads(data_path.read_text())
pool_path=ART/'depth75-storage-plan-v3/buffer-plan.json';pool=json.loads(pool_path.read_text())
pool_receipt=json.loads((pool_path.parent/'receipt.json').read_text())
assert pool_receipt['status']=='static_capacity_and_owner_audit_passed_execution_pending'
assert pool_receipt['dataflowSha256']==sha(data_path) and pool_receipt['bufferPlanSha256']==sha(pool_path)
assert sha(MODEL)==data['modelSha256']
OUT.mkdir(exist_ok=False);(OUT/'weights').mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='running_static_program_export',startedUtc=datetime.now(timezone.utc).isoformat(),
            modelSha256=data['modelSha256'],dataflowSha256=sha(data_path),bufferPlanSha256=sha(pool_path),
            inferenceExecuted=False,gpuExecuted=False,
            limits=['Exports existing model resources and static operator descriptions only; no learned computation',
                    'Raw weights remain external; no default distribution or product plan capability is enabled',
                    'Index shaders and composed execution remain uncompiled and unqualified',
                    'Static buffer capacity is not actual physical memory or performance'])
def save():(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
try:
    model=onnx.load(str(MODEL),load_external_data=False)
    assert len(model.graph.node)==len(data['steps'])==598
    initializers={t.name:t for t in model.graph.initializer}
    constants={n.output[0]:next(a.t for a in n.attribute if a.name=='value') for n in model.graph.node if n.op_type=='Constant'}
    resources={}
    for name,description in data['persistentFloatResources'].items():
        tensor=initializers[name] if name in initializers else constants[name]
        array=onnx.numpy_helper.to_array(tensor)
        assert array.dtype==np.float32 and np.isfinite(array).all() and list(array.shape)==description['shape']
        raw=np.ascontiguousarray(array,dtype='<f4').tobytes();digest=hashlib.sha256(raw).hexdigest()
        assert len(raw)==description['bytes'] and digest==description['sha256']
        path=OUT/'weights'/(digest+'.f32')
        if not path.exists():path.write_bytes(raw)
        assert sha(path)==digest
        resources[name]=dict(shape=description['shape'],bytes=len(raw),sha256=digest,file=path.relative_to(OUT).as_posix())
    program=[]
    for row in data['steps']:
        if row['phase']!='materialize_float_gpu_pending':continue
        node=model.graph.node[row['index']];assert node.name==row['name'] and node.op_type==row['operation']
        attrs={a.name:onnx.helper.get_attribute_value(a) for a in node.attribute}
        kind=node.op_type;operation=dict(kind=kind);family='numeric'
        if kind in ('Conv','ConvTranspose'):
            assert attrs.get('auto_pad',b'NOTSET')==b'NOTSET' and 'output_shape' not in attrs
            operation['attributes']=dict(kernel=attrs['kernel_shape'],stride=attrs['strides'],padding=attrs['pads'],
                dilation=attrs['dilations'],group=attrs['group'],output_padding=attrs.get('output_padding',[0,0]))
        elif kind in ('LayerNormalization','Softmax'):
            operation['axis']=attrs.get('axis',-1)
            if kind=='LayerNormalization':operation['epsilon']=attrs['epsilon']
        elif kind=='Resize':
            operation.update(mode=attrs['mode'].decode(),coordinate_transformation_mode=attrs['coordinate_transformation_mode'].decode())
        elif kind not in ('MatMul','Erf'):
            family='index'
            if kind=='Transpose':operation['permutation']=row['permutation']
            elif kind=='Gather':
                assert len(row['indices'])==1
                operation=dict(kind='GatherScalar',axis=row['axis'],index=row['indices'][0])
            elif kind=='Slice':
                mapping=row['sliceMapping']
                operation.update(starts=[x['start'] for x in mapping],
                    ends=[-(1<<63) if x['step']<0 and x['end']==-1 else x['end'] for x in mapping],
                    axes=[x['axis'] for x in mapping],steps=[x['step'] for x in mapping])
            elif kind=='Concat':operation['axis']=row['axis']
            else:assert kind in ('Add','Mul','Div','Relu','Expand')
        program.append(dict(index=row['index'],name=row['name'],family=family,operation=operation,
            inputs=row['inputs'],inputOwners=row['inputOwners'],output=row['output'],owner=row['owner']))
    assert len(program)==429 and sum(n['family']=='numeric' for n in program)==162
    assignments={e['owner']:e['slot'] for e in pool['trace'] if e['action']=='allocate'}
    assert set(assignments)==set(data['ownerIntervals']) and len(assignments)==430
    tensors={name:dict(dtype='float32',shape=d['shape'],bytes=d['bytes'])
             for name,d in data['tensors'].items() if d['dtype']=='FLOAT' and d['bytes']>0}
    blob=dict(version=1,capability='static_program_only_not_executable',modelSha256=data['modelSha256'],
        originalWeightsSha256='715fade13be8f229f8a70cc02066f656f2423a59effd0579197bbf57860e1378',
        input=dict(name='rgb',shape=[1,3,518,518],dtype='float32',preprocessing='Existing ImageNet-normalized NCHW518 tensor; RGB raster mapping not qualified here'),
        outputs=data['outputs'],tensors=tensors,resources=resources,aliases=data['aliases'],
        ownerSlots=assignments,poolSlotCapacities=pool['poolSlotCapacities'],
        persistentCapacities=pool['persistentCapacities'],capacityBudgetBytes=pool['budgetBytes'],
        declaredRetainedBufferCapacityBytes=pool['plannedRetainedBufferCapacityBytes'],
        uniformRingBytes=pool['uniformRingBytes'],uniformStride=256,readbackBytes=pool['readbackBytes'],
        uploadStagingBytes=pool['uploadStagingBytes'],dummyBindingBytes=pool['dummyBindingBytes'],
        orderingContract=pool['orderingContract'],allocationContract=pool['allocationContract'],operations=program)
    path=OUT/'program.json';path.write_text(json.dumps(blob,indent=2)+'\n',encoding='utf-8')
    # Deserialize/read back the exact instruction/resource boundary. This is a
    # serialization check, not a runtime schema/capability or inference proof.
    restored=json.loads(path.read_text());assert restored==blob
    assert path.stat().st_size<4<<20
    for name,r in restored['resources'].items():
        p=(OUT/r['file']).resolve(strict=True);assert p.is_relative_to(OUT)
        assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
    report.update(status='static_program_exported_execution_pending',programSha256=sha(path),programBytes=path.stat().st_size,
        gpuOperationDescriptions=len(program),numericalOperations=162,indexOperations=267,
        resourceNames=len(resources),rawWeightFiles=len(list((OUT/'weights').glob('*.f32'))),
        rawWeightBytes=sum(p.stat().st_size for p in (OUT/'weights').glob('*.f32')),
        declaredBufferCapacityBytes=pool['plannedRetainedBufferCapacityBytes'],
        modelUnchanged=sha(MODEL)==data['modelSha256'],elapsedSeconds=round(time.monotonic()-began,3),
        completedUtc=datetime.now(timezone.utc).isoformat())
    assert report['modelUnchanged'];save();print(json.dumps(report))
except BaseException as cause:
    report.update(status='static_program_export_failed_original_cause_retained',failure=repr(cause),traceback=traceback.format_exc(),completedUtc=datetime.now(timezone.utc).isoformat());save();raise
