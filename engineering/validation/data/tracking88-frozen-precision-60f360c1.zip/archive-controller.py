from pathlib import Path
import hashlib,json,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-colmap88';base=root/'artifacts/pr-queue'
dest=work/'engineering/validation/data/tracking88-frozen-precision-60f360c1.zip';assert not dest.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
entries={}
for directory in ['tracking88-current-freeze-build-v1','tracking88-current-freeze-native-v1']:
    for p in (base/directory).rglob('*'):
        if p.is_file():
            assert p.suffix.lower() not in ('.exe','.dll','.pdb','.onnx','.pth')
            entries['runs/'+p.relative_to(base).as_posix()]=p.read_bytes()
for rel in ['crates/motion-desktop-media/src/movie/frame.rs','crates/motion-desktop-media/src/movie/frozen.rs']:
    p=work/rel
    if p.is_file():entries['source/'+rel]=p.read_bytes()
entries['original-reference-receipt.json']=(work/'engineering/validation/data/tracking88-colmap-photographs-v1.json').read_bytes()
entries['archive-controller.py']=Path(__file__).read_bytes()
manifest={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(entries.items())}
entries['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(dest) as z:
    assert set(z.namelist())==set(entries)
    for name,data in entries.items():assert z.read(name)==data
receipt=dict(archive=dest.name,bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),members=len(entries),everyMemberReadBack=True,manifest=manifest)
dest.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='manifest'}))
