from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,time,zipfile
import cv2
import numpy as np
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-colmap88';probe=root/'.tools/tracking88/current-freeze-probe'
out=root/'artifacts/pr-queue/tracking88-current-freeze-native-v1';out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
builddir=root/'artifacts/pr-queue/tracking88-current-freeze-build-v1'
build=json.loads((builddir/'exit.json').read_text());assert build['exitCode']==0 and build['sourceUnchanged']
binary=root/'target/colmap88-isolated-check/debug/motion-tracking88-freeze-probe.exe';assert sha(binary.read_bytes())==build['binarySha256']
def frozen():
    return all(sha((probe/p.removeprefix('external-probe/')).read_bytes() if p.startswith('external-probe/') else (work/p).read_bytes())==h for p,h in build['source'].items())
assert frozen()
archive=work/'engineering/validation/data/tracking88-colmap-photographs-v1.zip'
original_receipt=json.loads(archive.with_suffix('.json').read_text());assert sha(archive.read_bytes())==original_receipt['sha256']
env=os.environ.copy()
for k in list(env):
    if k.startswith('MOTION_'):env.pop(k,None)
env.update(TEMP=str(root/'target/ci-policy-validation-tmp'),TMP=str(root/'target/ci-policy-validation-tmp'),LOCALAPPDATA=str(out/'appdata'))
env['PATH']=str(root/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')+os.pathsep+env['PATH']
report=dict(head=build['head'],source=build['source'],binarySha256=build['binarySha256'],commands=[],views=[],
            originalArchiveSha256=original_receipt['sha256'],startedUtc=datetime.now(timezone.utc).isoformat(),
            limits=['Three separately photographed calibrated poses, not continuous motion or COLMAP solver execution',
                    'Pinned independently generated ray/plane image oracles, not fresh calibration',
                    'Four working precisions -> explicitly SDR_CLIP 8-bit PNG, no HDR file or dynamic-range proof',
                    'Actual frozen exporter after live-layer deletion and Session closure, not a GUI window',
                    'Default stack/backend/layer environment; no full regression claim'])
(out/'controller.py').write_bytes(Path(__file__).read_bytes());(out/'build-receipt.json').write_bytes((builddir/'exit.json').read_bytes())
for rel in ('Cargo.toml','Cargo.lock','src/main.rs'):
    dest=out/'probe'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((probe/rel).read_bytes())
def save(): (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
started=time.monotonic()
try:
    with zipfile.ZipFile(archive) as z:
        for label in ('left03','left08','left14'):
            directory=out/label;directory.mkdir();project=directory/'project';project.mkdir()
            prefix=f'tracking88-colmap-photographs-native-v4/{label}/'
            inputs={}
            for name in z.namelist():
                if name.startswith(prefix):
                    rel=Path(name.removeprefix(prefix))
                    if str(rel).replace('\\','/')=='project.json' or str(rel).replace('\\','/').startswith('assets/'):
                        dest=(project/rel).resolve();assert dest.is_relative_to(project.resolve())
                        dest.parent.mkdir(parents=True,exist_ok=True);data=z.read(name);dest.write_bytes(data);inputs[rel.as_posix()]=sha(data)
            assert len(inputs)==3,inputs
            expected_bytes=z.read(f'tracking88-colmap-photographs-native-v4/{label}-independent.png')
            (directory/'independent.png').write_bytes(expected_bytes)
            expected=cv2.imdecode(np.frombuffer(expected_bytes,np.uint8),cv2.IMREAD_UNCHANGED)[:,:,[2,1,0,3]]
            assert expected.shape==(480,640,4)
            stable=np.ones((480,640),bool)
            for dy in (-2,0,2):
                for dx in (-2,0,2):stable &= np.all(expected==np.roll(expected,(dy,dx),(0,1)),axis=2)
            stable[:2]=False;stable[-2:]=False;stable[:,:2]=False;stable[:,-2:]=False
            checked=int(stable.sum());interior=int((stable&(expected[:,:,3]>0)).sum())
            assert checked>200000 and interior>3000
            command=[str(binary),str(project),str(directory)]
            row=dict(name=label,command=command);report['commands'].append(row);save()
            with (directory/'stdout.log').open('wb') as stdout,(directory/'stderr.log').open('wb') as stderr:
                p=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait(timeout=180)
            save();assert row['exitCode']==0,label
            assert not (directory/'stdout.log').read_bytes()
            assert all(sha((project/rel).read_bytes())==h for rel,h in inputs.items())
            result=json.loads((directory/'result.json').read_text());assert result['actualFrozenPng'] and not result['actualGuiEngine']
            log=(directory/'logs/motion-studio.log').read_text(encoding='utf-8');assert 'logging initialized level=INFO' in log
            scores=[]
            for item in result['views']:
                mode=item['precision'];assert item['liveLayersDeletedBeforeExport'] and item['sessionDroppedBeforeExport']
                assert 'phase=export_after_session_drop precision='+mode in log
                captured=json.loads((directory/(mode+'-captured-project.json')).read_text());live=json.loads((directory/(mode+'-live-after-delete.json')).read_text())
                assert captured['working_precision']==mode and len(captured['layers'])==40 and not live['layers']
                actual=cv2.imread(str(directory/(mode+'.png')),cv2.IMREAD_UNCHANGED)[:,:,[2,1,0,3]];assert actual.shape==expected.shape
                a=actual.copy();b=expected.copy();transparent=(a[:,:,3]==0)&(b[:,:,3]==0);a[transparent,:3]=0;b[transparent,:3]=0
                maximum=int(np.abs(a.astype(int)-b.astype(int))[stable].max());alpha=int(np.abs(a[:,:,3].astype(int)-b[:,:,3].astype(int))[stable].max())
                assert maximum<=2 and alpha<=2,(label,mode,maximum,alpha)
                def linear(v):
                    x=v[:,:,:3].astype(float)/255.;return np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)
                aa=actual[:,:,3:4].astype(float)/255.;ba=expected[:,:,3:4].astype(float)/255.;composite=[]
                for bg in (0.,1.):
                    error=float(np.abs(linear(actual)*aa+bg*(1-aa)-linear(expected)*ba-bg*(1-ba))[stable].max())*255.
                    assert error<=2.,(label,mode,bg,error);composite.append(error)
                scores.append(dict(precision=mode,maxByteError=maximum,maxAlphaByteError=alpha,blackWhiteCompositeByteErrors=composite,pngSha256=sha((directory/(mode+'.png')).read_bytes())))
            assert [v['precision'] for v in scores]==['unorm8','unorm16','float16','float32']
            report['views'].append(dict(name=label,inputs=inputs,oracleSha256=sha(expected_bytes),checkedStablePixels=checked,interiorStablePixels=interior,precisions=scores));save()
    report.update(status='passed',sourceUnchanged=frozen(),stdoutEmpty=True)
    assert report['sourceUnchanged']
except BaseException as error:
    report.update(status='failed_original_outputs_retained',failure=repr(error));raise
finally:
    report.update(elapsedSeconds=round(time.monotonic()-started,3),completedUtc=datetime.now(timezone.utc).isoformat());save()
report['artifacts']={p.relative_to(out).as_posix():sha(p.read_bytes()) for p in out.rglob('*') if p.is_file()}
(out/'verified.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('source','artifacts','commands')}))
