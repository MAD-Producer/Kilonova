//! External acceptance of current photographed tracking in frozen PNG output.
#[path = "E:/Dev/aem/.worktrees/tracking-colmap88/desktop/app/src/logging.rs"]
mod logging;
mod engine {
    pub fn current_command() -> Option<(u64, &'static str, std::time::Duration)> { None }
}
use motion_core::{Command, Project};
use motion_desktop_media::movie::{frame::FrameFreezePlan, ExportControl};
use motion_host::Session;
use std::{fs, path::PathBuf};

fn run() -> Result<(), String> {
    let root=PathBuf::from(std::env::args().nth(1).ok_or("missing project")?);
    let out=PathBuf::from(std::env::args().nth(2).ok_or("missing output")?);
    let _logger=logging::init(out.join("logs")).map_err(|e|e.to_string())?;
    let original:Project=serde_json::from_slice(&fs::read(root.join("project.json")).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
    original.validate().map_err(|e|e.to_string())?;
    assert_eq!(original.layers.len(),40);
    assert!(original.camera.tracking.is_some());
    let mut results=Vec::new();
    for mode in ["unorm8","unorm16","float16","float32"] {
        log::info!("probe operation=photographed_tracking_freeze phase=session precision={mode}");
        logging::flush();
        let mut project=original.clone();
        project.working_precision=serde_json::from_value(serde_json::json!(mode)).map_err(|e|e.to_string())?;
        let mut session=Session::new(project,root.clone(),motion_desktop_media::platform()).map_err(|e|e.to_string())?;
        let captured=session.engine.snapshot();
        let revision=session.engine.revision();
        let output=out.join(format!("{mode}.png"));
        let plan=FrameFreezePlan::capture(&session,Some(output),&ExportControl::default())?;
        assert_eq!(session.engine.snapshot(),captured);
        session.apply_command_batch(captured.layers.iter().map(|layer|Command::Delete {object:layer.id}).collect()).map_err(|e|e.to_string())?;
        assert!(session.engine.project().layers.is_empty());
        let live=session.engine.snapshot();
        assert_ne!(live,captured);
        fs::write(out.join(format!("{mode}-captured-project.json")),serde_json::to_vec_pretty(&captured).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
        fs::write(out.join(format!("{mode}-live-after-delete.json")),serde_json::to_vec_pretty(&live).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
        drop(session);
        log::info!("probe operation=photographed_tracking_freeze phase=export_after_session_drop precision={mode}");
        logging::flush();
        let result=std::thread::Builder::new().name("tracking-frozen-png-probe".into())
            .spawn(move ||plan.export(&ExportControl::default())).map_err(|e|e.to_string())?
            .join().map_err(|_|"frozen PNG worker panicked")??;
        assert_eq!(result["revision"],revision);
        assert_eq!(result["width"],640);assert_eq!(result["height"],480);assert_eq!(result["frame"],0.);
        results.push(serde_json::json!({"precision":mode,"export":result,"liveLayersDeletedBeforeExport":true,"sessionDroppedBeforeExport":true}));
    }
    fs::write(out.join("result.json"),serde_json::to_vec_pretty(&serde_json::json!({"actualFrozenPng":true,"actualGuiEngine":false,"views":results})).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
    logging::flush();Ok(())
}
fn main()->Result<(),String> {
    match std::thread::Builder::new().name("tracking-session-probe".into()).spawn(run).map_err(|e|e.to_string())?.join() {
        Ok(result)=>result,
        Err(payload)=>std::panic::resume_unwind(payload),
    }
}
