"""Archive only terminal, source-bound camera-routing evidence."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess,zipfile
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-lens-routing-acceptance-v2'
NATIVE=ROOT/'artifacts/pr-queue/tracking88-lens-routing-native-v2'
r=json.loads((OUT/'exit.json').read_text(encoding='utf-8'))
n=json.loads((NATIVE/'exit.json').read_text(encoding='utf-8'))
assert r['status']=='accepted_camera_lens_increment_full_issue_pending',r
assert n['status']=='accepted_native_nonlinear_lens_increment_not_full_issue',n
assert len(r['steps'])==7 and all(s['exitCode']==0 for s in r['steps'])
assert all(s['exitCode']==0 for s in n['steps'])
for name,digest in r['source'].items():assert hashlib.sha256((WORK/name).read_bytes()).hexdigest()==digest,name
counts={}
for name in ('model','core','render','host-tracking'):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (OUT/(name+'.log')).read_text(encoding='utf-8'))
 assert rows,name
 counts[name]=[sum(int(v[i]) for v in rows) for i in range(3)]
 assert counts[name][1]==0,counts
assert counts['model']==[242,0,0],counts
assert counts['core'][2]==1 and counts['render'][2]==0 and counts['host-tracking'][2]==0,counts
oracle=json.loads((OUT/'images/routing-oracle.json').read_text())
assert len(oracle)==12 and all(s['maxByteError']<=2 and s['checked']>250000 for s in oracle)
assert all(m['oracle']['mismatched']==0 for sample in n['samples'] for m in sample['markers'])
changed=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
assert not any(s.startswith('desktop/app/src/panels/') for s in changed)
source=sorted(s for s in changed if s.endswith(('.rs','.wgsl')))
payload={'finalizer.py':Path(__file__).read_bytes()}
for directory,label in [(OUT,'acceptance'),(NATIVE,'native')]:
 for file in sorted(directory.rglob('*')):
  if file.is_file() and file.suffix in ('.json','.jsonl','.log','.py','.png','.mstrack','.mp4','.pts'):
   payload[label+'/'+file.relative_to(directory).as_posix()]=file.read_bytes()
for name in source:payload['source/'+name]=(WORK/name).read_bytes()
payload['change.patch']=subprocess.check_output(['git','diff','--binary'],cwd=WORK)
for name in ('tracking88-lens-routing-focused-v1','tracking88-lens-routing-diagnostic-v1','tracking88-lens-routing-identity-v1','tracking88-lens-routing-isolation-v1','tracking88-lens-overlay-fix-v1','tracking88-lens-ownership-v1','tracking88-lens-ownership-v2','tracking88-lens-routing-boundaries-v1','tracking88-lens-routing-boundaries-v2','tracking88-lens-routing-acceptance-v1','tracking88-lens-retained-boundary-v1','tracking88-lens-host-guard-v1','tracking88-lens-host-guard-v2'):
 directory=ROOT/'artifacts/pr-queue'/name
 assert directory.is_dir(),name
 for file in sorted(directory.rglob('*')):
  if file.is_file() and file.suffix in ('.log','.png','.txt','.json'):
   payload['history/'+name+'/'+file.relative_to(directory).as_posix()]=file.read_bytes()
data=WORK/'engineering/validation/data';archive=data/'tracking88-lens-camera-routing-v1.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,content in sorted(payload.items()):z.writestr(name,content)
with zipfile.ZipFile(archive) as z:
 assert sorted(z.namelist())==sorted(payload)
 for name,content in payload.items():assert z.read(name)==content,name
archive_info=dict(path=archive.name,bytes=archive.stat().st_size,members=len(payload),sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
pending=['calibrated permitted-source real footage with independent measured residuals; the source-video controls use synthetic camera observations','vendor adapters, lens replacement/relink/cache invalidation','actual fractional camera shutter accumulation pixels beyond receiver ownership; nondefault spatial sampling requires an explicit path','lens plus aperture, spatial depth/masks/mattes/effects/custom blending/nested-3D boundaries explicitly refused until separately implemented','full maintained workspace/desktop regression and cross-platform CI','previous native/compiler crash causes and #82 strict P95/GPU coverage failures']
summary=dict(status=r['status'],createdUtc=datetime.now(timezone.utc).isoformat(),baseCommit=r['baseCommit'],counts=counts,archive=archive_info,source={s:hashlib.sha256((WORK/s).read_bytes()).hexdigest() for s in source},oracle=oracle,nativeExeSha256=n['steps'][-1].get('exeSha256'),nativeSamples=n['samples'],allOwnedValidatorsTerminal=True,pending=pending)
(data/'tracking88-lens-camera-routing-closeout.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
table='\n'.join(f'| {name} | {v[0]} | {v[1]} | {v[2]} |' for name,v in counts.items())
document=f'''# Tracking #88: nonlinear camera composition routing

This increment follows `{r['baseCommit']}` and the certified lens primitive.
Nonzero camera distortion now has an actual native composition output route,
with matching spatial projection, picking, drag and sampled selection outlines.
This is a bounded Windows acceptance checkpoint, not completion of #88 or the
3D route. Android is retired. No panel, widget, style, dependency or third-party
asset changed; test fixtures were independently authored.

## Implemented and verified

- **CAM-LENS-1 / runtime ownership:** CameraSample retains a separate LensWarp
  alongside the ideal pinhole matrix. Named/shared frames preserve that value;
  observer cameras replace only the root lens, nested compositions keep their
  own lens, and fractional exposure receivers retain their own calibration.
  Authored/imported model cameras carry no tracking lens. The matrix-only
  calibrated_projection API continues to refuse nonzero coefficients. Invalid
  or uncertifiable calibration is an error even under AuthoredOnly fallback.
- **CAM-LENS-2 / actual spatial composition:** eligible contiguous runs of OBJ
  meshes and planes resolve native depth, MSAA and premultiplied alpha into a
  certified physical overscan raster. The inverse output pass runs before the
  ordinary full-composition overlay. Authored flat-layer boundaries remain flat;
  nested raster output is not distorted again by its parent's camera. Overscan
  is charged to source and shared native allocation limits. Public encoder and
  device ownership guards remain intact; parameter blocks are immutable per
  encode and retained through submission.
- **CAM-LENS-3 / interaction geometry:** project_point now returns a checked
  Result rather than fabricated nonfinite/out-of-domain coordinates. Existing
  valid-point test callers unwrap that result without changing assertions.
  Spatial hit rays invert the same lens; flat and already-rasterized overlays
  retain output coordinates. View-plane drags preserve depth while applying an
  output delta through the forward/inverse mapping. Plane selection edges use
  bounded 16-point sampling per ideal edge. Uncertified anchors/outlines are
  omitted through the existing optional APIs; the checked point API retains
  the cause. This does not add widgets or alter hit tolerances.
- **CAM-LENS-4 / independent pixels:** 4 crop rotations 脳 zero/negative/positive
  radial controls with tangential distortion, real independently authored OBJ,
  transparent planes, depth overlap and a flat separator. Each full-frame
  comparison checks over 250,000 stable pixels using an independent analytic
  Newton ray oracle, with the original fixed two-pixel exclusion and two-byte
  threshold. Actual maxima: {max(s['maxByteError'] for s in oracle)}. Projection,
  picking and drag have independent ray checks; queued complete compositions
  retain distinct lens parameters. Native alpha survives all four precisions.
  Existing primitive controls continue to check HDR and exact identity bytes.
- **CAM-LENS-5 / explicit boundaries:** packed plans and host portable geometry
  output refuse root or nested nonlinear output before serialization. Unsupported
  spatial inputs, including model blending, report composition/frame/object and
  phase rather than rendering an undistorted fallback. Aperture plus lens is
  explicitly refused pending a calibrated gather path. Budget, blend and
  aperture failures have successful real-pixel recovery controls. Retained spatial
  images and actual ExposureFrame tasks explicitly refuse nonlinear temporal
  composition until that path exists; normal misses and flat receivers work.
  Already-retained ideal rasters cannot bypass the guard after camera replacement.
- **CAM-LENS-6 / native executable:** current-source FFmpeg desktop build, MCP
  import of original raw tracking bytes against the repository's original PTS
  fixture, nonzero radial/tangential output, keyed manual camera correction,
  undo/redo, save and read-only reopen. Three captures have independent Newton
  ray pixel checks with zero stable-pixel mismatches. Invalid binding, timing-gap
  and uncertifiable lens controls produce default-level Error records in both
  file and stderr. Info starts are present with MOTION_LOG unset; stdout remains
  strictly parsed JSON-RPC. This synthetic solve on a real video container is
  not a real-footage calibration or scene match.

## Separately explained functional correction

**CAM-LENS-FIX:** the first mesh pixel oracle failed at zero distortion too:
right-side coverage ended at x=560 instead of the independently expected region.
Replacing the OBJ with a plane restored coverage. The fast composition path
was applying the spatial camera to a full-composition model raster that already
contained camera projection. It now uses the same overlay projection as the
compositor and effect path. The original failure PNGs, geometry dump, isolated
model/plane controls and unchanged-threshold passing images are archived. This
is a functional projection fix, not an observability-only disposition. Temporary
test compile errors are retained as history; no failed assertion was weakened.

## Source-bound local acceptance

One serial controller hashed all Rust/WGSL/manifests before and after every
step. No source changed while it ran. Counts from its terminal logs:

| Gate | Passed | Failed | Ignored |
| --- | ---: | ---: | ---: |
{table}

The core ignored test is the pre-existing manual qualification gate; no new
test is ignored in this checkpoint. All selected renderer GPU tests ran.
FFmpeg desktop check, provenance validation and native executable acceptance
also passed. This does not replace full workspace/desktop or cross-platform CI.
Older compiler access violations and native failures remain unresolved; passing
changed source does not establish that those faults were repaired.

Archive: [source, logs, failures and actual captures](data/{archive_info['path']})
({archive_info['bytes']} bytes, {archive_info['members']} members), SHA-256
`{archive_info['sha256']}`. The JSON closeout records exact source hashes, counts,
pixel metrics and remaining scope. All owned validators were terminal before
archive creation. No cache, artifact or foreign worktree was deleted.

## Remaining scope

'''+''.join('- '+item+'\n' for item in pending)
(WORK/'engineering/validation/tracking88-lens-camera-routing-current.md').write_text(document,encoding='utf-8')
print(json.dumps(dict(counts=counts,archive=archive_info,pending=pending),indent=2))
