"""Resume successful source-frozen tests after auditing an outdated ignore inventory.
The original controller/output stay intact, including its failed inventory assertion.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess

root=Path('E:/Dev/aem');work=root/'.worktrees/gltf-scene'
prior=root/'artifacts/pr-queue/issue87-model-main-full-v1'
out=root/'artifacts/pr-queue/issue87-model-main-finish-v1';out.mkdir(exist_ok=False)
r=json.loads((prior/'exit.json').read_text(encoding='utf-8'))
head=r['head'];base=r['base'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def source():
    paths=subprocess.check_output(['git','ls-files','-z'],cwd=work).decode().split('\0')
    return {p:sha(work/p) for p in sorted(paths) if p and (work/p).is_file() and (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
def unchanged():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==head
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=work)
    assert r['source']==source()
unchanged()
assert all(s['exitCode']==0 and s['sourceUnchanged'] and s['worktreeClean'] for s in r['steps'])
s=r['steps'][-1];assert s['name']=='workspace-tests'
assert s['totals']==dict(passed=3164,failed=0,ignored=14,targets=311)
for step in r['steps']:
    for stream in ('stdout','stderr'):
        assert sha(prior/(step['name']+'.'+stream+'.log'))==step[stream+'Sha256']
text=(prior/'workspace-tests.stdout.log').read_text(encoding='utf-8')
observed=s['ignoredObserved'];assert len(observed)==14
old=(root/'artifacts/pr-queue/issue78-final-g-v8/workspace-tests/stdout.log').read_text(encoding='utf-8')
old_ignored=[line for line in old.splitlines() if re.match(r'test .* \.\.\. ignored',line)]
assert len(old_ignored)==12
extra=set(observed)-set(old_ignored)
assert extra=={
 'test panels::expressions::expanded::tests::native::expression_editor_native_drafts_menus_diagnostics_and_floating_input ... ignored, manual native GPU expression editor captures and input routing',
 'test panels::expressions::expanded::tests::native::reference::property_reference_native_menus_drag_drafts_and_float_transactions ... ignored, manual native GPU property reference gestures and menu captures',
}
tokens=[row.split(' ... ')[0].split('::')[-1].removeprefix('test ') for row in observed]
args=['git','grep','-l']
for token in tokens:args+=['-e',token]
paths=subprocess.check_output(args+[base,'--','*.rs'],cwd=work,text=True).splitlines()
audit=[]
for row,token in zip(observed,tokens):
    found=[]
    for ref in paths:
        path=ref.split(':',1)[1]
        data=subprocess.check_output(['git','show',base+':'+path],cwd=work)
        if ('fn '+token+'(').encode() not in data:continue
        base_blob=subprocess.check_output(['git','rev-parse',base+':'+path],cwd=work,text=True).strip()
        head_blob=subprocess.check_output(['git','rev-parse',head+':'+path],cwd=work,text=True).strip()
        assert base_blob==head_blob, path
        pos=data.index(('fn '+token+'(').encode())
        assert b'ignore' in data[max(0,pos-400):pos],path
        found.append(dict(path=path,blob=base_blob))
    assert len(found)==1,(token,found)
    audit.append(dict(test=row,unchangedFromMergedBase=found[0]))
for token in ('model_catalog_bounds_new_and_cached_retained_payloads_together','model_materials_obey_shared_source_budget_and_mesh_draws_are_reported','saved_model_keyframes_render_inside_the_editor','scene_native_access_rejects_a_foreign_thread_before_allocation_and_recovers'):
    assert re.search(r'test [^\n]*'+token+r' \.\.\. ok',text),token
receipt=dict(head=head,base=base,source=r['source'],priorReceipt=str(prior/'exit.json'),
             priorControllerFailure='outdated inventory expected 12; merged base already contains both manual expression captures',
             inventoryAudit=audit,newIgnoredTests=[],workspaceTotals=s['totals'],steps=[])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
(out/'baseline-audit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
env=os.environ.copy();target=root/'target/gltf-scene87-contract'
env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',LOCALAPPDATA=str(out/'appdata'))
env.pop('MOTION_LOG',None)
for name,cmd in [('desktop-binary',['cargo','build','-p','motion-desktop','--features','ffmpeg','--locked','--offline']),('command-list',[str(target/'debug/motion-studio.exe'),'--command-list'])]:
    unchanged();print(json.dumps(dict(start=name)),flush=True)
    step=dict(name=name,command=cmd)
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        p=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr)
        step['pid']=p.pid;receipt['steps'].append(step)
        (out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
        step['exitCode']=p.wait()
    unchanged();step['sourceUnchanged']=True
    for stream in ('stdout','stderr'):step[stream+'Sha256']=sha(out/(name+'.'+stream+'.log'))
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    assert step['exitCode']==0
    if name=='command-list':
        assert 'register_model_asset' in json.dumps(json.loads((out/(name+'.stdout.log')).read_text(encoding='utf-8')))
        assert not (out/(name+'.stderr.log')).read_bytes()
        receipt['binarySha256']=sha(target/'debug/motion-studio.exe')
receipt['completedUtc']=datetime.now(timezone.utc).isoformat()
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,totals=s['totals'],baselineIgnores=14,newIgnores=0)),flush=True)
