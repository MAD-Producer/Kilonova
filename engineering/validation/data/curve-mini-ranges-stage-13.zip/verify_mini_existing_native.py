from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
from PIL import Image
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges'
stage=root/'.tools/curve-view-ranges'/('app-stage-'+sys.argv[1])
r=json.loads((stage/'receipt.json').read_text(encoding='utf8'))
assert r['build_exit_code']==0 and r['source_unchanged'] and len(r['runs'])==9 and all(run['exit_code']==0 for run in r['runs'])
def freeze():return {path:hashlib.sha256((work/path).read_bytes()).hexdigest() for path in r['sources']}
assert freeze()==r['sources']
binary=Path(re.search(r'Executable unittests[^\n]*\(([^\n]+\.exe)\)',(stage/'build.log').read_text(encoding='utf8')).group(1))
assert hashlib.sha256(binary.read_bytes()).hexdigest()==r['binary_sha256']
out=stage/'native-clipboard';out.mkdir(exist_ok=False)
name='shell::curve_comparison_tests::curve_clipboard_native::curve_clipboard_native_main_and_float_keep_explicit_targets_and_cancel_focus_loss'
env=dict(os.environ,MOTION_CURVE_CLIPBOARD_GPU_ARTIFACTS=str(out));env.pop('MOTION_LOG',None)
started=time.monotonic()
with (out/'stdout.log').open('w',encoding='utf8') as stdout,(out/'stderr.log').open('w',encoding='utf8') as stderr:
 result=subprocess.run([str(binary),'--exact',name,'--ignored','--nocapture','--test-threads=1'],cwd=work,env=env,stdout=stdout,stderr=stderr)
text=(out/'stdout.log').read_text(encoding='utf8')
summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
record=dict(head=r['head'],binary_sha256=r['binary_sha256'],test=name,exit_code=result.returncode,summary=summary,seconds=round(time.monotonic()-started,2),source_unchanged=freeze()==r['sources'],scope='Existing native Mini copy/paste routing regression, production Input injection, six EN/ZH main/floating GPU screenshots at controlled ratios. Does not prove new range-menu native/DPI acceptance, physical OS input or saved-file bytes.')
(out/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8')
assert result.returncode==0 and summary==[('ok','1','0','0')] and record['source_unchanged'],record
e=json.loads((out/'result.json').read_text(encoding='utf8'))
assert e['screenshots']==6 and e['nativeMainAndFloat'] and e['focusLossAndImeCancel'] and e['projectRevisionHistoryUnchanged']
pngs=[]
for p in sorted(out.glob('*.png')):
 im=Image.open(p);im.verify();im=Image.open(p)
 pngs.append(dict(path=p.name,size=list(im.size),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
assert len(pngs)==6
record.update(evidence=e,pngs=pngs)
(out/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in record.items() if k!='pngs'}),flush=True)
