from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
ART = ROOT / 'artifacts/pr-queue'
OUT = ART / 'tracking88-manual-absence-review-v1'
OUT.mkdir(exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
audit = json.loads((ART / 'tracking88-manual-absence-validation-v3/exit.json').read_text(encoding='utf-8'))
assert audit['status'] == 'passed_final_audit_of_executed_v2_gates_without_rerunning'
members = {}
staged = {}
for name, digest in audit['source'].items():
    data = (WORK / name).read_bytes()
    assert sha(data) == digest
    members['final-source/' + name] = data
    blob = subprocess.check_output(['git', 'show', ':'+name], cwd=WORK)
    assert blob.replace(b'\r\n', b'\n') == data.replace(b'\r\n', b'\n')
    staged[name] = sha(blob)
for name in ['plate_contract.py', 'plate_flow.py', 'track_plate.py']:
    members['baseline-source/' + name] = subprocess.check_output(
        ['git', 'show', 'cb7871f48e3ab62ddafe89eecd1bcbbaeb0c5845:tools/tracking/'+name], cwd=WORK)

for stem in ['red', 'green']:
    directory = ART / f'tracking88-manual-absence-{stem}-v1'
    receipt = json.loads((directory / 'evaluation.json').read_text(encoding='utf-8'))
    assert receipt['status'] == ('failed' if stem == 'red' else 'accepted_actual_manual_absence_and_failure_reset_controls')
    for path in directory.rglob('*'):
        if path.is_file():
            members[f'actual-cli-{stem}/' + path.relative_to(directory).as_posix()] = path.read_bytes()
for version in [1, 2, 3]:
    directory = ART / f'tracking88-manual-absence-validation-v{version}'
    for name in ['controller.py', 'exit.json', 'tools.stdout.log', 'tools.stderr.log',
                 'cv-controls.stdout.log', 'cv-controls.stderr.log', 'synthetic.stdout.log', 'synthetic.stderr.log',
                 'full-real.stdout.log', 'full-real.stderr.log', 'real-controller.py', 'synthetic/evaluation.json']:
        if (directory / name).is_file():
            members[f'validation-v{version}/' + name] = (directory / name).read_bytes()
real = ART / 'tracking88-photographed-manual-absence-v2'
members['real/measurement.json'] = (real / 'measurement.json').read_bytes()
members['real/baseline-measurement.json'] = (ART / 'tracking88-photographed-prototype-v6/measurement.json').read_bytes()
for mode in ['no-corrections', 'periodic-manual-200']:
    for name in [mode+'.stdout.log', mode+'.stderr.log', mode+'/tracking.log']:
        members['real/' + name] = (real / name).read_bytes()
for directory, names in [
    ('tracking88-local-motion-v1', ['controller.py', 'diagnostic.json']),
    ('tracking88-preview-alignment-v1', ['controller.py', 'diagnostic.json', 'nearest-tie-summary.json', 'identical-image-annotation-check.json']),
    ('tracking88-original-frames-v1', ['controller.py', 'acquisition.json']),
]:
    for name in names:
        members['diagnostic/' + directory + '/' + name] = (ART / directory / name).read_bytes()
for name in ['verify-tracking88-original-image-checks-v1.py', 'measure-tracking88-photographed-v5.py',
             'validate-tracking88-manual-absence-v1.py', 'validate-tracking88-manual-absence-v2.py',
             'audit-tracking88-manual-absence-v3.py']:
    members['controllers/' + name] = (ROOT / '.tools/issue-closure-review' / name).read_bytes()
members['archive-controller.py'] = Path(__file__).read_bytes()
archive = OUT / 'tracking88-manual-absence-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted(members.items()):
        bundle.writestr(name, data)
with zipfile.ZipFile(archive) as bundle:
    assert set(bundle.namelist()) == set(members)
    assert all(bundle.read(name) == data for name, data in members.items())
report = dict(status='manual_absence_fault_classification_fixed_and_actual_failure_paths_verified',
    oldHead='cb7871f48e3ab62ddafe89eecd1bcbbaeb0c5845', audit=audit, stagedSourceSha256=staged,
    classification=dict(newObservation='Source-index context for real degradation',
        fixedFault='Normal authored absence no longer counted as automatic failure until explicit visible recovery',
        existingCoverage='Default Info start, Error file/stderr, stdout isolation, counter suppression and retained primary causes',
        preservedBehavior='All original photographed observation bytes, manual states and algorithm thresholds unchanged',
        pending='Photographed tracking accuracy, Surface/cache, complete maintained regression/final CI and broader 3D route'),
    exclusion='Original third-party videos/JPEGs/annotations, permission HTML, diagnostic captures and per-frame derived payloads excluded. Included blank media and its requests/outputs are independently authored controls.',
    archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
        members={name: dict(bytes=len(data), sha256=sha(data)) for name, data in sorted(members.items())}))
(OUT / 'tracking88-manual-absence-v1.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
destination = WORK / 'engineering/validation/data'
for path in OUT.iterdir():
    assert not (destination / path.name).exists()
    (destination / path.name).write_bytes(path.read_bytes())
print(json.dumps(dict(status=report['status'], bytes=archive.stat().st_size, members=len(members)), indent=2))
