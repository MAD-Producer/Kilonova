"""Reproduce independent image/annotation aggregates, without changing inputs."""
from pathlib import Path
import hashlib
import json
import zipfile
import numpy as np

ROOT = Path('E:/Dev/aem/artifacts/pr-queue')
out = ROOT / 'tracking88-preview-alignment-v1'
rows = []
hashes = []
previous = None
with zipfile.ZipFile(ROOT / 'tracking88-original-frames-v1/phone_img.zip') as images, zipfile.ZipFile(ROOT / 'tracking88-real-planar-acquisition-v1/phone-gt.zip') as labels:
    for index in range(2300):
        name = f'img_{index+200:05d}'
        hashes.append(hashlib.sha256(images.read(name+'.jpg')).hexdigest())
        values = np.array([float(x) for x in labels.read(name+'.txt').decode('ascii').split()]).reshape(2, 4)
        corners = np.column_stack((values[1]-1, values[0]-1))
        if index and hashes[-1] == hashes[-2]:
            difference = np.linalg.norm(corners-previous, axis=1)
            rows.append(dict(index=index, maximumCornerDifference=float(difference.max()),
                             medianCornerDifference=float(np.median(difference))))
        previous = corners
result = dict(identicalOriginalAdjacentPairs=len(rows),
    maximumDifferentCorner=max(row['maximumCornerDifference'] for row in rows),
    over1=sum(row['maximumCornerDifference'] > 1 for row in rows),
    over5=sum(row['maximumCornerDifference'] > 5 for row in rows),
    over15=sum(row['maximumCornerDifference'] > 15 for row in rows),
    at1800=[row for row in rows if 1790 <= row['index'] <= 1830],
    worst=sorted(rows, key=lambda row: row['maximumCornerDifference'], reverse=True)[:8])
assert result == json.loads((out / 'identical-image-annotation-check.json').read_text(encoding='utf-8'))

align = json.loads((out / 'local-per-frame-diagnostic.json').read_text(encoding='utf-8'))
alternate = [row for row in align if row['bestOffset'] != 0]
same = [row for row in alternate if hashes[row['index']] == hashes[row['index']+row['bestOffset']]]
other = [row for row in alternate if hashes[row['index']] != hashes[row['index']+row['bestOffset']]]
ties = dict(nonzeroNearestOffset=len(alternate), identicalNamedImageTies=len(same), otherNearestOffsets=len(other),
    otherMaximumOwnMinusNearestMae=max(row['ownMae']-row['bestMae'] for row in other),
    otherIndices=[row['index'] for row in other],
    limit='Raw nearest-MAE ties are not evidence of an AVI index shift; no relabeling applied.')
assert ties == json.loads((out / 'nearest-tie-summary.json').read_text(encoding='utf-8'))
print('Both original-image aggregate reports independently reproduced')
