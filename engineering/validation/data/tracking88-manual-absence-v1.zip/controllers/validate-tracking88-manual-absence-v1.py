from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-manual-absence-validation-v1'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
source_paths = list((WORK / 'tools/tracking').glob('*.py')) + [WORK / 'tools/test_ci_plate_tracking.py']
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = {path.relative_to(WORK).as_posix(): sha(path) for path in source_paths}
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['TEMP'] = env['TMP'] = str(ROOT / 'target/ci-policy-validation-tmp')
original = (ROOT / '.tools/issue-closure-review/measure-tracking88-photographed-v5.py').read_text(encoding='utf-8')
real = original.replace('photographed-prototype-v5', 'photographed-manual-absence-v1')
(OUT / 'real-controller.py').write_text(real, encoding='utf-8')
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), source=source, steps=[])
runtime = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
steps = [
    ('tools', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_ci_*.py', '-v']),
    ('cv-controls', [sys.executable, 'tools/tracking/test_flow.py', '-v']),
    ('synthetic', [sys.executable, 'tools/tracking/validate_prototype.py', '--ffmpeg', str(runtime / 'ffmpeg.exe'),
                   '--ffprobe', str(runtime / 'ffprobe.exe'), '--output', str(OUT / 'synthetic')]),
    ('full-real', [sys.executable, str(OUT / 'real-controller.py')]),
]


def save():
    (OUT / 'exit.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')


save()
try:
    for phase, command in steps:
        with (OUT / (phase+'.stdout.log')).open('wb') as stdout, (OUT / (phase+'.stderr.log')).open('wb') as stderr:
            child = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
            row = dict(phase=phase, command=command, pid=child.pid)
            report['steps'].append(row)
            save()
            row['exitCode'] = child.wait()
        assert row['exitCode'] == 0, (phase, row['exitCode'])
        assert all(sha(WORK / name) == digest for name, digest in source.items()), 'source changed while validating'
        save()
    current = ROOT / 'artifacts/pr-queue/tracking88-photographed-manual-absence-v1'
    baseline = ROOT / 'artifacts/pr-queue/tracking88-photographed-prototype-v6'
    equality = {}
    for mode in ['no-corrections', 'periodic-manual-200']:
        actual = current / mode / 'tracks.mstrack'
        reference = baseline / mode / 'tracks.mstrack'
        assert actual.read_bytes() == reference.read_bytes(), 'observation behavior changed: '+mode
        equality[mode] = sha(actual)
        assert (current / (mode+'.stdout.log')).read_bytes() == b''
    log = (current / 'periodic-manual-200/tracking.log').read_text(encoding='utf-8')
    assert 'INFO start operation=track_plate' in log
    errors = [line[line.index('ERROR '):] for line in log.splitlines() if 'ERROR ' in line]
    stderr = (current / 'periodic-manual-200.stderr.log').read_text(encoding='utf-8').splitlines()
    assert errors == stderr, 'default real Error file/stderr differs'
    indices = [int(re.search(r'source_index=(\d+)', line).group(1)) for line in errors if 'track=plane ' in line]
    assert not any(1200 <= index < 1400 for index in indices), 'authored lost interval escalated'
    report.update(status='passed_tools_cv_synthetic_and_full_real_observation_equivalence',
        observationSha256=equality, realPlaneErrorSourceIndices=indices,
        realQuality='Unchanged failed photographed quality; only false fault observation corrected. No native/full-workspace acceptance claimed.')
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps({key: report.get(key) for key in ['status', 'steps', 'observationSha256', 'realPlaneErrorSourceIndices', 'failure']}, indent=2), flush=True)
