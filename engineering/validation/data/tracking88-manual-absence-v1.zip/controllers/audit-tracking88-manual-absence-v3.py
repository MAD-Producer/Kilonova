"""Finish the executed v2 gates: correct only its final report lookup path."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-manual-absence-validation-v3'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
V2 = ROOT / 'artifacts/pr-queue/tracking88-manual-absence-validation-v2'
prior = json.loads((V2 / 'exit.json').read_text(encoding='utf-8'))
assert prior['status'] == 'failed' and 'FileNotFoundError' in prior['failure']
assert len(prior['steps']) == 4 and all(row['exitCode'] == 0 for row in prior['steps'])
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert all(sha(WORK / name) == digest for name, digest in prior['source'].items())
current = ROOT / 'artifacts/pr-queue/tracking88-photographed-manual-absence-v2'
baseline = ROOT / 'artifacts/pr-queue/tracking88-photographed-prototype-v6'
equality = {}
for mode in ['no-corrections', 'periodic-manual-200']:
    actual, original = current / mode / 'tracks.mstrack', baseline / mode / 'tracks.mstrack'
    assert actual.read_bytes() == original.read_bytes(), 'observation behavior changed: '+mode
    equality[mode] = sha(actual)
    assert (current / (mode+'.stdout.log')).read_bytes() == b''
log = (current / 'periodic-manual-200/tracking.log').read_text(encoding='utf-8')
assert 'INFO start operation=track_plate' in log
errors = [line[line.index('ERROR '):] for line in log.splitlines() if 'ERROR ' in line]
stderr = (current / 'periodic-manual-200.stderr.log').read_text(encoding='utf-8').splitlines()
assert errors == stderr
indices = [int(re.search(r'source_index=(\d+)', line).group(1)) for line in errors if 'track=plane ' in line]
assert not any(1200 <= index < 1400 for index in indices)
green = ROOT / 'artifacts/pr-queue/tracking88-manual-absence-green-v1/evaluation.json'
assert json.loads(green.read_text(encoding='utf-8'))['status'] == 'accepted_actual_manual_absence_and_failure_reset_controls'
report = dict(status='passed_final_audit_of_executed_v2_gates_without_rerunning', completedUtc=datetime.now(timezone.utc).isoformat(),
    source=prior['source'], executedSteps=prior['steps'], observationSha256=equality,
    realPlaneErrorSourceIndices=indices,
    earlierFailure='V1 lacked existing PyYAML path and new tool inventory. V2 passed all four commands, then used v1 instead of v2 in final observation lookup. Both receipts retained; no product/assertion/threshold repair was made to complete this audit.',
    realQuality='Unchanged failed photographed quality; only false fault observation corrected. No native/full-workspace or final CI acceptance claimed.')
(OUT / 'exit.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
print(json.dumps(report, indent=2))
