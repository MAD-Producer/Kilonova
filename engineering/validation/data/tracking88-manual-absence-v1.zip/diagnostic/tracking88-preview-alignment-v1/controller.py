from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib
import json
import sys
import zipfile

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-preview-alignment-v1'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
sys.path.insert(0, str(WORK / 'tools/tracking'))
import track_plate as tool
import plate_flow as flow
np, cv2 = flow.np, flow.cv2
cv2.setNumThreads(1)
INPUT = ROOT / 'artifacts/pr-queue/tracking88-real-planar-acquisition-v1'
images = ROOT / 'artifacts/pr-queue/tracking88-original-frames-v1/phone_img.zip'
assert tool.digest(images) == '468c86c52d5ac91c9a3b93082853b904240e212b6d4ead5963cefed58e0ea667'
assert tool.digest(INPUT / 'phone.avi') == 'c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(),
    scope='Read-only original JPEG versus overview AVI index diagnosis; no remapping or tracker-quality acceptance',
    jpegArchiveSha256=tool.digest(images), aviSha256=tool.digest(INPUT / 'phone.avi'), rows=[])
run = tool.Run(OUT / 'decode')
run.report['sourceSha256'] = report['aviSha256']
cache = {}


def compact(archive, index):
    if index not in cache:
        raw = archive.read(f'img_{index+200:05d}.jpg')
        image = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_GRAYSCALE)
        assert image is not None and image.shape == (480, 640)
        cache[index] = cv2.resize(image, (160, 120), interpolation=cv2.INTER_AREA).astype(np.float32)
    return cache[index]


try:
    runtime = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
    extent, ticks, rate, pts, metadata = tool.probe(run, runtime / 'ffprobe.exe', INPUT / 'phone.avi', 0)
    assert extent == [640, 480] or tuple(extent) == (640, 480)
    assert len(pts) == 2300
    previous = None
    duplicate = []
    with zipfile.ZipFile(images) as archive:
        for index, raw in enumerate(tool.frames(run, runtime / 'ffmpeg.exe', INPUT / 'phone.avi', 0, extent, len(pts))):
            data = np.frombuffer(raw, np.uint8).reshape(480, 640)
            if previous is not None and np.array_equal(data, previous):
                duplicate.append(index)
            previous = data.copy()
            small = cv2.resize(data, (160, 120), interpolation=cv2.INTER_AREA).astype(np.float32)
            errors = {offset: float(np.mean(np.abs(small-compact(archive, index+offset))))
                      for offset in range(-3, 4) if 0 <= index+offset < 2300}
            ranked = sorted(errors, key=lambda offset: errors[offset])
            report['rows'].append(dict(index=index, bestOffset=ranked[0], ownMae=errors[0],
                bestMae=errors[ranked[0]], runnerUpMae=errors[ranked[1]], errors=errors))
            for key in list(cache):
                if key < index-4:
                    del cache[key]
    rows = report.pop('rows')
    (OUT / 'local-per-frame-diagnostic.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    report.update(status='original_jpeg_preview_alignment_measured', frameCount=len(rows),
        offsetHistogram=dict(Counter(row['bestOffset'] for row in rows)), duplicateAviFrames=len(duplicate),
        allOwnMae=dict(median=float(np.median([row['ownMae'] for row in rows])), maximum=max(row['ownMae'] for row in rows)),
        allBestMae=dict(median=float(np.median([row['bestMae'] for row in rows])), maximum=max(row['bestMae'] for row in rows)),
        checkpoints=[rows[index] for index in [0, 200, 1000, 1600, 1799, 1800, 1801, 1810, 1822, 2299]])
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    report.pop('rows', None)
    raise
finally:
    run.close()
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    (OUT / 'diagnostic.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2), flush=True)
