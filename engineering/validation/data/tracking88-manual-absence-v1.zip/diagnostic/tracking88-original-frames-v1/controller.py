from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import urllib.request
import zipfile

ROOT = Path('E:/Dev/aem')
OUT = ROOT / 'artifacts/pr-queue/tracking88-original-frames-v1'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
URL = 'https://cmp.felk.cvut.cz/cmp/demos/Tracking/linTrack/data/phone/phone_img.zip'
report = dict(status='running', url=URL, startedUtc=datetime.now(timezone.utc).isoformat(),
    scope='Original named JPEG versus preview-AVI alignment diagnosis only; public-use input kept local, not redistributed')
try:
    destination = OUT / 'phone_img.zip'
    digest = hashlib.sha256()
    size = 0
    with urllib.request.urlopen(URL, timeout=45) as response, destination.open('xb') as output:
        report['headers'] = {key: response.headers.get(key) for key in ['Content-Length', 'Last-Modified', 'ETag', 'Content-Type']}
        while True:
            data = response.read(1 << 20)
            if not data:
                break
            size += len(data)
            assert size <= 96 << 20, 'source exceeds declared acquisition budget'
            output.write(data)
            digest.update(data)
    with zipfile.ZipFile(destination) as archive:
        names = sorted(info.filename for info in archive.infolist() if not info.is_dir())
        assert len(names) == 2300, (len(names), names[:3], names[-3:])
        assert all(name.endswith(f'img_{index:05d}.jpg') for index, name in enumerate(names, 200))
        assert all(archive.getinfo(name).file_size < 1 << 20 for name in names)
    report.update(status='original_named_images_acquired_not_yet_qualified', bytes=size,
                  sha256=digest.hexdigest(), count=len(names), first=names[0], last=names[-1])
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    (OUT / 'acquisition.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2), flush=True)
