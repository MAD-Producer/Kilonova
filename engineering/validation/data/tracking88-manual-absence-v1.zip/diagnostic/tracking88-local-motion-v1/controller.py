from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys
import zipfile

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-local-motion-v1'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
sys.path.insert(0, str(WORK / 'tools/tracking'))
import plate_flow as flow
import track_plate as tool
np, cv2 = flow.np, flow.cv2
cv2.setNumThreads(1)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source_hashes = {name: sha(WORK / 'tools/tracking' / name)
                 for name in ['plate_flow.py', 'plate_contract.py', 'track_plate.py']}
INPUT = ROOT / 'artifacts/pr-queue/tracking88-real-planar-acquisition-v1'
request = ROOT / 'artifacts/pr-queue/tracking88-photographed-descriptor-v1/periodic-manual-200.request.json'
assert sha(INPUT / 'phone-gt.zip') == 'd4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
with zipfile.ZipFile(INPUT / 'phone-gt.zip') as bundle:
    corners = []
    for index in range(2300):
        values = np.array([float(x) for x in bundle.read(f'img_{index+200:05d}.txt').decode('ascii').split()]).reshape(2, 4)
        corners.append(np.column_stack((values[1]-1., values[0]-1.)))
truth = [cv2.getPerspectiveTransform(corners[0].astype(np.float32), points.astype(np.float32)) for points in corners]
rows = []
state = dict(index=-1, previous=None, current=None, before=None, local=None)
original_frames = tool.frames


def frames(*args, **kwargs):
    for index, data in enumerate(original_frames(*args, **kwargs)):
        state['index'] = index
        state['previous'] = state['current']
        state['current'] = flow.prepare(np.frombuffer(data, np.uint8).reshape(480, 640))
        yield data


def patch_error(previous, current, warp, points):
    extent = (640, 480)
    aligned = cv2.warpPerspective(current, warp, extent, flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP)
    support = cv2.warpPerspective(np.full(current.shape, 255, np.uint8), warp, extent,
        flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP)
    support = cv2.erode(support, np.ones((23, 23), np.uint8), borderType=cv2.BORDER_CONSTANT, borderValue=0)
    errors = []
    for point in np.rint(points).astype(np.int32):
        x, y = point
        if not (11 <= x < 629 and 11 <= y < 469) or support[y, x] != 255:
            continue
        first = previous[y-10:y+11, x-10:x+11].astype(float)
        second = aligned[y-10:y+11, x-10:x+11].astype(float)
        errors.append(float(np.mean(np.abs(first-second))))
    return dict(patches=len(errors), medianMae=float(np.median(errors)) if errors else None,
                p90Mae=float(np.percentile(errors, 90)) if errors else None)


observe_code, flow_code = flow.Tracker.observe.__code__, flow.flow.__code__


def profile(frame, event, result):
    index = state['index']
    if not 1801 <= index <= 1822:
        return
    if frame.f_code == observe_code:
        local = frame.f_locals
        tracker = local['self']
        if tracker.seed['kind'] != 'plane':
            return
        if event == 'call':
            state['before'] = tracker.points.copy()
            state['local'] = None
        elif event == 'return' and result[0] is not None:
            before = state['before']
            measurement = np.asarray(result[0]['matrix'])
            preceding = truth[index-1] if index == 1801 else np.asarray(rows[-1]['localMatrix'])
            estimated = measurement @ np.linalg.inv(preceding)
            oracle = truth[index] @ np.linalg.inv(truth[index-1])
            moved, valid = state['local']
            ideal = flow.transform(oracle, before)
            row = dict(index=index, sourceFeatures=len(before), localAccepted=int(valid.sum()),
                localMatrix=measurement.tolist(),
                localMedianStep=float(np.median(np.linalg.norm(moved[valid]-before[valid], axis=1))),
                oracleMedianStep=float(np.median(np.linalg.norm(ideal[valid]-before[valid], axis=1))),
                localMedianOracleDifference=float(np.median(np.linalg.norm(moved[valid]-ideal[valid], axis=1))),
                localP90OracleDifference=float(np.percentile(np.linalg.norm(moved[valid]-ideal[valid], axis=1), 90)),
                estimatedPatch=patch_error(state['previous'], state['current'], estimated, before[valid]),
                oraclePatch=patch_error(state['previous'], state['current'], oracle, before[valid]))
            rows.append(row)
    elif frame.f_code == flow_code and event == 'return' and frame.f_back is not None:
        parent = frame.f_back
        if parent.f_code == observe_code and parent.f_locals['self'].seed['kind'] == 'plane' and state['local'] is None:
            state['local'] = (result[0].copy(), result[1].copy())


tool.frames = frames
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), source=source_hashes,
    scope='Read-only actual adjacent-pixel checks against corner-derived incremental projection; no changed tracker decisions or thresholds')
try:
    runtime = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
    sys.setprofile(profile)
    tool.track(INPUT / 'phone.avi', request, OUT / 'tracker', runtime / 'ffmpeg.exe', runtime / 'ffprobe.exe')
    sys.setprofile(None)
    measured = OUT / 'tracker/tracks.mstrack'
    original = ROOT / 'artifacts/pr-queue/tracking88-photographed-prototype-v6/periodic-manual-200/tracks.mstrack'
    assert sha(measured) == sha(original), 'observer changed original output'
    assert len(rows) == 22
    assert all(sha(WORK / 'tools/tracking' / name) == digest for name, digest in source_hashes.items())
    report.update(status='local_motion_observed_without_output_changes', observationSha256=sha(measured),
        first=rows[0], last=rows[-1], aggregate={
            name: dict(minimum=min(row[name] for row in rows), median=float(np.median([row[name] for row in rows])),
                       maximum=max(row[name] for row in rows))
            for name in ['sourceFeatures', 'localAccepted', 'localMedianStep', 'oracleMedianStep',
                         'localMedianOracleDifference', 'localP90OracleDifference']},
        patches={kind: dict(medianOfMedianMae=float(np.median([row[kind]['medianMae'] for row in rows])),
                           minimumPatches=min(row[kind]['patches'] for row in rows))
                 for kind in ['estimatedPatch', 'oraclePatch']},
        limit='Corner-projected feature locations are not independent per-feature truth. Better patch agreement alone cannot certify the plane or explain annotations.')
    # Keep original per-frame observations local; only aggregate diagnostics
    # and two numeric endpoints are included in the portable report.
    for endpoint in ['first', 'last']:
        report[endpoint].pop('localMatrix')
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    sys.setprofile(None)
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    (OUT / 'diagnostic.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2), flush=True)
