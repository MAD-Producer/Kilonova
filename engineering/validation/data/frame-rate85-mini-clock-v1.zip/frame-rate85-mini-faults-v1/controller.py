from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root=Path('E:/Dev/aem')
work=root/'.worktrees/rational-frame-rates85'
out=root/'artifacts/pr-queue/frame-rate85-mini-faults-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
prior=json.loads((root/'artifacts/pr-queue/frame-rate85-mini-clock-v1/exit.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert prior['status']=='passed_scope_acceptance_pending'
assert all(sha(work/name)==digest for name,digest in prior['sources'].items())
env=os.environ.copy()
env.pop('MOTION_LOG',None)
env['LOCALAPPDATA']=str(out/'local-app-data')
Path(env['LOCALAPPDATA']).mkdir()
env['MOTION_MINI_ADAPTIVE_GUARD_ARTIFACTS']=str(out/'adaptive')
env['MOTION_CURVE_MINI_FAULT_ARTIFACTS']=str(out/'channels')
report=dict(status='running',sourceHead=prior['head'],scope='Retain raw default-level failure logs/results/stdout/stderr for the two already passing actual-consumer tests; observation-output retention was missing from the first focused gate. No source changes, GPU work, retries or claim of full desktop acceptance.',startedUtc=datetime.now(timezone.utc).isoformat(),results=[])
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
started=time.monotonic()
for name in ['test-04','test-05']:
    command=next(item['command'] for item in prior['results'] if item['name']==name)
    began=time.monotonic()
    with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
        result=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr)
    report['results'].append(dict(name=name,command=command,exitCode=result.returncode,elapsedSeconds=round(time.monotonic()-began,3)))
    save()
for site in ['adaptive','channels']:
    for process in ['first-process','reset-process']:
        folder=out/site/process
        result=json.loads((folder/'result.json').read_text(encoding='utf-8'))
        log=(folder/'motion-studio.log').read_text(encoding='utf-8')
        stderr=(folder/'stderr.log').read_text(encoding='utf-8')
        stdout=(folder/'stdout.log').read_text(encoding='utf-8')
        assert 'logging initialized level=INFO' in log
        assert 'ERROR' in log and 'ERROR' in stderr
        assert 'count=60 ' in log and 'count=60 ' in stderr
        assert 'panel degradation' not in stdout and 'persistent panel degradation' not in stdout
        if site=='channels':
            assert 'comparison sample is not finite' in log and 'curve.mini.readout_sample' in log
        report.setdefault('retainedProcesses',[]).append(dict(site=site,process=process,result=result))
report['sourceUnchanged']=all(sha(work/name)==digest for name,digest in prior['sources'].items())
report.update(status='passed_output_retention' if all(item['exitCode']==0 for item in report['results']) and report['sourceUnchanged'] else 'failed_original_results_retained',completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-started,3))
save()
print(json.dumps(report),flush=True)
raise SystemExit(0 if report['status']=='passed_output_retention' else 1)
