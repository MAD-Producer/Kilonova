from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/frame-rate85-mini-clock-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
tracked = subprocess.check_output(['git','ls-files','-z','crates','desktop','Cargo.toml','Cargo.lock'],cwd=work).decode().split('\0')
sources = {name:sha(work/name) for name in tracked if name and (work/name).is_file()}
tests = [
    'panels::animation_controls::mapped_tests::mini_actual_readout_projects_local_interval_and_signed_speed_without_rounding',
    'panels::animation_controls::mini::tests::actual_readouts_preserve_zero_and_negative_amplitude_and_duration_in_physical_units',
    'panels::animation_controls::mini::tests::coupled_readout_keeps_each_visible_component_and_source_revision_invalidates_cache',
    'panels::animation_controls::mini::tests::fault_tests::adaptive_frozen_geometry_failure_uses_real_view_and_valid_normalized_readout_guard_stays_quiet',
    'panels::animation_controls::mini::tests::fault_tests::default_failure_channels_cache_suppression_recovery_and_process_reset_use_real_consumers',
    'panels::animation_controls::mini::tests::physical_readout_keeps_component_values_and_units_visible_with_long_layer_names',
    'panels::animation_controls::spatial_tests::actual_mini_readout_and_fit_selection_keep_fractional_spatial_intervals_in_both_directions',
    'panels::graph_ranges::tests::mini::mini_hover_uses_actual_composition_frame_and_percent_but_last_key_stays_normalized',
    'panels::animation_controls::mini::tests::rational_clock_readout_preserves_fractional_per_second_units_and_frame_coordinates',
    'panels::graph_ranges::tests::rational_rate_changes_reset_graph_ranges_but_equivalent_ratios_preserve_navigation',
]
os.environ['LOCALAPPDATA'] = str(out/'local-app-data')
Path(os.environ['LOCALAPPDATA']).mkdir()
report = dict(status='running',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),dirtyFiles=subprocess.check_output(['git','diff','--name-only'],cwd=work).decode().splitlines(),startedUtc=datetime.now(timezone.utc).isoformat(),scope='User-approved five panel files; compile all desktop test targets, then execute exactly eight previously failing CPU/model/readout tests and two new CPU clock/cache tests. No native/worker/GPU test filters are included; not complete desktop or final-main acceptance.',sources=sources,results=[])
assert len(report['dirtyFiles'])==5 and all(name.startswith('desktop/app/src/panels/') for name in report['dirtyFiles'])
save = lambda: (out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
commands=[('compile',['cargo','test','-p','motion-desktop','--no-run','--locked','--offline'])]
commands += [(f'test-{i:02d}',['cargo','test','-p','motion-desktop','--bin','motion-studio','--locked','--offline',test,'--','--exact','--test-threads=1']) for i,test in enumerate(tests,1)]
start=time.monotonic()
save()
try:
    for name,command in commands:
        item=dict(name=name,command=command,status='running',startedUtc=datetime.now(timezone.utc).isoformat())
        report['results'].append(item)
        save()
        began=time.monotonic()
        with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
            child=subprocess.Popen(command,cwd=work,env=os.environ.copy(),stdout=stdout,stderr=stderr)
            item['pid']=child.pid
            save()
            item['exitCode']=child.wait()
        item['elapsedSeconds']=round(time.monotonic()-began,3)
        item['summaries']=re.findall(r'^test result: .+$',(out/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
        item['status']='passed' if item['exitCode']==0 else 'failed'
        if name!='compile' and item['exitCode']==0:
            assert item['summaries'] and re.search(r'1 passed; 0 failed; 0 ignored;',item['summaries'][-1]), 'Exact filter must execute one real test'
        save()
        print(json.dumps(item),flush=True)
        if name=='compile' and item['exitCode']!=0:
            break
    report['sourceUnchanged']=all(sha(work/name)==digest for name,digest in sources.items())
    report['status']='passed_scope_acceptance_pending' if len(report['results'])==11 and all(item['status']=='passed' for item in report['results']) and report['sourceUnchanged'] else 'failed_original_results_retained'
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-start,3))
    save()
    print(json.dumps({k:v for k,v in report.items() if k!='sources'}),flush=True)
raise SystemExit(0 if report['status']=='passed_scope_acceptance_pending' else 1)
