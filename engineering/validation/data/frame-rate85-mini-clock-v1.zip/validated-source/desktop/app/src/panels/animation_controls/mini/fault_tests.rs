use super::*;

#[test]
fn adaptive_frozen_geometry_failure_uses_real_view_and_valid_normalized_readout_guard_stays_quiet()
{
    const CHILD: &str = "MOTION_MINI_ADAPTIVE_GUARD_CHILD";
    const NAME: &str="panels::animation_controls::mini::tests::fault_tests::adaptive_frozen_geometry_failure_uses_real_view_and_valid_normalized_readout_guard_stays_quiet";
    const SITE: &str = "curve.mini.adaptive";
    if let Some(root) = std::env::var_os(CHILD) {
        let root = std::path::PathBuf::from(root);
        let state = scalar_state(0.2, 0.8, 60);
        let original = state.clone();
        let target = KeyframeTarget::Property {
            object: 7,
            property: Property::Opacity,
            axis: None,
        };
        let mut atlas = TextAtlas::from_system(12.).unwrap();
        let _logger = crate::logging::init(root.clone()).unwrap();
        let file = root.join("motion-studio.log");
        let mut draw = |view: &mut View, easing: Easing, hover: bool, frozen: Option<Bounds>| {
            view.draw(
                &mut PaintList::default(),
                &mut atlas,
                Rect::new(0., 0., 500., 130.),
                &state,
                &Input {
                    mouse: if hover { [250., 87.] } else { [-1.; 2] },
                    ..Default::default()
                },
                Locale::En,
                easing,
                target.clone(),
                17,
                Some(77),
                None,
                frozen,
                None,
            );
        };
        let mut easings = vec![];
        for ease in [Ease::Linear, Ease::In, Ease::Out, Ease::InOut, Ease::Hold] {
            easings.push(Easing { ease, curve: None });
        }
        for y in [-8., 8.] {
            for x in [0., 1.] {
                easings.push(Easing {
                    ease: Ease::Linear,
                    curve: Some(Curve {
                        space: CurveSpace::Progress,
                        shape: CurveShape::Quadratic {
                            control: [x, y],
                            start: 0.,
                            end: 1.,
                        },
                    }),
                });
            }
            easings.push(Easing {
                ease: Ease::Linear,
                curve: Some(Curve {
                    space: CurveSpace::Progress,
                    shape: CurveShape::Cubic {
                        control1: [0., y],
                        control2: [1., -y],
                        start: 0.,
                        end: 1.,
                    },
                }),
            });
        }
        for value in [-8., 0.051, 8.] {
            easings.push(Easing {
                ease: Ease::Linear,
                curve: Some(Curve {
                    space: CurveSpace::Velocity,
                    shape: CurveShape::Quadratic {
                        control: [0.5, value],
                        start: value,
                        end: value,
                    },
                }),
            });
        }
        for space in [CurveSpace::Progress, CurveSpace::Velocity] {
            for oscillations in [0.5, 8.] {
                for damping in [0.5, 20.] {
                    easings.push(Easing {
                        ease: Ease::Linear,
                        curve: Some(Curve {
                            space,
                            shape: CurveShape::Elastic {
                                oscillations,
                                damping,
                            },
                        }),
                    });
                }
            }
        }
        // Boundary cases support the source-derived finite-range disposition;
        // they are not represented as an exhaustive proof over all curves.
        let mut normalized_samples = 0;
        for &easing in &easings {
            easing.validate().unwrap();
            for i in 0..=1024 {
                assert!(normalized(easing, f64::from(i) / 1024.)
                    .unwrap()
                    .is_finite());
                normalized_samples += 1;
            }
            let mut view = View::default();
            draw(&mut view, easing, true, None);
            assert!(
                view.shape.as_ref().unwrap().automatic.is_some(),
                "{easing:?}"
            );
            assert!(
                view.last_readout.is_some(),
                "actual normalized hover: {easing:?}"
            );
        }
        crate::logging::flush();
        let healthy = std::fs::read_to_string(&file).unwrap();
        assert_eq!(
            healthy.lines().count(),
            1,
            "valid curves/hover must stay quiet: {healthy}"
        );
        let mut view = View::default();
        let frozen = Bounds {
            x: Range::new(0., 1.).unwrap(),
            y: Range::new(0., 1e-310).unwrap(),
        };
        // A positive finite retained range can still overflow pixels/unit.
        // This is injected presentation state, not ordinary wheel navigation.
        draw(&mut view, Easing::default(), false, Some(frozen));
        assert!(view.shape.as_ref().unwrap().automatic.is_some());
        assert!(view.tessellation.as_ref().unwrap().points.is_none());
        for _ in 0..120 {
            draw(&mut view, Easing::default(), false, Some(frozen));
        }
        crate::logging::flush();
        assert_eq!(
            count(&file, SITE).len(),
            1,
            "unchanged failed geometry is negatively cached"
        );
        for occurrence in 2..=120 {
            draw(&mut view, Easing::default(), false, None);
            assert!(view.tessellation.as_ref().unwrap().points.is_some());
            draw(&mut view, Easing::default(), false, Some(frozen));
            assert!(view.tessellation.as_ref().unwrap().points.is_none());
            if [59, 60, 120].contains(&occurrence) {
                crate::logging::flush();
                assert_eq!(
                    count(&file, SITE).len(),
                    if occurrence < 60 { 1 } else { 2 }
                );
            }
        }
        draw(&mut view, Easing::default(), false, None);
        assert!(view.tessellation.as_ref().unwrap().points.is_some());
        // Malformed easing fails automatic fitting before reaching the hover
        // guard. Do not fabricate an impossible normalized-readout callback.
        let invalid = Easing {
            ease: Ease::Linear,
            curve: Some(Curve {
                space: CurveSpace::Progress,
                shape: CurveShape::Quadratic {
                    control: [0.5, f64::NAN],
                    start: 0.,
                    end: 1.,
                },
            }),
        };
        assert!(invalid.validate().is_err());
        draw(&mut view, invalid, true, None);
        assert!(view.shape.as_ref().unwrap().automatic.is_none());
        assert!(view.last_readout.is_none());
        crate::logging::flush();
        let lines = count(&file, SITE);
        assert_eq!(lines.len(), 2);
        assert!(lines[0].contains("WARN") && lines[0].contains("count=1 "));
        assert!(lines[1].contains("ERROR") && lines[1].contains("count=60 "));
        assert!(lines.iter().all(|line| line.contains("phase=adaptive")
            && line.contains("generation=Some(1)")
            && line.contains("revision=Some(0)")
            && line.contains("object: 7")
            && line.contains("graph sampling geometry is invalid")));
        assert!(count(&file, "curve.mini.normalized_readout").is_empty());
        assert_eq!(count(&file, "curve.mini.fit_all").len(), 1);
        assert_eq!(state, original);
        std::fs::write(root.join("result.json"),serde_json::to_vec_pretty(&serde_json::json!({
            "sites":[SITE],"actualViewConsumer":true,"retainedGeometryNegativeCache":true,
            "firstWarnAndErrorAtLifetime60":true,"suppressedAfter60":true,"recoveryPreservesCounterScope":true,
            "validEasingCases":easings.len(),"finiteNormalizedSamples":normalized_samples,
            "validActualHoverQuiet":true,"malformedEasingRejectedBeforeHover":true,"noEdits":true,
            "guardedBoundary":"curve.mini.normalized_readout: valid finite t is gated to0..1; validated Core Bezier/elastic definitions have finite bounded coefficients/normalization. Boundary cases plus actual hover are evidence, not an exhaustive injected-failure test.",
            "limits":"Frozen range1e-310 is an intentionally degraded presentation snapshot; not claimed reachable through ordinary wheel input. Normalized readout is a defensive guard disposition, not a newly reproduced/fixed defect."
        })).unwrap()).unwrap();
        return;
    }
    let temp = tempfile::tempdir().unwrap();
    let root = std::env::var_os("MOTION_MINI_ADAPTIVE_GUARD_ARTIFACTS")
        .map(std::path::PathBuf::from)
        .unwrap_or_else(|| temp.path().into());
    for name in ["first-process", "reset-process"] {
        let child = root.join(name);
        let result = std::process::Command::new(std::env::current_exe().unwrap())
            .args(["--exact", NAME, "--nocapture", "--test-threads=1"])
            .env_remove("MOTION_LOG")
            .env(CHILD, &child)
            .output()
            .unwrap();
        std::fs::create_dir_all(&child).unwrap();
        std::fs::write(child.join("stdout.log"), &result.stdout).unwrap();
        std::fs::write(child.join("stderr.log"), &result.stderr).unwrap();
        assert!(
            result.status.success(),
            "{}\n{}",
            String::from_utf8_lossy(&result.stdout),
            String::from_utf8_lossy(&result.stderr)
        );
        let stderr = String::from_utf8_lossy(&result.stderr);
        let stdout = String::from_utf8_lossy(&result.stdout);
        assert_eq!(stderr.lines().count(), 1, "{stderr}");
        assert!(stderr.contains(&format!("site={SITE} ")));
        assert!(
            !stderr.contains("WARN")
                && !stdout.contains("panel degradation")
                && !stdout.contains("ERROR")
        );
    }
}

fn read(
    view: &mut View,
    state: &Value,
    target: &KeyframeTarget,
    speed: bool,
) -> (String, Vec<String>) {
    view.actual_readout(
        state,
        Locale::En,
        target,
        17,
        Some(77),
        0.5,
        speed,
        "t=0.5".into(),
        vec![],
    )
}
fn count(path: &std::path::Path, site: &str) -> Vec<String> {
    std::fs::read_to_string(path)
        .unwrap()
        .lines()
        .filter(|line| line.contains(&format!("site={site} ")))
        .map(str::to_owned)
        .collect()
}

#[test]
fn default_failure_channels_cache_suppression_recovery_and_process_reset_use_real_consumers() {
    const CHILD: &str = "MOTION_CURVE_MINI_FAULT_CHILD";
    const NAME: &str = "panels::animation_controls::mini::tests::fault_tests::default_failure_channels_cache_suppression_recovery_and_process_reset_use_real_consumers";
    const SITES: [&str; 4] = [
        "curve.mini.fit_all",
        "curve.mini.readout_load",
        "curve.mini.readout_fps",
        "curve.mini.readout_sample",
    ];
    if let Some(root) = std::env::var_os(CHILD) {
        let root = std::path::PathBuf::from(root);
        let good = scalar_state(0.2, 0.8, 60);
        let original = good.clone();
        let target = KeyframeTarget::Property {
            object: 7,
            property: Property::Opacity,
            axis: None,
        };
        let mut atlas = TextAtlas::from_system(12.).unwrap();
        let _logger = crate::logging::init(root.clone()).unwrap();
        let file = root.join("motion-studio.log");
        let mut view = View::default();
        for _ in 0..120 {
            assert!(read(&mut view, &good, &target, false).0.contains("47.00 f"));
        }
        let missing = KeyframeTarget::Property {
            object: 999,
            property: Property::Opacity,
            axis: None,
        };
        assert!(read(&mut view, &good, &missing, false).1[0].contains("unavailable"));
        assert!(view.readout.as_ref().unwrap().data.is_err());
        // Missing channels and a missing outgoing interval are normal states.
        let (_, lines) = view.actual_readout(
            &good,
            Locale::En,
            &target,
            77,
            None,
            0.5,
            false,
            "t=0.5".into(),
            vec![],
        );
        assert!(lines.is_empty());
        crate::logging::flush();
        let healthy_log = std::fs::read_to_string(&file).unwrap();
        assert_eq!(
            healthy_log.lines().count(),
            1,
            "healthy branches must add no records beyond logger initialization: {healthy_log}"
        );
        assert!(
            healthy_log.contains("logging initialized level=INFO")
                && !healthy_log.contains("panel degradation")
        );

        let mut malformed = good.clone();
        malformed["revision"] = 1.into();
        malformed["project"]["layers"][0]["transform"]["opacity"]["keys"][0]["frame"] =
            "not-a-frame".into();
        for _ in 0..120 {
            assert!(read(&mut view, &malformed, &target, false).1[0].contains("unavailable"));
        }
        assert_eq!(
            count(&file, SITES[1]).len(),
            1,
            "same failed source must stay negatively cached"
        );
        for revision in 2..=60 {
            assert!(read(&mut view, &good, &target, false).0.contains("47.00 f"));
            malformed["revision"] = revision.into();
            assert!(read(&mut view, &malformed, &target, false).1[0].contains("unavailable"));
        }
        assert_eq!(count(&file, SITES[1]).len(), 2);
        for revision in 61..=120 {
            malformed["revision"] = revision.into();
            assert!(read(&mut view, &malformed, &target, false).1[0].contains("unavailable"));
        }
        assert!(read(&mut view, &good, &target, false).0.contains("47.00 f"));
        malformed["revision"] = 121.into();
        read(&mut view, &malformed, &target, false);
        assert_eq!(
            count(&file, SITES[1]).len(),
            2,
            "documented process-lifetime counters do not reset on recovery"
        );

        let mut bad_fps = good.clone();
        bad_fps["project"]["fps"] = 0.into();
        for _ in 0..120 {
            assert!(read(&mut view, &bad_fps, &target, true).1[0].contains("unavailable"));
            assert!(read(&mut view, &good, &target, true).1[0].ends_with("%/s"));
        }
        // The strict project clock rejects malformed rates before sampling.
        // Exercise the distinct sample overflow boundary with a valid clock
        // and finite authored values whose percent conversion overflows f32.
        let mut overflow = good.clone();
        overflow["revision"] = 122.into();
        overflow["project"]["layers"][0]["transform"]["opacity"]["keys"][0]["value"] =
            serde_json::json!(1e37);
        overflow["project"]["layers"][0]["transform"]["opacity"]["keys"][1]["value"] =
            serde_json::json!(3e38);
        for _ in 0..120 {
            assert!(read(&mut view, &overflow, &target, true).1[0].contains("unavailable"));
            assert!(read(&mut view, &good, &target, true).0.contains("47.00 f"));
        }

        let mut geometry = View::default();
        let mut draw = |view: &mut View, width: f32, height: f32| {
            view.draw(
                &mut PaintList::default(),
                &mut atlas,
                Rect::new(0., 0., width, height),
                &good,
                &Input::default(),
                Locale::En,
                Easing::default(),
                target.clone(),
                17,
                Some(77),
                None,
                None,
                None,
            );
        };
        draw(&mut geometry, 500., 0.);
        assert!(geometry.shape.as_ref().unwrap().automatic.is_none());
        for _ in 0..120 {
            draw(&mut geometry, 500., 0.);
        }
        assert_eq!(
            count(&file, SITES[0]).len(),
            1,
            "failed geometry is cached for an unchanged view"
        );
        for i in 1..120 {
            draw(&mut geometry, 500., 130.);
            assert!(geometry.shape.as_ref().unwrap().automatic.is_some());
            draw(&mut geometry, 500. + i as f32, 0.);
            assert!(geometry.shape.as_ref().unwrap().automatic.is_none());
        }
        draw(&mut geometry, 500., 130.);
        assert!(geometry.shape.as_ref().unwrap().automatic.is_some());
        assert!(geometry.tessellation.as_ref().unwrap().points.is_some());
        for site in SITES {
            let lines = count(&file, site);
            assert_eq!(lines.len(), 2, "{site}: {lines:?}");
            assert!(lines[0].contains("WARN") && lines[0].contains("count=1 "));
            assert!(lines[1].contains("ERROR") && lines[1].contains("count=60 "));
            assert!(lines.iter().all(|line| line.contains("object: 7")
                && line.contains("generation=Some(1)")
                && line.contains("revision=Some(")
                && line.contains("phase=")));
        }
        let text = std::fs::read_to_string(&file).unwrap();
        for cause in [
            "not-a-frame",
            "composition fps unavailable",
            "comparison sample is not finite",
            "graph sampling geometry is invalid",
        ] {
            assert!(text.contains(cause), "missing original cause: {cause}");
        }
        assert!(
            !text.contains("site=curve.mini.adaptive ")
                && !text.contains("site=curve.mini.normalized_readout ")
        );
        assert_eq!(good, original);
        std::fs::write(root.join("result.json"),serde_json::to_vec_pretty(&serde_json::json!({
            "sites":SITES,"sameSourceFailuresCached":true,"firstWarnAndErrorAtLifetime60":true,
            "suppressedAfter60":true,"healthyRecoveryPreservesCounterScope":true,"actualConsumers":true,
            "normalMissingAndNoIntervalQuiet":true,"originalCausesRetained":true,"sourceUnchanged":true,
            "limits":"Invalid geometry is a presentation boundary; Malformed fps and overflowing percent samples are model-provider faults, not legal stored projects. Adaptive/normalized_readout defensive branches and other surfaces remain unverified here."
        })).unwrap()).unwrap();
        return;
    }
    let temp = tempfile::tempdir().unwrap();
    let root = std::env::var_os("MOTION_CURVE_MINI_FAULT_ARTIFACTS")
        .map(std::path::PathBuf::from)
        .unwrap_or_else(|| temp.path().into());
    std::fs::create_dir_all(&root).unwrap();
    for run in ["first-process", "reset-process"] {
        let child_root = root.join(run);
        let result = std::process::Command::new(std::env::current_exe().unwrap())
            .args(["--exact", NAME, "--nocapture", "--test-threads=1"])
            .env_remove("MOTION_LOG")
            .env(CHILD, &child_root)
            .output()
            .unwrap();
        std::fs::create_dir_all(&child_root).unwrap();
        std::fs::write(child_root.join("stdout.log"), &result.stdout).unwrap();
        std::fs::write(child_root.join("stderr.log"), &result.stderr).unwrap();
        assert!(
            result.status.success(),
            "{}\n{}",
            String::from_utf8_lossy(&result.stdout),
            String::from_utf8_lossy(&result.stderr)
        );
        let stderr = String::from_utf8_lossy(&result.stderr);
        let stdout = String::from_utf8_lossy(&result.stdout);
        for site in SITES {
            assert_eq!(
                stderr
                    .lines()
                    .filter(|line| line.contains(&format!("site={site} ")))
                    .count(),
                1,
                "{stderr}"
            );
        }
        assert_eq!(
            stderr.lines().count(),
            4,
            "only Error records belong to stderr"
        );
        assert!(
            !stderr.contains("WARN")
                && !stdout.contains("panel degradation")
                && !stdout.contains("ERROR")
        );
    }
}
