from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('E:/Dev/aem');work=root/'.worktrees/text-format-controls';out=root/'.tools/text-format-controls';folder=out/'after-01';folder.mkdir(exist_ok=False)
def freeze():
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=work,text=True).splitlines()
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p.startswith(('crates/','desktop/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']}
sources=freeze();record=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),sources=sources,runs=[],active=None)
def save():
    record['source_unchanged']=freeze()==sources;(folder/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8')
for name,extra in [('new-regressions',['--lib','text::format_controls_tests::']),('full-ui',['--all-targets'])]:
    record['active']=name;save();env=os.environ.copy();env.pop('MOTION_LOG',None);env['MOTION_UI_SEQUENCE_CONTROL_ARTIFACTS']=str(folder/(name+'-observations'))
    command=['cargo','test','-p','motion-ui',*extra,'--locked','--offline','-j1','--','--nocapture','--test-threads=1'];began=time.monotonic()
    print('Started fixed '+name,flush=True)
    with (folder/(name+'.log')).open('w',encoding='utf8') as sink:child=subprocess.run(command,cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT,timeout=1800)
    text=(folder/(name+'.log')).read_text(encoding='utf8');summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
    item=dict(name=name,command=command,exit_code=child.returncode,summary=summaries,seconds=round(time.monotonic()-began,2));record['runs'].append(item);record['active']=None;save();print(json.dumps(item),flush=True)
    assert child.returncode==0 and summaries and all(s[0]=='ok' and s[2]=='0' for s in summaries) and record['source_unchanged']
record['scope']='Three actual regressions and the full default-feature UI suite at one frozen production change. Per-target counts retained; phases overlap and must not be added as distinct cases. Default Info library log facade with a file/Error-stderr test sink; desktop sink unchanged, not revalidated by this helper.';save()
