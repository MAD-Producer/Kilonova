from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('E:/Dev/aem');work=root/'.worktrees/text-format-controls';out=root/'.tools/text-format-controls';out.mkdir(exist_ok=True)
folder=out/'before-01';folder.mkdir(exist_ok=False)
def freeze():
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=work,text=True).splitlines()
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p.startswith(('crates/','desktop/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']}
sources=freeze();reference=json.loads((root/'.tools/curve-view-ranges/performance-current-07/receipt.json').read_text())
old=reference['sources'];changed=[p for p,h in sources.items() if (p.startswith(('crates/','desktop/ui/')) or p in ['Cargo.toml','Cargo.lock']) and old.get(p)!=h]
roots={'desktop/ui/src/lib.rs'}
if any(p in ['Cargo.toml','Cargo.lock'] for p in changed):roots.update(p for p in sources if p.endswith('/src/lib.rs'))
else:
    for p in changed:
        if p.startswith('crates/'):roots.add('/'.join(p.split('/')[:2])+'/src/lib.rs')
for p in roots:(work/p).touch()
env=os.environ.copy();env.pop('MOTION_LOG',None);env['MOTION_UI_SEQUENCE_CONTROL_ARTIFACTS']=str(folder/'observations')
command=['cargo','test','-p','motion-ui','--lib','text::format_controls_tests::','--locked','--offline','-j1','--','--nocapture','--test-threads=1'];began=time.monotonic()
print('Running new public text/observation regressions against unchanged production glyph behavior.',flush=True)
with (folder/'tests.log').open('w',encoding='utf8') as sink:r=subprocess.run(command,cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT)
record=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),command=command,exit_code=r.returncode,source_unchanged=freeze()==sources,sources=sources,seconds=round(time.monotonic()-began,2),forced_roots=sorted(roots),changed_shared_sources=changed,
    scope='Negative regression: three new tests, original production glyph code except test-module registration. Actual result, including compilation/harness errors, must be inspected; nonzero alone is not a reproduced defect.')
(folder/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in record.items() if k not in ['sources','changed_shared_sources']}),flush=True)
