import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT/'.worktrees/prerender-disk-cache'
OUT = ROOT/'artifacts/pr-queue/prerender-input-completion-v5'
BASE = '652fbe6525f5813a85620fe0d5d2ad4eef5f9bfb'
PRODUCTION = WORK/'desktop/app/src/engine/prerender.rs'
NAME = 'engine::prerender::tests::input_completion::native_completed_result_waits_for_input_acknowledgment_before_upload'

def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()
def sources():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: hashlib.sha256((WORK/name).read_bytes()).hexdigest() for name in names
            if name and name.endswith(('.rs','.toml','.lock','.wgsl','.json','.yml','.yaml','.py','.md'))}

assert git('rev-parse','HEAD') == BASE
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
original = PRODUCTION.read_bytes()
source = sources()
report = dict(status='queued', controllerPid=os.getpid(), base=BASE, source=source, steps=[], startedUtc=now(),
    limits='Actual completed native result, input hold, submission exclusion and pixel recovery. Original combined-v8 full regression and strict input P95 remain FAILED; this gate first executes changed native input-completion controls, not issue acceptance. No existing assertions changed.')

def save():
    pending = OUT/'exit.next.json'
    pending.write_text(json.dumps(report,indent=2),encoding='utf-8')
    os.replace(pending,OUT/'exit.json')

env = os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT/'owned-profile'), PYTHONPATH=str(ROOT/'.tools/build-validation-python'))
Path(env['LOCALAPPDATA']).mkdir()

def step(name,args,expected=None,negative=False):
    test_env=env.copy()
    test_env['MOTION_PRERENDER_INPUT_COMPLETION_REPORT']=str(OUT/f'{name}.report.json')
    report['activeStep']=dict(name=name,command=args,startedUtc=now());save()
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(args,cwd=WORK,env=test_env,stdout=stdout,stderr=stderr)
        report['activeStep']['pid']=child.pid;save();code=child.wait()
    report['activeStep'].update(exitCode=code,completedUtc=now());save()
    output=(OUT/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace')
    errors=(OUT/f'{name}.stderr.log').read_text(encoding='utf-8',errors='replace')
    counts=re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',output)
    if negative:
        passed=code!=0 and counts==[('0','1','0')] and 'pending native input must reject completed optional pixels before upload' in output+errors
    else:
        passed=code==0 and (expected is None or counts==[(str(expected),'0','0')])
        if counts:passed=passed and all(int(c[1])==0 for c in counts)
    row=dict(name=name,command=args,exitCode=code,counts=counts,passed=passed,negativeControl=negative,
        startedUtc=report['activeStep']['startedUtc'],completedUtc=report['activeStep']['completedUtc'])
    report['steps'].append(row);save();print(json.dumps(row),flush=True)
    assert passed,f'{name} failed; inspect actual exit and logs before any later build'
    report.pop('activeStep',None);save()

try:
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
    kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.WaitForSingleObject.restype=wintypes.DWORD
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    for pid in [35200,19860,34476,4444]:
        prior_handle=kernel.OpenProcess(0x100000,False,pid)
        if prior_handle:
            try: assert kernel.WaitForSingleObject(prior_handle,0)==0,f'exact preceding owner still live: {pid}'
            finally: kernel.CloseHandle(prior_handle)
    report['admission']='Original v4 fixture failure inspected: waiting observation precedes mailbox send. New fixture waits bounded real acknowledgments, preserving every original assertion and all production criteria.';save()
    diagnostic=json.loads((ROOT/'artifacts/pr-queue/prerender-mcp-stack-diagnostic-v1/debugger/report.json').read_text(encoding='utf-8'))
    assert 'exitCode' in diagnostic and diagnostic.get('status')=='diagnostic_application_exit_observed_not_acceptance','inspect actual application diagnostic driver failure first'
    report['originalMcpDiagnostic']={key:diagnostic.get(key) for key in ['status','exitCode','exceptions']};save()
    previous=json.loads((ROOT/'artifacts/pr-queue/prerender-idle-upload-v5/exit.json').read_text(encoding='utf-8'))
    assert previous.get('completedUtc'),'idle owner ended without terminal receipt'
    report['idleTerminal']={key:previous.get(key) for key in ['status','completedUtc']};save()
    assert previous['status']=='accepted_idle_upload_components_not_performance_acceptance','inspect preceding actual failure first'
    report['retainedOriginalFailure']=previous.get('retainedOriginalFailure')
    assert report['retainedOriginalFailure'],'original full-regression failure disposition must remain visible'
    save()
    assert git('rev-parse','HEAD')==BASE and sources()==source
    report.update(status='running',releasedUtc=now());save()
    for name in ['crates/motion-model/src/lib.rs','crates/motion-core/src/lib.rs','crates/motion-render/src/lib.rs',
                 'crates/motion-host/src/lib.rs','crates/motion-desktop-media/src/lib.rs','desktop/app/src/main.rs']:
        os.utime(WORK/name,None)
    negative=subprocess.check_output(['git','show','HEAD:desktop/app/src/engine/prerender.rs'],cwd=WORK)
    assert negative!=original
    report['negativeProductionSha256']=hashlib.sha256(negative).hexdigest();save()
    desktop=['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--bin','motion-studio']
    PRODUCTION.write_bytes(negative)
    try:
        step('original-input-completion-negative',desktop+[NAME,'--','--ignored','--exact','--nocapture','--test-threads=1'],negative=True)
    finally:
        PRODUCTION.write_bytes(original)
        assert PRODUCTION.read_bytes()==original
    assert sources()==source
    step('input-completion-control',desktop+[NAME,'--','--ignored','--exact','--nocapture','--test-threads=1'],expected=1)
    for name,selector in [
        ('native-input-routing','engine::prerender::tests::input_priority::native_input_preempts_before_action_generation_and_waits_for_its_present'),
        ('native-foreground-refresh','engine::prerender::tests::foreground_refresh::native_edit_waits_for_foreground_refresh_before_warming_its_revision'),
        ('native-playback','engine::prerender::tests::playback::native_playback_ignores_idle_delay_and_presents_a_warm_exact_frame')]:
        step(name,desktop+[selector,'--','--ignored','--exact','--test-threads=1'],expected=1)
    step('provenance',[sys.executable,'tools/validate_provenance.py'])
    step('tool-inventory',[sys.executable,'tools/validation_inventory.py'])
    step('whitespace',['git','diff','--check'])
    assert sources()==source
    report.update(status='accepted_native_input_completion_boundary_not_p95_acceptance',completedUtc=now());save()
except BaseException as error:
    report.update(status='failed',completedUtc=now(),failure=repr(error));save();raise
