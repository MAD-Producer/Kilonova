import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT/'.worktrees/prerender-disk-cache'
OUT = ROOT/'artifacts/pr-queue/prerender-late-input-native-v5'
BASE = '652fbe6525f5813a85620fe0d5d2ad4eef5f9bfb'
PRODUCTION = WORK/'desktop/app/src/engine/prerender.rs'
NAME = 'engine::prerender::tests::input_completion::native_late_input_rejects_completed_result_after_demand_reconciliation'

def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()
def sources():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: hashlib.sha256((WORK/name).read_bytes()).hexdigest() for name in names
            if name and name.endswith(('.rs','.toml','.lock','.wgsl','.json','.yml','.yaml','.py','.md'))}

assert git('rev-parse','HEAD') == BASE
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
original = PRODUCTION.read_bytes()
source = sources()
report = dict(status='queued', controllerPid=os.getpid(), base=BASE, source=source, steps=[], startedUtc=now(),
    limits='Actual completed native result, input hold, submission exclusion and pixel recovery. Original combined-v8 full regression and strict input P95 remain FAILED. A separate late-input admission marker is tested; ordinary completed-token behavior and original assertions remain unchanged. No existing assertions changed.')

def save():
    pending = OUT/'exit.next.json'
    pending.write_text(json.dumps(report,indent=2),encoding='utf-8')
    os.replace(pending,OUT/'exit.json')

env = os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT/'owned-profile'), PYTHONPATH=str(ROOT/'.tools/build-validation-python'))
Path(env['LOCALAPPDATA']).mkdir()

def step(name,args,expected=None,negative=False):
    test_env=env.copy()
    test_env['MOTION_PRERENDER_INPUT_COMPLETION_REPORT']=str(OUT/f'{name}.report.json')
    report['activeStep']=dict(name=name,command=args,startedUtc=now());save()
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(args,cwd=WORK,env=test_env,stdout=stdout,stderr=stderr)
        report['activeStep']['pid']=child.pid;save();code=child.wait()
    report['activeStep'].update(exitCode=code,completedUtc=now());save()
    output=(OUT/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace')
    errors=(OUT/f'{name}.stderr.log').read_text(encoding='utf-8',errors='replace')
    counts=re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',output)
    if negative:
        passed=code!=0 and counts==[('0','1','0')] and 'late input must reject completed optional pixels after demand reconciliation' in output+errors
    else:
        passed=code==0 and (expected is None or counts==[(str(expected),'0','0')])
        if counts:passed=passed and all(int(c[1])==0 for c in counts) and any(int(c[0])>0 for c in counts)
    row=dict(name=name,command=args,exitCode=code,counts=counts,passed=passed,negativeControl=negative,
        startedUtc=report['activeStep']['startedUtc'],completedUtc=report['activeStep']['completedUtc'])
    report['steps'].append(row);save();print(json.dumps(row),flush=True)
    assert passed,f'{name} failed; inspect actual exit and logs before any later build'
    report.pop('activeStep',None);save()

PROPOSAL = ROOT/'artifacts/pr-queue/prerender-late-input-proposal-v5'
metadata = json.loads((PROPOSAL/'proposal.json').read_text(encoding='utf-8'))
files = list(metadata['source'])
baseline = {name: (WORK/name).read_bytes() for name in files}
candidate = {name: (PROPOSAL/'proposed'/name).read_bytes() for name in files}
assert all(hashlib.sha256(data).hexdigest() == metadata['source'][name] for name,data in baseline.items())
mutated = False
try:
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
    kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.WaitForSingleObject.restype=wintypes.DWORD
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    for pid in [14748,2176]:
        handle=kernel.OpenProcess(0x100000,False,pid)
        if handle:
            try: assert kernel.WaitForSingleObject(handle,0)==0, 'previous validator still active'
            finally: kernel.CloseHandle(handle)
    report['parent']=dict(pid=14748,receipt='prerender-input-completion-v5',verifiedTerminalBeforeSnapshot=True);save()
    previous=json.loads((ROOT/'artifacts/pr-queue/prerender-input-completion-v5/exit.json').read_text(encoding='utf-8'))
    assert previous.get('completedUtc'),'preceding owner ended without terminal receipt'
    report['parent']['terminal']={key:previous.get(key) for key in ['status','completedUtc']};save()
    assert previous['status']=='accepted_native_input_completion_boundary_not_p95_acceptance','inspect actual preceding failure before source mutation'
    report['retainedOriginalFailure']=previous.get('retainedOriginalFailure')
    assert report['retainedOriginalFailure']
    assert git('rev-parse','HEAD')==BASE and sources()==source
    report['predecessorSnapshotDisposition']='v4 captured prerender.rs during the predecessor negative control; only that file differed after the predecessor restored accepted production. v5 captures the stable accepted source before its first native execution.'
    report.update(status='running_first_native_controls_not_issue_acceptance',releasedUtc=now());save()
    for name in ['crates/motion-model/src/lib.rs','crates/motion-core/src/lib.rs','crates/motion-render/src/lib.rs',
                 'crates/motion-host/src/lib.rs','crates/motion-desktop-media/src/lib.rs','desktop/app/src/main.rs']:
        os.utime(WORK/name,None)
    report['proposalPatchSha256']=metadata['patchSha256']
    testfile='desktop/app/src/engine/prerender/tests/input_completion.rs'
    (WORK/testfile).write_bytes(candidate[testfile]);mutated=True
    desktop=['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--bin','motion-studio']
    step('original-late-input-negative',desktop+[NAME,'--','--ignored','--exact','--nocapture','--test-threads=1'],negative=True)
    for name in files:
        (WORK/name).write_bytes(candidate[name])
    report['candidateSource']=sources();save()
    step('late-input-positive',desktop+[NAME,'--','--ignored','--exact','--nocapture','--test-threads=1'],expected=1)
    step('original-completed-input-control',desktop+['engine::prerender::tests::input_completion::native_completed_result_waits_for_input_acknowledgment_before_upload','--','--ignored','--exact','--nocapture','--test-threads=1'],expected=1)
    step('signals-regression',desktop+['engine::prerender::signals::tests::','--','--test-threads=1'])
    step('native-input-routing',desktop+['engine::prerender::tests::input_priority::native_input_preempts_before_action_generation_and_waits_for_its_present','--','--ignored','--exact','--test-threads=1'],expected=1)
    step('native-playback',desktop+['engine::prerender::tests::playback::native_playback_ignores_idle_delay_and_presents_a_warm_exact_frame','--','--ignored','--exact','--test-threads=1'],expected=1)
    media=['cargo','test','-p','motion-desktop-media','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--lib']
    step('native-worker-yield-controls',media+['movie::prerender::worker::tests::yielding::','--','--include-ignored','--test-threads=1'],expected=5)
    step('coordinator-regression',media+['movie::prerender::coordinator::','--','--test-threads=1'])
    step('provenance',[sys.executable,'tools/validate_provenance.py'])
    step('tool-inventory',[sys.executable,'tools/validation_inventory.py'])
    step('whitespace',['git','diff','--check'])
    assert sources()==report['candidateSource']
    report.update(status='accepted_native_late_input_components_not_p95_acceptance',completedUtc=now());save()
except BaseException as error:
    if mutated:
        for name,data in baseline.items():
            (WORK/name).write_bytes(data)
        report['restoredOriginalSourceAfterFailure']=all((WORK/n).read_bytes()==b for n,b in baseline.items())
    report.update(status='failed',completedUtc=now(),failure=repr(error));save();raise
