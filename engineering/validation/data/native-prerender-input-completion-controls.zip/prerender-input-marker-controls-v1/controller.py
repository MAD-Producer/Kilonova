"""Compile actual proposed token methods without starting Cargo or a GPU.

The fixture sets completed=true; these controls do not render native pixels,
execute Signals routing, or qualify original whole-application P95.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT/'.worktrees/prerender-disk-cache'
PROPOSAL = ROOT/'artifacts/pr-queue/prerender-late-input-proposal-v4'
OUT = ROOT/'artifacts/pr-queue/prerender-input-marker-controls-v1'
OUT.mkdir(exist_ok=False)
movie_path = WORK/'crates/motion-desktop-media/src/movie.rs'
yield_path = PROPOSAL/'proposed/crates/motion-desktop-media/src/movie/prerender/worker.rs'
input_path = WORK/'desktop/app/src/engine/prerender/input.rs'
raw = {str(p): p.read_bytes() for p in [movie_path, yield_path, input_path]}
movie, yielding, inputs = [data.decode('utf-8').replace('\r\n','\n') for data in raw.values()]
export = movie[movie.index('#[derive(Clone, Default)]\npub struct ExportControl'):movie.index('#[derive(Clone, Serialize)]\npub struct MovieResult')]
yielding = yielding[yielding.index('#[derive(Clone, Default)]\npub struct YieldControl'):yielding.index('pub struct Completion')]
inputs = inputs.split('#[cfg(test)]')[0]
tests = r'''
#[test]
fn ordinary_present_preserves_completed_control_and_admission() {
    let token = YieldControl::default();
    token.completed.store(true, Ordering::Release);
    assert!(!token.preempt());
    assert!(token.control().check().is_ok());
    assert!(!token.input_preempted());
}
#[test]
fn input_after_clear_snapshot_marks_only_admission_of_completed_pixels() {
    let mut input = InputGate::default();
    let token = YieldControl::default();
    token.completed.store(true, Ordering::Release);
    let snapshot = input.pending();
    assert!(!snapshot);
    input.observe(InputActivity::Pulse).unwrap();
    assert!(!token.preempt_for_input());
    assert!(input.pending());
    assert!(token.input_preempted());
    // Preserve the original native fixture's control contract.
    assert!(token.control().check().is_ok());
}
#[test]
fn unfinished_input_yields_work_and_marks_admission() {
    let token = YieldControl::default();
    assert!(token.preempt_for_input());
    assert!(token.input_preempted());
    assert_eq!(token.control().check().unwrap_err(), "movie export cancelled");
    assert!(token.control.yielded_only());
}
#[test]
fn clones_share_the_same_input_admission_marker() {
    let token = YieldControl::default();
    let clone = token.clone();
    std::thread::spawn(move || { clone.preempt_for_input(); }).join().unwrap();
    assert!(token.input_preempted());
}
#[test]
fn_other_jobs_are_not_marked_PLACEHOLDER
#[test]
fn strong_cancel_still_wins_over_marked_cooperative_yield() {
    let token = YieldControl::default();
    token.preempt_for_input();
    assert!(token.control().cancel());
    assert!(token.input_preempted());
    assert!(token.control().check().is_err());
    assert!(!token.control.yielded_only());
}
#[test]
fn input_marker_does_not_reuse_a_single_use_claim() {
    let token = YieldControl::default();
    token.claim().unwrap();
    token.preempt_for_input();
    assert_eq!(token.claim().unwrap_err(), "prerender yield token already submitted");
}
'''.replace('fn_other_jobs_are_not_marked_PLACEHOLDER', '''fn other_jobs_are_not_marked() {
    let first = YieldControl::default();
    let second = YieldControl::default();
    first.preempt_for_input();
    assert!(first.input_preempted());
    assert!(!second.input_preempted());
    assert!(second.control().check().is_ok());
}''')
prelude = 'use std::sync::{Arc, Mutex, atomic::{AtomicBool, AtomicU64, Ordering}};\ntype Result<T, E = String> = std::result::Result<T, E>;\n'
source = OUT/'controls.rs'
source.write_bytes(('mod protocol {\n'+inputs+prelude+export+yielding+tests+'\n}\n').encode())
env = os.environ.copy()
env['TEMP'] = env['TMP'] = str(ROOT/'target/ci-policy-validation-tmp')
compiled = subprocess.run(['rustc','--edition=2024','--test',str(source),'-o',str(OUT/'controls.exe')],env=env,capture_output=True)
(OUT/'compile.stderr.log').write_bytes(compiled.stderr)
assert compiled.returncode == 0, compiled.stderr.decode(errors='replace')
result = subprocess.run([str(OUT/'controls.exe'),'--nocapture','--test-threads=1'],env=env,capture_output=True)
(OUT/'stdout.log').write_bytes(result.stdout)
(OUT/'stderr.log').write_bytes(result.stderr)
assert result.returncode == 0 and b'7 passed; 0 failed; 0 ignored;' in result.stdout
assert all(Path(p).read_bytes()==data for p,data in raw.items())
report = dict(status='accepted_seven_extracted_candidate_token_controls_not_native_acceptance',
    completedUtc=datetime.now(timezone.utc).isoformat(),passed=7,failed=0,ignored=0,
    source={p:hashlib.sha256(data).hexdigest() for p,data in raw.items()},
    limits='Actual proposed YieldControl and production ExportControl/InputGate methods only. Fixture sets completed; Signals routing, Coordinator upload, native recovery and original strict P95 are not executed. No product edits or Cargo/GPU work. Earlier original protocol negative and historical crash failures remain retained.')
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(report))
