mod protocol {
//! Bounded pointer state; only a frame queued after the latest input may release it.
#[derive(Clone, Copy)]
pub(crate) enum InputActivity {
    Button { index: u8, pressed: bool },
    Pulse,
    Cancel,
}

#[derive(Default)]
pub(super) struct InputGate {
    buttons: u8,
    epoch: u64,
    awaiting_present: bool,
}
impl InputGate {
    pub fn observe(&mut self, activity: InputActivity) -> Result<bool, String> {
        let buttons = match activity {
            InputActivity::Button { index, pressed } => {
                if index >= 3 {
                    return Err("prerender input button outside supported range".into());
                }
                let bit = 1 << index;
                if pressed {
                    self.buttons | bit
                } else {
                    self.buttons & !bit
                }
            }
            InputActivity::Cancel => 0,
            InputActivity::Pulse => self.buttons,
        };
        if buttons == self.buttons && !matches!(activity, InputActivity::Pulse) {
            return Ok(false);
        }
        let epoch = self
            .epoch
            .checked_add(1)
            .ok_or("prerender input epoch exhausted")?;
        self.buttons = buttons;
        self.epoch = epoch;
        self.awaiting_present = true;
        Ok(true)
    }
    pub fn token(&self) -> u64 {
        self.epoch
    }
    pub fn pending(&self) -> bool {
        self.buttons != 0 || self.awaiting_present
    }
    pub fn presented(&mut self, token: u64) {
        if token == self.epoch && self.buttons == 0 {
            self.awaiting_present = false;
        }
    }
}

use std::sync::{Arc, Mutex, atomic::{AtomicBool, AtomicU64, Ordering}};
type Result<T, E = String> = std::result::Result<T, E>;
#[derive(Clone, Default)]
pub struct ExportControl(Arc<Mutex<ControlState>>, Arc<AtomicU64>);
#[derive(Default)]
struct ControlState {
    cancelled: bool,
    yielded: bool,
    published: bool,
}
impl ExportControl {
    pub fn progress(&self) -> f64 {
        f64::from_bits(self.1.load(Ordering::Acquire))
    }
    fn set_progress(&self, progress: f64) {
        self.1.store(progress.to_bits(), Ordering::Release);
    }
    pub fn cancel(&self) -> bool {
        let mut state = self.0.lock().unwrap_or_else(|e| e.into_inner());
        if state.published {
            return false;
        }
        state.cancelled = true;
        true
    }
    pub fn check(&self) -> Result<()> {
        let state = self
            .0
            .lock()
            .map_err(|_| "export cancellation state poisoned")?;
        if state.cancelled || state.yielded {
            Err("movie export cancelled".into())
        } else {
            Ok(())
        }
    }

    // Only prerender uses cooperative yield. Explicit cancellation always wins,
    // including when it follows a yield before acknowledgment is consumed.
    fn yield_to_foreground(&self) -> bool {
        let mut state = self.0.lock().unwrap_or_else(|e| e.into_inner());
        if state.published || state.cancelled {
            return false;
        }
        state.yielded = true;
        true
    }
    fn yielded_only(&self) -> bool {
        self.0
            .lock()
            .is_ok_and(|state| state.yielded && !state.cancelled)
    }
}

#[derive(Clone, Default)]
pub struct YieldControl {
    control: ExportControl,
    completed: Arc<AtomicBool>,
    input_preempted: Arc<AtomicBool>,
    claimed: Arc<AtomicBool>,
}
impl YieldControl {
    pub fn control(&self) -> ExportControl {
        self.control.clone()
    }
    pub fn completed(&self) -> bool {
        self.completed.load(Ordering::Acquire)
    }
    pub fn preempt(&self) -> bool {
        if self.completed() {
            false
        } else {
            self.control.yield_to_foreground()
        }
    }
    /// Input must get its own foreground frame even if native pixels are ready.
    /// Keep ordinary Present yielding unchanged and preserve the reusable owner.
    pub fn preempt_for_input(&self) -> bool {
        self.input_preempted.store(true, Ordering::Release);
        self.preempt()
    }
    pub fn input_preempted(&self) -> bool {
        self.input_preempted.load(Ordering::Acquire)
    }
    fn claim(&self) -> Result<()> {
        self.claimed
            .compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)
            .map(|_| ())
            .map_err(|_| "prerender yield token already submitted".into())
    }
}

#[test]
fn ordinary_present_preserves_completed_control_and_admission() {
    let token = YieldControl::default();
    token.completed.store(true, Ordering::Release);
    assert!(!token.preempt());
    assert!(token.control().check().is_ok());
    assert!(!token.input_preempted());
}
#[test]
fn input_after_clear_snapshot_marks_only_admission_of_completed_pixels() {
    let mut input = InputGate::default();
    let token = YieldControl::default();
    token.completed.store(true, Ordering::Release);
    let snapshot = input.pending();
    assert!(!snapshot);
    input.observe(InputActivity::Pulse).unwrap();
    assert!(!token.preempt_for_input());
    assert!(input.pending());
    assert!(token.input_preempted());
    // Preserve the original native fixture's control contract.
    assert!(token.control().check().is_ok());
}
#[test]
fn unfinished_input_yields_work_and_marks_admission() {
    let token = YieldControl::default();
    assert!(token.preempt_for_input());
    assert!(token.input_preempted());
    assert_eq!(token.control().check().unwrap_err(), "movie export cancelled");
    assert!(token.control.yielded_only());
}
#[test]
fn clones_share_the_same_input_admission_marker() {
    let token = YieldControl::default();
    let clone = token.clone();
    std::thread::spawn(move || { clone.preempt_for_input(); }).join().unwrap();
    assert!(token.input_preempted());
}
#[test]
fn other_jobs_are_not_marked() {
    let first = YieldControl::default();
    let second = YieldControl::default();
    first.preempt_for_input();
    assert!(first.input_preempted());
    assert!(!second.input_preempted());
    assert!(second.control().check().is_ok());
}
#[test]
fn strong_cancel_still_wins_over_marked_cooperative_yield() {
    let token = YieldControl::default();
    token.preempt_for_input();
    assert!(token.control().cancel());
    assert!(token.input_preempted());
    assert!(token.control().check().is_err());
    assert!(!token.control.yielded_only());
}
#[test]
fn input_marker_does_not_reuse_a_single_use_claim() {
    let token = YieldControl::default();
    token.claim().unwrap();
    token.preempt_for_input();
    assert_eq!(token.claim().unwrap_err(), "prerender yield token already submitted");
}

}
