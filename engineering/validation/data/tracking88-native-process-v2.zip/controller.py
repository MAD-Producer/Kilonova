from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88';OUT=ROOT/'artifacts/pr-queue/tracking88-native-process-v2'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
source={p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in set(paths) if p.endswith('.rs') and (WORK/p).is_file()}
tests=[('receipt','test_process::child_identity_exit_codes_streams_and_secondary_write_failure_are_preserved'),
 ('mask','engine::failure::composition_tests::mask_admission::mask_refusal_preserves_cause_and_reaches_default_file_and_stderr'),
 ('text','engine::text_style_tests::export::text_style_png_movie_and_independent_reopen_preserve_authored_pixels'),
 ('precision','shell::project_precision_tests::project_precision_menu_apply_cancel_history_and_gpu_screens_cover_locales_sizes_and_ratios')]
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',MOTION_PRECISION_OUTPUT_ARTIFACTS=str(OUT/'precision'))
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),source=source,steps=[])
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2))
save()
try:
 for label,test in tests:
  command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','--',test,'--exact','--test-threads=1','--nocapture']
  with (OUT/f'{label}.stdout.log').open('wb') as stdout,(OUT/f'{label}.stderr.log').open('wb') as stderr:
   child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row=dict(phase=label,command=command,pid=child.pid);report['steps'].append(row);save();row['exitCode']=child.wait();save()
  assert all(hashlib.sha256((WORK/p).read_bytes()).hexdigest()==h for p,h in source.items()),'source changed'
  assert row['exitCode']==0,(label,row['exitCode'])
  assert '1 passed; 0 failed; 0 ignored' in (OUT/f'{label}.stdout.log').read_text(encoding='utf-8')
 report['status']='process_receipt_and_three_native_wrapper_controls_passed_not_full_regression'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=datetime.now(timezone.utc).isoformat();save()

