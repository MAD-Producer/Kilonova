"""Archive the executed shared-kernel source and native GPU scalar proof."""
from pathlib import Path
import hashlib, json, re, zipfile
ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/reference-depth76'
OUT = ROOT / 'artifacts/pr-queue/depth76-registered-blend-v2'
DATA = WORK / 'engineering/validation/data'
report = json.loads((OUT / 'exit.json').read_text())
assert report['status'] == 'passed_selected_complete_targets' and report['sourceUnchanged']
assert len(report['phases']) == 2 and all(p['exitCode'] == 0 for p in report['phases'])
sha = lambda data: hashlib.sha256(data).hexdigest()
summaries = []
for path in sorted(OUT.glob('*-stdout.log')):
    summaries.extend(re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', path.read_text()))
assert len(summaries) == 9 and sum(int(s[0]) for s in summaries) == 50
assert all(s[1:] == ('0', '0', '0', '0') for s in summaries)
entries = {str(p.relative_to(OUT)).replace('\\', '/'): p.read_bytes() for p in OUT.rglob('*') if p.is_file()}
entries['archive-controller.py'] = Path(__file__).read_bytes()
for path, expected in report['source'].items():
    data = (WORK / path).read_bytes()
    assert sha(data) == expected, path
    entries['source/' + path] = data
archive = DATA / 'depth76-registered-blend-v2.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for name, content in sorted(entries.items()): output.writestr(name, content)
with zipfile.ZipFile(archive) as output:
    assert set(output.namelist()) == set(entries)
    for name, content in entries.items(): assert output.read(name) == content
manifest = dict(status='verified_registered_model_and_scalar_gpu_not_whole_issue',
    baseCommit=report['baseCommit'], sourceUnchanged=True, commands=report['commands'],
    tests=dict(passed=50, failed=0, ignored=0, filtered=0, targets=9),
    elapsedSeconds=report['elapsedSeconds'], archive=archive.name,
    bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
    members=[dict(path=n, bytes=len(d), sha256=sha(d)) for n,d in sorted(entries.items())],
    limits=['GPU proof covers generic scalar display, not depth texture/native scene integration',
            'Moving depth control is authored data, not real footage or automatic registration',
            'No host persistence, UI or full-workspace acceptance is claimed'])
(DATA / 'depth76-registered-blend-v2.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({k:v for k,v in manifest.items() if k != 'members'}))
