
struct EffectUniform {
    size: vec4<f32>, region: vec4<f32>, input_region: vec4<f32>, source_region: vec4<f32>,
    clock: vec4<f32>, mode: vec4<f32>, output_mode: vec4<f32>, params: array<vec4<f32>,32>,
};
@group(0) @binding(0) var<uniform> fx: EffectUniform;
@group(1) @binding(0) var input_image: texture_2d<f32>;
@group(1) @binding(1) var input_sampler: sampler;
@group(1) @binding(2) var source_image: texture_2d<f32>;
@group(1) @binding(3) var source_sampler: sampler;
@group(1) @binding(4) var curve_image: texture_2d<f32>;
@group(1) @binding(5) var curve_sampler: sampler;
@group(2) @binding(0) var resource0: texture_2d<f32>;
@group(2) @binding(1) var resource_sampler0: sampler;
@group(2) @binding(2) var resource1: texture_2d<f32>;
@group(2) @binding(3) var resource_sampler1: sampler;
@group(2) @binding(4) var resource2: texture_2d<f32>;
@group(2) @binding(5) var resource_sampler2: sampler;
@group(2) @binding(6) var resource3: texture_2d<f32>;
@group(2) @binding(7) var resource_sampler3: sampler;
struct EffectVertex { @builtin(position) position: vec4<f32>, @location(0) uv: vec2<f32> };
@vertex fn sdk_vertex(@builtin(vertex_index) index: u32) -> EffectVertex {
    let p = vec2(f32((index << 1u) & 2u)*2.0-1.0,f32(index & 2u)*2.0-1.0); var out: EffectVertex;
    out.position = vec4(p,0.0,1.0); out.uv = vec2(p.x*0.5+0.5,0.5-p.y*0.5); return out;
}
fn edge_uv(uv: vec2<f32>) -> vec2<f32> {
    if fx.mode.x == 2.0 { return fract(uv); }
    if fx.mode.x == 3.0 {
        // Reflection is the identity inside the image. Preserve those bits;
        // subtracting twice from one perturbs Float32 texel-centre weights.
        let reflected=1.0-abs(fract(uv*0.5)*2.0-1.0);
        return select((reflected),(uv),((uv>=vec2(0.0)) & (uv<=vec2(1.0))));
    }
    return clamp(uv,vec2(0.0),vec2(1.0));
}
fn sample_input(p: vec2<f32>) -> vec4<f32> {
    let uv = (p-fx.input_region.xy)/fx.input_region.zw;
    var coord=edge_uv(uv);
    if fx.mode.w<0.5 {
        let dimensions=vec2<f32>(textureDimensions(input_image));let pixels=ceil(fx.input_region.zw*fx.output_mode.w);
        coord*=pixels/dimensions;
        if fx.mode.x!=0.0 {coord=clamp(coord,vec2(0.5)/dimensions,(pixels-0.5)/dimensions);}
    }
    let c = textureSampleLevel(input_image,input_sampler,coord,0.0);
    return select((c),(vec4(0.0)),(fx.mode.x == 0.0 && (any(uv < vec2(0.0)) || any(uv > vec2(1.0)))));
}
fn sample_source(p: vec2<f32>) -> vec4<f32> {
    let uv = (p-fx.source_region.xy)/fx.source_region.zw;
    var coord=edge_uv(uv);
    if fx.mode.w<0.5 {
        let dimensions=vec2<f32>(textureDimensions(source_image));let pixels=ceil(fx.source_region.zw*fx.output_mode.w);
        coord*=pixels/dimensions;
        if fx.mode.x!=0.0 {coord=clamp(coord,vec2(0.5)/dimensions,(pixels-0.5)/dimensions);}
    }
    let c = textureSampleLevel(source_image,source_sampler,coord,0.0);
    return select((c),(vec4(0.0)),(fx.mode.x == 0.0 && (any(uv < vec2(0.0)) || any(uv > vec2(1.0)))));
}
fn curve_lookup_component(value: f32, channel: u32) -> f32 {
    let last=i32(textureDimensions(curve_image).x)-1;
    let position=clamp(value,0.0,1.0)*f32(last);
    let lower=i32(floor(position));let upper=min(lower+1,last);
    let a=textureLoad(curve_image,vec2(lower,0),0)[channel];
    let b=textureLoad(curve_image,vec2(upper,0),0)[channel];
    return a+(b-a)*(position-f32(lower));
}
fn curve_lookup(v: vec4<f32>) -> vec4<f32> {
    return vec4(curve_lookup_component(v.r,0u),curve_lookup_component(v.g,1u),
        curve_lookup_component(v.b,2u),curve_lookup_component(v.a,3u));
}
fn srgb_encode(v: vec3<f32>) -> vec3<f32> {
    return select((1.055*pow(max(v,vec3(0.0)),vec3(1.0/2.4))-0.055),(12.92*v),(v<=vec3(0.0031308)));
}
fn srgb_decode(v: vec3<f32>) -> vec3<f32> {
    return select((pow((max(v,vec3(0.0))+0.055)/1.055,vec3(2.4))),(v/12.92),(v<=vec3(0.04045)));
}
fn straight(c: vec4<f32>) -> vec4<f32> { return vec4(select((vec3(0.0)),(c.rgb/max(c.a,0.000001)),(c.a>0.000001)),c.a); }
fn convert_pixel(pixel: vec4<f32>, src_mode: vec2<f32>, dst_mode: vec2<f32>) -> vec4<f32> {
    var c=pixel; if src_mode.y == 0.0 { c=straight(c); }
    if src_mode.x != dst_mode.x { if dst_mode.x == 1.0 { c=vec4(srgb_encode(c.rgb),c.a); } else { c=vec4(srgb_decode(c.rgb),c.a); } }
    if dst_mode.y == 0.0 { c=vec4(c.rgb*c.a,c.a); } return c;
}

// A host-selected Float16 attachment receives an already representable value.
// Native floating-point attachment conversion need not use nearest-even.
fn sdk_half(v:f32)->f32 {
    let bits=bitcast<u32>(v);let sign=bits&0x80000000u;let magnitude=bits&0x7fffffffu;
    if magnitude>=0x7f800000u{return v;}
    if magnitude>=0x47800000u{return bitcast<f32>(sign|0x7f800000u);}
    if magnitude<0x38800000u {
        let scaled=abs(v)*16777216.0;let lower=floor(scaled);let fraction=scaled-lower;
        let increment=fraction>0.5||(fraction==0.5&&(u32(lower)&1u)==1u);
        let q=(lower+select((0.0),(1.0),(increment)))/16777216.0;
        return bitcast<f32>(bitcast<u32>(q)|sign);
    }
    let rounded=(magnitude+0xfffu+((magnitude>>13u)&1u))&0x7fffe000u;
    if rounded>=0x47800000u{return bitcast<f32>(sign|0x7f800000u);}
    return bitcast<f32>(sign|rounded);
}


const SDK_STORE_FLOAT16: bool = false;
fn sdk_store(c:vec4<f32>)->vec4<f32> {
    if SDK_STORE_FLOAT16 {return vec4(sdk_half(c.x),sdk_half(c.y),sdk_half(c.z),sdk_half(c.w));}
    return c;
}

// Motion Studio .msgraph format 1; SDK 6 single-pass image target.
fn ng_div1(a:f32,b:f32)->f32{let d=select((max(b,f32(1.0e-6))),(min(b,f32(-1.0e-6))),(b<f32(0.0)));return select((a/d),(f32(0.0)),(abs(b)<=f32(1.0e-6)));}
fn ng_smooth1(a:f32,b:f32,v:f32)->f32{let lo=min(a,b);let hi=max(a,b);let t=clamp((v-lo)/max(hi-lo,f32(1.0e-6)),f32(0.0),f32(1.0));return select((t*t*(f32(3.0)-f32(2.0)*t)),(select((f32(0.0)),(f32(1.0)),(v>=lo))),(hi-lo<=f32(1.0e-6)));}
fn ng_div2(a:vec2<f32>,b:vec2<f32>)->vec2<f32>{let d=select((max(b,vec2<f32>(1.0e-6))),(min(b,vec2<f32>(-1.0e-6))),(b<vec2<f32>(0.0)));return select((a/d),(vec2<f32>(0.0)),(abs(b)<=vec2<f32>(1.0e-6)));}
fn ng_smooth2(a:vec2<f32>,b:vec2<f32>,v:vec2<f32>)->vec2<f32>{let lo=min(a,b);let hi=max(a,b);let t=clamp((v-lo)/max(hi-lo,vec2<f32>(1.0e-6)),vec2<f32>(0.0),vec2<f32>(1.0));return select((t*t*(vec2<f32>(3.0)-vec2<f32>(2.0)*t)),(select((vec2<f32>(0.0)),(vec2<f32>(1.0)),(v>=lo))),(hi-lo<=vec2<f32>(1.0e-6)));}
fn ng_div3(a:vec3<f32>,b:vec3<f32>)->vec3<f32>{let d=select((max(b,vec3<f32>(1.0e-6))),(min(b,vec3<f32>(-1.0e-6))),(b<vec3<f32>(0.0)));return select((a/d),(vec3<f32>(0.0)),(abs(b)<=vec3<f32>(1.0e-6)));}
fn ng_smooth3(a:vec3<f32>,b:vec3<f32>,v:vec3<f32>)->vec3<f32>{let lo=min(a,b);let hi=max(a,b);let t=clamp((v-lo)/max(hi-lo,vec3<f32>(1.0e-6)),vec3<f32>(0.0),vec3<f32>(1.0));return select((t*t*(vec3<f32>(3.0)-vec3<f32>(2.0)*t)),(select((vec3<f32>(0.0)),(vec3<f32>(1.0)),(v>=lo))),(hi-lo<=vec3<f32>(1.0e-6)));}
fn ng_to_straight(c:vec4<f32>)->vec4<f32>{return c;}
fn ng_from_straight(c:vec4<f32>)->vec4<f32>{return c;}
fn ng_rounded_rect(p:vec2<f32>,half_size:vec2<f32>,radius:f32)->f32{let h=max(half_size,vec2<f32>(0.0));let r=clamp(radius,0.0,min(h.x,h.y));let q=abs(p)-h+vec2<f32>(r);return length(max(q,vec2<f32>(0.0)))+min(max(q.x,q.y),0.0)-r;}
fn ng_segment(p:vec2<f32>,a:vec2<f32>,b:vec2<f32>)->f32{let ba=b-a;let h=clamp(dot(p-a,ba)/max(dot(ba,ba),1.0e-12),0.0,1.0);return length(p-a-ba*h);}
fn ng_smooth_union(a:f32,b:f32,k:f32)->f32{if k<=1.0e-6{return min(a,b);}let h=clamp(0.5+0.5*(b-a)/k,0.0,1.0);return mix(b,a,h)-k*h*(1.0-h);}
fn ng_fill(d:f32)->f32{let w=max(fwidth(d),1.0e-5);return 1.0-smoothstep(-w*0.5,w*0.5,d);}
fn ng_stroke(d:f32,width:f32)->f32{let w=max(fwidth(d),1.0e-5);let edge=abs(d)-max(width,0.0)*0.5;return 1.0-smoothstep(-w*0.5,w*0.5,edge);}

fn graph_fx(p:vec2<f32>)->vec4<f32>{
    let ng0:f32=1.0;
    let ng1:f32=clamp(fx.params[0].x,f32(-1.0e12),f32(1.0e12));
    let ng2:f32=clamp(fx.params[1].x,f32(-1.0e12),f32(1.0e12));
    let ng3:f32=clamp(fx.params[2].x,f32(-1.0e12),f32(1.0e12));
    let ng4:f32=clamp(fx.params[3].x,f32(-1.0e12),f32(1.0e12));
    let ng5:f32=clamp((ng3*ng4),f32(-1.0e12),f32(1.0e12));
    let ng6:f32=clamp(mix(ng1,ng2,ng5),f32(-1.0e12),f32(1.0e12));
    let ng7:vec4<f32>=ng_from_straight(clamp(vec4<f32>(ng6,ng6,ng6,ng0),vec4<f32>(0.0),vec4<f32>(1.0)));
    return ng7;
}

@fragment fn sdk_fragment(input:EffectVertex)->@location(0) vec4<f32>{let p=fx.region.xy+input.uv*fx.region.zw;return sdk_store(mix(sample_source(p),graph_fx(p),fx.output_mode.z));}
