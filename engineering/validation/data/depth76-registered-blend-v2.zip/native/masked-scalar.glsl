#version 300 es

precision highp float;
precision highp int;

struct EffectUniform {
    vec4 size;
    vec4 region;
    vec4 input_region;
    vec4 source_region;
    vec4 clock;
    vec4 mode;
    vec4 output_mode;
    vec4 params[32];
};
struct EffectVertex {
    vec4 position;
    vec2 uv;
};
const bool SDK_STORE_FLOAT16_ = false;

layout(std140) layout(std140) uniform EffectUniform_block_0Fragment { EffectUniform _group_0_binding_0_fs; };

uniform highp sampler2D _group_1_binding_2_fs;

smooth in vec2 _vs2fs_location0;
layout(location = 0) out vec4 _fs2p_location0;

vec2 edge_uv(vec2 uv) {
    float _e4 = _group_0_binding_0_fs.mode.x;
    if ((_e4 == 2.0)) {
        return fract(uv);
    }
    float _e11 = _group_0_binding_0_fs.mode.x;
    if ((_e11 == 3.0)) {
        vec2 reflected = (vec2(1.0) - abs(((fract((uv * 0.5)) * 2.0) - vec2(1.0))));
        return mix(reflected, uv, bvec2(greaterThanEqual(uv, vec2(0.0)).x && lessThanEqual(uv, vec2(1.0)).x, greaterThanEqual(uv, vec2(0.0)).y && lessThanEqual(uv, vec2(1.0)).y));
    }
    return clamp(uv, vec2(0.0), vec2(1.0));
}

vec4 sample_source(vec2 p_1) {
    vec2 coord_1 = vec2(0.0);
    bool local_2 = false;
    bool local_3 = false;
    vec4 _e3 = _group_0_binding_0_fs.source_region;
    vec4 _e8 = _group_0_binding_0_fs.source_region;
    vec2 uv_1 = ((p_1 - _e3.xy) / _e8.zw);
    vec2 _e11 = edge_uv(uv_1);
    coord_1 = _e11;
    float _e16 = _group_0_binding_0_fs.mode.w;
    if ((_e16 < 0.5)) {
        vec2 dimensions = vec2(uvec2(textureSize(_group_1_binding_2_fs, 0).xy));
        vec4 _e24 = _group_0_binding_0_fs.source_region;
        float _e29 = _group_0_binding_0_fs.output_mode.w;
        vec2 pixels = ceil((_e24.zw * _e29));
        vec2 _e32 = coord_1;
        coord_1 = (_e32 * (pixels / dimensions));
        float _e38 = _group_0_binding_0_fs.mode.x;
        if ((_e38 != 0.0)) {
            vec2 _e41 = coord_1;
            coord_1 = clamp(_e41, (vec2(0.5) / dimensions), ((pixels - vec2(0.5)) / dimensions));
        }
    }
    vec2 _e52 = coord_1;
    vec4 c_5 = textureLod(_group_1_binding_2_fs, vec2(_e52), 0.0);
    float _e58 = _group_0_binding_0_fs.mode.x;
    if ((_e58 == 0.0)) {
        if (!(any(lessThan(uv_1, vec2(0.0))))) {
            local_3 = any(greaterThan(uv_1, vec2(1.0)));
        } else {
            local_3 = true;
        }
        bool _e75 = local_3;
        local_2 = _e75;
    } else {
        local_2 = false;
    }
    bool _e77 = local_2;
    return (_e77 ? vec4(0.0) : c_5);
}

vec3 srgb_encode(vec3 v_1) {
    return mix(((1.055 * pow(max(v_1, vec3(0.0)), vec3(0.41666666))) - vec3(0.055)), (12.92 * v_1), lessThanEqual(v_1, vec3(0.0031308)));
}

vec3 srgb_decode(vec3 v_2) {
    return mix(pow(((max(v_2, vec3(0.0)) + vec3(0.055)) / vec3(1.055)), vec3(2.4)), (v_2 / vec3(12.92)), lessThanEqual(v_2, vec3(0.04045)));
}

vec4 straight(vec4 c) {
    return vec4(((c.w > 1e-6) ? (c.xyz / vec3(max(c.w, 1e-6))) : vec3(0.0)), c.w);
}

vec4 convert_pixel(vec4 pixel, vec2 src_mode, vec2 dst_mode) {
    vec4 c_1 = vec4(0.0);
    c_1 = pixel;
    if ((src_mode.y == 0.0)) {
        vec4 _e7 = c_1;
        vec4 _e8 = straight(_e7);
        c_1 = _e8;
    }
    if ((src_mode.x != dst_mode.x)) {
        if ((dst_mode.x == 1.0)) {
            vec4 _e15 = c_1;
            vec3 _e17 = srgb_encode(_e15.xyz);
            float _e19 = c_1.w;
            c_1 = vec4(_e17, _e19);
        } else {
            vec4 _e21 = c_1;
            vec3 _e23 = srgb_decode(_e21.xyz);
            float _e25 = c_1.w;
            c_1 = vec4(_e23, _e25);
        }
    }
    if ((dst_mode.y == 0.0)) {
        vec4 _e30 = c_1;
        float _e33 = c_1.w;
        float _e36 = c_1.w;
        c_1 = vec4((_e30.xyz * _e33), _e36);
    }
    vec4 _e38 = c_1;
    return _e38;
}

float sdk_half(float v_3) {
    bool local_4 = false;
    bool local_5 = false;
    uint bits = floatBitsToUint(v_3);
    uint sign_ = (bits & 2147483648u);
    uint magnitude = (bits & 2147483647u);
    if ((magnitude >= 2139095040u)) {
        return v_3;
    }
    if ((magnitude >= 1199570944u)) {
        return uintBitsToFloat((sign_ | 2139095040u));
    }
    if ((magnitude < 947912704u)) {
        float scaled = (abs(v_3) * 16777216.0);
        float lower = floor(scaled);
        float fraction = (scaled - lower);
        if (!((fraction > 0.5))) {
            if ((fraction == 0.5)) {
                local_5 = ((uint(lower) & 1u) == 1u);
            } else {
                local_5 = false;
            }
            bool _e35 = local_5;
            local_4 = _e35;
        } else {
            local_4 = true;
        }
        bool increment = local_4;
        float q = ((lower + (increment ? 1.0 : 0.0)) / 16777216.0);
        return uintBitsToFloat((floatBitsToUint(q) | sign_));
    }
    uint rounded = (((magnitude + 4095u) + ((magnitude >> 13u) & 1u)) & 2147475456u);
    if ((rounded >= 1199570944u)) {
        return uintBitsToFloat((sign_ | 2139095040u));
    }
    return uintBitsToFloat((sign_ | rounded));
}

vec4 sdk_store(vec4 c_2) {
    if (SDK_STORE_FLOAT16_) {
        float _e3 = sdk_half(c_2.x);
        float _e5 = sdk_half(c_2.y);
        float _e7 = sdk_half(c_2.z);
        float _e9 = sdk_half(c_2.w);
        return vec4(_e3, _e5, _e7, _e9);
    }
    return c_2;
}

float ng_div1_(float a, float b) {
    float d_2 = ((b < 0.0) ? min(b, -1e-6) : max(b, 1e-6));
    return ((abs(b) <= 1e-6) ? 0.0 : (a / d_2));
}

float ng_smooth1_(float a_1, float b_1, float v_4) {
    float lo = min(a_1, b_1);
    float hi = max(a_1, b_1);
    float t = clamp(((v_4 - lo) / max((hi - lo), 1e-6)), 0.0, 1.0);
    return (((hi - lo) <= 1e-6) ? ((v_4 >= lo) ? 1.0 : 0.0) : ((t * t) * (3.0 - (2.0 * t))));
}

vec2 ng_div2_(vec2 a_2, vec2 b_2) {
    vec2 d_3 = mix(max(b_2, vec2(1e-6)), min(b_2, vec2(-1e-6)), lessThan(b_2, vec2(0.0)));
    return mix((a_2 / d_3), vec2(0.0), lessThanEqual(abs(b_2), vec2(1e-6)));
}

vec2 ng_smooth2_(vec2 a_3, vec2 b_3, vec2 v_5) {
    vec2 lo_1 = min(a_3, b_3);
    vec2 hi_1 = max(a_3, b_3);
    vec2 t_1 = clamp(((v_5 - lo_1) / max((hi_1 - lo_1), vec2(1e-6))), vec2(0.0), vec2(1.0));
    return mix(((t_1 * t_1) * (vec2(3.0) - (vec2(2.0) * t_1))), mix(vec2(0.0), vec2(1.0), greaterThanEqual(v_5, lo_1)), lessThanEqual((hi_1 - lo_1), vec2(1e-6)));
}

vec3 ng_div3_(vec3 a_4, vec3 b_4) {
    vec3 d_4 = mix(max(b_4, vec3(1e-6)), min(b_4, vec3(-1e-6)), lessThan(b_4, vec3(0.0)));
    return mix((a_4 / d_4), vec3(0.0), lessThanEqual(abs(b_4), vec3(1e-6)));
}

vec3 ng_smooth3_(vec3 a_5, vec3 b_5, vec3 v_6) {
    vec3 lo_2 = min(a_5, b_5);
    vec3 hi_2 = max(a_5, b_5);
    vec3 t_2 = clamp(((v_6 - lo_2) / max((hi_2 - lo_2), vec3(1e-6))), vec3(0.0), vec3(1.0));
    return mix(((t_2 * t_2) * (vec3(3.0) - (vec3(2.0) * t_2))), mix(vec3(0.0), vec3(1.0), greaterThanEqual(v_6, lo_2)), lessThanEqual((hi_2 - lo_2), vec3(1e-6)));
}

vec4 ng_to_straight(vec4 c_3) {
    return c_3;
}

vec4 ng_from_straight(vec4 c_4) {
    return c_4;
}

float ng_rounded_rect(vec2 p_2, vec2 half_size, float radius) {
    vec2 h = max(half_size, vec2(0.0));
    float r = clamp(radius, 0.0, min(h.x, h.y));
    vec2 q_1 = ((abs(p_2) - h) + vec2(r));
    return ((length(max(q_1, vec2(0.0))) + min(max(q_1.x, q_1.y), 0.0)) - r);
}

float ng_segment(vec2 p_3, vec2 a_6, vec2 b_6) {
    vec2 ba = (b_6 - a_6);
    float h_1 = clamp((dot((p_3 - a_6), ba) / max(dot(ba, ba), 1e-12)), 0.0, 1.0);
    return length(((p_3 - a_6) - (ba * h_1)));
}

float ng_smooth_union(float a_7, float b_7, float k) {
    if ((k <= 1e-6)) {
        return min(a_7, b_7);
    }
    float h_2 = clamp((0.5 + ((0.5 * (b_7 - a_7)) / k)), 0.0, 1.0);
    return (mix(b_7, a_7, h_2) - ((k * h_2) * (1.0 - h_2)));
}

vec4 graph_fx(vec2 p_4) {
    float _e6 = _group_0_binding_0_fs.params[0].x;
    float ng1_ = clamp(_e6, -1000000000000.0, 1000000000000.0);
    float _e14 = _group_0_binding_0_fs.params[1].x;
    float ng2_ = clamp(_e14, -1000000000000.0, 1000000000000.0);
    float _e22 = _group_0_binding_0_fs.params[2].x;
    float ng3_ = clamp(_e22, -1000000000000.0, 1000000000000.0);
    float _e30 = _group_0_binding_0_fs.params[3].x;
    float ng4_ = clamp(_e30, -1000000000000.0, 1000000000000.0);
    float ng5_ = clamp((ng3_ * ng4_), -1000000000000.0, 1000000000000.0);
    float ng6_ = clamp(mix(ng1_, ng2_, ng5_), -1000000000000.0, 1000000000000.0);
    vec4 _e48 = ng_from_straight(clamp(vec4(ng6_, ng6_, ng6_, 1.0), vec4(0.0), vec4(1.0)));
    return _e48;
}

void main() {
    EffectVertex input_ = EffectVertex(gl_FragCoord, _vs2fs_location0);
    vec4 _e3 = _group_0_binding_0_fs.region;
    vec4 _e8 = _group_0_binding_0_fs.region;
    vec2 p_5 = (_e3.xy + (input_.uv * _e8.zw));
    vec4 _e12 = sample_source(p_5);
    vec4 _e13 = graph_fx(p_5);
    float _e17 = _group_0_binding_0_fs.output_mode.z;
    vec4 _e19 = sdk_store(mix(_e12, _e13, _e17));
    _fs2p_location0 = _e19;
    return;
}

