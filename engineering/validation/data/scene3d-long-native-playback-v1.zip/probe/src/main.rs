//! Manual native-surface acceptance, never a time-coupled default CI test.
#[path = "../../../.worktrees/native-camera-dof/desktop/app/src/logging.rs"]
mod logging;
mod engine {
    pub fn current_command() -> Option<(u64, &'static str, std::time::Duration)> {
        None
    }
}
mod fixture;
use motion_host::{
    depth::{Backend, Cancellation, Costs, Estimate, Input},
    Platform, Session,
};
use std::{
    fs,
    path::PathBuf,
    sync::{
        atomic::{AtomicUsize, Ordering},
        mpsc, Arc,
    },
    time::{Duration, Instant},
};
use winit::platform::pump_events::EventLoopExtPumpEvents;

struct OwnedScalar(Arc<AtomicUsize>);
impl Backend for OwnedScalar {
    fn infer(
        &mut self,
        input: &Input,
        cancel: &Cancellation,
    ) -> motion_host::depth::Result<Estimate> {
        cancel.check()?;
        self.0.fetch_add(1, Ordering::SeqCst);
        Ok(Estimate {
            resource: motion_model::depth::DepthResource::new(
                motion_model::depth::DepthDescriptor {
                    size: input.size(),
                    source: input.key().source.clone(),
                    geometry: input.key().geometry.clone(),
                    model: input.key().model.clone(),
                    measure: motion_model::depth::DepthMeasure::Relative {
                        near: motion_model::depth::NearDirection::Increasing,
                    },
                    scale: 1.,
                    offset: 0.,
                    valid_range: None,
                },
                input
                    .rgb()
                    .chunks_exact(3)
                    .map(|p| f32::from(p[0]))
                    .collect(),
                None,
                None,
            )?,
            provider: "owned-sustained-red-channel".into(),
            costs: Costs::default(),
        })
    }
}
fn pixels(g: &motion_host::session::Graphics) -> Vec<u8> {
    let target = &g.scratch;
    assert_eq!((target.width, target.height), (32, 32));
    assert_eq!(
        target.view.texture().format(),
        wgpu::TextureFormat::Rgba8UnormSrgb
    );
    let row = 128u32;
    let stride = 256u32;
    let buffer = g
        .renderer
        .allocation_context()
        .buffer(&wgpu::BufferDescriptor {
            label: Some("actual retained native preview readback"),
            size: u64::from(stride * 32),
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        })
        .unwrap();
    let mut encoder = g
        .renderer
        .allocation_command_encoder(&Default::default())
        .unwrap();
    encoder.copy_texture_to_buffer(
        target.view.texture().as_image_copy(),
        wgpu::TexelCopyBufferInfo {
            buffer: &buffer,
            layout: wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(stride),
                rows_per_image: Some(32),
            },
        },
        wgpu::Extent3d {
            width: 32,
            height: 32,
            depth_or_array_layers: 1,
        },
    );
    g.renderer
        .submit_allocated(encoder.finish(), |_| {})
        .unwrap();
    let (send, recv) = mpsc::sync_channel(1);
    buffer.slice(..).map_async(wgpu::MapMode::Read, move |r| {
        send.send(r).unwrap();
    });
    g.renderer
        .device
        .poll(wgpu::PollType::wait_indefinitely())
        .unwrap();
    recv.recv().unwrap().unwrap();
    let mapped = buffer.slice(..).get_mapped_range().unwrap();
    let bytes = mapped
        .chunks_exact(stride as usize)
        .flat_map(|r| r[..row as usize].iter().copied())
        .collect();
    drop(mapped);
    buffer.unmap();
    bytes
}
fn verify(
    session: &mut Session,
    data: &fixture::Fixture,
    frame: u32,
    out: &std::path::Path,
) -> serde_json::Value {
    let estimate = session
        .poll_depth()
        .unwrap()
        .expect("presented source must retain its admitted depth");
    assert_eq!(
        estimate.resource.descriptor().source.pts.ticks,
        data.pts[frame as usize] as i64
    );
    assert_eq!(
        session.depth_input_fingerprint().unwrap().unwrap(),
        fixture::fingerprint(&data.decoded[frame as usize])
    );
    let g = session.graphics.as_ref().unwrap();
    let actual = pixels(g);
    let at = |x: usize, y: usize| &actual[(y * 32 + x) * 4..][..4];
    let far = at(16, 10);
    let near = at(16, 22);
    assert!(
        far[0] < 20 && far[1] < 20 && far[2] > 220,
        "frame={frame} far={far:?}"
    );
    assert!(
        near[0] > 30 + (frame % 3) as u8 * 40,
        "frame={frame} near={near:?}"
    );
    let reference = &data.decoded[frame as usize][(22 * 32 + 16) * 4..][..4];
    for ch in [1, 2] {
        assert!(
            near[ch].abs_diff(reference[ch]) <= 10,
            "frame={frame} channel={ch} actual={near:?} decoded={reference:?}"
        );
    }
    image::save_buffer(
        out.join(format!("native-{frame:04}.png")),
        &actual,
        32,
        32,
        image::ColorType::Rgba8,
    )
    .unwrap();
    let budget = session.allocation_budget_info().unwrap();
    let status = session.depth_status().unwrap().unwrap();
    assert!(budget.admitted_bytes <= budget.budget_bytes);
    assert!(status.retained_samples <= 128);
    assert!(status.stored_samples <= 4096);
    serde_json::json!({"frame":frame,"pts":data.pts[frame as usize],"far":far,"near":near,"decodedNear":reference,
        "admittedBytes":budget.admitted_bytes,"budgetBytes":budget.budget_bytes,"liveDepthSamples":status.retained_samples,"storedDepthSamples":status.stored_samples})
}
#[allow(deprecated)]
fn main() {
    let out = PathBuf::from(std::env::args_os().nth(1).expect("output directory"));
    fs::create_dir_all(&out).unwrap();
    let _guard = logging::init(out.join("logs")).unwrap();
    let preparation = Instant::now();
    log::info!(
        "start #87003 long_native_playback phase=owned_codec_preparation frames={}",
        fixture::FRAMES
    );
    let root = out.join("source-project");
    let data = fixture::create(&root);
    log::info!(
        "long_native_playback phase=owned_codec_ready elapsed_ms={}",
        preparation.elapsed().as_millis()
    );
    let calls = Arc::new(AtomicUsize::new(0));
    let platform = motion_desktop_media::platform();
    let mut s = Session::new(data.project.clone(), root, platform.clone()).unwrap();
    // The independent pixel oracle fixes composition sampling at source size;
    // adaptive preview quality is a different acceptance axis.
    s.preview.set_mode(motion_render::PreviewMode::High);
    s.allocation_budget().set_limit(64 << 20).unwrap();
    let budget = s.allocation_budget().clone();
    let depth_cache = out.join("depth-cache");
    fs::create_dir_all(&depth_cache).unwrap();
    s.configure_depth_in(OwnedScalar(calls.clone()), depth_cache)
        .unwrap();
    let mut events = winit::event_loop::EventLoop::new().unwrap();
    let window = Arc::new(
        events
            .create_window(
                winit::window::Window::default_attributes()
                    .with_title("Owned 3D pipeline acceptance")
                    .with_visible(false)
                    .with_inner_size(winit::dpi::PhysicalSize::new(128, 128)),
            )
            .unwrap(),
    );
    let surface = platform
        .attach_surface(window, 128, 128, budget.clone())
        .unwrap();
    s.attach(surface).unwrap();
    let adapter = format!("{:?}", s.graphics.as_ref().unwrap().renderer.adapter_info);
    // Complete initial lazy pipelines outside the timed interval.
    let warm = Instant::now();
    while !s.render(0.).unwrap() {
        assert!(warm.elapsed() < Duration::from_secs(15));
        events.pump_events(Some(Duration::ZERO), |_, _| {});
        std::thread::sleep(Duration::from_millis(1));
    }
    let mut checkpoints = vec![verify(&mut s, &data, 0, &out)];
    log::info!("start #87004 long_native_playback phase=timed_present duration_seconds=60");
    let started = Instant::now();
    let mut attempts = Vec::new();
    let mut presented = Vec::new();
    let mut last = Some(0u32);
    let mut second = 0;
    while started.elapsed() < Duration::from_secs(60) {
        events.pump_events(Some(Duration::ZERO), |_, _| {});
        let wanted = (started.elapsed().as_secs_f64() * 30.)
            .floor()
            .min(f64::from(fixture::FRAMES - 1)) as u32;
        if last == Some(wanted) {
            std::thread::sleep(Duration::from_millis(1));
            continue;
        }
        let began = Instant::now();
        let rendered = s.render(f64::from(wanted)).unwrap();
        attempts.push(began.elapsed().as_micros() as u64);
        if rendered {
            assert_eq!(s.last_presented_frame, Some(f64::from(wanted)));
            presented.push(wanted);
            last = Some(wanted);
            let now = started.elapsed().as_secs();
            if now > second {
                checkpoints.push(verify(&mut s, &data, wanted, &out));
                second = now;
            }
        } else {
            std::thread::sleep(Duration::from_millis(1));
        }
    }
    let wall = started.elapsed().as_secs_f64();
    let final_wait = Instant::now();
    while !s.render(f64::from(fixture::FRAMES - 1)).unwrap() {
        assert!(final_wait.elapsed() < Duration::from_secs(5));
        events.pump_events(Some(Duration::ZERO), |_, _| {});
        std::thread::sleep(Duration::from_millis(1));
    }
    checkpoints.push(verify(&mut s, &data, fixture::FRAMES - 1, &out));
    assert!(wall >= 60.);
    assert!(presented.len() > 128);
    assert!(presented.windows(2).all(|p| p[1] > p[0]));
    let status = s.depth_status().unwrap().unwrap();
    assert!(status.stored_samples > 128);
    let stored = status.stored_samples;
    let live = status.retained_samples;
    let device = s.graphics.as_ref().unwrap().renderer.device.clone();
    let peak = budget.info().unwrap().peak_admitted_bytes;
    let attempts_count = attempts.len();
    attempts.sort_unstable();
    let p95 = attempts[(attempts.len() - 1) * 95 / 100];
    let maximum = *attempts.last().unwrap();
    let backend_calls = calls.load(Ordering::SeqCst);
    log::info!("long_native_playback phase=timed_complete elapsed_seconds={wall:.3} presented={} stored_samples={stored} render_p95_us={p95}", presented.len());
    drop(s);
    device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
    let remaining = budget.info().unwrap();
    assert_eq!(
        remaining.admitted_bytes, 0,
        "native owners must release after surface/session completion"
    );
    log::info!(
        "long_native_playback phase=retired admitted_bytes={}",
        remaining.admitted_bytes
    );
    fs::write(out.join("accepted.json"),serde_json::to_vec_pretty(&serde_json::json!({
        "wallSeconds":wall,"sourceFrames":fixture::FRAMES,"sourceFps":30,"adapter":adapter,"presentedFrames":presented,
        "renderAttempts":attempts_count,"renderAttemptP95Us":p95,"renderAttemptMaxUs":maximum,"checkpoints":checkpoints,
        "backendCalls":backend_calls,"storedSamples":stored,"liveSamples":live,"peakAdmittedBytes":peak,"afterDropBytes":remaining.admitted_bytes,
        "scope":"60-second actual Session native-surface playback on 32x32 owned H.264, controlled scalar backend, High preview and default Unorm8; not adaptive quality, trained-model quality or high-resolution throughput",
    })).unwrap()).unwrap();
    logging::flush();
}
