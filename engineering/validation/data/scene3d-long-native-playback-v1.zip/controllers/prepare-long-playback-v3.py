from pathlib import Path
r=Path('E:/Dev/aem/.tools/issue-closure-review')
s=(r/'validate-long-native-playback-v2.py').read_text(encoding='utf-8')
s=s.replace('long-native-playback-v2','long-native-playback-v3')
needle="step('native',[str(binary),str(out/'native')],timeout=600)"
assert needle in s
replacement='''# Use the same validated native runtime as the accepted actual codec tests.
runtime=json.loads((root/'artifacts/pr-queue/video-depth-file-export-current-main-v8/runtime-staging.json').read_text(encoding='utf-8'))
assert runtime['harnessExit']==0
for name,item in runtime['files'].items():
    assert Path(name).name==name and name.endswith('.dll')
    source=Path(item['source']);destination=binary.parent/name
    assert hashlib.sha256(source.read_bytes()).hexdigest()==item['sha256'],name
    if destination.exists():
        assert hashlib.sha256(destination.read_bytes()).hexdigest()==item['sha256'],name
    else:
        shutil.copyfile(source,destination)
    assert hashlib.sha256(destination.read_bytes()).hexdigest()==item['sha256'],name
report['runtimeStaging']=runtime
(out/'runtime-staging.json').write_text(json.dumps(runtime,indent=2),encoding='utf-8')
step('native',[str(binary),str(out/'native')],timeout=600)'''
s=s.replace(needle,replacement)
(r/'validate-long-native-playback-v3.py').write_text(s,encoding='utf-8')
