"""Source-bound manual real-codec/native-surface run; not a PR timing test."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import shutil

root = Path('E:/Dev/aem')
work = root / '.worktrees/native-camera-dof'
probe = root / '.tools/scene87-long-playback'
prior = json.loads((root / 'artifacts/pr-queue/native-camera-dof-regression-v2/accepted.json').read_text(encoding='utf-8'))
assert prior['sourceUnchanged'] and prior['unexecutedIgnored'] == 0

def source_check():
    for path, sha in prior['source'].items():
        assert hashlib.sha256((work/path).read_bytes()).hexdigest() == sha, path

source_check()
out = root / 'artifacts/pr-queue/long-native-playback-v3'
out.mkdir(exist_ok=False)
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1')
env.pop('MOTION_LOG', None)
report = dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),
              inheritedSource=prior['source'], startedUtc=datetime.now(timezone.utc).isoformat(), steps=[])
paths = [probe/'Cargo.toml', probe/'src/main.rs', probe/'src/fixture.rs', Path(__file__)]
report['toolSource'] = {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}

def step(name, command, timeout=1800):
    print(json.dumps(dict(start=name)), flush=True)
    began = datetime.now(timezone.utc)
    with (out/(name+'.stdout.log')).open('wb') as so, (out/(name+'.stderr.log')).open('wb') as se:
        try:
            code = subprocess.run(command,cwd=work,env=env,stdout=so,stderr=se,timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            code = 'timeout'
    source_check()
    row = dict(name=name, command=[str(c) for c in command], exitCode=code,
               wallSeconds=(datetime.now(timezone.utc)-began).total_seconds(), sourceUnchanged=True)
    report['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    assert code == 0, row

shutil.copyfile(work/'Cargo.lock', probe/'Cargo.lock')
step('lock',['cargo','metadata','--manifest-path',str(probe/'Cargo.toml'),'--format-version','1','--offline'])
report['toolLockSha256'] = hashlib.sha256((probe/'Cargo.lock').read_bytes()).hexdigest()
step('build',['cargo','build','--manifest-path',str(probe/'Cargo.toml'),'--locked','--offline'])
binary = root/'target/gltf-animation87-contract/debug/motion-scene87-long-playback.exe'
report['binarySha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
# Use the same validated native runtime as the accepted actual codec tests.
runtime=json.loads((root/'artifacts/pr-queue/video-depth-file-export-current-main-v8/runtime-staging.json').read_text(encoding='utf-8'))
assert runtime['harnessExit']==0
for name,item in runtime['files'].items():
    assert Path(name).name==name and name.endswith('.dll')
    source=Path(item['source']);destination=binary.parent/name
    assert hashlib.sha256(source.read_bytes()).hexdigest()==item['sha256'],name
    if destination.exists():
        assert hashlib.sha256(destination.read_bytes()).hexdigest()==item['sha256'],name
    else:
        shutil.copyfile(source,destination)
    assert hashlib.sha256(destination.read_bytes()).hexdigest()==item['sha256'],name
report['runtimeStaging']=runtime
(out/'runtime-staging.json').write_text(json.dumps(runtime,indent=2),encoding='utf-8')
step('native',[str(binary),str(out/'native')],timeout=600)
assert not (out/'native.stdout.log').read_bytes(), 'unexpected stdout'
native = json.loads((out/'native/accepted.json').read_text(encoding='utf-8'))
assert native['wallSeconds'] >= 60 and native['sourceFrames'] == 1800
frames = native['presentedFrames']
assert len(frames) > 128 and all(b>a for a,b in zip(frames,frames[1:]))
assert native['storedSamples'] > 128 and native['liveSamples'] <= 128
assert native['afterDropBytes'] == 0
assert len(native['checkpoints']) >= 3
assert native['checkpoints'][0]['frame'] == 0 and native['checkpoints'][-1]['frame'] == 1799
assert all(c['admittedBytes'] <= c['budgetBytes'] for c in native['checkpoints'])
source_check()
report.update(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=True, native=native,
              scope=native['scope'])
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True, wallSeconds=native['wallSeconds'], presented=len(frames))),flush=True)
