//! Independently owned 60-second H.264 fixture and explicit per-PTS calibration.
use motion_core::{Content, Layer, Project, VideoClip};
use motion_host::platform::VideoDecoder;
use motion_model::depth::*;
use sha2::{Digest, Sha256};
use std::{fs, path::Path};

pub const FRAMES: u32 = 1800;
pub fn model() -> DepthModel {
    DepthModel {
        id: "owned-sustained-codec".into(),
        revision: "1".into(),
        sha256: [7; 32],
        processing: "red-channel".into(),
    }
}
pub fn geometry() -> DepthGeometry {
    DepthGeometry {
        source_size: [32; 2],
        crop: [0, 0, 32, 32],
        quarter_turns: 0,
        mirror_x: false,
    }
}
pub fn fingerprint(rgba: &[u8]) -> PreparedDepthInput {
    let mut h = Sha256::new();
    h.update(b"MotionStudio/depth/rgb8-srgb-opaque/v1\0");
    h.update(32u32.to_le_bytes());
    h.update(32u32.to_le_bytes());
    for p in rgba.chunks_exact(4) {
        h.update(&p[..3]);
    }
    PreparedDepthInput {
        rgb_size: [32; 2],
        rgb_sha256: h.finalize().into(),
    }
}
pub fn resource(pts: i64, values: Vec<f32>) -> DepthResource {
    DepthResource::new(
        DepthDescriptor {
            size: [32; 2],
            source: DepthSource {
                asset: 74,
                revision: 0,
                pts: DepthTime {
                    ticks: pts,
                    timescale: 1_000_000,
                },
            },
            geometry: geometry(),
            model: model(),
            measure: DepthMeasure::Relative {
                near: NearDirection::Increasing,
            },
            scale: 1.,
            offset: 0.,
            valid_range: None,
        },
        values,
        None,
        None,
    )
    .unwrap()
}
pub struct Fixture {
    pub project: Project,
    pub pts: Vec<u64>,
    pub decoded: Vec<Vec<u8>>,
}
pub fn create(root: &Path) -> Fixture {
    fs::create_dir_all(root.join("assets")).unwrap();
    let path = root.join("assets/source.mp4");
    let mut encoder = motion_desktop_media::encode::Mp4Encoder::new(&path, 32, 32, 30).unwrap();
    for index in 0..FRAMES {
        let pixels: Vec<u8> = (0..32u8)
            .flat_map(|y| {
                (0..32).flat_map(move |_| {
                    [
                        24 + (index % 3) as u8 * 40 + y * 2,
                        (8 + (index * 73) % 239) as u8,
                        (8 + (index * 131) % 241) as u8,
                        255,
                    ]
                })
            })
            .collect();
        encoder.video_frame(&pixels, index).unwrap();
    }
    let count = u64::from(FRAMES) * 48_000 / 30;
    let mut offset = 0;
    while offset < count {
        let n = encoder.audio_frame_size().min((count - offset) as usize);
        encoder.audio_frame(&vec![0.; n * 2], offset).unwrap();
        offset += n as u64;
    }
    encoder.finish().unwrap();
    let mut probe = motion_desktop_media::av::probe(&path, None, None, &|| Ok(())).unwrap();
    assert_eq!(probe.timestamps.len(), FRAMES as usize);
    probe.asset.id = 74;
    probe.asset.path = "assets/source.mp4".into();
    let index = motion_media::video_cache_path(root, &probe.asset).unwrap();
    fs::create_dir_all(index.parent().unwrap()).unwrap();
    motion_media::save_index(&index, &probe.asset, &probe.timestamps).unwrap();
    let mut reader = motion_desktop_media::av::Decoder::open(
        &path,
        probe.asset.clone(),
        probe.timestamps.clone(),
    )
    .unwrap();
    let decoded: Vec<_> = probe
        .timestamps
        .iter()
        .map(|&pts| {
            let frame = reader.frame(pts, &|| Ok(())).unwrap();
            assert_eq!(frame.pts, pts);
            assert_eq!(
                reader.rgb_encoding().unwrap(),
                motion_host::video_frame::RgbEncoding::Srgb
            );
            frame.rgba().unwrap().into_owned()
        })
        .collect();
    drop(reader);
    let mut p = Project::new(32, 32, 30, FRAMES).unwrap();
    let mut video = Layer::solid(
        1,
        "Owned sustained indexed video",
        [80.; 2],
        [16., 16., 0.],
        [1.; 4],
    );
    video.content = Content::Video {
        video: VideoClip::new(74),
    };
    video.three_d = true;
    let mut blue = Layer::solid(
        2,
        "Independent physical occluder",
        [80.; 2],
        [16., 16., 0.],
        [0., 0., 1., 1.],
    );
    blue.three_d = true;
    p.layers.extend([video, blue]);
    p.video_assets.push(probe.asset.clone());
    p.camera.created = true;
    p.camera.position.value = [16., 16., -120.];
    p.camera.target.value = [16., 16., 0.];
    p.camera.fov.value = 60.;
    let mut scene = motion_render::Scene::new(&p).unwrap();
    scene
        .sample(&p, 0., None, &motion_core::ExpressionEvaluator)
        .unwrap();
    let layer = scene.layers.iter().find(|l| l.id == 1).unwrap();
    let reference = DepthReference {
        camera: scene.native_camera(),
        world: layer.model,
        size: layer.size,
    };
    let mut track = VideoDepthTrack::default();
    for (i, rgba) in decoded.iter().enumerate() {
        let values: Vec<_> = rgba.chunks_exact(4).map(|p| f32::from(p[0])).collect();
        let low = values.iter().copied().fold(f32::INFINITY, f32::min);
        let high = values.iter().copied().fold(f32::NEG_INFINITY, f32::max);
        assert!(high - low > 40.);
        let resource = resource(probe.timestamps[i] as i64, values);
        let calibration = SavedDepthCalibration::new(
            &resource,
            fingerprint(rgba),
            [
                DepthAnchor {
                    value: f64::from(low),
                    camera_z_meters: 8.,
                },
                DepthAnchor {
                    value: f64::from(high),
                    camera_z_meters: 4.,
                },
            ],
            CalibrationCurve::CameraZ,
            CalibrationExtrapolation::Reject,
            20.,
        )
        .unwrap()
        .with_reference(reference.clone())
        .unwrap();
        let end = probe
            .timestamps
            .get(i + 1)
            .copied()
            .unwrap_or(probe.asset.video_end_us);
        track
            .upsert(VideoDepthSample::new(calibration, end).unwrap())
            .unwrap();
    }
    p.layers[0].video_depth_calibration = Some(track);
    p.validate().unwrap();
    let json = serde_json::to_vec_pretty(&p).unwrap();
    fs::write(root.join("authored-project.json"), &json).unwrap();
    let restored: Project = serde_json::from_slice(&json).unwrap();
    assert_eq!(restored, p);
    Fixture {
        project: restored,
        pts: probe.timestamps,
        decoded,
    }
}
