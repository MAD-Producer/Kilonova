from pathlib import Path
from datetime import datetime, timezone
import ctypes, ctypes.wintypes as wintypes, hashlib, json, os, re, shutil, subprocess, sys, time

root=Path('E:/Dev/aem'); work=root/'.worktrees/depth-calibration'
out=root/'artifacts/pr-queue/depth-calibration-native-v1'; out.mkdir(exist_ok=False)
target=root/'target/gltf-animation87-contract'
full=root/'artifacts/pr-queue/issue87-skin-main-full-v2'
def source():
    paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z'],cwd=work).decode().split('\0')
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if p and (p.endswith(('.rs','.py','.toml','.wgsl')) or p=='Cargo.lock')}
before=source(); env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',LOCALAPPDATA=str(out/'appdata'))
for key in ('MOTION_LOG','VK_DRIVER_FILES','VK_ICD_FILENAMES'):env.pop(key,None)
receipt=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),source=before,controllerPid=os.getpid(),startedUtc=datetime.now(timezone.utc).isoformat(),steps=[],scope='Explicit two-anchor calibration and immutable admitted native shared-depth seed; synthetic independently authored fields, not real inference accuracy or project integration')
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
def run(name,cmd):
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as so,(out/(name+'.stderr.log')).open('wb') as se:
        code=subprocess.run(cmd,cwd=work,env=env,stdout=so,stderr=se).returncode
    text=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
    rows=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    row=dict(name=name,command=cmd,exitCode=code,sourceUnchanged=before==source())
    if rows:row['totals']=dict(zip(('passed','failed','ignored'),[sum(int(v[i]) for v in rows) for i in range(3)]))
    for stream in ('stdout','stderr'):row[stream+'Sha256']=hashlib.sha256((out/(name+'.'+stream+'.log')).read_bytes()).hexdigest()
    receipt['steps'].append(row); (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(row),flush=True)
    assert code==0 and row['sourceUnchanged'],name
    if rows:assert row['totals']['failed']==row['totals']['ignored']==0
    return text

run('provenance',[sys.executable,'tools/validate_provenance.py'])
run('panel-style',[sys.executable,'-c',"import runpy; runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"])
run('model-tests',['cargo','test','-p','motion-model','--locked','--offline','--','--test-threads=1'])
build=run('native-build',['cargo','test','-p','motion-render','--features','gpu-tests','--test','scene_gpu','--lib','--no-run','--message-format=json','--locked','--offline'])
executables={}
for line in build.splitlines():
    try:row=json.loads(line)
    except ValueError:continue
    if row.get('reason')=='compiler-artifact' and row.get('executable') and row['profile']['test']:
        executables[row['target']['name']]=row['executable']
assert set(executables)=={'motion_render','scene_gpu'},executables
receipt['executables']=executables

# Compile while the isolated whole-workspace gate runs, but do not contend for
# the actual GPU or shared native cache. Wait on the exact owned controller.
pid=json.loads((full/'started.json').read_text(encoding='utf-8'))['controllerPid']
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];kernel.GetExitCodeProcess.restype=wintypes.BOOL
kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
handle=kernel.OpenProcess(0x1000,False,pid)
receipt.update(state='build complete; waiting for owned full GPU gate',frozenControllerPid=pid)
(out/'state.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
try:
    while not (full/'accepted.json').exists():
        assert handle,'full gate exited without acceptance'
        status=wintypes.DWORD();assert kernel.GetExitCodeProcess(handle,ctypes.byref(status))
        assert status.value==259,'full gate exited without acceptance'
        time.sleep(2)
finally:
    if handle:kernel.CloseHandle(handle)
assert source()==before
assert json.loads((full/'accepted.json').read_text(encoding='utf-8'))['head']==receipt['base']
receipt['state']='running actual native pixels after frozen GPU gate accepted'
(out/'state.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
staged=[]
for p in (root/'target/gltf-scene87-contract/debug/deps').glob('*.dll'):
    if p.name.startswith(('avcodec-','avdevice-','avfilter-','avformat-','avutil-','swresample-','swscale-')):
        destination=target/'debug/deps'/p.name;shutil.copyfile(p,destination)
        digest=hashlib.sha256(p.read_bytes()).hexdigest();assert hashlib.sha256(destination.read_bytes()).hexdigest()==digest
        staged.append(dict(file=p.name,sha256=digest))
receipt['nativeDlls']=staged
text=run('native-scene',[executables['scene_gpu'],'--test-threads=1'])
for test in ('calibrated_depth_occludes_real_meshes_in_four_precisions_and_both_sample_counts','calibrated_native_validity_and_letterbox_leave_color_and_uncovered_depth_intact','stale_calibrated_source_camera_and_world_units_refuse_before_target_recording','calibrated_depth_admission_rolls_back_and_pending_frames_keep_immutable_inputs','calibrated_perspective_depth_uses_actual_finite_and_infinite_projection_in_world_units','calibrated_depth_preserves_global_blending_and_alpha_mask_depth_rules','calibrated_depth_failure_observation_keeps_sample_context_and_recovers_at_default_level'):
    assert 'test calibrated_depth::'+test+' ... ok' in text,test
assert receipt['steps'][-1]['totals']['passed']>=45
text=run('native-original-errors',[executables['motion_render'],'wrapped_native_','--test-threads=1'])
assert 'wrapped_native_calibrated_depth_keeps_original_typed_resource_refusal ... ok' in text
assert receipt['steps'][-1]['totals']['passed']==3
run('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'])
receipt.update(state='accepted targeted CPU/native gate; project and actual calibrated inference remain pending',completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=source()==before)
assert receipt['sourceUnchanged']
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,totalPassed=sum(s.get('totals',{}).get('passed',0) for s in receipt['steps']))))
