from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess
root=Path('E:/Dev/aem');work=root/'.worktrees/depth-calibration';out=root/'artifacts/pr-queue/depth-calibration-cpu-v4';out.mkdir(exist_ok=False)
def source():
 paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z'],cwd=work).decode().split('\0')
 return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if p and (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
before=source();env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
receipt=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),source=before,controllerPid=os.getpid(),steps=[],startedUtc=datetime.now(timezone.utc).isoformat(),scope='Pure owned sample-bound calibration and camera projection math; native occlusion/project/real inference acceptance are not established by this CPU gate')
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
for name,cmd in [('model-tests',['cargo','test','-p','motion-model','--locked','--offline','--','--test-threads=1'])]:
 print(json.dumps(dict(start=name)),flush=True)
 with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
  code=subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
 row=dict(name=name,command=cmd,exitCode=code,sourceUnchanged=source()==before)
 text=(out/(name+'.stdout.log')).read_text(encoding='utf-8'); totals=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 if totals:row['totals']=dict(zip(('passed','failed','ignored'),(sum(int(v[i]) for v in totals) for i in range(3))))
 for stream in ('stdout','stderr'):row[stream+'Sha256']=hashlib.sha256((out/(name+'.'+stream+'.log')).read_bytes()).hexdigest()
 receipt['steps'].append(row);(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(row),flush=True)
 assert code==0 and row['sourceUnchanged']
 if totals:assert row['totals']['failed']==row['totals']['ignored']==0 and row['totals']['passed']>=17
 if name=='model-tests':
  for test in ('explicit_linear_and_inverse_calibration_have_independent_numeric_references','stale_source_time_model_geometry_or_decoded_units_refuse_even_on_an_invalid_pixel','projected_fields_keep_crop_rotation_mirror_invalidity_and_exact_camera_identity','camera_z_projects_to_independent_orthographic_finite_and_infinite_depth_formulas','relative_depth_preserves_float_values_without_claiming_world_distance'):
   assert 'test '+test+' ... ok' in text,test
# Do not suppress pre-existing lints or edit unrelated model code. Compare full
# all-target JSON diagnostics against the exact clean parent using the same compiler.
from collections import Counter
baseline=root/'.worktrees/gltf-skin'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=baseline).decode().strip()==receipt['base']
def diagnostics(name,directory):
 cmd=['cargo','clippy','-p','motion-model','--all-targets','--no-deps','--locked','--offline','--message-format=json']
 with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
  lint_env=env.copy()
  if name=='model-clippy-parent':lint_env['CARGO_TARGET_DIR']=str(root/'target/depth-calibration-lint-parent9ffe')
  code=subprocess.run(cmd,cwd=directory,env=lint_env,stdout=stdout,stderr=stderr).returncode
 assert code==0, name
 found=[]
 for line in (out/(name+'.stdout.log')).read_text(encoding='utf-8').splitlines():
  try:value=json.loads(line)
  except ValueError:continue
  if value.get('reason')!='compiler-message' or value['target']['name'] not in ('motion_model','depth_calibration'):continue
  d=value['message']
  if d.get('code',{}):
   spans=[{k:s[k] for k in ('file_name','line_start','line_end','column_start','column_end','is_primary')} for s in d['spans']]
   found.append(dict(code=d['code']['code'],message=d['message'],level=d['level'],spans=spans))
 row=dict(name=name,command=cmd,exitCode=code,diagnostics=found,sourceUnchanged=source()==before)
 receipt['steps'].append(row);(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');assert row['sourceUnchanged']
 return found
expected=diagnostics('model-clippy-parent',baseline);actual=diagnostics('model-clippy-current',work)
key=lambda d:json.dumps(d,sort_keys=True)
assert Counter(map(key,actual))==Counter(map(key,expected)), 'new or changed Clippy diagnostic'
receipt['lintBoundary']=dict(parent=receipt['base'],unchangedDiagnostics=len(actual),newDiagnostics=0,strictWholeModelStatus='Strict -D warnings failed on existing baseline; no allowances or unrelated source fixes applied. Non-strict all-target Clippy succeeded with exact baseline diagnostic equality.')
receipt['completedUtc']=datetime.now(timezone.utc).isoformat();(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
