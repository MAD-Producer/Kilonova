//! External acceptance only: actual Session/ONNX result through the native seed.
use crate::Result;
use glam::{Mat4, Vec3};
use motion_model::{CameraPose, ProjectionKind, depth::*};
use motion_render::{Renderer, scene_gpu::{GpuScene, SceneGpuLimits, SceneRequest, ScenePass, ScenePassFrame, ScenePassInstance, SceneDepthInput}};
use std::{fs, path::Path, sync::Arc};

struct NoResources;
impl motion_scene::AssetResolver for NoResources {
    fn read(&mut self, _: &str, _: motion_scene::ResourceKind, _: usize) -> std::io::Result<Vec<u8>> {
        Err(std::io::Error::other("independent quad has no external resources"))
    }
}
fn quad() -> Result<Arc<motion_scene::Scene>> {
    let mut bytes=Vec::new();
    for value in [-1f32,-1.,0.125, 1.,-1.,0.125, 1.,1.,0.125, -1.,1.,0.125] { bytes.extend(value.to_le_bytes()); }
    for value in [0u16,1,2,0,2,3] { bytes.extend(value.to_le_bytes()); }
    let doc=serde_json::json!({"asset":{"version":"2.0"},"buffers":[{"byteLength":bytes.len()}],
        "bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":48},{"buffer":0,"byteOffset":48,"byteLength":12}],
        "accessors":[{"bufferView":0,"componentType":5126,"count":4,"type":"VEC3","min":[-1,-1,0.125],"max":[1,1,0.125]},
            {"bufferView":1,"componentType":5123,"count":6,"type":"SCALAR"}],
        "materials":[{"emissiveFactor":[1,0,0],"pbrMetallicRoughness":{"metallicFactor":0}}],
        "meshes":[{"primitives":[{"attributes":{"POSITION":0},"indices":1,"material":0}]}],
        "nodes":[{"mesh":0}],"scenes":[{"nodes":[0]}],"scene":0});
    let json=serde_json::to_vec(&doc)?;
    let json_len=json.len().next_multiple_of(4);let bin_len=bytes.len().next_multiple_of(4);
    let mut glb=Vec::new();
    for value in [0x46546c67u32,2,(12+8+json_len+8+bin_len) as u32,json_len as u32,0x4e4f534a] { glb.extend(value.to_le_bytes()); }
    glb.extend(json);glb.resize(12+8+json_len,b' ');
    glb.extend((bin_len as u32).to_le_bytes());glb.extend(0x004e4942u32.to_le_bytes());glb.extend(bytes);glb.resize(12+8+json_len+8+bin_len,0);
    Ok(Arc::new(motion_scene::import(motion_scene::ImportContext { request: 740087, source: 7401 },&glb,&mut NoResources,&Default::default())?))
}
fn read(renderer:&Renderer, texture:&motion_render::AdmittedTexture, aspect:wgpu::TextureAspect, bpp:u32) -> Result<Vec<u8>> {
    let width=texture.width();let height=texture.height();let stride=(width*bpp).div_ceil(256)*256;
    let buffer=renderer.allocation_context().buffer(&wgpu::BufferDescriptor { label:Some("actual calibrated result readback"),size:u64::from(stride)*u64::from(height),usage:wgpu::BufferUsages::COPY_DST|wgpu::BufferUsages::MAP_READ,mapped_at_creation:false })?;
    let mut encoder=renderer.allocation_command_encoder(&Default::default())?;
    encoder.copy_texture_to_buffer(wgpu::TexelCopyTextureInfo { texture,mip_level:0,origin:wgpu::Origin3d::ZERO,aspect },
        wgpu::TexelCopyBufferInfo { buffer:&buffer,layout:wgpu::TexelCopyBufferLayout { offset:0,bytes_per_row:Some(stride),rows_per_image:Some(height) } },
        wgpu::Extent3d { width,height,depth_or_array_layers:1 });
    renderer.submit_allocated(encoder.finish(), |_|{})?;
    let (tx,rx)=std::sync::mpsc::sync_channel(1);
    buffer.slice(..).map_async(wgpu::MapMode::Read,move |value|{let _=tx.send(value);});
    renderer.device.poll(wgpu::PollType::wait_indefinitely())?;rx.recv()??;
    let mapped=buffer.slice(..).get_mapped_range()?;
    let values=mapped.chunks_exact(stride as usize).flat_map(|row|row[..(width*bpp) as usize].iter().copied()).collect();
    drop(mapped);buffer.unmap();Ok(values)
}
pub fn prove(out:&Path, resource:&DepthResource) -> Result<()> {
    let descriptor=resource.descriptor();
    assert_eq!(descriptor.scale,1.);assert_eq!(descriptor.offset,0.);assert!(resource.validity().is_none());
    assert_eq!(descriptor.geometry,DepthGeometry { source_size:[96,64],crop:[7,5,80,52],quarter_turns:1,mirror_x:true });
    assert_eq!(descriptor.size,[52,80]);
    assert!(resource.camera_z_meters(0,None).is_err(),"raw relative inference must never become metres implicitly");
    let low=resource.values().iter().copied().reduce(f32::min).ok_or("empty inference")? as f64;
    let high=resource.values().iter().copied().reduce(f32::max).ok_or("empty inference")? as f64;
    assert!(low.is_finite() && high.is_finite() && high>low);
    // Supplied illustrative anchors; this is not a measured accuracy claim.
    let calibration=RelativeDepthCalibration::new(descriptor.clone(),[
        DepthAnchor { value:low,camera_z_meters:4. },DepthAnchor { value:high,camera_z_meters:2. }
    ],CalibrationCurve::CameraZ,CalibrationExtrapolation::Reject)?;
    let eye=Vec3::new(0.,0.,3.);
    let camera=CameraPose { eye,target:Vec3::ZERO,projection:ProjectionKind::Orthographic,
        view_projection:Mat4::orthographic_rh(-1.,1.,-1.,1.,0.1,10.)*Mat4::look_at_rh(eye,Vec3::ZERO,Vec3::Y) };
    let projected=ProjectedDepth::from_calibrated(&calibration.bind(resource)?,DepthProjection::new(camera,1.)?,[96,64])?;
    let renderer=pollster::block_on(Renderer::headless())?;
    let target=renderer.render_target(96,64)?;
    let request=SceneRequest { request:740087,source:74 };
    let mut source=GpuScene::upload(&renderer,request,quad()?,SceneGpuLimits::default())?;
    let mut instance=ScenePassInstance::new(0,request,0,1.);instance.lights=&[];instance.ambient=[0.;3];
    let frame=ScenePassFrame::new(camera);let mut pass=ScenePass::new(&renderer,4)?;
    let input=SceneDepthInput { field:&projected,source:&descriptor.source,pixels_per_metre:1. };
    let stats=pass.draw_with_depth(&renderer,request,&target,&mut [&mut source],&[instance],&frame,&input)?;
    assert_eq!(stats.depth_input_bytes,96*64*8+16);
    // RenderTarget stores its admitted texture privately; use the admitted view
    // through an explicit buffer copy for color, as in native acceptance tests.
    let stride=(96u32*4).div_ceil(256)*256;
    let buffer=renderer.allocation_context().buffer(&wgpu::BufferDescriptor {label:Some("actual calibrated color"),size:u64::from(stride)*64,usage:wgpu::BufferUsages::COPY_DST|wgpu::BufferUsages::MAP_READ,mapped_at_creation:false})?;
    let mut encoder=renderer.allocation_command_encoder(&Default::default())?;
    encoder.copy_texture_to_buffer(target.view.texture().as_image_copy(),wgpu::TexelCopyBufferInfo { buffer:&buffer,layout:wgpu::TexelCopyBufferLayout {offset:0,bytes_per_row:Some(stride),rows_per_image:Some(64)}},wgpu::Extent3d {width:96,height:64,depth_or_array_layers:1});
    renderer.submit_allocated(encoder.finish(), |_|{})?;
    let(tx,rx)=std::sync::mpsc::sync_channel(1);buffer.slice(..).map_async(wgpu::MapMode::Read,move|r|{let _=tx.send(r);});
    renderer.device.poll(wgpu::PollType::wait_indefinitely())?;rx.recv()??;
    let mapped=buffer.slice(..).get_mapped_range()?;
    let color:Vec<u8>=mapped.chunks_exact(stride as usize).flat_map(|r|r[..96*4].iter().copied()).collect();drop(mapped);buffer.unmap();
    let depth_bytes=read(&renderer,pass.depth().ok_or("no hardware depth")?,wgpu::TextureAspect::DepthOnly,4)?;
    let actual:Vec<f32>=depth_bytes.chunks_exact(4).map(|b|f32::from_le_bytes(b.try_into().unwrap())).collect();
    let mut occluded=0;let mut visible=0;let mut cropped=0;let mut worst=0f64;
    for y in 0..64usize { for x in 0..96usize {
        let inside=(7..87).contains(&x)&&(5..57).contains(&y);
        // Independent discrete inverse of 90deg+mirror: (depth_x,depth_y)=(y-5,x-7).
        let z=if inside { let v=resource.values()[(x-7)*52+(y-5)] as f64;4.-2.*(v-low)/(high-low) }else{f64::INFINITY};
        assert!((z-2.875).abs()>1e-6,"ambiguous analytical occlusion boundary");
        let show=z>=2.875;
        if !inside {cropped+=1;} else if show {visible+=1;} else {occluded+=1;}
        let expected=if show{[255,0,0,255]}else{[0;4]};
        let index=y*96+x;
        assert_eq!(&color[index*4..][..4],&expected,"actual inference color pixel {x},{y}");
        let expected=(z.min(2.875)-0.1)/(10.-0.1);
        let error=(actual[index] as f64-expected).abs();worst=worst.max(error);
        assert!(error<1e-6,"actual inference hardware depth {x},{y} error={error}");
    }}
    assert!(visible>0&&occluded>0);assert_eq!(cropped,96*64-80*52);
    fs::write(out.join("calibrated-native.rgba"),&color)?;
    fs::write(out.join("calibrated-native-depth.f32"),depth_bytes)?;
    fs::write(out.join("calibration.json"),serde_json::to_vec_pretty(&calibration)?)?;
    // Actual default-level failure output retains source and actual sample PTS.
    let mut stale=descriptor.source.clone();stale.pts.ticks+=1;
    let bad=SceneDepthInput {field:&projected,source:&stale,pixels_per_metre:1.};
    let failure=pass.draw_with_depth(&renderer,request,&target,&mut [],&[],&frame,&bad).expect_err("stale real result must refuse");
    assert!(failure.to_string().contains("stale depth source/revision/PTS"));
    fs::write(out.join("calibrated-proof.json"),serde_json::to_vec_pretty(&serde_json::json!({
        "actualSessionOnnxResource":true,"actualNativeGpu":true,"source":descriptor.source,
        "pixelsVerified":6144,"visibleInsideCrop":visible,"occludedInsideCrop":occluded,"outsideCrop":cropped,
        "maxHardwareDepthAbsoluteError":worst,"depthInputBytes":stats.depth_input_bytes,
        "anchorsAreSuppliedIllustrationNotMetricAccuracy":true,"guiEngine":false,"projectRenderIntegration":false,
        "staleRealSampleRefusal":failure.to_string()
    }))?)?;
    Ok(())
}
