"""Rebuild only the external harness with standard worker ownership."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess

root=Path('E:/Dev/aem');work=root/'.worktrees/depth-calibration'
probe=root/'.tools/ai-depth74/calibration-probe'
out=root/'artifacts/pr-queue/depth-calibration-actual-probe-build-v5'
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((root/'artifacts/pr-queue/depth-calibration-actual-probe-build-v4/built.json').read_text(encoding='utf-8'))
native=json.loads((root/'artifacts/pr-queue/depth-calibration-native-v2/accepted.json').read_text(encoding='utf-8'))
assert prior['productSource']==native['source']
assert all(sha(work/p)==h for p,h in native['source'].items())
source={p:sha(probe/p) for p in prior['source']}
for p in source:
    dest=out/'probe-source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(probe/p,dest)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/ai-depth74-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_NET_OFFLINE='true')
cmd=['cargo','build','--locked','--offline']
receipt=dict(startedUtc=datetime.now(timezone.utc).isoformat(),productSource=native['source'],source=source,
    nativeGpuExecuted=False,scope='External harness only: independent native Renderer follows normal desktop Engine worker ownership; default standard thread stack, no stack override, unchanged product source and test bounds')
with (out/'build.stdout.log').open('wb') as so,(out/'build.stderr.log').open('wb') as se:
    code=subprocess.run(cmd,cwd=probe,env=env,stdout=so,stderr=se).returncode
receipt['steps']=[dict(name='build',command=cmd,exitCode=code,productSourceUnchanged=all(sha(work/p)==h for p,h in native['source'].items()))]
(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
assert code==0 and receipt['steps'][0]['productSourceUnchanged']
assert all(sha(probe/p)==h for p,h in source.items())
binary=root/'target/ai-depth74-contract/debug/motion-depth74-calibration-probe.exe'
receipt.update(binarySha256=sha(binary),completedUtc=datetime.now(timezone.utc).isoformat())
(out/'built.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(built=True,productSourceUnchanged=True,nativeGpuExecuted=False)),flush=True)
