from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

root = Path('E:/Dev/aem')
work = root / '.worktrees/ai-depth'
out = root / 'artifacts/pr-queue/issue74-session-v1'
out.mkdir(exist_ok=False)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip()
assert head.startswith('b358db06')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=work)

def source():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=work).decode().split('\0')
    return {p: hashlib.sha256((work / p).read_bytes()).hexdigest() for p in paths
            if p and (p.endswith(('.rs', '.py', '.toml')) or p == 'Cargo.lock')}

before = source()
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_TARGET_DIR=str(root / 'target/ai-depth74-contract'), CARGO_BUILD_JOBS='1',
           CARGO_INCREMENTAL='0', CARGO_NET_OFFLINE='true', CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0')
steps = [
    ('session', ['cargo', 'test', '-p', 'motion-host', '--no-default-features', '--features',
                 'ai-depth', '--test', 'depth_session', '--locked', '--offline', '--', '--test-threads=1'], 8),
    ('jobs', ['cargo', 'test', '-p', 'motion-host', '--no-default-features', '--features',
              'ai-depth', '--test', 'depth_jobs', '--locked', '--offline', '--', '--test-threads=1'], 6),
    ('onnx-unit', ['cargo', 'test', '-p', 'motion-host', '--no-default-features', '--features',
                   'ai-depth', '--lib', 'depth::onnx::tests::', '--locked', '--offline', '--', '--test-threads=1'], 4),
    ('default-host', ['cargo', 'check', '-p', 'motion-host', '--no-default-features', '--locked', '--offline'], None),
]
receipt = dict(head=head, source=before, controllerPid=os.getpid(), steps=[], motionLog=None,
               scope='Native CPU Session+Jobs+optional ONNX protocol; not real model inference or UI/depth compositing')
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
for name, command, expected in steps:
    print(json.dumps(dict(start=name)), flush=True)
    assert before == source()
    step = dict(name=name, command=command)
    with (out / f'{name}.stdout.log').open('wb') as stdout, (out / f'{name}.stderr.log').open('wb') as stderr:
        process = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
        step['pid'] = process.pid
        receipt['steps'].append(step)
        (out / 'started.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        step['exitCode'] = process.wait()
    step['sourceUnchanged'] = before == source()
    step['worktreeClean'] = not subprocess.check_output(['git', 'status', '--porcelain'], cwd=work)
    for stream in ('stdout', 'stderr'):
        step[f'{stream}Sha256'] = hashlib.sha256((out / f'{name}.{stream}.log').read_bytes()).hexdigest()
    (out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    assert step['sourceUnchanged'] and step['worktreeClean']
    if step['exitCode']:
        sys.exit(step['exitCode'])
    if expected is not None:
        rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (out / f'{name}.stdout.log').read_text(encoding='utf-8'))
        assert rows and all(int(r[1]) == 0 and int(r[2]) == 0 for r in rows)
        step['passed'] = sum(int(r[0]) for r in rows)
        assert step['passed'] == expected
    print(json.dumps(dict(done=name, passed=step.get('passed'))), flush=True)
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(passed=18, failed=0, ignored=0)), flush=True)
