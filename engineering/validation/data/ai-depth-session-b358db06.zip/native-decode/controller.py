from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root = Path('E:/Dev/aem')
work = root / '.worktrees/ai-depth'
probe = root / '.tools/ai-depth74/session-probe'
mode = sys.argv[1]
assert mode in ('decode-only', 'decode', 'hash', 'success')
out = root / 'artifacts/pr-queue' / f'issue74-session-native-{mode}-v1'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def source():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=work).decode().split('\0')
    values = {p: sha(work / p) for p in paths if p and (p.endswith(('.rs','.py','.toml')) or p == 'Cargo.lock')}
    for p in ('Cargo.toml', 'Cargo.lock', 'src/main.rs'):
        values['external-probe/' + p] = sha(probe / p)
    return values

before = source()
binary = root / 'target/ai-depth74-contract/debug/motion-depth74-session-probe.exe'
env = os.environ.copy()
env.pop('MOTION_LOG', None)
command = [str(binary), str(out), mode]
receipt = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip(),
               source=before, binarySha256=sha(binary), command=command, mode=mode, motionLog=None,
               actualInference=mode != 'decode-only')
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
(out / 'probe.rs').write_bytes((probe / 'src/main.rs').read_bytes())
(out / 'probe-Cargo.toml').write_bytes((probe / 'Cargo.toml').read_bytes())
(out / 'probe-Cargo.lock').write_bytes((probe / 'Cargo.lock').read_bytes())
with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
    process = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
    receipt['pid'] = process.pid
    (out / 'started.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    receipt['exitCode'] = process.wait(timeout=180)
receipt['sourceUnchanged'] = before == source()
receipt['worktreeClean'] = not subprocess.check_output(['git', 'status', '--porcelain'], cwd=work)
(out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
assert receipt['exitCode'] == 0 and receipt['sourceUnchanged'] and receipt['worktreeClean']
assert (out / 'stdout.log').read_bytes() == b''
log = (out / 'logs/motion-studio.log').read_text(encoding='utf-8')
stderr = (out / 'stderr.log').read_text(encoding='utf-8')
assert 'logging initialized level=INFO' in log
assert 'start #1 depth_infer asset=74' in log
if mode != 'success':
    for stream in (log, stderr):
        assert 'ERROR' in stream and 'request=1 operation=depth_infer asset=74' in stream
        assert 'phase=prepare_or_backend' in stream and 'cause=' in stream
    assert log.index('start #1 depth_infer') < log.index('ERROR')
    assert 'start #1' not in stderr and 'logging initialized' not in stderr
else:
    assert stderr == '' and 'ERROR' not in log
result = json.loads((out / 'accepted.json').read_text(encoding='utf-8'))
if mode == 'decode-only':
    assert result['inferenceEntered'] is False
else:
    assert result['maxNormalized'] <= 2e-4 and result['meanNormalized'] <= 2e-5
    assert result['provider'] == 'CPUExecutionProvider' and result['seekInvalidated']
receipt['result'] = result
receipt['artifacts'] = {str(p.relative_to(out)): sha(p) for p in out.rglob('*') if p.is_file()}
(out / 'verified.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(mode=mode, exit=0, defaultInfoStart=True, errorFileAndStderr=mode != 'success',
                      stdoutEmpty=True, actualInference=receipt['actualInference'], result=result)), flush=True)
