"""Retain actual full failure and new panic/Jobs gates without model payloads."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, zipfile

ROOT = Path('E:/Dev/aem')
ART = ROOT/'artifacts/pr-queue'
WORK = ROOT/'.worktrees/reference-depth76'
OUT = ART/'depth75-panic-retention-archive-v1'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
full = read(ART/'depth75-backend-workspace-v1/receipt.json')
native = read(ART/'depth75-panic-retention-v1/receipt.json')
jobs = read(ART/'depth75-shared-jobs-v3/receipt.json')
sequence = read(ART/'depth75-backend-sequence-v2/receipt.json')
assert full['completedUtc'] and full['sourceUnchanged']
assert native['status'] == 'new_panic_controls_and_actual_output_channels_passed_model_jobs_pending'
assert jobs['status'] == 'final_source_numerics_failures_cancel_and_stale_passed_video_and_full_regression_pending'
assert native['sourceUnchanged'] and jobs['sourceUnchanged']
assert sequence['sourceUnchanged'] and sequence['status'] == 'ordered_frame_backend_agreement_passed_quality_policy_and_video_acceptance_pending'
directories = ('depth75-backend-workspace-v1', 'depth75-panic-retention-v1',
               'depth75-shared-jobs-v3', 'depth75-backend-sequence-v2')
for directory in directories:
    consumed = read(ART/directory/'session-consumed.json')
    assert consumed['exitCode'] is not None
    if directory != 'depth75-backend-workspace-v1':
        assert consumed['exitCode'] == 0
expected = full['source'] | native['source']
assert expected == jobs['source']
assert expected == sequence['qualifiedSource']
assert all(sha(WORK/name) == value for name, value in expected.items())
assert not OUT.exists()
OUT.mkdir()
files = {'archive-controller.py': Path(__file__)}
for name in ('pr.json', 'receipt.json'):
    files['preceding-438a47eb-ci/'+name] = ART/'depth75-pr626-438a47eb-ci-v1'/name
for directory in directories:
    base = ART/directory
    for path in base.rglob('*'):
        relative = path.relative_to(base)
        if not path.is_file() or path.suffix not in ('.json', '.log', '.py', '.patch', '.rs', '.toml'):
            continue
        if any(part in ('scratch', 'appdata', 'weights', 'tensors', 'retained-binary') for part in relative.parts):
            continue
        if path.name == 'program.json' or path.name.startswith('ort-profile'):
            continue
        files['execution/'+directory+'/'+relative.as_posix()] = path
for name in native['source']:
    files['qualified-source/'+name] = WORK/name
for name in ('crates/motion-core/tests/format_version_boundaries.rs',
             'crates/motion-core/src/storage.rs', 'crates/motion-core/src/storage/publication.rs',
             'desktop/app/src/shell/project_precision_tests.rs', 'desktop/app/src/test_process.rs',
             'crates/motion-render/tests/compositions.rs', 'crates/motion-render/tests/exposure_sdr.rs',
             'crates/motion-render/tests/support/sdr_fixture.rs',
             'desktop/app/src/logging/sink.rs', 'crates/motion-host/src/depth/onnx.rs',
             'crates/motion-host/src/depth.rs', 'crates/motion-host/examples/wgsl_depth.rs',
             'crates/motion-desktop-media/tests/fixtures/professional-screen/source.json',
             'tools/ai_depth_onnx.py', 'tools/depth_tensor.py', 'Cargo.lock'):
    files['unchanged-base-source/'+name] = WORK/name
entries = {name: dict(bytes=path.stat().st_size, sha256=sha(path)) for name, path in sorted(files.items())}
archive = OUT/'depth75-panic-retention-v1.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(files.items()):
        z.writestr(name, path.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(entries)
    for name, row in entries.items():
        data = z.read(name)
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
manifest = dict(status='actual_panic_and_jobs_gates_archived_original_full_result_retained',
    createdUtc=datetime.now(timezone.utc).isoformat(), archive=archive.name,
    bytes=archive.stat().st_size, sha256=sha(archive), entries=entries,
    precedingFull=dict(baseCommit=full['baseCommit'], status=full['status'],
        totals=full.get('totals'), failedTestNames=full.get('failedTestNames'),
        fullTargetCoverageAccounted=full.get('fullTargetCoverageAccounted'),
        abnormalTargetExits=re.findall(r"^.*process didn't exit successfully:.*$",
            (ART/'depth75-backend-workspace-v1/stderr.log').read_text(encoding='utf-8', errors='replace'), re.M)),
    actualPanicChildren=native['rawChildren'], hostControls=11, originalAdmissionControls=31,
    actualNumerics=jobs['numerics'], actualFaults=jobs['faults'], actualCancel=jobs['cancel'],
    actualStale=jobs['stale'], nativeWorkerSha256=jobs['workerSha256'], driverSha256=jobs['driverSha256'],
    orderedFrameControl={name: sequence[name] for name in ('frames', 'numerics', 'gates',
        'temporalAllGpu', 'temporalMixed', 'injectedJumpControl', 'observerBackendSchedule', 'globalReferenceScale')},
    limits=['The original full test failure is retained without retries, assertion changes or waivers',
        'Selected panic/Jobs gates do not replace complete regression of the changed source or later rebase',
        'Five real test-child processes qualify the production hook; host parser tests are separate controls',
        'Actual model Jobs cover numerics, ordinary native failures, cancellation and stale results',
        'No product panic injection mode or forced-panic learned model is introduced',
        'Host retains bounded panic cause/location; the complete temporary native backtrace is not permanently archived',
        'One Vulkan GPU, two images and an authored crop sequence are not quality-tier, actual-video, thermal or cross-GPU acceptance',
        'No model, weights, raw image/tensor, executable/PDB or optional runtime payload is included'])
(OUT/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
for source, name in ((archive, archive.name), (OUT/'manifest.json', 'depth75-panic-retention-v1.json')):
    destination = WORK/'engineering/validation/data'/name
    assert not destination.exists()
    destination.write_bytes(source.read_bytes())
    assert sha(source) == sha(destination)
print(json.dumps({k: v for k, v in manifest.items() if k != 'entries'}))
