"""Deferred ordered-frame backend agreement; not quality-tier or video truth."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess, time, traceback

ROOT=Path('E:/Dev/aem'); WORK=ROOT/'.worktrees/reference-depth76'
ART=ROOT/'artifacts/pr-queue'; OUT=ART/'depth75-backend-sequence-v2'
FULL=ART/'depth75-backend-workspace-v1/receipt.json'
PYTHON=ROOT/'.tools/ai-depth74/venv/Scripts/python.exe'
MODEL=ROOT/'.tools/ai-depth74/models/depth_anything_v2_vits_518.onnx'
PROGRAM=ART/'depth75-static-program-v1/program.json'
WORKER=ROOT/'target/colmap88-isolated-check/debug/motion-depth-wgsl.exe'
DRIVER=ROOT/'target/colmap88-isolated-check/debug/examples/wgsl_depth.exe'
MAX=.0002; MEAN=.00002; FRAMES=12
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
full=json.loads(FULL.read_text(encoding='utf-8'))
assert full['status']!='running' and full.get('completedUtc') and full['sourceUnchanged'], 'Consume full native session before this separate sequence'
assert full['baseCommit'].startswith('438a47eb')
jobs_path=ART/'depth75-shared-jobs-v3/receipt.json'
jobs=json.loads(jobs_path.read_text(encoding='utf-8'))
assert jobs['status']=='final_source_numerics_failures_cancel_and_stale_passed_video_and_full_regression_pending'
assert jobs['sourceUnchanged'] and jobs['completedUtc']
assert json.loads((jobs_path.parent/'session-consumed.json').read_text())['exitCode']==0
expected_source=jobs['source']
assert all(sha(WORK/name)==digest for name,digest in expected_source.items())
assert sha(WORKER)==jobs['workerSha256'] and sha(DRIVER)==jobs['driverSha256']
assert not OUT.exists() and shutil.disk_usage(ROOT).free>=10<<30, 'Original measured disk admission'
assert sha(MODEL)=='274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
assert sha(PROGRAM)=='2ec1d8012905198cfd5af1430f88d1770edbf752531fe817dfcc65e1477fef6a'
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'):env.pop(name)
env.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
    TEMP=str(ROOT/'target/colmap88-isolated-check/tmp'),TMP=str(ROOT/'target/colmap88-isolated-check/tmp'),RUST_BACKTRACE='full')
report=dict(status='running_ordered_frame_backend_control',startedUtc=datetime.now(timezone.utc).isoformat(),
    source=full['baseCommit'],qualifiedSource=expected_source,sourceReceiptSha256=sha(FULL),nativeQualificationSha256=sha(jobs_path),workerSha256=sha(WORKER),driverSha256=sha(DRIVER),
    modelSha256=sha(MODEL),programSha256=sha(PROGRAM),frames=FRAMES,stages=[],numerics=[],
    gates=dict(maxNormalized=MAX,meanNormalized=MEAN,maxTemporalError=MAX*2,meanTemporalError=MEAN*2),
    limits=['Twelve authored pan/crop frames from an existing credited static photograph; not original video footage or depth truth',
        'Same Small model, resolution and processing for both backends; no fast/standard/high quality policy',
        'Fixed synthetic backend alternation is an observer control, not product scheduler or hysteresis acceptance',
        'One cold directly owned inference process per frame; not steady-state, interactive or thermal qualification',
        'Default Info, stdout protocol isolation, unchanged numerical gates, no affine fit or per-frame rescaling',
        'Original full-regression status remains separate, including any retained failures'])
def save():
    pending=OUT/'receipt.pending.json';pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(pending,OUT/'receipt.json')
def run(name,command):
    row=dict(name=name,command=list(map(str,command)),status='running');report['stages'].append(row);save();began=time.monotonic()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(row['command'],cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();code=child.wait()
    row.update(exitCode=code,status='passed' if code==0 else 'failed',elapsedSeconds=round(time.monotonic()-began,3));save()
    assert code==0,(name,code)
def temporal(actual,reference,scale,np):
    delta=(actual[1:]-actual[:-1])-(reference[1:]-reference[:-1])
    absolute=np.abs(delta)/scale
    maximum=float(absolute.max());mean=float(absolute.mean())
    return dict(maxNormalized=maximum,meanNormalized=mean,passed=maximum<=MAX*2 and mean<=MEAN*2)
began=time.monotonic();save()
try:
    import numpy as np
    from PIL import Image
    photo=WORK/'crates/motion-desktop-media/tests/fixtures/professional-screen/destiny-screen.png'
    assert sha(photo)=='e8ed893f990ba8850000064e153d57b84e6e1d5c0a0aa2ccc8dfd1254b2e379d'
    image=np.asarray(Image.open(photo).convert('RGB'));assert image.shape==(654,960,3)
    model=dict(id='dav2-small',revision='a561b849ebae10a6f5ef49e26c83cbbcd36c71bf',sha256=list(bytes.fromhex(sha(MODEL))),
        processing='dav2-small-rgb8-letterbox518-align-corners-relative-v1')
    references=[];predictions=[]
    for index in range(FRAMES):
        case=OUT/f'frame-{index:03}';case.mkdir();x=80+index*4;y=70+index*2;width=480;height=320
        rgb=image[y:y+height,x:x+width].copy().tobytes(order='C');(case/'input.rgb').write_bytes(rgb)
        key=dict(source=dict(asset=7512,revision=1,pts=dict(ticks=index*1001,timescale=24000)),
            geometry=dict(source_size=[960,654],crop=[x,y,width,height],quarter_turns=0,mirror_x=False),model=model)
        (case/'input.json').write_text(json.dumps(dict(key=key,size=[width,height],rgb='input.rgb'),indent=2)+'\n',encoding='utf-8')
        cpu=case/'cpu';cpu.mkdir();shutil.copyfile(case/'input.rgb',cpu/'input.rgb')
        (cpu/'request.json').write_text(json.dumps(dict(schema=1,model=str(MODEL),sha256=sha(MODEL),processing=model['processing'],
            width=width,height=height,provider='CPUExecutionProvider')),encoding='utf-8')
        run(f'{index:03}-cpu',[PYTHON,'-I','-B',WORK/'tools/ai_depth_onnx.py',cpu])
        cpu_report=json.loads((OUT/f'{index:03}-cpu.stdout.log').read_text());assert cpu_report['providers']==['CPUExecutionProvider']
        run(f'{index:03}-wgsl',[DRIVER,PYTHON,WORKER,PROGRAM,case/'scratch',case/'input.json',case/'gpu'])
        result=json.loads((case/'gpu/receipt.json').read_text())
        assert result['key']==key and result['descriptor']['source']==key['source'] and result['descriptor']['geometry']==key['geometry'] and result['descriptor']['model']==model
        assert result['in_flight_observed'] and result['in_flight_clear'] and result['queue_depth']==0
        assert result['counts']==dict(submitted=1,completed=1,failed=0,stale=0)
        fingerprint=hashlib.sha256(b'MotionStudio/depth/rgb8-srgb-opaque/v1\0'+width.to_bytes(4,'little')+height.to_bytes(4,'little')+rgb).digest()
        assert result['prepared']['rgb_sha256']==list(fingerprint) and result['prepared']['rgb_size']==[width,height]
        actual=np.frombuffer((case/'gpu/depth.f32').read_bytes(),dtype='<f4').astype(np.float64)
        reference=np.frombuffer((cpu/'output.f32').read_bytes(),dtype='<f4').astype(np.float64)
        assert len(actual)==len(reference)==width*height and np.isfinite(actual).all() and np.isfinite(reference).all()
        scale=max(float(np.abs(reference).max()),1e-6);error=np.abs(actual-reference)/scale
        row=dict(frame=index,pts=key['source']['pts'],crop=key['geometry']['crop'],rgbSha256=hashlib.sha256(rgb).hexdigest(),
            actualSha256=sha(case/'gpu/depth.f32'),referenceSha256=sha(cpu/'output.f32'),
            maxNormalized=float(error.max()),meanNormalized=float(error.mean()),normalizationScale=scale,
            sharedJobsReceiptSha256=sha(case/'gpu/receipt.json'),costs=result['costs_ns'],cpuCosts=cpu_report['costs_ns'])
        row['passed']=row['maxNormalized']<=MAX and row['meanNormalized']<=MEAN
        report['numerics'].append(row);save();assert row['passed'],row
        info=(case/'gpu/logs/motion-studio.log').read_text(encoding='utf-8')
        assert 'logging initialized level=INFO' in info and 'phase=native_inference start' in info and 'phase=remap start' in info
        assert not (OUT/f'{index:03}-wgsl.stdout.log').read_bytes() and not list((case/'scratch').iterdir())
        references.append(reference);predictions.append(actual)
    reference=np.stack(references);actual=np.stack(predictions);scale=max(float(np.abs(reference).max()),1e-6)
    # One scale for the entire ordered sequence; no frame-wise affine correction.
    report['temporalAllGpu']=temporal(actual,reference,scale,np);assert report['temporalAllGpu']['passed']
    use_gpu=np.array([(i//3)%2==1 for i in range(FRAMES)])
    mixed=np.where(use_gpu[:,None],actual,reference)
    report['observerBackendSchedule']=['wgsl' if flag else 'onnx-cpu' for flag in use_gpu]
    report['temporalMixed']=temporal(mixed,reference,scale,np);assert report['temporalMixed']['passed']
    bad=reference.copy();bad[FRAMES//2]+=scale*.01
    report['injectedJumpControl']=temporal(bad,reference,scale,np)
    assert not report['injectedJumpControl']['passed'],'Observer must reject a real backend-introduced jump'
    report['globalReferenceScale']=scale
    report['status']='ordered_frame_backend_agreement_passed_quality_policy_and_video_acceptance_pending'
except BaseException as error:
    report.update(status='failed_original_source_output_and_gate_retained',failure=repr(error),traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=all(sha(WORK/name)==digest for name,digest in expected_source.items()),
        completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3));save()
print(json.dumps({k:v for k,v in report.items() if k not in ('stages','traceback','numerics','qualifiedSource')}))
raise SystemExit(0 if report['status']=='ordered_frame_backend_agreement_passed_quality_policy_and_video_acceptance_pending' and report['sourceUnchanged'] else 1)
