"""Apply the reviewed proposal only after the original full run is consumed."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,re,shutil,subprocess,time,traceback
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/reference-depth76';ART=ROOT/'artifacts/pr-queue'
FULL=ART/'depth75-backend-workspace-v1/receipt.json'
PROPOSAL=ROOT/'target/silent-failure-validation/depth75-panic-retention-v1'
OUT=ART/'depth75-panic-retention-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
full=json.loads(FULL.read_text(encoding='utf-8'))
assert full['status']!='running' and full.get('completedUtc') and full['sourceUnchanged']
consumed=json.loads((FULL.parent/'session-consumed.json').read_text())
assert consumed['session']==7640 and consumed['exitCode'] is not None
assert shutil.disk_usage(ROOT).free>=10<<30,'Original admission; no cleanup or test started'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==full['baseCommit']
before=json.loads((PROPOSAL/'source-before.json').read_text())
assert all((sha(WORK/name) if (WORK/name).exists() else None)==value for name,value in before.items())
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
shutil.copyfile(PROPOSAL/'proposal-v8.patch',OUT/'applied.patch')
env=os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'):env.pop(name)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/colmap88-isolated-check'),
    CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full',TEMP=str(ROOT/'target/colmap88-isolated-check/tmp'),TMP=str(ROOT/'target/colmap88-isolated-check/tmp'),
    PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',LOCALAPPDATA=str(OUT/'appdata'))
report=dict(status='applying_then_running_new_panic_gates',startedUtc=datetime.now(timezone.utc).isoformat(),
    base=full['baseCommit'],precedingFullStatus=full['status'],precedingFullReceiptSha256=sha(FULL),
    proposalSha256=sha(PROPOSAL/'proposal-v8.patch'),stages=[],rawChildren=[],
    limits=['Source application follows terminal original full execution and actual tool-session consumption',
        'Original full failure(s) retained, not repaired, retried or waived by these selected gates',
        'No original assertion, ignore, GPU, feature or stack budget is weakened',
        'New real child failures run once more solely to retain independent raw file/stderr/stdout evidence lost by normal test-fixture cleanup',
        'No learned inference or second native workload runs concurrently; actual Jobs outputs are a later gate'])
def save():
    pending=OUT/'receipt.pending.json';pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(pending,OUT/'receipt.json')
def run(name,command,expected=0,extra=None):
    row=dict(name=name,command=list(map(str,command)),status='running');report['stages'].append(row);save();began=time.monotonic()
    child_env=env.copy();child_env.update(extra or {})
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(row['command'],cwd=WORK,env=child_env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();code=child.wait()
    row.update(exitCode=code,expectedExitCode=expected,status='expected' if code==expected else 'failed',elapsedSeconds=round(time.monotonic()-began,3));save()
    assert code==expected,(name,code,expected)
began=time.monotonic();save();source=None
try:
    subprocess.run(['git','apply','--check',str(OUT/'applied.patch')],cwd=WORK,check=True,env=env)
    subprocess.run(['git','apply',str(OUT/'applied.patch')],cwd=WORK,check=True,env=env)
    source={name:sha(WORK/name) for name in before}
    report['source']=source
    for name in source:
        destination=OUT/'frozen-source'/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes((WORK/name).read_bytes())
    save()
    run('host-tests',['cargo','test','-p','motion-host','--features','ai-depth','--locked','--lib','depth::wgsl::tests','--','--test-threads=1'])
    features='motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth'
    command=['cargo','test','-p','motion-desktop','--features',features,'--locked']
    for name in ('admission','convolution-admission','index-admission','graph-admission','panic'):command+=['--test','depth-worker-'+name]
    run('worker-tests',command+['--','--test-threads=1'])
    run('worker-build',['cargo','build','-p','motion-desktop','--features',features,'--locked','--bin','motion-depth-wgsl'])
    run('example-build',['cargo','build','-p','motion-host','--features','ai-depth','--locked','--example','wgsl_depth'])
    target=ROOT/'target/colmap88-isolated-check/debug'
    report.update(workerSha256=sha(target/'motion-depth-wgsl.exe'),driverSha256=sha(target/'examples/wgsl_depth.exe'))
    stderr=(OUT/'worker-tests.stderr.log').read_text(encoding='utf-8',errors='replace')
    matches=re.findall(r'^\s*Running [^\r\n]+\(([^\r\n]*depth_worker_panic-[a-f0-9]+\.exe)\)',stderr,re.M)
    assert len(matches)==1,matches
    executable=Path(matches[0]);dep=executable.with_suffix('.d').read_bytes()
    assert 'desktop/app/src/depth_worker/tests/panic.rs' in dep.decode('utf-8').replace('\\','/')
    report.update(panicTestSha256=sha(executable),panicTestDepInfoSha256=hashlib.sha256(dep).hexdigest())
    cases=[('fatal',False,False,False),('fatal-blocked',True,False,False),('caught',False,True,False),
        ('caught-blocked',True,True,False),('caught-then-fatal',False,False,True)]
    for name,blocked,caught,prelude in cases:
        root=OUT/('raw-'+name);root.mkdir()
        extra={'MOTION_DEPTH_WORKER_PANIC_CHILD':str(root)}
        if blocked:extra['MOTION_DEPTH_PANIC_BLOCK_RECEIPT']='1'
        if caught:extra['MOTION_DEPTH_PANIC_CAUGHT']='1'
        if prelude:extra['MOTION_DEPTH_PANIC_PRELUDE']='1'
        run('raw-'+name,[executable,'--exact','fatal_child_panic_retains_cause_without_changing_unwind_or_stdout','--nocapture','--test-threads=1'],0 if caught else 101,extra)
        text=(OUT/('raw-'+name+'.stderr.log')).read_text(encoding='utf-8')
        tail=text[-512:];sentinel='native-depth-original-panic-sentinel'
        assert sentinel in tail and 'at=' in tail and 'panic.rs:' in tail
        log=(root/'logs/motion-studio.log').read_text(encoding='utf-8')
        assert 'logging initialized level=INFO' in log and sentinel in log and ' ERROR ' in log
        stdout=(OUT/('raw-'+name+'.stdout.log')).read_text(encoding='utf-8')
        assert 'ERROR motion_depth_wgsl' not in stdout and 'panic command=' not in stdout
        if blocked:assert (root/'panic.json').is_dir() and 'panic receipt unavailable' in text
        else:
            receipt=json.loads((root/'panic.json').read_text(encoding='utf-8'))
            assert receipt['status']=='native_panic_original_cause_retained' and len(receipt['cause'])<=1536
            assert ('earlier-caught-panic' if prelude else sentinel) in receipt['cause']
        report['rawChildren'].append(dict(name=name,exitCode=0 if caught else 101,defaultFileError=True,defaultStderrError=True,
            logStdoutIsolated=True,final512RetainsCauseAndLocation=True,receiptBlocked=blocked,earlierCaught=prelude));save()
    summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',
        (OUT/'worker-tests.stdout.log').read_text(),re.M)
    assert len(summaries)==5 and sum(int(r[1]) for r in summaries)==32
    assert all(r[0]=='ok' and r[2]==r[3]==r[5]=='0' for r in summaries)
    assert '11 passed; 0 failed; 0 ignored;' in (OUT/'host-tests.stdout.log').read_text()
    report['status']='new_panic_controls_and_actual_output_channels_passed_model_jobs_pending'
except BaseException as error:
    report.update(status='failed_original_source_output_and_gate_retained',failure=repr(error),traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=source is not None and all(sha(WORK/name)==value for name,value in source.items()),
        completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3),freeBytesAfter=shutil.disk_usage(ROOT).free);save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','traceback')}))
raise SystemExit(0 if report['status']=='new_panic_controls_and_actual_output_channels_passed_model_jobs_pending' and report['sourceUnchanged'] else 1)
