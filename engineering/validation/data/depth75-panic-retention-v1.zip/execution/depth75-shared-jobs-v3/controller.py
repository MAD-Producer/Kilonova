"""Final-source GPU outputs, actual failures, owned-child cancel and stale guard."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,time,traceback
ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/reference-depth76'
OUT=ART/'depth75-shared-jobs-v3';OLD=ART/'depth75-shared-jobs-v1'
PRIOR=ART/'depth75-panic-retention-v1/receipt.json';TARGET=ROOT/'target/colmap88-isolated-check/debug'
PROGRAM=ART/'depth75-static-program-v1/program.json';PYTHON=ROOT/'.tools/ai-depth74/venv/Scripts/python.exe'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((OLD/'receipt.json').read_text());prior=json.loads(PRIOR.read_text())
assert prior['status']=='new_panic_controls_and_actual_output_channels_passed_model_jobs_pending' and prior['sourceUnchanged'] and prior['completedUtc']
consumed=json.loads((PRIOR.parent/'session-consumed.json').read_text())
assert consumed['exitCode']==0
full_path=ART/'depth75-backend-workspace-v1/receipt.json'
full=json.loads(full_path.read_text())
assert full['completedUtc'] and full['sourceUnchanged']
expected_source=full['source'] | prior['source']
assert all(sha(WORK/name)==digest for name,digest in expected_source.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==full['baseCommit']
assert sha(TARGET/'motion-depth-wgsl.exe')==prior['workerSha256']
assert sha(TARGET/'examples/wgsl_depth.exe')==prior['driverSha256']
assert old['status']=='two_real_shared_jobs_pipelines_passed_scheduling_and_video_acceptance_pending'
assert all(sha(WORK/name)==digest for name,digest in prior['source'].items())
assert not OUT.exists() and shutil.disk_usage(ROOT).free>=10<<30
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'):env.pop(name)
env.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',RUST_BACKTRACE='full',
    TEMP=str(ROOT/'target/colmap88-isolated-check/tmp'),TMP=str(ROOT/'target/colmap88-isolated-check/tmp'))
worker=TARGET/'motion-depth-wgsl.exe';driver=TARGET/'examples/wgsl_depth.exe'
report=dict(status='running_actual_job_controls',startedUtc=datetime.now(timezone.utc).isoformat(),source=expected_source,
    prerequisiteSha256=sha(PRIOR), precedingFullReceiptSha256=sha(full_path),referenceReceiptSha256=sha(OLD/'receipt.json'),workerSha256=sha(worker),driverSha256=sha(driver),
    stages=[],numerics=[],faults=[],limits=['Final native worker and real shared Jobs, not mocked successful results',
        'Two frozen CPU references reused after verifying their hashes; no repeated CPU inference',
        'One Vulkan hardware adapter; no video-quality transition, thermal or cross-desktop acceptance',
        'Original max2e-4/mean2e-5 bounds and failed full-workspace records unchanged'])
def save():
    p=OUT/'receipt.pending.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(p,OUT/'receipt.json')
def fixture(name,original='authored-portrait'):
    case=OUT/name;case.mkdir();shutil.copyfile(OLD/original/'input.json',case/'input.json');shutil.copyfile(OLD/original/'input.rgb',case/'input.rgb');return case
def launch(name,case,program=PROGRAM,mode=None):
    command=list(map(str,[driver,PYTHON,worker,program,case/'scratch',case/'input.json',case/'gpu']))+([mode] if mode else [])
    stdout=(OUT/(name+'.stdout.log')).open('wb');stderr=(OUT/(name+'.stderr.log')).open('wb')
    child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
    row=dict(name=name,command=command,pid=child.pid,status='running');report['stages'].append(row);save()
    return child,stdout,stderr,row,time.monotonic()
def finish(state,expected=0):
    child,stdout,stderr,row,began=state;code=child.wait();stdout.close();stderr.close()
    row.update(exitCode=code,status='expected' if code==expected else 'failed',elapsedSeconds=round(time.monotonic()-began,3));save()
    assert code==expected,(row,expected)
began=time.monotonic();save()
try:
    import numpy as np
    for name in ('authored-portrait','photo-crop-rotate-mirror'):
        case=fixture(name,name);finish(launch(name,case))
        original=next(row for row in old['cases'] if row['name']==name)
        reference=OLD/name/'cpu/output.f32';assert sha(reference)==original['referenceSha256']
        expected=np.frombuffer(reference.read_bytes(),dtype='<f4').astype(np.float64)
        output=case/'gpu/depth.f32';actual=np.frombuffer(output.read_bytes(),dtype='<f4').astype(np.float64)
        assert actual.shape==expected.shape and np.isfinite(actual).all()
        error=np.abs(actual-expected);scale=max(float(np.abs(expected).max()),1e-6)
        maximum=float(error.max())/scale;mean=float(error.mean())/scale
        row=dict(name=name,actualSha256=sha(output),referenceSha256=sha(reference),maxNormalized=maximum,meanNormalized=mean,passed=maximum<=.0002 and mean<=.00002)
        report['numerics'].append(row);save();assert row['passed']
        result=json.loads((case/'gpu/receipt.json').read_text());key=json.loads((case/'input.json').read_text())['key']
        assert result['key']==key and result['descriptor']['source']==key['source'] and result['descriptor']['geometry']==key['geometry']
        assert result['in_flight_clear'] and result['counts']==dict(submitted=1,completed=1,failed=0,stale=0)
        assert not (OUT/(name+'.stdout.log')).read_bytes() and not list((case/'scratch').iterdir())
    for fault in ('program-digest','resource-missing'):
        case=fixture('fault-'+fault);program=case/'program.json'
        program.write_bytes(PROGRAM.read_bytes()+(b' ' if fault=='program-digest' else b''))
        finish(launch('fault-'+fault,case,program),1)
        info=(case/'gpu/logs/motion-studio.log').read_text(encoding='utf-8')
        stderr=(OUT/('fault-'+fault+'.stderr.log')).read_text(encoding='utf-8')
        cause='pinned static program digest differs' if fault=='program-digest' else 'resource /blocks.0/attn/Constant_1_output_0'
        assert ' ERROR ' in info and cause in info and cause in stderr and 'native_receipt' in info
        assert not (OUT/('fault-'+fault+'.stdout.log')).read_bytes() and not list((case/'scratch').iterdir())
        report['faults'].append(dict(fault=fault,cause=cause,fileError=True,stderrError=True,stdoutEmpty=True));save()
    case=fixture('stale-source');finish(launch('stale-source',case,mode='stale'))
    stale=json.loads((case/'gpu/receipt.json').read_text());assert stale['status']=='actual_old_gpu_result_discarded' and stale['stale']==1 and stale['completed']==1
    assert not (case/'gpu/depth.f32').exists() and not list((case/'scratch').iterdir())
    report['stale']=stale;save()
    case=fixture('cancel-native');state=launch('cancel-native',case,mode='cancel');child=state[0]
    native_pid=None;native_handle=None
    import ctypes
    from ctypes import wintypes
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
    kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.WaitForSingleObject.restype=wintypes.DWORD
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    while child.poll() is None:
        for path in (case/'scratch').glob('motion-depth-wgsl-*/native/receipt.json'):
            try:value=json.loads(path.read_text(encoding='utf-8'))
            except (OSError,ValueError):continue
            if value.get('phase')=='read_hash_finite_upload_resource':
                native_pid=value['pid'];native_handle=kernel.OpenProcess(0x00100000,False,native_pid)
                assert native_handle and kernel.WaitForSingleObject(native_handle,0)==258,'Native child must actually be alive before cancellation'
                report['cancelEntry']=dict(nativePid=native_pid,phase=value['phase'],resource=value.get('resource'));save()
                (case/'gpu/cancel').write_bytes(b'cancel')
                break
        if native_pid is not None:break
        time.sleep(.005)
    assert native_pid is not None,'No live actual native upload observed; no passing cancellation claim'
    finish(state)
    try:assert kernel.WaitForSingleObject(native_handle,0)==0,'Owned native process still alive after backend cancellation'
    finally:kernel.CloseHandle(native_handle)
    canceled=json.loads((case/'gpu/receipt.json').read_text());assert canceled['status']=='actual_shared_jobs_cancellation_completed' and canceled['canceled']==1 and canceled['failed']==0
    assert not (case/'gpu/depth.f32').exists() and not list((case/'scratch').iterdir())
    assert not (OUT/'cancel-native.stdout.log').read_bytes()
    report['cancel']=canceled
    report['status']='final_source_numerics_failures_cancel_and_stale_passed_video_and_full_regression_pending'
except BaseException as error:
    report.update(status='failed_original_source_output_and_gate_retained',failure=repr(error),traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=all(sha(WORK/name)==digest for name,digest in expected_source.items()),completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3));save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','traceback')}))
raise SystemExit(0 if report['status']=='final_source_numerics_failures_cancel_and_stale_passed_video_and_full_regression_pending' and report['sourceUnchanged'] else 1)
