"""One complete maintained-workspace run of the committed optional backend."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, os, re, shutil, subprocess, time, traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/reference-depth76'
OUT = ROOT / 'artifacts/pr-queue/depth75-backend-workspace-v1'
assert shutil.disk_usage(ROOT).free >= 10 << 30, 'Original 10 GiB admission; no test started'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert head.startswith('438a47eb')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
names = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()
assert all((WORK / n).is_file() for n in names)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def identity():
    return {n: sha(WORK/n) for n in names if (WORK/n).is_file()}
source = identity()
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'): env.pop(name, None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),
    CARGO_TARGET_DIR=str(ROOT/'target/colmap88-isolated-check'),
    CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT/'appdata'),
    TEMP=str(ROOT/'target/colmap88-isolated-check/tmp'), TMP=str(ROOT/'target/colmap88-isolated-check/tmp'))
Path(env['TEMP']).mkdir(parents=True, exist_ok=True)
metadata = json.loads(subprocess.check_output(['cargo','metadata','--no-deps','--format-version','1','--locked'],cwd=WORK,env=env))
(OUT/'cargo-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
command = ['cargo','test','--workspace','--exclude','motion-android','--features',
    'motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth',
    '--no-fail-fast','--locked','--','--test-threads=1']
report = dict(status='running',baseCommit=head,main='daf806b5f29c2ec0a70e41068445230fb7b13585',
    startedUtc=datetime.now(timezone.utc).isoformat(),source=source,command=command,
    freeBytesBefore=shutil.disk_usage(ROOT).free,targetDirectory=env['CARGO_TARGET_DIR'],temporaryDirectory=env['TEMP'],
    limits=['No assertion, original ignore, GPU/backend, stack, feature or admission budget changes',
            'Complete maintained workspace; Android excluded by user',
            'One own serial native workload; no foreign process stopped or cache deleted',
            'Default Info; all controlled temp/cache/output on E',
            'Earlier #88 full regression two failures remain a separate source-bound result',
            'A native compilation failure or missing target cannot be called a full pass'])
def save():
    pending=OUT/'receipt.pending.json'
    pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    os.replace(pending,OUT/'receipt.json')
save(); began=time.monotonic()
try:
    with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        report['pid']=child.pid;save();code=child.wait()
    report['exitCode']=code
    stdout=(OUT/'stdout.log').read_text(encoding='utf-8',errors='replace')
    stderr=(OUT/'stderr.log').read_text(encoding='utf-8',errors='replace')
    summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
    executables=re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)',stderr,re.M)
    docs=re.findall(r'^\s*Doc-tests (\S+)\s*$',stderr,re.M)
    expected=[];by_name={};doc_owners={}
    for package in metadata['packages']:
        if package['id'] not in metadata['workspace_members'] or package['name']=='motion-android':continue
        for target in package['targets']:
            if not target['test']:continue
            relative=Path(target['src_path']).relative_to(WORK).as_posix()
            key=package['name']+'::'+target['kind'][0]+'::'+relative
            expected.append(key);by_name.setdefault(target['name'].replace('-','_'),[]).append((relative,key))
        if any(t['doctest'] for t in package['targets']):
            key='doc::'+package['name'];expected.append(key);doc_owners[package['name'].replace('-','_')]=key
    observed=[];bound=[]
    for executable in executables:
        path=Path(executable);dependency=path.with_suffix('.d');raw=dependency.read_bytes()
        line=raw.decode('utf-8').splitlines()[0].split(': ',1)[1].replace('\\','/')
        name=re.sub(r'-[a-f0-9]+$','',path.stem)
        owners=[key for relative,key in by_name[name] if re.search(r'(?<!\S)'+re.escape(relative)+r'(?!\S)',line)]
        assert len(owners)==1,(executable,owners)
        observed.extend(owners)
        bound.append(dict(executable=executable,target=owners[0],depInfoSha256=hashlib.sha256(raw).hexdigest()))
    observed.extend(doc_owners[name] for name in docs)
    report.update(totals=dict(passed=sum(int(s[1]) for s in summaries),failed=sum(int(s[2]) for s in summaries),
        originalIgnored=sum(int(s[3]) for s in summaries),filtered=sum(int(s[5]) for s in summaries),
        summaryCount=len(summaries),observedInvocations=len(observed),expectedInvocations=len(expected)),
        sourceBoundInvocations=bound,missingSourceTargets=dict(Counter(expected)-Counter(observed)),
        unexpectedSourceTargets=dict(Counter(observed)-Counter(expected)),
        fullTargetCoverageAccounted=Counter(expected)==Counter(observed) and len(summaries)==len(observed),
        failedTestNames=re.findall(r'^test ([^\r\n]+?) \.\.\. FAILED\s*$',stdout,re.M))
    report['status']='complete_maintained_workspace_passed' if code==0 and report['fullTargetCoverageAccounted'] and not report['totals']['failed'] and not report['totals']['filtered'] else 'failed_original_outputs_retained'
except BaseException as error:
    report.update(status='observer_failed_original_outputs_retained',failure=repr(error),traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=identity()==source and subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,
        completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3),freeBytesAfter=shutil.disk_usage(ROOT).free)
    report['logs']={n:dict(bytes=(OUT/n).stat().st_size,sha256=sha(OUT/n)) for n in ('stdout.log','stderr.log','cargo-metadata.json') if (OUT/n).exists()}
    save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','sourceBoundInvocations')}))
raise SystemExit(0 if report['status']=='complete_maintained_workspace_passed' and report['sourceUnchanged'] else 1)
