Actual Windows Release application source-texture budget study at 53f2b24ef3bfc8c97811a3cd6748f8e0949cbfa0.
Source bundle requires the existing main ancestor dec6fec0764ccab61ecf4460c76b5f2f6b98ac97.
The earlier sourcebc native failure remains failed and is archived separately.
Source53 corrected only the test Seek driver; identity checks and product policy were not relaxed.
One renderer/session/device, four authored 4K source files, actual budget refusals and full-quality recovery.
No physical VRAM exhaustion, playback FPS, complete GPU/readback coverage, Android acceptance or optimization gain.
Raw fixture videos and executables stay local; their hashes are retained.
Fresh-main delivery correctness gates are a separate source-bound record, not a performance rerun.
