$ErrorActionPreference = 'Stop'
Set-Location 'E:/Dev/aem/.worktrees/shared-menu-navigation'
. E:/Dev/aem/artifacts/multiple-camera-layers/env.ps1
$env:CARGO_TARGET_DIR = 'E:/Dev/aem/target/host-error-contract-verified'
$env:CARGO_BUILD_JOBS = '1'
$source = 'fcf5bfc49ac6460d5b3837be44a9debfcba39c8a'
$outputRoot = 'E:/Dev/aem/artifacts/pr-ci-followups/menu-cascade-correction/ci-followup'
New-Item -ItemType Directory -Force -Path $outputRoot | Out-Null
$results = [System.Collections.Generic.List[object]]::new()
function Assert-Source {
    if ((& git rev-parse HEAD).Trim() -ne $source) { throw 'source HEAD changed' }
    & git diff --quiet HEAD -- desktop crates
    if ($LASTEXITCODE -ne 0) { throw 'dirty implementation source' }
}
function Run-Check([string]$name, [string[]]$arguments) {
    Assert-Source
    Write-Output "start $name source=$source"
    $timer = [Diagnostics.Stopwatch]::StartNew()
    & cargo @arguments *> (Join-Path $outputRoot "$name.log")
    $status = $LASTEXITCODE
    Assert-Source
    $results.Add(@{ name=$name; source=$source; arguments=$arguments; exit=$status; elapsed_ms=$timer.ElapsedMilliseconds })
    $results | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 (Join-Path $outputRoot 'results.json')
    Write-Output "done $name exit=$status elapsed=$($timer.Elapsed)"
    if ($status -ne 0) { throw "$name failed; preserve its log" }
}
Run-Check 'property-selection' @('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','panels::key_navigation::tests::property_selection','--','--test-threads=1')
Run-Check 'menu-library' @('test','-p','motion-ui','--lib','--locked','--offline','widgets::menu::tests','--','--test-threads=1')
Run-Check 'style-integration' @('test','-p','motion-ui','--test','style','--locked','--offline','--','--test-threads=1')
Assert-Source
Write-Output "all checks passed source=$source"
