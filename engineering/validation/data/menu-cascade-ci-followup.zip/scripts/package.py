import hashlib
import json
import pathlib
import zipfile

root = pathlib.Path('E:/Dev/aem/artifacts/pr-ci-followups/menu-cascade-correction')
repo = pathlib.Path('E:/Dev/aem/.worktrees/shared-menu-navigation')
source = 'fcf5bfc49ac6460d5b3837be44a9debfcba39c8a'
results = json.loads((root / 'ci-followup-rebuilt/results.json').read_text(encoding='utf-8-sig'))
assert len(results) == 3 and all(r['exit'] == 0 and r['source'] == source for r in results)
files = {
    'ci/linux-original-failure.log': root / 'linux-ci-failure.log',
    'ci/macos-original-failure.log': root / 'macos-ci-failure.log',
    'local/stale-target-first.log': root / 'property-selection-ci-followup.log',
    'local/stale-target-second.log': root / 'ci-followup/property-selection.log',
    'scripts/stale-target-check.ps1': root / 'verify-ci-followup.ps1',
    'scripts/rebuilt-check.ps1': root / 'verify-ci-followup-rebuilt.ps1',
    'scripts/package.py': pathlib.Path(__file__),
    'source/property_selection.rs': repo / 'desktop/app/src/panels/key_navigation/tests/property_selection.rs',
}
for path in sorted((root / 'ci-followup-rebuilt').glob('*')):
    if path.is_file():
        files['verified/' + path.name] = path
payloads = {name: path.read_bytes() for name, path in files.items()}
manifest = {'source': source, 'checks': results, 'files': {
    name: {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    for name, data in payloads.items()
}}
payloads['manifest.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8')
target = repo / 'engineering/validation/data/menu-cascade-ci-followup.zip'
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(payloads.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(payloads)
    for name, data in payloads.items():
        assert archive.read(name) == data
digest = hashlib.sha256(target.read_bytes()).hexdigest()
summary = {'source': source, 'checks': results, 'archive': {
    'file': target.name, 'entries': len(payloads), 'bytes': target.stat().st_size, 'sha256': digest
}}
(repo / 'engineering/validation/menu-cascade-ci-followup-results.json').write_text(
    json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False))
