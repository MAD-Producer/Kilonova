"""Bounded, exact-head raw CI evidence for explicitly selected completed jobs."""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=int, required=True)
    parser.add_argument('--head', required=True)
    parser.add_argument('--job', action='append', required=True, help='name:job_number')
    parser.add_argument('--test', action='append', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = Path('E:/Dev/aem/artifacts/pr-queue').resolve()
    out = args.output.resolve()
    assert out.is_relative_to(root) and out != root
    assert re.fullmatch('[0-9a-f]{40}', args.head)
    jobs = []
    for specification in args.job:
        name, number = specification.split(':')
        assert re.fullmatch('[a-z0-9-]{1,64}', name) and number.isdecimal()
        jobs.append((name, int(number)))
    assert len(jobs) <= 8 and len({name for name, _ in jobs}) == len(jobs)
    assert len(args.test) <= 32 and all(re.fullmatch('[a-zA-Z0-9_:]{1,256}', test) for test in args.test)

    def api(path):
        return json.loads(subprocess.check_output(['gh', 'api', 'repos/MAD-Producer/Kilonova' + path], encoding='utf-8'))

    run = api(f'/actions/runs/{args.run}')
    assert run['head_sha'] == args.head and run['event'] == 'pull_request'
    metadata = {name: api(f'/actions/jobs/{number}') for name, number in jobs}
    assert all(row['run_id'] == args.run and row['status'] == 'completed' and row['conclusion'] == 'success'
               for row in metadata.values())
    out.mkdir(exist_ok=False)
    (out / 'controller.py').write_bytes(Path(__file__).read_bytes())
    report = dict(status='collecting', sourceCommit=args.head, run=args.run, invocation=vars(args) | {'output': str(out)},
        observedUtc=datetime.now(timezone.utc).isoformat(), jobs={}, verifiedTests={}, limits=[
            'Only explicitly selected completed jobs and exact named passing tests are qualified',
            'The complete workflow may still be running; this does not authorize merging before all checks pass',
            'No real model, video quality, thermal stability or integrated local full-feature regression is inferred'])

    def save():
        (out / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

    save()
    try:
        for name, number in jobs:
            (out / (name + '.job.json')).write_text(json.dumps(metadata[name], indent=2) + '\n', encoding='utf-8')
            target = out / (name + '.log')
            size = 0
            with target.open('xb') as output, (out / (name + '.download.stderr.log')).open('xb') as errors:
                child = subprocess.Popen(['gh', 'api', f'repos/MAD-Producer/Kilonova/actions/jobs/{number}/logs'],
                                         stdout=subprocess.PIPE, stderr=errors)
                try:
                    while block := child.stdout.read(64 << 10):
                        size += len(block)
                        assert size <= 32 << 20, 'Download exceeds budget; partial output retained'
                        output.write(block)
                    code = child.wait()
                except BaseException:
                    if child.poll() is None:
                        child.terminate()
                    child.wait()
                    raise
                finally:
                    child.stdout.close()
            assert code == 0 and size > 0
            report['jobs'][name] = dict(job=number, bytes=size, sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                downloadExit=code, url=metadata[name]['html_url'])
            lines = target.read_text(encoding='utf-8').splitlines()
            for test in args.test:
                matches = [line for line in lines if 'test ' + test + ' ... ok' in line]
                assert len(matches) == 1, (name, test, len(matches))
                report['verifiedTests'][name + '/' + test] = matches[0]
            save()
        assert api(f'/actions/runs/{args.run}')['head_sha'] == args.head
        report['status'] = 'selected_named_tests_verified_in_completed_exact_head_jobs'
    except BaseException as error:
        report.update(status='failed_original_outputs_retained', error=str(error)[:2048])
        raise
    finally:
        report['completedUtc'] = datetime.now(timezone.utc).isoformat()
        save()
    print(json.dumps(dict(status=report['status'], sourceCommit=args.head, jobs=report['jobs'], tests=len(report['verifiedTests']))))


if __name__ == '__main__':
    main()
