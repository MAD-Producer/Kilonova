use super::*;
use motion_ui::input::MouseButton;
use std::hint::black_box;
#[path = "E:/Dev/aem/.tools/node-height-combined/allocator.rs"]
mod allocator;
fn draw(editor:&mut NodeEditor,atlas:&mut TextAtlas,area:Rect,input:Input,language:Language)->String {
    let mut list=PaintList::default();
    let response=editor.draw(&mut list,atlas,area,&input,language);
    format!("{:?}\n{:?}\n{:?}\n{:?}\n{}\n{:?}\n{:?}\n{:?}\n",list.shapes,list.colors,list.glyphs,list.order,
        serde_json::to_string(&editor.document).unwrap(),editor.view,response.actions,
        (editor.revision,editor.semantic_revision,editor.preview_revision,editor.selected.clone(),editor.primary.clone(),editor.undo.len(),editor.redo.len()))
}
fn capture(editor:&mut NodeEditor,atlas:&mut TextAtlas,area:Rect,input:Input,language:Language,out:&std::path::Path,index:usize) {
    std::fs::write(out.join(format!("interaction-{language:?}-{index:02}.txt")),draw(editor,atlas,area,input,language)).unwrap();
}
#[test]
fn record_complete_node_frames_and_allocations() {
    assert!(allocator::measure(||{black_box(Box::new(7u64));}).0>0);
    let out=std::path::PathBuf::from(std::env::var_os("MOTION_NODE_CARD_HEIGHT_PROBE_OUT").unwrap());
    std::fs::create_dir_all(&out).unwrap();
    let mut records=vec![];
    for language in [Language::English,Language::Chinese] {
        let mut atlas=TextAtlas::from_system_language(12.,language==Language::Chinese).unwrap();
        for (count, defaults, collapsed, culled, broken) in [(4,false,false,false,false),(4,true,false,false,false),(4,false,true,false,false),(128,false,false,false,false),(128,false,false,true,false),(4,false,false,false,true),(4,false,true,false,true)] {
            for size in [[900.,600.],[1600.,1000.]] {
                let mut editor=if defaults {
                    let graph=motion_graph::builtin_examples().iter().find(|e|e.id=="compact_gradient").unwrap().load().unwrap();
                    let mut editor=NodeEditor::new(graph);editor.first_frame=false;editor.library_open=false;editor.view=CanvasView{pan:[30.,30.],zoom:1.};editor
                } else {tests::simple()};
                if count>4 {
                    let original=editor.document.nodes.iter().find(|n|n.id=="number").unwrap().clone();
                    editor.document.nodes=(0..count).map(|i| {
                        let mut node=original.clone();node.id=format!("number-{i}");
                        node.position=[(i%16) as f32*320.,(i/16) as f32*220.];node
                    }).collect();
                    editor.document.connections.clear();
                }
                if defaults {editor.set_input_default("gradient", "falloff", motion_graph::InputValue::Float(2.)).unwrap();assert!(editor.diagnostic().is_none());}
                if collapsed {editor.document.nodes.iter_mut().find(|n|n.id=="math").unwrap().collapsed=true;}
                if broken {
                    let node=editor.document.nodes.iter_mut().find(|n|n.id=="number").unwrap();
                    node.operation=motion_graph::NodeOp::Unsupported {feature:"height-probe-unsupported".into()};
                    node.collapsed=collapsed;
                }
                if culled {editor.view.pan=[-100000.;2];}
                let area=Rect::new(0.,0.,size[0],size[1]);
                let actual_count=editor.document.nodes.len();
                let before=editor.document.clone();
                for _ in 0..3 {black_box(draw(&mut editor,&mut atlas,area,Input{mouse:[-100.;2],..Default::default()},language));}
                let cost=allocator::measure(||for _ in 0..20 {
                    let mut list=PaintList::default();
                    black_box(editor.draw(&mut list,&mut atlas,area,&Input{mouse:[-100.;2],..Default::default()},language));
                    black_box(list);
                });
                assert_eq!(editor.document,before);
                let name=format!("{language:?}-{actual_count}-defaults{defaults}-collapsed{collapsed}-culled{culled}-broken{broken}-{}x{}.txt",size[0],size[1]);
                std::fs::write(out.join(&name),draw(&mut editor,&mut atlas,area,Input{mouse:[-100.;2],..Default::default()},language)).unwrap();
                records.push(serde_json::json!({"name":name,"nodes":actual_count,"defaults":defaults,"collapsed":collapsed,"culled":culled,"frames":20,"allocation_requests":cost.0,"requested_bytes":cost.1}));
            }
        }
        let mut editor=tests::simple();
        let area=Rect::new(0.,0.,1600.,1000.);
        capture(&mut editor,&mut atlas,area,Input::default(),language,&out,0);
        let mouse=[editor.last_canvas.min[0]+400.,editor.last_canvas.min[1]+250.];
        capture(&mut editor,&mut atlas,area,Input{mouse,wheel:[0.,30.],modifiers:motion_ui::input::Modifiers{control:true,..Default::default()},..Default::default()},language,&out,1);
        capture(&mut editor,&mut atlas,area,Input{mouse,wheel:[10.,25.],..Default::default()},language,&out,2);
        capture(&mut editor,&mut atlas,area,tests::press(mouse,MouseButton::Middle),language,&out,3);
        let end=[mouse[0]+35.,mouse[1]-15.];
        capture(&mut editor,&mut atlas,area,Input{mouse:end,held:Some(MouseButton::Middle),..Default::default()},language,&out,4);
        capture(&mut editor,&mut atlas,area,tests::release(end,MouseButton::Middle),language,&out,5);
        let point=editor.view.world_to_screen(editor.document.nodes.iter().find(|n|n.id=="number").unwrap().position,editor.last_canvas);
        let start=[point[0]+40.,point[1]+8.];let end=[start[0]+25.,start[1]+15.];
        let mut input=tests::press(start,MouseButton::Left);input.mouse=end;
        capture(&mut editor,&mut atlas,area,input,language,&out,6);
        capture(&mut editor,&mut atlas,area,tests::release(end,MouseButton::Left),language,&out,7);
        assert!(editor.undo());
        capture(&mut editor,&mut atlas,area,Input::default(),language,&out,8);
        editor.select(Some("number"),false);editor.select(Some("math"),true);
        assert!(editor.group_selected().unwrap());let group=editor.primary.clone().unwrap();
        assert!(editor.enter_group(&group));
        capture(&mut editor,&mut atlas,area,Input::default(),language,&out,9);
        editor.view=editor.parents.last().unwrap().view;
        let toolbar=editor.layout(area).toolbar;
        capture(&mut editor,&mut atlas,area,tests::press([toolbar.min[0]+45.,toolbar.max[1]-14.],MouseButton::Left),language,&out,10);
        assert!(editor.parents.is_empty());
        capture(&mut editor,&mut atlas,area,Input::default(),language,&out,11);
    }
    std::fs::write(out.join("records.json"),serde_json::to_vec_pretty(&records).unwrap()).unwrap();
    println!("20 static node frames plus 24 interaction frames recorded");
}
