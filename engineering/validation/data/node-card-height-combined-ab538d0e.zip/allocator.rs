use std::{alloc::{GlobalAlloc,Layout,System},cell::Cell};
thread_local! {static COUNTS:Cell<(bool,usize,usize)>=const {Cell::new((false,0,0))};}
struct ProbeAllocator;
fn note(bytes:usize) {
    let _=COUNTS.try_with(|state| {
        let (enabled,count,total)=state.get();
        if enabled {state.set((true,count.saturating_add(1),total.saturating_add(bytes)));}
    });
}
unsafe impl GlobalAlloc for ProbeAllocator {
    unsafe fn alloc(&self,layout:Layout)->*mut u8 {
        let pointer=unsafe{System.alloc(layout)};
        if !pointer.is_null(){note(layout.size());} pointer
    }
    unsafe fn alloc_zeroed(&self,layout:Layout)->*mut u8 {
        let pointer=unsafe{System.alloc_zeroed(layout)};
        if !pointer.is_null(){note(layout.size());} pointer
    }
    unsafe fn realloc(&self,pointer:*mut u8,layout:Layout,size:usize)->*mut u8 {
        let next=unsafe{System.realloc(pointer,layout,size)};
        if !next.is_null(){note(size);} next
    }
    unsafe fn dealloc(&self,pointer:*mut u8,layout:Layout){unsafe{System.dealloc(pointer,layout)}}
}
#[global_allocator]
static ALLOCATOR:ProbeAllocator=ProbeAllocator;
pub(crate) fn measure(work:impl FnOnce())->(usize,usize) {
    struct Reset;
    impl Drop for Reset {fn drop(&mut self){COUNTS.with(|state|state.set((false,0,0)));}}
    COUNTS.with(|state|state.set((true,0,0)));
    let reset=Reset;work();
    let counts=COUNTS.with(|state| {let (_,count,bytes)=state.get();(count,bytes)});
    drop(reset);counts
}
