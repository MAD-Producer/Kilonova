from pathlib import Path
import json,hashlib,subprocess,os,shutil,time,re
root=Path('E:/Dev/aem');out=root/'.tools/node-height-combined';work=root/'.worktrees/node-height-combined';proposal=root/'.worktrees/node-card-height'
load=lambda n:json.loads((out/n).read_text(encoding='utf8'))
def git(*args):return subprocess.check_output(['git',*args],cwd=work,text=True).strip()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for phase in ['before','after']:
 r=load(phase+'-receipt.json');assert r['exit_code']==0 and r['source_unchanged']
 log=(out/(phase+'.log')).read_text(encoding='utf8')
 assert 'Compiling motion-desktop v0.1.0 (E:\\Dev\\aem\\.worktrees\\node-height-combined\\desktop\\app)' in log
 assert '1 passed; 0 failed; 0 ignored' in log
old=load('before/records.json');new={r['name']:r for r in load('after/records.json')};assert len(old)==len(new)==28
rows=[dict(name=r['name'],frames=r['frames'],requests_saved=r['allocation_requests']-new[r['name']]['allocation_requests'],requested_bytes_saved=r['requested_bytes']-new[r['name']]['requested_bytes']) for r in old]
assert all(r['requests_saved']>=0 and r['requested_bytes_saved']>=0 for r in rows)
files=sorted(p.name for p in (out/'before').glob('*.txt'));assert len(files)==52 and files==sorted(p.name for p in (out/'after').glob('*.txt'))
assert all((out/'before'/n).read_bytes()==(out/'after'/n).read_bytes() for n in files)
comparison={'baseline':git('rev-parse','HEAD'),'scenes':28,'measured_frames':sum(r['frames'] for r in rows),'identical_snapshots':52,'allocation_requests_saved':sum(r['requests_saved'] for r in rows),'requested_bytes_saved':sum(r['requested_bytes_saved'] for r in rows),'all_cases_nonincreasing':True,'both_phases_compiled_actual_changed_sources':True,'rows':rows}
assert comparison['allocation_requests_saved']>0 and comparison['requested_bytes_saved']>0
binary=root/'target/debug/deps/motion_studio-d5bd28a41c2d0117.exe';assert digest(binary)!=load('excluded-stale-reason.json')['binary_sha256_before_forced_recompile']
(out/'comparison.json').write_text(json.dumps(comparison,indent=2),encoding='utf8')
source=work/'desktop/app/src/node_editor.rs';original=(out/'original-node-editor.rs').read_bytes();marker=b'\n#[cfg(test)]\n#[path = "E:/Dev/aem/.tools/node-height-combined/probe.rs"]\nmod card_height_probe;\n'
assert source.read_bytes()==original+marker;source.write_bytes(original)
assert set(git('diff','--name-only').splitlines())=={'desktop/app/src/node_editor/view/canvas.rs','desktop/app/src/node_editor/view/mod.rs'}
for p in ['desktop/app/src/node_editor.rs','desktop/app/src/node_editor/view/canvas.rs','desktop/app/src/node_editor/view/mod.rs']:
 expected=subprocess.check_output(['git','rev-parse','HEAD:'+p],cwd=proposal,text=True).strip();assert git('hash-object','--path='+p,p)==expected
subprocess.run(['git','add','--','desktop/app/src/node_editor/view/canvas.rs','desktop/app/src/node_editor/view/mod.rs'],cwd=work,check=True)
subprocess.run(['git','commit','-m','test(desktop): 固化卡片高度复用的组合验证代码'],cwd=work,check=True)
paths=['desktop/app/src/node_editor.rs','desktop/app/src/node_editor/view/canvas.rs','desktop/app/src/node_editor/view/mod.rs','desktop/app/src/shell/effect_timeline_acceptance.rs','desktop/app/src/shell/effect_timeline_acceptance/protocol_tests.rs','desktop/app/src/shell/effect_timeline_acceptance/tests.rs','desktop/ui/src/paint.rs','Cargo.lock','tools/ci_desktop.py']
sources={p:digest(work/p) for p in paths};frozen=lambda:all(digest(work/p)==h for p,h in sources.items())
intent={'head':git('rev-parse','HEAD'),'tree':git('show','-s','--format=%T','HEAD'),'sources':sources,'source_blobs':{p:git('rev-parse','HEAD:'+p) for p in paths},'public_proposal':subprocess.check_output(['git','rev-parse','HEAD'],cwd=proposal,text=True).strip()}
(out/'final-source.json').write_text(json.dumps(intent,indent=2),encoding='utf8')
base=['cargo','test','-p','motion-desktop','--bin','motion-studio','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1']
def execute(name,command,env=None,timeout=None):
 start=time.monotonic()
 with (out/(name+'.log')).open('w',encoding='utf8') as log:r=subprocess.run(command,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 record=dict(intent,command=command,exit_code=r.returncode,seconds=round(time.monotonic()-start,2),source_unchanged=frozen())
 (out/(name+'-receipt.json')).write_text(json.dumps(record,indent=2),encoding='utf8');assert r.returncode==0 and record['source_unchanged'];return record
execute('node-regressions',base+['node_editor::','--','--test-threads=1'])
assert '164 passed; 0 failed; 0 ignored' in (out/'node-regressions.log').read_text(encoding='utf8')
env=os.environ.copy();env.pop('MOTION_LOG',None);env['MOTION_EFFECT_CAPTURE_FAILURE_ARTIFACTS']=str(out/'failure-path')
execute('native-protocol-tests',[str(binary),'shell::effect_timeline_acceptance::','--test-threads=1','--nocapture'],env,180)
assert '3 passed; 0 failed; 0 ignored' in (out/'native-protocol-tests.log').read_text(encoding='utf8')
command=base.copy();command[1]='build'
execute('native-build',command)
folder=out/'native';folder.mkdir(exist_ok=False);native=folder/'motion-studio.exe';shutil.copy2(root/'target/debug/motion-studio.exe',native)
build=load('native-build-receipt.json');build['binary_sha256']=digest(native);(out/'native-build-receipt.json').write_text(json.dumps(build,indent=2),encoding='utf8')
s=(root/'.tools/node-labels-f9-integration/run_native_case.py').read_text(encoding='utf8').replace('E:/Dev/aem/.worktrees/node-labels-f9-integration','E:/Dev/aem/.worktrees/node-height-combined');(out/'run_native_case.py').write_text(s,encoding='utf8')
execute('minimum-zh-properties',['python',str(out/'run_native_case.py'),'minimum-zh-properties'],env,270)
print(json.dumps({k:v for k,v in comparison.items() if k!='rows'}),flush=True)
print('Final rebased sources: 164 node tests, 3 native protocol tests and minimum Chinese native GPU property capture passed.',flush=True)
