from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88';OUT=ROOT/'artifacts/pr-queue/tracking88-pair-native-v1'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
source={p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in set(paths) if (WORK/p).is_file()}
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','--',
    'engine::tracking_video_replacement_tests::paired::fresh_plate_and_solve_are_atomic_native_verified_undoable_and_reopenable','--exact','--test-threads=1','--nocapture']
report=dict(status='running',pid=os.getpid(),startedUtc=datetime.now(timezone.utc).isoformat(),source=source,command=command)
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2))
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',MOTION_TRACKED_PAIR_NATIVE_DIR=str(OUT))
save()
try:
    with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);report['childPid']=child.pid;save();report['exitCode']=child.wait()
    for p,h in source.items():assert hashlib.sha256((WORK/p).read_bytes()).hexdigest()==h,p
    assert report['exitCode']==0,report['exitCode']
    text=(OUT/'stdout.log').read_text(encoding='utf-8')
    assert '1 passed; 0 failed' in text,'native test did not execute'
    log=(OUT/'logs/motion-studio.log').read_text(encoding='utf-8');stderr=(OUT/'stderr.log').read_text(encoding='utf-8')
    assert 'tracked video replacement start request=pair-fresh' in log and ' INFO ' in log
    assert 'tracking source content differs' in log and 'tracking source content differs' in stderr
    report['status']='passed_native_pair_source_clock_gpu_history_reopen_default_logs'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
