from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-desktop-package-v1'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_snapshot():
    paths = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard'],
        cwd=WORK, text=True,
    ).splitlines()
    return {p: digest(WORK / p) for p in sorted(set(paths))
            if (p.endswith('.rs') or p.endswith('Cargo.toml') or p == 'Cargo.lock')
            and (WORK / p).is_file()}


env = os.environ.copy()
for key in ['MOTION_LOG', 'MOTION_TRACKED_PAIR_NATIVE_DIR',
            'MOTION_TRACKED_PAIR_AUDIO_DIR', 'MOTION_TRACKED_RPC_DIR']:
    env.pop(key, None)
env.update(
    CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
    CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0',
    CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1', RUST_BACKTRACE='full',
    MOTION_PRECISION_OUTPUT_ARTIFACTS=str(OUT / 'precision'),
)
command = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg',
           '--locked', '--offline', '--no-fail-fast', '--', '--test-threads=1']
started = time.monotonic()
report = dict(
    status='running', startedUtc=datetime.now(timezone.utc).isoformat(),
    head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip(),
    gitStatus=subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK, text=True),
    source=source_snapshot(), command=command,
    scope='Complete FFmpeg-enabled motion-desktop package; binary and all integration targets; existing ignored tests remain ignored; not workspace regression',
    environment={k: env.get(k) for k in ['CARGO_HOME', 'CARGO_TARGET_DIR',
        'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG',
        'CARGO_BUILD_JOBS', 'FFMPEG_DIR', 'RUST_BACKTRACE', 'MOTION_LOG',
        'MOTION_PRECISION_OUTPUT_ARTIFACTS']},
)


def save():
    temp = OUT / 'exit.pending.json'
    temp.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(temp, OUT / 'exit.json')


save()
try:
    with (OUT / 'package.stdout.log').open('wb') as stdout, (OUT / 'package.stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    report['sourceUnchanged'] = source_snapshot() == report['source']
    stdout_text = (OUT / 'package.stdout.log').read_text(encoding='utf-8', errors='replace')
    stderr_text = (OUT / 'package.stderr.log').read_text(encoding='utf-8', errors='replace')
    report['summaries'] = re.findall(r'^test result: .+$', stdout_text, flags=re.M)
    report['invokedTargets'] = re.findall(r'^\s*Running (.+)$', stderr_text, flags=re.M)
    expected = ['dock_frame_cache', 'effect_search_cache', 'effect_track_cache',
                'timeline_row_cache', 'timeline_scroll_signature']
    report['integrationTargetsConfirmed'] = {
        target: any(target in line for line in report['invokedTargets']) for target in expected
    }
    assert report['sourceUnchanged'], 'Rust/manifest source changed during regression'
    assert all(report['integrationTargetsConfirmed'].values()), 'missing integration target'
    assert report['exitCode'] == 0, ('cargo package regression failed', report['exitCode'])
    assert len(report['summaries']) == 6, ('expected binary and five integration summaries', report['summaries'])
    assert all('test result: ok.' in value for value in report['summaries']), report['summaries']
    report['status'] = 'full_desktop_package_passed_not_workspace_or_real_footage_quality'
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    report['elapsedSeconds'] = round(time.monotonic() - started, 3)
    report['logs'] = {name: digest(OUT / name) for name in ['package.stdout.log', 'package.stderr.log'] if (OUT / name).exists()}
    save()
    print(json.dumps({key: report.get(key) for key in ['status', 'head', 'exitCode', 'elapsedSeconds', 'summaries', 'integrationTargetsConfirmed']}, indent=2), flush=True)
