from pathlib import Path
import hashlib,json,os,subprocess,sys,time
out=Path(__file__).resolve().parent;work=Path('E:/Dev/aem/.worktrees/node-card-height');phase=sys.argv[1]
assert phase in ['before','after'] and not (out/(phase+'-receipt.json')).exists()
source=work/'desktop/app/src/node_editor.rs';canvas=work/'desktop/app/src/node_editor/view/canvas.rs'
marker=b'\n#[cfg(test)]\n#[path = "E:/Dev/aem/.tools/node-card-height/probe.rs"]\nmod card_height_probe;\n'
if phase=='before':
    assert subprocess.check_output(['git','status','--porcelain'],cwd=work,text=True).strip()==''
    (out/'original-node-editor.rs').write_bytes(source.read_bytes());(out/'original-canvas.rs').write_bytes(canvas.read_bytes());(out/'original-view-mod.rs').write_bytes((canvas.parent/'mod.rs').read_bytes())
    source.write_bytes(source.read_bytes()+marker)
assert source.read_bytes().endswith(marker)
if phase=='before-valid':
    assert canvas.read_bytes()==(out/'original-canvas.rs').read_bytes()
    assert source.read_bytes()==(out/'original-node-editor.rs').read_bytes()+marker
extra=['view/mod.rs','view/frame_cards_tests.rs','view/wire_target_tests.rs','view/wires/socket_index_tests.rs']
freeze=lambda:{'node_editor':hashlib.sha256(source.read_bytes()).hexdigest(),'canvas':hashlib.sha256(canvas.read_bytes()).hexdigest(),'probe':hashlib.sha256((out/'probe.rs').read_bytes()).hexdigest(),'allocator':hashlib.sha256((out/'allocator.rs').read_bytes()).hexdigest(),**{p:hashlib.sha256((canvas.parent.parent/p).read_bytes()).hexdigest() for p in extra}}
frozen=freeze();command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1','node_editor::card_height_probe::record_complete_node_frames_and_allocations','--','--exact','--test-threads=1','--nocapture']
env=os.environ.copy();env['CARGO_TERM_COLOR']='never';env['MOTION_NODE_CARD_HEIGHT_PROBE_OUT']=str(out/phase)
start=time.monotonic();log=out/(phase+'.log')
with log.open('w',encoding='utf-8') as stream:result=subprocess.run(command,cwd=work,stdout=stream,stderr=subprocess.STDOUT,env=env)
record=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),sources=frozen,source_unchanged=freeze()==frozen,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(out/(phase+'-receipt.json')).write_text(json.dumps(record,indent=2),encoding='utf-8');assert result.returncode==0 and record['source_unchanged'];print(json.dumps(record),flush=True)
