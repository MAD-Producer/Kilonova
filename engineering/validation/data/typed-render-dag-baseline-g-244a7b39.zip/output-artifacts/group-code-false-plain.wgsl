// Motion Studio .msgraph format 1; SDK 6 single-pass image target.
fn ng_div1(a:f32,b:f32)->f32{let d=select(max(b,f32(1.0e-6)),min(b,f32(-1.0e-6)),b<f32(0.0));return select(a/d,f32(0.0),abs(b)<=f32(1.0e-6));}
fn ng_smooth1(a:f32,b:f32,v:f32)->f32{let lo=min(a,b);let hi=max(a,b);let t=clamp((v-lo)/max(hi-lo,f32(1.0e-6)),f32(0.0),f32(1.0));return select(t*t*(f32(3.0)-f32(2.0)*t),select(f32(0.0),f32(1.0),v>=lo),hi-lo<=f32(1.0e-6));}
fn ng_div2(a:vec2<f32>,b:vec2<f32>)->vec2<f32>{let d=select(max(b,vec2<f32>(1.0e-6)),min(b,vec2<f32>(-1.0e-6)),b<vec2<f32>(0.0));return select(a/d,vec2<f32>(0.0),abs(b)<=vec2<f32>(1.0e-6));}
fn ng_smooth2(a:vec2<f32>,b:vec2<f32>,v:vec2<f32>)->vec2<f32>{let lo=min(a,b);let hi=max(a,b);let t=clamp((v-lo)/max(hi-lo,vec2<f32>(1.0e-6)),vec2<f32>(0.0),vec2<f32>(1.0));return select(t*t*(vec2<f32>(3.0)-vec2<f32>(2.0)*t),select(vec2<f32>(0.0),vec2<f32>(1.0),v>=lo),hi-lo<=vec2<f32>(1.0e-6));}
fn ng_div3(a:vec3<f32>,b:vec3<f32>)->vec3<f32>{let d=select(max(b,vec3<f32>(1.0e-6)),min(b,vec3<f32>(-1.0e-6)),b<vec3<f32>(0.0));return select(a/d,vec3<f32>(0.0),abs(b)<=vec3<f32>(1.0e-6));}
fn ng_smooth3(a:vec3<f32>,b:vec3<f32>,v:vec3<f32>)->vec3<f32>{let lo=min(a,b);let hi=max(a,b);let t=clamp((v-lo)/max(hi-lo,vec3<f32>(1.0e-6)),vec3<f32>(0.0),vec3<f32>(1.0));return select(t*t*(vec3<f32>(3.0)-vec3<f32>(2.0)*t),select(vec3<f32>(0.0),vec3<f32>(1.0),v>=lo),hi-lo<=vec3<f32>(1.0e-6));}
fn ng_to_straight(c:vec4<f32>)->vec4<f32>{return c;}
fn ng_from_straight(c:vec4<f32>)->vec4<f32>{return c;}
fn ng_rounded_rect(p:vec2<f32>,half_size:vec2<f32>,radius:f32)->f32{let h=max(half_size,vec2<f32>(0.0));let r=clamp(radius,0.0,min(h.x,h.y));let q=abs(p)-h+vec2<f32>(r);return length(max(q,vec2<f32>(0.0)))+min(max(q.x,q.y),0.0)-r;}
fn ng_segment(p:vec2<f32>,a:vec2<f32>,b:vec2<f32>)->f32{let ba=b-a;let h=clamp(dot(p-a,ba)/max(dot(ba,ba),1.0e-12),0.0,1.0);return length(p-a-ba*h);}
fn ng_smooth_union(a:f32,b:f32,k:f32)->f32{if k<=1.0e-6{return min(a,b);}let h=clamp(0.5+0.5*(b-a)/k,0.0,1.0);return mix(b,a,h)-k*h*(1.0-h);}
fn ng_fill(d:f32)->f32{let w=max(fwidth(d),1.0e-5);return 1.0-smoothstep(-w*0.5,w*0.5,d);}
fn ng_stroke(d:f32,width:f32)->f32{let w=max(fwidth(d),1.0e-5);let edge=abs(d)-max(width,0.0)*0.5;return 1.0-smoothstep(-w*0.5,w*0.5,edge);}

fn graph_fx(p:vec2<f32>)->vec4<f32>{
    let ng0:vec4<f32>=ng_from_straight(clamp(fx.params[2],vec4<f32>(0.0),vec4<f32>(1.0)));
    let ng1:vec2<f32>=clamp(fx.params[1].xy,vec2<f32>(-1.0e12),vec2<f32>(1.0e12));
    let ng2:f32=fx.clock.x;
    let ng3:f32=clamp(fx.params[3].x,f32(-1.0e12),f32(1.0e12));
    let ng4:f32=clamp((ng2*ng3),f32(-1.0e12),f32(1.0e12));
    let ng5:f32=0.0;
    let ng6:vec2<f32>=vec2<f32>(ng4,ng5);
    let ng7:vec2<f32>=clamp((ng1+ng6),vec2<f32>(-1.0e12),vec2<f32>(1.0e12));
    let ng8:vec2<f32>=p;
    let ng9:f32=clamp(fx.params[0].x,f32(-1.0e12),f32(1.0e12));
    let ng10:f32=length(ng8-ng7)-max(ng9,0.0);
    let ng11:f32=ng_fill(ng10);
    let ng12:vec4<f32>=vec4<f32>(ng0.rgb,ng0.a*clamp(ng11,0.0,1.0));
    return ng12;
}
