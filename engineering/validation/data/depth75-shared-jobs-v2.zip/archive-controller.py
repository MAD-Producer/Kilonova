"""Public numeric/log receipts only; model/media/scalar payloads stay private."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/reference-depth76'
OUT=ART/'depth75-shared-jobs-archive-v2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
native=read(ART/'depth75-host-backend-v2/receipt.json');final=read(ART/'depth75-shared-jobs-v2/receipt.json')
assert native['sourceUnchanged'] and final['sourceUnchanged']
assert final['status']=='final_source_numerics_failures_cancel_and_stale_passed_video_and_full_regression_pending'
assert final['source']==native['source'] and all(sha(WORK/name)==value for name,value in native['source'].items())
OUT.mkdir(exist_ok=False)
files={'archive-controller.py':Path(__file__)}
for name in native['source']:files['qualified-source/'+name]=ART/'depth75-host-backend-v2/frozen-source'/name
for name in ('Cargo.lock','tools/ai_depth_onnx.py'):files['unchanged-base-source/'+name]=WORK/name
for directory in ('depth75-host-backend-v1','depth75-host-backend-v2','depth75-shared-jobs-v1','depth75-shared-jobs-v2'):
    base=ART/directory
    for path in base.rglob('*'):
        if not path.is_file() or path.suffix not in ('.json','.log','.py','.patch'):continue
        relative=path.relative_to(base)
        if any(part in ('frozen-source','scratch','retained-binary','weights','tensors') for part in relative.parts):continue
        if path.name.startswith('ort-profile'):continue
        # The identical metadata blueprint is already in the research archive.
        if path.name=='program.json':continue
        files['execution/'+directory+'/'+relative.as_posix()]=path
for name in ('crates/motion-host/src/depth/wgsl.rs','crates/motion-host/src/depth/wgsl/tests.rs','crates/motion-host/examples/wgsl_depth.rs'):
    files['preceding-v1-source/'+name]=ART/'depth75-host-backend-v1/frozen-source'/name
files['existing-photograph-source.json']=WORK/'crates/motion-desktop-media/tests/fixtures/professional-screen/source.json'
entries={name:dict(bytes=path.stat().st_size,sha256=sha(path)) for name,path in sorted(files.items())}
archive=OUT/'depth75-shared-jobs-v2.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(files.items()):z.writestr(name,path.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(entries)
    for name,row in entries.items():
        raw=z.read(name);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
manifest=dict(status='actual_optional_host_backend_evidence_archived_full_and_ci_pending',createdUtc=datetime.now(timezone.utc).isoformat(),
    archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),entries=entries,
    nativeHostTests=6,unchangedWorkerAdmissionTests=31,unchangedLoggerRegressionTests=7,pythonTransformTests=3,
    actualNumerics=final['numerics'],actualFaults=final['faults'],actualCancel=final['cancel'],actualStale=final['stale'],
    nativeWorkerSha256=final['workerSha256'],acceptanceDriverSha256=final['driverSha256'],
    limits=['Optional explicit host backend, not default installation, interactive quality policy or video switching',
        'Both earlier qualification and final-source execution retained; static source equality does not rerun unchanged gates',
        'One Vulkan GPU; numerical equivalence to a model is not physical depth truth',
        'Raw learned tensors, input/photograph/reference/output data, model, executable/PDB and runtimes excluded',
        'Existing photograph attribution retained; no third-party image is added to product/release resources',
        'Remaining complete regression and exact-head cross-platform CI are separate gates',
        'Original #88 full regression failed two tests and is not repaired by this evidence'])
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for source,name in ((archive,archive.name),(OUT/'manifest.json','depth75-shared-jobs-v2.json')):
    destination=WORK/'engineering/validation/data'/name;assert not destination.exists();destination.write_bytes(source.read_bytes());assert sha(source)==sha(destination)
print(json.dumps({k:v for k,v in manifest.items() if k not in ('entries',)}))
