"""One serial native qualification attempt; source frozen until terminal."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,time,traceback
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/reference-depth76'
OUT=ROOT/'artifacts/pr-queue/depth75-host-backend-v1'
assert not OUT.exists()
assert shutil.disk_usage(ROOT).free>=10<<30,'Original start gate; no local cleanup'
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'):env.pop(name)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/colmap88-isolated-check'),
    CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
    TEMP=str(ROOT/'target/colmap88-isolated-check/tmp'),TMP=str(ROOT/'target/colmap88-isolated-check/tmp'),
    PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',RUST_BACKTRACE='full')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def source():
    names=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard','-z'],cwd=WORK).decode().split('\0')
    return {name:sha(WORK/name) for name in names if name and (WORK/name).is_file()}
before=source()
for name in before:
    path=OUT/'frozen-source'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((WORK/name).read_bytes())
(OUT/'changes.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=WORK))
report=dict(status='running_serial_native_gates',startedUtc=datetime.now(timezone.utc).isoformat(),source=before,
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),stages=[],
    limits=['Selected new host/worker tests and existing logger regressions, not a complete workspace pass',
            'No model or actual GPU inference is performed by these admission/build gates',
            'Original #88 full regression failed two tests; no retry or waiver'])
def save():
    p=OUT/'receipt.pending.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(p,OUT/'receipt.json')
began=time.monotonic();save()
try:
    commands=[('host-tests',['cargo','test','-p','motion-host','--features','ai-depth','--locked','--lib','depth::wgsl::tests','--','--test-threads=1']),
        ('worker-admission',['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth','--locked',
            '--test','depth-worker-admission','--test','depth-worker-convolution-admission','--test','depth-worker-index-admission','--test','depth-worker-graph-admission','--','--test-threads=1']),
        ('worker-build',['cargo','build','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth','--locked','--bin','motion-depth-wgsl']),
        ('host-example-build',['cargo','build','-p','motion-host','--features','ai-depth','--locked','--example','wgsl_depth']),
        ('existing-logger',['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth','--locked','--bin','motion-studio','logging::tests::','--','--test-threads=1'])]
    for name,command in commands:
        row=dict(name=name,command=command,status='running');report['stages'].append(row);save();start=time.monotonic()
        with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
            child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();code=child.wait()
        row.update(status='passed' if code==0 else 'failed',exitCode=code,elapsedSeconds=round(time.monotonic()-start,3));save()
        assert code==0,(name,code)
    report['status']='selected_native_gates_passed_actual_backend_execution_pending'
except BaseException as error:
    report.update(status='failed_original_source_and_output_retained',failure=repr(error),traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=source()==before,completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3));save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','traceback')}))
raise SystemExit(0 if report['status']=='selected_native_gates_passed_actual_backend_execution_pending' and report['sourceUnchanged'] else 1)
