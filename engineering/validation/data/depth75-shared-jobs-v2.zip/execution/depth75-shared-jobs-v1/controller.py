"""Deferred two real CPU/GPU pipelines through product Jobs; no parallel inference."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,shutil,subprocess,time,traceback
ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/reference-depth76'
OUT=ART/'depth75-shared-jobs-v1';PREVIOUS=ART/'depth75-host-backend-v1/receipt.json'
MODEL=ROOT/'.tools/ai-depth74/models/depth_anything_v2_vits_518.onnx'
PROGRAM=ART/'depth75-static-program-v1/program.json'
TARGET=ROOT/'target/colmap88-isolated-check/debug'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads(PREVIOUS.read_text())
assert previous['status']=='selected_native_gates_passed_actual_backend_execution_pending' and previous['sourceUnchanged'] and previous['completedUtc']
assert all(sha(WORK/name)==value for name,value in previous['source'].items())
assert not OUT.exists() and shutil.disk_usage(ROOT).free>=10<<30
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'):env.pop(name)
env.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
    TEMP=str(ROOT/'target/colmap88-isolated-check/tmp'),TMP=str(ROOT/'target/colmap88-isolated-check/tmp'),RUST_BACKTRACE='full')
report=dict(status='running_actual_shared_jobs_qualification',startedUtc=datetime.now(timezone.utc).isoformat(),
    prerequisiteSha256=sha(PREVIOUS),source=previous['source'],stages=[],cases=[],originalMaxNormalized=.0002,originalMeanNormalized=.00002,
    limits=['Two CPU/GPU numerical pipeline controls, not physical depth truth, video transitions, thermal or cross-desktop acceptance',
            'Same opaque sRGB RGB8 and shared ONNX letterbox/normalization/align-corners procedures',
            'Actual Jobs and DepthResource, not a mocked backend; no automatic backend/quality selection',
            'Prior workspace full regression still failed two tests'])
def save():
    pending=OUT/'receipt.pending.json';pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(pending,OUT/'receipt.json')
def run(name,command,cwd):
    row=dict(name=name,command=list(map(str,command)),status='running');report['stages'].append(row);save();began=time.monotonic()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(row['command'],cwd=cwd,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();code=child.wait()
    row.update(status='passed' if code==0 else 'failed',exitCode=code,elapsedSeconds=round(time.monotonic()-began,3));save()
    assert code==0,(name,code)
began=time.monotonic();save()
try:
    import numpy as np
    from PIL import Image
    spec=importlib.util.spec_from_file_location('shared',WORK/'tools/ai_depth_onnx.py');shared=importlib.util.module_from_spec(spec);spec.loader.exec_module(shared)
    python=ROOT/'.tools/ai-depth74/venv/Scripts/python.exe';worker=TARGET/'motion-depth-wgsl.exe';driver=TARGET/'examples/wgsl_depth.exe'
    assert sha(MODEL)=='274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
    assert sha(PROGRAM)=='2ec1d8012905198cfd5af1430f88d1770edbf752531fe817dfcc65e1477fef6a'
    report.update(modelSha256=sha(MODEL),programSha256=sha(PROGRAM),workerSha256=sha(worker),driverSha256=sha(driver))
    y,x=np.indices((157,93));authored=np.stack(((x*3+y*2)%256,(y*5)%256,((x//7+y//9)%2)*255),axis=-1).astype(np.uint8)
    photo=WORK/'crates/motion-desktop-media/tests/fixtures/professional-screen/destiny-screen.png'
    assert sha(photo)=='e8ed893f990ba8850000064e153d57b84e6e1d5c0a0aa2ccc8dfd1254b2e379d'
    original=np.asarray(Image.open(photo).convert('RGB'));assert original.shape==(654,960,3)
    rotated=np.rot90(original[50:570,70:860],k=-1)[:,::-1,:].copy()
    fixtures=[('authored-portrait',authored,dict(source_size=[93,157],crop=[0,0,93,157],quarter_turns=0,mirror_x=False)),
              ('photo-crop-rotate-mirror',rotated,dict(source_size=[960,654],crop=[70,50,790,520],quarter_turns=1,mirror_x=True))]
    for index,(name,image,geometry) in enumerate(fixtures):
        case=OUT/name;case.mkdir();rgb=image.tobytes(order='C');height,width=image.shape[:2]
        (case/'input.rgb').write_bytes(rgb)
        model=dict(id='dav2-small',revision='a561b849ebae10a6f5ef49e26c83cbbcd36c71bf',sha256=list(bytes.fromhex(sha(MODEL))),processing=shared.PROCESSING)
        key=dict(source=dict(asset=7501+index,revision=3,pts=dict(ticks=7+index,timescale=30)),geometry=geometry,model=model)
        request=dict(key=key,size=[width,height],rgb='input.rgb')
        (case/'input.json').write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8')
        cpu=case/'cpu';cpu.mkdir();shutil.copyfile(case/'input.rgb',cpu/'input.rgb')
        (cpu/'request.json').write_text(json.dumps(dict(schema=1,model=str(MODEL),sha256=sha(MODEL),processing=shared.PROCESSING,
            width=width,height=height,provider='CPUExecutionProvider')),encoding='utf-8')
        run(name+'-cpu',[python,'-I','-B',WORK/'tools/ai_depth_onnx.py',cpu],WORK)
        cpu_report=json.loads((OUT/(name+'-cpu.stdout.log')).read_text());assert cpu_report['providers']==['CPUExecutionProvider']
        run(name+'-wgsl',[driver,python,worker,PROGRAM,case/'scratch',case/'input.json',case/'gpu'],WORK)
        result=json.loads((case/'gpu/receipt.json').read_text())
        assert result['key']==key and result['descriptor']['geometry']==geometry and result['descriptor']['model']==model
        assert result['descriptor']['source']==key['source'] and result['descriptor']['size']==[width,height]
        assert result['in_flight_observed'] and result['in_flight_clear'] and result['queue_depth']==0
        assert result['counts']==dict(submitted=1,completed=1,failed=0,stale=0)
        expected_input=hashlib.sha256(b'MotionStudio/depth/rgb8-srgb-opaque/v1\0'+width.to_bytes(4,'little')+height.to_bytes(4,'little')+rgb).digest()
        assert result['prepared']['rgb_sha256']==list(expected_input) and result['prepared']['rgb_size']==[width,height]
        actual=np.frombuffer((case/'gpu/depth.f32').read_bytes(),dtype='<f4').astype(np.float64)
        expected=np.frombuffer((cpu/'output.f32').read_bytes(),dtype='<f4').astype(np.float64)
        assert len(actual)==len(expected)==width*height and np.isfinite(actual).all() and np.isfinite(expected).all()
        error=np.abs(actual-expected);scale=max(float(np.abs(expected).max()),1e-6)
        maximum=float(error.max())/scale;mean=float(error.mean())/scale
        info=(case/'gpu/logs/motion-studio.log').read_text(encoding='utf-8')
        assert 'start #' in info and 'phase=prepare start' in info and 'phase=native_inference start' in info and 'phase=remap start' in info
        assert not (OUT/(name+'-wgsl.stdout.log')).read_bytes()
        assert not list((case/'scratch').iterdir()),'Owned temporary children cleaned only after completion'
        row=dict(name=name,geometry=geometry,rgbSha256=hashlib.sha256(rgb).hexdigest(),referenceSha256=sha(cpu/'output.f32'),
            actualSha256=sha(case/'gpu/depth.f32'),maxNormalized=maximum,meanNormalized=mean,normalizationScale=scale,
            passed=maximum<=.0002 and mean<=.00002,sharedJobsReceiptSha256=sha(case/'gpu/receipt.json'),defaultInfoStartVisible=True,stdoutEmpty=True)
        report['cases'].append(row);save();assert row['passed'],row
    report['status']='two_real_shared_jobs_pipelines_passed_scheduling_and_video_acceptance_pending'
except BaseException as error:
    report.update(status='failed_original_source_output_and_gate_retained',failure=repr(error),traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=all(sha(WORK/name)==value for name,value in previous['source'].items()),
        completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3));save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','traceback')}))
raise SystemExit(0 if report['status']=='two_real_shared_jobs_pipelines_passed_scheduling_and_video_acceptance_pending' and report['sourceUnchanged'] else 1)
