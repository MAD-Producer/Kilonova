"""Create a checked primitive-only record after the one source-bound controller."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,zipfile,subprocess
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88';OUT=ROOT/'artifacts/pr-queue/tracking88-lens-acceptance-v1'
receipt=json.loads((OUT/'exit.json').read_text(encoding='utf-8'))
assert receipt['status']=='accepted_standalone_primitive_camera_integration_pending',receipt['status']
assert len(receipt['steps'])==4 and all(s['exitCode']==0 for s in receipt['steps'])
for n,h in receipt['source'].items():assert hashlib.sha256((WORK/n).read_bytes()).hexdigest()==h,n
def counts(name):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (OUT/(name+'.log')).read_text(encoding='utf-8'))
 assert rows,name
 result=[sum(int(r[i]) for r in rows) for i in range(3)]
 assert result[1:]==[0,0],result
 return result
totals={name:counts(name) for name in ('model','render')}
assert totals['model'][0]==242,totals
render_log=(OUT/'render.log').read_text(encoding='utf-8')
for name in ('tracking_lens','viewer_views','viewer_frame_views','multiple_camera_compositions','model_layers','scene_gpu','image_capture','allocation_retirement'):
 assert re.search(r'Running tests[\\/]'+name+r'\.rs',render_log),name
oracle=json.loads((OUT/'images/oracle.json').read_text(encoding='utf-8'))
assert len(oracle)==8 and all(r['maxByteError']<=1 and r['detectsIdentityPixels']>80 for r in oracle)
changed=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
assert not any(n.startswith('desktop/app/src/panels/') for n in changed)
source_names=sorted(n for n in changed if n.endswith(('.rs','.wgsl')))
payload={'controller.py':(OUT/'controller.py').read_bytes(),'exit.json':(OUT/'exit.json').read_bytes(),'finalizer.py':Path(__file__).read_bytes()}
for name in ('model','render','desktop-check','provenance'):payload['logs/'+name+'.log']=(OUT/(name+'.log')).read_bytes()
for path in sorted((OUT/'images').glob('*')):payload['images/'+path.name]=path.read_bytes()
for name in source_names:payload['source/'+name]=(WORK/name).read_bytes()
for directory,filename in [('tracking88-lens-check-v1','check.log'),('tracking88-lens-model-v1','test.log'),('tracking88-lens-focused-v2','model.log'),('tracking88-lens-focused-v2','render.log'),('tracking88-lens-focused-v3','render.log'),('tracking88-lens-focused-v4','render.log'),('tracking88-lens-focused-v5','render.log')]:
 p=ROOT/'artifacts/pr-queue'/directory/filename
 payload['history/'+directory+'/'+filename]=p.read_bytes()
data=WORK/'engineering/validation/data'
archive=data/'tracking88-lens-primitive-v1.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,content in sorted(payload.items()):z.writestr(name,content)
with zipfile.ZipFile(archive) as z:
 assert sorted(z.namelist())==sorted(payload)
 for name,content in payload.items():assert z.read(name)==content,name
archive_info=dict(path=archive.name,bytes=archive.stat().st_size,members=len(payload),sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
summary=dict(status=receipt['status'],createdUtc=datetime.now(timezone.utc).isoformat(),baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),counts=totals,archive=archive_info,source={n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in source_names},oracle=oracle,allOwnedValidatorsTerminal=True,pending=['composition camera spatial-run routing, independent 2D boundaries and nested/shared/frozen/exposure consumers','forward projection, inverse picking and view-plane drag integration','calibrated permitted-source real-footage reprojection and lens replacement','vendor adapters, relink/cache invalidation and full maintained regression/cross-platform CI','previous compiler/native crash causes and strict #82 P95/GPU coverage failures'])
with (data/'tracking88-lens-primitive-closeout.json').open('x',encoding='utf-8') as f:json.dump(summary,f,indent=2)
document=f'''# Tracking #88: certified lens inverse and GPU output primitive

This checkpoint follows `{summary['baseCommit']}` on the tracking import branch.
It implements necessary output primitives. It does **not** connect nonzero lens
distortion to a composition camera and does not close #88, #82 or the 3D route.
The calibrated camera consumer still explicitly refuses nonzero coefficients.
Android is retired. No panel, UI, interaction, dependency or third-party asset
was changed. Fixtures and code were independently authored.

## Implemented items and boundaries

- **LENS-1 / new model primitive:** Brown-Conrady radial k1/k2/k3 and tangential
  p1/p2 retain independent fx/fy, principal point, focal correction and plate
  crop/rotation. The documented forward model is referenced from the
  [official OpenCV calibration documentation](https://docs.opencv.org/4.10.0/d9/d0c/group__calib3d.html).
  No upstream implementation, dependency or asset was copied. The new inverse
  uses a fixed 48-step contraction, not the separate Newton test oracle.
- **LENS-2 / admission:** over the radius R=2D+epsilon disk, displacement Jacobian
  norm B is bounded by 3|k1|R²+5|k2|R⁴+7|k3|R⁶+8(|p1|+|p2|)R. B must be below .45.
  This proves uniqueness and convergence on the entire output domain. Lens
  domains outside this conservative proof are explicitly refused, including
  some physically valid lenses; an arbitrary sampled grid is not a proof of
  non-folding. Float coefficients, focal/principal/domain ranges and residuals
  are checked. This admission is not a universal subpixel f32 error guarantee.
- **LENS-3 / overscan:** inverse Lipschitz bound 1/(1-B) encloses every point in
  each normalized output cell, then transforms complete conservative bounds
  through calibration and plate coordinates. Raster allocation adds two
  physical guard texels, has explicit scale/side/16-megapixel limits and gives
  the producer a matching projection window. Identity retains the original
  rectangle. Out-of-domain queries and insufficient footprints return errors.
- **LENS-4 / new GPU primitive:** reusable device/format-owned pipeline consumes
  an already composed linear premultiplied spatial raster. Manual bilinear
  texture loads avoid optional Float32 filtering/blending. Four native channel
  precisions retain their storage; there is no tone map, clamp, alpha conversion
  or display LUT. Hardware sRGB transfer for UNORM8 is honored. Identity at the
  same physical extent copies exact texels, including odd dimensions.
- **LENS-5 / resource and failure controls:** source/destination/encoder/pipeline
  device ownership, aliasing, storage, dimensions, color meaning and certified
  footprint are checked. Each encode has an immutable 128-byte admitted uniform,
  retained by the actual allocation encoder through submission or abandonment.
  Budget refusals preserve typed resource errors and context. The primitive
  returns causes to its caller and does not add healthy file IO or polling logs.
  Default-level worker request/start/error observations are existing coverage;
  a new native camera-distortion logging path is **not yet exercised**.

## Actual validation

The source-bound serial controller and complete commands/logs are archived.
Full model: **{totals['model'][0]} passed / 0 failed / 0 ignored** including doc
tests. Selected renderer targets: **{totals['render'][0]} passed / 0 failed /
0 ignored**, with GPU tests enabled. These include the four new lens controls,
image capture, resource retirement, shared planes/meshes/depth/alpha, imported
camera, scene GPU, explicit/shared views and multiple compositions. FFmpeg
desktop check and provenance validation passed. These are selected controls,
not a full desktop/workspace or cross-platform qualification.

The independent analytic Newton/Jacobian oracle checks every RGBA output byte
for four rotations and both signed radial cases with nonzero tangential terms,
crop and asymmetric intrinsics. All eight actual GPU captures have maximum
byte error <=1; skipping distortion is detected at 535–598 pixels per case.
The comparison decodes sRGB source bytes, interpolates linear light and encodes
the destination transfer. Actual PNGs and per-case results are archived.

Other GPU controls use spatially varying identity fields at all four precisions,
negative/HDR Float16/32 fields, nonlinear constant fields with alpha, two
different lenses queued before a single submission, exact 127/128-byte budget
boundary, retirement after completion and target-owner release before submission.
CPU controls cover zoom, all rotations, independent Newton reprojection,
continuous-footprint admission, preview scales, projection window/depth and
explicit numeric/folding/capacity refusals. No existing assertion was weakened
or gate disabled. All new GPU tests ran; none was skipped.

## Failed attempts retained

Initial compiler errors were a comparison of an owned texture wrapper with a
native texture, a shadowed calibration variable in the test oracle and the
integration-test submodule path. They were corrected directly. The first GPU
oracle run was refused because its pipeline requested plain UNORM8 while the
capture contract negotiated sRGB storage. The test now selects actual storage
and its independent oracle accounts for the documented transfer. The original
one-byte tolerance was preserved. Earlier logs and successful intermediate
logs remain in the archive.

The previous calibrated-camera renderer compilation access violation remains
unexplained. This checkpoint changes renderer source and therefore legitimately
compiles a new artifact; a successful new build is **not proof that rustc was
repaired**. Earlier native/Naga/MCP compiler faults and #82 strict P95 failures
and incomplete GPU coverage remain unresolved. No unchanged failed gate was
rerun merely to obtain green.

## Remaining work

Connect this primitive after depth/alpha composition of each contiguous spatial
run, preserving authored 2D boundaries, independently selected/nested cameras,
shared-frame/frozen views and exposure samples. Carry matching forward/inverse
mapping into projected anchors, picking and view-plane drags. Unsupported
spatial effects/matte/depth combinations must refuse explicitly until implemented.
Only after that routing and native acceptance should the current nonzero lens
refusal be removed. A genuinely calibrated permitted-source real clip and
independent reprojection/lens-replacement evidence remain necessary; synthetic
GPU checker controls are not proof of real-footage tracking. Vendor adapters,
relink/cache controls and full maintained regression/CI remain open.

Archive `{archive_info['path']}`: {archive_info['bytes']} bytes,
{archive_info['members']} members; SHA-256 `{archive_info['sha256']}`.
Every archived member was read back and byte-compared. The closeout JSON records
source hashes, counts and remaining scope. Origin main was fetched during this
validation; HEAD already contained main `8573d997`, with no incoming commits.
'''
(WORK/'engineering/validation/tracking88-lens-primitive-current.md').write_text(document,encoding='utf-8')
print(json.dumps(dict(counts=totals,archive=archive_info),indent=2))
