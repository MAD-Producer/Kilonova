from pathlib import Path
import hashlib,json,os,subprocess,time
out=Path(__file__).resolve().parent;work=Path.cwd()
assert work==Path('E:/Dev/aem/.worktrees/paint-clip-index-maps')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='6bdb692a7f6878dc8c78742a80561ee28937d145'
assert (work/'desktop/ui/src/paint.rs').read_bytes()==(out/'original-paint.rs').read_bytes()
files=subprocess.check_output(['git','ls-files','-z']).decode('utf-8').strip('\0').split('\0')
def freeze():return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in files}
original=freeze();(out/'before-source-freeze.json').write_text(json.dumps(dict(head=head,hashes=original),indent=2),encoding='utf-8')
env=os.environ.copy();env['CARGO_TERM_COLOR']='never';env.pop('WGPU_BACKEND',None)
cmd=['cargo','test','-p','motion-ui','--no-default-features','--test','paint_clip_buffers','--locked','--offline','-j1','--','--test-threads=1','--nocapture']
start=time.monotonic();log=out/'baseline-tests.log'
with log.open('w',encoding='utf-8') as stream:p=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,env=env)
text=log.read_text(encoding='utf-8')
record=dict(head=head,command=cmd,exit_code=p.returncode,seconds=round(time.monotonic()-start,2),source_unchanged=freeze()==original,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(out/'baseline-receipt.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
assert p.returncode==101 and record['source_unchanged']
assert '20 clips / retained shape and cropped glyph: 40 allocation requests' in text
assert '7 passed; 1 failed; 0 ignored' in text
print(json.dumps(record),flush=True)
print(text[-2300:],flush=True)
