from pathlib import Path
import hashlib,json,os,re,subprocess,time
out=Path(__file__).resolve().parent;work=Path.cwd()
assert work==Path('E:/Dev/aem/.worktrees/paint-clip-index-maps')
old=json.loads((out/'corrected-before-source-freeze.json').read_text(encoding='utf-8'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def freeze():return {p:digest(work/p) for p in old['hashes']}
current=freeze();assert [p for p in current if current[p]!=old['hashes'][p]]==['desktop/ui/src/paint.rs']
(out/'after-source-freeze.json').write_text(json.dumps(dict(head=old['head'],hashes=current),indent=2),encoding='utf-8')
initial=json.loads((out/'before-source-freeze.json').read_text(encoding='utf-8'))
fixture=(work/'desktop/ui/tests/paint_clip_buffers.rs').read_bytes().replace(b'Rect::new(x, 1., 2., 2.)',b'Rect::new(x, 1., 1., 1.)')
assert hashlib.sha256(fixture).hexdigest()==initial['hashes']['desktop/ui/tests/paint_clip_buffers.rs']
(out/'initial-test-fixture.rs').write_bytes(fixture)
env=os.environ.copy();env.pop('WGPU_BACKEND',None);env.pop('MOTION_LOG',None);env['CARGO_TERM_COLOR']='never'
base=['cargo','test','-p','motion-ui','--no-default-features','--locked','--offline','-j1']
stages=[('optimized-clip-tests',base+['--test','paint_clip_buffers','--','--test-threads=1','--nocapture']),('ui-native-tests',base+['--features','gpu-tests','--','--test-threads=1','--nocapture'])]
records=[]
for name,cmd in stages:
 start=time.monotonic();log=out/(name+'.log')
 with log.open('w',encoding='utf-8') as stream:p=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,env=env)
 text=log.read_text(encoding='utf-8');results=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)
 record=dict(name=name,command=cmd,seconds=round(time.monotonic()-start,2),exit_code=p.returncode,source_unchanged=freeze()==current,sha256=digest(log),results=results)
 records.append(record);(out/'checks-receipt.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
 assert p.returncode==0 and record['source_unchanged'] and results,record
 assert all(r[0]=='ok' and r[2]=='0' for r in results),results
 if name=='optimized-clip-tests':
  assert '8 passed; 0 failed; 0 ignored' in text
  assert '20 clips / retained shape and cropped glyph: 0 allocation requests' in text
 if name=='ui-native-tests':
  assert all(r[3]=='0' for r in results),results
  assert 'procedural_patterns_and_fractional_dpi_borders_render_actual_pixels ... ok' in text
 print(json.dumps(record),flush=True)
