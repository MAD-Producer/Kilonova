"""Archive terminal exact-source CI and native memory controls; no test restart."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import traceback
import zipfile

ROOT = Path('E:/Dev/aem/artifacts/pr-queue')
WORK = Path('E:/Dev/aem/.worktrees/depth-wgsl-cache75')
OUT = ROOT / 'depth75-ci-ad799f2f-final-v1'
BASE = ROOT / 'depth75-ci-ad799f2f-completed-tests-v1'
HEAD = 'ad799f2f634b5a3897c7df2e06053216db9e86a4'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='collecting', run=42556322285, head=HEAD, jobs=[],
    observed_utc=datetime.now(timezone.utc).isoformat(),
    limits=['Terminal maintained desktop CI at this exact source only',
        'Original local native-child failures remain failures',
        'No model, performance, full process/device memory, thermal or quality qualification',
        'Selected source snapshots and raw logs, not a full source archive or binary distribution'])

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def api(path):
    result = subprocess.run(['gh', 'api', 'repos/MAD-Producer/Kilonova/' + path],
        capture_output=True, timeout=60)
    assert result.returncode == 0, result.stderr.decode(errors='replace')
    return result.stdout

try:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
    raw = api('actions/runs/42556322285')
    (OUT / 'run.json').write_bytes(raw)
    run = json.loads(raw)
    assert run['head_sha'] == HEAD and run['status'] == 'completed' and run['conclusion'] == 'success'
    raw = api('actions/runs/42556322285/jobs?per_page=100')
    (OUT / 'jobs.json').write_bytes(raw)
    jobs = json.loads(raw)['jobs']
    assert len(jobs) < 100
    previous = json.loads((BASE / 'collection.json').read_text())
    assert previous['head'] == HEAD and previous['status'] == 'three_platform_test_logs_and_fifteen_memory_controls_verified'
    retained = {row['id']: row for row in previous['jobs']}
    for job in jobs:
        assert job['run_id'] == report['run'] and job['status'] == 'completed'
        if job['conclusion'] == 'skipped':
            assert job['name'] in ('Desktop libav backend', 'Publish desktop release'), job
            continue
        assert job['conclusion'] == 'success', job
        filename = f"job-{job['id']}.log"
        if job['id'] in retained:
            prior = retained[job['id']]
            raw = (BASE / prior['filename']).read_bytes()
            assert len(raw) == prior['bytes'] and sha(raw) == prior['sha256']
        else:
            raw = api(f"actions/jobs/{job['id']}/logs")
        (OUT / filename).write_bytes(raw)
        row = dict(id=job['id'], name=job['name'], conclusion=job['conclusion'],
            filename=filename, bytes=len(raw), sha256=sha(raw))
        if job['name'].startswith('Desktop tests ('):
            row['named_memory_controls'] = retained[job['id']]['named_memory_controls']
            assert len(row['named_memory_controls']) == 5 and all(v == 1 for v in row['named_memory_controls'].values())
        report['jobs'].append(row)
    assert len(report['jobs']) == 8
    assert sum(row['name'].startswith('Desktop tests (') for row in report['jobs']) == 3
    assert sum(row['name'].startswith('Desktop build (') for row in report['jobs']) == 3
    assert sum(len(row.get('named_memory_controls', {})) for row in report['jobs']) == 15
    frozen = json.loads((ROOT / 'depth75-memory-current-workspace-v1/receipt.json').read_text())
    assert frozen['head'] == HEAD
    selected = ['crates/motion-host/src/process_memory.rs',
        'crates/motion-host/src/depth/capability/memory.rs',
        'crates/motion-host/src/depth/wgsl.rs',
        'crates/motion-host/src/depth/onnx.rs',
        'desktop/app/src/depth_worker/graph_runtime_impl.rs',
        'desktop/app/src/depth_worker/main.rs']
    report['selected_source_sha256'] = {}
    for name in selected:
        raw = (WORK / name).read_bytes()
        assert sha(raw) == frozen['source_sha256'][name]
        destination = OUT / 'source' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
        report['selected_source_sha256'][name] = sha(raw)
    (OUT / 'source-bindings.json').write_text(json.dumps(dict(head=HEAD,
        all_tracked_source_sha256=frozen['source_sha256']), indent=2))
    report.update(status='terminal_ci_eight_jobs_and_fifteen_memory_controls_verified',
        workflow_status=run['status'], workflow_conclusion=run['conclusion'])
except BaseException:
    report.update(status='collection_failed_original_outputs_retained', cause=traceback.format_exc())
finally:
    (OUT / 'collection.json').write_text(json.dumps(report, indent=2) + '\n')

if report['status'] == 'terminal_ci_eight_jobs_and_fifteen_memory_controls_verified':
    archive = OUT / 'depth75-current-platform-memory-v1.zip'
    members = {}
    for path in sorted(OUT.rglob('*')):
        if path.is_file() and path.suffix != '.zip':
            members[path.relative_to(OUT).as_posix()] = dict(bytes=path.stat().st_size, sha256=sha(path.read_bytes()))
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
        for name in members:
            target.write(OUT / name, name)
    with zipfile.ZipFile(archive) as target:
        assert target.testzip() is None
        assert set(target.namelist()) == set(members)
        for name, expected in members.items():
            raw = target.read(name)
            assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256']
    manifest = dict(archive=archive.name, bytes=archive.stat().st_size,
        sha256=sha(archive.read_bytes()), members=members,
        readback='CRC, length and SHA-256 of every member verified')
    (OUT / 'depth75-current-platform-memory-v1.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: manifest[key] for key in ('archive', 'bytes', 'sha256')}))
print(json.dumps({key: report.get(key) for key in ('status', 'workflow_status', 'workflow_conclusion', 'cause')}))
raise SystemExit(0 if report['status'] == 'terminal_ci_eight_jobs_and_fifteen_memory_controls_verified' else 1)
