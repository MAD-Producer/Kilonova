from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-surface-bindings-v4'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sources = {path: sha(WORK / path) for path in sorted(set(paths)) if path.endswith(('.rs', 'Cargo.toml', 'Cargo.lock')) and (WORK / path).is_file()}
for name in ['tracking_surface_binding_tests.rs', 'tracking_video_surface_tests.rs']:
    (OUT / name).write_bytes((WORK / 'desktop/app/src/engine' / name).read_bytes())
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'),
           CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           CARGO_BUILD_JOBS='1', RUST_BACKTRACE='full',
           MOTION_TRACKED_BINDINGS_SURFACE_ARTIFACTS=str(OUT / 'native'),
           MOTION_TRACKED_SURFACE_ARTIFACTS=str(OUT / 'existing-native'))
command = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg', '--locked', '--offline', '--bin', 'motion-studio', '--',
           'engine::tracking_video_replacement_tests::paired::surface::', '--nocapture', '--test-threads=1']
started = time.monotonic()
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), source=sources,
              head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip(), command=command)

def save():
    temporary = OUT / 'exit.pending.json'
    temporary.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(temporary, OUT / 'exit.json')

save()
try:
    with (OUT / 'stdout.log').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    report['sourceUnchanged'] = all(sha(WORK / path) == digest for path, digest in sources.items())
    assert report['sourceUnchanged'], 'source changed'
    assert report['exitCode'] == 0, report['exitCode']
    assert '2 passed; 0 failed; 0 ignored' in (OUT / 'stdout.log').read_text(encoding='utf-8')
    report.update(status='actual_surface_point_plane_nonlinear_lens_and_previous_camera_controls_passed',
                  cases=json.loads((OUT / 'native/report.json').read_text(encoding='utf-8')),
                  childProcess=json.loads((OUT / 'native/child-process.json').read_text(encoding='utf-8')),
                  previousCamera=json.loads((OUT / 'existing-native/report.json').read_text(encoding='utf-8')))
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - started, 3))
    save()
    print(json.dumps({key: report.get(key) for key in ['status', 'exitCode', 'failure', 'elapsedSeconds']}, indent=2), flush=True)
