"""Complete changed-crate regression, guarded by consumed Session/GPU/file stages."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, os, re, shutil, subprocess, time, traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/depth-session75'
BASE = ROOT / 'artifacts/pr-queue'
OUT = BASE / 'depth75-session-regression-v2'
PRIOR = BASE / 'depth75-session-file-v4'

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

prior = read(PRIOR / 'receipt.json')
consumed = read(PRIOR / 'session-consumed.json')
assert prior['status'] == 'actual_session_capacity_blocking_failure_default_file_stderr_stdout_passed'
assert prior['sourceUnchanged'] and prior['fixtureUnchanged']
assert consumed['status'] == 'terminal_consumed' and consumed['exitCode'] == 0
assert shutil.disk_usage(ROOT).free >= 10 << 30
assert 'RUSTC_WRAPPER' not in os.environ and 'RUSTC_WORKSPACE_WRAPPER' not in os.environ
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()
def identity(): return {p: sha(WORK / p) for p in paths}
source = identity()
assert source == prior['source'], 'Source changed after default-channel qualification'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert head == '7d6e9cf9be9670e4ad3a4a210117f81fa9f07437'
assert prior['baseCommit'] == head and prior['mainBaseline'] == '47925a32d78802a6657fd9d59789aca312390c10'
assert consumed['session'] == 85293
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = {k: v for k, v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT / 'target/depth75-post-restart-validation'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0', RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT / 'appdata'),
           TEMP=str(ROOT / 'target/depth75-post-restart-validation/tmp'),
           TMP=str(ROOT / 'target/depth75-post-restart-validation/tmp'))
metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--no-deps', '--format-version', '1', '--locked'], cwd=WORK, env=env))
(OUT / 'cargo-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
old_names = read(BASE / 'depth75-aligned-workspace-v5/receipt.json')['namedPasses']
gpu = read(BASE / 'depth75-session-render-gpu-v1/receipt.json')
names = old_names + [name for stage in gpu['stages'] for name in stage['expectedNewControls']]
assert len(names) == len(set(names)) == 58
report = dict(status='running', mainBaseline='47925a32d78802a6657fd9d59789aca312390c10', baseCommit=head, source=source, startedUtc=datetime.now(timezone.utc).isoformat(),
              expectedNamedControls=names, stages=[], limits=[
                  'Both complete changed-crate suites, all original worker controls, ten new controls and desktop integration check',
                  'Existing gpu-tests features explicitly execute GPU controls; original assertions/default backend/timeouts unchanged',
                  'One own heavy workload; no Android, panels, cache deletion, inference-model quality or frozen-export acceptance inferred'])

def save():
    temporary = OUT / 'receipt.pending.json'
    temporary.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    os.replace(temporary, OUT / 'receipt.json')

def run(name, command):
    assert shutil.disk_usage(ROOT).free >= 10 << 30
    row = dict(name=name, command=command)
    report['stages'].append(row)
    save()
    with (OUT / (name + '.stdout.log')).open('wb') as out, (OUT / (name + '.stderr.log')).open('wb') as err:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=out, stderr=err)
        row['pid'] = child.pid
        save()
        row['exitCode'] = child.wait()
    save()
    return row

save()
began = time.monotonic()
try:
    row = run('changed-crates', ['cargo', 'test', '--locked', '-p', 'motion-host', '-p', 'motion-render',
        '--features', 'motion-host/ai-depth,motion-host/gpu-tests,motion-render/gpu-tests',
        '--no-fail-fast', '--', '--test-threads=1'])
    stdout = (OUT / 'changed-crates.stdout.log').read_text(encoding='utf-8', errors='replace')
    stderr = (OUT / 'changed-crates.stderr.log').read_text(encoding='utf-8', errors='replace')
    summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', stdout, re.M)
    expected, by_name, doc_owners = [], {}, {}
    for package in metadata['packages']:
        if package['name'] not in ('motion-host', 'motion-render'): continue
        for target in package['targets']:
            if not target['test']: continue
            relative = Path(target['src_path']).relative_to(WORK).as_posix()
            key = package['name'] + '::' + target['kind'][0] + '::' + relative
            expected.append(key)
            by_name.setdefault(target['name'].replace('-', '_'), []).append((relative, key))
        if any(t['doctest'] for t in package['targets']):
            key = 'doc::' + package['name']
            expected.append(key)
            doc_owners[package['name'].replace('-', '_')] = key
    observed, bound = [], []
    for executable in re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)', stderr, re.M):
        path = Path(executable)
        raw = path.with_suffix('.d').read_bytes()
        line = raw.decode('utf-8').splitlines()[0].split(': ', 1)[1].replace('\\', '/')
        name = re.sub(r'-[a-f0-9]+$', '', path.stem)
        owners = [key for relative, key in by_name[name] if re.search(r'(?<!\S)' + re.escape(relative) + r'(?!\S)', line)]
        assert len(owners) == 1, (executable, owners)
        observed.extend(owners)
        bound.append(dict(executable=executable, target=owners[0], depInfoSha256=hashlib.sha256(raw).hexdigest()))
    observed.extend(doc_owners[n] for n in re.findall(r'^\s*Doc-tests (\S+)\s*$', stderr, re.M))
    report.update(totals=dict(passed=sum(int(s[1]) for s in summaries), failed=sum(int(s[2]) for s in summaries),
        originalIgnored=sum(int(s[3]) for s in summaries), filtered=sum(int(s[5]) for s in summaries),
        summaryCount=len(summaries), observedInvocations=len(observed), expectedInvocations=len(expected)),
        sourceBoundInvocations=bound, missingSourceTargets=dict(Counter(expected) - Counter(observed)),
        unexpectedSourceTargets=dict(Counter(observed) - Counter(expected)),
        fullTargetCoverageAccounted=Counter(expected) == Counter(observed) and len(summaries) == len(observed),
        abnormalTargetExits=[line for line in stderr.splitlines() if "process didn't exit successfully:" in line],
        failedTestNames=re.findall(r'^test ([^\r\n]+?) \.\.\. FAILED\s*$', stdout, re.M))
    report['namedPasses'] = [n for n in names if len(re.findall(r'(?m)^test ' + re.escape(n) + r' \.\.\. ok$', stdout)) == 1]
    row['passed'] = row['exitCode'] == 0 and report['fullTargetCoverageAccounted'] and not report['totals']['failed'] and not report['totals']['filtered'] and not report['abnormalTargetExits'] and len(report['namedPasses']) == 58
    save()
    if row['passed']:
        check = run('desktop-check', ['cargo', 'check', '--locked', '-p', 'motion-desktop', '--features',
            'ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth'])
        check['passed'] = check['exitCode'] == 0
    report['status'] = 'complete_changed_crates58_controls_and_desktop_check_passed' if len(report['stages']) == 2 and all(s['passed'] for s in report['stages']) else 'failed_original_outputs_retained'
except BaseException as error:
    report.update(status='observer_failed_original_outputs_retained', cause=repr(error), traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=identity() == source, completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - began, 3))
    report['logs'] = {p.name: dict(bytes=p.stat().st_size, sha256=sha(p)) for p in OUT.glob('*.log')}
    save()
print(json.dumps({k: v for k, v in report.items() if k not in ('source', 'sourceBoundInvocations')}))
raise SystemExit(0 if report['status'] == 'complete_changed_crates58_controls_and_desktop_check_passed' and report['sourceUnchanged'] else 1)
