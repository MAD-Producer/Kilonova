"""Actual production file/stderr/stdout channels after complete Session/GPU controls."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,tomllib,traceback
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/depth-session75'
BASE=ROOT/'artifacts/pr-queue';PRIOR=BASE/'depth75-session-render-gpu-v1'
PROBE=BASE/'depth75-session-file-source-v4';OUT=BASE/'depth75-session-file-v4'
prior=json.loads((PRIOR/'receipt.json').read_text(encoding='utf-8'))
consumed=json.loads((PRIOR/'session-consumed.json').read_text(encoding='utf-8-sig'))
assert prior['status']=='both_complete_targets_and_ten_new_controls_passed' and prior['sourceUnchanged']
assert consumed['status']=='terminal_consumed' and consumed['exitCode']==0
failed=json.loads((BASE/'depth75-session-file-v1/receipt.json').read_text(encoding='utf-8'))
failed_consumed=json.loads((BASE/'depth75-session-file-v1/session-consumed.json').read_text(encoding='utf-8'))
assert failed['status']=='failed_original_outputs_retained' and failed['sourceUnchanged'] and failed['stages'][-1]['exitCode']==101
assert failed_consumed['session']==44420 and failed_consumed['exitCode']==1
assert 'E0433' in (BASE/'depth75-session-file-v1/build.stderr.log').read_text(encoding='utf-8')
overflow=json.loads((BASE/'depth75-session-file-v2/receipt.json').read_text(encoding='utf-8'))
overflow_consumed=json.loads((BASE/'depth75-session-file-v2/session-consumed.json').read_text(encoding='utf-8'))
assert overflow['sourceUnchanged'] and overflow['stages'][-1]['exitCode']==3221225725
assert overflow_consumed['session']==74440 and overflow_consumed['exitCode']==1
assert 'has overflowed its stack' in (BASE/'depth75-session-file-v2/actual.stderr.log').read_text(encoding='utf-8')
assert 'RUST_MIN_STACK' not in os.environ, 'No stack override permitted'
assert shutil.disk_usage(ROOT).free>=10<<30
assert 'RUSTC_WRAPPER' not in os.environ and 'RUSTC_WORKSPACE_WRAPPER' not in os.environ
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def identity():return {p:digest(WORK/p) for p in paths}
source=identity()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert head=='7d6e9cf9be9670e4ad3a4a210117f81fa9f07437'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
subprocess.run(['git','merge-base','--is-ancestor','47925a32d78802a6657fd9d59789aca312390c10',head],cwd=WORK,check=True)
pre_rebase=json.loads((BASE/'depth75-session-file-v3/receipt.json').read_text(encoding='utf-8'))
pre_consumed=json.loads((BASE/'depth75-session-file-v3/session-consumed.json').read_text(encoding='utf-8'))
assert pre_rebase['status']=='actual_session_capacity_blocking_failure_default_file_stderr_stdout_passed' and pre_rebase['sourceUnchanged']
assert pre_consumed['session']==81628 and pre_consumed['exitCode']==0

fixture={p.name:digest(p) for p in (PROBE/'Cargo.toml',PROBE/'src/main.rs',PROBE/'probe-main.rs',PROBE/'generate.py',PROBE/'fixture-generation.json')}
generation=json.loads((PROBE/'fixture-generation.json').read_text(encoding='utf-8'))
assert generation['generatedSha256']==digest(PROBE/'src/main.rs')
assert all(source[p]==sha for p,sha in generation['helpers'].items())
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/depth75-post-restart-validation'),
           CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
           TEMP=str(ROOT/'target/depth75-post-restart-validation/tmp'),TMP=str(ROOT/'target/depth75-post-restart-validation/tmp'),
           LOCALAPPDATA=str(OUT/'appdata'))
report=dict(status='running',baseCommit=head,mainBaseline='47925a32d78802a6657fd9d59789aca312390c10',previousQualifiedSourceDoesNotQualifyRebase=True,executionContext='standard_named_owner_thread_no_stack_override',mainThreadOverflowRemainsUnqualified=True,source=source,fixture=fixture,startedUtc=datetime.now(timezone.utc).isoformat(),stages=[],
            limits=['Rebased exact committed source executes this actual default-channel probe; earlier GPU/source evidence is historical, complete current-source regression remains required',
                    'Controlled backend/registered synthetic PNG fixtures do not establish real model accuracy or frozen export',
                    'All fixture registry dependencies must already exist with exact existing workspace lock checksums',
                    'One own native workload; no timeout, feature, assertion, admission or default backend change',
                    'Probe now uses the same default named owner-worker context as desktop engine.rs:805; no stack configuration changes, prior main-thread overflow remains unqualified'])
def save():
    pending=OUT/'receipt.pending.json';pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(pending,OUT/'receipt.json')
def stage(name,command):
    row=dict(name=name,command=command);report['stages'].append(row);save()
    with (OUT/(name+'.stdout.log')).open('wb') as out,(OUT/(name+'.stderr.log')).open('wb') as err:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=out,stderr=err);row['pid']=child.pid;save();row['exitCode']=child.wait()
    save();assert row['exitCode']==0, name+' failed; original output retained'
save()
try:
    assert not (PROBE/'Cargo.lock').exists(), 'Do not silently overwrite an earlier fixture run'
    shutil.copyfile(WORK/'Cargo.lock',PROBE/'Cargo.lock')
    stage('metadata',['cargo','metadata','--offline','--format-version','1','--manifest-path',str(PROBE/'Cargo.toml')])
    known={(p['name'],p['version'],p.get('source')):p.get('checksum') for p in tomllib.loads((WORK/'Cargo.lock').read_text(encoding='utf-8'))['package']}
    for p in tomllib.loads((PROBE/'Cargo.lock').read_text(encoding='utf-8'))['package']:
        if p.get('source'):assert known[(p['name'],p['version'],p['source'])]==p.get('checksum')
    assert shutil.disk_usage(ROOT).free>=10<<30
    stage('build',['cargo','build','--offline','--locked','--manifest-path',str(PROBE/'Cargo.toml')])
    stage('actual',[str(ROOT/'target/depth75-post-restart-validation/debug/motion-depth75-session-file-probe.exe'),str(OUT/'execution')])
    stdout=(OUT/'actual.stdout.log').read_text(encoding='utf-8')
    stderr=(OUT/'actual.stderr.log').read_text(encoding='utf-8')
    assert len(stdout.splitlines())==1 and json.loads(stdout)==dict(status='actual_session_capacity_blocking_failure_and_default_channels_verified')
    assert 'ERROR motion_host::session::depth::transition:' in stderr and 'operation=depth_transition_session_admit' in stderr
    assert 'original managed transition failure' in stderr
    assert ' INFO ' not in stderr and ' DEBUG ' not in stderr
    file=(OUT/'execution/logs/motion-studio.log').read_text(encoding='utf-8')
    assert ' INFO ' in file and 'start #130 depth_infer asset=128' in file
    assert 'operation=depth_transition_session_admit request=129 source_id=128' in file
    assert 'original managed transition failure' in file
    report['status']='actual_session_capacity_blocking_failure_default_file_stderr_stdout_passed'
except BaseException as error:
    report.update(status='failed_original_outputs_retained',cause=repr(error),traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=identity()==source,fixtureUnchanged=all(digest(p)==fixture[p.name] for p in (PROBE/'Cargo.toml',PROBE/'src/main.rs',PROBE/'probe-main.rs',PROBE/'generate.py',PROBE/'fixture-generation.json')),completedUtc=datetime.now(timezone.utc).isoformat())
    report['logs']={p.name:dict(bytes=p.stat().st_size,sha256=digest(p)) for p in OUT.glob('*.log')};save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','fixture')}))
raise SystemExit(0 if report['status']=='actual_session_capacity_blocking_failure_default_file_stderr_stdout_passed' and report['sourceUnchanged'] and report['fixtureUnchanged'] else 1)
