struct Release(mpsc::Sender<()>);
impl Drop for Release { fn drop(&mut self) { let _=self.0.send(()); } }
fn run()->Result<(),Box<dyn std::error::Error>> {
    assert!(std::env::var_os("MOTION_LOG").is_none());
    let directory=std::path::PathBuf::from(std::env::args().nth(1).expect("E evidence directory"));
    assert!(directory.starts_with("E:/Dev/aem/artifacts/pr-queue"));
    std::fs::create_dir_all(&directory)?;
    let _logging=logging::init(directory.join("logs"))?;
    assert_eq!(log::max_level(),log::LevelFilter::Info);
    let initial=session(&directory);
    let mut project=initial.engine.project().clone();
    let asset=project.assets[0].clone();
    project.assets=(1..=motion_model::MAX_LAYERS).map(|id|Asset{id:id as u64,..asset.clone()}).collect();
    drop(initial);
    let mut s=Session::new(project,directory.clone(),Arc::new(NoMedia))?;
    let (echo,seen,_)=backend(false);
    let (release,blocked)=mpsc::channel();
    s.configure_depth(Scaled{echo,blocked:Some(blocked),fail:true})?;
    for id in 1..=motion_model::MAX_LAYERS {
        s.request_image_depth(id as u64,geometry(),model())?;
        wait_done(&mut s,id as u64);
        assert!(s.poll_depth()?.is_some());
        seen.recv_timeout(Duration::from_secs(5))?;
    }
    let before=s.depth_status()?.unwrap();
    s.begin_image_depth_transition(settled(),policy(),limits())?;
    let rejected=s.request_image_depth_transition(Activity::Interactive,Duration::ZERO)?.unwrap();
    wait_done(&mut s,129);
    let capacity=s.poll_image_depth_transition().unwrap_err().to_string();
    assert!(capacity.contains("phase=retain: capacity exceeded"));
    seen.recv_timeout(Duration::from_secs(5))?;
    let file=directory.join("logs/motion-studio.log");
    let written=std::fs::read_to_string(&file)?;
    assert!(written.contains(&format!("operation=depth_transition_session_admit request={rejected} source_id=128 cause={capacity}")));
    assert_eq!(s.depth_status()?.unwrap().retained_samples,before.retained_samples);
    assert!(s.image_depth_transition()?.is_none());
    s.request_image_depth_transition(Activity::Idle,Duration::from_millis(100))?;
    let request=s.request_image_depth_transition(Activity::Idle,Duration::from_millis(400))?.unwrap();
    let _release=Release(release.clone());
    let observed=seen.recv_timeout(Duration::from_secs(5))?;
    assert_eq!(observed.key.model,settled());
    let active=s.depth_status()?.unwrap();
    let flight=active.in_flight.expect("must publish before entering the blocked backend");
    assert_eq!(active.request,Some(request));
    assert_eq!(flight.phase,"backend");
    let written=std::fs::read_to_string(&file)?;
    assert!(written.lines().any(|line|line.contains(" INFO ") && line.contains(&format!("start #{request} depth_infer asset=128"))),"default Info must reach disk before backend return");
    release.send(())?;
    wait_done(&mut s,130);
    let backend=s.poll_image_depth_transition().unwrap_err().to_string();
    assert!(backend.contains("original managed transition failure"));
    let written=std::fs::read_to_string(&file)?;
    assert!(written.contains("original managed transition failure"));
    assert!(s.image_depth_transition()?.is_none());
    assert_eq!(s.depth_status()?.unwrap().counts.submitted,130);
    s.cancel_depth()?;
    s.request_image_depth(128,geometry(),model())?;
    wait_done(&mut s,131);assert!(s.poll_depth()?.is_some());
    s.begin_image_depth_transition(settled(),policy(),limits())?;
    s.request_image_depth_transition(Activity::Interactive,Duration::ZERO)?;
    wait_done(&mut s,132);assert!(s.image_depth_transition()?.is_some());
    assert_eq!(s.depth_status()?.unwrap().retention_rejections,1);
    log::logger().flush();
    println!("{}",serde_json::json!({"status":"actual_session_capacity_blocking_failure_and_default_channels_verified"}));
    Ok(())
}

// Match desktop engine.rs:805's default owner-worker context. No stack size
// override; main-thread stack overflow remains a retained unsupported probe path.
fn main()->Result<(),Box<dyn std::error::Error>> {
    assert!(std::env::var_os("RUST_MIN_STACK").is_none());
    let worker=std::thread::Builder::new().name("motion-depth75-session-probe".into())
        .spawn(||run().map_err(|cause|cause.to_string()))?;
    match worker.join() {
        Ok(result)=>result.map_err(Into::into),
        Err(payload)=>std::panic::resume_unwind(payload),
    }
}
