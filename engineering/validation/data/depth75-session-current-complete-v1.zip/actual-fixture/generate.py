"""Copy only this repository's source-controlled synthetic fixture helpers."""
from pathlib import Path
import hashlib,json,subprocess
root=Path('E:/Dev/aem/.worktrees/depth-session75')
out=Path(__file__).resolve().parent
base=root/'crates/motion-host/tests/depth_session.rs'
new=root/'crates/motion-host/tests/depth_session/transitions.rs'
text=base.read_text(encoding='utf-8');extra=new.read_text(encoding='utf-8')
helpers=text[text.index('struct NoMedia;'):text.index('fn calibrated_source_session(')]
backend=extra[extra.index('fn policy()'):extra.index('fn configure(')]
prefix='''use motion_core::{Asset, Project};
use motion_host::{Platform,Session,depth::{Backend,Cancellation,Costs,Estimate,Input,Key,alignment::Limits,transition::{Activity,Policy}}};
use motion_model::depth::{DepthDescriptor,DepthGeometry,DepthMeasure,DepthModel,DepthResource,NearDirection};
use std::{path::Path,sync::{mpsc,Arc},time::{Duration,Instant}};
#[path="E:/Dev/aem/.worktrees/depth-session75/desktop/app/src/logging/sink.rs"]
mod logging;
mod engine { pub fn current_command()->Option<(u64,&'static str,std::time::Duration)>{None} }
'''
main=(out/'probe-main.rs').read_text(encoding='utf-8')
(out/'src').mkdir(exist_ok=True)
(out/'src/main.rs').write_text(prefix+helpers+backend+main,encoding='utf-8')
subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true',str(out/'src/main.rs')],check=True)
sources={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (base,new)}
(out/'fixture-generation.json').write_text(json.dumps(dict(status='generated_not_executed',helpers=sources,generatedSha256=hashlib.sha256((out/'src/main.rs').read_bytes()).hexdigest(),scope='Only own synthetic fixtures, original production sink, no Adobe or other third-party asset'),indent=2)+'\n',encoding='utf-8')
print('Synthetic Session production-sink probe generated; not built or executed')
