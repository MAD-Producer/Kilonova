use motion_core::{Asset, Project};
use motion_host::{
    depth::{
        alignment::Limits,
        transition::{Activity, Policy},
        Backend, Cancellation, Costs, Estimate, Input, Key,
    },
    Platform, Session,
};
use motion_model::depth::{
    DepthDescriptor, DepthGeometry, DepthMeasure, DepthModel, DepthResource, NearDirection,
};
use std::{
    path::Path,
    sync::{mpsc, Arc},
    time::{Duration, Instant},
};
#[path = "E:/Dev/aem/.worktrees/depth-session75/desktop/app/src/logging/sink.rs"]
mod logging;
mod engine {
    pub fn current_command() -> Option<(u64, &'static str, std::time::Duration)> {
        None
    }
}
struct NoMedia;
impl Platform for NoMedia {
    fn name(&self) -> &'static str {
        "depth-session-test"
    }
    fn probe_video(
        &self,
        _: &Path,
        _: Option<u32>,
        _: Option<u32>,
        _: &dyn Fn() -> motion_media::Result<()>,
    ) -> motion_media::Result<motion_media::VideoProbe> {
        panic!("no video probing")
    }
    fn open_decoder(
        &self,
        _: &Path,
        _: motion_core::VideoAsset,
        _: Vec<u64>,
    ) -> motion_media::Result<Box<dyn motion_host::VideoDecoder>> {
        panic!("no video decoding")
    }
    fn decode_audio(
        &self,
        _: &Path,
        _: &Path,
        _: Option<u32>,
        _: u64,
        _: &mut dyn FnMut(Option<f64>) -> motion_media::Result<()>,
    ) -> motion_media::Result<motion_core::AudioAsset> {
        panic!("no audio decoding")
    }
    fn media_capabilities(
        &self,
        _: Option<&motion_host::VideoQuery>,
    ) -> motion_media::Result<serde_json::Value> {
        Ok(serde_json::json!({}))
    }
    fn attach_surface(
        &self,
        _: Arc<dyn wgpu::DisplayAndWindowHandle + Send + Sync>,
        _: u32,
        _: u32,
        _: motion_render::AllocationBudget,
    ) -> motion_host::Result<motion_host::SurfaceTarget> {
        panic!("no GPU surface")
    }
}

struct Seen {
    key: Key,
    size: [u32; 2],
    rgb: Vec<u8>,
    thread: std::thread::ThreadId,
}
struct Echo {
    entered: mpsc::Sender<Seen>,
    release: Option<mpsc::Receiver<()>>,
}
impl Backend for Echo {
    fn infer(&mut self, input: &Input, _: &Cancellation) -> motion_host::depth::Result<Estimate> {
        self.entered
            .send(Seen {
                key: input.key().clone(),
                size: input.size(),
                rgb: input.rgb().to_vec(),
                thread: std::thread::current().id(),
            })
            .unwrap();
        if let Some(release) = self.release.take() {
            release.recv_timeout(Duration::from_secs(5)).unwrap();
        }
        // Deliberately ignores cancellation to prove the installation guard.
        Ok(Estimate {
            resource: DepthResource::new(
                DepthDescriptor {
                    size: input.size(),
                    source: input.key().source.clone(),
                    geometry: input.key().geometry.clone(),
                    model: input.key().model.clone(),
                    measure: DepthMeasure::Relative {
                        near: NearDirection::Increasing,
                    },
                    scale: 1.,
                    offset: 0.,
                    valid_range: None,
                },
                input
                    .rgb()
                    .chunks_exact(3)
                    .map(|rgb| f32::from(rgb[0]))
                    .collect(),
                None,
                None,
            )?,
            provider: "controlled_cpu".into(),
            costs: Costs::default(),
        })
    }
}
fn backend(block: bool) -> (Echo, mpsc::Receiver<Seen>, mpsc::Sender<()>) {
    let (entered, seen) = mpsc::channel();
    let (release, receiver) = mpsc::channel();
    (
        Echo {
            entered,
            release: block.then_some(receiver),
        },
        seen,
        release,
    )
}
fn model() -> DepthModel {
    DepthModel {
        id: "owned-depth-test".into(),
        revision: "r1".into(),
        sha256: [7; 32],
        processing: "rgb-test-v1".into(),
    }
}
fn geometry() -> DepthGeometry {
    DepthGeometry {
        source_size: [3, 3],
        crop: [0, 0, 3, 3],
        quarter_turns: 0,
        mirror_x: false,
    }
}
fn session(root: &Path) -> Session {
    std::fs::create_dir_all(root.join("assets")).unwrap();
    let mut image = image::RgbaImage::new(3, 3);
    for (x, y, pixel) in image.enumerate_pixels_mut() {
        *pixel = image::Rgba([((y * 3 + x + 1) * 10) as u8, 2, 3, 255]);
    }
    image.save(root.join("assets/input.png")).unwrap();
    let mut project = Project::new(32, 32, 30, 60).unwrap();
    project.assets.push(Asset {
        id: 7,
        path: "assets/input.png".into(),
        width: 3,
        height: 3,
    });
    Session::new(project, root.into(), Arc::new(NoMedia)).unwrap()
}
fn wait_done(session: &mut Session, count: u64) {
    let until = Instant::now() + Duration::from_secs(5);
    loop {
        let status = session.depth_status().unwrap().unwrap();
        if status.counts.completed + status.counts.failed + status.counts.canceled >= count {
            return;
        }
        assert!(Instant::now() < until, "depth completion timed out");
        std::thread::sleep(Duration::from_millis(1));
    }
}

fn policy() -> Policy {
    Policy {
        idle_delay: Duration::from_millis(100),
        minimum_interactive_residence: Duration::from_millis(300),
    }
}
fn limits() -> Limits {
    Limits {
        minimum_fit_pairs: 3,
        minimum_validation_pairs: 3,
        minimum_pair_fraction: 1.,
        minimum_confidence: None,
        minimum_reference_stddev: 1e-8,
        scale_bounds: [0.1, 10.],
        maximum_normalized_rms: 1e-8,
        maximum_normalized_error: 1e-8,
    }
}
fn settled() -> DepthModel {
    let mut value = model();
    value.processing = "settled".into();
    value
}
struct Scaled {
    echo: Echo,
    blocked: Option<mpsc::Receiver<()>>,
    fail: bool,
}
impl Backend for Scaled {
    fn infer(
        &mut self,
        input: &Input,
        canceled: &Cancellation,
    ) -> motion_host::depth::Result<Estimate> {
        let original = self.echo.infer(input, canceled)?;
        if input.key().model.processing != "settled" {
            return Ok(original);
        }
        if let Some(blocked) = self.blocked.take() {
            blocked.recv_timeout(Duration::from_secs(5)).unwrap();
        }
        if self.fail {
            return Err(motion_host::depth::Error::Backend(
                "original managed transition failure".into(),
            ));
        }
        Ok(Estimate {
            resource: DepthResource::new(
                original.resource.descriptor().clone(),
                original
                    .resource
                    .values()
                    .iter()
                    .map(|v| (*v - 3.) / 2.)
                    .collect(),
                None,
                None,
            )?,
            provider: "actual_settled_provider".into(),
            costs: Costs {
                inference: Duration::from_millis(7),
                ..Costs::default()
            },
        })
    }
}
struct Release(mpsc::Sender<()>);
impl Drop for Release {
    fn drop(&mut self) {
        let _ = self.0.send(());
    }
}
fn run() -> Result<(), Box<dyn std::error::Error>> {
    assert!(std::env::var_os("MOTION_LOG").is_none());
    let directory =
        std::path::PathBuf::from(std::env::args().nth(1).expect("E evidence directory"));
    assert!(directory.starts_with("E:/Dev/aem/artifacts/pr-queue"));
    std::fs::create_dir_all(&directory)?;
    let _logging = logging::init(directory.join("logs"))?;
    assert_eq!(log::max_level(), log::LevelFilter::Info);
    let initial = session(&directory);
    let mut project = initial.engine.project().clone();
    let asset = project.assets[0].clone();
    project.assets = (1..=motion_model::MAX_LAYERS)
        .map(|id| Asset {
            id: id as u64,
            ..asset.clone()
        })
        .collect();
    drop(initial);
    let mut s = Session::new(project, directory.clone(), Arc::new(NoMedia))?;
    let (echo, seen, _) = backend(false);
    let (release, blocked) = mpsc::channel();
    s.configure_depth(Scaled {
        echo,
        blocked: Some(blocked),
        fail: true,
    })?;
    for id in 1..=motion_model::MAX_LAYERS {
        s.request_image_depth(id as u64, geometry(), model())?;
        wait_done(&mut s, id as u64);
        assert!(s.poll_depth()?.is_some());
        seen.recv_timeout(Duration::from_secs(5))?;
    }
    let before = s.depth_status()?.unwrap();
    s.begin_image_depth_transition(settled(), policy(), limits())?;
    let rejected = s
        .request_image_depth_transition(Activity::Interactive, Duration::ZERO)?
        .unwrap();
    wait_done(&mut s, 129);
    let capacity = s.poll_image_depth_transition().unwrap_err().to_string();
    assert!(capacity.contains("phase=retain: capacity exceeded"));
    seen.recv_timeout(Duration::from_secs(5))?;
    let file = directory.join("logs/motion-studio.log");
    let written = std::fs::read_to_string(&file)?;
    assert!(written.contains(&format!("operation=depth_transition_session_admit request={rejected} source_id=128 cause={capacity}")));
    assert_eq!(
        s.depth_status()?.unwrap().retained_samples,
        before.retained_samples
    );
    assert!(s.image_depth_transition()?.is_none());
    s.request_image_depth_transition(Activity::Idle, Duration::from_millis(100))?;
    let request = s
        .request_image_depth_transition(Activity::Idle, Duration::from_millis(400))?
        .unwrap();
    let _release = Release(release.clone());
    let observed = seen.recv_timeout(Duration::from_secs(5))?;
    assert_eq!(observed.key.model, settled());
    let active = s.depth_status()?.unwrap();
    let flight = active
        .in_flight
        .expect("must publish before entering the blocked backend");
    assert_eq!(active.request, Some(request));
    assert_eq!(flight.phase, "backend");
    let written = std::fs::read_to_string(&file)?;
    assert!(
        written.lines().any(|line| line.contains(" INFO ")
            && line.contains(&format!("start #{request} depth_infer asset=128"))),
        "default Info must reach disk before backend return"
    );
    release.send(())?;
    wait_done(&mut s, 130);
    let backend = s.poll_image_depth_transition().unwrap_err().to_string();
    assert!(backend.contains("original managed transition failure"));
    let written = std::fs::read_to_string(&file)?;
    assert!(written.contains("original managed transition failure"));
    assert!(s.image_depth_transition()?.is_none());
    assert_eq!(s.depth_status()?.unwrap().counts.submitted, 130);
    s.cancel_depth()?;
    s.request_image_depth(128, geometry(), model())?;
    wait_done(&mut s, 131);
    assert!(s.poll_depth()?.is_some());
    s.begin_image_depth_transition(settled(), policy(), limits())?;
    s.request_image_depth_transition(Activity::Interactive, Duration::ZERO)?;
    wait_done(&mut s, 132);
    assert!(s.image_depth_transition()?.is_some());
    assert_eq!(s.depth_status()?.unwrap().retention_rejections, 1);
    log::logger().flush();
    println!(
        "{}",
        serde_json::json!({"status":"actual_session_capacity_blocking_failure_and_default_channels_verified"})
    );
    Ok(())
}

// Match desktop engine.rs:805's default owner-worker context. No stack size
// override; main-thread stack overflow remains a retained unsupported probe path.
fn main() -> Result<(), Box<dyn std::error::Error>> {
    assert!(std::env::var_os("RUST_MIN_STACK").is_none());
    let worker = std::thread::Builder::new()
        .name("motion-depth75-session-probe".into())
        .spawn(|| run().map_err(|cause| cause.to_string()))?;
    match worker.join() {
        Ok(result) => result.map_err(Into::into),
        Err(payload) => std::panic::resume_unwind(payload),
    }
}
