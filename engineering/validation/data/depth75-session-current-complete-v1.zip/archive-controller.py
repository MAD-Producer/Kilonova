"""Archive consumed exact-parent qualification outside the frozen export tree."""
from pathlib import Path
from datetime import datetime,timezone
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json
root=Path('E:/Dev/aem');base=root/'artifacts/pr-queue';work=root/'.worktrees/depth-session75'
out=base/'depth75-session-current-complete-v1';out.mkdir(exist_ok=False)
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(data):return hashlib.sha256(data).hexdigest()
reg=read(base/'depth75-session-regression-v2/receipt.json')
assert reg['baseCommit']=='7d6e9cf9be9670e4ad3a4a210117f81fa9f07437' and reg['sourceUnchanged']
assert reg['status']=='complete_changed_crates58_controls_and_desktop_check_passed' and reg['totals']['passed']==1471 and len(reg['namedPasses'])==58
assert read(base/'depth75-session-regression-v2/session-consumed.json')['exitCode']==0
paths=[]
for name in ['depth75-session-regression-v2','depth75-session-file-v4']+[f'depth75-session-ci-{p}-v1' for p in ['linux','windows','macos','render']]:
    consumed=read(base/name/'session-consumed.json'); assert consumed['status']=='terminal_consumed' and consumed['exitCode']==0
    for path in (base/name).rglob('*'):
        if path.is_file() and path.suffix in ('.json','.py','.log') and '.download.stderr.' not in path.name:
            paths.append((name+'/'+path.relative_to(base/name).as_posix(),path))
for name in ['Cargo.toml','Cargo.lock','generate.py','probe-main.rs','fixture-generation.json','src/main.rs']:
    paths.append(('actual-fixture/'+name,base/'depth75-session-file-source-v4'/name))
paths.append(('merge.json',base/'depth75-session-merged-v1.json'))
paths.append(('archive-controller.py',Path(__file__)))
owned=['crates/motion-host/src/depth.rs','crates/motion-host/src/depth/alignment.rs',
    'crates/motion-host/src/depth/transition.rs','crates/motion-host/src/depth/transition/admission.rs',
    'crates/motion-host/src/session/depth.rs','crates/motion-host/src/session/depth/transition.rs',
    'crates/motion-render/src/scene/depth.rs','crates/motion-host/tests/depth_session/transitions.rs',
    'crates/motion-host/tests/depth_session.rs','crates/motion-render/tests/depth_surface/aligned.rs',
    'crates/motion-render/tests/depth_surface.rs','desktop/app/src/logging/sink.rs','Cargo.lock']
for name in owned:
    path=work/name;assert sha(path.read_bytes())==reg['source'][name];paths.append(('executed-source/'+name,path))
members={}
archive=out/'depth75-session-current-complete-v1.zip'
with ZipFile(archive,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in paths:
        assert name not in members
        data=path.read_bytes();members[name]=dict(bytes=len(data),sha256=sha(data));z.writestr(name,data)
with ZipFile(archive) as z:
    assert set(z.namelist())==set(members)
    for name,record in members.items():
        data=z.read(name);assert len(data)==record['bytes'] and sha(data)==record['sha256']
report=dict(sourceCommit=reg['baseCommit'],mergeCommit='b190db953ef966d6b12d7ae98005c94ae615afa2',
    archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=members,
    memberCount=len(members),allMembersReadBackVerified=True,observedUtc=datetime.now(timezone.utc).isoformat(),
    totals=reg['totals'],namedControls=58,ciHostNamedPerPlatform=56,ciRendererNamed=2,
    limits=['Qualifies exact parent PR642 only, not subsequent frozen-export changes',
        'Existing synthetic inference/fixtures and actual native GPU controls do not establish real-model quality',
        'Historical failed fixture compilation/main-thread overflow retained separately in the already published pre-rebase archive; no claim of fixing those failures'])
(out/'depth75-session-current-complete-v1.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='members'}))
