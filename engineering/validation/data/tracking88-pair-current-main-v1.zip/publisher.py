from pathlib import Path
import hashlib,json,re,subprocess,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-solve-current-main'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
runs=['tracking583-current-main-v2','tracking583-integration-controls-v1','tracking583-host-controls-v1']
reports={name:json.loads((root/'artifacts/pr-queue'/name/'exit.json').read_text(encoding='utf-8')) for name in runs}
head='b5d73deb31474240b95cf169a8971ee9fb677760'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work).strip()
entries={};totals=[0,0,0];commands=[]
for name,report in reports.items():
    assert report['status']=='scoped_current_main_native_passed_final_ci_pending' and report['sourceUnchanged'] and report['head']==head
    assert all(sha(work/n)==digest for n,digest in report['sources'].items())
    for item in report['results']:
        assert item['exitCode']==0
        commands.append(dict(run=name,**item))
        # This first host selector matched no tests. Keep it visible, and never count it as coverage.
        if name=='tracking583-integration-controls-v1' and item['name']=='host-publication':
            assert len(item['summaries'])==1 and '0 passed;' in item['summaries'][0]
            continue
        for line in item['summaries']:
            match=re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored;',line)
            totals=[a+int(b) for a,b in zip(totals,match.groups())]
    folder=root/'artifacts/pr-queue'/name
    for path in folder.iterdir():
        if path.is_file():entries[name+'/'+path.name]=path.read_bytes()
assert totals==[20,0,0],totals
review=dict(originalSession=19322,terminalConsumed=True,transportExitCode=0,
            coverageDisposition='Host selector matched zero; excluded from all counts. Correct five named host tests listed then executed in tracking583-host-controls-v1',
            actualNativeCases=4,uniquePassed=20,failed=0,ignored=0)
entries['validation-review.json']=(json.dumps(review,indent=2)+'\n').encode('utf-8')
failure=root/'artifacts/pr-queue/tracking583-current-main-v1'
for name in ['exit.json','check-all-targets.stderr.log','check-all-targets.stdout.log','resolution.json','resolver.py']:
    entries['original-encoding-failure/'+name]=(failure/name).read_bytes()
repair=root/'artifacts/pr-queue/tracking583-utf8-repair-v1'
for name in ['receipt.json','controller.py']:entries['utf8-repair/'+name]=(repair/name).read_bytes()
for run in runs:
    wrapper='run-'+run+'.ps1'
    entries['environment/'+wrapper]=(root/'.tools/issue-closure-review'/wrapper).read_bytes()
entries['publisher.py']=Path(__file__).read_bytes()
entries['manifest.json']=(json.dumps({n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in entries.items()},indent=2)+'\n').encode('utf-8')
dest=work/'engineering/validation/data/tracking88-pair-current-main-v1.zip'
dest.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in entries.items():z.writestr(name,data)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    for name,data in entries.items():assert z.read(name)==data
receipt=dict(sourceHead=head,main='c0e25eda7c469c62ee94135e380647d818921662',status='scoped_integration_passed_final_ci_pending',
             totals=dict(zip(['passed','failed','ignored'],totals)),review=review,commands=commands,
             archive=dict(path=dest.name,bytes=dest.stat().st_size,sha256=sha(dest),members=len(entries)),
             limits=['Original encoding failure retained and corrected from original conflict bytes using explicit UTF-8',
                     'Earlier green CI against old PR583 base is historical; current head CI required',
                     'Not complete workspace or prototype tracking-quality acceptance; no panels, assets, dependencies, assertion or budget changes; no Android acceptance'])
dest.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='commands'}))
