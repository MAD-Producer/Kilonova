from pathlib import Path
import hashlib, json, subprocess

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-solve-current-main'
old = root / 'artifacts/pr-queue/tracking583-current-main-v1'
out = root / 'artifacts/pr-queue/tracking583-utf8-repair-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=work).strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip().startswith('88902763')
records = []
for entry in json.loads((old / 'resolution.json').read_text(encoding='utf-8'))['files']:
    name = entry['path']
    path = work / name
    before = path.read_bytes()
    assert hashlib.sha256(before).hexdigest() == entry['sha256']
    original = (old / (path.name + '.conflicted')).read_bytes()
    lines = original.decode('utf-8').splitlines(keepends=True)
    result, side, count = [], None, 0
    for line in lines:
        if line.startswith('<<<<<<< HEAD'):
            assert side is None
            side = 'ours'
            count += 1
        elif line.startswith('======='):
            assert side == 'ours'
            side = 'theirs'
        elif line.startswith('>>>>>>> origin/main'):
            assert side == 'theirs'
            side = None
        elif side != 'theirs':
            result.append(line)
    assert side is None and count == entry['conflictHunks']
    after = ''.join(result).encode('utf-8')
    assert all(marker not in after for marker in [b'<<<<<<<', b'=======', b'>>>>>>>'])
    # Exact inverse of the earlier Windows-default write, including newline translation.
    assert ''.join(result).replace('\n', '\r\n').encode('cp936') == before
    path.write_bytes(after)
    records.append(dict(path=name, beforeSha256=entry['sha256'],
                        afterSha256=hashlib.sha256(after).hexdigest(),
                        verification='Exact same conflict resolution; explicit UTF-8 instead of CP936'))
(out / 'receipt.json').write_text(json.dumps(dict(files=records, originalFailure=str(old / 'exit.json')), indent=2)+'\n', encoding='utf-8')
print(json.dumps(records))
