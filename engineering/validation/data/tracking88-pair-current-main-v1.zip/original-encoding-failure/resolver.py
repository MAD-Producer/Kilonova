from pathlib import Path
import json,subprocess,hashlib
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-solve-current-main'
out=root/'artifacts/pr-queue/tracking583-current-main-v1';out.mkdir(exist_ok=False)
(out/'resolver.py').write_bytes(Path(__file__).read_bytes())
expected={'crates/motion-host/src/ops/media.rs':1,'crates/motion-media/src/video/candidate.rs':5,'desktop/app/src/engine/tracking_video_replacement_tests.rs':1}
assert set(subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=work).decode().splitlines())==set(expected)
records=[]
for name,count in expected.items():
    path=work/name;data=path.read_bytes();(out/(path.name+'.conflicted')).write_bytes(data)
    lines=data.decode().splitlines(keepends=True);result=[];side=None;actual=0
    for line in lines:
        if line.startswith('<<<<<<< HEAD'):
            assert side is None;side='ours';actual+=1
        elif line.startswith('======='):
            assert side=='ours';side='theirs'
        elif line.startswith('>>>>>>> origin/main'):
            assert side=='theirs';side=None
        elif side!='theirs':result.append(line)
    assert side is None and actual==count
    text=''.join(result);assert not any(marker in text for marker in ['<<<<<<<','=======','>>>>>>>'])
    path.write_text(text)
    records.append(dict(path=name,conflictHunks=actual,resolution='Preserve atomic-pair additions in conflicts and every non-conflicting main integration; existing assertions untouched',sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
subprocess.run(['git','add',*expected],cwd=work,check=True)
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=work).strip()
(out/'resolution.json').write_text(json.dumps(dict(status='resolved_compile_and_runtime_pending',base='c0e25eda7c469c62ee94135e380647d818921662',oldHead='6e2ea59a1380654f7f6cb769f0a4c7aa3b984cf6',files=records),indent=2))
print(json.dumps(records))
