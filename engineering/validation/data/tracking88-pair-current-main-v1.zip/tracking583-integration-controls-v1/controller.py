from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys,time
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-solve-current-main'
out=root/'artifacts/pr-queue/tracking583-integration-controls-v1'
assert (out/'resolution.json').exists() and not (out/'exit.json').exists()
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work).strip()
names=subprocess.check_output(['git','ls-files','-z','crates','desktop','tools','Cargo.toml','Cargo.lock'],cwd=work).decode().split('\0')
sources={n:sha(work/n) for n in names if n and (work/n).is_file()}
report=dict(status='running_cpu_then_native_requires_terminal_receipt',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),main='c0e25eda7c469c62ee94135e380647d818921662',sources=sources,results=[],startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Own PR583 latest-main integration; previous green CI was against old base and is not reused as final acceptance','No concurrent GPU with final-render63700; actual native stage requires root-confirmed terminal receipt','No assertion, ignore, threshold, input geometry or retry change; no Android acceptance'])
assert report['head'].startswith('b5d73deb')
os.environ.pop('MOTION_LOG',None);os.environ['LOCALAPPDATA']=str(out/'local-app-data')
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n')
commands=[
('core-atomic',['cargo','test','-p','motion-core','--test','tracking_replacement','--locked','--offline','--','--test-threads=1']),
('host-publication',['cargo','test','-p','motion-host','--lib','ops::media::tracked_replacement_tests::','--locked','--offline','--','--test-threads=1']),
('native-original',['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','engine::tracking_video_replacement_tests::tracked_video_replacement_refuses_changed_plate_and_preserves_identical_source','--','--exact','--test-threads=1','--nocapture']),
('native-mapped',['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','engine::tracking_video_replacement_tests::mapped_time::mapped_original_video_keeps_native_picture_and_authored_clock_across_replacement','--','--exact','--test-threads=1','--nocapture']),
('native-audio',['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','engine::tracking_video_replacement_tests::paired::audio::native_audio_and_tracking_replace_rollback_undo_redo_and_reopen_together','--','--exact','--test-threads=1','--nocapture'])]

save()
try:
    for name,command in commands:
        if name.startswith('native-'):
            report['status']='cpu_passed_waiting_for_original63700_terminal_consumption';save()
            permission=out/'render-terminal-consumed.json'
            while not permission.exists():time.sleep(1)
            token=json.loads(permission.read_text());assert token['originalSession']==63700 and token['terminalConsumed']
            gate=root/'artifacts/pr-queue/professional-api86-final-render-v1/exit.json'
            assert token['gateReportSha256']==sha(gate) and json.loads(gate.read_text()).get('completedUtc')
            report['gpuPrerequisite']=token;report['status']='running_native_after_original_render_terminal';save()
        item=dict(name=name,command=command,status='running');report['results'].append(item);began=time.monotonic();save()
        with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
            process=subprocess.Popen(command,cwd=work,stdout=stdout,stderr=stderr,env=os.environ.copy());item['pid']=process.pid;save();item['exitCode']=process.wait()
        item.update(status='passed' if item['exitCode']==0 else 'failed',elapsedSeconds=round(time.monotonic()-began,3),summaries=re.findall(r'^test result: .+$',(out/f'{name}.stdout.log').read_text(errors='replace'),re.M));save();print(json.dumps(item),flush=True)
        assert item['exitCode']==0,(name,item['exitCode'])
    assert all(item['summaries'] and any('1 passed; 0 failed; 0 ignored;' in s for s in item['summaries']) for item in report['results'] if item['name'].startswith('native-'))
    assert all(item['summaries'] for item in report['results'])
    report['sourceUnchanged']=all(sha(work/n)==v for n,v in sources.items());assert report['sourceUnchanged']
    report['status']='scoped_current_main_native_passed_final_ci_pending'
except BaseException as cause:
    report.update(status='failed_original_outputs_retained',failure=repr(cause));raise
finally:
    report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
