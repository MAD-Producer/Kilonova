"""Source-frozen idle upload boundary red/green controls, queued after exact live owner."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT/'.worktrees/prerender-input-priority'
OUT = ROOT/'artifacts/pr-queue/prerender-idle-upload-v3'
BASE = '652fbe6525f5813a85620fe0d5d2ad4eef5f9bfb'
WORKER = WORK/'crates/motion-desktop-media/src/movie/prerender/coordinator.rs'
NAME = 'movie::prerender::coordinator::tests::idle_upload::idle_warmup_submits_and_retires_before_the_next_foreground_frame'

def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git',*args],cwd=WORK).decode().strip()
def digest(data): return hashlib.sha256(data).hexdigest()
def sources():
    return {n:digest((WORK/n).read_bytes()) for n in git('ls-files','--cached','--others','--exclude-standard','-z').split('\0')
            if n and n.endswith(('.rs','.toml','.lock','.wgsl','.json','.yml','.yaml','.py','.md'))}

assert git('rev-parse','HEAD') == BASE
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
original=WORKER.read_bytes()
source=sources()
report=dict(status='queued',controllerPid=os.getpid(),base=BASE,source=source,steps=[],startedUtc=now(),
    limits='Actual native idle upload submission and retirement controls; Original combined-v8 full regression and strict foreground P95 remain FAILED; this is first execution of changed idle-upload controls after inspected native diagnostic, not issue acceptance. No assertions weakened, no retries, no Android.')
def save():
    tmp=OUT/'exit.next.json'; tmp.write_text(json.dumps(report,indent=2),encoding='utf-8');os.replace(tmp,OUT/'exit.json')
env=os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'owned-profile'),PYTHONPATH=str(ROOT/'.tools/build-validation-python'))
Path(env['LOCALAPPDATA']).mkdir()

def step(name,args,expected=None,negative=False):
    report['activeStep']=dict(name=name,command=args,startedUtc=now());save()
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        report['activeStep']['pid']=child.pid;save();code=child.wait()
    report['activeStep'].update(exitCode=code,completedUtc=now());save()
    text=(OUT/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace')
    errors=(OUT/f'{name}.stderr.log').read_text(encoding='utf-8',errors='replace')
    counts=re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
    if negative:
        passed=code!=0 and counts==[('0','1','0')] and 'idle warmup must submit its own upload' in text+errors
    else:
        passed=code==0 and (expected is None or counts==[(str(expected),'0','0')])
        if counts: passed=passed and all(int(c[1])==0 for c in counts)
    row=dict(name=name,command=args,exitCode=code,counts=counts,passed=passed,negativeControl=negative,
        startedUtc=report['activeStep']['startedUtc'],completedUtc=report['activeStep']['completedUtc'])
    report['steps'].append(row);save();print(json.dumps(row),flush=True)
    assert passed,f'{name} failed; original bytes and actual exit preserved; no later build'
    report.pop('activeStep',None);save()

try:
    import ctypes
    from ctypes import wintypes
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
    kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.WaitForSingleObject.restype=wintypes.DWORD
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    for pid in [38076,36596,21084,12072,18056,22820,41956]:
        prior_handle=kernel.OpenProcess(0x100000,False,pid)
        if prior_handle:
            try: assert kernel.WaitForSingleObject(prior_handle,0)==0,f'original owner still live: {pid}'
            finally: kernel.CloseHandle(prior_handle)
    report['admission']='All exact original owners terminal; v2 compiler failure inspected; only new fixture accessors and explicit ignored-test selection corrected.';save()
    previous=json.loads((ROOT/'artifacts/pr-queue/prerender-effect-search-exception-v1/exit.json').read_text(encoding='utf-8'))
    assert previous.get('completedUtc'),'upstream ended without terminal receipt'
    report['diagnosticTerminal']={k:previous.get(k) for k in ['head','status','completedUtc']};save()
    assert previous['status']=='diagnostic_collected_not_a_fix','inspect diagnostic driver failure before any build'
    retained=json.loads((ROOT/'artifacts/pr-queue/prerender-combined-v8/exit.json').read_text(encoding='utf-8'))
    full=next(step for step in retained['steps'] if step['name']=='workspace-regression')
    assert retained.get('completedUtc') and not full['passed'],'original actual full failure must remain recorded'
    report['retainedOriginalFailure']=dict(head=retained.get('head'),status=retained['status'],completedUtc=retained['completedUtc'],workspaceCounts=full.get('counts'),limits='Original native UI failure and strict input P95 remain failed; these new controls have never executed.')
    report['nativeDiagnostic']=previous.get('diagnostic')
    for prior in ['prerender-idle-upload-v1','prerender-input-completion-v1']:
        receipt=json.loads((ROOT/f'artifacts/pr-queue/{prior}/exit.json').read_text(encoding='utf-8'))
        assert receipt.get('completedUtc') and receipt['steps']==[],'these controls must be first execution after original admission stop'
    save()
    active=subprocess.check_output(['powershell','-NoProfile','-Command',
        "@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('rustc.exe','link.exe','cargo.exe') -and $_.CommandLine -match 'gltf-animation87-contract' }).Count"]).decode().strip()
    assert active=='0',f'owned target still active: {active}'
    assert git('rev-parse','HEAD')==BASE and sources()==source
    report.update(status='running',releasedUtc=now());save()
    for name in ['crates/motion-model/src/lib.rs','crates/motion-core/src/lib.rs','crates/motion-render/src/lib.rs',
                 'crates/motion-host/src/lib.rs','crates/motion-desktop-media/src/lib.rs','desktop/app/src/main.rs']:
        os.utime(WORK/name,None)
    negative=subprocess.check_output(['git','show','HEAD:crates/motion-desktop-media/src/movie/prerender/coordinator.rs'],cwd=WORK)
    assert negative!=original
    report['negativeCoordinatorSha256']=digest(negative);save()
    WORKER.write_bytes(negative)
    media=['cargo','test','-p','motion-desktop-media','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--lib']
    try:
        step('original-idle-upload-negative',media+[NAME,'--','--ignored','--exact','--nocapture','--test-threads=1'],negative=True)
    finally:
        WORKER.write_bytes(original)
        assert WORKER.read_bytes()==original
    assert sources()==source
    step('idle-upload-controls',media+['movie::prerender::coordinator::tests::idle_upload::','--','--ignored','--nocapture','--test-threads=1'],expected=2)
    step('coordinator-regression',media+['movie::prerender::coordinator::','--','--test-threads=1'])
    step('media-prerender',media+['movie::prerender::','--','--test-threads=1'])
    render=['cargo','test','-p','motion-render','--locked','--offline','--lib']
    step('four-precision-foreground-fusion',render+['renderer::composition_frames::native::tests::deferred::queued_native_upload_and_foreground_copy_share_one_submission_in_all_four_precisions','--','--ignored','--exact','--test-threads=1'],expected=1)
    step('provenance',[sys.executable,'tools/validate_provenance.py'])
    step('tool-inventory',[sys.executable,'tools/validation_inventory.py'])
    step('whitespace',['git','diff','--check'])
    assert sources()==source
    report.update(status='accepted_idle_upload_components_not_performance_acceptance',completedUtc=now());save()
except BaseException as error:
    report.update(status='failed',completedUtc=now(),failure=repr(error));save();raise
