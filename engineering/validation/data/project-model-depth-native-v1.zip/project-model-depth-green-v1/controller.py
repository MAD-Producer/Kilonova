"""Execute the two unchanged red fixtures with the actual project consumer."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess
root=Path('E:/Dev/aem');work=root/'.worktrees/project-model-depth'
red=json.loads((root/'artifacts/pr-queue/project-model-depth-red-v1/reproduced.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert red['expectedRegressionFailure'] and red['gpuExecuted']
for p in red['source']:
    if '/tests/' in p:assert sha(work/p)==red['source'][p], 'keep all original assertions and fixtures unchanged'
paths=list(red['source'])+['crates/motion-render/src/renderer/model_layers/shared.rs']
source={p:sha(work/p) for p in paths}
out=root/'artifacts/pr-queue/project-model-depth-green-v1';out.mkdir(exist_ok=False)
for p in paths:
    dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/p,dest)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG',None)
cmd=['cargo','test','-p','motion-render','--features','gpu-tests','--test','model_layers','--locked','--offline','shared_project_','--','--test-threads=1']
receipt=dict(startedUtc=datetime.now(timezone.utc).isoformat(),source=source,regressionAssertionsUnchanged=True,command=cmd)
with (out/'native.stdout.log').open('wb') as so,(out/'native.stderr.log').open('wb') as se:
    code=subprocess.run(cmd,cwd=work,env=env,stdout=so,stderr=se).returncode
receipt.update(exitCode=code,completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=all(sha(work/p)==h for p,h in source.items()))
(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
assert code==0 and receipt['sourceUnchanged']
text=(out/'native.stdout.log').read_text(encoding='utf-8')
assert 'test result: ok. 2 passed; 0 failed; 0 ignored;' in text
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,passed=2,failed=0,ignored=0)),flush=True)
