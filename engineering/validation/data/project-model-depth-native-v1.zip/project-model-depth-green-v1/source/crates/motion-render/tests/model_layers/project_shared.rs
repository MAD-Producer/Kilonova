//! Actual saved-project coverage for geometry shared across model layer sources.
use super::*;

struct Paint(String);
impl AssetResolver for Paint {
    fn read(&mut self, path: &str, _: ResourceKind, _: usize) -> io::Result<Vec<u8>> {
        assert_eq!(path, "paint.mtl");
        Ok(self.0.as_bytes().to_vec())
    }
}

fn crossing_project(root: &std::path::Path, samples: u32, blended: bool) -> Project {
    let mut project = Project::new(96, 64, 30, 61).unwrap();
    project.background = [0.; 4];
    std::fs::create_dir_all(root.join("assets/models")).unwrap();
    for (id, material) in [
        (7, "newmtl Paint\nKd 1 0 0\nillum 0\n"),
        (8, "newmtl Paint\nKd 0 0 1\nillum 0\n"),
    ] {
        let sign = if id == 7 { 1. } else { -1. };
        let (left, right) = if blended {
            (sign * 0.2, sign * 0.2)
        } else {
            (-sign * 0.6, sign * 0.6)
        };
        let source = format!("mtllib paint.mtl\nv -0.8 -0.6 {left}\nv 0.8 -0.6 {right}\nv 0.8 0.6 {right}\nv -0.8 0.6 {left}\nusemtl Paint\nf 1 2 3 4\n");
        let mut paint = material.to_string();
        if blended {
            paint.push_str("d 0.5\n");
        }
        let imported = motion_scene::obj::import_obj(
            ImportContext {
                request: 8710,
                source: id,
            },
            source.as_bytes(),
            &mut Paint(paint),
            &Default::default(),
            &ImportLimits::default(),
        )
        .unwrap();
        let frozen = imported
            .freeze(
                source.as_bytes(),
                motion_core::model_assets::MAX_MODEL_ASSET_BYTES as usize,
            )
            .unwrap();
        let path = format!("assets/models/plane-{id}.mscn");
        std::fs::write(root.join(&path), &frozen).unwrap();
        project.model_assets.push(ModelAsset {
            id,
            path,
            bytes: frozen.len() as u64,
            sha256: format!("{:x}", Sha256::digest(&frozen)),
        });
        let mut layer = Layer::solid(
            id - 6,
            "Shared depth surface",
            [40.; 2],
            [48., 32., 0.],
            [1.; 4],
        );
        layer.three_d = true;
        layer.content = Content::Model {
            model: ModelClip {
                asset: id,
                scene: 0,
                pixels_per_metre: 20.,
                pivot: [0.; 3],
                samples,
                animation: None,
            },
        };
        project.layers.push(layer);
    }
    project.validate().unwrap();
    project
}

fn capture(renderer: &mut Renderer, project: &Project) -> Vec<u8> {
    let mut scene = Scene::new(project).unwrap();
    scene
        .sample(project, 0., None, &motion_core::ExpressionEvaluator)
        .unwrap();
    renderer.retain_video_instances(&scene);
    let target = renderer.capture_target(96, 64).unwrap();
    renderer.capture(&scene, &target).unwrap().0
}
fn pixel(bytes: &[u8], x: usize) -> &[u8] {
    &bytes[(32 * 96 + x) * 4..][..4]
}

#[test]
#[cfg_attr(not(feature = "gpu-tests"), ignore = "requires an actual GPU")]
fn shared_project_crossing_models_use_per_fragment_depth_in_either_layer_order() {
    for samples in [1, 4] {
        let root = tempfile::tempdir().unwrap();
        let authored = crossing_project(root.path(), samples, false);
        motion_core::storage::save(root.path(), &authored).unwrap();
        let mut restored = motion_core::storage::load(root.path()).unwrap();
        assert_eq!(restored, authored);
        let mut renderer = pollster::block_on(Renderer::headless()).unwrap();
        renderer.configure_assets(&restored, root.path()).unwrap();
        for asset in &restored.model_assets {
            std::fs::remove_file(root.path().join(&asset.path)).unwrap();
        }
        let first = capture(&mut renderer, &restored);
        assert_eq!(
            pixel(&first, 40),
            &[0, 0, 255, 255],
            "left ray must hit nearer blue model, samples={samples}"
        );
        assert_eq!(
            pixel(&first, 56),
            &[255, 0, 0, 255],
            "right ray must hit nearer red model, samples={samples}"
        );
        restored.layers.reverse();
        let reversed = capture(&mut renderer, &restored);
        assert_eq!(
            first, reversed,
            "opaque geometry cannot depend on authored layer order"
        );
        restored.layers.reverse();
        assert_eq!(
            restored, authored,
            "shared rendering must preserve saved authoring"
        );
    }
}

#[test]
#[cfg_attr(not(feature = "gpu-tests"), ignore = "requires an actual GPU")]
fn shared_project_blended_models_sort_globally_across_sources() {
    for samples in [1, 4] {
        let root = tempfile::tempdir().unwrap();
        let mut project = crossing_project(root.path(), samples, true);
        let mut renderer = pollster::block_on(Renderer::headless()).unwrap();
        renderer.configure_assets(&project, root.path()).unwrap();
        let first = capture(&mut renderer, &project);
        let center = pixel(&first, 48);
        assert!(
            center[0] > center[2] && center[2] > 0 && center[3] > 0 && center[3] < 255,
            "nearer red must blend above blue in linear premultiplied color, got {center:?}"
        );
        project.layers.reverse();
        let reversed = capture(&mut renderer, &project);
        assert_eq!(
            first, reversed,
            "global transparent order cannot be the source/layer order"
        );
    }
}
