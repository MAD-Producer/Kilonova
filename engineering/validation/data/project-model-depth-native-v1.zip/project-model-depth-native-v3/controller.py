"""Project consumer acceptance: existing native API and saved model receivers."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/project-model-depth'
out=root/'artifacts/pr-queue/project-model-depth-native-v3';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((root/'artifacts/pr-queue/project-model-depth-green-v1/accepted.json').read_text(encoding='utf-8'))
test='crates/motion-render/tests/model_layers/project_shared.rs'
old=(root/'artifacts/pr-queue/project-model-depth-green-v1/source'/test).read_text(encoding='utf-8')
new=(work/test).read_text(encoding='utf-8')
assert new.startswith(old.rstrip()), 'retain both reproduced fixtures and every original assertion'
assert (root/'artifacts/pr-queue/depth-calibration-actual-v4/accepted.json').is_file()
paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z'],cwd=work).decode().split('\0')
source={p:sha(work/p) for p in sorted(set(paths)) if p and (p.endswith(('.rs','.py','.toml','.wgsl','.json')) or p=='Cargo.lock')}
changes=['crates/motion-render/src/renderer.rs','crates/motion-render/src/renderer/model_layers.rs',
    'crates/motion-render/src/renderer/model_layers/shared.rs','crates/motion-render/src/scene_gpu/render/shared.rs',
    'crates/motion-render/tests/model_layers.rs',test]
for p in changes:
    dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/p,dest)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG',None)
receipt=dict(startedUtc=datetime.now(timezone.utc).isoformat(),base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),source=source,steps=[],originalRegressionAssertionsUnchanged=True,
    scope='Actual homogeneous project model consumer; mixed plane/effect/matte/nested/sampling and differing MSAA boundaries retain isolated semantics')
steps=[('provenance',[sys.executable,'tools/validate_provenance.py']),
    ('panel-style',[sys.executable,'-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
    ('native',['cargo','test','-p','motion-render','--features','gpu-tests','--test','model_layers','--test','scene_gpu','--lib','--locked','--offline','--no-fail-fast','--','--test-threads=1']),
    ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'])]
for name,cmd in steps:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as so,(out/(name+'.stderr.log')).open('wb') as se:
        code=subprocess.run(cmd,cwd=work,env=env,stdout=so,stderr=se).returncode
    row=dict(name=name,command=cmd,exitCode=code,sourceUnchanged=all(sha(work/p)==h for p,h in source.items()))
    for stream in ('stdout','stderr'):row[stream+'Sha256']=sha(out/(name+'.'+stream+'.log'))
    text=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
    if name=='native':
        results=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
        row['totals']=dict(zip(('passed','failed','ignored'),[sum(int(v[i]) for v in results) for i in range(3)]));row['targets']=len(results)
    receipt['steps'].append(row);(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    assert code==0 and row['sourceUnchanged'],name
    if name=='native':
        assert row['targets']==3 and row['totals']['failed']==row['totals']['ignored']==0
        for test_name in ('shared_project_crossing_models_use_per_fragment_depth_in_either_layer_order',
                'shared_project_blended_models_sort_globally_across_sources',
                'shared_project_pending_frames_keep_their_own_poses_when_submitted_in_reverse',
                'shared_project_raster_budget_refuses_one_byte_short_and_deletion_releases_depth',
                'shared_project_depth_preserves_four_working_precisions_and_both_sample_counts'):
            assert 'test project_shared::'+test_name+' ... ok' in text,test_name
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=True)
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,totals=next(s['totals'] for s in receipt['steps'] if s['name']=='native'))),flush=True)
