"""Reproduce actual project geometry ordering before applying the consumer."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,re,shutil,subprocess,time

root=Path('E:/Dev/aem');work=root/'.worktrees/project-model-depth'
out=root/'artifacts/pr-queue/project-model-depth-red-v1';out.mkdir(exist_ok=False)
target=root/'target/gltf-animation87-contract'
paths=['crates/motion-render/src/renderer.rs','crates/motion-render/src/renderer/model_layers.rs',
       'crates/motion-render/src/scene_gpu/render/shared.rs','crates/motion-render/tests/model_layers.rs',
       'crates/motion-render/tests/model_layers/project_shared.rs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={p:sha(work/p) for p in paths}
for p in paths:
    dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/p,dest)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG',None)
receipt=dict(startedUtc=datetime.now(timezone.utc).isoformat(),base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),source=source,steps=[])
cmd=['cargo','test','-p','motion-render','--features','gpu-tests','--test','model_layers','--no-run','--message-format=json','--locked','--offline']
with (out/'build.stdout.log').open('wb') as so,(out/'build.stderr.log').open('wb') as se:
    code=subprocess.run(cmd,cwd=work,env=env,stdout=so,stderr=se).returncode
receipt['steps'].append(dict(name='build',command=cmd,exitCode=code))
(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
assert code==0
executables=[]
for line in (out/'build.stdout.log').read_text(encoding='utf-8').splitlines():
    try:d=json.loads(line)
    except ValueError:continue
    if d.get('reason')=='compiler-artifact' and d.get('executable') and d.get('target',{}).get('name')=='model_layers':executables.append(d['executable'])
assert len(executables)==1
receipt.update(state='compiled; waiting for separate combined GPU gate to finish',executable=executables[0])
(out/'state.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
gate=root/'artifacts/pr-queue/depth-model-main-v1/exit.json'
while True:
    d=json.loads(gate.read_text(encoding='utf-8'))
    steps=[s for s in d['steps'] if s['name']=='native']
    if steps:
        assert steps[0]['exitCode']==0,'retain the earlier native failure before running another GPU gate'
        break
    time.sleep(2)
assert all(sha(work/p)==h for p,h in source.items())
for dll in (root/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin').glob('*.dll'):
    dest=Path(executables[0]).parent/dll.name
    if not dest.exists():shutil.copyfile(dll,dest)
    assert sha(dest)==sha(dll)
cmd=[executables[0],'shared_project_','--test-threads=1']
with (out/'native.stdout.log').open('wb') as so,(out/'native.stderr.log').open('wb') as se:
    code=subprocess.run(cmd,cwd=work,env=env,stdout=so,stderr=se).returncode
text=(out/'native.stdout.log').read_text(encoding='utf-8')
assert code==101
assert 'test result: FAILED. 0 passed; 2 failed; 0 ignored;' in text
assert 'left ray must hit nearer blue model' in text or 'right ray must hit nearer red model' in text
assert 'global transparent order cannot be the source/layer order' in text or 'nearer red must blend above blue' in text
assert all(sha(work/p)==h for p,h in source.items())
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),exitCode=code,expectedRegressionFailure=True,
    sourceUnchanged=True,gpuExecuted=True,totals=dict(passed=0,failed=2,ignored=0))
(out/'reproduced.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(reproduced=True,totals=receipt['totals'])),flush=True)
