"""Verify current-main model/storage integration and desktop compilation of owned PR528."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, sys
root = Path('E:/Dev/aem')
work = root / '.worktrees/depth-calibration'
out = root / 'artifacts/pr-queue/depth-project-followup-main-cpu-v2'
alignment = json.loads((root / 'artifacts/pr-queue/depth-project-followup-main-alignment-v2/aligned.json').read_text(encoding='utf-8'))
assert alignment['clean'] and alignment['ownPatchGitBlobsUnchanged']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip() == alignment['head']
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=work).decode().split('\0')
source = {p: sha(work / p) for p in paths if p and (p.endswith(('.rs', '.py', '.toml', '.wgsl', '.json')) or p == 'Cargo.lock')}
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root / 'target/gltf-scene87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG', None)
receipt = dict(startedUtc=datetime.now(timezone.utc).isoformat(), head=alignment['head'], main=alignment['main'], source=source, steps=[])
steps = [('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline']),
         ('model-tests', ['cargo', 'test', '-p', 'motion-model', '--locked', '--offline', '--', '--test-threads=1']),
         ('provenance', [sys.executable, 'tools/validate_provenance.py']),
         ('panel-style', [sys.executable, '-c', "import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"])]
for name, cmd in steps:
    print(json.dumps(dict(start=name)), flush=True)
    with (out / (name + '.stdout.log')).open('wb') as so, (out / (name + '.stderr.log')).open('wb') as se:
        code = subprocess.run(cmd, cwd=work, env=env, stdout=so, stderr=se).returncode
    row = dict(name=name, command=cmd, exitCode=code, sourceUnchanged=all(sha(work / p) == h for p, h in source.items()))
    text = (out / (name + '.stdout.log')).read_text(encoding='utf-8')
    results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    if results:
        row['totals'] = dict(zip(('passed', 'failed', 'ignored'), [sum(int(v[i]) for v in results) for i in range(3)]))
    receipt['steps'].append(row)
    (out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], name
    if name == 'model-tests':
        assert results and row['totals']['passed'] >= 91 and row['totals']['failed'] == row['totals']['ignored'] == 0
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=True)
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True, head=receipt['head'])), flush=True)
