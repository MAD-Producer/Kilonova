"""Current-main union of calibration, receivers, contiguous models and real mixed planes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys
root = Path('E:/Dev/aem')
work = root / '.worktrees/depth-calibration'
out = root / 'artifacts/pr-queue/depth-project-geometry-main-v1'
integration = json.loads((root / 'artifacts/pr-queue/depth-project-followup-geometry-integration-v1/integrated.json').read_text(encoding='utf-8'))
assert integration['ownPatchGitBlobsUnchanged'] and integration['clean']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip() == integration['head']
assert (root / 'artifacts/pr-queue/mixed-plane-depth-native-v2/accepted.json').exists()
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=work).decode().split('\0')
source = {p: sha(work / p) for p in paths if p and (p.endswith(('.rs', '.py', '.toml', '.wgsl', '.json')) or p == 'Cargo.lock')}
changed = subprocess.check_output(['git', 'diff', '--name-only', integration['main'], 'HEAD'], cwd=work).decode().splitlines()
for p in changed:
    if p in source:
        dest = out / 'source' / p
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(work / p, dest)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root / 'target/gltf-scene87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG', None)
receipt = dict(startedUtc=datetime.now(timezone.utc).isoformat(), head=integration['head'], main=integration['main'], source=source, steps=[],
               scope='Latest maintained main plus all owned PR528 geometry/calibration/receiver changes; Android excluded; exact 19-target native union')
targets = ['scene_gpu', 'model_layers', 'exposure_frame', 'exposure_allocation_budget', 'exposure_accumulation',
           'nested_exposure', 'exposure_sdr', 'exposure_scenes', 'layer_rasters', 'layer_masks', 'mask_error_boundaries',
           'scene_effects', 'typed_snapshot_execution', 'effects', 'spatial_effects', 'layer_compositing', 'compositions', 'multiple_camera_compositions']
native = ['cargo', 'test', '-p', 'motion-render', '--features', 'gpu-tests', '--lib']
for target in targets:
    native.extend(['--test', target])
native.extend(['--locked', '--offline', '--no-fail-fast', '--', '--test-threads=1'])
steps = [('provenance', [sys.executable, 'tools/validate_provenance.py']),
         ('panel-style', [sys.executable, '-c', "import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
         ('model-tests', ['cargo', 'test', '-p', 'motion-model', '--locked', '--offline', '--', '--test-threads=1']),
         ('native', native),
         ('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline'])]
for name, cmd in steps:
    print(json.dumps(dict(start=name)), flush=True)
    with (out / (name + '.stdout.log')).open('wb') as so, (out / (name + '.stderr.log')).open('wb') as se:
        code = subprocess.run(cmd, cwd=work, env=env, stdout=so, stderr=se).returncode
    row = dict(name=name, command=cmd, exitCode=code, sourceUnchanged=all(sha(work / p) == h for p, h in source.items()))
    text = (out / (name + '.stdout.log')).read_text(encoding='utf-8')
    results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    if results:
        row.update(targets=len(results), totals=dict(zip(('passed', 'failed', 'ignored'), [sum(int(v[i]) for v in results) for i in range(3)])))
    receipt['steps'].append(row)
    (out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], name
    if results:
        assert row['totals']['failed'] == row['totals']['ignored'] == 0
    if name == 'model-tests':
        assert row['totals']['passed'] == 93
    if name == 'native':
        assert row['targets'] == len(targets) + 1 and row['totals']['passed'] == 434
        assert len(re.findall(r'test project_shared::mixed_planes::mixed_plane_.* \.\.\. ok', text)) == 5
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=True,
               totals=dict(passed=sum(s.get('totals', {}).get('passed', 0) for s in receipt['steps']), failed=0, ignored=0))
assert receipt['totals']['passed'] == 527
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True, totals=receipt['totals'])), flush=True)
