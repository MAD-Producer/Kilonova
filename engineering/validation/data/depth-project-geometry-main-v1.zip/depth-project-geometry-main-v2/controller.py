"""Correct controller arithmetic from actual successful outputs; never rerun or weaken tests."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess
root = Path('E:/Dev/aem')
work = root / '.worktrees/depth-calibration'
original = root / 'artifacts/pr-queue/depth-project-geometry-main-v1'
out = root / 'artifacts/pr-queue/depth-project-geometry-main-v2'
receipt = json.loads((original / 'exit.json').read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(work / p) == h for p, h in receipt['source'].items())
assert all(s['exitCode'] == 0 and s['sourceUnchanged'] for s in receipt['steps'])
native = next(s for s in receipt['steps'] if s['name'] == 'native')
text = (original / 'native.stdout.log').read_text(encoding='utf-8')
rows = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
totals = dict(zip(('passed', 'failed', 'ignored'), [sum(int(v[i]) for v in rows) for i in range(3)]))
assert len(rows) == native['targets'] == 19
assert totals == native['totals'] == dict(passed=439, failed=0, ignored=0)
assert len(re.findall(r'test project_shared::mixed_planes::mixed_plane_.* \.\.\. ok', text)) == 5
assert 'passed\'] == 434' in (original / 'controller.py').read_text(encoding='utf-8')
assert not any(s['name'] == 'desktop-check' for s in receipt['steps'])
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
receipt.update(originalNativeGate='artifacts/pr-queue/depth-project-geometry-main-v1',
               originalNativeOutputSha256=sha(original / 'native.stdout.log'), originalNativeExitSha256=sha(original / 'exit.json'),
               controllerCountCorrection='434 was estimated from the earlier pre-project-model checkpoint; actual unchanged native tests pass439. The five all-model project tests were omitted from that estimate. Correct aggregation only; no assertion/test/product changes or reruns.')
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root / 'target/gltf-scene87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG', None)
cmd = ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline']
with (out / 'desktop-check.stdout.log').open('wb') as so, (out / 'desktop-check.stderr.log').open('wb') as se:
    code = subprocess.run(cmd, cwd=work, env=env, stdout=so, stderr=se).returncode
row = dict(name='desktop-check', command=cmd, exitCode=code, sourceUnchanged=all(sha(work / p) == h for p, h in receipt['source'].items()))
receipt['steps'].append(row)
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=row['sourceUnchanged'],
               totals=dict(passed=sum(s.get('totals', {}).get('passed', 0) for s in receipt['steps']), failed=0, ignored=0))
(out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
assert code == 0 and receipt['sourceUnchanged'] and receipt['totals']['passed'] == 532
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True, totals=receipt['totals'], nativeTestsRerun=False, sourceUnchanged=True)), flush=True)
