"""One retained-binary diagnostic; never replaces the failed full regression."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,time
ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue';OUT=ART/'tracking88-plugin-child-diagnostic-v1'
retained=json.loads((ART/'tracking88-workspace-v4-failures-v1/receipt.json').read_text())
row=next(r for r in retained['binaries'] if r['target'].startswith('motion-desktop::'))
binary=Path(row['retained']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(binary)==row['sha256']
for name in ['depth75-composed-v1','depth75-index-operators-v1']:
    status=json.loads((ART/name/'receipt.json').read_text());assert 'completedUtc' in status and status['sourceUnchanged']
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'):env.pop(name)
env.update(MOTION_PLUGIN_SETTINGS_LOG_CHILD=str(OUT/'fixture'),MOTION_PLUGIN_SETTINGS_CASE='valid',
    TEMP=str(ROOT/'target/colmap88-isolated-check/tmp'),TMP=str(ROOT/'target/colmap88-isolated-check/tmp'),RUST_BACKTRACE='full')
test='engine::failure::project_tests::recovered_plugin_settings_reach_default_file_and_stderr_without_polling_noise'
command=[str(binary),'--exact',test,'--nocapture','--test-threads=1']
report=dict(status='running_single_diagnostic',startedUtc=datetime.now(timezone.utc).isoformat(),command=command,
    binarySha256=row['sha256'],originalFullFailed=2,source=retained['source'],
    limits=['One original valid-mode child, exact retained executable and assertions, no compilation or retry',
        'Explicit new artifact fixture path replaces the original discarded tempfile path',
        'A passing isolated diagnostic does not repair or pass the original full regression',
        'Original parent did not report native exit status; this execution records its own status, not the lost original one'])
def save():(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
    process=subprocess.Popen(command,cwd=ROOT/'.worktrees/planar-tracker88',env=env,stdout=stdout,stderr=stderr)
    report['pid']=process.pid;save();code=process.wait()
report.update(status='single_diagnostic_passed_original_cause_unresolved' if code==0 else 'single_diagnostic_failed_original_cause_retained',
    exitCode=code,exitCodeHex=f'0x{code&0xffffffff:08x}',elapsedSeconds=round(time.monotonic()-began,3),
    completedUtc=datetime.now(timezone.utc).isoformat(),binaryUnchanged=sha(binary)==row['sha256'])
save();print(json.dumps(report))
raise SystemExit(0 if code==0 else 1)
