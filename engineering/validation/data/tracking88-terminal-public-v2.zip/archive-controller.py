"""Retain full failing execution and isolated diagnosis without a waiver."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, subprocess
ROOT=Path('E:/Dev/aem'); ART=ROOT/'artifacts/pr-queue'
OUT=ART/'tracking88-terminal-public-v2'; TREE=ROOT/'.worktrees/planar-tracker88'
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p: json.loads(p.read_text(encoding='utf-8'))
terminal=read(ART/'tracking88-prototype-workspace-terminal-v4/receipt.json')
diagnostic=read(ART/'tracking88-plugin-child-diagnostic-v1/receipt.json')
assert terminal['totals']['failed']==2 and terminal['sourceUnchanged']
assert terminal['sourceTargetCoverageAccounted'] and diagnostic['completedUtc']
OUT.mkdir(exist_ok=False)
files={'archive-controller.py':Path(__file__)}
for directory in ('tracking88-prototype-workspace-integration-v4',
                  'tracking88-prototype-workspace-terminal-v4',
                  'tracking88-workspace-v4-failures-v1',
                  'tracking88-plugin-child-diagnostic-v1'):
    base=ART/directory
    for name in ('controller.py','receipt.json','exit.json','metadata.json',
                 'stdout.log','stderr.log','failure-1.log','failure-2.log'):
        if (base/name).is_file(): files[directory+'/'+name]=base/name
    for path in (base/'sources').rglob('*.rs'):
        files[directory+'/sources/'+path.relative_to(base/'sources').as_posix()]=path
    # Preserve all bounded fixture logs and file metadata, never learned/media
    # payloads or retained executable/PDB files. Original binary hashes remain.
    if directory=='tracking88-plugin-child-diagnostic-v1':
        for path in (base/'fixture').rglob('*.log'):
            files[directory+'/fixture/'+path.relative_to(base/'fixture').as_posix()]=path
files['terminal-observer.py']=ROOT/'.tools/issue-closure-review/account-tracking88-workspace-v4.py'
files['previous-terminal-manifest.json']=TREE/'engineering/validation/data/tracking88-terminal-public-v1.json'
files['terminal-observer.stdout.log']=ART/'tracking88-terminal-v4-observer.stdout.log'
files['terminal-observer.stderr.log']=ART/'tracking88-terminal-v4-observer.stderr.log'
pr=json.loads(subprocess.check_output(['gh','pr','view','582','--repo','MAD-Producer/Kilonova',
    '--json','number,state,isDraft,headRefOid,statusCheckRollup'],text=True,encoding='utf-8'))
assert pr['isDraft'] and pr['headRefOid']==terminal['source']
assert sum(x.get('conclusion')=='SUCCESS' for x in pr['statusCheckRollup'])==8
(OUT/'ci582.json').write_text(json.dumps(pr,indent=2)+'\n',encoding='utf-8')
files['ci582.json']=OUT/'ci582.json'
entries={name:dict(bytes=p.stat().st_size,sha256=sha(p)) for name,p in sorted(files.items())}
archive=OUT/'tracking88-terminal-public-v2.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(files.items()):z.writestr(name,path.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(entries)
    for name,row in entries.items():
        raw=z.read(name); assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
manifest=dict(status='original_two_failures_archived_not_waived',createdUtc=datetime.now(timezone.utc).isoformat(),
    source=terminal['source'],totals=terminal['totals'],archive=archive.name,bytes=archive.stat().st_size,
    sha256=sha(archive),entries=entries,diagnostic=diagnostic,
    limits=['Full v4 failed two original tests; green exact-head CI is separate evidence',
            'Original plugin parent omitted child exit code and cleaned fixture; no original native cause established',
            'One retained-binary valid-mode diagnostic passed with an explicit new fixture; original cause remains unresolved',
            'No original assertion, ignore, feature, backend, ACL or budget changed',
            'Retained executable/PDB bytes and private complete source snapshots are identified, not duplicated',
            'Real phone sequence still has 21 plane observations beyond original 15px; PR remains draft and issue open'])
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for src,name in ((archive,archive.name),(OUT/'manifest.json','tracking88-terminal-public-v2.json')):
    dest=TREE/'engineering/validation/data'/name;assert not dest.exists();dest.write_bytes(src.read_bytes());assert sha(src)==sha(dest)
print(json.dumps({k:v for k,v in manifest.items() if k not in ('entries','diagnostic')}))
