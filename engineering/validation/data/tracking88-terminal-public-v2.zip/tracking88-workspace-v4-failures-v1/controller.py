"""Retain exact failed executables and original output; no tests run here."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,shutil
ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue'
RUN=ART/'tracking88-prototype-workspace-integration-v4';OUT=ART/'tracking88-workspace-v4-failures-v1'
terminal=json.loads((ART/'tracking88-prototype-workspace-terminal-v4/receipt.json').read_text())
assert terminal['totals']['failed']==2 and terminal['sourceTargetCoverageAccounted']
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=['crates/motion-core/tests/format_version_boundaries.rs','crates/motion-core/src/storage.rs',
    'crates/motion-core/src/storage/publication.rs','desktop/app/src/engine/failure/project_tests.rs']
work=ROOT/'.worktrees/planar-tracker88';report=dict(status='original_failures_retained_cause_unresolved',
    createdUtc=datetime.now(timezone.utc).isoformat(),source=terminal['source'],totals=terminal['totals'],binaries=[],sources={},
    limits=['Original full run failed twice; no repair, skip or passing reproduction is claimed',
        'Parent assertion omitted child exit code in plugin-settings valid mode; cause must not be invented'])
for row in terminal['sourceBoundInvocations']:
    if not any(row['target'].endswith(s) for s in [sources[0],'desktop/app/src/main.rs']):continue
    original=Path(row['executable']);destination=OUT/'retained-binary'/original.name;destination.parent.mkdir(exist_ok=True)
    shutil.copyfile(original,destination);assert sha(original)==sha(destination)
    item=dict(target=row['target'],original=str(original),retained=str(destination),sha256=sha(destination),bytes=destination.stat().st_size)
    pdb=original.with_suffix('.pdb')
    if pdb.is_file():
        copied=destination.with_suffix('.pdb');shutil.copyfile(pdb,copied);assert sha(pdb)==sha(copied)
        item['pdb']=dict(path=str(copied),sha256=sha(copied),bytes=copied.stat().st_size)
    report['binaries'].append(item)
assert len(report['binaries'])==2
for name in sources:
    destination=OUT/'sources'/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes((work/name).read_bytes())
    report['sources'][name]=sha(destination)
text=(RUN/'stdout.log').read_text(encoding='utf-8')
blocks=re.findall(r'^---- (.+?) stdout ----\n(.*?)(?=^---- |^failures:\s*$)',text,re.M|re.S)
assert len(blocks)==2
for index,(name,body) in enumerate(blocks):
    (OUT/f'failure-{index+1}.log').write_text(name+'\n'+body,encoding='utf-8')
report['originalLogs']={name:dict(path=str(RUN/name),sha256=sha(RUN/name)) for name in ['stdout.log','stderr.log','exit.json']}
(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('sources','originalLogs')}))
