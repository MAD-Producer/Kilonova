"""Terminal full-gate accounting, including all failures and original scope gaps."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import re

ROOT=Path('E:/Dev/aem')
RUN=ROOT/'artifacts/pr-queue/tracking88-prototype-workspace-integration-v4'
OUT=ROOT/'artifacts/pr-queue/tracking88-prototype-workspace-terminal-v4'
execution=json.loads((RUN/'exit.json').read_text(encoding='utf-8'))
assert execution['status']!='running' and 'completedUtc' in execution and execution['sourceUnchanged']
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
metadata=json.loads((RUN/'cargo-metadata.json').read_text(encoding='utf-8'))
stdout=(RUN/'stdout.log').read_text(encoding='utf-8',errors='replace')
stderr=(RUN/'stderr.log').read_text(encoding='utf-8',errors='replace')
rows=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
running=re.findall(r'^\s*Running .+?\([^\r\n]*[\\/]([^\\/()]+)-[a-f0-9]+\.exe\)',stderr,re.M)
docs=re.findall(r'^\s*Doc-tests (\S+)\s*$',stderr,re.M)
expected=[]
for package in metadata['packages']:
    if package['id'] not in metadata['workspace_members'] or package['name']=='motion-android': continue
    expected.extend(t['name'].replace('-','_') for t in package['targets'] if t['test'])
    if any(t['doctest'] for t in package['targets']): expected.append('doc:'+package['name'].replace('-','_'))
actual=running+['doc:'+n for n in docs]
counts=Counter(expected); observed=Counter(actual)
failures=re.findall(r'^test ([^\r\n]+?) \.\.\. FAILED\s*$',stdout,re.M)
failure_headers=re.findall(r'^---- ([^\r\n]+) stdout ----\s*$',stdout,re.M)
report=dict(status='terminal_original_full_execution_accounted',createdUtc=datetime.now(timezone.utc).isoformat(),
            originalStatus=execution['status'],exitCode=execution['exitCode'],source=execution['baseCommit'],
            sourceUnchanged=execution['sourceUnchanged'],elapsedSeconds=execution['elapsedSeconds'],
            totals=dict(passed=sum(int(r[1]) for r in rows),failed=sum(int(r[2]) for r in rows),
                        originalIgnored=sum(int(r[3]) for r in rows),measured=sum(int(r[4]) for r in rows),
                        filtered=sum(int(r[5]) for r in rows),summaryCount=len(rows),invocations=len(actual),expectedInvocations=len(expected)),
            missingInvocations=dict(counts-observed),unexpectedInvocations=dict(observed-counts),
            fullTargetCoverageAccounted=counts==observed and len(rows)==len(actual),
            failedTestNames=failures,failureOutputHeaders=failure_headers,
            originalCommand=execution['command'],
            logs={n:dict(bytes=(RUN/n).stat().st_size,sha256=hashlib.sha256((RUN/n).read_bytes()).hexdigest())
                  for n in ('stdout.log','stderr.log','exit.json','cargo-metadata.json')},
            limits=['Complete frozen a21c3c1c integration includes unchanged later-main video retirement targets',
                    'Later source edits outside this frozen tree are not covered',
                    'Original MoveFileExW publish PermissionDenied failure cannot be erased by a filtered passing reproduction',
                    'No assertion, timeout, backend, stack, test filter or original ignore was changed',
                    'Photographed tracker 15-pixel quality and coverage are independent outstanding gates',
                    'Android excluded by maintained user scope'])
# Equal target names may exist in different workspace packages. Also bind each
# actual executable to the original target source through its exact dep-info
# file, instead of treating a basename count as package identity evidence.
work=ROOT/'.worktrees/planar-tracker88'
expected_sources=[];by_name={};doc_owners={}
for package in metadata['packages']:
    if package['id'] not in metadata['workspace_members'] or package['name']=='motion-android':continue
    for target in package['targets']:
        if not target['test']:continue
        relative=Path(target['src_path']).relative_to(work).as_posix()
        identity=package['name']+'::'+target['kind'][0]+'::'+relative
        expected_sources.append(identity)
        by_name.setdefault(target['name'].replace('-','_'),[]).append((relative,identity))
    if any(t['doctest'] for t in package['targets']):
        identity='doc::'+package['name'];expected_sources.append(identity)
        doc_owners[package['name'].replace('-','_')]=identity
source_rows=[];source_actual=[]
for executable in re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)',stderr,re.M):
    path=Path(executable);dependency=path.with_suffix('.d')
    assert dependency.is_file(), 'Retained exact-executable dep-info is required: '+str(dependency)
    raw=dependency.read_bytes();line=raw.decode('utf-8').splitlines()[0].split(': ',1)[1].replace('\\','/')
    name=re.sub(r'-[a-f0-9]+$','',path.stem)
    candidates=[identity for relative,identity in by_name[name]
                if re.search(r'(?<!\S)'+re.escape(relative)+r'(?!\S)',line)]
    assert len(candidates)==1, (executable,candidates)
    source_actual.extend(candidates)
    source_rows.append(dict(executable=str(path),target=candidates[0],depInfo=str(dependency),
        depInfoSha256=hashlib.sha256(raw).hexdigest()))
source_actual.extend(doc_owners[name] for name in docs)
report['sourceBoundInvocations']=source_rows
report['sourceTargetCoverageAccounted']=Counter(source_actual)==Counter(expected_sources)
report['missingSourceTargets']=dict(Counter(expected_sources)-Counter(source_actual))
report['unexpectedSourceTargets']=dict(Counter(source_actual)-Counter(expected_sources))
(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
assert report['fullTargetCoverageAccounted'], 'Do not call incomplete target coverage a complete regression'
assert report['sourceTargetCoverageAccounted'], 'Package/source identities must match, not only target basenames'
assert report['totals']['failed']==len(failure_headers)==len(failures), 'Inspect unmatched failure accounting'
