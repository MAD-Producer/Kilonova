from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess

root=Path('E:/Dev/aem'); work=root/'.worktrees/shared-scene-depth'
out=root/'artifacts/pr-queue/issue87-shared-depth-native-v1'; out.mkdir(exist_ok=False)
def git(*args): return subprocess.check_output(['git',*args],cwd=work).decode().strip()
def source():
    paths=set(git('ls-files','-co','--exclude-standard','-z').split('\0'))
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(paths) if p and
        (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
base=git('rev-parse','HEAD'); assert base=='317371f1e8136afe933ff4982ff083180288112e'
assert not git('diff','--name-only','HEAD','--','desktop/app/src/panels')
before=source(); env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-scene87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',
    CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',LOCALAPPDATA=str(out/'appdata'),
    MOTION_MODEL_UI_ARTIFACTS=str(out/'model-editor-fixture'))
for key in ('MOTION_LOG','MOTION_MODEL_UI_PROJECT','VK_DRIVER_FILES','VK_ICD_FILENAMES'): env.pop(key,None)
receipt=dict(base=base,source=before,controllerPid=os.getpid(),steps=[],
    scope='Native multi-source depth, global primitive ordering and allocation lifetime foundation; project mixed plane/matte/effect integration remains pending; Android excluded')
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
commands=[('provenance',['python','tools/validate_provenance.py']),
    ('scene-cpu',['cargo','test','-p','motion-scene','--locked','--offline','--','--test-threads=1']),
    ('core-model',['cargo','test','-p','motion-core','--test','model_layers','--locked','--offline','--','--test-threads=1']),
    ('native-model',['cargo','test','-p','motion-render','--features','gpu-tests','--test','model_layers','--test','scene_gpu','--locked','--offline','--','--test-threads=1']),
    ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),
    ('desktop-model',['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','model_layer_tests','--','--test-threads=1'])]
for name,command in commands:
    print(json.dumps(dict(start=name)),flush=True); row=dict(name=name,command=command)
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        process=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr)
        row['pid']=process.pid; row['exitCode']=process.wait()
    row['sourceUnchanged']=source()==before
    for stream in ('stdout','stderr'): row[stream+'Sha256']=hashlib.sha256((out/(name+'.'+stream+'.log')).read_bytes()).hexdigest()
    text=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
    totals=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    if totals: row['totals']=dict(zip(('passed','failed','ignored'),(sum(int(v[i]) for v in totals) for i in range(3))))
    receipt['steps'].append(row); (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(dict(done=name,exit=row['exitCode'],totals=row.get('totals'))),flush=True)
    assert row['exitCode']==0 and row['sourceUnchanged']
    if totals: assert row['totals']['failed']==row['totals']['ignored']==0
    if name=='scene-cpu': assert row['totals']['passed']==60
    if name=='core-model': assert row['totals']['passed']==5
    if name=='native-model':
        assert row['totals']['passed']==32
        required=('shared_depth_interleaves_separate_sources_independently_of_submission_order',
            'shared_blend_queue_is_global_and_masked_fragments_do_not_write_depth',
            'shared_instances_and_two_pending_encodes_retain_independent_uniforms_and_leases',
            'shared_attachment_budget_failure_rolls_back_and_recovers_without_losing_prior_depth',
            'shared_owner_thread_source_limits_and_invalid_frames_reject_before_recording',
            'shared_abandoned_encoder_retires_attachments_and_source_capacity',
            'shared_empty_pass_clears_actual_depth_and_four_precisions_keep_hdr_contracts',
            'shared_perspective_depth_uses_the_actual_common_projection',
            'shared_failure_observation_is_bounded_retains_context_and_resets_after_recovery',
            'shared_draw_allowance_counts_primitives_across_all_instances')
        for test in required: assert re.search(r'test shared::'+test+r' \.\.\. ok',text),test
    if name=='desktop-model': assert row['totals']['passed']>=1 and 'saved_model_keyframes_render_inside_the_editor ... ok' in text
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=source()==before)
assert receipt['sourceUnchanged']
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True)))
