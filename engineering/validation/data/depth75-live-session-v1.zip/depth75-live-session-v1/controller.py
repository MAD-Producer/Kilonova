"""First actual retained backend integration with Session and frozen GPU rendering."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,traceback
from datetime import datetime,timezone
ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue'
WORK=ROOT/'.worktrees/depth-retained-context75'
OUT=ART/'depth75-live-session-v1';TARGET=ROOT/'target/depth-wgsl-cache75-contract'
CP=ART/'depth75-resume-current.json'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=WORK,text=True).strip()
def source():
    names=set(git('diff','--name-only').splitlines())
    names.update(git('ls-files','--others','--exclude-standard').splitlines())
    assert names=={'crates/motion-host/tests/depth_wgsl_retained.rs','crates/motion-host/tests/depth_wgsl_retained/session.rs'}
    return {n:sha(WORK/n) for n in sorted(names)}
state=read(CP);v=state['versionedCache75']
assert v['activeController'] is None and not v['ownHeavyWorkloads']
assert read(ART/'depth75-child-diagnostics-v2/session-consumed.json')['consumed']
assert shutil.disk_usage(ROOT).free>=10<<30
head=git('rev-parse','HEAD');assert head=='76dceecab3b0ea7765839351e210d880f5dd9b49'
bindings=source();OUT.mkdir(exist_ok=False);shutil.copyfile(__file__,OUT/'controller.py')
for name in bindings:
    dest=OUT/'frozen-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WORK/name,dest)
env=os.environ.copy();env.pop('MOTION_LOG',None)
ffmpeg=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),
    CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
    TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'appdata'),
    LIBCLANG_PATH=str(ROOT/'.tools/python-libclang/clang/native'),PYTHONDONTWRITEBYTECODE='1',
    FFMPEG_DIR=str(ffmpeg),FFMPEG_INCLUDE_DIR=str(ffmpeg/'include'),FFMPEG_LIB_DIR=str(ffmpeg/'lib'))
env['PATH']=str(ffmpeg/'bin')+os.pathsep+env['PATH'];Path(env['LOCALAPPDATA']).mkdir()
fixture=read(ART/'depth75-live-service-v3/fixture.json')
fixture.update(scratch=str(OUT/'scratch'),evidence=str(OUT/'evidence.json'))
write(OUT/'fixture.json',fixture)
worker_digest=sha(Path(fixture['worker']))
assert worker_digest=='033b161c1789a09011162630a24430e79271b27bcddc3bb64f39986bbdef1158'
env['MOTION_DEPTH_RETAINED_TEST_FIXTURE']=str(OUT/'fixture.json')
report=dict(status='running',source_head=head,changed_source_sha256=bindings,worker_sha256=worker_digest,
    started_utc=datetime.now(timezone.utc).isoformat(),commands=[],
    limits=['Explicit unqualified Session only; no fabricated quality/memory/thermal report',
        'Original native access violations and full-host/workspace failures remain failed',
        'No Android, panels, downloads, debugger, overlays or foreign process changes'])
v.update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(kind='actual retained Session frozen render',
    output=str(OUT),sourceFrozen=True)])
write(CP,state)
def save():write(OUT/'receipt.json',report)
def frozen():return git('rev-parse','HEAD')==head and source()==bindings and sha(Path(fixture['worker']))==worker_digest
def command(label,args,timeout=None):
    item=dict(label=label,args=args,timeout_seconds=timeout,started_utc=datetime.now(timezone.utc).isoformat())
    report['commands'].append(item);save();began=time.monotonic()
    with (OUT/(label+'.stdout.log')).open('wb') as stdout,(OUT/(label+'.stderr.log')).open('wb') as stderr:
        result=subprocess.run(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr,timeout=timeout)
    item.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-began);save()
    assert result.returncode==0 and frozen(),item
began=time.monotonic()
try:
    base=['cargo','test','-p','motion-host','--features','ai-depth','--test','depth_wgsl_retained','--locked','--offline']
    command('compile',base+['--no-run'])
    command('actual-session',base+['session::actual_retained_session_installs_and_freezes_depth_after_worker_exit',
        '--','--ignored','--exact','--test-threads=1'],timeout=300)
    evidence=read(OUT/'evidence.json')
    assert evidence['status']=='actual_retained_session_frozen_render_passed' and evidence['qualified'] is False
    assert evidence['owned_worker_workspace_removed'] and evidence['frame_count']==3
    assert evidence['cache_hits']==1 and evidence['cache_misses']==1
    report['status']='actual_session_frozen_render_passed_unqualified'
except BaseException:
    report.update(status='failed_original_outcome_retained',failure=traceback.format_exc())
finally:
    report.update(source_unchanged=frozen(),elapsed_seconds=time.monotonic()-began,completed_utc=datetime.now(timezone.utc).isoformat())
    save();print(json.dumps(dict(status=report['status'],commands=report['commands'],source_unchanged=report['source_unchanged'])))
raise SystemExit(0 if report['status']=='actual_session_frozen_render_passed_unqualified' else 1)
