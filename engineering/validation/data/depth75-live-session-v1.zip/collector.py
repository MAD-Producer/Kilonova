"""Retain the mistaken setup, corrected actual integration and frozen-render evidence."""
from pathlib import Path
import hashlib,json,zipfile
ART=Path('E:/Dev/aem/artifacts/pr-queue');WORK=Path('E:/Dev/aem/.worktrees/depth-retained-context75')
OUT=ART/'depth75-live-session-public-v1'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
members={}
for name,session,code in [('depth75-live-session-v1',39149,1),('depth75-live-session-v2',60556,0)]:
    root=ART/name;c=read(root/'session-consumed.json');r=read(root/'receipt.json')
    assert c['session']==session and c['consumed'] and c['exit_code']==code and r['source_unchanged']
    for p in root.rglob('*'):
        rel=p.relative_to(root)
        if p.is_file() and p.suffix in {'.py','.rs','.json','.log'} and not any(
            part in {'appdata','project','scratch'} for part in rel.parts):
            assert p.stat().st_size<32<<20
            members[f'{name}/{rel.as_posix()}']=p.read_bytes()
r=read(ART/'depth75-live-session-v2/receipt.json');e=read(ART/'depth75-live-session-v2/evidence.json')
assert r['status']=='actual_session_frozen_render_passed_unqualified'
assert all(c['exit_code']==0 for c in r['commands'])
assert e['qualified'] is False and e['frame_count']==3 and e['owned_worker_workspace_removed']
assert e['cache_hits']==1 and e['cache_misses']==1 and e['after_calibration_cache_misses']==2
assert e['native']['completed_inputs']==1 and e['after_calibration_native']['completed_inputs']==2
assert e['native']['pid']==e['after_calibration_native']['pid'] and e['after_calibration_native']['context_preparations']==1
assert e['pixels_changed_from_flat']==717
for n,d in r['changed_source_sha256'].items():assert sha((WORK/n).read_bytes())==d
old=(ART/'depth75-live-session-v1/frozen-source/crates/motion-host/tests/depth_wgsl_retained/session.rs').read_text()
new=(WORK/'crates/motion-host/tests/depth_wgsl_retained/session.rs').read_text()
for assertion in ['assert_eq!(status.counts.cache_misses, 1);','assert_eq!(status.counts.cache_hits, 1);',
    'assert_eq!(native["context_preparations"], 1);','assert_eq!(native["completed_inputs"], 1);']:
    assert assertion in old and assertion in new
members['collector.py']=Path(__file__).read_bytes()
OUT.mkdir(exist_ok=False);archive=OUT/'depth75-live-session-v1.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(members.items()):z.writestr(n,b)
m=dict(schema=1,archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
    members={n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(members.items())})
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for n,b in members.items():assert z.read(n)==b and sha(z.read(n))==m['members'][n]['sha256']
(OUT/'depth75-live-session-v1.json').write_bytes((json.dumps(m,indent=2)+'\n').encode())
print(json.dumps(dict(bytes=m['bytes'],sha256=m['sha256'],members=len(members),blue_pixels=e['blue_pixels'])))
