from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-main-time-render-v1'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
paths = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
sha = lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
source = {path:sha(WORK/path) for path in sorted(set(paths)) if path.endswith(('.rs','Cargo.toml','Cargo.lock')) and (WORK/path).is_file()}
changed = subprocess.check_output(['git','diff','--name-only'],cwd=WORK,text=True).splitlines()
changed += subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
for name in changed:
    if name.endswith('.rs'):
        target=OUT/'source'/name
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes((WORK/name).read_bytes())
env=os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
           CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='1',RUST_BACKTRACE='full',
           MOTION_LENS_VIDEO_ARTIFACTS=str(OUT/'native'))
command=['cargo','test','-p','motion-render','--locked','--offline','--no-fail-fast']
for name in ['tracking_lens','video_yuv','video_lifetime','video_instances','video_allocation_budget','model_layers','layer_time_nested']:
    command+=['--test',name]
command+=['--','--test-threads=1']
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),source=source,command=command,
            head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip())
started=time.monotonic()
def save():
    temp=OUT/'exit.pending.json'
    temp.write_text(json.dumps(report,indent=2),encoding='utf-8')
    os.replace(temp,OUT/'exit.json')
save()
try:
    with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        report['pid']=child.pid
        save()
        report['exitCode']=child.wait()
    report['sourceUnchanged']=all(sha(WORK/path)==digest for path,digest in source.items())
    assert report['sourceUnchanged'],'source changed'
    assert report['exitCode']==0,report['exitCode']
    report['native']=json.loads((OUT/'native/video-lens-report.json').read_text(encoding='utf-8'))
    assert len(report['native'])==8
    assert all(row['checked']>250000 and row['maximumError']<=2 for row in report['native'])
    report['status']='seven_complete_render_integration_targets_on_integrated_main_passed'
except BaseException as cause:
    report.update(status='failed',failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-started,3))
    save()
    print(json.dumps({k:report.get(k) for k in ['status','exitCode','failure','elapsedSeconds']},indent=2),flush=True)

