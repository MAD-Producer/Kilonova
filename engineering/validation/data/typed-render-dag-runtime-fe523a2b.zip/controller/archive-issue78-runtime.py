"""Retain source-bound runtime-template acceptance without double counting."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/render-dag'
LABEL = sys.argv[1]
assert re.fullmatch(r'runtime-template-v[0-9]+', LABEL)
OUT = ROOT / 'artifacts/pr-queue' / ('issue78-numeric-' + LABEL)
receipt = json.loads((OUT / 'accepted.json').read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def current_source():
    names = set()
    for args in [('diff', '--name-only', '-z', '302a15bfb0a69b52df89c69da63bd7bbd25e3e1e'),
                 ('ls-files', '--others', '--exclude-standard', '-z')]:
        names.update(p.decode() for p in subprocess.check_output(['git', *args], cwd=WORK).split(b'\0') if p)
    return {p: sha((WORK / p).read_bytes()) for p in sorted(names)
            if (WORK / p).is_file() and (p.endswith('.rs') or p.endswith('Cargo.toml') or p == 'Cargo.lock')}


assert receipt['sourceUnchanged'] and receipt['source'] == current_source()
steps = {s['name']: s for s in receipt['steps']}
assert list(steps) == ['desktop-check', 'template-unit', 'effects-all', 'graph-all',
                       'render-library', 'runtime-native', 'desktop-nodes']
for name, step in steps.items():
    assert step['exitCode'] == 0 and step['sourceUnchanged'], name
    for stream in ['stdout', 'stderr']:
        data = (OUT / name / (stream + '.log')).read_bytes()
        assert sha(data) == step[stream + 'Sha256'], (name, stream)
    if name != 'desktop-check':
        text = (OUT / name / 'stdout.log').read_text(encoding='utf-8')
        matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
        totals = dict(passed=sum(int(x[0]) for x in matches), failed=sum(int(x[1]) for x in matches),
                      ignored=sum(int(x[2]) for x in matches), targets=len(matches))
        assert totals == step['totals'] and totals['ignored'] == 0, (name, totals)
assert steps['template-unit']['totals']['passed'] == 4

native_log = (OUT / 'runtime-native/stdout.log').read_text(encoding='utf-8')
for name in ['persisted_package_diamond_controls_actual_native_order_and_four_precision_pixels',
             'runtime_branch_storage_refusal_preserves_previous_gpu_pixels_and_recovers']:
    assert 'test ' + name + ' ... ok' in native_log, name
package_log = (OUT / 'effects-all/stdout.log').read_text(encoding='utf-8')
for name in ['actual_package_loader_refuses_runtime_version_and_capabilities_before_shader_parsing',
             'actual_package_loader_binds_template_to_real_compiled_code_and_recovers',
             'actual_package_loader_preserves_typed_cycles_and_contract_failures']:
    assert 'test ' + name + ' ... ok' in package_log, name
rows = json.loads((OUT / 'output-artifacts/runtime-template-diamond.json').read_text(encoding='utf-8'))
assert len(rows) == 4
assert len({json.dumps(r['precision']) for r in rows}) == 4
for row in rows:
    assert row['shader_order'] == [2, 0, 3, 1] and row['native_passes'] == 7
    assert row['actual_draw_calls'] == 8 and row['legacy_control_differs']
    assert row['warm_pipeline_builds'] == 0

private = json.loads((OUT / 'output-artifacts/private-instance-four-precision.json').read_text(encoding='utf-8'))
assert len(private['updates']) == 16 and len(private['cases']) == 8
assert len({(json.dumps(r['precision']), r['overflow']) for r in private['cases']}) == 8
for row in private['updates']:
    assert row['portable_compilations'] == 0 and row['native_pipeline_builds'] == 0
    assert row['warm_upload_bytes'] == 0 and row['matches_baked_pixels'] and row['package_arc_reused']
    assert row['worst_linear_error'] <= 0.012
for row in private['cases']:
    assert row['disk_reopened_pixels_equal'] and row['independent_instance_preserved'] and row['undo_pixels_restored']

formatted = [
    'crates/motion-effects/src/execution_template.rs',
    'crates/motion-effects/src/execution_template/tests.rs',
    'crates/motion-effects/src/shader/identity.rs',
    'crates/motion-effects/tests/execution_template_package.rs',
    'crates/motion-render/src/effect_plan/effect_execution.rs',
    'crates/motion-render/src/effect_plan/runtime_template.rs',
    'crates/motion-render/tests/runtime_execution_template.rs',
    'crates/motion-graph/src/compiler_order.rs',
    'crates/motion-graph/tests/groups.rs',
    'desktop/app/src/node_layer/tests/numeric_precision.rs',
]
command = ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--check', *formatted]
result = subprocess.run(command, cwd=WORK, capture_output=True)
assert result.returncode == 0, (result.stdout, result.stderr)
(OUT / 'format.json').write_text(json.dumps(dict(command=command, exitCode=0), indent=2), encoding='utf-8')
assert not subprocess.check_output(['git', 'diff', '--name-only', '302a15bfb0a69b52df89c69da63bd7bbd25e3e1e',
                                    '--', 'desktop/app/src/panels'], cwd=WORK).strip()

attempts = []
files = {}
for folder in sorted((ROOT / 'artifacts/pr-queue').glob('issue78-numeric-runtime-template-v*')):
    label = folder.name.removeprefix('issue78-numeric-')
    assert re.fullmatch(r'runtime-template-v[0-9]+', label)
    attempt = json.loads((folder / 'exit.json').read_text(encoding='utf-8'))
    accepted = (folder / 'accepted.json').exists()
    assert accepted or attempt['steps'][-1]['exitCode'] != 0, 'Do not archive a live attempt'
    assert all(s['sourceUnchanged'] for s in attempt['steps'])
    attempts.append(dict(label=label, accepted=accepted,
                         completedStages=[s['name'] for s in attempt['steps']],
                         lastExitCode=attempt['steps'][-1]['exitCode']))
    for path in sorted(folder.rglob('*')):
        if path.is_file() and path.name != 'archive-verification.json':
            files['attempts/' + label + '/' + path.relative_to(folder).as_posix()] = path.read_bytes()

v1 = next(a for a in attempts if a['label'] == 'runtime-template-v1')
assert v1['accepted'] and v1['completedStages'] == ['desktop-check', 'template-unit']
v2 = next(a for a in attempts if a['label'] == 'runtime-template-v2')
assert not v2['accepted'] and v2['lastExitCode'] == 101
failure = (ROOT / 'artifacts/pr-queue/issue78-numeric-runtime-template-v2/runtime-native/stdout.log').read_text(encoding='utf-8')
assert 'test persisted_package_diamond_controls_actual_native_order_and_four_precision_pixels ... ok' in failure
assert 'test runtime_branch_storage_refusal_preserves_previous_gpu_pixels_and_recovers ... FAILED' in failure
assert 'unwrap_err()' in failure and 'Ok' in failure and 'draw_calls: 1' in failure
v3 = next(a for a in attempts if a['label'] == 'runtime-template-v3')
assert not v3['accepted'] and v3['lastExitCode'] == 101
failure = (ROOT / 'artifacts/pr-queue/issue78-numeric-runtime-template-v3/desktop-nodes/stdout.log').read_text(encoding='utf-8')
assert 'test node_editor::view::group_tests::group_boundaries_preserve_types_units_export_and_atomic_undo_then_ungroup ... FAILED' in failure
assert '217 passed; 1 failed; 0 ignored' in failure
v4 = next(a for a in attempts if a['label'] == 'runtime-template-v4')
assert not v4['accepted'] and v4['lastExitCode'] == 101
v5 = next(a for a in attempts if a['label'] == 'runtime-template-v5')
assert v5['accepted'] and v5['completedStages'] == ['group-code-green']
files['controller/archive-issue78-runtime.py'] = Path(__file__).read_bytes()
files['patch/tracked.patch'] = subprocess.check_output(['git', 'diff', '--binary', '--',
    'crates/motion-effects', 'crates/motion-graph', 'crates/motion-render'], cwd=WORK)
distinct = sum(s.get('totals', {}).get('passed', 0) for n, s in steps.items() if n != 'template-unit')
manifest = dict(
    createdUtc=datetime.now(timezone.utc).isoformat(), base=receipt['head'], source=receipt['source'],
    scope='Package-local versioned image execution templates consumed by actual native DAG scheduling; partial issue #78',
    attempts=attempts, distinctPasses=distinct, testTotals={n: s.get('totals') for n, s in steps.items()},
    retainedFailures=['v2 new storage-refusal test received Ok with one plain draw after legacy preview bypass',
                      'v3 existing group export equality failed after code identity became observable in templates',
                      'v4 new exact actual-code wrapping regression failed before canonical emission fix'],
    countLimit='Focused four are a subset of effects-all; earlier attempts and earlier checkpoints are not additional final passes',
    limitations=['Frozen Android/GLES packed v12 refuses private data; all Android work is explicitly excluded by the user',
                 'Initial semantic frontend and fully typed external imports remain pending',
                 'Parallel CPU preparation and complete measured costs remain pending',
                 'Complete new IR production output channels and final current-main/cross-platform acceptance remain pending'],
    files={name: sha(data) for name, data in sorted(files.items())},
)
archive = WORK / 'engineering/validation/data/typed-render-dag-runtime-fe523a2b.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(files.items()):
        z.writestr(name, data)
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(files) | {'manifest.json'}
    for name, digest in manifest['files'].items():
        assert sha(z.read(name)) == digest, name
assert receipt['source'] == current_source()
summary = dict(archive=str(archive), bytes=archive.stat().st_size, files=len(files),
               sha256=sha(archive.read_bytes()), sourcesVerified=len(receipt['source']),
               distinctPasses=distinct, testTotals=manifest['testTotals'])
(OUT / 'archive-verification.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary))
