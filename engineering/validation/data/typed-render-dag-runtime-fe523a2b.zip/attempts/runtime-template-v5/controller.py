"""Source-bound package-template gates; retained attempts are never overwritten."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/render-dag'
label=sys.argv[1];assert re.fullmatch(r'[a-z0-9-]+',label)
out=root/'artifacts/pr-queue'/f'issue78-numeric-{label}';out.mkdir(exist_ok=False)
def now():return datetime.now(timezone.utc).isoformat()
def source():
 names=set()
 for args in [('diff','--name-only','-z','302a15bfb0a69b52df89c69da63bd7bbd25e3e1e'),('ls-files','--others','--exclude-standard','-z')]:
  names.update(p.decode() for p in subprocess.check_output(['git',*args],cwd=work).split(b'\0') if p)
 return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(names) if (work/p).is_file() and (p.endswith('.rs') or p.endswith('Cargo.toml') or p == 'Cargo.lock')}
inputs=source()
for name in inputs:
 target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((work/name).read_bytes())
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/original-source-memory-b273180a'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',MOTION_EXECUTION_ARTIFACTS=str(out/'output-artifacts'),RUST_BACKTRACE='1',MOTION_POINTWISE_FILE_ARTIFACTS=str(out/'compiler-output-artifacts'));env.pop('MOTION_LOG',None)
metadata=json.loads(subprocess.check_output(['cargo','metadata','--no-deps','--format-version','1','--offline'],cwd=work,env=env,text=True))
render=next(p for p in metadata['packages'] if p['name']=='motion-render')
targets=sorted(t['name'] for t in render['targets'] if t['kind']==['test'])
assert len(targets)>20,targets
all_native=['cargo','test','-p','motion-render','--offline','--no-fail-fast']
for target in targets: all_native+=['--test',target]
all_native+=['--','--test-threads=1']
steps=[('group-code-green',['cargo','test','-p','motion-graph','--test','groups','pure_group_wrapping_preserves_actual_compiled_code_and_runtime_template','--offline','--','--exact','--test-threads=1'])]
if len(sys.argv)>2 and sys.argv[2]=='focused': steps=steps[:2]
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
receipt=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),source=inputs,startedUtc=now(),controllerPid=os.getpid(),steps=[])
for name,cmd in steps:
 stage=out/name;stage.mkdir();item=dict(name=name,command=cmd,startedUtc=now());receipt['steps'].append(item)
 print(json.dumps(dict(starting=name,output=str(stage))),flush=True)
 with (stage/'stdout.log').open('wb') as stdout,(stage/'stderr.log').open('wb') as stderr:
  process=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr);item['cargoPid']=process.pid;(out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');code=process.wait()
 item.update(exitCode=code,completedUtc=now(),sourceUnchanged=source()==inputs)
 for stream in ['stdout','stderr']:item[stream+'Sha256']=hashlib.sha256((stage/(stream+'.log')).read_bytes()).hexdigest()
 (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
 assert item['sourceUnchanged'],'source changed during gate'
 if code:print(json.dumps(dict(stage=name,exitCode=code)),flush=True);sys.exit(code)
 if name!='desktop-check':
  results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (stage/'stdout.log').read_text(encoding='utf-8'))
  assert results and sum(int(r[0]) for r in results)>0,(name,results)
  assert all(int(r[1])==0 for r in results),(name,results)
  item['totals']=dict(passed=sum(int(r[0]) for r in results),failed=0,ignored=sum(int(r[2]) for r in results),targets=len(results))
 print(json.dumps(dict(completed=name,exitCode=code,totals=item.get('totals'))),flush=True)
receipt.update(completedUtc=now(),sourceUnchanged=source()==inputs)
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,output=str(out))),flush=True)

