"""Serialize current-main prerender boundary controls after both live owners."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/prerender-disk-cache'
OUT = ROOT / 'artifacts/pr-queue/prerender-rebased-main-v1'
HEAD = '02a19dadbf26b06ebea365775c965e0daa1f0e54'
BASE = 'f2e9f0e82f625eb0e1095857bf3e98d917bcfbcf'
PARENTS = [(22572, 'prerender-combined-v7'), (39828, 'prerender-draw-phases-v1')]

def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git', *args], cwd=WORK).decode('utf-8').strip()
def sources():
    return {name: hashlib.sha256((WORK/name).read_bytes()).hexdigest()
        for name in git('ls-files', '-z').split('\0')
        if name and name.endswith(('.rs','.toml','.lock','.wgsl','.json','.yml','.yaml','.py','.md'))}

assert git('branch','--show-current') == 'codex/82-final-integration'
assert git('rev-parse','HEAD') == HEAD and not git('status','--porcelain')
assert git('merge-base',HEAD,BASE) == BASE
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
source = sources()
report = dict(status='queued',controllerPid=os.getpid(),head=HEAD,mainBase=BASE,
    source=source,steps=[],parents=[],startedUtc=now(),
    limits='Current-main integration components only, not final workspace or issue82 acceptance. No strict input failure, historical native crash or exact8bb CI result is erased. Source is frozen through this gate; no panel edits or Android validation.')
def save():
    temp=OUT/'exit.next.json'
    temp.write_text(json.dumps(report,indent=2),encoding='utf-8')
    os.replace(temp,OUT/'exit.json')

env=os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),
    CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',
    CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',
    LOCALAPPDATA=str(OUT/'owned-profile'),PYTHONPATH=str(ROOT/'.tools/build-validation-python'))

def step(name,args,expected=None):
    active=dict(name=name,command=args,startedUtc=now(),phase='starting')
    report['activeStep']=active;save()
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        active.update(pid=child.pid,phase='running');save()
        code=child.wait()
    active.update(exitCode=code,phase='exited',completedUtc=now());save()
    text=(OUT/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace')
    errors=(OUT/f'{name}.stderr.log').read_text(encoding='utf-8',errors='replace')
    counts=re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
    row=dict(name=name,command=args,exitCode=code,counts=counts,
        startedUtc=active['startedUtc'],completedUtc=active['completedUtc'],
        sourceUnchanged=sources()==source and git('rev-parse','HEAD')==HEAD)
    row['passed']=code==0 and row['sourceUnchanged'] and (expected is None or counts==[(str(expected),'0','0')])
    report['steps'].append(row);save()
    if re.search(r'(?i)0xc000[0-9a-f]+|unsafe precondition|non-unwinding panic|stack overflow',text+'\n'+errors):
        target=(ROOT/'target/gltf-animation87-contract/debug/deps').resolve()
        candidates=set()
        for raw in re.findall(r'([A-Za-z]:[^\r\n`"<>]*?\.exe)',text+'\n'+errors):
            path=Path(raw.strip().lstrip('(')).resolve()
            if path.parent==target and path.is_file(): candidates.add(path)
        for path in sorted(candidates)[:3]:
            for original in [path,path.with_suffix('.pdb')]:
                if not original.is_file(): continue
                dest=OUT/'native-failures'/name/original.name
                dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(original,dest)
                digest=hashlib.sha256(original.read_bytes()).hexdigest()
                assert hashlib.sha256(dest.read_bytes()).hexdigest()==digest
                report.setdefault('nativeEvidence',[]).append(dict(path=str(dest),sha256=digest))
        save()
    print(json.dumps(row),flush=True)
    assert row['passed'],f'{name}: raw output and actual exit retained; no later build'
    report.pop('activeStep',None);save()

kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
kernel.OpenProcess.restype=wintypes.HANDLE
kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD]
kernel.WaitForSingleObject.restype=wintypes.DWORD
kernel.CloseHandle.argtypes=[wintypes.HANDLE]
handles=[]
save()
try:
    for pid,receipt in PARENTS:
        handle=kernel.OpenProcess(0x100000,False,pid)
        assert handle and kernel.WaitForSingleObject(handle,0)==258,f'exact parent not live: {pid}'
        handles.append(handle)
        report['parents'].append(dict(pid=pid,receipt=receipt,handleCapturedLive=True))
    save()
    print(json.dumps(dict(queuedBehind=[pid for pid,_ in PARENTS])),flush=True)
    for handle in handles:
        while True:
            result=kernel.WaitForSingleObject(handle,1000)
            if result==0: break
            assert result==258
    for row in report['parents']:
        previous=json.loads((ROOT/'artifacts/pr-queue'/row['receipt']/'exit.json').read_text(encoding='utf-8'))
        assert previous.get('completedUtc'),f'{row["receipt"]} stopped without terminal evidence'
        row['terminal']={k:previous.get(k) for k in ['head','status','completedUtc']}
    active=subprocess.check_output(['powershell','-NoProfile','-Command',
        "@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('rustc.exe','link.exe','cargo.exe') -and $_.CommandLine -match 'gltf-animation87-contract' }).Count"]).decode().strip()
    assert active=='0',f'owned target still active: {active}'
    assert sources()==source and git('rev-parse','HEAD')==HEAD
    for name in ['crates/motion-model/src/lib.rs','crates/motion-core/src/lib.rs',
        'crates/motion-render/src/lib.rs','crates/motion-host/src/lib.rs',
        'crates/motion-desktop-media/src/lib.rs','desktop/app/src/main.rs']:
        os.utime(WORK/name,None)
    assert sources()==source
    report.update(status='running',releasedUtc=now());save()
    Path(env['LOCALAPPDATA']).mkdir()
    step('host-static-roving',['cargo','test','-p','motion-host','--features','ai-depth','--locked','--offline','--lib','prerender::static_intervals::tests::','--','--test-threads=1'],expected=3)
    step('media-spatial-native',['cargo','test','-p','motion-desktop-media','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--lib','movie::prerender::tests::spatial_timing::','--','--test-threads=1'],expected=2)
    desktop=['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--bin','motion-studio']
    step('desktop-source-inventory',desktop+['--','--list'])
    names=['engine::failure::composition_tests::timing_admission::unsupported_timing_is_quiet_and_preserves_default_output_channels',
        'shell::effect_application::tests::recent_menu::an_actual_worker_rejects_stale_menu_targets_without_partial_additions_or_extra_history']
    listing=(OUT/'desktop-source-inventory.stdout.log').read_text(encoding='utf-8')
    assert all(name+': test' in listing for name in names)
    for name,label in zip(names,['timing-child-wrapper','recent-child-wrapper']):
        step(label,desktop+[name,'--','--exact','--test-threads=1'],expected=1)
    step('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'])
    step('provenance',[sys.executable,'tools/validate_provenance.py'])
    step('tool-inventory',[sys.executable,'tools/validation_inventory.py'])
    report.update(status='accepted_current_main_boundary_components_not_issue_completion',completedUtc=now());save()
except BaseException as error:
    report.update(status='failed',completedUtc=now(),failure=repr(error));save()
    raise
finally:
    for handle in handles: kernel.CloseHandle(handle)
