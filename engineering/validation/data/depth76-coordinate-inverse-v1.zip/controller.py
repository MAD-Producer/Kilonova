"""Execute complete existing depth targets plus the new inverse-coordinate controls."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/reference-depth76'
OUT = ROOT / 'artifacts/pr-queue/depth76-coordinate-inverse-v1'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
paths = ['Cargo.lock', 'crates/motion-model/Cargo.toml', 'crates/motion-model/src/depth.rs',
         'crates/motion-model/tests/depth.rs', 'crates/motion-model/tests/depth_prepared.rs',
         'crates/motion-model/tests/depth_blend_coordinates.rs']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = lambda: {p: sha(WORK / p) for p in paths}
command = ['cargo', 'test', '-p', 'motion-model', '--test', 'depth', '--test', 'depth_prepared',
           '--test', 'depth_blend_coordinates', '--locked', '--offline', '--', '--test-threads=1']
environment = os.environ.copy()
environment.update(CARGO_TARGET_DIR=str(ROOT / 'target/reference-depth76-contract'),
                   CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_BUILD_JOBS='1',
                   CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0',
                   TEMP=str(ROOT / 'target/ci-policy-validation-tmp'), TMP=str(ROOT / 'target/ci-policy-validation-tmp'))
report = dict(status='running', command=command, source=sources(),
              baseCommit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip(),
              startedUtc=datetime.now(timezone.utc).isoformat(),
              scope='Three complete model targets; inverse coordinate foundation, not complete issue76 blend delivery')
receipt = OUT / 'exit.json'
save = lambda: receipt.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
save()
began = time.monotonic()
try:
    with (OUT / 'stdout.log').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
        process = subprocess.Popen(command, cwd=WORK, env=environment, stdout=stdout, stderr=stderr)
        report['pid'] = process.pid
        save()
        report['exitCode'] = process.wait()
    report['sourceUnchanged'] = sources() == report['source']
    report['status'] = 'passed_selected_complete_targets' if report['exitCode'] == 0 and report['sourceUnchanged'] else 'failed_original_outputs_retained'
except BaseException as error:
    report.update(status='failed_original_outputs_retained', error=repr(error))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=time.monotonic() - began)
    save()
print(json.dumps({k: v for k, v in report.items() if k != 'source'}))
raise SystemExit(0 if report['status'] == 'passed_selected_complete_targets' else 1)
