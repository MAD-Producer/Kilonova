"""Retain the executed coordinate increment, not whole issue-76 acceptance."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/reference-depth76'
OUT = ROOT / 'artifacts/pr-queue/depth76-coordinate-inverse-v1'
DATA = WORK / 'engineering/validation/data'
report = json.loads((OUT / 'exit.json').read_text(encoding='utf-8'))
assert report['status'] == 'passed_selected_complete_targets'
assert report['exitCode'] == 0 and report['sourceUnchanged']
sha = lambda data: hashlib.sha256(data).hexdigest()
stdout = (OUT / 'stdout.log').read_text(encoding='utf-8')
summaries = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', stdout)
assert summaries == [('8', '0', '0', '0', '0'), ('3', '0', '0', '0', '0'), ('1', '0', '0', '0', '0')], summaries
stderr = (OUT / 'stderr.log').read_text(encoding='utf-8')
for target in ('depth.rs', 'depth_blend_coordinates.rs', 'depth_prepared.rs'):
    assert stderr.count('Running tests\\' + target + ' ') == 1
entries = {name: (OUT / name).read_bytes() for name in ('controller.py', 'exit.json', 'stdout.log', 'stderr.log')}
entries['archive-controller.py'] = Path(__file__).read_bytes()
for path, expected in report['source'].items():
    content = (WORK / path).read_bytes()
    assert sha(content) == expected, path
    entries['source/' + path] = content
archive = DATA / 'depth76-coordinate-inverse-v1.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for name, content in sorted(entries.items()):
        output.writestr(name, content)
with zipfile.ZipFile(archive) as verify:
    assert set(verify.namelist()) == set(entries)
    for name, expected in entries.items():
        assert verify.read(name) == expected
manifest = dict(status='verified_coordinate_foundation_not_complete_blend',
                baseCommit=report['baseCommit'], sourceUnchanged=True,
                command=report['command'], tests=dict(passed=12, failed=0, ignored=0, filtered=0, targets=3),
                elapsedSeconds=report['elapsedSeconds'], bytes=archive.stat().st_size,
                archive=archive.name, sha256=sha(archive.read_bytes()),
                members=[dict(path=name, bytes=len(content), sha256=sha(content)) for name, content in sorted(entries.items())],
                limits=['Coordinate inverse foundation only; no depth blending or registration is delivered yet',
                        'No GPU, UI, temporal sequence or complete-workspace acceptance is claimed',
                        'Existing assertions, dependencies and source geometry policies remain unchanged'])
(DATA / 'depth76-coordinate-inverse-v1.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in manifest.items() if k != 'members'}))
