"""Actual existing resolve/attest CLI controls after finite context refactoring."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import struct
import subprocess
import time
import traceback

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-retained-context75'
PRIOR = ART / 'depth75-retained-context-v1'
OUT = ART / 'depth75-retained-contract-v1'
EXE = ROOT / 'target/depth-wgsl-cache75-contract/debug/motion-depth-wgsl.exe'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
def bindings():
    changed = set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=WORK, text=True).splitlines())
    changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines())
    assert len(changed) == 9 and not any('/panels/' in name for name in changed)
    return {name: sha(WORK / name) for name in sorted(changed)}
consumed = json.loads((PRIOR / 'session-consumed.json').read_text(encoding='utf-8'))
assert consumed['session'] == 43396 and consumed['consumed'] is True and consumed['exit_code'] == 0
prior = json.loads((PRIOR / 'receipt.json').read_text(encoding='utf-8'))
assert sha(EXE) == prior['binary_sha256']
assert shutil.disk_usage(ROOT).free >= 10 << 30
source = bindings()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert head == prior['source_head']
checkpoint = ART / 'depth75-resume-current.json'
state = json.loads(checkpoint.read_text(encoding='utf-8'))
assert state['versionedCache75']['activeController'] is None
assert not state['versionedCache75']['ownHeavyWorkloads']
OUT.mkdir(exist_ok=False)
shutil.copyfile(Path(__file__), OUT / 'controller.py')
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(TEMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'),
    TMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'),
    LOCALAPPDATA=str(OUT / 'appdata'), PYTHONDONTWRITEBYTECODE='1', RUST_BACKTRACE='full')
Path(env['LOCALAPPDATA']).mkdir()
report = dict(status='running', source_head=head, source_sha256=source,
    binary_sha256=sha(EXE), controller_sha256=sha(OUT / 'controller.py'),
    started_utc=datetime.now(timezone.utc).isoformat(), commands=[],
    limits=['Actual existing native CLI resolve/attest contract, not a Rust Jobs/Session invocation',
        'Original60-second directly owned child allowance, no retries or fallback',
        'Original complete-workspace failures remain failures; no Android/panels or model acquisition'])
state['versionedCache75'].update(activeController=str(Path(__file__)), ownHeavyWorkloads=[dict(
    kind='actual resolve/attest native controls', output=str(OUT), sourceFrozen=True)])
write(checkpoint, state)
began = time.monotonic()
def save():
    write(OUT / 'receipt.json', report)
def native(label, args, expected=0):
    path = OUT / label
    command = dict(label=label, args=[str(EXE), *map(str, args), str(path)],
        expected_exit=expected, timeout_seconds=60,
        started_utc=datetime.now(timezone.utc).isoformat())
    report['commands'].append(command)
    save()
    start = time.monotonic()
    with (OUT / (label + '.stdout.log')).open('wb') as stdout, (OUT / (label + '.stderr.log')).open('wb') as stderr:
        try:
            child = subprocess.run(command['args'], cwd=WORK, env=env, stdout=stdout, stderr=stderr, timeout=60)
            command['exit_code'] = child.returncode
        finally:
            command['elapsed_seconds'] = time.monotonic() - start
            save()
    assert command['exit_code'] == expected, command
    assert (OUT / (label + '.stdout.log')).stat().st_size == 0
    result = json.loads((path / 'receipt.json').read_text(encoding='utf-8'))
    log = (path / 'logs/motion-studio.log').read_text(encoding='utf-8')
    assert 'start #0' in log
    if expected:
        assert result['status'] == 'failed_original_cause_retained'
        assert result['failure'] in log
        assert result['failure'] in (OUT / (label + '.stderr.log')).read_text(encoding='utf-8')
    return result, path
try:
    save()
    request = json.loads((PRIOR / 'cold-0.json').read_text(encoding='utf-8'))
    del request['input']
    resolve_request = OUT / 'resolve.json'
    write(resolve_request, request)
    resolved, _ = native('resolve', ['--resolve', resolve_request])
    assert resolved['status'] == 'actual_execution_identity_resolved_without_inference'
    assert resolved['verified_resources'] == 282
    assert resolved['encoded_operations'] == resolved['final_readbacks'] == 0
    assert resolved['execution'] == prior['retained']['receipt']['execution']
    execution = OUT / 'execution.json'
    write(execution, resolved['execution'])
    outputs = []
    for index in range(2):
        result, path = native('attest-' + str(index), ['--attest', execution, PRIOR / ('cold-' + str(index) + '.json')])
        assert result['status'] == 'actual_complete_gpu_output_written_independent_comparison_pending'
        assert result['phase'] == 'completed' and result['verified_resources'] == 282
        assert result['execution'] == resolved['execution']
        assert result['encoded_operations'] == 429 and result['final_readbacks'] == 1
        assert result['per_node_cpu_injection'] is False and result['pool_retained_through_completion'] is True
        assert result['actual_retained_buffer_capacity_bytes'] == 227968156
        assert result['request_sha256'] == sha(PRIOR / ('cold-' + str(index) + '.json'))
        raw = (path / 'relative_inverse_depth.f32').read_bytes()
        assert len(raw) == result['output_bytes'] == 518 * 518 * 4
        assert hashlib.sha256(raw).hexdigest() == result['output_sha256'] == prior['cold'][index]['digest']
        assert all(__import__('math').isfinite(item[0]) for item in struct.iter_unpack('<f', raw))
        outputs.append(dict(input_index=index, output_sha256=result['output_sha256']))
    changed = dict(resolved['execution'])
    changed['runtime_sha256'] = changed['runtime_sha256'].copy()
    changed['runtime_sha256'][0] ^= 1
    changed_path = OUT / 'changed-execution.json'
    write(changed_path, changed)
    rejected, path = native('reject-changed-execution', ['--attest', changed_path, PRIOR / 'cold-0.json'], 1)
    assert 'native execution changed since cache resolution' in rejected['failure']
    assert rejected['encoded_operations'] == 0 and 'context_preparations' not in rejected
    assert not (path / 'relative_inverse_depth.f32').exists()
    report.update(status='actual_resolve_attest_and_changed_identity_controls_passed',
        resolved_execution=resolved['execution'], exact_cold_output_controls=outputs)
except BaseException:
    report.update(status='failed_original_outputs_retained', cause=traceback.format_exc())
finally:
    try:
        report['source_unchanged'] = bindings() == source and sha(EXE) == report['binary_sha256']
    except BaseException:
        report['source_unchanged'] = False
        report['source_verification_failure'] = traceback.format_exc()
    report.update(completed_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - began)
    save()
print(json.dumps({key:report.get(key) for key in ('status', 'cause', 'source_unchanged', 'elapsed_seconds')}))
raise SystemExit(0 if report['status'] == 'actual_resolve_attest_and_changed_identity_controls_passed' and report['source_unchanged'] else 1)
