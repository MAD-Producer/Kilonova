"""Consume existing-contract controls and publish only their original observations."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import zipfile

root = Path('E:/Dev/aem')
art = root / 'artifacts/pr-queue'
actual = art / 'depth75-retained-contract-v1'
work = root / '.worktrees/depth-retained-context75'
public = art / 'depth75-retained-contract-public-v1'
receipt = json.loads((actual / 'receipt.json').read_text(encoding='utf-8'))
assert receipt['status'] == 'actual_resolve_attest_and_changed_identity_controls_passed'
assert receipt['source_unchanged'] is True
assert len(receipt['commands']) == 4
assert [item['exit_code'] for item in receipt['commands']] == [0, 0, 0, 1]
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for name, expected in receipt['source_sha256'].items():
    assert sha(work / name) == expected
assert sha(root / 'target/depth-wgsl-cache75-contract/debug/motion-depth-wgsl.exe') == receipt['binary_sha256']
marker = actual / 'session-consumed.json'
assert not marker.exists()
consumed = dict(session=86672, consumed=True, exit_code=0, source_unchanged=True,
    status=receipt['status'], observed_utc=datetime.now(timezone.utc).isoformat())
marker.write_text(json.dumps(consumed, indent=2) + '\n', encoding='utf-8')
public.mkdir(exist_ok=False)
shutil.copyfile(Path(__file__), public / 'collection-controller.py')
for path in sorted(actual.rglob('*')):
    if path.is_file() and 'appdata' not in path.relative_to(actual).parts and path.suffix in ('.json', '.py', '.log'):
        target = public / 'actual' / path.relative_to(actual)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
members = {}
for path in sorted(public.rglob('*')):
    if path.is_file():
        members[path.relative_to(public).as_posix()] = dict(bytes=path.stat().st_size, sha256=sha(path))
archive = public / 'depth75-retained-contract-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
    for name in members:
        target.write(public / name, name)
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(members)
    for name, expected in members.items():
        data = target.read(name)
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
manifest = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=members,
    readback='Every member CRC, length and SHA-256 verified',
    limits='Existing native CLI contract only; not an actual Rust Jobs/Session call, live service or broad regression pass')
(public / 'depth75-retained-contract-v1.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
for extension in ('.json', '.zip'):
    target = work / 'engineering/validation/data' / ('depth75-retained-contract-v1' + extension)
    assert not target.exists()
    shutil.copyfile(public / target.name, target)
path = work / 'engineering/validation/depth75-retained-context-current.md'
text = path.read_text(encoding='utf-8')
assert '## Existing resolve/attest CLI controls' not in text
text += f'''
## Existing resolve/attest CLI controls

After consuming the finite comparison, original session 86672 exercised the
same binary's existing `--resolve` and `--attest` routes with source frozen.
Resolution verified all 282 resources and returned the same actual execution
identity as the finite batch without encoding inference operations. Attested
A and B each completed 429 operations and one final readback; both entire output
digests matched their corresponding cold outputs. A changed-runtime identity
was rejected with its original cause before context preparation/inference, with
Error in file/stderr, empty stdout and no output. The four commands returned
0/0/0/1 as declared and completed in {receipt['elapsed_seconds']:.3f} seconds.

Original session 86672 was consumed with exit 0; source and binary were unchanged.
The [contract manifest](data/depth75-retained-contract-v1.json) and
[contract archive](data/depth75-retained-contract-v1.zip) retain {len(members)}
members, {manifest['bytes']:,} bytes, SHA-256 `{manifest['sha256']}`.
Every member passed CRC, length and SHA-256 readback. This verifies the existing
native CLI contracts, not an actual Rust Jobs/Session invocation, a persistent
application backend or a replacement for the failed complete-workspace run.
'''
path.write_text(text, encoding='utf-8')
checkpoint = art / 'depth75-resume-current.json'
state = json.loads(checkpoint.read_text(encoding='utf-8'))
current = state['versionedCache75']
current.update(activeController=None, ownHeavyWorkloads=[], retainedContractResult=dict(
    status=receipt['status'], originalSession=86672, consumed=True, exitCode=0,
    receipt=str(actual / 'receipt.json'), archive=str(archive), archiveSha256=manifest['sha256']))
state['updatedUtc'] = consumed['observed_utc']
checkpoint.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status=receipt['status'], consumed=True, exit_code=0,
    archive_bytes=manifest['bytes'], archive_sha256=manifest['sha256'], members=len(members))))
