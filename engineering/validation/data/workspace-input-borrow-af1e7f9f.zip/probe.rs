use super::*;
use motion_ui::InputSource;
#[path = "E:/Dev/aem/.tools/workspace-input-borrow/allocator.rs"]
mod counts;

fn frame(p: &mut Panels, s: &Value, input: &Input, atlas: &mut TextAtlas,
    size: [f32;2], floating: bool) -> (PaintList,Vec<Action>) {
    let mut paint=PaintList::default();
    let mut actions=Vec::new();
    if floating {
        actions=super::super::super::floating_chrome(&mut paint,atlas,Panel::Timeline,size,p,s,input);
    } else {
        actions=super::super::super::chrome(&mut paint,atlas,size,
            &dock::Node::dock(Panel::Timeline.dock()),p,s,input);
    }
    (paint,actions)
}

fn snapshot(paint:PaintList, actions:Vec<Action>, p:&Panels, state:&Value)->String {
    let c=&p.timeline.comparison;
    let channels:Vec<_>=c.entries.iter().map(|e|
        format!("{:?}/{}:{}",e.channel.target,e.channel.component,e.visible)).collect();
    format!("{:?}",(paint.shapes,paint.colors,paint.glyphs,paint.order,actions,
        (p.selected,p.timeline.graph_mode,p.timeline.speed_graph,c.enabled,c.channels_open,
         c.mode.open,c.bar_focus,c.unit.as_ref().map(|u|u.title(p.timeline.speed_graph)),channels),state))
}

#[test]
fn record_real_window_frames_and_input_allocations() {
    let folder=std::path::PathBuf::from(std::env::var_os("MOTION_CURVE_INPUT_PROBE_OUT").unwrap());
    std::fs::create_dir_all(&folder).unwrap();
    let engine=fixture();let state=state(&engine);let original=state.clone();
    let mut records=Vec::new();
    for locale in [Locale::En,Locale::Zh] {
        let mut atlas=TextAtlas::from_system_language(12.,locale==Locale::Zh).unwrap();
        for size in [[900.,600.],[1600.,1000.]] {
            for floating in [false,true] {
                for popup in [false,true] {
                    for mode in ["normal","composing","ime-consumed","focus-lost"] {
                        for payload in [false,true] {
                            let name=format!("{:?}-{}x{}-float{}-popup{}-{}-payload{}",locale,size[0],size[1],floating,popup,mode,payload);
                            let input=Input {
                                mouse:[-100.,-100.],
                                keys:if payload {vec![(Key::F8,Modifiers::default());3]}else{vec![]},
                                key_repeats:if payload {vec![false,true,false]}else{vec![]},
                                held_keys:if payload {vec![Key::F8;3]}else{vec![]},
                                released_keys:if payload {vec![Key::F8;2]}else{vec![]},
                                text:if payload {"测🙂e\u{301}".repeat(8192)}else{String::new()},
                                composing:mode=="composing",ime_consumed:mode=="ime-consumed",focus_lost:mode=="focus-lost",
                                ..Default::default()
                            };
                            let input_before=format!("{:?}",input.input_view());
                            let mut requests=0usize;let mut bytes=0usize;let mut first=None;
                            for iteration in 0..13 {
                                let mut p=setup(&state,locale);p.timeline.comparison.channels_open=popup;
                                let mut output=None;
                                let measured=counts::measure(||output=Some(frame(&mut p,&state,&input,&mut atlas,size,floating)));
                                let (paint,actions)=output.unwrap();
                                assert!(actions.is_empty(),"{name}: {actions:?}");
                                assert_eq!(state,original);assert_eq!(format!("{:?}",input.input_view()),input_before);
                                if iteration>=3 {
                                    requests+=measured.0;bytes+=measured.1;
                                    if first.is_none(){first=Some(snapshot(paint,actions,&p,&state));}
                                }
                            }
                            std::fs::write(folder.join(format!("{name}.txt")),first.unwrap()).unwrap();
                            records.push(serde_json::json!({"name":name,"locale":format!("{locale:?}"),"size":size,"floating":floating,
                                "popup":popup,"mode":mode,"payload":payload,"payload_bytes":input.text.len(),"frames":10,
                                "allocation_requests":requests,"requested_bytes":bytes}));
                        }
                    }
                }
            }
        }
    }
    assert_eq!(records.len(),128);
    std::fs::write(folder.join("records.json"),serde_json::to_vec_pretty(&records).unwrap()).unwrap();
}
