from pathlib import Path
import subprocess,hashlib,json,time,os,re
root=Path('E:/Dev/aem');out=root/'.tools/workspace-input-borrow';work=root/'.worktrees/workspace-input-borrow';sources=json.loads((out/'production-source.json').read_text(encoding='utf8'))
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sources}
assert freeze()==sources;(work/'desktop/app/src/main.rs').touch();records=[]
common=['cargo','test','-p','motion-desktop','--bin','motion-studio','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1']
steps=[('panel-regressions','panels::',563,1,False),('node-regressions','node_editor::',164,0,False),('protocol-regressions','shell::effect_timeline_acceptance::',3,0,False),('native-final','shell::curve_comparison_tests::curve_comparison_native_main_and_float_pixels_preserve_authored_project',1,0,True)]
for label,pattern,expected,ignored,native in steps:
 command=common+[pattern,'--','--test-threads=1']
 if native:command+=['--exact','--ignored']
 env=os.environ.copy();env.pop('MOTION_LOG',None);env['MOTION_CURVE_COMPARISON_GPU_ARTIFACTS']=str(out/'native-final');start=time.monotonic();print(label+' started',flush=True)
 with (out/(label+'.log')).open('w',encoding='utf8') as log:r=subprocess.run(command,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(out/(label+'.log')).read_text(encoding='utf8');summary=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 item=dict(label=label,command=command,exit_code=r.returncode,seconds=round(time.monotonic()-start,2),sources=sources,source_unchanged=freeze()==sources,binary_sha256=hashlib.sha256((root/'target/debug/deps/motion_studio-d5bd28a41c2d0117.exe').read_bytes()).hexdigest());records.append(item)
 (out/'final-validation.json').write_text(json.dumps(records,indent=2),encoding='utf8');assert r.returncode==0 and summary and item['source_unchanged']
 item['passed'],item['failed'],item['ignored']=map(int,summary.groups());assert (item['passed'],item['failed'],item['ignored'])==(expected,0,ignored)
 assert 'input_borrow_probe::' not in text
 if label=='panel-regressions':assert any('Compiling motion-desktop ' in line and str(work).replace('\\','/').casefold() in line.replace('\\','/').casefold() for line in text.splitlines())
 else:assert item['binary_sha256']==records[0]['binary_sha256']
 if native:
  pngs=sorted((out/'native-final').glob('*.png'));assert len(pngs)==13
  item['pngs_equal_to_accepted_baseline']=all(p.read_bytes()==(root/'.tools/curve-input-views/native-final'/p.name).read_bytes() for p in pngs);assert item['pngs_equal_to_accepted_baseline']
 (out/'final-validation.json').write_text(json.dumps(records,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in item.items() if k!='sources'}),flush=True)
