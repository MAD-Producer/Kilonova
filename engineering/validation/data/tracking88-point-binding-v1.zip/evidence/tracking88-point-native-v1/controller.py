"""Own serial executable acceptance: original video PTS -> tracked null -> actual OBJ renderer."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,struct,subprocess,copy
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-point-native-v1'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def now():return datetime.now(timezone.utc).isoformat()
names=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
sources={n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (WORK/n).is_file()}
report=dict(status='running',controllerPid=os.getpid(),startedUtc=now(),source=sources,steps=[],scope='New point-binding executable target, not a retry or repair of earlier full-host native crashes or MCP test compilation fault')
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def identity():
 for n,h in sources.items():assert hashlib.sha256((WORK/n).read_bytes()).hexdigest()==h,n
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'local-appdata'))
EXE=ROOT/'target/gltf-animation87-contract/debug/motion-studio.exe';project_root=OUT/'project';active=[]
def build():
 identity();args=['cargo','build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline']
 row=dict(name='ffmpeg-build',command=args,startedUtc=now());report['steps'].append(row);save()
 with (OUT/'build.stdout.log').open('wb') as stdout,(OUT/'build.stderr.log').open('wb') as stderr:
  p=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait()
 row['completedUtc']=now();save();assert row['exitCode']==0,row
class Rpc:
 def __init__(self,name,readonly=False):
  identity();self.name=name;self.inputs=[];self.raw=[];self.next_id=0
  args=[str(EXE),'--mcp','--project',str(project_root)]+(['--mcp-read-only'] if readonly else [])
  self.row=dict(name=name,command=args,startedUtc=now(),exeSha256=hashlib.sha256(EXE.read_bytes()).hexdigest());report['steps'].append(self.row)
  self.stderr=(OUT/f'{name}.stderr.log').open('wb')
  self.p=subprocess.Popen(args,cwd=WORK,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr,text=True,encoding='utf-8');active.append(self)
  self.row['pid']=self.p.pid;save()
  self.request('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='owned-point-binding-proof',version='1')))
  self.send(dict(jsonrpc='2.0',method='notifications/initialized'))
 def send(self,message):
  self.inputs.append(message);self.p.stdin.write(json.dumps(message)+'\n');self.p.stdin.flush()
 def request(self,method,params):
  self.next_id+=1;self.send(dict(jsonrpc='2.0',id=self.next_id,method=method,params=params))
  line=self.p.stdout.readline();self.raw.append(line);assert line,f'{self.name}: stdout closed'
  reply=json.loads(line);assert reply['jsonrpc']=='2.0' and reply['id']==self.next_id and 'error' not in reply,reply
  return reply['result']
 def call(self,name,args):return self.request('tools/call',dict(name=name,arguments=args))
 def ok(self,name,args):
  result=self.call(name,args);assert not result['isError'],result;return result['structuredContent']
 def state(self):return self.ok('motion_state',{})
 def close(self):
  if self.p.stdin and not self.p.stdin.closed:self.p.stdin.close()
  trailing=self.p.stdout.read();assert not trailing,repr(trailing)
  self.row['exitCode']=self.p.wait();self.stderr.close();self.row['completedUtc']=now()
  (OUT/f'{self.name}.stdin.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in self.inputs),encoding='utf-8')
  (OUT/f'{self.name}.stdout.jsonl').write_text(''.join(self.raw),encoding='utf-8')
  log=OUT/'local-appdata/MotionStudio/logs/motion-studio.log'
  if log.exists():(OUT/f'{self.name}.file.log').write_bytes(log.read_bytes())
  active.remove(self);save();assert self.row['exitCode']==0,self.name
save()
try:
 build()
 boot=Rpc('bootstrap');project=boot.state()['project'];boot.close();assert project['version']==33
 project.update(width=640,height=480,fps=24,frames=96,work_area=dict(in_frame=0,out_frame=96),background=[0.02,0.02,0.02,1.])
 name='video-ctts.mp4';folder=WORK/'crates/motion-media/tests/fixtures/video';timing=json.loads((folder/'native-timing.json').read_text(encoding='utf-8'))[name]
 ticks=timing['timescale'];pts=sorted(s[0] for s in timing['samples']);assert ticks==1_000_000 and len(pts)==72
 source=project_root/'assets/plate.mp4';source.parent.mkdir(exist_ok=True);shutil.copyfile(folder/name,source)
 end=max(s[0]+s[1] for s in timing['samples'])
 project['video_assets']=[dict(id=1,path='assets/plate.mp4',bytes=source.stat().st_size,mime='video/avc',track=0,width=256,height=144,rotation=0,display_width=256,display_height=144,video_start_us=pts[0],video_end_us=end,duration_us=end,frame_count=len(pts),variable_frame_rate=True,nominal_frame_rate=24.,color_standard=1,color_range=2,audio_asset=None)]
 (project_root/'project.json').write_text(json.dumps(project),encoding='utf-8')
 cache=project_root/'cache/video-v2/plate/index.pts';cache.parent.mkdir(parents=True)
 cache.write_bytes(b'MSVID001'+struct.pack('<Q',source.stat().st_size)+b''.join(struct.pack('<Q',v) for v in pts))
 points=[[32.+80.*(v-pts[0])/(pts[-1]-pts[0]),40.+40.*(v-pts[0])/(pts[-1]-pts[0])] for v in pts]
 solve=dict(version=1,source_id='independently-authored point motion on repo original video',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),source_extent=[256,144],coordinates='right_down_forward',ticks_per_second=ticks,nominal_rate=[24,1],source_pts=pts,meters_per_world_unit=None,tracks=[dict(id='point-motion',kind='point',reference_index=None,samples=[dict(source_index=i,visibility='visible',confidence=1.,manual_correction=i==24,observation=dict(kind='point',pixels=point)) for i,point in enumerate(points)])])
 original=b' \n'+json.dumps(solve,indent=2).encode()+b'\r\n';document=OUT/'original.mstrack';document.write_bytes(original)
 live=Rpc('point-binding');before=live.state()
 imported=live.ok('import_tracking',dict(path=str(document),source=dict(kind='video',id=1),expectedRevision=before['revision'],expectedDocumentGeneration=before['document_generation']))
 descriptor=imported['project']['tracking_assets'][0];assert descriptor['id']==2 and (project_root/descriptor['path']).read_bytes()==original
 # Independently authored cube: no external assets, materials, textures, or copied data.
 obj=OUT/'owned-cube.obj';obj.write_text('''o OwnedCube
v -0.5 -0.5 -0.5
v 0.5 -0.5 -0.5
v 0.5 0.5 -0.5
v -0.5 0.5 -0.5
v -0.5 -0.5 0.5
v 0.5 -0.5 0.5
v 0.5 0.5 0.5
v -0.5 0.5 0.5
f 1 4 3 2
f 5 6 7 8
f 1 2 6 5
f 4 8 7 3
f 1 5 8 4
f 2 3 7 6
''',encoding='utf-8')
 model=live.ok('import_model',dict(path=str(obj),expectedRevision=imported['revision']));model_layer=next(l for l in model['project']['layers'] if l['content']['kind']=='model');model_id=model_layer['id']
 parent=copy.deepcopy(model_layer);parent.update(id=700,name='Original-PTS tracked null',content=dict(kind='null'),size=[1.,1.],parent=None)
 parent['transform']['position']['value']=[220.,180.,0.]
 def edit(commands):
  current=live.state();return live.ok('motion_edit',dict(commands=commands,expectedRevision=current['revision']))
 edit([dict(op='add',layer=parent),dict(op='parent_with_mode',object=model_id,parent=700,frame=0,mode='preserve_local'),dict(op='set_vector',object=model_id,property='rotation',frame=0,value=[25.,35.,0.])])
 binding=dict(asset=2,track='point-motion',anchor_local_frame=0,source_anchor_pts=pts[0],speed_numerator=1,speed_denominator=1,reference_pixels=points[0],crop=[0.,0.,256.,144.],rotation='none',interpolation='linear',max_gap_ticks=100000,minimum_confidence=0.8,missing='error')
 before=live.state();bad=copy.deepcopy(binding);bad['track']='absent'
 rejected=live.call('motion_edit',dict(commands=[dict(op='set_tracking_point',object=700,binding=bad)],expectedRevision=before['revision']))
 assert rejected['isError'] and 'phase=binding object=700 asset=2 track=absent' in rejected['content'][0]['text'],rejected
 unchanged=live.state();assert unchanged['project']==before['project'] and unchanged['revision']==before['revision']
 bound=edit([dict(op='set_tracking_point',object=700,binding=binding)])
 rows=[]
 for frame in [0.,30.]:
  sampled=live.ok('motion_seek',dict(frame=frame));anchor=next(l['anchor'] for l in sampled['projectedLayers'] if l['id']==700)
  fraction=(frame/24.*ticks)/(pts[-1]-pts[0]);expected=[220.+200.*fraction,180.+(40.*480./144.)*fraction]
  assert all(abs(anchor[i]-expected[i])<0.003 for i in range(2)),(frame,anchor,expected)
  capture=live.ok('render_preview',dict(frame=frame));rows.append(dict(frame=frame,anchor=anchor,expected=expected,capture=capture))
 report['samples']=rows;save()
 document.unlink() # The external JSON is no longer needed by runtime, undo, or reopen.
 undone=live.ok('motion_history',dict(operation='undo'));layer=next(l for l in undone['project']['layers'] if l['id']==700);assert layer.get('tracking_point') is None
 anchor=next(l['anchor'] for l in undone['projectedLayers'] if l['id']==700);assert all(abs(anchor[i]-[220.,180.][i])<0.003 for i in range(2)),anchor
 redone=live.ok('motion_history',dict(operation='redo'));assert redone['project']==bound['project']
 assert not any(next(l for l in redone['project']['layers'] if l['id']==700)['transform']['position'].get('keys',[]))
 live.ok('motion_seek',dict(frame=0.))
 strict=copy.deepcopy(binding);strict['max_gap_ticks']=0
 strict_state=edit([dict(op='set_tracking_point',object=700,binding=strict)])
 failed_sample=live.call('motion_seek',dict(frame=0.5))
 assert failed_sample['isError'] and 'tracking interpolation gap exceeds policy' in failed_sample['content'][0]['text'],failed_sample
 recovered=live.ok('motion_edit',dict(commands=[dict(op='set_tracking_point',object=700,binding=binding)],expectedRevision=strict_state['revision']))
 assert recovered['project']==bound['project']
 live.ok('motion_save',{});live.close()
 saved=json.loads((project_root/'project.json').read_text(encoding='utf-8'));assert saved['version']==33 and saved['tracking_assets'][0]['data']['tracks'][0]['samples'][24]['manual_correction'] is True
 reopen=Rpc('readonly-reopen',True);assert reopen.state()['project']==bound['project'];reopen.close()
 from PIL import Image
 captures=sorted((project_root/'exports').glob('frame-*.png'));assert len(captures)==2,captures
 boxes=[]
 for p in captures:
  img=Image.open(p).convert('RGB');assert img.size==(640,480)
  mask=img.point(lambda x:255 if x>80 else 0).convert('L');bbox=mask.getbbox();assert bbox is not None,bbox;boxes.append(bbox)
 assert boxes[1][0]-boxes[0][0]>50 and boxes[1][1]-boxes[0][1]>25,boxes
 report['renderBounds']=boxes
 log=(OUT/'point-binding.file.log').read_text(encoding='utf-8');stderr=(OUT/'point-binding.stderr.log').read_text(encoding='utf-8',errors='replace')
 for sink in [log,stderr]:
  assert 'phase=binding object=700 asset=2 track=absent' in sink and re.search(r'error #\d+',sink),sink[-4000:]
  assert 'tracking interpolation gap exceeds policy' in sink and 'frame=0.5' in sink,sink[-4000:]
 assert ' INFO ' in log and re.search(r'start #\d+ import_tracking',log)
 identity();report.update(status='accepted_native_point_increment_not_full_issue',originalSha256=hashlib.sha256(original).hexdigest(),frames=len(pts),sourceSha256=solve['source_sha256'])
except BaseException as error:report.update(status='failed',failure=repr(error));raise
finally:
 for rpc in list(active):
  try:rpc.close()
  except BaseException as secondary:report.setdefault('cleanupFailures',[]).append(repr(secondary))
 report['completedUtc']=now();save()
