from pathlib import Path
import subprocess,json,hashlib,os,re
from datetime import datetime,timezone
root=Path('E:/Dev/aem'); work=root/'.worktrees/tracking-import88'; out=root/'artifacts/pr-queue/tracking88-point-v3';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
def now(): return datetime.now(timezone.utc).isoformat()
names=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard'],cwd=work,text=True).splitlines()
source={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(set(names)) if (work/p).is_file()}
report=dict(status='running',startedUtc=now(),controllerPid=os.getpid(),source=source,steps=[],remaining='Earlier full-host native crashes and MCP compiler fault remain unqualified; unchanged failed targets are not retried here')
def save(): (out/'exit.json').write_text(json.dumps(report,indent=2))
env=os.environ.copy();env.update(CARGO_HOME=str(root/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full');env.pop('MOTION_LOG',None)
steps=[('model-tests',['cargo','test','-p','motion-model','--locked','--offline','--','--test-threads=1']),('core-tests',['cargo','test','-p','motion-core','--locked','--offline','--','--test-threads=1']),('host-tracking',['cargo','test','-p','motion-host','--lib','tracking::','--locked','--offline','--','--test-threads=1']),('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg','--locked','--offline'])]
save()
try:
 for name,args in steps:
  for p,h in source.items(): assert hashlib.sha256((work/p).read_bytes()).hexdigest()==h,p
  row=dict(name=name,command=args,startedUtc=now());report['steps'].append(row);save()
  with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
   proc=subprocess.Popen(args,cwd=work,env=env,stdout=stdout,stderr=stderr);row['pid']=proc.pid;save();row['exitCode']=proc.wait()
  row['completedUtc']=now();row['counts']=[list(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (out/(name+'.stdout.log')).read_text(encoding='utf-8',errors='replace'))];save()
  print(name,row['exitCode'],row['counts'],flush=True);assert row['exitCode']==0,name
 report['status']='accepted_increment_cpu_gates_not_full_issue'
except BaseException as e:report.update(status='failed',failure=repr(e));raise
finally:report['completedUtc']=now();save()
