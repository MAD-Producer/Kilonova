"""Validate a message-only repair using the actual failed test's assertion.

The frozen product tree is read only. Native-status children use process::exit;
they are synthetic exit-status controls, not CPU exceptions or crash fixes.
"""
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/native-prerender-runtime'
OUT=ROOT/'artifacts/pr-queue/prerender-effect-search-child-status-v1'
NAME='desktop/app/src/shell/effect_application/tests.rs'
BASE='652fbe6525f5813a85620fe0d5d2ad4eef5f9bfb'
SOURCE_SHA='e34b52dae8a5c0b5cfa8d47f9bbda12af61a579895fb46887704a098f28bb233'
OUT.mkdir(exist_ok=False)
original=(WORK/NAME).read_bytes()
assert hashlib.sha256(original).hexdigest()==SOURCE_SHA
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK).decode().strip()==BASE
text=original.decode('utf-8')
old='''assert!(
        output.status.success(),
        "{}\\n{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );'''
# Only line endings are normalized for extracting this exact Rust expression.
normalized=text.replace('\r\n','\n')
assert normalized.count(old)==1
new=old.replace('"{}\\n{}",','"child status={}\\n{}\\n{}",\n        output.status,')
assert old.split(',')[0]==new.split(',')[0]
proposed=normalized.replace(old,new)
patch=''.join(difflib.unified_diff(normalized.splitlines(keepends=True),proposed.splitlines(keepends=True),
    fromfile='a/'+NAME,tofile='b/'+NAME))
(OUT/'proposal.patch').write_text(patch,encoding='utf-8')
program='''use std::process::{Command,exit};
fn main() {
    let args:Vec<String>=std::env::args().collect();
    if args[1]=="child" {
        match args[2].as_str() {
            "success"=>return,
            "panic"=>panic!("controlled child panic"),
            "synthetic_native_status"=>exit(0xc0000005u32 as i32),
            _=>panic!("unknown control")
        }
    }
    let output=Command::new(std::env::current_exe().unwrap())
        .args(["child",&args[2]]).output().unwrap();
    println!("actual_child_status={}",output.status);
    if args[1]=="original" { ORIGINAL } else { PROPOSED }
}
'''.replace('ORIGINAL',old).replace('PROPOSED',new)
(OUT/'control.rs').write_text(program,encoding='utf-8')
env=os.environ.copy()
env['TEMP']=env['TMP']=str(ROOT/'target/ci-policy-validation-tmp')
compile=subprocess.run(['rustc','--edition=2024',str(OUT/'control.rs'),'-o',str(OUT/'control.exe')],
    env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(OUT/'compile.stdout.log').write_bytes(compile.stdout);(OUT/'compile.stderr.log').write_bytes(compile.stderr)
assert compile.returncode==0,compile.stderr.decode('utf-8',errors='replace')
rows=[]
for version in ['original','proposed']:
    for mode in ['success','panic','synthetic_native_status']:
        result=subprocess.run([str(OUT/'control.exe'),version,mode],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (OUT/f'{version}-{mode}.stdout.log').write_bytes(result.stdout)
        (OUT/f'{version}-{mode}.stderr.log').write_bytes(result.stderr)
        actual=result.stdout.decode('utf-8').strip().removeprefix('actual_child_status=')
        error=result.stderr.decode('utf-8',errors='replace')
        expected_failure=mode!='success'
        assert (result.returncode!=0)==expected_failure
        if expected_failure:
            assert ('child status='+actual in error)==(version=='proposed')
        rows.append(dict(version=version,mode=mode,exitCode=result.returncode,actualChildStatus=actual,
            originalSuccessPredicatePreserved=True,actualStatusRetainedInFailure=(version=='proposed' and expected_failure)))
assert (WORK/NAME).read_bytes()==original,'frozen product source changed'
report=dict(status='accepted_message_only_proposal_not_native_crash_fix',sourceHead=BASE,sourceSha256=SOURCE_SHA,
    completedUtc=datetime.now(timezone.utc).isoformat(),controls=rows,
    proposedNormalizedSourceSha256=hashlib.sha256(proposed.encode('utf-8')).hexdigest(),
    limits='Product patch is not applied. All original assertion predicates and pass/fail outcomes are unchanged. Synthetic native status comes from process::exit, not a CPU exception. No Cargo/GPU work, full regression or native failure fix is qualified.')
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(report))
