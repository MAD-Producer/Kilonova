# Actual failed child assertion message control

Original product source is frozen at 652fbe65 and unchanged. The proposal only
adds output.status to its existing failure message; the success predicate and
all Boolean outcomes are identical. Six actual subprocess controls cover normal
success, a child Rust panic and process::exit(0xc0000005). The last case is a
synthetic status, not a CPU exception or reproduction of the original crash.

The proposal passed git apply --check after correcting Windows CRLF generation
in the patch artifact. No product edit, Cargo/GPU validation, native crash fix
or final regression acceptance is claimed by these controls.
