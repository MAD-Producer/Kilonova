use std::process::{Command,exit};
fn main() {
    let args:Vec<String>=std::env::args().collect();
    if args[1]=="child" {
        match args[2].as_str() {
            "success"=>return,
            "panic"=>panic!("controlled child panic"),
            "synthetic_native_status"=>exit(0xc0000005u32 as i32),
            _=>panic!("unknown control")
        }
    }
    let output=Command::new(std::env::current_exe().unwrap())
        .args(["child",&args[2]]).output().unwrap();
    println!("actual_child_status={}",output.status);
    if args[1]=="original" { assert!(
        output.status.success(),
        "{}\n{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    ); } else { assert!(
        output.status.success(),
        "child status={}\n{}\n{}",
        output.status,
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    ); }
}
