from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json,time
root=Path('E:/Dev/aem');work=root/'.worktrees/rational-frame-rates85';out=root/'artifacts/pr-queue/clock85-budget-native-build-v1';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
assert git('rev-parse','HEAD').startswith('cc301c04') and not git('status','--porcelain')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={n:sha(work/n) for n in git('ls-files','crates','desktop','Cargo.toml','Cargo.lock').splitlines() if (work/n).is_file() and n.endswith(('.rs','.wgsl','Cargo.toml','Cargo.lock'))}
command=['cargo','build','-p','motion-desktop','--features','ffmpeg','--locked','--offline']
r=dict(status='running',head=git('rev-parse','HEAD'),source=source,command=command,startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Normal dev application build, no codegen override or source/assertion changes','Does not prove default test-program compiler AV or CI timeout fixed'])
save=lambda:(out/'exit.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
try:
 with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
  p=subprocess.Popen(command,cwd=work,stdout=stdout,stderr=stderr);r['cargoPid']=p.pid;save();r['exitCode']=p.wait()
 r['sourceUnchanged']=all(sha(work/n)==h for n,h in source.items());save()
 assert r['exitCode']==0 and r['sourceUnchanged']
 binary=root/'target/rational-rate85-contract/debug/motion-studio.exe';r['binarySha256']=sha(binary)
 r['status']='native_dev_binary_built_default_profile'
except BaseException as cause:r.update(status='failed_original_outputs_retained',failure=repr(cause));raise
finally:r.update(elapsedSeconds=round(time.monotonic()-began,3),completedUtc=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({k:v for k,v in r.items() if k!='source'}),flush=True)
