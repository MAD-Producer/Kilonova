from pathlib import Path
import json,hashlib,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/rational-frame-rates85'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
entries={}
for folder in ['clock85-budget-native-build-v1','clock85-budget-wire-v1','clock85-budget-wire-v2']:
 out=root/'artifacts/pr-queue'/folder
 for p in out.rglob('*'):
  if p.is_file() and p.suffix in ['.py','.json','.jsonl','.log','.ps1'] and 'project' not in p.relative_to(out).parts:entries[folder+'/'+p.relative_to(out).as_posix()]=p
b=json.loads((root/'artifacts/pr-queue/clock85-budget-native-build-v1/exit.json').read_text(encoding='utf-8'))
r=json.loads((root/'artifacts/pr-queue/clock85-budget-wire-v2/exit.json').read_text(encoding='utf-8'))
assert b['exitCode']==0 and b['sourceUnchanged'] and r['status']=='native_default_info_file_error_stderr_pure_jsonrpc_atomic_refusal_recovery_passed'
assert all(sha(work/n)==h for n,h in b['source'].items())
for name in ['run-clock85-budget-native-build-v1.ps1','validate-clock85-budget-wire-v2.py','publish-clock85-budget-wire-v2.py']:
 entries['environment/'+name]=root/'.tools/issue-closure-review'/name
manifest=dict(head=b['head'],binarySha256=b['binarySha256'],source=b['source'],replyCount=r['replyCount'],actualFailure=r['failureText'],limits=['Actual default Info file/Error stderr and JSONRPC isolation through native worker, refusal atomicity, valid recovery and undo','First wire attempt stopped on an empty fixture layer list before any edit. Corrected observer fixture uses native legacy camera object0; no product/assertion changes','Normal dev binary build, no codegen override; this does not prove original default TEST compiler AV or CI timeout fixed','Full31target desktop/UI gate is frozen2a5 before this observation increment. This workflow is sourcecc301 based on mainb413, before later586merge'],entries={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in entries.items()})
archive=work/'engineering/validation/data/expression-budget-native-v2.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
 for n,p in entries.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,p in entries.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(p)
receipt={k:v for k,v in manifest.items() if k not in ['entries','source']};receipt.update(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members=len(entries)+1)
archive.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
(work/'engineering/validation/expression-budget-native-current.md').write_text('''# Expression interruption through the actual native worker

Status: default-channel workflow passed on `cc301c04`, based on main `b4133761`.
Normal dev FFmpeg application build passed without a code-generation override.
Its binary SHA-256 is recorded in the [receipt](data/expression-budget-native-v2.json).

A real stdio MCP process submitted an infinite position expression on the native
legacy camera, object 0. The response retained the target and frame plus
`phase=execution cause=execution_deadline elapsed_us=21201
frame_remaining_at_entry_us=99890`. This is a controlled real timeout, not a
diagnosis of the earlier CI failure. Original 20ms/100ms budgets remain unchanged.

With MOTION_LOG unset, actual file logs contained Info start and Error details;
stderr carried the same Error context. All six stdout replies parsed as JSON-RPC.
No expression source appeared in either error sink. The refused edit retained
the complete project and revision; a subsequent valid expression committed one
revision and undo restored the initial project exactly. The process closed zero.

The first observer attempt found no unlocked layer in its empty fixture and
stopped before editing. The corrected controller uses the existing camera; the
original failed receipt remains retained. No product source, test assertion,
budget, ignore marker or return value was modified for this workflow.

The [archive](data/expression-budget-native-v2.zip) retains controllers, failed
attempt, normal build output, source hashes, raw JSON-RPC and both actual sinks.
Every member was read back and hash-verified. The full desktop/UI run predates
this increment; later main integration and complete issue acceptance remain
separate gates. No Android, physical scanout, original compiler/native-crash fix,
or full 3D-route completion is claimed.
''',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['limits']}))
