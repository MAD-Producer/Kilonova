from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,os,queue,shutil,subprocess,threading,time
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/rational-frame-rates85'
OUT=ROOT/'artifacts/pr-queue/clock85-budget-wire-v1';OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
b=json.loads((ROOT/'artifacts/pr-queue/clock85-budget-native-build-v1/exit.json').read_text(encoding='utf-8'))
assert b['status']=='native_dev_binary_built_default_profile'
binary=ROOT/'target/rational-rate85-contract/debug/motion-studio.exe'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(binary)==b['binarySha256'] and all(sha(WORK/n)==h for n,h in b['source'].items())
fixture=json.loads((ROOT/'artifacts/pr-queue/clock85-tracking-tools-v2/rpc-fixture.json').read_text(encoding='utf-8'))
project=OUT/'project';shutil.copytree(fixture['project'],project)
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(LOCALAPPDATA=str(OUT/'appdata'),TEMP=str(ROOT/'target/ci-policy-validation-tmp'),TMP=str(ROOT/'target/ci-policy-validation-tmp'))
env['PATH']=str(ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')+os.pathsep+env['PATH']
report=dict(status='running',head=b['head'],binarySha256=b['binarySha256'],source=b['source'],startedUtc=datetime.now(timezone.utc).isoformat())
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
# Reuse the previously exercised stdio client without executing its old workflow.
client_source=(ROOT/'.tools/issue-closure-review/validate-clock85-tracking-tools-wire-v1.py').read_text(encoding='utf-8')
(OUT/'original-client-controller.py').write_text(client_source,encoding='utf-8')
node=next(n for n in ast.parse(client_source).body if isinstance(n,ast.ClassDef) and n.name=='Client')
exec(compile(ast.Module(body=[node],type_ignores=[]),'<preserved-stdio-client>','exec'))
save();client=None
try:
 client=Client('budget');before=client.tool('motion_state',{})
 layer=next(l for l in before['project']['layers'] if not l['locked'] and l['content']['kind']!='camera')
 target=dict(kind='property',object=layer['id'],property='position',axis=None)
 expression=dict(target=target,source='while (true) {}\nvalue',enabled=True,seed=1,profile='motion-studio-ae-js-1')
 bad=dict(op='set_expression',expression=expression,frame=0)
 failure=client.tool('command_run',dict(command=bad,expectedRevision=before['revision']),error='budget exceeded')
 text=failure['content'][0]['text']
 for fragment in ['phase=','cause=','elapsed_us=','frame_remaining_at_entry_us=']:assert fragment in text,text
 after=client.tool('motion_state',{});assert after['project']==before['project'] and after['revision']==before['revision']
 expression=dict(expression,source='value');good=dict(op='set_expression',expression=expression,frame=0)
 recovered=client.tool('command_run',dict(command=good,expectedRevision=before['revision']))
 assert recovered['revision']==before['revision']+1
 undo=client.tool('motion_history',dict(operation='undo'));assert undo['project']==before['project']
 report['replyCount']=client.close();client=None
 logs=(OUT/'appdata/MotionStudio/logs/motion-studio.log').read_text(encoding='utf-8')
 stderr=(OUT/'budget.stderr.log').read_text(encoding='utf-8')
 assert 'start #' in logs and any(' INFO ' in line and 'start #' in line for line in logs.splitlines())
 for fragment in ['budget exceeded','phase=','cause=','elapsed_us=']:
  assert any(' ERROR ' in line and fragment in line for line in logs.splitlines()),fragment
  assert fragment in stderr,fragment
 assert 'while (true)' not in logs and 'while (true)' not in stderr
 assert all(sha(WORK/n)==h for n,h in b['source'].items())
 report.update(status='native_default_info_file_error_stderr_pure_jsonrpc_atomic_refusal_recovery_passed',failureText=text)
except BaseException as cause:report.update(status='failed_original_outputs_retained',failure=repr(cause));raise
finally:
 if client is not None:
  try:client.close()
  except BaseException as cause:report['closureFailure']=repr(cause)
 report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({k:v for k,v in report.items() if k!='source'}),flush=True)
