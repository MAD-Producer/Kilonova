from pathlib import Path
import hashlib,json,re,subprocess,zipfile

root=Path('E:/Dev/aem');work=root/'.worktrees/rational-frame-rates85';parent=root/'.worktrees/tracking-import88'
out=root/'artifacts/pr-queue/clock85-3d-current-main-v4';audio=root/'artifacts/pr-queue/clock85-3d-current-main-v3';previous=root/'artifacts/pr-queue/clock85-3d-current-main-v2';loader=root/'artifacts/pr-queue/clock85-native-loader-diagnostic-v1';failed=root/'artifacts/pr-queue/clock85-3d-current-main-v1'
report=json.loads((out/'exit.json').read_text())
assert report['status']=='combined_clock_parameters_and_current_main_tracking_controls_passed'
assert report['head']=='6135221460639e18450e91d395e5459648049391' and report['sourceUnchanged']
sha=lambda b:hashlib.sha256(b).hexdigest()
assert all(sha((work/n).read_bytes())==h for n,h in report['sources'].items())
assert sum(int(s[1]) for p in report['priorSuccessfulSteps']+report['steps'] for s in p['summaries'])+report['audioPassed']==17
original=json.loads((failed/'exit.json').read_text());assert original['status']=='failed_original_outputs_retained'
assert len(original['steps'])==1 and original['steps'][0]['exitCode']==101
err=(failed/'check.stderr.log').read_text(encoding='utf-8',errors='replace')
assert err.count('error[E0277]')==2
files={}
for run in [failed,previous,loader,audio,out]:
    for p in sorted(run.rglob('*')):
        if p.is_file() and 'appdata' not in p.relative_to(run).parts:
            files[str(p.relative_to(root/'artifacts/pr-queue')).replace('\\','/')]=p.read_bytes()
for name in ['desktop/app/src/engine/tracking_video_replacement/mapped_time.rs','desktop/app/src/engine/tracking_video_replacement_tests.rs']:
    before=subprocess.check_output(['git','show',original['head']+':'+name],cwd=work)
    after=(work/name).read_bytes()
    canonical=lambda b:re.sub(r'out_frame: .*?(?=\n        offset_frame: 0,)','out_frame: <clock conversion>',b.decode().replace('\r\n','\n'),flags=re.S)
    assert canonical(before)==canonical(after)
    files['source-before/'+name]=before;files['source-after/'+name]=after
files['publisher.py']=Path(__file__).read_bytes()
files['run-wrapper.ps1']=(root/'.tools/issue-closure-review/run-clock85-3d-current-main-v4.ps1').read_bytes()
data=parent/'engineering/validation/data';archive=data/'frame-rate85-tracking-integration-v4.zip'
manifest={n:dict(bytes=len(b),sha256=sha(b)) for n,b in files.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in files.items():z.writestr(n,b)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    for n,m in manifest.items():
        b=z.read(n);assert len(b)==m['bytes'] and sha(b)==m['sha256']
proof=dict(status=report['status'],head=report['head'],main=report['main'],sourceUnchanged=True,priorSuccessfulSteps=report['priorSuccessfulSteps'],steps=report['steps'],loaderProof=report['loaderProof'],audioPassed=report['audioPassed'],audioGate=report['audioGate'],elapsedSeconds=report['elapsedSeconds'],archive=archive.name,archiveBytes=archive.stat().st_size,archiveSha256=sha(archive.read_bytes()),members=len(files),originalFailure=dict(head=original['head'],status=original['status'],exitCode=101,compileErrors=2,testsExecuted=0),scope='17 distinct scoped tests; complete core tracking_replacement target, filtered host and native targets; not a full desktop/workspace run',limits=['No assertion, threshold, ignore or timeout changes; all source outside two frame-boundary initializers byte-equivalent','PR CI omits FFmpeg; historical green heads cannot establish this feature combination or new-head checks','First native invocation failed in Windows loader before tests (0xc0000135); app-local DLL assembly fixed listing without changing test executable','Combined native invocation passed audio but second test failed at global logger initialization; remaining three run separately without changing code or assertions; neither thirteen prior successes nor passed audio repeated','Earlier native product stack/heap failures, full issue acceptance and Android are not resolved by this run'])
(data/'frame-rate85-tracking-integration-v4.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False))
