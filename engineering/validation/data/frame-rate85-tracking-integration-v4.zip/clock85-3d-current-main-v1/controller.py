from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,time
root=Path('E:/Dev/aem');work=root/'.worktrees/rational-frame-rates85';out=root/'artifacts/pr-queue/clock85-3d-current-main-v1';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
assert git('rev-parse','HEAD')=='2d5dfc03ed649ad854aea96026ad206a251d91dd' and not git('status','--porcelain')
names=git('ls-files','crates','desktop','Cargo.toml','Cargo.lock').splitlines()
sha=lambda b:hashlib.sha256(b).hexdigest()
sources={n:sha((work/n).read_bytes()) for n in names if (work/n).is_file() and n.endswith(('.rs','.wgsl','Cargo.toml','Cargo.lock'))}
env=os.environ.copy();env.pop('MOTION_LOG',None);env['LOCALAPPDATA']=str(out/'appdata')
env['MOTION_TRACKING_VIDEO_CLOCK_DIR']=str(out/'mapped');env['MOTION_TRACKED_PAIR_NATIVE_DIR']=str(out/'paired')
common=['--locked','--offline'];native=['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg']+common
commands=[('check',['cargo','check','-p','motion-host','-p','motion-desktop','--features','motion-desktop/ffmpeg','--all-targets']+common),
('core',['cargo','test','-p','motion-core','--test','tracking_replacement']+common+['--','--test-threads=1']),
('host',['cargo','test','-p','motion-host','--lib']+common+['ops::media::tracked_replacement::tests::','--','--test-threads=1']),
('paired',native+['engine::tracking_video_replacement_tests::paired::','--','--test-threads=1','--nocapture']),
('original',native+['engine::tracking_video_replacement_tests::tracked_video_replacement_refuses_changed_plate_and_preserves_identical_source','--','--exact','--test-threads=1','--nocapture']),
('mapped',native+['engine::tracking_video_replacement_tests::mapped_time::mapped_original_video_keeps_native_picture_and_authored_clock_across_replacement','--','--exact','--test-threads=1','--nocapture'])]
report=dict(status='running',head=git('rev-parse','HEAD'),main=git('rev-parse','origin/main'),sources=sources,steps=[],startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Newly combined rational clocks, parameter API and merged3D transactions; scoped integration, not full desktop rerun','Default GPU, one own GPU workload, no retries or changed assertions/ignores/budgets; no Android'])
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
try:
 for phase,command in commands:
    item=dict(phase=phase,command=command);report['steps'].append(item);save()
    with (out/f'{phase}.stdout.log').open('wb') as stdout,(out/f'{phase}.stderr.log').open('wb') as stderr:
        p=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);item['pid']=p.pid;save();item['exitCode']=p.wait()
    item['summaries']=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',(out/f'{phase}.stdout.log').read_text(encoding='utf-8',errors='replace'));save()
    assert item['exitCode']==0,(phase,item)
    if phase!='check':
        assert item['summaries'] and all(s[0]=='ok' and s[2]=='0' and s[3]=='0' for s in item['summaries'])
        assert sum(int(s[1]) for s in item['summaries'])==dict(core=8,host=5,paired=2,original=1,mapped=1)[phase],item
    print(json.dumps(item),flush=True)
 assert all(sha((work/n).read_bytes())==h for n,h in sources.items())
 report.update(status='combined_clock_parameters_and_current_main_tracking_controls_passed',sourceUnchanged=True)
except BaseException as cause:report.update(status='failed_original_outputs_retained',failure=repr(cause));raise
finally:
 report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3));save()
