import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT/'.worktrees/prerender-input-priority'
OUT = ROOT/'artifacts/pr-queue/prerender-input-poll-parking-v2'
PROPOSAL = ROOT/'artifacts/pr-queue/prerender-input-poll-parking-proposal-v4'
GROUP = ROOT/'artifacts/pr-queue/prerender-multiview-admission-proposal-v2/proposed'
BASE = '2b6e48600e33f58d3a40abf7cf536bec92d87f27'
PARENT_PID = 31784
NAME = 'engine::prerender::polling_tests::acknowledged_idle_owner_parks_until_the_input_present_arrives'
NATIVE = 'engine::prerender::tests::input_poll_parking::native_input_parks_optional_timer_after_acknowledgment_and_present_rearms_it'
production = 'desktop/app/src/engine/prerender.rs'
module = 'desktop/app/src/engine/prerender/tests.rs'
cpu = 'desktop/app/src/engine/prerender/polling_tests.rs'
native = 'desktop/app/src/engine/prerender/tests/input_poll_parking.rs'

def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git',*args],cwd=WORK).decode().strip()
def sources():
    names=git('ls-files','--cached','--others','--exclude-standard','-z').split('\0')
    return {n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in names
        if n and n.endswith(('.rs','.toml','.lock','.wgsl','.json','.yml','.yaml','.py','.md'))}

previous_queue=json.loads((OUT/'exit.json').read_text(encoding='utf-8'))
assert previous_queue['status']=='interrupted_system_shutdown_before_execution' and not previous_queue['steps']
(OUT/'controller-before-system-shutdown.py').write_bytes((OUT/'controller.py').read_bytes())
OUT.mkdir(exist_ok=True)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='queued',controllerPid=os.getpid(),base=BASE,startedUtc=now(),steps=[],
    limits='One serialized build owner. Original v9 strict P95 failures remain binding. New actual timer parking controls and original native input/foreground recovery; no weakened assertions, Android, panels, timeouts, restarts or retries.')
def save():
    p=OUT/'exit.next.json'
    p.write_text(json.dumps(report,indent=2),encoding='utf-8');os.replace(p,OUT/'exit.json')

env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'owned-profile'),PYTHONPATH=str(ROOT/'.tools/build-validation-python'))
Path(env['LOCALAPPDATA']).mkdir(exist_ok=True)
env['MOTION_PRERENDER_PARKING_REPORT']=str(OUT/'native-timer-report.json')

def step(name,args,expected=None,negative=None):
    report['activeStep']=dict(name=name,command=args,startedUtc=now());save()
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        report['activeStep']['pid']=child.pid;save();code=child.wait()
    output='\n'.join((OUT/f'{name}.{suffix}.log').read_text(encoding='utf-8',errors='replace') for suffix in ['stdout','stderr'])
    counts=re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',output)
    passed=(code!=0 and counts==[('0','1','0')] and negative in output) if negative else (
        code==0 and (expected is None or counts==[(str(expected),'0','0')]))
    row=dict(name=name,exitCode=code,counts=counts,passed=passed,negativeControl=bool(negative),
        startedUtc=report['activeStep']['startedUtc'],completedUtc=now())
    report['steps'].append(row);report.pop('activeStep',None);save();print(json.dumps(row),flush=True)
    assert passed,f'{name} failed; inspect before any later build'

baseline={}
mutated=False
save()
try:
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
    kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.WaitForSingleObject.restype=wintypes.DWORD
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    handle=kernel.OpenProcess(0x100000,False,PARENT_PID)
    assert handle and kernel.WaitForSingleObject(handle,0)==258,'preceding native validator must be live'
    report['parent']=dict(pid=PARENT_PID,handleCapturedLive=True,receipt='prerender-multiview-admission-v1');save()
    print(json.dumps(dict(queuedBehind=PARENT_PID)),flush=True)
    try:
        while True:
            state=kernel.WaitForSingleObject(handle,1000)
            if state==0:break
            assert state==258
    finally:kernel.CloseHandle(handle)
    parent=json.loads((ROOT/'artifacts/pr-queue/prerender-multiview-admission-v1/exit.json').read_text(encoding='utf-8'))
    assert parent.get('completedUtc') and parent['status']=='accepted_native_multiview_profile_boundary_not_final_integration', 'inspect actual parent failure before building'
    assert git('rev-parse','HEAD')==BASE and sources()==parent['candidateSource']
    report['parent']['terminal']=dict(status=parent['status'],completedUtc=parent['completedUtc'])
    report['baselineSource']=sources()
    for n in [production,module]:
        baseline[n]=(WORK/n).read_bytes()
        assert (WORK/n).read_text(encoding='utf-8')==(GROUP/n).read_text(encoding='utf-8')
    for n in [cpu,native]:assert not (WORK/n).exists()
    report.update(status='running_first_execution_of_distinct_timer_controls',releasedUtc=now());save()
    # Apply only the new fixtures first; original production behavior must fail.
    original=(WORK/production).read_text(encoding='utf-8')
    fixture=original.replace('mod input;\n','mod input;\n#[cfg(test)]\nmod polling_tests;\n',1)
    assert fixture!=original
    (WORK/production).write_text(fixture,encoding='utf-8',newline='\n');mutated=True
    for n in [cpu,native,module]:
        target=WORK/n;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes((PROPOSAL/'proposed'/n).read_bytes())
    desktop=['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--bin','motion-studio']
    step('original-cpu-parking-negative',desktop+[NAME,'--','--exact','--nocapture','--test-threads=1'],
        negative='pending input with no outstanding lease must park optional timer polling')
    step('original-native-timer-negative',desktop+[NATIVE,'--','--ignored','--exact','--nocapture','--test-threads=1'],
        negative='acknowledged native input must park synthetic prerender timer commands')
    (WORK/production).write_bytes((PROPOSAL/'proposed'/production).read_bytes())
    report['candidateSource']=sources();save()
    step('cpu-parking-positive',desktop+['engine::prerender::polling_tests::','--','--test-threads=1'],expected=4)
    step('native-timer-positive',desktop+[NATIVE,'--','--ignored','--exact','--test-threads=1'],expected=1)
    for label,name in [
        ('native-input-routing','input_priority::native_input_preempts_before_action_generation_and_waits_for_its_present'),
        ('native-completed-input','input_completion::native_completed_result_waits_for_input_acknowledgment_before_upload'),
        ('native-late-input','input_completion::native_late_input_rejects_completed_result_after_demand_reconciliation'),
        ('native-playback-wake','playback::native_playback_ignores_idle_delay_and_presents_a_warm_exact_frame'),
        ('native-grouped-profile','multiview_admission::native_multiview_retires_single_view_warmup_and_recovers_after_single_present')]:
        step(label,desktop+['engine::prerender::tests::'+name,'--','--ignored','--exact','--test-threads=1'],expected=1)
    step('provenance',[sys.executable,'tools/validate_provenance.py'])
    step('tool-inventory',[sys.executable,'tools/validation_inventory.py'])
    step('whitespace',['git','diff','--check'])
    assert sources()==report['candidateSource']
    report.update(status='accepted_timer_parking_component_not_performance_acceptance',completedUtc=now());save()
except BaseException as error:
    if mutated:
        for n,b in baseline.items():(WORK/n).write_bytes(b)
        report['restoredTrackedProductionAndModuleAfterFailure']=all((WORK/n).read_bytes()==b for n,b in baseline.items())
        report['newFixturesRetainedUnreferenced']=True
    report.update(status='failed',failure=repr(error),completedUtc=now());save();raise
