"""Archive exact-head, actual passing names for all three maintained CI jobs."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-transition75'
HEAD = 'a86e8ffae58b175b313cd11c12e6412c7a39f7c0'
RUN = 42328873218
OUT = BASE / 'depth75-worker-binding-ci-public-v1'
sha = lambda data: hashlib.sha256(data).hexdigest()
api = lambda path: json.loads(subprocess.check_output(['gh', 'api', 'repos/MAD-Producer/Kilonova' + path], encoding='utf-8'))
workflow = api(f'/actions/runs/{RUN}')
jobs = api(f'/actions/runs/{RUN}/jobs?per_page=100')
assert workflow['head_sha'] == HEAD and workflow['status'] == 'completed' and workflow['conclusion'] == 'success'
assert all(row['status'] == 'completed' and row['conclusion'] in ('success', 'skipped') for row in jobs['jobs'])
members = {'workflow.json': json.dumps(workflow, indent=2).encode(),
           'jobs.json': json.dumps(jobs, indent=2).encode(),
           'archive-controller.py': Path(__file__).read_bytes()}
collectors = []
for platform in ('linux', 'macos', 'windows'):
    path = BASE / f'depth75-worker-binding-ci-{platform}-v1'
    report = json.loads((path / 'receipt.json').read_text(encoding='utf-8'))
    assert report['sourceCommit'] == HEAD and report['run'] == RUN
    assert report['status'] == 'selected_named_tests_verified_in_completed_exact_head_jobs'
    assert len(report['verifiedTests']) == 30
    for name, row in report['jobs'].items():
        data = (path / (name + '.log')).read_bytes()
        assert sha(data) == row['sha256'] and len(data) == row['bytes']
    for file in path.iterdir():
        if file.is_file():
            members[f'{platform}/{file.name}'] = file.read_bytes()
    collectors.append(dict(platform=platform, namedPasses=30, jobs=report['jobs']))
for path in ('crates/motion-host/src/depth.rs', 'crates/motion-host/src/depth/alignment.rs',
             'crates/motion-host/src/depth/transition.rs', 'crates/motion-host/tests/depth_alignment.rs',
             'crates/motion-host/tests/depth_transition.rs', 'crates/motion-host/tests/depth_transition_jobs.rs',
             'crates/motion-host/Cargo.toml', 'Cargo.lock'):
    members['source/' + path] = subprocess.check_output(['git', 'show', HEAD + ':' + path], cwd=WORK)
manifest = dict(status='all90_named_alignment_admission_worker_passes_and_exact_head_workflow_verified',
                sourceCommit=HEAD, run=RUN, observedUtc=datetime.now(timezone.utc).isoformat(), collectors=collectors,
                limits=['14 alignment +9 admission +7 actual Jobs controls in each maintained desktop test job',
                        'Exact later worker-binding source; earlier369 CI is retained separately',
                        'CI is not the integrated local full-feature command or real-model video/thermal qualification'],
                members={name: dict(bytes=len(data), sha256=sha(data)) for name, data in members.items()})
OUT.mkdir(exist_ok=False)
archive = OUT / 'depth75-worker-binding-ci-three-platforms-v1.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
    for name, data in members.items():
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == {'manifest.json', *members}
    assert json.loads(z.read('manifest.json')) == manifest
    for name, row in manifest['members'].items():
        data = z.read(name)
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
manifest['archive'] = dict(file=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
                           verifiedMembers=len(members) + 1)
(OUT / 'depth75-worker-binding-ci-three-platforms-v1.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: manifest[k] for k in ('status', 'sourceCommit', 'archive')}))
