import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT/'.worktrees/prerender-input-priority'
OUT = ROOT/'artifacts/pr-queue/prerender-multiview-admission-v3'
BASE = '2b6e48600e33f58d3a40abf7cf536bec92d87f27'
PRODUCTION = WORK/'desktop/app/src/engine/prerender.rs'
NAME = 'engine::prerender::tests::multiview_admission::native_multiview_retires_single_view_warmup_and_recovers_after_single_present'

def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()
def sources():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: hashlib.sha256((WORK/name).read_bytes()).hexdigest() for name in names
            if name and name.endswith(('.rs','.toml','.lock','.wgsl','.json','.yml','.yaml','.py','.md'))}

assert git('rev-parse','HEAD') == BASE
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
original = PRODUCTION.read_bytes()
source = sources()
report = dict(status='queued', controllerPid=os.getpid(), base=BASE, source=source, steps=[], startedUtc=now(),
    limits='Actual native grouped-view transition, background hold and single-view pixel recovery. Original current-main strict performance/full/MCP results remain independently binding. No UI, Android, existing assertion, threshold, timeout, retry or stack-policy changes.')

def save():
    pending = OUT/'exit.next.json'
    pending.write_text(json.dumps(report,indent=2),encoding='utf-8')
    os.replace(pending,OUT/'exit.json')

env = os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT/'owned-profile'), PYTHONPATH=str(ROOT/'.tools/build-validation-python'))
Path(env['LOCALAPPDATA']).mkdir(exist_ok=True)

def step(name,args,expected=None,negative=False):
    test_env=env.copy()
    test_env['MOTION_PRERENDER_INPUT_COMPLETION_REPORT']=str(OUT/f'{name}.report.json')
    report['activeStep']=dict(name=name,command=args,startedUtc=now());save()
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(args,cwd=WORK,env=test_env,stdout=stdout,stderr=stderr)
        report['activeStep']['pid']=child.pid;save();code=child.wait()
    report['activeStep'].update(exitCode=code,completedUtc=now());save()
    output=(OUT/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace')
    errors=(OUT/f'{name}.stderr.log').read_text(encoding='utf-8',errors='replace')
    counts=re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',output)
    if negative:
        passed=code!=0 and counts==[('0','1','0')] and 'independent views must suspend authored single-view warming' in output+errors
    else:
        passed=code==0 and (expected is None or counts==[(str(expected),'0','0')])
        if counts:passed=passed and all(int(c[1])==0 for c in counts) and any(int(c[0])>0 for c in counts)
    row=dict(name=name,command=args,exitCode=code,counts=counts,passed=passed,negativeControl=negative,
        startedUtc=report['activeStep']['startedUtc'],completedUtc=report['activeStep']['completedUtc'])
    report['steps'].append(row);save();print(json.dumps(row),flush=True)
    assert passed,f'{name} failed; inspect actual exit and logs before any later build'
    report.pop('activeStep',None);save()

PROPOSAL=ROOT/'artifacts/pr-queue/prerender-multiview-admission-proposal-v3'
metadata=json.loads((PROPOSAL/'proposal.json').read_text(encoding='utf-8'))
production=['crates/motion-host/src/session/viewer.rs','desktop/app/src/engine/prerender.rs']
baseline={n:(WORK/n).read_bytes() for n in production}
candidate={n:(PROPOSAL/'proposed'/n).read_bytes() for n in production}
assert all(hashlib.sha256(b).hexdigest()==metadata['source'][n] for n,b in baseline.items())
for n in ['desktop/app/src/engine/prerender/tests.rs','desktop/app/src/engine/prerender/tests/multiview_admission.rs']:
    assert (WORK/n).read_bytes()==(PROPOSAL/'proposed'/n).read_bytes()
mutated=False
save()
try:
    # All preceding owned gates actually ended. The pose gate rejected a stale
    # 35-test binary rather than falsely accepting its intended44-test source.
    # A later host gate must force rebuild from the current worktree.
    for old_gate in ['tracking88-host-v1','tracking88-pose-host-v1','tracking88-plane-host-v1','tracking88-time-host-v2']:
        previous=json.loads((ROOT/'artifacts/pr-queue'/old_gate/'exit.json').read_text(encoding='utf-8'))
        assert previous.get('completedUtc'), 'preceding actual process must be terminal'
    pose_gate=json.loads((ROOT/'artifacts/pr-queue/tracking88-pose-host-v1/exit.json').read_text(encoding='utf-8'))
    assert pose_gate['failure']=="AssertionError('expected all 44 tracking tests')"
    assert all(s['exitCode']==0 for s in pose_gate['steps'])
    report['precedingHostCoverageFailure']='Actual host35 succeeded; intendedhost44 got cached35 binary and correctly failed its count guard. No host44/47/56 qualification. Rebuild source explicitly before later host acceptance.'
    full=json.loads((ROOT/'artifacts/pr-queue/prerender-combined-v9/exit.json').read_text(encoding='utf-8'))
    assert full.get('completedUtc') and full['head']==BASE
    assert all(s['name']=='input-assessment' for s in full['steps'] if not s['passed'])
    assert all(any(s['name']==n and s['passed'] for s in full['steps']) for n in ['workspace-regression','desktop-check','desktop-build','shared-mcp'])
    report['retainedPriorNativeFailure']='prerender-multiview-admission-v1'
    report['fixtureCorrection']=metadata['fixtureCorrection']
    report['originalAssertionsPreserved']=metadata['originalAssertionsPreserved'];save()
    assert sources()==source and git('rev-parse','HEAD')==BASE
    report.update(status='running_first_native_multiview_controls_not_performance_acceptance',releasedUtc=now());save()
    for name in ['crates/motion-model/src/lib.rs','crates/motion-core/src/lib.rs','crates/motion-render/src/lib.rs','crates/motion-host/src/lib.rs','crates/motion-desktop-media/src/lib.rs','desktop/app/src/main.rs']:os.utime(WORK/name,None)
    desktop=['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--bin','motion-studio']
    step('original-grouped-warming-negative',desktop+[NAME,'--','--ignored','--exact','--nocapture','--test-threads=1'],negative=True)
    for n,b in candidate.items():(WORK/n).write_bytes(b)
    mutated=True;report['candidateSource']=sources();save()
    step('native-grouped-warming-positive',desktop+[NAME,'--','--ignored','--exact','--nocapture','--test-threads=1'],expected=1)
    step('native-viewer-regression',desktop+['engine::viewer_frame::native::normal_present_and_capture_route_cameras_freeze_canvas_and_window_identity','--','--include-ignored','--exact','--test-threads=1'],expected=1)
    step('native-late-input-regression',desktop+['engine::prerender::tests::input_completion::native_late_input_rejects_completed_result_after_demand_reconciliation','--','--ignored','--exact','--test-threads=1'],expected=1)
    step('host-grouped-views',['cargo','test','-p','motion-host','--features','ai-depth','--locked','--offline','--lib','session::viewer::tests::','--','--include-ignored','--test-threads=1'])
    step('provenance',[sys.executable,'tools/validate_provenance.py'])
    step('tool-inventory',[sys.executable,'tools/validation_inventory.py'])
    step('whitespace',['git','diff','--check'])
    assert sources()==report['candidateSource']
    report.update(status='accepted_native_multiview_profile_boundary_not_final_integration',completedUtc=now());save()
except BaseException as error:
    if mutated:
        for n,b in baseline.items():(WORK/n).write_bytes(b)
        report['restoredProductionAfterFailure']=all((WORK/n).read_bytes()==b for n,b in baseline.items())
    report.update(status='failed',failure=repr(error),completedUtc=now());save();raise
