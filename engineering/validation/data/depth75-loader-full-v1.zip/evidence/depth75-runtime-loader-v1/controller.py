"""Deferred loader-only diagnosis; never replaces the retained failed full run."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
FULL = ROOT/'artifacts/pr-queue/depth75-backend-workspace-v3'
OUT = ROOT/'artifacts/pr-queue/depth75-runtime-loader-v1'
BIN = ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


if len(sys.argv) == 3 and sys.argv[1] == '--load-library':
    # Each probe starts in a new process, so earlier imports cannot mask a
    # transitive dependency by preloading another version. winmode=0 selects
    # legacy LoadLibrary rules rather than Python's default restricted flags.
    ctypes.windll.kernel32.SetErrorMode(0x8003)
    path = Path(sys.argv[2])
    try:
        library = ctypes.WinDLL(str(path), winmode=0, use_last_error=True)
        print(json.dumps(dict(file=str(path), loaded=True, handleNonzero=bool(library._handle))))
    except OSError as error:
        print(json.dumps(dict(file=str(path), loaded=False, winerror=error.winerror, cause=str(error))))
        raise SystemExit(1)
    raise SystemExit(0)

receipt = json.loads((FULL/'receipt.json').read_text(encoding='utf-8'))
consumed = json.loads((FULL/'session-consumed.json').read_text(encoding='utf-8'))
assert receipt.get('completedUtc') and receipt['sourceUnchanged'] and consumed['exitCode'] is not None
assert receipt['baseCommit'] == '0646083d672b0d362901cc0a8c8992c41d59182c'
assert str(BIN).replace('/', '\\').lower() in os.environ['PATH'].replace('/', '\\').lower()
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='running_loader_diagnosis', startedUtc=datetime.now(timezone.utc).isoformat(),
              source=receipt['baseCommit'], originalFullStatus=receipt['status'],
              fullReceiptSha256=sha(FULL/'receipt.json'), stages=[], runtimeFiles={},
              limits=['No test body is executed by --list; original full failure remains authoritative',
                      'Explicit pinned runtime and unchanged executable; no PATH mutation, DLL staging or source changes',
                      'Individual library probes are isolated fresh owned children',
                      'A successful listing is not regression acceptance or proof of the original missing DLL'])


def save():
    (OUT/'receipt.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')


def run(name, command):
    row = dict(name=name, command=list(map(str, command)))
    report['stages'].append(row); save()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout, (OUT/(name+'.stderr.log')).open('wb') as stderr:
        child = subprocess.Popen(row['command'], stdout=stdout, stderr=stderr, cwd=ROOT)
        row['pid'] = child.pid; save()
        row['exitCode'] = child.wait()
    row['logs'] = {suffix:dict(bytes=(OUT/(name+'.'+suffix+'.log')).stat().st_size,
                            sha256=sha(OUT/(name+'.'+suffix+'.log'))) for suffix in ('stdout','stderr')}
    save()


save()
for dll in sorted(BIN.glob('*.dll')):
    report['runtimeFiles'][dll.name] = dict(bytes=dll.stat().st_size, sha256=sha(dll))
save()
for name in ['motion_studio-782a930f79dba3a2.exe','video_retirement_export-107b68fe6baa3729.exe']:
    executable = ROOT/'target/colmap88-isolated-check/debug/deps'/name
    assert executable.is_file()
    report.setdefault('executables', {})[name] = dict(sha256=sha(executable), bytes=executable.stat().st_size)
    save()
    run(name.split('-')[0]+'-list', [executable, '--list'])
run('pinned-ffmpeg-version', [BIN/'ffmpeg.exe','-version'])
for dll in sorted(BIN.glob('*.dll')):
    run(dll.stem+'-load-library', [sys.executable, '-B', Path(__file__).resolve(), '--load-library', dll])
report.update(status='loader_observations_complete_not_regression_acceptance', completedUtc=datetime.now(timezone.utc).isoformat())
save()
print(json.dumps(dict(status=report['status'], stages=[dict(name=s['name'],exitCode=s['exitCode']) for s in report['stages']])))
