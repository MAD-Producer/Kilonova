"""Deferred controlled loader experiment using an unchanged owned test binary.

Only --list is executed. Adjacent DLL staging is isolated in this artifact,
never installed globally or substituted into the original failed target.
"""
from pathlib import Path
from datetime import datetime, timezone
import ctypes, hashlib, json, os, shutil, subprocess, sys

ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue'
OUT=ART/'depth75-runtime-loader-v2'
BIN=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.SetErrorMode(0x8003)

if len(sys.argv)==4 and sys.argv[1]=='--load-library':
    path=Path(sys.argv[2]);flags=int(sys.argv[3])
    kernel.LoadLibraryExW.argtypes=[ctypes.c_wchar_p,ctypes.c_void_p,ctypes.c_uint32]
    kernel.LoadLibraryExW.restype=ctypes.c_void_p
    kernel.GetModuleFileNameW.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint32]
    kernel.GetModuleFileNameW.restype=ctypes.c_uint32
    handle=kernel.LoadLibraryExW(str(path),None,flags)
    code=ctypes.get_last_error() if not handle else 0
    row=dict(file=str(path),flags=hex(flags),loaded=bool(handle),winerror=code)
    if handle:
        buffer=ctypes.create_unicode_buffer(2048)
        assert kernel.GetModuleFileNameW(handle,buffer,len(buffer))
        row['actualModule']=buffer.value
    else:row['cause']=ctypes.FormatError(code)
    print(json.dumps(row))
    raise SystemExit(0 if handle else 1)

full=ART/'depth75-backend-workspace-v3'
assert json.loads((full/'receipt.json').read_text(encoding='utf-8'))['completedUtc']
assert json.loads((full/'session-consumed.json').read_text(encoding='utf-8'))['exitCode']==1
jobs=ART/'depth75-resolution-jobs-v2'
assert json.loads((jobs/'receipt.json').read_text(encoding='utf-8'))['completedUtc']
assert json.loads((jobs/'session-consumed.json').read_text(encoding='utf-8'))['exitCode'] is not None
assert shutil.disk_usage(ROOT).free>=10<<30, 'Original admission; no loader process started'
original=json.loads((ART/'depth75-runtime-loader-v1/receipt.json').read_text(encoding='utf-8'))
name='motion_studio-782a930f79dba3a2.exe'
source=ROOT/'target/colmap88-isolated-check/debug/deps'/name
assert sha(source)==original['executables'][name]['sha256']
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
stage=OUT/'isolated-stage';stage.mkdir()
executable=stage/name;os.link(source,executable)
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),sourceExeSha256=sha(source),stages=[],
            runtimeFiles={},limits=['Only --list; no test assertions or fixtures execute',
              'Control changes only adjacent exact pinned DLL presence beside a byte-identical hardlinked owned executable',
              'Same-volume hardlinks save storage; only loader reads occur, no contents or permissions are changed',
              'Original target, source, PATH, registry, system directories and FFmpeg installation are unchanged',
              'Original failed full run remains authoritative; listing is not full regression acceptance'])

def save():
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')

def run(name,command):
    row=dict(name=name,command=list(map(str,command)));report['stages'].append(row);save()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(row['command'],cwd=ROOT,stdout=stdout,stderr=stderr)
        row['pid']=child.pid;save();row['exitCode']=child.wait()
    save();return row['exitCode']

save()
try:
    without=run('same-exe-without-adjacent-runtime',[executable,'--list'])
    for dll in sorted(BIN.glob('*.dll')):
        digest=sha(dll)
        assert digest==original['runtimeFiles'][dll.name]['sha256']
        target=stage/dll.name;os.link(dll,target);assert sha(target)==digest
        report['runtimeFiles'][dll.name]=dict(sha256=digest,bytes=target.stat().st_size)
    save()
    adjacent=run('same-exe-with-adjacent-pinned-runtime',[executable,'--list'])
    for dll_name in ['avcodec-62.dll','swresample-6.dll','avutil-60.dll']:
        for flags in [0,8]:
            run(f'{dll_name}-{flags}-direct-load',[sys.executable,'-B',Path(__file__).resolve(),'--load-library',BIN/dll_name,flags])
    report.update(unchangedSourceAndCopiedExecutable=sha(source)==sha(executable)==report['sourceExeSha256'],
                  withoutAdjacentExit=without,withAdjacentExit=adjacent)
    report['status']='isolated_adjacent_runtime_restores_listing_not_full_regression' if without==0xc0000135 and adjacent==0 and report['unchangedSourceAndCopiedExecutable'] else 'loader_cause_still_unresolved_outputs_retained'
except BaseException as error:
    report.update(status='loader_diagnostic_failed_original_outputs_retained',failure=repr(error))
finally:
    report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({k:v for k,v in report.items() if k not in ('stages','runtimeFiles')}))
raise SystemExit(0 if report['status'].startswith('isolated_adjacent_runtime_') else 1)
