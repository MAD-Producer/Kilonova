"""Preserve the failed full run and the independent loader controls, not a pass."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/reference-depth76'
ART = ROOT / 'artifacts/pr-queue'
DATA = WORK / 'engineering/validation/data'
HEAD = '0646083d672b0d362901cc0a8c8992c41d59182c'
ARCHIVE = DATA / 'depth75-loader-full-v1.zip'
MANIFEST = DATA / 'depth75-loader-full-v1.json'
digest = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == HEAD
assert not ARCHIVE.exists() and not MANIFEST.exists()
full_dir = ART / 'depth75-backend-workspace-v3'
full = read(full_dir / 'receipt.json')
assert full['baseCommit'] == HEAD and full['sourceUnchanged'] and full['completedUtc']
assert full['exitCode'] == 101 and read(full_dir / 'session-consumed.json')['exitCode'] == 1
assert full['allSourceInvocationsStarted'] and not full['fullTargetCoverageAccounted']
assert not full['missingSourceTargets'] and not full['unexpectedSourceTargets']
assert full['totals'] == dict(passed=3141, failed=0, originalIgnored=4, filtered=0,
                            summaryCount=414, observedInvocations=430, expectedInvocations=430)
assert len(full['abnormalTargetExits']) == 16
assert all('0xc0000135' in line for line in full['abnormalTargetExits'])
for name, expected in full['logs'].items():
    raw = (full_dir / name).read_bytes()
    assert len(raw) == expected['bytes'] and digest(raw) == expected['sha256']
loader = read(ART / 'depth75-runtime-loader-v2/receipt.json')
assert loader['completedUtc'] and loader['unchangedSourceAndCopiedExecutable']
assert loader['withoutAdjacentExit'] == 0xc0000135 and loader['withAdjacentExit'] == 0
assert loader['status'] == 'isolated_adjacent_runtime_restores_listing_not_full_regression'
members = {}

def add_bytes(name, raw):
    assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
    assert Path(name).suffix not in ('.exe', '.dll', '.pdb', '.onnx', '.pth', '.png', '.rgb', '.f32')
    members[name] = raw

for directory in ('depth75-backend-workspace-v3', 'depth75-runtime-loader-v1', 'depth75-runtime-loader-v2'):
    for path in sorted((ART / directory).iterdir()):
        if path.is_file() and path.suffix in ('.json', '.py', '.log'):
            add_bytes('evidence/' + directory + '/' + path.name, path.read_bytes())

# HEAD is still the exact tested commit, but three worktree files now contain a
# subsequent unqualified observation patch. Recover only bytes matching the
# original run's retained hash; never present the new patch as tested source.
source_names = ('Cargo.toml', 'Cargo.lock', 'crates/motion-host/Cargo.toml',
                'crates/motion-host/src/depth.rs', 'crates/motion-host/src/depth/wgsl.rs',
                'crates/motion-host/tests/depth_jobs.rs', 'crates/motion-host/tests/depth_video.rs',
                'desktop/app/src/logging.rs', '.github/workflows/ci.yml')
for name in source_names:
    expected = full['source'][name]
    working = (WORK / name).read_bytes()
    if digest(working) == expected:
        actual = working
    else:
        committed = subprocess.check_output(['git', 'show', HEAD + ':' + name], cwd=WORK)
        candidates = (committed, committed.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n'))
        matching = [raw for raw in candidates if digest(raw) == expected]
        assert matching, name
        actual = matching[0]
    assert digest(actual) == expected
    add_bytes('qualified-source/' + name, actual)
add_bytes('observers/archive.py', Path(__file__).read_bytes())
inventory = {name: dict(bytes=len(raw), sha256=digest(raw)) for name, raw in members.items()}
summary = dict(schema=1, createdUtc=datetime.now(timezone.utc).isoformat(), sourceCommit=HEAD,
               main=full['main'], fullRunStatus=full['status'], cargoExitCode=full['exitCode'],
               totals=full['totals'], loaderTargetFailures=len(full['abnormalTargetExits']),
               allSourceInvocationsStarted=True, fullTargetCoverageAccounted=False,
               isolatedLoaderControl=loader['status'],
               limits=['Full regression failed; zero ordinary assertions failed does not waive 16 loader failures',
                       'All 430 source invocations started; only 414 produced summaries',
                       'Byte-identical isolated executable listing succeeds with seven adjacent pinned DLLs',
                       'Listing executes no test bodies; exact missing transitive library is not identified',
                       'No original target runtime, global environment, permissions or existing assertions were changed',
                       'Later model-identity logging patch is absent from qualified source and is not tested here',
                       'No runtime binaries, model weights, images or tensors are distributed'],
               members=inventory)
add_bytes('manifest.json', (json.dumps(summary, indent=2) + '\n').encode('utf-8'))
with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, raw in members.items():
        output.writestr(name, raw)
with zipfile.ZipFile(ARCHIVE) as output:
    assert output.testzip() is None
    for name, expected in inventory.items():
        raw = output.read(name)
        assert len(raw) == expected['bytes'] and digest(raw) == expected['sha256']
summary.pop('members')
summary.update(archive=ARCHIVE.name, archiveBytes=ARCHIVE.stat().st_size,
               archiveSha256=digest(ARCHIVE.read_bytes()), memberCount=len(members))
MANIFEST.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
