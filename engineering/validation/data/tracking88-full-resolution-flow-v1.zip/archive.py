"""Independent aggregate audit of the rejected full-resolution LK experiment."""
from pathlib import Path
import hashlib,json,math,zipfile
BASE=Path('E:/Dev/aem/artifacts/pr-queue');SOURCE=BASE/'tracking88-full-resolution-flow-v1';OUT=BASE/'tracking88-full-resolution-flow-public-v1'
load=lambda p:json.loads(p.read_text());sha=lambda raw:hashlib.sha256(raw).hexdigest()
r=load(SOURCE/'receipt.json');prep=load(SOURCE/'preparation.json')
assert r['status']=='rejected_candidate_original_quality_or_coverage_failure_retained' and r['candidate_unchanged']
assert load(SOURCE/'session-consumed.json')['consumed']
assert len(r['stages'])==3 and all(s['exit_code']==0 for s in r['stages'])
assert 'Ran 8 tests' in (SOURCE/'original-controls.stderr.log').read_text()
labels=BASE/'tracking88-real-planar-acquisition-v1/phone-gt.zip'
assert sha(labels.read_bytes())=='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
with zipfile.ZipFile(labels) as z:
 corners=[]
 for i in range(2300):
  values=[float(v) for v in z.read(f'img_{i+200:05d}.txt').decode().split()]
  assert len(values)==8;corners.append([(values[4+j]-1,values[j]-1) for j in range(4)])
def project(m,p):
 x,y=p;d=m[2][0]*x+m[2][1]*y+m[2][2];assert abs(d)>1e-10
 return ((m[0][0]*x+m[0][1]*y+m[0][2])/d,(m[1][0]*x+m[1][1]*y+m[1][2])/d)
audits=[]
for row in r['runs']:
 mode=row['mode'];path=SOURCE/mode/'tracks.mstrack';assert sha(path.read_bytes())==r['blind_outputs'][mode]
 asset=load(path);assert asset['source_pts']==list(range(2300)) and asset['ticks_per_second']==100
 request=Path(r['requests'][mode]['path']);assert sha(request.read_bytes())==r['requests'][mode]['sha256']
 assert len(load(request)['corrections'])==(0 if mode=='no-corrections' else 22)
 for track in asset['tracks']:
  recorded=next(t for t in row['tracks'] if t['track']==track['id']);errors=[];lost=manual=0
  assert len(track['samples'])==2300
  for i,sample in enumerate(track['samples']):
   assert sample['source_index']==i
   if i==0:continue
   if sample['manual_correction']:manual+=1;continue
   if sample['visibility']!='visible':lost+=1;continue
   observation=sample['observation']
   e=math.dist(observation['pixels'],corners[i][0]) if track['kind']=='point' else max(math.dist(project(observation['matrix'],p),truth) for p,truth in zip(corners[0],corners[i]))
   assert math.isfinite(e);errors.append(e)
  summary=dict(mode=mode,track=track['id'],automaticVisible=len(errors),automaticLost=lost,manualSamples=manual,maxPixels=max(errors),rmsPixels=math.sqrt(sum(e*e for e in errors)/len(errors)),automaticOver15Pixels=sum(e>15 for e in errors))
  for name in ('automaticVisible','automaticLost','manualSamples','automaticOver15Pixels'):assert summary[name]==recorded[name]
  for name in ('maxPixels','rmsPixels'):assert math.isclose(summary[name],recorded[name],rel_tol=1e-10,abs_tol=1e-9)
  assert not recorded['coverage_retained'];audits.append(summary)
files={}
def put(path,name):
 raw=path.read_bytes();assert path.suffix in ('.json','.log','.py') and len(raw)<=4<<20
 assert name not in files;files[name]=raw
for name in ('receipt.json','preparation.json','session-consumed.json','controller.py','original-controls.stdout.log','original-controls.stderr.log','no-corrections.stdout.log','no-corrections.stderr.log','periodic-manual-200.stdout.log','periodic-manual-200.stderr.log'):
 put(SOURCE/name,'experiment/'+name)
for name,record in prep['files'].items():
 path=SOURCE/'candidate'/name;assert sha(path.read_bytes())==record['candidate_sha256'];put(path,'experiment/candidate/'+name)
 assert sha((Path('E:/Dev/aem/.worktrees/planar-tracker88/tools/tracking')/name).read_bytes())==record['original_sha256']
put(Path(__file__),'archive.py')
limits=prep['limits']+['Actual both-mode result rejected: coverage worsened and the same severe-plane-error category persists','Controller exit0 is measurement completion, not acceptance; original product algorithm remains unchanged','No video, annotations, full requests or per-frame observations redistributed','No native/Surface integration or CI result established by this experiment']
manifest=dict(version=1,status=r['status'],base=prep['base'],independently_recomputed=audits,limits=limits,members={name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in files.items()})
OUT.mkdir(exist_ok=False);archive=OUT/'tracking88-full-resolution-flow-v1.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in files.items():z.writestr(name,raw)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)|{'manifest.json'}
 for name,raw in files.items():assert z.read(name)==raw
 assert json.loads(z.read('manifest.json'))==manifest
result={k:v for k,v in manifest.items() if k!='members'};result.update(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members_readback_verified=len(files)+1)
(OUT/'receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))
