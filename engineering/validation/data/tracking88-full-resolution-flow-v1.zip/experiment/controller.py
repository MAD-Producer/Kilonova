"""Distinct isolated algorithm experiment; never changes a production worktree."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,traceback,zipfile
ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';OUT=BASE/'tracking88-full-resolution-flow-v1';SRC=OUT/'candidate'
assert json.loads((BASE/'depth75-sustained-sensor-v1/session-consumed.json').read_text())['consumed']
assert not (OUT/'receipt.json').exists()
prep=json.loads((OUT/'preparation.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(SRC/name)==row['candidate_sha256'] for name,row in prep['files'].items())
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='running_original_analytic_controls',preparation_sha256=sha(OUT/'preparation.json'),started_utc=datetime.now(timezone.utc).isoformat(),limits=prep['limits'],stages=[])
def save():(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def run(name,command):
 row=dict(name=name,command=command);report['stages'].append(row);save()
 with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
  child=subprocess.Popen(command,cwd=SRC,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();row['exit_code']=child.wait();save()
 assert row['exit_code']==0,'Original failed outputs retained; no retry'
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')};env.update(PYTHONDONTWRITEBYTECODE='1',TEMP=str(ROOT/'target/tmp'),TMP=str(ROOT/'target/tmp'),LOCALAPPDATA=str(OUT/'appdata'))
try:
 run('original-controls',[sys.executable,str(SRC/'test_flow.py'),'-v'])
 assert 'Ran 8 tests' in (OUT/'original-controls.stderr.log').read_text()
 original=BASE/'tracking88-stratified-seed-candidate-v1/real-baseline'
 video=BASE/'tracking88-real-planar-acquisition-v1/phone.avi'
 assert sha(video)=='c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
 ffmpeg=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
 report['source_sha256']=sha(video);report['blind_outputs']={}
 for mode in ('no-corrections','periodic-manual-200'):
  request=original/(mode+'.request.json');report.setdefault('requests',{})[mode]=dict(path=str(request),sha256=sha(request));save()
  run(mode,[sys.executable,str(SRC/'track_plate.py'),'--source',str(video),'--request',str(request),'--output',str(OUT/mode),'--ffmpeg',str(ffmpeg),'--ffprobe',str(ffmpeg.with_name('ffprobe.exe'))])
  assert not (OUT/(mode+'.stdout.log')).read_bytes()
  asset=json.loads((OUT/mode/'tracks.mstrack').read_text())
  assert asset['source_pts']==list(range(2300)) and asset['ticks_per_second']==100
  report['blind_outputs'][mode]=sha(OUT/mode/'tracks.mstrack');save()
 report['status']='both_complete_outputs_sealed_before_full_annotation_read';save()
 # No reference-driven parameter or output changes after opening labels.
 sys.path.insert(0,str(SRC));import numpy as np;import plate_flow as flow
 labels=BASE/'tracking88-real-planar-acquisition-v1/phone-gt.zip'
 assert sha(labels)=='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
 with zipfile.ZipFile(labels) as z:
  corners=[]
  for index in range(2300):
   values=np.array([float(v) for v in z.read(f'img_{index+200:05d}.txt').decode().split()]).reshape(2,4)
   corners.append(np.column_stack((values[1]-1,values[0]-1)))
 baseline=json.loads((original/'measurement.json').read_text());report['runs']=[]
 for mode in ('no-corrections','periodic-manual-200'):
  asset=json.loads((OUT/mode/'tracks.mstrack').read_text());summaries=[]
  assert sha(OUT/mode/'tracks.mstrack')==report['blind_outputs'][mode]
  for track in asset['tracks']:
   errors=[];lost=manual=0
   for index,sample in enumerate(track['samples']):
    assert sample['source_index']==index
    if index==0:continue
    if sample['manual_correction']:manual+=1;continue
    if sample['visibility']!='visible':lost+=1;continue
    observation=sample['observation']
    error=float(np.linalg.norm(np.array(observation['pixels'])-corners[index][0])) if track['kind']=='point' else float(np.linalg.norm(flow.transform(np.array(observation['matrix']),corners[0])-corners[index],axis=1).max())
    errors.append(error)
   original_track=next(t for r in baseline['runs'] if r['mode']==mode for t in r['tracks'] if t['track']==track['id'])
   summaries.append(dict(track=track['id'],automaticVisible=len(errors),automaticLost=lost,manualSamples=manual,maxPixels=max(errors) if errors else None,rmsPixels=float(np.sqrt(np.mean(np.square(errors)))) if errors else None,automaticOver15Pixels=sum(e>15 for e in errors),baselineVisible=original_track['automaticVisible'],baselineMaxPixels=original_track['maxPixels'],coverage_retained=len(errors)>=original_track['automaticVisible'],original_accuracy_gate=bool(errors) and max(errors)<=15))
  report['runs'].append(dict(mode=mode,tracks=summaries))
 report['all_original_quality_and_coverage_gates']=all(t['coverage_retained'] and t['original_accuracy_gate'] for r in report['runs'] for t in r['tracks'])
 report['status']='isolated_candidate_needs_independent_adoption_review' if report['all_original_quality_and_coverage_gates'] else 'rejected_candidate_original_quality_or_coverage_failure_retained'
except BaseException as cause:
 report.update(status='failed_original_outputs_retained_not_adopted',cause=repr(cause),traceback=traceback.format_exc())
finally:
 report.update(candidate_unchanged=all(sha(SRC/n)==r['candidate_sha256'] for n,r in prep['files'].items()),completed_utc=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({k:report.get(k) for k in ('status','cause','runs','candidate_unchanged')}))
raise SystemExit(0 if report['status']!='failed_original_outputs_retained_not_adopted' and report['candidate_unchanged'] else 1)
