"""Archive actual scheduler controls and independent owned-job counter proof."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ART = Path('E:/Dev/aem/artifacts/pr-queue')
WORK = Path('E:/Dev/aem/.worktrees/depth-retained-context75')
SOURCE = ART / 'depth75-sustained-host-example-controls-v1'
OUT = ART / 'depth75-sustained-host-controls-public-v1'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


report = read(SOURCE / 'receipt.json')
consumed = read(SOURCE / 'session-consumed.json')
assert report['status'] == 'complete_reference_example_controls_and_build_passed'
assert report['source_unchanged'] and consumed['original_tool_result_consumed']
assert consumed['session'] == 23477 and consumed['exit_code'] == 0
assert report['complete_example_controls'] == dict(passed=4, failed=0, ignored=0, filtered=0)
counter = read(ART / 'depth75-owned-job-memory-control-v1/receipt.json')
assert counter['status'] == 'passed' and counter['failure'] is None and not counter['cleanup_failures']
before, overlap, after = counter['observations']
assert before['active_processes'] == after['active_processes'] == 1
assert overlap['active_processes'] == overlap['total_processes'] == after['total_processes'] == 3
assert overlap['peak_job_commit_bytes'] > overlap['peak_process_commit_bytes']
assert after['peak_job_commit_bytes'] >= overlap['peak_job_commit_bytes']
assert all(row['limit_flags'] == 0 for row in counter['observations'])
assert all(row['resident_bytes'] is None and row['device_bytes'] is None for row in counter['observations'])
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'collection-controller.py')
for name in ('controller.py', 'receipt.json', 'session-consumed.json',
             'example-tests.stdout.log', 'example-tests.stderr.log',
             'example-build.stdout.log', 'example-build.stderr.log'):
    origin = SOURCE / name
    if name in report['logs']:
        assert sha(origin) == report['logs'][name]['sha256']
    shutil.copyfile(origin, OUT / name)
for path in sorted((SOURCE / 'source').rglob('*.rs')):
    relative = path.relative_to(SOURCE / 'source').as_posix()
    assert sha(path) == report['source_sha256'][relative] == sha(WORK / relative)
    destination = OUT / 'source' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, destination)
shutil.copyfile(ART / 'depth75-sustained-host-example-controls-v1-consume.py', OUT / 'consume-controller.py')
shutil.copyfile(ART / 'depth75-owned-job-memory-proposal.py', OUT / 'owned-job-control.py')
assert sha(OUT / 'owned-job-control.py') == '6afcfc4357d6c46dd3e0198ae693e816d75522b88d6ff9f83df11283e517bb9d'
shutil.copyfile(ART / 'depth75-owned-job-memory-control-v1/receipt.json', OUT / 'owned-job-receipt.json')
for name in ('stdout', 'stderr'):
    origin = ART / f'depth75-owned-job-memory-control-v1.{name}.log'
    assert origin.stat().st_size == 0
    shutil.copyfile(origin, OUT / f'owned-job-{name}.log')
protocol = WORK / 'engineering/validation/depth75-sustained-host-remap-protocol.md'
assert protocol.read_bytes() == (ART / 'depth75-sustained-host-proposal/protocol.md').read_bytes()
shutil.copyfile(protocol, OUT / 'protocol.md')
collection = dict(status='complete_example_controls_and_owned_job_counter_passed_not_model_qualification',
                  component_session=23477, component_exit=0, source_parent=report['head'],
                  component_controls=report['complete_example_controls'],
                  original_counter_tool_chunk='3eecbb', original_counter_exit=0,
                  counter_method='windows_owned_job_commit',
                  counter_overlap_peak_job_bytes=overlap['peak_job_commit_bytes'],
                  counter_overlap_peak_process_bytes=overlap['peak_process_commit_bytes'],
                  driver_sha256=report['driver_sha256'], protocol_sha256=sha(protocol),
                  qualified=False, actual_model_or_sustained_run=False,
                  limits=['Two controlled owned16MiB allocations, no resource limit or foreign process attachment',
                          'Committed-memory peak is not RSS, GPU allocation or actual model consumption',
                          'Four complete example controls include three unchanged pre-existing assertions',
                          'Original full-workspace failures remain failed; no repeat of those targets'])
(OUT / 'collection.json').write_text(json.dumps(collection, indent=2) + '\n', encoding='utf-8')
members = {p.relative_to(OUT).as_posix(): dict(bytes=p.stat().st_size, sha256=sha(p))
           for p in sorted(OUT.rglob('*')) if p.is_file()}
archive = OUT / 'depth75-sustained-host-controls-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
    for name in members:
        target.write(OUT / name, name)
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(members)
    for name, expected in members.items():
        raw = target.read(name)
        assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256']
manifest = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=members,
                readback='Every member CRC, byte length and SHA-256 verified',
                qualification='No actual learned-model sustained or memory qualification')
(OUT / 'depth75-sustained-host-controls-v1.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: manifest[k] for k in ('archive', 'bytes', 'sha256')}))
