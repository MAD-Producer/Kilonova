"""First complete example controls after adding bounded one-service scheduling."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import shutil
import subprocess
import traceback

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-retained-context75'
TARGET = ROOT / 'target/depth-wgsl-cache75-contract'
OUT = ART / 'depth75-sustained-host-example-controls-v1'
CP = ART / 'depth75-resume-current.json'
FILES = {'crates/motion-host/examples/depth_reference.rs',
         'crates/motion-host/examples/depth_reference/sustained.rs'}


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.pending')
    temporary.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=WORK, text=True).strip()


def main():
    assert shutil.disk_usage(ROOT).free >= 10 << 30
    state = read(CP)
    v = state['versionedCache75']
    assert v['activeController'] is None and not v['ownHeavyWorkloads']
    assert read(ART / 'depth75-host-remap-workspace-v1/session-consumed.json')['original_tool_result_consumed']
    counter = read(ART / 'depth75-owned-job-memory-control-v1/receipt.json')
    assert counter['status'] == 'passed' and not counter['cleanup_failures']
    head = git('rev-parse', 'HEAD')
    assert head == '0868d049aee673b1591766c34d6d6008dd766516'
    changed = set(git('diff', '--name-only').splitlines())
    changed.update(git('ls-files', '--others', '--exclude-standard').splitlines())
    assert changed == FILES
    names = git('ls-files').splitlines() + sorted(FILES - set(git('ls-files').splitlines()))

    def sources():
        return {name: sha(WORK / name) for name in names}

    OUT.mkdir(exist_ok=False)
    shutil.copyfile(__file__, OUT / 'controller.py')
    for name in FILES:
        destination = OUT / 'source' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(WORK / name, destination)
    env = {k: value for k, value in os.environ.items() if not k.startswith('MOTION_')}
    ff = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
    env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(TARGET),
               CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0',
               CARGO_PROFILE_TEST_DEBUG='0', TEMP=str(TARGET / 'tmp'), TMP=str(TARGET / 'tmp'),
               LOCALAPPDATA=str(OUT / 'appdata'), PYTHONDONTWRITEBYTECODE='1', RUST_BACKTRACE='full',
               LIBCLANG_PATH=str(ROOT / '.tools/python-libclang/clang/native'), FFMPEG_DIR=str(ff),
               FFMPEG_INCLUDE_DIR=str(ff / 'include'), FFMPEG_LIB_DIR=str(ff / 'lib'))
    env['PATH'] = str(ff / 'bin') + os.pathsep + env['PATH']
    report = dict(status='running', head=head, source_sha256=sources(), stages=[],
                  started_utc=datetime.now(timezone.utc).isoformat(),
                  limits=['Complete reference example controls; no learned model or sustained run yet',
                          'No original assertion, timeout, ignored test or scientific threshold changed',
                          'Previous original full regression remains failed and is not rerun'])

    def save():
        write(OUT / 'receipt.json', report)

    def frozen():
        return git('rev-parse', 'HEAD') == head and sources() == report['source_sha256']

    def command(label, arguments):
        stage = dict(label=label, arguments=arguments)
        report['stages'].append(stage)
        save()
        with (OUT / (label + '.stdout.log')).open('wb') as stdout, (OUT / (label + '.stderr.log')).open('wb') as stderr:
            child = subprocess.Popen(arguments, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
            stage['pid'] = child.pid
            save()
            stage['exit_code'] = child.wait()
        save()
        assert stage['exit_code'] == 0 and frozen(), stage

    v.update(activeController=str(Path(__file__)), ownHeavyWorkloads=[dict(
        kind='complete example controls and build after sustained entry addition', head=head,
        sourceFrozen=True, output=str(OUT))], currentLocalSourceHead=head)
    write(CP, state)
    save()
    try:
        command('example-tests', ['cargo', 'test', '-p', 'motion-host', '--features', 'ai-depth',
                                 '--example', 'depth_reference', '--locked', '--offline', '--', '--test-threads=1'])
        stdout = (OUT / 'example-tests.stdout.log').read_text(encoding='utf-8')
        summaries = re.findall(r'(?m)^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out', stdout)
        assert summaries == [('4', '0', '0', '0')]
        name = 'sustained::tests::schedule_requires_complete_cohorts_duration_and_refuses_a_short_capped_run'
        assert len(re.findall(r'(?m)^test ' + re.escape(name) + r' \.\.\. ok$', stdout)) == 1
        report['complete_example_controls'] = dict(passed=4, failed=0, ignored=0, filtered=0)
        command('example-build', ['cargo', 'build', '-p', 'motion-host', '--features', 'ai-depth',
                                 '--example', 'depth_reference', '--locked', '--offline'])
        report.update(status='complete_reference_example_controls_and_build_passed',
                      driver_sha256=sha(TARGET / 'debug/examples/depth_reference.exe'))
    except BaseException:
        report.update(status='failed_original_outcome_retained', cause=traceback.format_exc())
    finally:
        report.update(source_unchanged=frozen(), completed_utc=datetime.now(timezone.utc).isoformat())
        report['logs'] = {p.name: dict(bytes=p.stat().st_size, sha256=sha(p)) for p in OUT.glob('*.log')}
        save()
        print(json.dumps({k: report.get(k) for k in ('status', 'complete_example_controls', 'driver_sha256', 'source_unchanged')}))
    return 0 if report['status'] == 'complete_reference_example_controls_and_build_passed' and report['source_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
