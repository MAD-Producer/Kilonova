"""Pending control: an owned Windows process group, not additive process peaks.

API declarations independently authored from the public Windows documentation:
https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects
https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-queryinformationjobobject
https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_extended_limit_information

Only this newly launched observer process joins its newly created job. Future
children inherit it. No resource limit, breakaway flag, process termination,
global enumeration, external PID or foreign job handle is configured here.
The observed job peak is committed memory, NOT resident/GPU/physical memory.
This proposal has not yet been executed and is not qualification evidence.
"""
import ctypes as C
from ctypes import wintypes as W
from pathlib import Path
import json,os,subprocess,sys,time,traceback

class BasicLimits(C.Structure):
    _fields_=[('process_time',C.c_int64),('job_time',C.c_int64),('flags',W.DWORD),
              ('minimum_ws',C.c_size_t),('maximum_ws',C.c_size_t),('process_limit',W.DWORD),
              ('affinity',C.c_size_t),('priority',W.DWORD),('scheduling',W.DWORD)]
class Io(C.Structure):
    _fields_=[(n,C.c_uint64) for n in ('read_ops','write_ops','other_ops','read_bytes','write_bytes','other_bytes')]
class ExtendedLimits(C.Structure):
    _fields_=[('basic',BasicLimits),('io',Io),('process_limit',C.c_size_t),('job_limit',C.c_size_t),
              ('peak_process',C.c_size_t),('peak_job',C.c_size_t)]
class Accounting(C.Structure):
    _fields_=[(n,C.c_int64) for n in ('user','kernel','period_user','period_kernel')]+[
             (n,W.DWORD) for n in ('faults','total_processes','active_processes','terminated_by_limit')]
class ProcessIds(C.Structure):
    _fields_=[('assigned',W.DWORD),('count',W.DWORD),('ids',C.c_size_t*64)]

class OwnedJob:
    def __init__(self):
        if os.name!='nt' or C.sizeof(C.c_void_p)!=8:
            raise RuntimeError('this control requires Windows64; no fallback metric')
        assert (C.sizeof(BasicLimits),C.sizeof(ExtendedLimits),C.sizeof(Accounting))==(64,144,48)
        self.api=C.WinDLL('kernel32',use_last_error=True)
        a=self.api
        a.CreateJobObjectW.argtypes=[C.c_void_p,W.LPCWSTR];a.CreateJobObjectW.restype=W.HANDLE
        a.AssignProcessToJobObject.argtypes=[W.HANDLE,W.HANDLE];a.AssignProcessToJobObject.restype=W.BOOL
        a.GetCurrentProcess.argtypes=[];a.GetCurrentProcess.restype=W.HANDLE
        a.QueryInformationJobObject.argtypes=[W.HANDLE,C.c_int,C.c_void_p,W.DWORD,C.POINTER(W.DWORD)]
        a.QueryInformationJobObject.restype=W.BOOL
        a.IsProcessInJob.argtypes=[W.HANDLE,W.HANDLE,C.POINTER(W.BOOL)];a.IsProcessInJob.restype=W.BOOL
        a.CloseHandle.argtypes=[W.HANDLE];a.CloseHandle.restype=W.BOOL
        self.handle=a.CreateJobObjectW(None,None)
        if not self.handle:raise C.WinError(C.get_last_error())
        if not a.AssignProcessToJobObject(self.handle,a.GetCurrentProcess()):
            cause=C.WinError(C.get_last_error())
            try:self.close()
            except BaseException as cleanup:cause.add_note('job handle cleanup: '+repr(cleanup))
            raise cause
        self.owner=os.getpid()
        assert self.snapshot()['limit_flags']==0
    def close(self):
        if self.handle:
            handle=self.handle;self.handle=None
            if not self.api.CloseHandle(handle):raise C.WinError(C.get_last_error())
    def query(self,kind,structure):
        result=structure();returned=W.DWORD()
        if not self.api.QueryInformationJobObject(self.handle,kind,C.byref(result),C.sizeof(result),C.byref(returned)):
            raise C.WinError(C.get_last_error())
        if returned.value!=C.sizeof(result) and kind!=3:
            raise RuntimeError('unexpected job-counter result size')
        return result
    def contains_owned_child(self,child):
        # The exact direct child handle returned by our own Popen; no OpenProcess
        # call or global/foreign process discovery is performed.
        result=W.BOOL()
        if not self.api.IsProcessInJob(int(child._handle),self.handle,C.byref(result)):
            raise C.WinError(C.get_last_error())
        return bool(result.value)
    def snapshot(self):
        limits=self.query(9,ExtendedLimits);account=self.query(1,Accounting);ids=self.query(3,ProcessIds)
        if limits.basic.flags!=0 or account.terminated_by_limit!=0:
            raise RuntimeError('observer did not remain without resource restrictions')
        if ids.count>64 or ids.count!=ids.assigned:
            raise RuntimeError('owned job membership exceeds bounded observation')
        return dict(method='windows_owned_job_commit',owner_pid=os.getpid(),
                    peak_job_commit_bytes=limits.peak_job,peak_process_commit_bytes=limits.peak_process,
                    total_processes=account.total_processes,active_processes=account.active_processes,
                    member_pids=list(ids.ids[:ids.count]),limit_flags=limits.basic.flags,
                    resident_bytes=None,device_bytes=None)

def control(output):
    output=Path(output);output.mkdir(exist_ok=False)
    job=None;children=[];observations=[];failure=None;cleanup_failures=[]
    try:
        job=OwnedJob()
        before=job.snapshot();observations.append(before)
        assert before['total_processes']==before['active_processes']==1
        assert before['member_pids']==[os.getpid()]
        child_code="import sys; from pathlib import Path; value=bytearray(16<<20); Path(sys.argv[1]).write_text('ready'); sys.stdin.buffer.read(1)"
        for i in range(2):
            ready=output/('child-'+str(i)+'.ready')
            with (output/('child-'+str(i)+'.stderr.log')).open('wb') as stderr, (output/('child-'+str(i)+'.stdout.log')).open('wb') as stdout:
                child=subprocess.Popen([sys.executable,'-B','-c',child_code,str(ready)],stdin=subprocess.PIPE,
                    stdout=stdout,stderr=stderr)
            children.append(child);assert job.contains_owned_child(child)
            deadline=time.monotonic()+5
            while not ready.exists():
                assert child.poll() is None, 'own allocation child exited before readiness'
                assert time.monotonic()<deadline, 'own allocation child readiness timeout'
                time.sleep(.01)
            assert ready.read_bytes()==b'ready'
        overlap=job.snapshot();observations.append(overlap)
        assert overlap['active_processes']==overlap['total_processes']==3
        assert set(overlap['member_pids'])=={os.getpid(),*(p.pid for p in children)}
        assert overlap['peak_job_commit_bytes']>=before['peak_job_commit_bytes']+(32<<20)
        assert overlap['peak_job_commit_bytes']>overlap['peak_process_commit_bytes']
        for child in children:
            stdout,_=child.communicate(b'x',timeout=5);assert child.returncode==0 and stdout is None
        assert all(p.stat().st_size==0 for p in output.glob('child-*.stdout.log'))
        # Close our owned process handles so accounting can observe their exit.
        for child in children:child._handle.Close()
        deadline=time.monotonic()+5
        while True:
            after=job.snapshot()
            if after['active_processes']==1:break
            assert time.monotonic()<deadline, 'owned child accounting did not observe exit'
            time.sleep(.01)
        observations.append(after)
        assert after['active_processes']==1 and after['total_processes']==3
        assert after['peak_job_commit_bytes']>=overlap['peak_job_commit_bytes']
    except BaseException:
        failure=traceback.format_exc();raise
    finally:
        for child in children:
            try:
                if child.poll() is None:
                    child.stdin.close();child.wait(timeout=5)
            except BaseException:cleanup_failures.append(traceback.format_exc())
        if job is not None:
            try:job.close()
            except BaseException:cleanup_failures.append(traceback.format_exc())
        (output/'receipt.json').write_text(json.dumps(dict(status='passed' if failure is None and not cleanup_failures else 'failed',
            failure=failure,cleanup_failures=cleanup_failures,observations=observations,qualified=False,
            limits=['Only a new own observer and its two children',
                    'Committed memory; not RSS, GPU allocations or whole-application qualification',
                    'No SetInformationJobObject, resource limits, foreign processes or fallback']),indent=2)+'\n',encoding='utf-8')
        if failure is None and cleanup_failures:raise RuntimeError('owned cleanup failed; receipt retains causes')
if __name__=='__main__':
    control(sys.argv[1])
