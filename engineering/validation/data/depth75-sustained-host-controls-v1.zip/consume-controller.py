"""Consume original example-control session23477 before source editing resumes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

ART = Path('E:/Dev/aem/artifacts/pr-queue')
WORK = Path('E:/Dev/aem/.worktrees/depth-retained-context75')
OUT = ART / 'depth75-sustained-host-example-controls-v1'
CP = ART / 'depth75-resume-current.json'
report = json.loads((OUT / 'receipt.json').read_text())
assert report['status'] == 'complete_reference_example_controls_and_build_passed'
assert report['source_unchanged'] and all(row['exit_code'] == 0 for row in report['stages'])
assert report['complete_example_controls'] == dict(passed=4, failed=0, ignored=0, filtered=0)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == report['head']
for name, expected in report['source_sha256'].items():
    assert hashlib.sha256((WORK / name).read_bytes()).hexdigest() == expected, name
for name, expected in report['logs'].items():
    raw = (OUT / name).read_bytes()
    assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256']
receipt = dict(session=23477, exit_code=0, original_tool_result_consumed=True,
               original_chunk_id='516ca8', source_unchanged=True,
               source_freeze_released=True, observed_utc=datetime.now(timezone.utc).isoformat(),
               complete_example_controls=report['complete_example_controls'],
               learned_model_or_sustained_observation=False)
with (OUT / 'session-consumed.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
state = json.loads(CP.read_text(encoding='utf-8-sig'))
v = state['versionedCache75']
assert Path(v['activeController']) == ART / 'depth75-sustained-host-example-controls-v1-controller.py'
v.update(activeController=None, ownHeavyWorkloads=[], sustainedExampleControls=receipt,
         sustainedExampleControlsOutput=str(OUT), localUnpublishedHead=report['head'],
         pendingOwnedJobMemoryProposal=dict(
             status='actual_control_passed', original_tool_exit=0, original_tool_chunk='3eecbb',
             receipt=str(ART / 'depth75-owned-job-memory-control-v1/receipt.json'),
             counter='windows_owned_job_commit', full_model_memory_measured=False))
temporary = CP.with_suffix('.pending.json')
temporary.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
temporary.replace(CP)
print(json.dumps(receipt))
