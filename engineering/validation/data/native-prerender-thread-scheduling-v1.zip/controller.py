"""One source-frozen OS scheduling red/green gate; not issue completion."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT/'.worktrees/native-prerender-runtime'
OUT = ROOT/'artifacts/pr-queue/prerender-thread-scheduling-v1'
BASE = '02a19dadbf26b06ebea365775c965e0daa1f0e54'
WORKER = WORK/'crates/motion-desktop-media/src/movie/prerender/worker.rs'
NAME = 'movie::prerender::worker::tests::scheduling::actual_optional_owner_has_background_priority_before_source_preparation'

def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git',*args],cwd=WORK).decode().strip()
def digest(data): return hashlib.sha256(data).hexdigest()
def sources():
    return {n:digest((WORK/n).read_bytes()) for n in git('ls-files','--cached','--others','--exclude-standard','-z').split('\0')
            if n and n.endswith(('.rs','.toml','.lock','.wgsl','.json','.yml','.yaml','.py','.md'))}

assert git('rev-parse','HEAD') == BASE
previous=json.loads((ROOT/'artifacts/pr-queue/prerender-rebased-main-v1/exit.json').read_text(encoding='utf-8'))
assert previous['completedUtc'] and previous['status']=='accepted_current_main_boundary_components_not_issue_completion'
active=subprocess.check_output(['powershell','-NoProfile','-Command',
    "@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('rustc.exe','link.exe','cargo.exe') -and $_.CommandLine -match 'gltf-animation87-contract' }).Count"]).decode().strip()
assert active=='0',f'owned target still active: {active}'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
original=WORKER.read_bytes()
source=sources()
report=dict(status='running',controllerPid=os.getpid(),base=BASE,source=source,steps=[],startedUtc=now(),
    limits='Actual Windows OS policy and worker controls; strict foreground input and other OS execution not accepted by component passes. No assertions weakened, no retries, no Android.')
def save():
    tmp=OUT/'exit.next.json'; tmp.write_text(json.dumps(report,indent=2),encoding='utf-8');os.replace(tmp,OUT/'exit.json')
env=os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'owned-profile'),PYTHONPATH=str(ROOT/'.tools/build-validation-python'))
Path(env['LOCALAPPDATA']).mkdir()

def step(name,args,expected=None,negative=False):
    report['activeStep']=dict(name=name,command=args,startedUtc=now());save()
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        report['activeStep']['pid']=child.pid;save();code=child.wait()
    report['activeStep'].update(exitCode=code,completedUtc=now());save()
    text=(OUT/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace')
    errors=(OUT/f'{name}.stderr.log').read_text(encoding='utf-8',errors='replace')
    counts=re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
    if negative:
        passed=code!=0 and counts==[('0','1','0')] and 'native owner still has foreground CPU priority' in text+errors
    else:
        passed=code==0 and (expected is None or counts==[(str(expected),'0','0')])
        if counts: passed=passed and all(int(c[1])==0 for c in counts)
    row=dict(name=name,command=args,exitCode=code,counts=counts,passed=passed,negativeControl=negative,
        startedUtc=report['activeStep']['startedUtc'],completedUtc=report['activeStep']['completedUtc'])
    report['steps'].append(row);save();print(json.dumps(row),flush=True)
    assert passed,f'{name} failed; original bytes and actual exit preserved; no later build'
    report.pop('activeStep',None);save()

try:
    for name in ['crates/motion-model/src/lib.rs','crates/motion-core/src/lib.rs','crates/motion-render/src/lib.rs',
                 'crates/motion-host/src/lib.rs','crates/motion-desktop-media/src/lib.rs','desktop/app/src/main.rs']:
        os.utime(WORK/name,None)
    start=original.index(b'            if scheduling.is_none()')
    end=original.index(b'            match work {',start)
    negative=original[:start]+original[end:]
    # The unchanged real-worker assertion must fail without production policy.
    # Remove its now-unused local to keep the original inference context valid.
    negative=negative.replace(b'    let mut scheduling = None;\n',b'').replace(b'    let mut scheduling = None;\r\n',b'')
    report['negativeWorkerSha256']=digest(negative);save()
    WORKER.write_bytes(negative)
    media=['cargo','test','-p','motion-desktop-media','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--lib']
    try:
        step('original-priority-negative',media+[NAME,'--','--exact','--nocapture','--test-threads=1'],negative=True)
    finally:
        WORKER.write_bytes(original)
        assert WORKER.read_bytes()==original
    assert sources()==source
    step('actual-worker-priority',media+[NAME,'--','--exact','--nocapture','--test-threads=1'],expected=1)
    step('actual-os-isolation',media+['movie::prerender::worker::scheduling::background_policy_changes_only_its_own_thread_and_is_idempotent','--','--exact','--test-threads=1'],expected=1)
    step('native-worker-regression',media+['movie::prerender::worker::','--','--test-threads=1'])
    step('provenance',[sys.executable,'tools/validate_provenance.py'])
    step('tool-inventory',[sys.executable,'tools/validation_inventory.py'])
    step('whitespace',['git','diff','--check'])
    assert sources()==source
    report.update(status='accepted_windows_scheduling_component_not_performance_acceptance',completedUtc=now());save()
except BaseException as error:
    report.update(status='failed',completedUtc=now(),failure=repr(error));save();raise
