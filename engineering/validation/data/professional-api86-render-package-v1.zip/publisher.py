from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
folder = root / 'artifacts/pr-queue/professional-api86-render-package-v1'
report = json.loads((folder / 'exit.json').read_text(encoding='utf-8'))
assert report['exitCode'] == 0 and report['sourceUnchanged']
assert report['status'] == 'passed_scope_acceptance_pending'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(work / name) == digest for name, digest in report['sources'].items())
expected = report['expectedTargets']
invoked = report['invokedTargets']
assert len(expected) == 120 and len(invoked) == len(expected) + 1
for target in expected:
    path = target['src_path'].replace('\\', '/')
    if 'lib' in target['kind']:
        marker = 'unittests src/lib.rs'
    elif 'example' in target['kind']:
        marker = 'unittests examples/' + path.rsplit('/', 1)[-1]
    else:
        marker = 'tests/' + path.rsplit('/', 1)[-1]
    assert sum(marker in line.replace('\\', '/') for line in invoked) == 1, marker
assert sum('Doc-tests motion_render' in line for line in invoked) == 1
assert len(report['summaries']) == len(invoked)
counts = [tuple(map(int, re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored;', line).groups())) for line in report['summaries']]
totals = dict(zip(('passed', 'failed', 'ignored'), map(sum, zip(*counts))))
assert totals['failed'] == 0
out = work / 'engineering/validation/data/professional-api86-render-package-v1.zip'
receipt = out.with_suffix('.json')
assert not out.exists() and not receipt.exists()
out.parent.mkdir(parents=True, exist_ok=True)
entries = {p.name: p for p in folder.iterdir() if p.is_file()}
entries['environment.ps1'] = root / '.tools/issue-closure-review/run-professional-api86-render-package-v1.ps1'
entries['publisher.py'] = Path(__file__)
manifest = dict(status='complete_render_package_passed_final_main_acceptance_pending', head=report['head'], sourceUnchanged=True, targets=len(expected), docTestTargets=1, elapsedSeconds=report['elapsedSeconds'], **totals, entries={name: dict(bytes=p.stat().st_size, sha256=sha(p)) for name, p in entries.items()}, limits=['This gate predates integration of main251d and tracking root PR580; it does not validate the final combined source', 'Only tracked crates and Cargo manifests were frozen; approved desktop-only clock edits were made during this gate', 'Complete desktop previously failed eight readouts; ten focused CPU tests subsequently passed with the approved fix, not a complete desktop acceptance', 'Original native heap corruption and further issue86 professional acceptance remain unresolved', 'Android is outside the maintained acceptance scope'])
with zipfile.ZipFile(out, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
    for name, path in entries.items():
        z.write(path, name)
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for name, details in manifest['entries'].items():
        assert hashlib.sha256(z.read(name)).hexdigest() == details['sha256']
summary = {k: v for k, v in manifest.items() if k != 'entries'}
summary.update(archive=out.name, bytes=out.stat().st_size, sha256=sha(out), members=len(entries)+1)
receipt.write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
doc = work / 'engineering/validation/professional-api86-render-package-current.md'
assert not doc.exists()
doc.write_text(f'''# Complete render package acceptance

The complete `motion-render` package passed on the tracked crate/manifests
closure of `{report['head']}`. The source hashes were unchanged throughout
the run. This is a completed package gate, not final-main or issue86 closure.

The real command was `cargo test -p motion-render --no-fail-fast --locked
--offline -- --test-threads=1`. Default mandatory GPU acceptance was enabled.
All {len(expected)} Cargo-discovered test targets and the documentation target
were matched independently against the actual Cargo invocation log. There
were {totals['passed']} passed tests, {totals['failed']} failures and
{totals['ignored']} existing ignored tests. The process exited 0 after
{report['elapsedSeconds']} seconds. No filters, retries, assertion changes,
ignore edits, Android checks or second simultaneous GPU gate were used.

Approved desktop-only clock edits happened during this run. The recorded
closure freezes all tracked crate files and the root Cargo manifests, not
the entire worktree. Neither the later main251d integration nor the new
tracking-root PR580 merge is covered by this result. Fresh combined-source
regression and cross-platform CI remain required.

The previous full desktop failure and subsequent ten-test clock repair are
separately retained in `frame-rate85-panel-fixtures-current.md` and
`frame-rate85-mini-clock-current.md`. The historical native heap corruption
has not been diagnosed by this successful renderer gate. Professional
footage/matte acceptance remaining under issue86 is not implied complete.

The immutable archive is `data/{out.name}` with {len(entries)+1} members.
SHA-256: `{sha(out)}`. Its manifest includes every raw-log, controller,
environment and source-identity report hash; every member was read back and
verified after creation. The adjacent JSON receipt records the exact count
and scope. No product code, panels, styles, assets or dependencies change in
this evidence-only increment.
''', encoding='utf-8')
print(json.dumps(summary), flush=True)
