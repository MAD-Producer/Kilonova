from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/professional-api86-render-package-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
tracked = subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock'],cwd=work).decode().split('\0')
sources = {name:sha(work/name) for name in tracked if name and (work/name).is_file()}
assert subprocess.check_output(['git','status','--porcelain'],cwd=work).strip() == b''
metadata = json.loads(subprocess.check_output(['cargo','metadata','--no-deps','--format-version','1','--offline','--locked'],cwd=work))
package = next(p for p in metadata['packages'] if p['name']=='motion-render')
targets = [{k:t[k] for k in ['name','kind','test','src_path']} for t in package['targets'] if t['test']]
report = dict(status='running',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),startedUtc=datetime.now(timezone.utc).isoformat(),scope='Complete motion-render package with default mandatory GPU acceptance, all Cargo-discovered test targets and doc tests; no filters, retries, ignore edits or Android acceptance. Does not include the failing desktop package.',sources=sources,expectedTargets=targets)
save = lambda: (out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
command = ['cargo','test','-p','motion-render','--no-fail-fast','--locked','--offline','--','--test-threads=1']
report['command'] = command
save()
start = time.monotonic()
try:
    with (out/'package.stdout.log').open('wb') as stdout,(out/'package.stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command,cwd=work,env=os.environ.copy(),stdout=stdout,stderr=stderr)
        report['pid']=child.pid
        save()
        report['exitCode']=child.wait()
    stdout=(out/'package.stdout.log').read_text(encoding='utf-8',errors='replace')
    stderr=(out/'package.stderr.log').read_text(encoding='utf-8',errors='replace')
    report['summaries']=re.findall(r'^test result: .+$',stdout,re.M)
    report['invokedTargets']=re.findall(r'^\s*(?:Running|Doc-tests) .+$',stderr,re.M)
    report['sourceUnchanged']=all(sha(work/name)==digest for name,digest in sources.items())
    report['status']='passed_scope_acceptance_pending' if report['exitCode']==0 and report['sourceUnchanged'] else 'failed_original_results_retained'
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-start,3))
    save()
    print(json.dumps({k:v for k,v in report.items() if k!='sources'}),flush=True)
raise SystemExit(0 if report['status']=='passed_scope_acceptance_pending' else 1)
