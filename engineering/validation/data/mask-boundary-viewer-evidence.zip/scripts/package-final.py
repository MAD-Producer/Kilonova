from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile

WORK = Path('E:/Dev/aem/.worktrees/mask-boundary-handles')
ART = Path('E:/Dev/aem/artifacts/pr-ci-followups/mask-boundary-handles')
RUN = ART / 'final-9b7fec95'
SOURCE = '9b7fec95c7c96333d9e013e073b79a4c408d99a0'
BASE = '171fc7a7ea6a78891c68133c27a1ecdc3b2d941a'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK)
assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
subprocess.run(['git', 'diff', '--quiet', 'HEAD', '--', 'desktop', 'crates', 'DESIGN.md'], cwd=WORK, check=True)
checks = json.loads((RUN/'results.json').read_text(encoding='utf-8-sig'))
assert [r['name'] for r in checks] == ['path-controls','native-viewer','native-link','boundary-gpu','render-masks','mask-plan','core-masks']
for row in checks:
    assert row['source'] == SOURCE and row['exit'] == 0
    log = (RUN/(row['name']+'.log')).read_text(encoding='utf-8-sig')
    row['test_results'] = [line for line in log.splitlines() if line.startswith('test result:')]
    assert row['test_results'] and all('test result: ok.' in result for result in row['test_results'])
viewer = json.loads((RUN/'viewer/matrix.json').read_text())
owners = json.loads((RUN/'owners/matrix.json').read_text())
assert len(viewer) == 12 and len(owners) == 24
assert all(case['result'] == 'passed' for case in owners)
assert len(list((RUN/'viewer').glob('*.png'))) == 72
assert len(list((RUN/'link').glob('*.png'))) == 24
error_file = (RUN/'failure/motion-studio.log').read_text()
error_stderr = (RUN/'failure/stderr.log').read_text()
error_stdout = (RUN/'failure/stdout.log').read_text()
assert sum('site=mask.boundary_geometry' in line for line in error_file.splitlines()) == 2
assert sum('site=mask.boundary_geometry' in line for line in error_stderr.splitlines()) == 2
assert 'site=mask.boundary_geometry' not in error_stdout
assert 'mask-boundary-info-probe' in error_file
assert 'mask-boundary-info-probe' not in error_stderr+error_stdout
summary = {'source': SOURCE, 'base': BASE, 'checks': checks, 'viewer_cases':len(viewer),
    'owner_cases':len(owners), 'viewer_pngs':72, 'link_pngs':24,
    'style_consumers':'passed', 'diff_check':'passed',
    'limits':['Windows native owners and explicit WindowEvents, not physical OS mouse injection',
        'Drawing pixel ratios do not change OS DPI', 'No standalone release executable produced',
        'Source-space feather sampling support excludes the sampler footprint and is not a hard alpha contour'],
    'earlier_runs': {'path-controls.log':'87 passed, 5 actual input/visibility regressions; superseded',
        'path-controls-priority.log':'91 passed, 2 remaining visibility/flush checks; superseded',
        'path-controls-distinct-grips.log':'93 passed, 1 ignored at 8cf5b278; superseded by final run',
        'native-viewer.log':'overlay-only capture insufficient for rendered content; superseded',
        'native-rendered-and-owners.log':'2 passed at b9087d33; superseded by final run'}}
entries = {}
def add(name, data):
    assert name not in entries
    entries[name] = data
for root in [RUN/'viewer',RUN/'link']:
    for file in root.rglob('*'):
        if file.is_file(): add('final/'+file.relative_to(RUN).as_posix(), file.read_bytes())
for part in ['owners','failure']:
    for name in ['matrix.json','stdout.log','stderr.log','logs/motion-studio.log','motion-studio.log']:
        file = RUN/part/name
        if file.is_file(): add('final/'+file.relative_to(RUN).as_posix(), file.read_bytes())
for file in RUN.glob('*.log'): add('final/'+file.name,file.read_bytes())
for file in (ART/'viewer-iteration').glob('*.log'): add('iterations/'+file.name,file.read_bytes())
for name in ['verify-final.ps1','package-final.py']: add('scripts/'+name,(ART/name).read_bytes())
add('source/change.patch',git('diff','--binary',BASE,SOURCE,'--','DESIGN.md','crates','desktop'))
for name in git('diff','--name-only',BASE,SOURCE,'--','DESIGN.md','crates','desktop').decode().splitlines():
    add('source/'+name,git('show',SOURCE+':'+name))
add('results.json',json.dumps(summary,ensure_ascii=False,indent=2).encode())
manifest = {name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in entries.items()}
add('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
out=WORK/'engineering/validation'
(out/'data').mkdir(exist_ok=True)
bundle=out/'data/mask-boundary-viewer-evidence.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(entries.items()): archive.writestr(name,data)
with zipfile.ZipFile(bundle) as archive:
    assert archive.testzip() is None
    for name,item in manifest.items(): assert hashlib.sha256(archive.read(name)).hexdigest() == item['sha256']
summary['bundle']={'path':'data/'+bundle.name,'entries':len(entries),'bytes':bundle.stat().st_size,
    'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest()}
shots=out/'mask-boundary-viewer'
shots.mkdir(exist_ok=True)
summary['screenshots']=[]
for name in ['zh-main-1x-feather-hover.png','zh-main-1x-feather-after.png',
    'zh-float-1x-expansion-hover.png','zh-main-1.5x-feather-hover.png']:
    original=RUN/'viewer'/name
    shutil.copyfile(original,shots/name)
    summary['screenshots'].append({'path':'mask-boundary-viewer/'+name,'original':str(original),
        'sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'modified':False})
(out/'mask-boundary-viewer-results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary['bundle'],ensure_ascii=False))
