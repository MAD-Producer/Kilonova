$ErrorActionPreference='Stop'
Set-Location -LiteralPath E:/Dev/aem/.worktrees/mask-boundary-handles
$frozen='9b7fec95c7c96333d9e013e073b79a4c408d99a0'
$evidenceRoot='E:/Dev/aem/artifacts/pr-ci-followups/mask-boundary-handles/final-9b7fec95'
New-Item -ItemType Directory -Path $evidenceRoot -Force | Out-Null
. E:/Dev/aem/artifacts/multiple-camera-layers/env.ps1
$env:CARGO_TARGET_DIR='E:/Dev/aem/target/host-error-contract-verified'
$env:CARGO_BUILD_JOBS='1'
$env:MOTION_MASK_VIEWER_EVIDENCE=Join-Path $evidenceRoot 'viewer'
$env:MOTION_MASK_VIEWER_OWNER_EVIDENCE=Join-Path $evidenceRoot 'owners'
$env:MOTION_MASK_BOUNDARY_EVIDENCE=Join-Path $evidenceRoot 'link'
$env:MOTION_MASK_BOUNDARY_FAILURE_EVIDENCE=Join-Path $evidenceRoot 'failure'
Remove-Item Env:MOTION_LOG -ErrorAction SilentlyContinue
function Verify-Frozen {
    if ((& git rev-parse HEAD).Trim() -ne $frozen) { throw 'HEAD changed during frozen validation' }
    & git diff --quiet HEAD -- desktop crates DESIGN.md
    if ($LASTEXITCODE -ne 0) { throw 'Frozen source content changed' }
}
Verify-Frozen
# Different worktrees share this target; require the local package roots to
# invalidate stale cross-worktree artifacts, without changing source bytes.
foreach ($manifest in (& rg --files crates desktop -g Cargo.toml)) {
    $crateRoot=Split-Path $manifest
    foreach ($entry in @('src/lib.rs','src/main.rs')) {
        $source=Join-Path $crateRoot $entry
        if (Test-Path -LiteralPath $source) { (Get-Item -LiteralPath $source).LastWriteTime=Get-Date }
    }
}
$records=[System.Collections.Generic.List[object]]::new()
function Run-Cargo([string]$name,[string[]]$arguments) {
    Verify-Frozen
    $timer=[System.Diagnostics.Stopwatch]::StartNew()
    & cargo @arguments *> (Join-Path $evidenceRoot "$name.log")
    $code=$LASTEXITCODE
    $records.Add([pscustomobject]@{name=$name;source=$frozen;arguments=$arguments;exit=$code;elapsed_ms=$timer.ElapsedMilliseconds})
    $records | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $evidenceRoot 'results.json') -Encoding utf8
    Verify-Frozen
    Write-Output "$name exit=$code elapsed_ms=$($timer.ElapsedMilliseconds)"
    if ($code -ne 0) { Get-Content -LiteralPath (Join-Path $evidenceRoot "$name.log") -Tail 45; throw "$name failed" }
}
$desktop=@('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline')
Run-Cargo 'path-controls' ($desktop+@('panels::path_controls','--','--test-threads=1'))
Run-Cargo 'native-viewer' ($desktop+@('panels::path_controls::mask_boundaries::viewer::tests::native','--','--ignored','--nocapture','--test-threads=1'))
Run-Cargo 'native-link' ($desktop+@('--','--exact','panels::path_controls::mask_boundaries::tests::native::native_mask_feather_link_main_and_float_pixels_and_transactions','--ignored','--nocapture','--test-threads=1'))
Run-Cargo 'boundary-gpu' @('test','-p','motion-render','--test','mask_boundary_geometry','--locked','--offline','--','--test-threads=1')
Run-Cargo 'render-masks' @('test','-p','motion-render','--test','layer_masks','--locked','--offline','--','--test-threads=1')
Run-Cargo 'mask-plan' @('test','-p','motion-render','--lib','--locked','--offline','mask_plan','--','--test-threads=1')
Run-Cargo 'core-masks' @('test','-p','motion-core','--test','layer_masks','--locked','--offline','--','--test-threads=1')
& python -B -c "from pathlib import Path; import runpy; d=runpy.run_path('tools/ci_desktop.py'); d['verify_style_consumers'](Path('desktop/app/src/panels'))" *> (Join-Path $evidenceRoot 'style-consumers.log')
if ($LASTEXITCODE -ne 0) {throw 'Style consumer check failed'}
& git diff --check
if ($LASTEXITCODE -ne 0) {throw 'git diff --check failed'}
Verify-Frozen
Write-Output 'Frozen validation complete'
