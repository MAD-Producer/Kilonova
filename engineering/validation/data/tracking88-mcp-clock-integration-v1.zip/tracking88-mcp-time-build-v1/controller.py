from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-mcp-time-build-v1'
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=WORK, encoding='utf-8').strip() == 'codex/88-tracking-replacement-mcp'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=WORK, encoding='utf-8').splitlines()
source = {p: hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in set(paths) if p.endswith(('.rs', '.wgsl', 'Cargo.toml', 'Cargo.lock')) and (WORK/p).is_file()}
owned = ['desktop/app/src/engine.rs', 'desktop/app/src/mcp/tracked_video.rs',
    'desktop/app/src/mcp/tracked_video_tests.rs', 'desktop/app/src/mcp/tracked_video_native_tests.rs',
    'desktop/app/src/workflow/tracked_video.rs', 'desktop/app/src/engine/tracking_video_surface_tests.rs']
for relative in owned:
    path = OUT / 'source' / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((WORK / relative).read_bytes())
commands = [
    ('tests', ['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','--','mcp::tracked_video::tests::','--test-threads=1','--nocapture']),
    ('surface', ['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','--',
        'engine::tracking_video_replacement_tests::paired::surface::tracked_plate_replacement_invalidates_actual_surface_front_and_history_retains_reuse', '--exact','--test-threads=1','--nocapture']),
    ('build', ['cargo','build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline']),
]
report = dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),source=source,commands=commands,results=[], head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,encoding='utf-8').strip(), integratedParent=subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=WORK,encoding='utf-8').strip())
def save(): (OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', RUST_BACKTRACE='full', MOTION_TRACKED_RPC_DIR=str(OUT))
ffmpeg = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
for name in ['MOTION_TRACKED_RPC_DIR', 'MOTION_TRACKED_SURFACE_ARTIFACTS']:
    env.pop(name, None)
env.update(FFMPEG_DIR=str(ffmpeg), FFMPEG_INCLUDE_DIR=str(ffmpeg / 'include'), FFMPEG_LIB_DIR=str(ffmpeg / 'lib'),
    LIBCLANG_PATH=str(ROOT / '.tools/python-libclang/clang/native'), CARGO_BUILD_JOBS='1',
    TEMP=str(ROOT / 'target/ci-policy-validation-tmp'), TMP=str(ROOT / 'target/ci-policy-validation-tmp'),
    MOTION_TRACKED_RPC_DIR=str(OUT), MOTION_TRACKED_SURFACE_ARTIFACTS=str(OUT / 'surface'))
env['PATH'] = str(ffmpeg / 'bin') + os.pathsep + env['PATH']
save()
try:
    for label, command in commands:
        with (OUT/f'{label}.stdout.log').open('wb') as stdout, (OUT/f'{label}.stderr.log').open('wb') as stderr:
            child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
            report.update(phase=label,childPid=child.pid); save()
            code=child.wait()
        report['results'].append(dict(phase=label,exitCode=code)); save()
        assert all(hashlib.sha256((WORK/p).read_bytes()).hexdigest()==h for p,h in source.items()), 'source changed during validation'
        assert code==0,(label,code)
        if label=='tests':
            assert '3 passed; 0 failed' in (OUT/'tests.stdout.log').read_text(encoding='utf-8')
        if label=='surface':
            assert '1 passed; 0 failed; 0 ignored' in (OUT/'surface.stdout.log').read_text(encoding='utf-8')
            report['surface'] = json.loads((OUT/'surface/report.json').read_text(encoding='utf-8'))
            report['surfaceChild'] = json.loads((OUT/'surface/child-process.json').read_text(encoding='utf-8'))
    binary=ROOT/'target/gltf-animation87-contract/debug/motion-studio.exe'
    report.update(status='focused_controls_and_native_binary_build_passed',binarySha256=hashlib.sha256(binary.read_bytes()).hexdigest())
except BaseException as cause:
    report.update(status='failed',failure=repr(cause)); raise
finally:
    report['completedUtc']=datetime.now(timezone.utc).isoformat(); save()


