from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-import88'
helper = root / '.tools/issue-closure-review'
build_dir = root / 'artifacts/pr-queue/tracking88-mcp-time-build-v1'
wire_dir = root / 'artifacts/pr-queue/tracking88-mcp-time-wire-v1'
build = json.loads((build_dir / 'exit.json').read_text(encoding='utf-8'))
wire = json.loads((wire_dir / 'exit.json').read_text(encoding='utf-8'))
assert build['status'] == 'focused_controls_and_native_binary_build_passed'
assert wire['status'] == 'native_stdio_workflow_default_logs_history_and_reopen_passed'
assert len(wire['checks']) == 10 and all(result['exitCode'] == 0 for result in build['results'])
sha = lambda data: hashlib.sha256(data).hexdigest()
assert build['source'] == wire['source']
assert all(sha((work / path).read_bytes()) == digest for path, digest in build['source'].items())
assert sha((root / 'target/gltf-animation87-contract/debug/motion-studio.exe').read_bytes()) == build['binarySha256'] == wire['binarySha256']
git = lambda *args: subprocess.check_output(['git', *args], cwd=work)
assert not git('diff', '--name-only', '--diff-filter=U')
assert not git('diff', '--name-only', 'origin/main', '--', 'desktop/app/src/panels')
staged_tree = git('write-tree').decode().strip()
crate_trees = {}
for name in ['motion-model', 'motion-core', 'motion-host', 'motion-media', 'motion-render']:
    path = f'crates/{name}'
    parent = git('rev-parse', build['integratedParent'] + ':' + path).decode().strip()
    current = git('rev-parse', staged_tree + ':' + path).decode().strip()
    assert parent == current, name
    crate_trees[path] = current
source = {}
for path in (build_dir / 'source').rglob('*.rs'):
    relative = path.relative_to(build_dir / 'source').as_posix()
    current = (work / relative).read_bytes()
    staged = git('show', ':' + relative)
    assert current == path.read_bytes() and staged == current.replace(b'\r\n', b'\n')
    source[relative] = dict(rawSha256=sha(current), gitLfSha256=sha(staged))
members = {'publisher.py': Path(__file__).read_bytes()}
for directory in [build_dir, wire_dir]:
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in {'.py', '.rs', '.json', '.jsonl', '.log', '.png'}:
            members[directory.name + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
archive = work / 'engineering/validation/data/tracking88-mcp-clock-integration-v1.zip'
assert not archive.exists() and not archive.with_suffix('.json').exists()
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, data in sorted(members.items()):
        zipped.writestr(name, data)
with zipfile.ZipFile(archive) as zipped:
    assert set(zipped.namelist()) == set(members)
    for name, data in members.items():
        assert zipped.read(name) == data, name
receipt = dict(status='mcp_and_retained_surface_verified_on_integrated_layer_time_baseline',
    head=build['head'], integratedParent=build['integratedParent'], source=source,
    unchangedParentCrateTrees=crate_trees, binarySha256=build['binarySha256'],
    buildResults=build['results'], surface=build['surface'], surfaceChild=build['surfaceChild'], wireChecks=wire['checks'],
    editReplies=wire['editReplyCount'], readonlyReplies=wire['readonlyReplyCount'],
    limits=['Focused current-source tests and actual native protocol/window proof, not a fresh full desktop/workspace regression',
        'Parent full model/core/host results belong to #583; five unchanged crate trees are explicitly compared',
        'One synthetic camera/video Surface case, not every mapped clock or binding/lens combination',
        'Final-head cross-platform CI, photographed tracker quality and full #88/3D route remain incomplete',
        'Android is retired and excluded'],
    archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
        members={name: dict(bytes=len(data), sha256=sha(data)) for name, data in sorted(members.items())}))
archive.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
document = f'''# #88 MCP workflow on the integrated layer-time baseline

PR #584 integrates parent #583 `{build['integratedParent']}` without textual
conflicts. Main's layer-time behavior and paired video/solve replacement both
remain present. No new product behavior, UI, dependency or asset is authored.
The entire staged model, core, host, media and render crate trees equal that
parent byte for byte; their Git tree IDs are recorded in the receipt. The parent's
1060-pass/one-existing-ignore result is historical evidence for that parent and
its unchanged crates, not a newly executed full desktop regression for this PR.

## Current-source native verification

- Three existing MCP replacement tests passed, including actual asynchronous
  preparation, wrong-original refusal, cancellation, atomic publication/history
  and the fixture used by the independent stdio test
- One actual Windows Surface test passed, zero failed/ignored, exercising the
  native video decoder, successful Present, retained-front pixel identity,
  invalidation/reuse counters, refusal, replacement, undo/redo and fresh reopen
- The FFmpeg-enabled desktop executable built successfully; its SHA-256 is
  `{build['binarySha256']}`
- That exact executable passed all ten existing stdio workflow controls via real
  pipes and a separately opened read-only process

The wire controls verify five advertised actions; stale/unknown-field rejection;
cancel/release without author edits; native ready preparation without publication;
wrong-original/document-generation rejection; one-revision stable-ID commit;
atomic undo/redo/save; default Info starts, original Error in both file and stderr
with every stdout line valid JSON-RPC; fresh-process saved-project reopening;
and read-only mutation denial with status dispatch still available. MOTION_LOG
is unset. Existing assertions and protocol/product behavior remain unchanged.

The Surface uses a real hidden native window, its owner-thread event loop and
the committed scratch front. It does not prove physical display scanout or all
codec, lens, point/plane or mapped-clock combinations. The separate native
footage-clock and paired/audio controls remain in the parent's evidence.

All Rust, shader and Cargo source hashes stayed frozen across the commands and
stdio process. Six relevant desktop source snapshots match staged LF-normalized
Git blobs. The [receipt](data/tracking88-mcp-clock-integration-v1.json) and
[member-by-member verified archive](data/tracking88-mcp-clock-integration-v1.zip)
retain command results, current-source hashes, actual process exits, native
images/counters, JSON-RPC streams and default logs. No panel differs from main.

## Remaining boundaries

This is a focused current-source acceptance. The previous 1542-pass full desktop
package belongs to `52ce7ebf`; it is not repeated or relabeled as this source's
full regression. Earlier native access violations remain unexplained. Final-head
cross-platform CI, full maintained regression, photographed planar-tracker
quality and full #88/3D-route acceptance remain separate work. Android is retired
and excluded. No GitHub PR merge or issue closure is implied by these results.
'''
(work / 'engineering/validation/tracking88-mcp-clock-integration-current.md').write_text(document, encoding='utf-8')
existing = work / 'engineering/validation/tracking88-mcp-replacement-current.md'
text = existing.read_text(encoding='utf-8')
assert '## Current layer-time baseline integration' not in text
text += '''\n\n## Current layer-time baseline integration\n\nThe [fresh integration record](tracking88-mcp-clock-integration-current.md) covers\nparent #583 and main's layer-time baseline, with newly executed MCP, actual\nretained-Surface and real stdio workflow controls on that frozen source. Earlier\nresults above keep their original source/scope; they are not final-head full\nregression claims.\n'''
existing.write_text(text, encoding='utf-8')
index = work / 'engineering/validation/tracking88-acceptance-map-current.md'
text = index.read_text(encoding='utf-8')
old = 'PRs #580 and #581 are formal increments with passing required CI. #582 is the'
assert old in text
text = text.replace(old, 'PRs #580 and #581 are formal increments. Their earlier heads passed required CI;\nthe updated parent/main integration heads require fresh checks. #582 is the')
text += '''\n\n## Layer-time baseline synchronization\n\nThe root [main integration](tracking88-root-main-integration-current.md), native\n[footage clock combinations](tracking88-video-clock-current.md), [paired edit\nhistory](tracking88-pair-clock-integration-current.md), and [MCP/native Surface\nworkflow](tracking88-mcp-clock-integration-current.md) record the synchronized\nsource and their newly executed gates. PR #583's frozen source passed 1060 tests\nwith one existing manual ignore; PR #584 separately re-executed three MCP tests,\none actual Surface test, and ten actual executable stdio controls. Five complete\ncrate trees are identical to #583, with their Git identities recorded. These\nresults do not constitute a new full desktop/workspace run or final-head\ncross-platform CI pass. The full 3D route and issue #88 remain incomplete.\n'''
index.write_text(text, encoding='utf-8')
body = f'''现有联合替换事务只可通过后端媒体请求调用，MCP 无法准备新原片并提交匹配解算。本 PR 增加 `tracked_video_replacement` 工具，将准备、状态查询、联合提交、取消和释放接入现有串行 worker，并补充实际预览缓存验收。

基于 #583，关联 #88，不关闭该 issue。本次同步父提交 `{build['integratedParent'][:8]}`，包含主分支图层时钟；没有新增产品、panels 或既有断言改动。

- 准备时检查修订、document generation、活动手势及跟踪资源，只启动媒体任务
- 提交时复用原片 SHA、真实解码尺寸、精确 PTS、全部解算与绑定校验，保留一次撤销与保存边界
- 限制输入及资源数量，拒绝未知字段和重复解算；只读会话仅允许状态查询
- 默认记录非 Present 开始，错误写文件与 stderr，stdio 仅输出 JSON-RPC

本次冻结整合源码的验证：

- MCP 专项 3 项通过，含真实异步导入、错误原片拒绝、一次修订及撤销重做
- 实际 Windows Surface 专项 1 项通过、0 ignored；验证保留画面、失效及复用计数、替换、历史与重开
- FFmpeg 可执行程序构建通过；该程序的 10 项真实 stdio 控制全部通过，覆盖取消、权限、保存重开与默认日志及 stdout 隔离
- 模型、核心、host、media、render 的完整 Git 子树与父提交完全相同；父提交 1060 项通过的记录保留原范围，不计为本 PR 新跑的全量桌面结果
- 源码哈希保持不变，归档成员逐项回读；provenance 和 panels 差异另行核验

[当前源码验收](https://github.com/MAD-Producer/Kilonova/blob/codex/88-tracking-replacement-mcp/engineering/validation/tracking88-mcp-clock-integration-current.md)、[工作流及历史证据](https://github.com/MAD-Producer/Kilonova/blob/codex/88-tracking-replacement-mcp/engineering/validation/tracking88-mcp-replacement-current.md)。

本轮未重新运行完整 desktop/workspace，最新提交跨平台 CI 待完成。旧源码 `52ce7ebf` 的完整 package 1542 通过、50 项既有 ignored 属于历史结果；此前原生崩溃根因仍未知。当前 Surface 是一组真实窗口控制，未证明所有时钟、绑定及镜头组合；#582 实拍质量及完整 #88/3D 路线仍未完成。

不新增 UI、依赖、第三方素材、自动追踪或转码。Android 停维，不在验收范围。
'''
(helper / 'tracking88-mcp-clock-integration-pr-body.md').write_text(body, encoding='utf-8')
(helper / 'tracking88-mcp-clock-integration-commit.txt').write_text('''test(tracking): 同步联合替换基线并验证原生协议与窗口缓存

- 整合主分支图层时钟及父分支原片解算事务
- 复核实际协议取消权限与原子历史保存重开
- 验证原生窗口保留画面及默认日志输出隔离
- 归档冻结源码身份和独立验收范围
''', encoding='utf-8')
print(json.dumps(dict(status=receipt['status'], wireChecks=len(wire['checks']), archiveBytes=archive.stat().st_size,
    members=len(members)), indent=2), flush=True)
