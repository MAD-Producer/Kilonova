"""Real same-weight Conv/ConvTranspose/Erf fixtures, with all earlier controls."""
from pathlib import Path
from datetime import datetime, timezone
import copy
import hashlib
import json
import logging
import math
import os
import shutil
import sys
import time
import traceback

ROOT=Path('E:/Dev/aem')
ART=ROOT/'artifacts/pr-queue'
MODEL=ROOT/'.tools/ai-depth74/models/depth_anything_v2_vits_518.onnx'
OUT=ART/'depth75-convolution-fixtures-v1'
OLD=ART/'depth75-operator-fixtures-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
previous=json.loads((ART/'depth75-operators-v3/receipt.json').read_text())
assert previous['status']=='selected_operator_tests_and_numerics_passed' and previous['sourceUnchanged']
request=json.loads((OLD/'request.json').read_text())
assert sha(MODEL)==request['model_sha256']
OUT.mkdir(exist_ok=False);(OUT/'tensors').mkdir()
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
logger=logging.getLogger('depth75-convolution-fixtures');logger.setLevel(logging.INFO)
sink=logging.FileHandler(OUT/'research.log',encoding='utf-8')
sink.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'));logger.addHandler(sink)
errors=logging.StreamHandler(sys.stderr);errors.setLevel(logging.ERROR);errors.setFormatter(sink.formatter);logger.addHandler(errors)
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),pid=os.getpid(),phases=[],
            modelSha256=request['model_sha256'],
            limits=['Selected real operators plus independent controls; no composed WGSL inference',
                    'Original model, prior case bytes and numerical tolerances unchanged',
                    'No model, weight or tensor payload is published'])
def phase(name):
    report['phase']=name;report['phases'].append(dict(name=name,utc=datetime.now(timezone.utc).isoformat()))
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    logger.info('start request=75 operation=%s',name);sink.flush()
began=time.monotonic()
try:
    phase('load_explicit_existing_cpu_reference')
    os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='')
    import numpy as np
    import onnx
    import onnxruntime as ort
    model=onnx.load(str(MODEL),load_external_data=False)
    initializers={t.name:t for t in model.graph.initializer}
    inventory=json.loads((ART/'depth75-static-model-audit-v3/tensor-inventory.json').read_text())
    metadata={row['name']:row for node in inventory for row in node['outputs']}
    selected=[(i,n) for i,n in enumerate(model.graph.node) if n.op_type in ('Conv','ConvTranspose','Erf')]
    assert len(selected)==45
    assert {kind:sum(n.op_type==kind for _,n in selected) for kind in ('Conv','ConvTranspose','Erf')}=={'Conv':31,'ConvTranspose':2,'Erf':12}
    needed={name for _,node in selected for name in list(node.input)+list(node.output)
            if name and name not in initializers and name!='rgb'}
    augmented=copy.deepcopy(model)
    existing={o.name for o in augmented.graph.output}
    for name in sorted(needed-existing):
        d=metadata[name];assert d['dtype']=='FLOAT' and len(d['shape'])<=4
        augmented.graph.output.append(onnx.helper.make_tensor_value_info(name,onnx.TensorProto.FLOAT,d['shape']))
    onnx.checker.check_model(augmented)
    rng=np.random.default_rng(75);y,x=np.indices((518,518),dtype=np.float32)
    rgb=np.stack((x/517.,y/517.,(x+y)/1034.),axis=-1)
    rgb=np.clip(rgb+rng.uniform(-.03,.03,rgb.shape).astype(np.float32),0.,1.)
    image=((rgb-np.array([.485,.456,.406],np.float32))/np.array([.229,.224,.225],np.float32)).transpose(2,0,1)[None].copy()
    prior=json.loads((OLD/'receipt.json').read_text())
    assert hashlib.sha256(image.astype('<f4').tobytes()).hexdigest()==prior['authoredInputSha256']
    phase('create_cpu_session_and_run_original_same_weight_model')
    options=ort.SessionOptions();options.intra_op_num_threads=1;options.inter_op_num_threads=1
    options.log_severity_level=3;options.graph_optimization_level=ort.GraphOptimizationLevel.ORT_DISABLE_ALL
    session=ort.InferenceSession(augmented.SerializeToString(),sess_options=options,providers=['CPUExecutionProvider'])
    assert session.get_providers()==['CPUExecutionProvider']
    names=sorted(needed|existing)
    values=dict(zip(names,session.run(names,{'rgb':image})));values['rgb']=image
    assert all(v.dtype==np.float32 and np.isfinite(v).all() for v in values.values())
    assert hashlib.sha256(values['relative_inverse_depth'].astype('<f4').tobytes()).hexdigest()==prior['finalDepthSha256']
    report.update(providers=session.get_providers(),versions=dict(numpy=np.__version__,onnx=onnx.__version__,onnxruntime=ort.__version__),
                  authoredInputSha256=prior['authoredInputSha256'],finalDepthSha256=prior['finalDepthSha256'])
    phase('retain_real_operator_inputs_weights_references')
    for c in request['cases']:
        for t in c['inputs']+[c['expected']]:
            src=OLD/t['file'];dst=OUT/t['file']
            assert sha(src)==t['sha256']
            if not dst.exists():shutil.copyfile(src,dst)
            assert sha(dst)==t['sha256']
    def write(name,array):
        array=np.asarray(array,dtype=np.float32);assert array.ndim<=4 and np.isfinite(array).all()
        raw=np.ascontiguousarray(array,dtype='<f4').tobytes();digest=hashlib.sha256(raw).hexdigest()
        p=OUT/'tensors'/(digest+'.f32')
        if not p.exists():p.write_bytes(raw)
        assert sha(p)==digest
        return dict(name=name,dtype='float32',shape=list(array.shape),file=p.relative_to(OUT).as_posix(),sha256=digest)
    def tensor(name):return write(name,onnx.numpy_helper.to_array(initializers[name]) if name in initializers else values[name])
    for index,node in selected:
        attrs={a.name:onnx.helper.get_attribute_value(a) for a in node.attribute}
        operation=dict(kind=node.op_type)
        if node.op_type!='Erf':
            assert attrs.get('auto_pad',b'NOTSET')==b'NOTSET' and 'output_shape' not in attrs
            operation['attributes']=dict(kernel=attrs['kernel_shape'],stride=attrs['strides'],padding=attrs['pads'],
                                         dilation=attrs['dilations'],group=attrs['group'],output_padding=attrs.get('output_padding',[0,0]))
        request['cases'].append(dict(id=f'model-{index}-{node.op_type.lower()}',origin='same_model_intermediate',source_node=node.name,
            operation=operation,inputs=[tensor(n) for n in node.input if n],expected=tensor(node.output[0])))
    phase('author_independent_convolution_and_erf_controls')
    def control(name,op,arrays,reference):
        request['cases'].append(dict(id=name,origin='authored_control',source_node=None,operation=op,
            inputs=[write(f'{name}-input-{i}',a) for i,a in enumerate(arrays)],expected=write(name+'-reference',reference)))
    for label,shape,co,kernel,stride,pads,biased in [
        ('rectangular-bias',(2,3,5,7),4,(3,2),(2,1),(1,2,0,1),True),
        ('rectangular-no-bias',(2,3,5,7),4,(3,2),(2,1),(1,2,0,1),False),
        ('patch14',(1,2,31,29),3,(14,14),(14,14),(0,0,0,0),True)]:
        n,ci,h,w=shape;kh,kw=kernel;sh,sw=stride;top,left,bottom,right=pads
        a=rng.uniform(-2,2,shape).astype(np.float32);weights=rng.uniform(-1,1,(co,ci,kh,kw)).astype(np.float32)
        bias=rng.uniform(-1,1,co).astype(np.float32);oh=(h+top+bottom-kh)//sh+1;ow=(w+left+right-kw)//sw+1
        ref=np.zeros((n,co,oh,ow),np.float64)
        for oy in range(oh):
            for ox in range(ow):
                for ky in range(kh):
                    iy=oy*sh+ky-top
                    if not 0<=iy<h:continue
                    for kx in range(kw):
                        ix=ox*sw+kx-left
                        if not 0<=ix<w:continue
                        ref[:,:,oy,ox]+=a[:,:,iy,ix].astype(np.float64)@weights[:,:,ky,kx].astype(np.float64).T
        if biased:ref+=bias[None,:,None,None]
        attrs=dict(kernel=list(kernel),stride=list(stride),padding=list(pads),dilation=[1,1],group=1,output_padding=[0,0])
        control('control-conv-'+label,dict(kind='Conv',attributes=attrs),[a,weights]+([bias] if biased else []),ref)
    for k in (2,4):
        a=rng.uniform(-2,2,(2,3,5,7)).astype(np.float32);weights=rng.uniform(-1,1,(3,4,k,k)).astype(np.float32)
        bias=rng.uniform(-1,1,4).astype(np.float32);ref=np.zeros((2,4,5*k,7*k),np.float64)
        for ky in range(k):
            for kx in range(k):
                ref[:,:,ky::k,kx::k]=np.einsum('nchw,co->nohw',a.astype(np.float64),weights[:,:,ky,kx].astype(np.float64))
        ref+=bias[None,:,None,None]
        attrs=dict(kernel=[k,k],stride=[k,k],padding=[0,0,0,0],dilation=[1,1],group=1,output_padding=[0,0])
        control(f'control-transpose-{k}',dict(kind='ConvTranspose',attributes=attrs),[a,weights,bias],ref)
    special=np.array([0.,-0.,1e-45,-1e-45,1e-20,-1e-20,.49999997,.5,.50000006,-.49999997,-.5,-.50000006,
                      5.9999995,6.,6.0000005,-5.9999995,-6.,-6.0000005,20.,-20.,1e20,-1e20,np.finfo(np.float32).max,-np.finfo(np.float32).max],np.float32)
    arguments=np.concatenate((np.linspace(-6,6,20001,dtype=np.float32),special))
    ref=np.fromiter((math.erf(float(v)) for v in arguments),np.float64,count=len(arguments))
    control('control-erf-boundaries',dict(kind='Erf'),[arguments],ref)
    assert len(request['cases'])==85 and len({c['id'] for c in request['cases']})==85
    (OUT/'request.json').write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8')
    report.update(status='same_weight_reference_fixtures_generated_wgsl_comparison_pending',requestSha256=sha(OUT/'request.json'),
        selectedNodes=prior['selectedNodes']+[dict(index=i,name=n.name,operation=n.op_type) for i,n in selected],
        outputCounts=dict(cases=85,sameModelCases=58,authoredControls=27,rawFiles=len(list((OUT/'tensors').glob('*.f32')))),
        declaredComparisonBounds=prior['declaredComparisonBounds'],
        additionalErfMaximumAbsolute=1e-6,modelUnchanged=sha(MODEL)==request['model_sha256'],
        elapsedSeconds=round(time.monotonic()-began,3),completedUtc=datetime.now(timezone.utc).isoformat())
    assert report['modelUnchanged'];phase('completed')
except BaseException as cause:
    report.update(status='reference_fixture_generation_failed_original_cause_retained',failure=repr(cause),traceback=traceback.format_exc(),completedUtc=datetime.now(timezone.utc).isoformat())
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    logger.error('reference fixture generation failed phase=%s cause=%s',report.get('phase'),repr(cause)[:4096]);raise
