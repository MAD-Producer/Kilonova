//! Standalone numerical research. No model inference backend is installed.
mod admission;
mod convolution_admission;
mod logging;

use admission::{Case, Request, Result, Tensor};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    collections::HashMap,
    fs,
    io::Read,
    path::{Component, Path, PathBuf},
    time::Instant,
};
use wgpu::util::DeviceExt;

// Reuse the application's unchanged logger and panic hook with a real local
// operation context. The probe is single-threaded; no business locks are held.
mod engine {
    use std::{
        cell::RefCell,
        time::{Duration, Instant},
    };
    thread_local! { static CURRENT: RefCell<Option<(u64, &'static str, Instant)>> = const { RefCell::new(None) }; }
    pub fn current_command() -> Option<(u64, &'static str, Duration)> {
        CURRENT.with(|slot| {
            slot.try_borrow().ok().and_then(|v| {
                v.as_ref()
                    .map(|(id, op, start)| (*id, *op, start.elapsed()))
            })
        })
    }
    pub struct Flight {
        previous: Option<(u64, &'static str, Instant)>,
        entered: bool,
    }
    pub fn enter(id: u64, operation: &'static str) -> Flight {
        CURRENT.with(|slot| {
            if let Ok(mut v) = slot.try_borrow_mut() {
                Flight {
                    previous: v.replace((id, operation, Instant::now())),
                    entered: true,
                }
            } else {
                Flight {
                    previous: None,
                    entered: false,
                }
            }
        })
    }
    impl Drop for Flight {
        fn drop(&mut self) {
            if !self.entered {
                return;
            }
            CURRENT.with(|slot| {
                if let Ok(mut v) = slot.try_borrow_mut() {
                    *v = self.previous.take();
                }
            });
        }
    }
}
fn digest(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}
fn require(ok: bool, reason: &str) -> Result<()> {
    if ok { Ok(()) } else { Err(reason.into()) }
}
fn limited_read(path: &Path, maximum: u64) -> Result<Vec<u8>> {
    let file = fs::File::open(path).map_err(|e| format!("open {}: {e}", path.display()))?;
    require(
        file.metadata().map_err(|e| e.to_string())?.len() <= maximum,
        "input exceeds declared byte bound",
    )?;
    let mut data = Vec::new();
    file.take(maximum + 1)
        .read_to_end(&mut data)
        .map_err(|e| e.to_string())?;
    require(
        data.len() as u64 <= maximum,
        "input grew beyond declared byte bound",
    )?;
    Ok(data)
}
fn tensor_bytes(root: &Path, tensor: &Tensor) -> Result<Vec<u8>> {
    let relative = Path::new(&tensor.file);
    require(
        !relative.is_absolute()
            && relative
                .components()
                .all(|p| matches!(p, Component::Normal(_))),
        "tensor path must stay within fixture root",
    )?;
    let path = root
        .join(relative)
        .canonicalize()
        .map_err(|e| format!("tensor {}: {e}", tensor.name))?;
    require(
        path.starts_with(root),
        "tensor canonical path escapes fixture root",
    )?;
    let bytes = limited_read(&path, tensor.bytes()?)?;
    require(
        bytes.len() as u64 == tensor.bytes()? && digest(&bytes) == tensor.sha256,
        "tensor length or SHA-256 mismatch",
    )?;
    require(
        bytes
            .chunks_exact(4)
            .all(|v| f32::from_le_bytes([v[0], v[1], v[2], v[3]]).is_finite()),
        "tensor contains nonfinite Float32 values",
    )?;
    Ok(bytes)
}
fn save(out: &Path, report: &Value) -> Result<()> {
    fs::write(
        out.join("receipt.json"),
        serde_json::to_vec_pretty(report).map_err(|e| e.to_string())?,
    )
    .map_err(|e| format!("write observation receipt: {e}"))
}
fn phase(out: &Path, report: &mut Value, name: &str) -> Result<()> {
    report["phase"] = name.into();
    if let Some((request, operation, elapsed)) = engine::current_command() {
        report["in_flight"] =
            json!({"request":request,"operation":operation,"elapsed_ms":elapsed.as_millis()});
    }
    log::info!(
        "phase={name} request={} operation={}",
        report["request"],
        report["operation"]
    );
    logging::flush();
    save(out, report)
}
fn gpu_buffers(
    device: &wgpu::Device,
    inputs: &[Vec<u8>],
    output_size: u64,
    parameters: &[u32; 16],
) -> (Vec<wgpu::Buffer>, wgpu::Buffer, wgpu::Buffer, wgpu::Buffer) {
    let mut buffers: Vec<_> = inputs
        .iter()
        .map(|bytes| {
            device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: Some("depth research input"),
                contents: bytes,
                usage: wgpu::BufferUsages::STORAGE,
            })
        })
        .collect();
    while buffers.len() < 3 {
        buffers.push(
            device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: Some("unused depth research binding"),
                contents: &[0; 4],
                usage: wgpu::BufferUsages::STORAGE,
            }),
        );
    }
    let output = device.create_buffer(&wgpu::BufferDescriptor {
        label: Some("depth research output"),
        size: output_size,
        usage: wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_SRC,
        mapped_at_creation: false,
    });
    let readback = device.create_buffer(&wgpu::BufferDescriptor {
        label: Some("depth research readback"),
        size: output_size,
        usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
        mapped_at_creation: false,
    });
    let params = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
        label: Some("depth research parameters"),
        contents: bytemuck::cast_slice(parameters),
        usage: wgpu::BufferUsages::UNIFORM,
    });
    (buffers, output, readback, params)
}
fn execute_case(
    device: &wgpu::Device,
    queue: &wgpu::Queue,
    layout: &wgpu::BindGroupLayout,
    pipeline: &wgpu::ComputePipeline,
    case: &Case,
    root: &Path,
    out: &Path,
    report: &mut Value,
    budget: u64,
) -> Result<Value> {
    let began = Instant::now();
    let plan = case.plan(&device.limits(), budget)?;
    phase(out, report, "read_hashed_finite_tensors")?;
    let inputs: Vec<_> = case
        .inputs
        .iter()
        .map(|t| tensor_bytes(root, t))
        .collect::<Result<_>>()?;
    // The reference is checked but never uploaded as a GPU input or substituted
    // for the output. The independent comparator runs after this process exits.
    let reference = tensor_bytes(root, &case.expected)?;
    drop(reference);
    let input_seconds = began.elapsed().as_secs_f64();
    phase(out, report, "allocate_and_upload")?;
    let oom = device.push_error_scope(wgpu::ErrorFilter::OutOfMemory);
    let validation = device.push_error_scope(wgpu::ErrorFilter::Validation);
    let (inputs, output, readback, parameters) =
        gpu_buffers(device, &inputs, plan.output_bytes, &plan.parameters);
    let group = device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some("depth research bindings"),
        layout,
        entries: &[
            wgpu::BindGroupEntry {
                binding: 0,
                resource: inputs[0].as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 1,
                resource: inputs[1].as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 2,
                resource: inputs[2].as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 3,
                resource: output.as_entire_binding(),
            },
            wgpu::BindGroupEntry {
                binding: 4,
                resource: parameters.as_entire_binding(),
            },
        ],
    });
    phase(out, report, "submit_and_map")?;
    let submitted = Instant::now();
    let mut encoder = device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
        label: Some("depth research operator"),
    });
    {
        let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
            label: Some("depth research compute"),
            timestamp_writes: None,
        });
        pass.set_pipeline(pipeline);
        pass.set_bind_group(0, &group, &[]);
        pass.dispatch_workgroups(plan.dispatch[0], plan.dispatch[1], plan.dispatch[2]);
    }
    encoder.copy_buffer_to_buffer(&output, 0, &readback, 0, plan.output_bytes);
    queue.submit([encoder.finish()]);
    let (send, receive) = std::sync::mpsc::sync_channel(1);
    readback
        .slice(..)
        .map_async(wgpu::MapMode::Read, move |result| {
            let _ = send.send(result);
        });
    let polled = device.poll(wgpu::PollType::wait_indefinitely());
    let validation_cause = pollster::block_on(validation.pop());
    let oom_cause = pollster::block_on(oom.pop());
    if let Err(cause) = polled {
        return Err(format!(
            "device poll: {cause}; validation={validation_cause:?}; allocation={oom_cause:?}"
        ));
    }
    if validation_cause.is_some() || oom_cause.is_some() {
        return Err(format!(
            "GPU operator refused: validation={validation_cause:?}; allocation={oom_cause:?}"
        ));
    }
    receive
        .recv()
        .map_err(|e| format!("readback callback closed: {e}"))?
        .map_err(|e| format!("readback mapping: {e}"))?;
    let view = readback
        .slice(..)
        .get_mapped_range()
        .map_err(|e| format!("mapped view: {e}"))?;
    let pixels = view.to_vec();
    drop(view);
    readback.unmap();
    let submit_map_seconds = submitted.elapsed().as_secs_f64();
    require(
        pixels.len() as u64 == plan.output_bytes,
        "readback output length differs",
    )?;
    require(
        pixels
            .chunks_exact(4)
            .all(|v| f32::from_le_bytes([v[0], v[1], v[2], v[3]]).is_finite()),
        "GPU output contains nonfinite values",
    )?;
    phase(out, report, "write_actual_gpu_output")?;
    fs::write(out.join(format!("{}.f32", case.id)), &pixels)
        .map_err(|e| format!("write GPU output: {e}"))?;
    Ok(
        json!({"id":case.id,"origin":case.origin,"source_node":case.source_node,"operation":plan.entry,"output_sha256":digest(&pixels),"output_bytes":pixels.len(),
        "logical_buffer_bytes":plan.admitted_buffer_bytes,"dispatch":plan.dispatch,
        "read_and_hash_seconds":input_seconds,"submit_through_map_seconds":submit_map_seconds,
        "wall_seconds":began.elapsed().as_secs_f64(),"numerical_comparison":"pending independent comparator",
        "timing_limit":"One cold operator wall observation including submit/readback; not GPU timestamps or an inference latency baseline"}),
    )
}
fn run(request_path: &Path, out: &Path, report: &mut Value) -> Result<()> {
    require(
        cfg!(target_endian = "little"),
        "probe requires explicit little-endian Float32 storage",
    )?;
    let raw = limited_read(request_path, 512 * 1024)?;
    let request: Request =
        serde_json::from_slice(&raw).map_err(|e| format!("request schema: {e}"))?;
    request.validate()?;
    report["request_sha256"] = digest(&raw).into();
    report["model_sha256"] = request.model_sha256.clone().into();
    report["requested_backend"] = request.requested_backend.clone().into();
    let root = request_path
        .parent()
        .ok_or("request parent missing")?
        .canonicalize()
        .map_err(|e| e.to_string())?;
    let backend = match request.requested_backend.as_str() {
        "vulkan" => wgpu::Backends::VULKAN,
        "dx12" => wgpu::Backends::DX12,
        "metal" => wgpu::Backends::METAL,
        _ => return Err("unsupported explicit backend".into()),
    };
    phase(out, report, "create_instance_request_adapter")?;
    let instance = wgpu::Instance::new(wgpu::InstanceDescriptor {
        backends: backend,
        ..wgpu::InstanceDescriptor::new_without_display_handle()
    });
    let adapter = pollster::block_on(instance.request_adapter(&wgpu::RequestAdapterOptions {
        power_preference: wgpu::PowerPreference::HighPerformance,
        force_fallback_adapter: false,
        compatible_surface: None,
        ..Default::default()
    }))
    .map_err(|e| format!("adapter requested={}: {e}", request.requested_backend))?;
    let info = adapter.get_info();
    require(
        info.device_type != wgpu::DeviceType::Cpu,
        "software adapter is not admitted as hardware GPU evidence",
    )?;
    require(
        wgpu::Backends::from(info.backend) == backend,
        "resolved backend differs from explicit request",
    )?;
    report["adapter"] = json!({"name":info.name,"vendor":info.vendor,"device":info.device,"device_type":format!("{:?}",info.device_type),
        "backend":format!("{:?}",info.backend),"driver":info.driver,"driver_info":info.driver_info});
    phase(out, report, "request_device")?;
    let limits = wgpu::Limits::downlevel_defaults().using_resolution(adapter.limits());
    let (device, queue) = pollster::block_on(adapter.request_device(&wgpu::DeviceDescriptor {
        label: Some("depth operator research"),
        required_features: wgpu::Features::empty(),
        required_limits: limits,
        ..Default::default()
    }))
    .map_err(|e| format!("device request: {e}"))?;
    let limits = device.limits();
    require(
        limits.max_storage_buffers_per_shader_stage >= 4
            && limits.max_uniform_buffers_per_shader_stage >= 1,
        "insufficient operator bindings",
    )?;
    report["device_limits"] = json!({"storage_binding_bytes":limits.max_storage_buffer_binding_size,"buffer_bytes":limits.max_buffer_size,
        "workgroup_storage_bytes":limits.max_compute_workgroup_storage_size,"workgroup_invocations":limits.max_compute_invocations_per_workgroup,
        "workgroups_per_dimension":limits.max_compute_workgroups_per_dimension});
    let entries: Vec<_> = (0..5)
        .map(|binding| wgpu::BindGroupLayoutEntry {
            binding,
            visibility: wgpu::ShaderStages::COMPUTE,
            ty: wgpu::BindingType::Buffer {
                ty: if binding == 4 {
                    wgpu::BufferBindingType::Uniform
                } else {
                    wgpu::BufferBindingType::Storage {
                        read_only: binding != 3,
                    }
                },
                has_dynamic_offset: false,
                min_binding_size: None,
            },
            count: None,
        })
        .collect();
    let layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
        label: Some("depth research layout"),
        entries: &entries,
    });
    let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("depth research pipeline layout"),
        bind_group_layouts: &[Some(&layout)],
        immediate_size: 0,
    });
    let mut pipelines = HashMap::new();
    for (index, case) in request.cases.iter().enumerate() {
        let plan = case
            .plan(&limits, request.buffer_budget_bytes)
            .map_err(|e| format!("case={} admission: {e}", case.id))?;
        let _flight = engine::enter(index as u64 + 1, plan.entry);
        report["request"] = (index as u64 + 1).into();
        report["operation"] = plan.entry.into();
        report["case"] = case.id.clone().into();
        log::info!("start #{} {} case={}", index + 1, plan.entry, case.id);
        logging::flush();
        if !pipelines.contains_key(plan.entry) {
            phase(out, report, "create_shader_pipeline")?;
            let oom = device.push_error_scope(wgpu::ErrorFilter::OutOfMemory);
            let validation = device.push_error_scope(wgpu::ErrorFilter::Validation);
            let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
                label: Some("depth research operators"),
                source: wgpu::ShaderSource::Wgsl(
                    match plan.entry {
                        "conv_nchw" | "conv_transpose_no_overlap_nchw" => {
                            include_str!("convolution.wgsl")
                        }
                        "erf_elementwise" => include_str!("erf.wgsl"),
                        _ => include_str!("operators.wgsl"),
                    }
                    .into(),
                ),
            });
            let pipeline = device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
                label: Some(plan.entry),
                layout: Some(&pipeline_layout),
                module: &shader,
                entry_point: Some(plan.entry),
                compilation_options: Default::default(),
                cache: None,
            });
            let validation_cause = pollster::block_on(validation.pop());
            let oom_cause = pollster::block_on(oom.pop());
            require(
                validation_cause.is_none() && oom_cause.is_none(),
                &format!(
                    "pipeline={} validation={validation_cause:?}; allocation={oom_cause:?}",
                    plan.entry
                ),
            )?;
            pipelines.insert(plan.entry, pipeline);
        }
        let result = execute_case(
            &device,
            &queue,
            &layout,
            &pipelines[plan.entry],
            case,
            &root,
            out,
            report,
            request.buffer_budget_bytes,
        )
        .map_err(|e| format!("case={} operation={}: {e}", case.id, plan.entry))?;
        report["cases"]
            .as_array_mut()
            .ok_or("invalid internal result array")?
            .push(result);
        phase(out, report, "case_done")?;
    }
    report["status"] = "gpu_outputs_written_independent_numerical_comparison_pending".into();
    report["phase"] = "completed".into();
    report["in_flight"] = Value::Null;
    if let Some((_, _, elapsed)) = engine::current_command() {
        report["elapsed_ms"] = json!(elapsed.as_millis());
        log::debug!("done #0 operator_probe {}ms", elapsed.as_millis());
    }
    save(out, report)
}
fn main() {
    let args: Vec<_> = std::env::args_os().collect();
    if args.len() != 3 {
        eprintln!(
            "usage: motion-depth-operator-probe <absolute-request.json> <new-absolute-output-directory>"
        );
        std::process::exit(2);
    }
    let request = PathBuf::from(&args[1]);
    let out = PathBuf::from(&args[2]);
    if !request.is_absolute() || !out.is_absolute() {
        eprintln!("absolute input/output paths required");
        std::process::exit(2);
    }
    if let Err(cause) = fs::create_dir(&out) {
        eprintln!(
            "create new observation directory {}: {cause}",
            out.display()
        );
        std::process::exit(2);
    }
    let _logger = match logging::init(out.join("logs")) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("initialize file logger: {e}");
            std::process::exit(2);
        }
    };
    let mut report = json!({"status":"running","pid":std::process::id(),"request":0,"operation":"admission","phase":"read_request","cases":[],
        "limits":["Numerical operator research only; no installed model backend or complete model execution",
            "Software adapters and implicit backend/precision fallback refused",
            "Logical buffer admission is not measured process/device memory",
            "External fixture identities are verified, not leased against concurrent filesystem mutation"]});
    let _flight = engine::enter(0, "operator_probe");
    log::info!("start #0 operator_probe");
    logging::flush();
    let began = Instant::now();
    if let Err(cause) =
        phase(&out, &mut report, "read_request").and_then(|()| run(&request, &out, &mut report))
    {
        log::error!(
            "operator research failed phase={} case={} elapsed_ms={} cause={cause}",
            report["phase"],
            report["case"],
            began.elapsed().as_millis()
        );
        report["status"] = "failed_original_cause_retained".into();
        report["failure"] = cause.into();
        report["elapsed_ms"] = json!(began.elapsed().as_millis());
        report["in_flight"] = Value::Null;
        if let Err(secondary) = save(&out, &report) {
            log::error!("failure receipt also unavailable: {secondary}");
        }
        logging::flush();
        std::process::exit(1);
    }
    logging::flush();
}
