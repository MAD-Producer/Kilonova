"""Independent, post-process comparison; no WGSL dispatch or reference generation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
import sys
import traceback

ROOT = Path('E:/Dev/aem')
FULL = ROOT / 'artifacts/pr-queue/tracking88-prototype-workspace-integration-v3/exit.json'
native = json.loads(FULL.read_text(encoding='utf-8'))
assert native['status'] != 'running' and 'completedUtc' in native, 'Original native gate must terminate first'
assert len(sys.argv) == 4, 'usage: comparator fixture-root gpu-output-root new-output-root'
FIXTURES = Path(sys.argv[1]).resolve(strict=True)
GPU = Path(sys.argv[2]).resolve(strict=True)
OUT = Path(sys.argv[3]).absolute()
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='running_independent_comparison', createdUtc=datetime.now(timezone.utc).isoformat(), cases=[],
              limits=['Selected operators only, not an end-to-end WGSL backend or temporal/performance qualification',
                      'Bounds fixed before GPU execution and not relaxed for measured results',
                      'Reference tensor scale is max(max(abs(reference)),1e-6); no output rescaling or affine fit',
                      'Authored mathematical edge controls and same-model intermediate results are reported separately'])
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')

save()
try:
    import numpy as np
    request_raw = (FIXTURES / 'request.json').read_bytes()
    request = json.loads(request_raw)
    fixtures = json.loads((FIXTURES / 'receipt.json').read_text())
    gpu = json.loads((GPU / 'receipt.json').read_text())
    assert fixtures['status'] == 'same_weight_reference_fixtures_generated_wgsl_comparison_pending'
    assert gpu['status'] == 'gpu_outputs_written_independent_numerical_comparison_pending'
    assert sha(request_raw) == gpu['request_sha256'] == fixtures['requestSha256']
    assert gpu['model_sha256'] == request['model_sha256'] == fixtures['modelSha256']
    bounds = fixtures['declaredComparisonBounds']
    assert bounds['maxNormalized'] == .0002 and bounds['meanNormalized'] == .00002
    assert fixtures['additionalErfMaximumAbsolute'] == 1e-6
    report.update(requestSha256=sha(request_raw),gpuReceiptSha256=sha((GPU/'receipt.json').read_bytes()),
                  fixtureReceiptSha256=sha((FIXTURES/'receipt.json').read_bytes()),bounds=bounds,adapter=gpu['adapter'])
    actual = {c['id']:c for c in gpu['cases']}
    assert len(actual) == len(gpu['cases']) == len(request['cases'])
    assert set(actual) == {c['id'] for c in request['cases']}

    def compare(reference, values):
        assert reference.size > 0 and values.shape == reference.shape
        assert np.isfinite(reference).all() and np.isfinite(values).all(), 'nonfinite data cannot pass'
        scale = max(float(np.max(np.abs(reference.astype(np.float64)))), 1e-6)
        error = np.abs(values.astype(np.float64)-reference.astype(np.float64))
        maximum = float(error.max()) / scale
        mean = float(error.mean()) / scale
        return dict(maxAbsolute=float(error.max()),meanAbsolute=float(error.mean()),normalizationScale=scale,
                    maxNormalized=maximum,meanNormalized=mean,worstFlatIndex=int(np.argmax(error)),
                    passed=maximum <= bounds['maxNormalized'] and mean <= bounds['meanNormalized'])

    # Prove the observer rejects finite corruption, NaNs and mismatched lengths.
    base = np.array([1.,2.,3.,4.],np.float32)
    assert compare(base,base)['passed']
    corrupt = base.copy(); corrupt[0] += 1.
    assert not compare(base,corrupt)['passed']
    for invalid in (np.array([1.,2.],np.float32),np.array([1.,np.nan,3.,4.],np.float32)):
        try: compare(base,invalid)
        except AssertionError: pass
        else: raise AssertionError('negative comparator control accepted')
    report['observerNegativeControls'] = ['finite_corruption_rejected','nonfinite_rejected','length_mismatch_rejected']

    for case in request['cases']:
        expected = case['expected']
        path = (FIXTURES / expected['file']).resolve(strict=True)
        assert path.is_relative_to(FIXTURES)
        raw = path.read_bytes()
        assert sha(raw) == expected['sha256'] and len(raw) == math.prod(expected['shape'])*4
        output = (GPU / (case['id']+'.f32')).read_bytes()
        entry = actual[case['id']]
        assert sha(output) == entry['output_sha256'] and len(output) == entry['output_bytes'] == len(raw)
        assert entry['origin'] == case['origin'] and entry['source_node'] == case['source_node']
        result = compare(np.frombuffer(raw,dtype='<f4'),np.frombuffer(output,dtype='<f4'))
        if case['operation']['kind']=='Erf':
            result['additionalMaximumAbsoluteBound']=fixtures['additionalErfMaximumAbsolute']
            result['passed']=result['passed'] and result['maxAbsolute'] <= fixtures['additionalErfMaximumAbsolute']
        report['cases'].append(dict(id=case['id'],origin=case['origin'],sourceNode=case['source_node'],
                                    operation=case['operation']['kind'],shape=expected['shape'],referenceSha256=sha(raw),
                                    actualSha256=sha(output),**result))
        save()
    report['totals'] = {origin:dict(cases=sum(c['origin']==origin for c in report['cases']),
                                    failed=sum(c['origin']==origin and not c['passed'] for c in report['cases']))
                        for origin in ('same_model_intermediate','authored_control')}
    report['status'] = 'selected_operator_numerics_passed' if all(c['passed'] for c in report['cases']) else 'selected_operator_numerics_failed_original_bounds_retained'
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps({k:v for k,v in report.items() if k!='cases'}))
    raise SystemExit(0 if report['status']=='selected_operator_numerics_passed' else 1)
except SystemExit:
    raise
except BaseException as cause:
    report.update(status='independent_observer_failed_original_outputs_retained',failure=repr(cause),traceback=traceback.format_exc())
    save()
    print('ERROR independent comparison: '+repr(cause),file=sys.stderr)
    raise
