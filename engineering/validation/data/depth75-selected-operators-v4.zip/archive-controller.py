"""Archive only a terminal successful selected-operator attempt, no weights."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.tools/ai-depth75/operator-probe'
ART=ROOT/'artifacts/pr-queue'
RUN=ART/'depth75-operators-v4'
FIXTURES=ART/'depth75-convolution-fixtures-v1'
OUT=ART/'depth75-operators-archive-v4'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((RUN/'receipt.json').read_text(encoding='utf-8'))
assert report['status']=='selected_operator_tests_and_numerics_passed' and report['sourceUnchanged'] and 'completedUtc' in report
assert all(sha(WORK/n)==digest for n,digest in report['source'].items())
comparison=json.loads((RUN/'comparison/receipt.json').read_text(encoding='utf-8'))
assert comparison['status']=='selected_operator_numerics_passed'
assert comparison['totals']['same_model_intermediate']=={'cases':58,'failed':0}
assert comparison['totals']['authored_control']=={'cases':27,'failed':0}
assert len(report['failureObservations'])==7 and report['defaultInfoStartVisible'] and report['stdoutEmpty']
OUT.mkdir(exist_ok=False)
files={'source/'+n:WORK/n for n in report['source']}
files['source/README.md']=WORK/'README.md'
files['archive-controller.py']=Path(__file__)
for name in ('controller.py','receipt.json','request.json','research.log'):
    p=FIXTURES/name
    if p.is_file():files['reference-fixtures/'+name]=p
for path in RUN.rglob('*'):
    if not path.is_file():continue
    relative=path.relative_to(RUN)
    if path.suffix in ('.json','.log','.py') and 'tensors' not in relative.parts and 'appdata' not in relative.parts:
        files['execution/'+relative.as_posix()]=path
for directory in ('depth75-operator-layouts-v1','depth75-convolution-layouts-v1','depth75-erf-math-v1'):
    for name in ('controller.py','receipt.json'):
        files['separate-static-and-math/'+directory+'/'+name]=ART/directory/name
files['previous-four-family-qualification-manifest.json']=ART/'depth75-operators-archive-v3/manifest.json'
files['independent-comparison-controller.py']=ROOT/'.tools/issue-closure-review/compare-depth75-convolution-outputs-v1.py'
entries={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(files.items())}
archive=OUT/'depth75-selected-operators-v4.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(files.items()):z.writestr(name,path.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(entries)
    for name,entry in entries.items():
        raw=z.read(name); assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
manifest=dict(status='successful_selected_operator_attempt_archived_readback_verified',createdUtc=datetime.now(timezone.utc).isoformat(),
              archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),entries=entries,
              numericalTotals=comparison['totals'],adapter=comparison['adapter'],
              defaultInfoStartVisible=True,errorFileAndStderrFailures=7,stdoutEmpty=True,
              limits=['Seven numerical operator families only, not a shipped backend or complete model output',
                      'All31Conv/2ConvTranspose/12Erf nodes compared independently; no composed graph execution is established',
                      'Model weights, RGB, learned activations, reference/GPU raw tensors, binaries and optional runtimes are excluded',
                      'Static layout/scalar mathematics records are separate evidence, not device execution results',
                      'External references require exact separately installed model and recorded input/output routing',
                      'No real video, temporal switching, allocator, full inference latency, thermal or mobile qualification'])
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in manifest.items() if k!='entries'}))
