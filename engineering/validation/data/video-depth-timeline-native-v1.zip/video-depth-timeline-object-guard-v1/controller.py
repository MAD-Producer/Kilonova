from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess

root=Path('E:/Dev/aem'); work=root/'.worktrees/video-depth-geometry'
previous=root/'artifacts/pr-queue/video-depth-timeline-green-v3'
accepted=json.loads((previous/'accepted.json').read_text(encoding='utf-8'))
source={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in accepted['source']}
changed=[p for p,h in source.items() if h!=accepted['source'][p]]
assert changed==['crates/motion-host/tests/depth_video.rs'],changed
out=root/'artifacts/pr-queue/video-depth-timeline-object-guard-v1'; out.mkdir(exist_ok=False)
shutil.copyfile(work/changed[0],out/'depth_video.rs'); shutil.copyfile(__file__,out/'controller.py')
env=os.environ.copy(); env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true');env.pop('MOTION_LOG',None)
command=['cargo','test','-p','motion-host','--features','ai-depth','--test','depth_video','--locked','--offline','--','--exact','indexed_authoring_checks_actual_decoder_interval_rgb_and_object_before_commit','--test-threads=1']
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
    code=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
unchanged=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in source.items())
report=dict(previousAcceptance=str(previous/'accepted.json'),source=source,onlyDelta=changed,productSourcesIdentical=True,command=command,exitCode=code,sourceUnchanged=unchanged,completedUtc=datetime.now(timezone.utc).isoformat())
(out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='source'}),flush=True)
assert code==0 and unchanged and '1 passed; 0 failed; 0 ignored' in (out/'stdout.log').read_text(encoding='utf-8')
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
