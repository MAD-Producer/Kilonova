from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess
root=Path('E:/Dev/aem');work=root/'.worktrees/video-depth-geometry';out=root/'artifacts/pr-queue/video-depth-timeline-red-v1';out.mkdir(exist_ok=False)
cmd=['cargo','test','-p','motion-core','--test','video_depth_calibration','--locked','--offline','--','--test-threads=1']
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true');env.pop('MOTION_LOG',None)
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=work).decode().split('\0')
source={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and p.endswith(('.rs','.toml','.wgsl'))}
shutil.copyfile(work/'crates/motion-core/tests/video_depth_calibration.rs',out/'test.rs');shutil.copyfile(__file__,out/'controller.py')
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:code=subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
r=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),command=cmd,exitCode=code,source=source,sourceUnchanged=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in source.items()),priorAttempt='Direct preliminary invocation stopped at compilation because the fixture treated CommandRegistry.parse as one Command instead of Vec<Command>; not a product failure',completedUtc=datetime.now(timezone.utc).isoformat())
(out/'exit.json').write_text(json.dumps(r,indent=2),encoding='utf-8');text=(out/'stdout.log').read_text(encoding='utf-8');print(json.dumps(dict(exitCode=code,sourceUnchanged=r['sourceUnchanged'])),flush=True)
assert code==101 and r['sourceUnchanged'] and '0 passed; 1 failed; 0 ignored' in text and 'unknown variant' in text
(out/'reproduced.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
