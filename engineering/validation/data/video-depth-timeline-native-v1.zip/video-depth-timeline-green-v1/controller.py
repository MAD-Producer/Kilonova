from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

root = Path('E:/Dev/aem')
work = root / '.worktrees/video-depth-geometry'
out = root / 'artifacts/pr-queue/video-depth-timeline-green-v1'
out.mkdir(exist_ok=False)
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG', None)
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=work).decode().split('\0')
source = {p: hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and p.endswith(('.rs', '.toml', '.wgsl'))}
report = dict(base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip(), source=source, steps=[])
shutil.copyfile(__file__, out/'controller.py')
steps = [
    ('model', ['test', '-p', 'motion-model', '--test', 'depth_video_track']),
    ('core', ['test', '-p', 'motion-core', '--test', 'video_depth_calibration']),
    ('host-library', ['test', '-p', 'motion-host', '--features', 'ai-depth', '--lib']),
    ('video', ['test', '-p', 'motion-host', '--features', 'ai-depth', '--test', 'depth_video']),
    ('session', ['test', '-p', 'motion-host', '--features', 'ai-depth', '--test', 'depth_session']),
]
for name, args in steps:
    command = ['cargo', *args, '--locked', '--offline', '--', '--test-threads=1']
    with (out/f'{name}.stdout.log').open('wb') as stdout, (out/f'{name}.stderr.log').open('wb') as stderr:
        code = subprocess.run(command, cwd=work, env=env, stdout=stdout, stderr=stderr).returncode
    unchanged = all(hashlib.sha256((work/p).read_bytes()).hexdigest() == h for p, h in source.items())
    text = (out/f'{name}.stdout.log').read_text(encoding='utf-8')
    counts = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored', text)
    step = dict(name=name, command=command, exitCode=code, sourceUnchanged=unchanged, counts=counts)
    report['steps'].append(step)
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    (out/'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(step), flush=True)
    if code != 0 or not unchanged or not counts or any(int(f) or int(i) for _, f, i in counts):
        raise SystemExit(1)
(out/'accepted.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
