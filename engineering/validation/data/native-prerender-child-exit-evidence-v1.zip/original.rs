fn timing(output: std::process::Output) { let name = "timing_control"; assert!(output.status.success(), "{}\n{}", String::from_utf8_lossy(&output.stdout), String::from_utf8_lossy(&output.stderr)); }
fn recent(output: std::process::Output) { let name = "timing_control"; assert!(
            output.status.success(),
            "{}\n{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        ); }
fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() == 3 && args[1] == "--child" {
        use std::io::Write;
        std::io::stdout().write_all(b"child-original-stdout\n").unwrap();
        std::io::stderr().write_all(b"child-original-stderr\n").unwrap();
        std::process::exit(args[2].parse::<u32>().unwrap() as i32);
    }
    let mut passed = 0;
    let mut failed = 0;
    for (site, check) in [("timing", timing as fn(std::process::Output)), ("recent", recent as fn(std::process::Output))] {
        for code in [0u32, 101, 0xc000001d] {
            let output = std::process::Command::new(std::env::current_exe().unwrap())
                .args(["--child", &code.to_string()]).output().unwrap();
            assert_eq!(output.status.code(), Some(code as i32));
            let status = output.status.to_string();
            let result = std::panic::catch_unwind(|| check(output));
            let accepted = if code == 0 { result.is_ok() } else {
                let failure = result.expect_err("original nonzero success predicate must still fail");
                let message = failure.downcast_ref::<String>().map(String::as_str)
                    .or_else(|| failure.downcast_ref::<&str>().copied()).unwrap();
                message.contains(&format!("status={status}"))
                    && message.contains("child test=")
                    && message.contains("child-original-stdout")
                    && message.contains("child-original-stderr")
            };
            if accepted { passed += 1 } else { failed += 1 }
            println!("site={site} code={code:08x} accepted={accepted}");
        }
    }
    println!("controlPassed={passed} controlFailed={failed}");
    if failed != 0 { std::process::exit(1) }
}
