"""Real child-exit controls for the two retained failure wrappers, no GPU/Cargo."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/prerender-disk-cache'
OUT = ROOT / 'artifacts/pr-queue/prerender-child-status-controls-v2'
BASE = 'ce467238'
FILES = [
    'desktop/app/src/engine/failure/composition_tests/timing_admission.rs',
    'desktop/app/src/shell/effect_application/tests/recent_menu.rs',
]
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
env.update(TEMP=str(ROOT / 'target/ci-policy-validation-tmp'),
           TMP=str(ROOT / 'target/ci-policy-validation-tmp'))
report = dict(startedUtc=datetime.now(timezone.utc).isoformat(), source={}, steps=[],
    limits='Standalone standard-library exact assertion-message controls only. No GPU, Cargo, product execution or assertion predicate changes. Explicit OS exit status 0xc000001d is simulated with process::exit, not a CPU illegal instruction or a diagnosis of the historical crash.')

def macro(text):
    start = re.search(r'assert!\(\s*output\.status\.success\(\),', text)
    assert start
    # These two exact wrappers have either one line or this final own line.
    if text[start.start():].splitlines()[0].endswith(');'):
        return text[start.start():].splitlines()[0]
    end = re.search(r'(?m)^\s*\);', text[start.end():])
    assert end
    return text[start.start():start.end()+end.end()]

variants = {'original': [], 'fixed': []}
for relative in FILES:
    before = subprocess.check_output(['git', 'show', f'{BASE}:{relative}'], cwd=WORK).decode('utf-8')
    after = (WORK / relative).read_text(encoding='utf-8')
    old, new = macro(before), macro(after)
    assert before.replace(old, new, 1) == after, 'unexpected change outside failure message'
    assert old.startswith('assert!(') and new.startswith('assert!(')
    assert re.match(r'assert!\(\s*output\.status\.success\(\),', old)
    assert re.match(r'assert!\(\s*output\.status\.success\(\),', new)
    report['source'][relative] = hashlib.sha256((WORK / relative).read_bytes()).hexdigest()
    variants['original'].append(old)
    variants['fixed'].append(new)

MAIN = r'''
fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() == 3 && args[1] == "--child" {
        use std::io::Write;
        std::io::stdout().write_all(b"child-original-stdout\n").unwrap();
        std::io::stderr().write_all(b"child-original-stderr\n").unwrap();
        std::process::exit(args[2].parse::<u32>().unwrap() as i32);
    }
    let mut passed = 0;
    let mut failed = 0;
    for (site, check) in [("timing", timing as fn(std::process::Output)), ("recent", recent as fn(std::process::Output))] {
        for code in [0u32, 101, 0xc000001d] {
            let output = std::process::Command::new(std::env::current_exe().unwrap())
                .args(["--child", &code.to_string()]).output().unwrap();
            assert_eq!(output.status.code(), Some(code as i32));
            let status = output.status.to_string();
            let result = std::panic::catch_unwind(|| check(output));
            let accepted = if code == 0 { result.is_ok() } else {
                let failure = result.expect_err("original nonzero success predicate must still fail");
                let message = failure.downcast_ref::<String>().map(String::as_str)
                    .or_else(|| failure.downcast_ref::<&str>().copied()).unwrap();
                message.contains(&format!("status={status}"))
                    && message.contains("child test=")
                    && message.contains("child-original-stdout")
                    && message.contains("child-original-stderr")
            };
            if accepted { passed += 1 } else { failed += 1 }
            println!("site={site} code={code:08x} accepted={accepted}");
        }
    }
    println!("controlPassed={passed} controlFailed={failed}");
    if failed != 0 { std::process::exit(1) }
}
'''
for variant, assertions in variants.items():
    source = '\n'.join(f'fn {name}(output: std::process::Output) {{ let name = "timing_control"; {assertion} }}'
        for name, assertion in zip(['timing', 'recent'], assertions)) + MAIN
    path = OUT / f'{variant}.rs'
    executable = OUT / f'{variant}.exe'
    path.write_text(source, encoding='utf-8')
    compile_result = subprocess.run(['rustc', '--edition=2021', str(path), '-o', str(executable)],
        env=env, capture_output=True)
    (OUT / f'{variant}.compile.stderr.log').write_bytes(compile_result.stderr)
    assert compile_result.returncode == 0, compile_result.stderr.decode('utf-8', errors='replace')
    result = subprocess.run([str(executable)], env=env, capture_output=True)
    for channel in ['stdout', 'stderr']:
        (OUT / f'{variant}.{channel}.log').write_bytes(getattr(result, channel))
    expected = (1, b'controlPassed=2 controlFailed=4') if variant == 'original' else (0, b'controlPassed=6 controlFailed=0')
    assert result.returncode == expected[0] and expected[1] in result.stdout
    report['steps'].append(dict(variant=variant, exitCode=result.returncode,
        stdoutSha256=hashlib.sha256(result.stdout).hexdigest(),
        stderrSha256=hashlib.sha256(result.stderr).hexdigest(),
        actualSummary=expected[1].decode()))
    print(json.dumps(report['steps'][-1]), flush=True)
assert all(hashlib.sha256((WORK / name).read_bytes()).hexdigest() == digest for name, digest in report['source'].items())
report.update(status='accepted_child_failure_message_controls_not_crash_fix',
    completedUtc=datetime.now(timezone.utc).isoformat())
(OUT / 'accepted.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
