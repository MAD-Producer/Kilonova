"""Archive terminal real-photo acceptance only; does not close the issue or commit."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess,zipfile
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
ACCEPT=ROOT/'artifacts/pr-queue/tracking88-photographs-acceptance-v2'
INDEPENDENT=ROOT/'artifacts/pr-queue/tracking88-photographs-independent-v1'
NATIVE=ROOT/'artifacts/pr-queue/tracking88-photographs-native-v2'
data=WORK/'engineering/validation/data'
archive=data/'tracking88-photographed-calibration-v1.zip'
assert not archive.exists()
report=json.loads((ACCEPT/'exit.json').read_text(encoding='utf-8'))
assert report['status']=='accepted_photographed_calibration_increment_full_issue_pending'
assert all(s['exitCode']==0 and s.get('completedUtc') for s in report['steps'])
for name,digest in report['source'].items():assert hashlib.sha256((WORK/name).read_bytes()).hexdigest()==digest,name
independent=json.loads((INDEPENDENT/'report.json').read_text(encoding='utf-8'))
assert independent['status']=='accepted_independent_dense_ray_pixels'
native=json.loads((NATIVE/'exit.json').read_text(encoding='utf-8'))
assert native['status']=='accepted_native_photographed_image_camera_increment_full_issue_pending'
assert native.get('completedUtc') and not native.get('cleanupFailures')
counts={}
for n in ['model','render-lens','render-regression','core','host-tracking']:
 text=(ACCEPT/(n+'.log')).read_text(encoding='utf-8',errors='replace')
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
 assert rows,n
 counts[n]=[sum(int(row[i]) for row in rows) for i in range(3)]
assert counts['model']==[245,0,0],counts
assert counts['render-lens']==[16,0,0],counts
assert counts['render-regression']==[153,0,0],counts
assert counts['core']==[485,0,1] and counts['host-tracking']==[50,0,0],counts
names=set(subprocess.check_output(['git','diff','--name-only'],cwd=WORK,text=True).splitlines())
names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=WORK,text=True).splitlines())
assert not any(n.startswith('desktop/app/src/panels/') for n in names)
members={}
for name in sorted(names):
 p=WORK/name
 if p.is_file() and p.suffix not in ('.zip','.pyc'):members['source/'+name]=p.read_bytes()
folders=['tracking88-photographs-probe-v1','tracking88-photographs-probe-v2','tracking88-photographs-probe-v3',
 'tracking88-photographs-calibration-v1','tracking88-photographs-calibration-v2','tracking88-photographs-calibration-v3',
 'tracking88-photographs-acceptance-v1','tracking88-photographs-acceptance-v2','tracking88-photographs-independent-v1',
 'tracking88-photographs-native-v1','tracking88-photographs-native-v2']
for folder in folders:
 for p in sorted((ROOT/'artifacts/pr-queue'/folder).rglob('*')):
  if p.is_file():members['evidence/'+folder+'/'+p.relative_to(ROOT/'artifacts/pr-queue'/folder).as_posix()]=p.read_bytes()
for name in ['probe-tracking88-photographs-v1.py','probe-tracking88-photographs-v2.py','probe-tracking88-photographs-v3.py',
 'accept-tracking88-photographs-v1.py','accept-tracking88-photographs-v2.py','compare-tracking88-photographs-v2.py',
 'tracking88-photographs-native-v1.py','tracking88-photographs-native-body.py',
 'tracking88-photographs-native-v2.py','tracking88-photographs-native-body-v2.py','finalize-tracking88-photographs-v1.py']:
 members['controllers/'+name]=(ROOT/'.tools/issue-closure-review'/name).read_bytes()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,content in sorted(members.items()):z.writestr(name,content)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(members)
 for name,content in members.items():assert z.read(name)==content,name
identity=dict(path=archive.name,bytes=archive.stat().st_size,members=len(members),sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
closeout=dict(status=report['status'],createdUtc=datetime.now(timezone.utc).isoformat(),
 baseCommit=report['baseCommit'],branch='codex/88-track-import-contract',archive=identity,counts=counts,
 renderTotal=[counts['render-lens'][i]+counts['render-regression'][i] for i in range(3)],
 source=report['source'],steps=report['steps'],nativeGpu=json.loads((ACCEPT/'images/photographed-oracle.json').read_text(encoding='utf-8')),
 independent=independent,nativeImageMcp=native,panelsChanged=False,
 publication=dict(pr='https://github.com/MAD-Producer/Kilonova/pull/580',status='draft; photographed increment pending commit and push at archive creation'),
 retainedNativeV1Failure=dict(status='failed',reason='Raw straight-alpha PNG equality includes hidden RGB; v2 explicitly qualifies visible RGB, alpha and black/white composites; no encoder repair'),
 pending=['Actual bound-source relink/replacement and warmed-cache consistency, including undo/redo/reopen',
 'Native calibrated solve/lens asset replacement transactions on unchanged plate',
 'Built-in 2D/planar tracker prototype',
 'Full maintained desktop/workspace regression and exact-head cross-platform CI',
 'Prior compiler/native crash causes and strict #82 P95/GPU coverage failures'],
 limits=['Separate real board photographs, not continuous photographed motion',
 'Unknown physical board size; one-square/one-project-metre gauge is not a measured metric scale',
 'Library fixtures use placeholder video bytes; the separate native MCP gate verifies real photographed image bytes and decoded dimensions',
 'Native image acceptance does not qualify source relink/replacement or continuous original video camera tracking'])
(data/'tracking88-photographed-calibration-closeout.json').write_text(json.dumps(closeout,indent=2)+'\n',encoding='utf-8')
(ROOT/'.tools/issue-closure-review/tracking88-photographs-current.json').write_text(json.dumps(closeout,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=closeout['status'],counts=counts,archive=identity),indent=2))
