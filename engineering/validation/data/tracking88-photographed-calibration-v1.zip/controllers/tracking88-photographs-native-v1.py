"""Own serial executable acceptance: original video PTS -> independent projective plane -> actual builtin corner-pin GPU output."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,struct,subprocess,copy
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-photographs-native-v1'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def now():return datetime.now(timezone.utc).isoformat()
names=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
sources={n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (WORK/n).is_file()}
report=dict(status='running',controllerPid=os.getpid(),startedUtc=now(),source=sources,steps=[],scope='Actual pinned photographed image acquisition and camera output; prior compiler/native faults remain unresolved')
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def identity():
 for n,h in sources.items():assert hashlib.sha256((WORK/n).read_bytes()).hexdigest()==h,n
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'local-appdata'))
EXE=ROOT/'target/gltf-animation87-contract/debug/motion-studio.exe';project_root=OUT/'project';active=[]
def build():
 identity();args=['cargo','build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline']
 row=dict(name='ffmpeg-build',command=args,startedUtc=now());report['steps'].append(row);save()
 with (OUT/'build.stdout.log').open('wb') as stdout,(OUT/'build.stderr.log').open('wb') as stderr:
  p=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait()
 row['completedUtc']=now();save();assert row['exitCode']==0,row
class Rpc:
 def __init__(self,name,readonly=False):
  identity();self.name=name;self.inputs=[];self.raw=[];self.next_id=0
  args=[str(EXE),'--mcp','--project',str(project_root)]+(['--mcp-read-only'] if readonly else [])
  self.row=dict(name=name,command=args,startedUtc=now(),exeSha256=hashlib.sha256(EXE.read_bytes()).hexdigest());report['steps'].append(self.row)
  self.stderr=(OUT/f'{name}.stderr.log').open('wb')
  self.p=subprocess.Popen(args,cwd=WORK,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr,text=True,encoding='utf-8');active.append(self)
  self.row['pid']=self.p.pid;save()
  self.request('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='owned-camera-binding-proof',version='1')))
  self.send(dict(jsonrpc='2.0',method='notifications/initialized'))
 def send(self,message):
  self.inputs.append(message);self.p.stdin.write(json.dumps(message)+'\n');self.p.stdin.flush()
 def request(self,method,params):
  self.next_id+=1;self.send(dict(jsonrpc='2.0',id=self.next_id,method=method,params=params))
  line=self.p.stdout.readline();self.raw.append(line);assert line,f'{self.name}: stdout closed'
  reply=json.loads(line);assert reply['jsonrpc']=='2.0' and reply['id']==self.next_id and 'error' not in reply,reply
  return reply['result']
 def call(self,name,args):return self.request('tools/call',dict(name=name,arguments=args))
 def ok(self,name,args):
  result=self.call(name,args);assert not result['isError'],result;return result['structuredContent']
 def state(self):return self.ok('motion_state',{})
 def close(self):
  if self.p.stdin and not self.p.stdin.closed:self.p.stdin.close()
  trailing=self.p.stdout.read();assert not trailing,repr(trailing)
  self.row['exitCode']=self.p.wait();self.stderr.close();self.row['completedUtc']=now()
  (OUT/f'{self.name}.stdin.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in self.inputs),encoding='utf-8')
  (OUT/f'{self.name}.stdout.jsonl').write_text(''.join(self.raw),encoding='utf-8')
  log=OUT/'local-appdata/MotionStudio/logs/motion-studio.log'
  if log.exists():(OUT/f'{self.name}.file.log').write_bytes(log.read_bytes())
  active.remove(self);save();assert self.row['exitCode']==0,self.name
save()
try:
 build()
 import math
 import numpy as np
 from PIL import Image
 measured=json.loads((WORK/'crates/motion-model/tests/fixtures/tracking-photographs.json').read_text(encoding='utf-8'))
 K=np.array(measured['K']);dist=np.array(measured['distortion'])
 # Separate external reference already independently qualified from OpenCV rays.
 independent=ROOT/'artifacts/pr-queue/tracking88-photographs-independent-v1'
 assert json.loads((independent/'report.json').read_text(encoding='utf-8'))['status']=='accepted_independent_dense_ray_pixels'
 boot=Rpc('bootstrap');base=boot.state()['project'];boot.close()
 template=json.loads((ROOT/'artifacts/pr-queue/tracking88-point-native-v1/project/project.json').read_text(encoding='utf-8'))['layers'][0]
 rows=[]
 for view in measured['views']:
  name=view['name'];project_root=OUT/name.removesuffix('.jpg');project_root.mkdir()
  project=copy.deepcopy(base);project.update(width=640,height=480,fps=24,frames=96,
    work_area=dict(in_frame=0,out_frame=96),background=[0.,0.,0.,0.],layers=[],video_assets=[],tracking_assets=[])
  project['camera']['created']=True
  src=ROOT/'artifacts/pr-queue/tracking88-photographs-probe-v3'/name
  content=src.read_bytes();source=project_root/'assets'/name;source.parent.mkdir();source.write_bytes(content)
  digest=hashlib.sha256(content).hexdigest()
  assert digest==next(f['sha256'] for f in measured['sourceManifest']['files'] if f['name']==name)
  project['assets']=[dict(id=1,path='assets/'+name,width=640,height=480)]
  (project_root/'project.json').write_text(json.dumps(project),encoding='utf-8')
  R=np.array(view['worldToCameraRotation']).T;t=np.array(view['worldToCameraTranslation']);position=-R@t
  trace=float(np.trace(R));assert trace>0
  scale=2.*math.sqrt(trace+1.)
  quat=np.array([(R[2,1]-R[1,2])/scale,(R[0,2]-R[2,0])/scale,(R[1,0]-R[0,1])/scale,.25*scale]);quat/=np.linalg.norm(quat)
  k1,k2,p1,p2,k3=dist
  observation=dict(kind='camera',camera_to_world=dict(position=position.tolist(),orientation_xyzw=quat.tolist()),
   calibration=dict(source_extent=[640,480],focal=[K[0,0],K[1,1]],principal=[K[0,2],K[1,2]],radial=[k1,k2,k3],tangential=[p1,p2]))
  solve=dict(version=1,source_id='OpenCV photographed board square-scale gauge '+name,source_sha256=digest,
   source_extent=[640,480],coordinates='right_down_forward',ticks_per_second=24_000,nominal_rate=[24,1],source_pts=[0],meters_per_world_unit=1.,
   tracks=[dict(id='photographed-board',kind='camera',reference_index=None,samples=[dict(source_index=0,visibility='visible',confidence=1.,manual_correction=False,observation=observation)])])
  original=b' \n'+json.dumps(solve,indent=2).encode()+b'\r\n';document=OUT/(name+'.mstrack');document.write_bytes(original)
  live=Rpc(name+'-edit');before=live.state()
  imported=live.ok('import_tracking',dict(path=str(document),source=dict(kind='image',id=1),expectedRevision=before['revision'],expectedDocumentGeneration=before['document_generation']))
  descriptor=imported['project']['tracking_assets'][0];assert descriptor['id']==2
  assert (project_root/descriptor['path']).read_bytes()==original
  layers=[]
  for y in range(5):
   for x in range(8):
    layer=copy.deepcopy(template);layer.update(id=100+y*8+x,name=f'Measured replacement {x},{y}',
     content=dict(kind='solid',color=([0.,1.,0.,1.] if (x+y)%2==0 else [1.,0.,1.,1.])),size=[100.,100.],three_d=True,parent=None,effects=[])
    layer.pop('tracking_point',None);layer.pop('tracking_plane',None)
    layer['transform']['anchor']=[.5,.5];layer['transform']['position']['value']=[320.+100.*(x+.5),240.+100.*(y+.5),0.]
    layer['transform']['rotation']['value']=[0.,0.,0.];layers.append(layer)
  def edit(commands):
   state=live.state();return live.ok('motion_edit',dict(commands=commands,expectedRevision=state['revision']))
  edit([dict(op='add',layer=l) for l in layers])
  camera=live.state()['project']['camera'];p=camera['position']['value']
  reference=dict(world=dict(position=[p[0]-320.,240.-p[1],-p[2]],orientation_xyzw=[0.,0.,0.,1.]),vertical_fov_degrees=camera['fov']['value'])
  binding=dict(asset=2,track='photographed-board',anchor_local_frame=0,source_anchor_pts=0,speed_numerator=1,speed_denominator=1,
   world_basis=[1,-2,-3],target_meters_per_unit=.01,target_origin=[0.,0.,0.],correction_reference=reference,
   crop=[0.,0.,640.,480.],rotation='none',near=.5,far=100000.,interpolation='linear',max_gap_ticks=0,minimum_confidence=.8,missing='error')
  before=live.state();bad=copy.deepcopy(binding);bad['track']='absent'
  error=live.call('motion_edit',dict(commands=[dict(op='set_tracking_camera',object=0,binding=bad)],expectedRevision=before['revision']))
  assert error['isError'] and 'phase=binding object=0 asset=2 track=absent' in error['content'][0]['text'],error
  assert live.state()['project']==before['project']
  bound=edit([dict(op='set_tracking_camera',object=0,binding=binding)])
  state=live.ok('motion_seek',dict(frame=0.));anchors={a['id']:a['anchor'] for a in state['projectedLayers']}
  max_anchor_error=0.
  for y in range(5):
   for x in range(8):
    point=np.array([x+.5,y+.5,0.]);q=R.T@(point-position);qx,qy=q[:2]/q[2];r2=qx*qx+qy*qy;rad=1.+k1*r2+k2*r2**2+k3*r2**3
    expected=[K[0,0]*(qx*rad+2*p1*qx*qy+p2*(r2+2*qx*qx))+K[0,2], K[1,1]*(qy*rad+p1*(r2+2*qy*qy)+2*p2*qx*qy)+K[1,2]]
    anchor=anchors[100+y*8+x];e=math.hypot(anchor[0]-expected[0],anchor[1]-expected[1]);max_anchor_error=max(max_anchor_error,e)
    assert e<.0003,(name,x,y,anchor,expected,e)
  capture=live.ok('render_preview',dict(frame=0.));destination=OUT/(name+'-native.png');shutil.copyfile(capture['path'],destination)
  undo=live.ok('motion_history',dict(operation='undo'));assert undo['project']['camera'].get('tracking') is None
  redo=live.ok('motion_history',dict(operation='redo'));assert redo['project']==bound['project']
  live.ok('motion_save',{});live.close()
  reopen=Rpc(name+'-readonly',True);assert reopen.state()['project']==bound['project'];reopen.close()
  actual=np.array(Image.open(destination).convert('RGBA'));expected=np.array(Image.open(independent/(name+'-external-reference.png')).convert('RGBA'));assert actual.shape==expected.shape==(480,640,4)
  stable=np.ones((480,640),bool)
  for dy in [-2,0,2]:
   for dx in [-2,0,2]:stable&=np.all(expected==np.roll(expected,(dy,dx),(0,1)),axis=2)
  stable[:2]=False;stable[-2:]=False;stable[:,:2]=False;stable[:,-2:]=False
  maximum=int(np.abs(actual.astype(int)-expected.astype(int))[stable].max())
  assert int(stable.sum())>200000 and maximum<=2,(name,maximum)
  log=(OUT/(name+'-edit.file.log')).read_text(encoding='utf-8');stderr=(OUT/(name+'-edit.stderr.log')).read_text(encoding='utf-8',errors='replace')
  assert re.search(r'start #\d+ import_tracking',log) and 'tracking original source phase=decode source=Image:1' in log
  for sink in [log,stderr]:assert 'phase=binding object=0 asset=2 track=absent' in sink and re.search(r'error #\d+',sink)
  rows.append(dict(name=name,originalSha256=digest,originalDocumentSha256=hashlib.sha256(original).hexdigest(),
   maxAnchorError=max_anchor_error,checked=int(stable.sum()),maxByteError=maximum,undoRedoReopen=True))
 identity();report.update(status='accepted_native_photographed_image_camera_increment_full_issue_pending',samples=rows,
  limitation='Separate photographed image sources. No continuous-video solve, relink transaction or measured metric scale.')
except BaseException as error:report.update(status='failed',failure=repr(error));raise
finally:
 for rpc in list(active):
  try:rpc.close()
  except BaseException as secondary:report.setdefault('cleanupFailures',[]).append(repr(secondary))
 report['completedUtc']=now();save()
