"""Independent OpenCV dense-ray verification of the actual GPU photographs gate."""
from pathlib import Path
import hashlib,json
import cv2
import numpy as np
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
ACCEPT=ROOT/'artifacts/pr-queue/tracking88-photographs-acceptance-v2'
PHOTO=ROOT/'artifacts/pr-queue/tracking88-photographs-probe-v3'
OUT=ROOT/'artifacts/pr-queue/tracking88-photographs-independent-v1'
OUT.mkdir(exist_ok=False)
r=json.loads((WORK/'crates/motion-model/tests/fixtures/tracking-photographs.json').read_text(encoding='utf-8'))
report=dict(status='running',sourceAcceptance=str(ACCEPT),method='External OpenCV undistortPoints, external R/t and ray-plane equation; no production inverse/matrices',views=[])
try:
 assert json.loads((ACCEPT/'exit.json').read_text(encoding='utf-8'))['status']=='accepted_photographed_calibration_increment_full_issue_pending'
 K=np.array(r['K']);dist=np.array(r['distortion'])
 yy,xx=np.mgrid[:480,:640].astype(np.float64);pixels=np.stack([xx+.5,yy+.5],-1).reshape(-1,1,2)
 ideal=cv2.undistortPoints(pixels,K,dist,criteria=(cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER,100,1e-13)).reshape(480,640,2)
 rays=np.concatenate([ideal,np.ones((480,640,1))],-1)
 panels=[]
 for v in r['views']:
  name=v['name'];source=PHOTO/name
  entry=next(f for f in r['sourceManifest']['files'] if f['name']==name)
  assert hashlib.sha256(source.read_bytes()).hexdigest()==entry['sha256']
  rot=np.array(v['worldToCameraRotation']);t=np.array(v['worldToCameraTranslation']);origin=-rot.T@t
  ray=rays@rot;distance=-origin[2]/ray[:,:,2];world=origin+distance[:,:,None]*ray
  x,y=world[:,:,0],world[:,:,1]
  inside=(distance>0)&(x>=0)&(x<8)&(y>=0)&(y<5)
  odd=(np.floor(x).astype(int)+np.floor(y).astype(int))%2==1
  expected=np.zeros((480,640,4),np.uint8)
  expected[inside&~odd]=[0,255,0,255];expected[inside&odd]=[255,0,255,255]
  # OpenCV loads B,G,R,A; keep channel meanings explicit.
  actual=cv2.imread(str(ACCEPT/'images'/f'photographed-{name}-actual.png'),cv2.IMREAD_UNCHANGED)[:,:,[2,1,0,3]]
  assert actual.shape==expected.shape
  stable=np.ones((480,640),bool)
  for dy in [-2,0,2]:
   for dx in [-2,0,2]:stable&=np.all(expected==np.roll(expected,(dy,dx),(0,1)),axis=2)
  stable[:2]=False;stable[-2:]=False;stable[:,:2]=False;stable[:,-2:]=False
  error=np.abs(actual.astype(int)-expected.astype(int)).max(axis=2)
  row=dict(name=name,checked=int(stable.sum()),interior=int((stable&inside).sum()),
           maxByteError=int(error[stable].max()),mismatchedAboveTwoBytes=int((stable&(error>2)).sum()),
           photoSha256=entry['sha256'],actualSha256=hashlib.sha256((ACCEPT/'images'/f'photographed-{name}-actual.png').read_bytes()).hexdigest(),
           heldOutRms=v['heldOutRms'],heldOutMax=v['heldOutMax'],edgeExclusionPixels=2.)
  report['views'].append(row)
  assert row['checked']>200000 and row['interior']>3000 and row['mismatchedAboveTwoBytes']==0,row
  photo=cv2.imread(str(source));overlay=photo.copy()
  alpha=actual[:,:,3:4].astype(float)/255.*.6
  overlay=(photo*(1-alpha)+actual[:,:,[2,1,0]]*alpha).round().astype(np.uint8)
  for index in v['validationIndices']:
   p=tuple(int(round(a)) for a in r['measuredCorners'][name][index])
   cv2.circle(overlay,p,2,(0,200,255),1,cv2.LINE_AA)
  left=cv2.copyMakeBorder(photo,30,0,0,0,cv2.BORDER_CONSTANT,value=(25,25,25))
  right=cv2.copyMakeBorder(overlay,30,0,0,0,cv2.BORDER_CONSTANT,value=(25,25,25))
  cv2.putText(left,f'{name} | original photographed plate',(10,20),cv2.FONT_HERSHEY_SIMPLEX,.5,(240,240,240),1,cv2.LINE_AA)
  cv2.putText(right,f'GPU replacement | held-out RMS {v["heldOutRms"]:.3f} px',(10,20),cv2.FONT_HERSHEY_SIMPLEX,.5,(240,240,240),1,cv2.LINE_AA)
  panels.append(np.concatenate([left,right],axis=1))
  cv2.imwrite(str(OUT/f'{name}-external-reference.png'),expected[:,:,[2,1,0,3]])
  cv2.imwrite(str(OUT/f'{name}-overlay.png'),overlay)
 cv2.imwrite(str(OUT/'comparison.png'),np.concatenate(panels,axis=0))
 report['status']='accepted_independent_dense_ray_pixels'
except BaseException as cause:
 report.update(status='failed',failure=repr(cause));raise
finally:(OUT/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
