"""Exploratory real-photo calibration; not a native rendering acceptance gate."""
from pathlib import Path
import hashlib, json, urllib.request
import cv2
import numpy as np

OUT = Path('E:/Dev/aem/artifacts/pr-queue/tracking88-photographs-probe-v3')
OUT.mkdir(exist_ok=False)
REV = '71d3237a093b60a27601c20e9ee6c3e52154e8b1'
BASE = f'https://raw.githubusercontent.com/opencv/opencv/{REV}/'
names = [f'left{i:02}.jpg' for i in list(range(1, 10)) + list(range(11, 15))]
report = dict(status='exploratory', upstreamRevision=REV, files=[], views=[],
              cv2=cv2.__version__, numpy=np.__version__, units='checkerboard square, physical size unknown')
try:
    for name, relative in [('LICENSE', 'LICENSE'), ('stereo_calib.xml', 'samples/data/stereo_calib.xml')] + [(n, 'samples/data/'+n) for n in names]:
        with urllib.request.urlopen(BASE+relative, timeout=30) as response:
            content = response.read(2_000_001)
        assert 0 < len(content) <= 2_000_000, name
        (OUT/name).write_bytes(content)
        report['files'].append(dict(name=name, source=BASE+relative, bytes=len(content), sha256=hashlib.sha256(content).hexdigest()))
    objects = np.zeros((54, 3), np.float32)
    objects[:, :2] = np.mgrid[0:9, 0:6].T.reshape(-1, 2)
    corners = {}
    for name in names:
        image = cv2.imread(str(OUT/name), cv2.IMREAD_GRAYSCALE)
        assert image.shape == (480,640), (name,image.shape)
        found, points = cv2.findChessboardCorners(image, (9,6))
        assert found, name
        corners[name] = cv2.cornerSubPix(image, points, (11,11), (-1,-1),
            (cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-5))
    held = ['left03.jpg','left08.jpg','left14.jpg']
    train = [n for n in names if n not in held]
    rms,K,dist,_,_ = cv2.calibrateCamera([objects]*len(train),[corners[n] for n in train],(640,480),None,None)
    report.update(trainingViews=train, heldOutViews=held, trainingRms=rms, K=K.tolist(), distortion=dist.tolist(), measuredCorners={n:c.reshape(-1,2).tolist() for n,c in corners.items()})
    mask = np.array([(x+y)%2==0 for y in range(6) for x in range(9)])
    for name in held:
        ok,rvec,tvec = cv2.solvePnP(objects[mask],corners[name][mask],K,dist,flags=cv2.SOLVEPNP_ITERATIVE)
        assert ok,name
        projected,_=cv2.projectPoints(objects,rvec,tvec,K,dist)
        errors=np.linalg.norm(projected.reshape(-1,2)-corners[name].reshape(-1,2),axis=1)
        e=errors[~mask]
        report['views'].append(dict(name=name,poseFitIndices=np.flatnonzero(mask).tolist(),validationIndices=np.flatnonzero(~mask).tolist(),rvec=rvec.flatten().tolist(),tvec=tvec.flatten().tolist(), heldOutRms=float(np.sqrt(np.mean(e*e))),heldOutMax=float(e.max()),heldOutP95=float(np.percentile(e,95)),errors=errors.tolist()))
    # Reproduce the current conservative certificate exactly to identify whether
    # ordinary real lenses need a stronger proof; this is not the inverse oracle.
    D=max(np.linalg.norm((np.array(p)-K[:2,2])/np.diag(K)[:2]) for p in [(0,0),(640,0),(640,480),(0,480)])
    R=2*D+1e-12
    k1,k2,p1,p2,k3=dist.flatten()
    old=3*abs(k1)*R**2+5*abs(k2)*R**4+7*abs(k3)*R**6+8*(abs(p1)+abs(p2))*R
    report.update(currentCertificate=dict(radius=R,derivativeBound=float(old),admitted=bool(old<.45)))
except BaseException as error:
    report.update(status='failed',failure=repr(error))
    raise
finally:
    (OUT/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('measuredCorners','files')},indent=2))
