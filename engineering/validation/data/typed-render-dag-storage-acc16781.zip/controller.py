from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/render-dag-refinement';label=sys.argv[1]
out=root/'artifacts/pr-queue'/('issue78-storage-'+label);out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
 names=set(subprocess.check_output(['git','ls-files','-z'],cwd=work).split(b'\0'));names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=work).split(b'\0'))
 return {p.decode():sha(work/p.decode()) for p in sorted(names) if p and (work/p.decode()).is_file() and (p.endswith(b'.rs') or p.endswith(b'Cargo.toml') or p==b'Cargo.lock')}
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/ai-depth74-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='1',MOTION_EXECUTION_ARTIFACTS=str(out/'output-artifacts'));env.pop('MOTION_LOG',None)
base=['cargo','test','-p','motion-render','--locked','--offline']
commands=[('runtime',base+['--test','runtime_execution_template','--','--test-threads=1'],{}),('vulkan-frame-imports',base+['--test','frame_image_imports','--','--test-threads=1'],dict(WGPU_BACKEND='vulkan')),('library',base+['--lib','--','--test-threads=1'],{}),('native-regression',base+['--test','typed_snapshot_execution','--test','typed_group_invalidation','--test','pointwise_fusion','--test','pointwise_extreme_alpha','--','--test-threads=1'],{})]
receipt=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),source=sources(),controllerPid=os.getpid(),startedUtc=datetime.now(timezone.utc).isoformat(),steps=[])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
for name,cmd,overrides in commands:
 stage=out/name;stage.mkdir();item=dict(name=name,command=cmd,overrides=overrides);receipt['steps'].append(item);print(json.dumps(dict(starting=name)),flush=True)
 with (stage/'stdout.log').open('wb') as stdout,(stage/'stderr.log').open('wb') as stderr:
  child=subprocess.Popen(cmd,cwd=work,env=dict(env,**overrides),stdout=stdout,stderr=stderr);item['pid']=child.pid
  (out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');code=child.wait()
 item.update(exitCode=code,sourceUnchanged=receipt['source']==sources(),stdoutSha256=sha(stage/'stdout.log'),stderrSha256=sha(stage/'stderr.log'))
 (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');assert item['sourceUnchanged'],'source changed during gate'
 if code:sys.exit(code)
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (stage/'stdout.log').read_text(encoding='utf-8'))
 assert rows and all(int(r[1])==0 and int(r[2])==0 for r in rows)
 item['passes']=sum(int(r[0]) for r in rows);print(json.dumps(dict(completed=name,passes=item['passes'])),flush=True)
receipt['completedUtc']=datetime.now(timezone.utc).isoformat();(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(dict(accepted=True)),flush=True)
