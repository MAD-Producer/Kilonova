from pathlib import Path
from datetime import datetime,timezone
import concurrent.futures, hashlib,json,subprocess

root=Path('E:/Dev/aem')
out=root/'artifacts/pr-queue/tracking88-ci-green-5c6c654b-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
repo='repos/MAD-Producer/motion-studio'
run_id=41988958264
head='5c6c654bf98c3aef8ac4e098ca657f2d4f746cd3'
def api(path):
    return subprocess.check_output(['gh','api',repo+path])
run=api(f'/actions/runs/{run_id}')
metadata=json.loads(run)
(out/'run.json').write_bytes(run)
assert metadata['status']=='completed' and metadata['conclusion']=='success' and metadata['head_sha']==head
jobs=api(f'/actions/runs/{run_id}/jobs')
(out/'jobs.json').write_bytes(jobs)
report=dict(head=head,run=run_id,runConclusion='success',status='collecting',jobs=[],startedUtc=datetime.now(timezone.utc).isoformat(),
            limits=['Original remote head only, not rebased/local later source',
                    'PR workflow omits FFmpeg runtime/decode acceptance; not a replacement for the failed local maintained-workspace gate'])
def save():
    (out/'receipt.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def collect(job):
    assert job['status']=='completed' and job['conclusion'] in ('success','skipped')
    row=dict(id=job['id'],name=job['name'],conclusion=job['conclusion'])
    if job['conclusion']=='success':
        p=out/f"job-{job['id']}.log"
        with p.open('wb') as log:
            result=subprocess.run(['gh','api',repo+f"/actions/jobs/{job['id']}/logs"],stdout=log,stderr=subprocess.PIPE)
        row.update(log=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),retrievalExit=result.returncode)
        if result.returncode:
            (out/f"job-{job['id']}.retrieval.stderr").write_bytes(result.stderr)
        assert result.returncode==0,(job['id'],result.stderr.decode(errors='replace'))
    return row
save()
try:
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for row in pool.map(collect,json.loads(jobs)['jobs']):
            report['jobs'].append(row)
            save()
    report['status']='prior_remote_run_green_logs_collected'
except BaseException as error:
    report.update(status='retrieval_failed_original_outputs_retained',failure=repr(error))
    raise
finally:
    report['completedUtc']=datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps(report))
