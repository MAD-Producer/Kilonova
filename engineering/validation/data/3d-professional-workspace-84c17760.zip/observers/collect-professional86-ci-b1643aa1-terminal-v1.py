"""Retain the terminal run and every completed job without relabeling cancellations."""
from pathlib import Path
from datetime import datetime, timezone
import concurrent.futures
import hashlib
import json
import subprocess

ROOT = Path('E:/Dev/aem')
OUT = ROOT / 'artifacts/pr-queue/professional86-ci-b1643aa1-terminal-v1'
REPO = 'repos/MAD-Producer/motion-studio'
RUN = 41991436758
HEAD = 'b1643aa1fd78fffee7012cf20cd88825a6ec99c4'


def api(path):
    return subprocess.check_output(['gh', 'api', REPO + path])


def main():
    raw = api(f'/actions/runs/{RUN}')
    metadata = json.loads(raw)
    assert metadata['head_sha'] == HEAD and metadata['status'] == 'completed', 'Preserve the active run; collect after terminal state only'
    jobs_raw = api(f'/actions/runs/{RUN}/jobs?per_page=100')
    jobs = json.loads(jobs_raw)
    assert len(jobs['jobs']) == jobs['total_count'] and all(j['status'] == 'completed' for j in jobs['jobs'])
    OUT.mkdir(exist_ok=False)
    (OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
    (OUT / 'run.json').write_bytes(raw)
    (OUT / 'jobs.json').write_bytes(jobs_raw)
    report = dict(status='collecting', run=RUN, head=HEAD, conclusion=metadata['conclusion'],
                  startedUtc=datetime.now(timezone.utc).isoformat(), jobs=[], limits=[
                      'Exact original professional source; not a combined-source validation',
                      'Cancelled and timed-out jobs are not successful tests',
                      'No workflow rerun, source push or cancellation performed by this collector'])

    def save():
        (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

    def collect(job):
        row = dict(id=job['id'], name=job['name'], conclusion=job['conclusion'])
        if job['conclusion'] != 'skipped':
            path = OUT / f"job-{job['id']}.log"
            with path.open('wb') as stream:
                child = subprocess.run(['gh', 'api', REPO + f"/actions/jobs/{job['id']}/logs"],
                                       stdout=stream, stderr=subprocess.PIPE)
            row.update(log=path.name, bytes=path.stat().st_size,
                       sha256=hashlib.sha256(path.read_bytes()).hexdigest(), retrievalExit=child.returncode)
            if child.returncode:
                (OUT / f"job-{job['id']}.retrieval.stderr").write_bytes(child.stderr)
            assert child.returncode == 0, (job['id'], child.stderr.decode(errors='replace'))
        if job['conclusion'] not in ('success', 'skipped'):
            annotations = api(f"/check-runs/{job['check_run_url'].rsplit('/', 1)[1]}/annotations?per_page=100")
            (OUT / f"job-{job['id']}.annotations.json").write_bytes(annotations)
            row['annotations'] = json.loads(annotations)
        return row

    save()
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            for row in pool.map(collect, jobs['jobs']):
                report['jobs'].append(row)
                save()
        report['status'] = 'terminal_original_results_collected'
    except BaseException as cause:
        report.update(status='retrieval_failed_original_outputs_retained', failure=repr(cause))
        raise
    finally:
        report['completedUtc'] = datetime.now(timezone.utc).isoformat()
        save()
    print(json.dumps(report))


if __name__ == '__main__':
    main()
