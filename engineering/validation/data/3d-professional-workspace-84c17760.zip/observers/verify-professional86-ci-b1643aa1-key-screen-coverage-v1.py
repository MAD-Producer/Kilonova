from pathlib import Path
import hashlib,json,re
root=Path('E:/Dev/aem/artifacts/pr-queue/professional86-ci-b1643aa1-terminal-v1')
receipt=json.loads((root/'receipt.json').read_text(encoding='utf-8'))
tests=['photographed_screen_opacity_history_reopen_and_frozen_output_match_independent_reference','chroma_sample_public_api_preserves_alpha_local_animation_history_reopen_and_frozen_output','footage::photographed_key_with_manual_holdout_history_reopen_and_frozen_png_keep_fixed_controls']
rows=[]
for job in receipt['jobs']:
 if not job['name'].startswith('Desktop tests'):continue
 assert job['conclusion']=='success'
 p=root/job['log'];assert hashlib.sha256(p.read_bytes()).hexdigest()==job['sha256']
 lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
 evidence={name:[line for line in lines if 'test '+name+' ... ok' in line] for name in tests}
 assert all(len(hits)==1 for hits in evidence.values()),evidence
 command=[line for line in lines if 'cargo test -p motion-desktop -p motion-host -p motion-ui -p motion-desktop-media --locked --features' in line]
 assert command
 summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',p.read_text(encoding='utf-8',errors='replace'))
 assert all(s[1]=='0' for s in summaries)
 rows.append(dict(job=job['id'],name=job['name'],evidence=evidence,command=command[0],observedSummaries=len(summaries),observedPassed=sum(int(s[0]) for s in summaries),observedOriginalIgnores=sum(int(s[2]) for s in summaries)))
assert len(rows)==3
report=dict(head=receipt['head'],run=receipt['run'],status='three_key_and_photographed_screen_tests_observed_passed_on_all_three_native_platforms',platforms=rows,limits=['Exact b1643aa1 only; not combined84c17760; whole run cancelled by45minute Rust/GPU timeout','Observed log totals include platform GPU/memory adapter prechecks and desktop packages; not entire workspace','PR excludes FFmpeg runtime and actual ONNX model; original native failures remain historical unresolved failures'])
(root/'key-screen-execution-coverage.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='platforms'}));print([(r['name'],r['observedPassed'],r['observedSummaries']) for r in rows])
