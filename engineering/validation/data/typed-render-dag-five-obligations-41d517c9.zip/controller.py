from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/render-dag-refinement';out=root/'artifacts/pr-queue'/('issue78-five-proofs-'+sys.argv[1]);out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
 names=set(subprocess.check_output(['git','ls-files','-z'],cwd=work).split(b'\0'));names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=work).split(b'\0'))
 return {p.decode():sha(work/p.decode()) for p in sorted(names) if p and (work/p.decode()).is_file() and (p.endswith((b'.rs',b'.wgsl',b'.glsl')) or p.endswith(b'Cargo.toml') or p==b'Cargo.lock')}
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/ai-depth74-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='1',MOTION_EXECUTION_ARTIFACTS=str(out/'output-artifacts'),MOTION_POINTWISE_EXTREME_ARTIFACTS=str(out/'alpha-artifacts'),MOTION_POINTWISE_ARTIFACTS=str(out/'chain-artifacts'));env.pop('MOTION_LOG',None)
base=['cargo','test','-p','motion-render','--locked','--offline']
def exact(target,name):return base+['--test',target,name,'--','--exact','--test-threads=1']
commands=[
 ('frame-imports',base+['--test','frame_image_imports','--','--test-threads=1']),
 ('alpha',base+['--test','pointwise_extreme_alpha','--','--test-threads=1']),
 ('shader-kernel',exact('pointwise_proof_kernels','shader_operation_equivalence_uses_pinned_original_bodies_and_generated_gpu_functions')),
 ('quantization-kernel',exact('pointwise_proof_kernels','quantization_half_gpu_function_checks_every_finite_cell_and_ties_against_independent_centers')),
 ('quantization-native',exact('pointwise_fusion','unorm16_transfer_order_retains_native_stores_and_reverse_order_still_fuses')),
 ('external-reads',exact('pointwise_fusion','effected_resource_and_matte_consumers_keep_the_producers_real_stores')),
 ('compositing',exact('pointwise_fusion','transfer_blends_and_adjustment_backdrops_retain_unproved_compositing_boundaries')),
 ('whole-chain',exact('pointwise_fusion','native_fusion_preserves_four_storage_modes_alpha_channels_opacity_and_numeric_pipeline_reuse')),
 ('effects-cpu',['cargo','test','-p','motion-effects','--lib','--locked','--offline','--','--test-threads=1'])]
receipt=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),source=sources(),startedUtc=datetime.now(timezone.utc).isoformat(),controllerPid=os.getpid(),steps=[])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
for name,cmd in commands:
 stage=out/name;stage.mkdir();item=dict(name=name,command=cmd);receipt['steps'].append(item);print(json.dumps(dict(starting=name)),flush=True)
 with (stage/'stdout.log').open('wb') as stdout,(stage/'stderr.log').open('wb') as stderr:
  child=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr);item['pid']=child.pid;(out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');code=child.wait()
 item.update(exitCode=code,sourceUnchanged=receipt['source']==sources(),stdoutSha256=sha(stage/'stdout.log'),stderrSha256=sha(stage/'stderr.log'))
 (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');assert item['sourceUnchanged'],'source changed during gate'
 if code:sys.exit(code)
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',(stage/'stdout.log').read_text(encoding='utf-8'))
 assert rows and sum(int(r[0]) for r in rows)>0 and all(int(r[1])==0 and int(r[2])==0 for r in rows)
 item['passes']=sum(int(r[0]) for r in rows);print(json.dumps(dict(completed=name,passes=item['passes'])),flush=True)
receipt['completedUtc']=datetime.now(timezone.utc).isoformat();(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(dict(accepted=True)),flush=True)
