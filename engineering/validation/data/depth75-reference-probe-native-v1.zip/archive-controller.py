"""Keep the Path-driver failure and successful first CLI control distinct."""
from pathlib import Path
import hashlib, json, subprocess, zipfile
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/depth-wgsl-cache75';BASE=ROOT/'artifacts/pr-queue'
FIRST=BASE/'depth75-reference-probe-native-v1';SECOND=BASE/'depth75-reference-probe-cli-v2'
a=json.loads((FIRST/'receipt.json').read_text());b=json.loads((SECOND/'receipt.json').read_text())
assert json.loads((FIRST/'session-consumed.json').read_text())==dict(session=5772,consumed=True,exit_code=1)
assert json.loads((SECOND/'exec-completed.json').read_text())==dict(exec_chunk='193fc7',completed=True,exit_code=0)
assert a['status']=='failed_original_outputs_retained' and "has no attribute 'with_file_name'" in a['cause']
assert len(a['stages'])==2 and all(row['exit_code']==0 for row in a['stages'])
assert b['status']=='actual_default_cli_source_refusal_passed_no_inference' and b['exit_code']==1
assert a['head']==b['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert a['source_unchanged'] and b['source_unchanged'] and a['source_sha256']==b['source_sha256']
def sha(raw):return hashlib.sha256(raw).hexdigest()
for name,digest in a['source_sha256'].items():assert sha((WORK/name).read_bytes())==digest,name
assert not (FIRST/'changed-rgb-before-inference.stdout.log').exists()
assert not (SECOND/'changed-rgb.stdout.log').read_bytes()
assert '2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in (FIRST/'probe-unit-tests.stdout.log').read_text()
members={}
for label,folder,names in (
 ('native-v1',FIRST,('controller.py','receipt.json','session-consumed.json','probe-unit-tests.stdout.log',
 'probe-unit-tests.stderr.log','probe-product-build.stdout.log','probe-product-build.stderr.log')),
 ('cli-v2',SECOND,('controller.py','receipt.json','exec-completed.json','changed-rgb.stdout.log','changed-rgb.stderr.log',
 'refused/measurements.json','refused/logs/motion-studio.log'))):
 for name in names:members[label+'/'+name]=(folder/name).read_bytes()
for name in ('crates/motion-host/Cargo.toml','crates/motion-host/examples/depth_reference.rs'):
 members['source/'+name]=(WORK/name).read_bytes()
members['archive-controller.py']=Path(__file__).read_bytes()
data=WORK/'engineering/validation/data';archive=data/'depth75-reference-probe-native-v1.zip';manifest=data/'depth75-reference-probe-native-v1.json'
assert not archive.exists() and not manifest.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zipped:
 for name,raw in sorted(members.items()):zipped.writestr(name,raw)
with zipfile.ZipFile(archive) as zipped:
 assert sorted(zipped.namelist())==sorted(members)
 for name,raw in members.items():assert zipped.read(name)==raw
value=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
 members=[dict(path=name,bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(members.items())],
 head=a['head'],source_unchanged=True,unit_tests=dict(passed=2,failed=0,ignored=0,filtered=0),actual_product_build='passed',
 original_driver_status=a['status'],original_driver_cause='Python Path.with_file_name typo after completed tests/build, before any CLI invocation',
 followup_status=b['status'],actual_failure=b['actual_failure'],driver_sha256=b['driver_sha256'],
 limits=['First controller remains failed; only Path API spelling corrected in external second driver',
 'No native/test rerun, product/fixture/assertion change, inference retry or hidden success',
 'Actual first CLI invocation proves source refusal and default file/stderr/empty-stdout isolation; no learned-model inference',
 'No executable, input RGB, sensor or learned-depth array is redistributed'])
manifest.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
print(json.dumps({name:value[name] for name in ('archive','bytes','sha256')}))
