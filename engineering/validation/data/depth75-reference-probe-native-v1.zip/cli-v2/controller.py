"""Continue only the previously unexecuted CLI stage; no native/test rerun."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, traceback

ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
PARENT=BASE/'depth75-reference-probe-native-v1';OUT=BASE/'depth75-reference-probe-cli-v2'
assert json.loads((PARENT/'session-consumed.json').read_text())==dict(session=5772,consumed=True,exit_code=1)
parent=json.loads((PARENT/'receipt.json').read_text())
assert parent['status']=='failed_original_outputs_retained' and parent['source_unchanged']
assert len(parent['stages'])==2 and all(row['exit_code']==0 for row in parent['stages'])
assert "has no attribute 'with_file_name'" in parent['cause']
assert not (PARENT/'changed-rgb-before-inference.stdout.log').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==parent['head']
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def hashes():return {name:sha(WORK/name) for name in parent['source_sha256']}
assert hashes()==parent['source_sha256'] and not OUT.exists()
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env={key:value for key,value in os.environ.items() if not key.startswith('MOTION_')}
env.update(TEMP=str(OUT),TMP=str(OUT),LOCALAPPDATA=str(OUT/'appdata'),PYTHONDONTWRITEBYTECODE='1')
TARGET=ROOT/'target/depth-wgsl-cache75-contract'
env['PATH']=str(ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')+';'+env['PATH']
model=BASE/'depth75-resolution-models-v1/266/export/depth_anything_v2_vits_266.onnx'
# Correct Python Path API; no input, assertion, model or product change.
assert model.is_file() and model.with_name('model.json').is_file()
driver=TARGET/'debug/examples/depth_reference.exe'
report=dict(status='running',head=parent['head'],source_sha256=parent['source_sha256'],driver_sha256=sha(driver),
 started_utc=datetime.now(timezone.utc).isoformat(),predecessor_status=parent['status'],
 predecessor_receipt_sha256=sha(PARENT/'receipt.json'),
 limits=['Previously completed two unit controls and actual build are reused; no native command rerun',
 'Only the external driver Path method spelling changed; original failure remains failed',
 'Actual first CLI source-refusal invocation, same frozen negative copy, default sink, no model inference'])
def save():
 p=OUT/'receipt.pending.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(p,OUT/'receipt.json')
save()
try:
 command=[driver,'onnx',ROOT/'.tools/ai-depth74/venv/Scripts/python.exe',model,
 BASE/'depth75-wgsl-cache-resources-v2/program.json',TARGET/'debug/motion-depth-wgsl.exe',PARENT/'tampered-input',OUT/'refused']
 report['command']=[str(v) for v in command];save()
 with (OUT/'changed-rgb.stdout.log').open('wb') as stdout,(OUT/'changed-rgb.stderr.log').open('wb') as stderr:
  child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);report['pid']=child.pid;save();report['exit_code']=child.wait()
 save();assert report['exit_code']==1
 cause='reference RGB differs from frozen preparation identity'
 console=(OUT/'changed-rgb.stderr.log').read_text();logs=(OUT/'refused/logs/motion-studio.log').read_text()
 partial=json.loads((OUT/'refused/measurements.json').read_text())
 assert not (OUT/'changed-rgb.stdout.log').read_bytes()
 assert partial['status']=='failed' and partial['samples']==[] and partial['cause']==cause
 assert 'logging initialized level=INFO' in logs and 'start operation=depth_reference phase=source_plan' in logs
 assert 'ERROR' in logs and cause in logs and 'ERROR depth_reference:' in console and cause in console
 assert 'start #' not in logs
 prepared=json.loads((BASE/'depth75-reference-inputs-v1/inputs.json').read_text())
 for row in prepared:
  for kind in ('rgb','depth'):
   identity=row[kind+'_input'];assert sha(BASE/'depth75-reference-inputs-v1'/identity['filename'])==identity['sha256']
 report.update(status='actual_default_cli_source_refusal_passed_no_inference',
 actual_failure=dict(cause=cause,file=True,stderr=True,stdout_bytes=0,samples=0,submitted_worker_start_records=0));save()
except BaseException:
 report['status']='failed_original_outputs_retained';report['cause']=traceback.format_exc();save();raise
finally:
 report['source_unchanged']=hashes()==report['source_sha256'];report['finished_utc']=datetime.now(timezone.utc).isoformat();save()
 assert report['source_unchanged'],'Source changed during actual CLI qualification'
