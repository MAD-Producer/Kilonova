use crate::{ensure, Ease, Easing, Error, Keyframe, Layer, Result, Track, Tween};
use motion_effects::{EffectDefinition, ParamKind, MAX_EFFECTS_PER_LAYER, MAX_PARAMS};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};
pub type CurveLut = [[f32; 4]; 256];
mod curve_sampling;
pub use curve_sampling::{SampledColorCurve, HIGH_PRECISION_CURVE_SAMPLES};

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PluginDependency {
    pub plugin: String,
    pub version: String,
    pub hash: String,
}
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CurveObject {
    pub channels: [Vec<[f32; 2]>; 5],
    pub interpolation: [crate::color_curves::ColorInterpolation;5],
    #[serde(default,skip_serializing_if="crate::color_curves::no_overrides")]
    pub channel_luts: [Option<Vec<f32>>;5],
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sampled_lut: Option<Vec<[f32; 4]>>,
}
impl Default for CurveObject {
    fn default() -> Self {
        Self {
            channels: std::array::from_fn(|_| vec![[0.0, 0.0], [1.0, 1.0]]),
            sampled_lut: None,
            interpolation: [crate::color_curves::ColorInterpolation::NaturalCubic;5],
            channel_luts: std::array::from_fn(|_|None),
        }
    }
}
impl CurveObject {
    pub fn validate(&self) -> Result<()> {
        for lut in self.channel_luts.iter().flatten() {
            ensure(matches!(lut.len(), 256 | HIGH_PRECISION_CURVE_SAMPLES)&&lut.iter().all(|v|v.is_finite()&&(0. ..=1.).contains(v)),"invalid channel curve LUT")?;
        }
        if let Some(lut) = &self.sampled_lut {
            ensure(
                matches!(lut.len(), 256 | HIGH_PRECISION_CURVE_SAMPLES)
                    && lut
                        .iter()
                        .flatten()
                        .all(|v| v.is_finite() && (0.0..=1.0).contains(v)),
                "invalid frozen curve LUT",
            )?;
        }
        for c in &self.channels {
            ensure((2..=64).contains(&c.len()), "curve requires 2..64 points")?;
            ensure(
                c.first().is_some_and(|p| p[0] == 0.0)
                    && c.last().is_some_and(|p| p[0] == 1.0),
                "curve must cover the unit interval",
            )?;
            for p in c {
                ensure(
                    p.iter().all(|v| v.is_finite() && (0.0..=1.0).contains(v)),
                    "invalid curve point",
                )?;
            }
            ensure(
                c.windows(2).all(|p| p[0][0] < p[1][0]),
                "curve X coordinates must be strictly increasing",
            )?;
        }
        Ok(())
    }
    pub fn lut(&self) -> Result<CurveLut> {
        self.validate()?;
        if let Some(lut) = &self.sampled_lut {
            return Ok(std::array::from_fn(|i| curve_sampling::frozen_at(lut, i as f32 / 255.)));
        }
        let curves:[crate::color_curves::Transfer;5]=std::array::from_fn(|i|crate::color_curves::Transfer::new(&self.channels[i],self.interpolation[i],self.channel_luts[i].as_deref()));
        Ok(std::array::from_fn(|i| {
            let v = i as f32 / 255.0;
            let master = curves[0].at(v);
            [
                curves[1].at(master),
                curves[2].at(master),
                curves[3].at(master),
                curves[4].at(v),
            ]
        }))
    }
    /// Turn a frozen/interpolated LUT into independently editable channels.
    /// Untouched channels retain their complete stored grid rather than being fitted.
    pub fn editable(&self)->Result<Self> {
        self.validate()?;
        let Some(lut)=&self.sampled_lut else{return Ok(self.clone());};
        let mut result=Self::default();result.interpolation=crate::color_curves::legacy_modes();
        for channel in 1..5 {
            let values:Vec<_>=lut.iter().map(|row|row[channel-1]).collect();
            let last = values.len() - 1;
            result.channels[channel]=(0..64).map(|i|{let index=if last==255 && i<63{i*4}else{i*last/63};[index as f32/last as f32,values[index]]}).collect();
            result.channel_luts[channel]=Some(values);
        }
        Ok(result)
    }
    pub fn graph(&self)->Result<serde_json::Value> {
        let value=self.editable()?;
        let names=["RGB","R","G","B","Alpha"];
        let curves:Vec<_>=(0..5).map(|i|{
            let curve=crate::color_curves::Transfer::new(&value.channels[i],value.interpolation[i],value.channel_luts[i].as_deref());
            serde_json::json!({"channel":i,"name":names[i],"interpolation":value.interpolation[i],
                "lookup":value.channel_luts[i].is_some(),"points":value.channels[i],"segments":curve.segments(),
                "samples":(0..256).map(|j|[j as f32/255.,curve.at(j as f32/255.)]).collect::<Vec<_>>()})
        }).collect();
        Ok(serde_json::json!({"version":1,"channels":curves,"editableValue":value,"outputLut":self.lut()?.to_vec(),
            "preparedFromLut":self.sampled_lut.is_some(),"colorMapping":"channel(master(input))","alphaMapping":"alpha(input_alpha)"}))
    }
}
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CurveTrack {
    pub value: CurveObject,
    pub keys: Vec<Keyframe<CurveObject>>,
}
impl Default for CurveTrack {
    fn default() -> Self {
        Self {
            value: CurveObject::default(),
            keys: Vec::new(),
        }
    }
}
impl CurveTrack {
    pub fn sample(&self, frame: f64) -> Result<CurveLut> {
        self.sample_value(frame).map_err(|source| Error::ColorCurveSampling {
            frame, source: Box::new(source),
        })
    }
    fn sample_value(&self, frame: f64) -> Result<CurveLut> {
        if self.keys.is_empty() {
            return self.value.lut();
        }
        let upper = self.keys.partition_point(|k| f64::from(k.frame) <= frame);
        if upper == 0 {
            return self.keys.first().ok_or_else(|| Error::Invalid(
                format!("color curve sample frame={frame}: first key is missing")))?.value.lut();
        }
        if upper >= self.keys.len() {
            return self.keys.last().ok_or_else(|| Error::Invalid(
                format!("color curve sample frame={frame}: last key is missing")))?.value.lut();
        }
        let a = upper.checked_sub(1).and_then(|i| self.keys.get(i))
            .ok_or_else(|| Error::Invalid(format!("color curve sample frame={frame}: predecessor is missing")))?;
        let b = self.keys.get(upper)
            .ok_or_else(|| Error::Invalid(format!("color curve sample frame={frame}: successor is missing")))?;
        ensure(a.frame < b.frame, "color curve sample interval must increase")?;
        let t = ((frame - f64::from(a.frame)) / (f64::from(b.frame) - f64::from(a.frame))) as f32;
        let t = a
            .curve
            .map_or_else(|| a.ease.map(t), |c| c.sample(f64::from(t)).progress as f32);
        let aa = a.value.lut()?;
        let bb = b.value.lut()?;
        Ok(std::array::from_fn(|i| std::array::from_fn(|c| aa[i][c] + (bb[i][c] - aa[i][c]) * t)))
    }
    fn validate(&self, _frames: u32) -> Result<()> {
        self.value.validate()?;
        ensure(
            self.keys.len() <= crate::MAX_FRAMES as usize,
            "too many curve keys",
        )?;
        let mut last = None;
        for k in &self.keys {
            ensure(k.spatial.is_none(), "color transfer curves do not support spatial tangents")?;
            ensure(last.is_none_or(|v| v < k.frame), "invalid curve key time")?;
            k.value.validate()?;
            if let Some(c) = k.curve {
                c.validate()?;
            }
            last = Some(k.frame);
        }
        Ok(())
    }
}
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EffectParam {
    pub kind: ParamKind,
    pub animatable: bool,
    pub min: f32,
    pub max: f32,
    pub implemented: bool,
    pub default: [f32; 4],
    pub track: Track<[f32; 4]>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub curve: Option<CurveTrack>,
}
impl EffectParam {
    pub fn sample(&self, frame: f64) -> Result<[f32; 4]> {
        if self.kind.discrete() {
            ensure(self.track.axes.is_none(), "discrete effect parameters cannot separate dimensions")?;
            let i = self
                .track
                .keys
                .partition_point(|k| f64::from(k.frame) <= frame);
            return Ok(if self.track.keys.is_empty() {
                self.track.value
            } else {
                self.track.keys[i.saturating_sub(1)].value
            });
        }
        let mut value = self.track.sample(frame)?;
        for v in &mut value[..self.kind.dimensions()] {
            *v = v.clamp(self.min, self.max);
        }
        Ok(value)
    }
    fn validate(&self, frames: u32) -> Result<()> {
        ensure(
            self.min.is_finite() && self.max.is_finite() && self.min <= self.max,
            "invalid effect parameter range",
        )?;
        self.track.validate_local()?;
        for k in &self.track.keys {
            if let Some(s) = &k.spatial {
                ensure(matches!(self.kind, ParamKind::Vec2 | ParamKind::Vec3), "spatial paths require a vector parameter")?;
                for tangent in s.incoming.iter().chain(&s.outgoing) {
                    ensure(self.kind.valid_value(&k.value.add(*tangent), self.min, self.max), "spatial control exceeds effect parameter range")?;
                }
            }
        }
        ensure(
            self.animatable || self.track.keys.is_empty(),
            "effect parameter is not animatable",
        )?;
        for value in
            std::iter::once(self.track.value).chain(self.track.keys.iter().map(|k| k.value))
        {
            ensure(
                self.kind.valid_value(&value, self.min, self.max),
                "effect parameter exceeds range or discrete value is not integral",
            )?;
            if self.kind.discrete() {
                ensure(
                    value[0].fract() == 0.0,
                    "discrete effect parameter must be integral",
                )?;
            }
            ensure(
                self.implemented || value == self.default,
                "this AE parameter is not implemented",
            )?;
        }
        if let Some(c) = &self.curve {
            ensure(
                self.kind == ParamKind::Curve,
                "curve data attached to a non-curve parameter",
            )?;
            c.validate(frames)?;
            ensure(
                self.animatable || c.keys.is_empty(),
                "curve parameter is not animatable",
            )?;
        }
        ensure(
            (self.kind == ParamKind::Curve) == self.curve.is_some(),
            "curve parameter must contain curve data",
        )?;
        Ok(())
    }
}
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum EffectImageStage {
    Source,
    #[default]
    Effects,
}
/// Resource-0 override. Effects-stage inputs form a same-frame DAG, before
/// transforms/opacity. Source-stage inputs have no recursive dependency.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
pub enum EffectImageInput {
    Layer { layer: u64, stage: EffectImageStage },
    Asset { asset: u64 },
    Empty,
}
impl EffectImageInput {
    pub fn layer(self) -> Option<u64> { if let Self::Layer { layer, .. } = self { Some(layer) } else { None } }
}
pub fn clear_layer_image_inputs(layers: &mut [Layer], source: u64) {
    for layer in layers {
        for effect in &mut layer.effects {
            if effect.image_input.and_then(EffectImageInput::layer) == Some(source) {
                effect.image_input = Some(EffectImageInput::Empty);
            }
        }
    }
}
pub(crate) fn validate_image_graph(project: &crate::Project) -> Result<()> {
    fn visit(project: &crate::Project, id: u64, marks: &mut BTreeMap<u64, u8>) -> Result<()> {
        match marks.get(&id) {
            Some(1) => return Err(Error::Invalid("effect image input cycle".into())),
            Some(2) => return Ok(()),
            _ => {}
        }
        marks.insert(id, 1);
        if let Some(layer) = project.layers.iter().find(|l| l.id == id) {
            for e in layer.effects.iter().filter(|e| e.enabled) {
                if let Some(EffectImageInput::Layer {
                    layer,
                    stage: EffectImageStage::Effects,
                }) = e.image_input
                {
                    visit(project, layer, marks)?;
                }
            }
        }
        marks.insert(id, 2);
        Ok(())
    }
    let mut marks = BTreeMap::new();
    for layer in &project.layers {
        visit(project, layer.id, &mut marks)?;
    }
    Ok(())
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct EffectInstance {
    pub id: u64,
    pub plugin: String,
    pub effect: String,
    pub version: String,
    pub hash: String,
    pub enabled: bool,
    pub seed: u32,
    pub params: BTreeMap<String, EffectParam>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub image_input: Option<EffectImageInput>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub scene: Option<motion_effects::SceneSettings>,
    #[serde(default, skip_serializing_if="Option::is_none")]
    pub node_graph: Option<serde_json::Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub shader_data: Option<std::sync::Arc<motion_effects::shader_data::ShaderDataValues>>,
}
impl EffectInstance {
    pub fn new(
        id: u64,
        plugin: &str,
        version: &str,
        hash: &str,
        definition: &EffectDefinition,
        size: [f32; 2],
    ) -> Self {
        let params = definition
            .params
            .iter()
            .map(|p| {
                let mut value = p.default;
                if let Some(v) = p.relative_default {
                    value[0] = v[0] * size[0];
                    value[1] = v[1] * size[1];
                } else if p.center_default {
                    value[0] = size[0] * 0.5;
                    value[1] = size[1] * 0.5;
                }
                (
                    p.id.clone(),
                    EffectParam {
                        kind: p.kind,
                        animatable: p.animatable,
                        min: p.min,
                        max: p.max,
                        implemented: p.implemented,
                        default: value,
                        track: Track::constant(value),
                        curve: if p.kind == ParamKind::Curve {
                            Some(CurveTrack::default())
                        } else {
                            None
                        },
                    },
                )
            })
            .collect();
        Self {
            id,
            plugin: plugin.into(),
            effect: definition.id.clone(),
            version: version.into(),
            hash: hash.into(),
            enabled: true,
            seed: id as u32,
            params,
            image_input: None,
            scene: definition.scene.clone(),
            node_graph: None,
            shader_data: None,
        }
    }
    pub fn dependency(&self) -> PluginDependency {
        PluginDependency {
            plugin: self.plugin.clone(),
            version: self.version.clone(),
            hash: self.hash.clone(),
        }
    }
    pub fn validate(&self, frames: u32) -> Result<()> {
        if let Some(data) = &self.shader_data { data.validate().map_err(|error| Error::Invalid(error.to_string()))?; }
        ensure(
            self.id != 0
                && motion_effects::valid_id(&self.plugin)
                && motion_effects::valid_id(&self.effect),
            "invalid effect identity",
        )?;
        ensure(
            self.version.len() <= 64
                && self.hash.len() == 64
                && self.hash.bytes().all(|v| v.is_ascii_hexdigit()),
            "invalid effect version/hash",
        )?;
        ensure(
            self.params.len() <= MAX_PARAMS,
            "too many effect parameters",
        )?;
        if let Some(source) = &self.node_graph {
            ensure(
                source["format_version"] == 1
                    && source["key"].as_str().is_some_and(|key| !key.trim().is_empty() && key.len() <= 128)
                    && source["document"].is_object()
                    && source["options"].is_object(),
                "invalid editable node effect source",
            )?;
            ensure(serde_json::to_vec(source)?.len() <= 4 * 1024 * 1024,
                "node effect source exceeds 4 MiB")?;
        }
        if let Some(scene) = &self.scene {
            scene
                .validate()
                .map_err(|e| Error::Invalid(e.to_string()))?;
        }
        for (id, p) in &self.params {
            ensure(motion_effects::valid_id(id), "invalid effect parameter ID")?;
            p.validate(frames)?;
        }
        Ok(())
    }
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
pub enum EffectAction {
    /// Replace a compiled node effect and its source as one undoable edit.
    Replace { instance: EffectInstance },
    /// Preserve an unfinished graph without replacing the last valid shader.
    SetNodeGraph { effect: u64, source: serde_json::Value },
    SetImageInput {
        effect: u64,
        input: Option<EffectImageInput>,
    },
    SetScene {
        effect: u64,
        scene: motion_effects::SceneSettings,
    },
    Seed {
        effect: u64,
        seed: u32,
    },
    Insert {
        instance: EffectInstance,
    },
    Remove {
        effect: u64,
    },
    Duplicate {
        effect: u64,
    },
    Move {
        effect: u64,
        index: usize,
    },
    Enable {
        effect: u64,
        enabled: bool,
    },
    Set {
        effect: u64,
        param: String,
        frame: u32,
        value: [f32; 4],
    },
    /// Restore one literal color's complete track when a scoped picker cancels.
    RestoreColorTrack {
        effect: u64,
        param: String,
        track: Track<[f32; 4]>,
    },
    RestoreParameterTrack { effect: u64, param: String, track: Track<[f32; 4]> },
    Animate {
        effect: u64,
        param: String,
        frame: u32,
        enabled: bool,
    },
    DeleteKey {
        effect: u64,
        param: String,
        frame: u32,
    },
    MoveKey {
        effect: u64,
        param: String,
        from: u32,
        to: u32,
    },
    CopyKey {
        effect: u64,
        param: String,
        from: u32,
        to: u32,
    },
    Curve {
        effect: u64,
        param: String,
        frame: u32,
        easing: Easing,
    },
    Spatial {
        effect: u64,
        param: String,
        frame: u32,
        tangents: Option<crate::SpatialTangents<[f32; 4]>>,
    },
    SetCurveObject {
        effect: u64,
        param: String,
        frame: u32,
        value: CurveObject,
    },
}
fn instance_mut(layer: &mut Layer, id: u64) -> Result<&mut EffectInstance> {
    layer
        .effects
        .iter_mut()
        .find(|e| e.id == id)
        .ok_or_else(|| Error::Invalid("effect instance does not exist".into()))
}
fn param_mut<'a>(layer: &'a mut Layer, id: u64, param: &str) -> Result<&'a mut EffectParam> {
    instance_mut(layer, id)?
        .params
        .get_mut(param)
        .ok_or_else(|| Error::Invalid("effect parameter does not exist".into()))
}
pub fn apply(layer: &mut Layer, action: EffectAction, frames: u32) -> Result<()> {
    ensure(!layer.locked, "object is locked")?;
    ensure(
        !matches!(layer.content, crate::Content::Null | crate::Content::Camera { .. }),
        "null and camera objects do not have image effects",
    )?;
    let clip = layer.clip(frames);
    let local = |f| {
        ensure(f < frames, "effect edit frame outside composition")?;
        clip.edit_frame(f)
    };
    match action {
        EffectAction::Replace { instance } => {
            instance.validate(frames)?;
            let current = instance_mut(layer, instance.id)?;
            *current = instance;
        }
        EffectAction::SetNodeGraph { effect, source } => {
            let instance = instance_mut(layer, effect)?;
            instance.node_graph = Some(source);
            instance.validate(frames)?;
        }
        EffectAction::RestoreParameterTrack { effect, param, track } => {
            let p = param_mut(layer, effect, &param)?;
            ensure(matches!(p.kind, ParamKind::Vec2 | ParamKind::Vec3), "parameter scope requires a vector parameter")?;
            p.track = track;
            p.validate(frames)?;
        }
        EffectAction::RestoreColorTrack { effect, param, track } => {
            let p = param_mut(layer, effect, &param)?;
            ensure(p.kind == ParamKind::Color, "color restoration requires a color parameter")?;
            p.track = track;
            p.validate(frames)?;
        }
        EffectAction::SetScene { effect, scene } => {
            scene
                .validate()
                .map_err(|e| Error::Invalid(e.to_string()))?;
            let instance = instance_mut(layer, effect)?;
            ensure(instance.scene.is_some(), "effect has no scene editor")?;
            instance.scene = Some(scene);
        }
        EffectAction::Seed { effect, seed } => instance_mut(layer, effect)?.seed = seed,
        EffectAction::SetImageInput { effect, input } => instance_mut(layer, effect)?.image_input = input,
        EffectAction::Insert { instance } => {
            ensure(
                layer.effects.len() < MAX_EFFECTS_PER_LAYER,
                "layer effect limit exceeded",
            )?;
            instance.validate(frames)?;
            ensure(
                !layer.effects.iter().any(|e| e.id == instance.id),
                "duplicate effect instance ID",
            )?;
            layer.effects.push(instance);
        }
        EffectAction::Remove { effect } => {
            instance_mut(layer, effect)?;
            layer.effects.retain(|e| e.id != effect);
        }
        EffectAction::Duplicate { effect } => {
            ensure(
                layer.effects.len() < MAX_EFFECTS_PER_LAYER,
                "layer effect limit exceeded",
            )?;
            let mut copy = instance_mut(layer, effect)?.clone();
            copy.id = layer
                .effects
                .iter()
                .map(|e| e.id)
                .max()
                .unwrap_or(0)
                .checked_add(1)
                .ok_or_else(|| Error::Invalid("effect ID space exhausted".into()))?;
            layer.effects.push(copy);
        }
        EffectAction::Move { effect, index } => {
            ensure(index < layer.effects.len(), "invalid effect destination")?;
            let from = layer
                .effects
                .iter()
                .position(|e| e.id == effect)
                .ok_or_else(|| Error::Invalid("effect does not exist".into()))?;
            let e = layer.effects.remove(from);
            layer.effects.insert(index, e);
        }
        EffectAction::Enable { effect, enabled } => instance_mut(layer, effect)?.enabled = enabled,
        EffectAction::Set {
            effect,
            param,
            frame,
            value,
        } => {
            let frame = local(frame)?;
            let p = param_mut(layer, effect, &param)?;
            ensure(
                p.kind != ParamKind::Curve,
                "use set_curve_object for curve parameters",
            )?;
            p.track.set_at(frame, value)?;
            if p.kind.discrete() {
                for k in &mut p.track.keys {
                    k.ease = Ease::Hold;
                    k.curve = None;
                }
            }
        }
        EffectAction::Animate {
            effect,
            param,
            frame,
            enabled,
        } => {
            let frame = local(frame)?;
            let p = param_mut(layer, effect, &param)?;
            ensure(p.animatable, "effect parameter is not animatable")?;
            if let Some(c) = &mut p.curve {
                if enabled && c.keys.is_empty() {
                    c.keys.push(Keyframe {
                        frame,
                        value: c.value.clone(),
                        ease: Ease::Linear,
                        curve: None,
                        spatial: None,
                    });
                } else if !enabled {
                    let frozen = c.sampled_curve(f64::from(frame))?.high_precision_lut();
                    let upper = c.keys.partition_point(|k| k.frame <= frame);
                    if !c.keys.is_empty() {
                        c.value = c.keys[upper.saturating_sub(1)].value.clone();
                    }
                    c.value.sampled_lut = Some(
                        frozen
                            .iter()
                            .map(|pixel| pixel.map(|v| v.clamp(0.0, 1.0)))
                            .collect(),
                    );
                    c.keys.clear();
                }
            } else {
                p.track.set_animated(frame, enabled)?;
                if p.kind.discrete() {
                    for k in &mut p.track.keys {
                        k.ease = Ease::Hold;
                    }
                }
            }
        }
        EffectAction::DeleteKey {
            effect,
            param,
            frame,
        } => {
            let frame = local(frame)?;
            let p = param_mut(layer, effect, &param)?;
            if let Some(c) = &mut p.curve {
                let i = c
                    .keys
                    .iter()
                    .position(|k| k.frame == frame)
                    .ok_or_else(|| Error::Invalid("curve key not found".into()))?;
                if c.keys.len() == 1 {
                    c.value = c.keys[i].value.clone();
                }
                c.keys.remove(i);
            } else {
                p.track.delete_key(frame)?;
            }
        }
        EffectAction::MoveKey {
            effect,
            param,
            from,
            to,
        } => {
            let from = local(from)?;
            let to = local(to)?;
            let p = param_mut(layer, effect, &param)?;
            if let Some(c) = &mut p.curve {
                let i = c
                    .keys
                    .iter()
                    .position(|k| k.frame == from)
                    .ok_or_else(|| Error::Invalid("curve key not found".into()))?;
                if from != to {
                    let destination = crate::animation::vacant_key_index(&c.keys, to)?;
                    let mut key = c.keys.remove(i);
                    key.frame = to;
                    c.keys.insert(destination - usize::from(i < destination), key);
                }
            } else {
                p.track.move_key(from, to)?;
            }
        }
        EffectAction::CopyKey {
            effect,
            param,
            from,
            to,
        } => {
            let from = local(from)?;
            let to = local(to)?;
            let p = param_mut(layer, effect, &param)?;
            if let Some(c) = &mut p.curve {
                let mut key = c
                    .keys
                    .iter()
                    .find(|k| k.frame == from)
                    .cloned()
                    .ok_or_else(|| Error::Invalid("curve key not found".into()))?;
                if from != to {
                    let destination = crate::animation::vacant_key_index(&c.keys, to)?;
                    key.frame = to;
                    c.keys.insert(destination, key);
                }
            } else {
                p.track.copy_key(from, to)?;
            }
        }
        EffectAction::Spatial { effect, param, frame, tangents } => {
            let frame = local(frame)?;
            let p = param_mut(layer, effect, &param)?;
            ensure(p.animatable && p.implemented && matches!(p.kind, ParamKind::Vec2 | ParamKind::Vec3), "spatial path requires an editable vector parameter")?;
            p.track.set_spatial(frame, tangents)?;
        }
        EffectAction::Curve {
            effect,
            param,
            frame,
            easing,
        } => {
            let frame = local(frame)?;
            let p = param_mut(layer, effect, &param)?;
            ensure(
                !p.kind.discrete(),
                "discrete parameters only support hold interpolation",
            )?;
            if let Some(c) = &mut p.curve {
                easing.validate()?;
                let i = c
                    .keys
                    .iter()
                    .position(|k| k.frame == frame)
                    .ok_or_else(|| Error::Invalid("curve key not found".into()))?;
                ensure(i + 1 < c.keys.len(), "curve requires adjacent keys")?;
                c.keys[i].ease = easing.ease;
                c.keys[i].curve = easing.curve;
            } else {
                p.track.set_curve(frame, easing)?;
            }
        }
        EffectAction::SetCurveObject {
            effect,
            param,
            frame,
            value,
        } => {
            let frame = local(frame)?;
            value.validate()?;
            let p = param_mut(layer, effect, &param)?;
            let c = p
                .curve
                .as_mut()
                .ok_or_else(|| Error::Invalid("not a curve-object parameter".into()))?;
            if c.keys.is_empty() {
                c.value = value;
            } else {
                let key = Keyframe {
                    frame,
                    value,
                    ease: Ease::Linear,
                    curve: None,
                    spatial: None,
                };
                match c.keys.binary_search_by_key(&frame, |k| k.frame) {
                    Ok(i) => c.keys[i] = key,
                    Err(i) => c.keys.insert(i, key),
                }
            }
        }
    }
    Ok(())
}

#[derive(Clone, Debug)]
pub struct SampledEffect {
    pub shader_data: Option<std::sync::Arc<motion_effects::shader_data::ShaderDataValues>>,
    pub layer: u64,
    pub local_frame: f64,
    pub instance: u64,
    pub plugin: String,
    pub effect: String,
    pub version: String,
    pub hash: String,
    pub enabled: bool,
    pub seed: u32,
    pub image_input: Option<EffectImageInput>,
    pub param_ids: Vec<String>,
    pub values: [[f32; 4]; MAX_PARAMS],
    pub lut: Option<usize>,
    pub scene: Option<motion_effects::SceneSettings>,
    pub particle_history: Option<std::sync::Arc<crate::particle_history::ParticleHistory>>,
    pub particle_history_error: Option<std::sync::Arc<crate::Error>>,
}
impl SampledEffect {
    pub fn new(layer: u64, e: &EffectInstance) -> Self {
        Self {
            shader_data: e.shader_data.clone(),
            layer,
            local_frame: 0.0,
            instance: e.id,
            plugin: e.plugin.clone(),
            effect: e.effect.clone(),
            version: e.version.clone(),
            hash: e.hash.clone(),
            enabled: e.enabled,
            seed: e.seed,
            image_input: e.image_input,
            param_ids: e.params.keys().cloned().collect(),
            values: [[0.0; 4]; MAX_PARAMS],
            lut: None,
            scene: e.scene.clone(),
            particle_history: None,
            particle_history_error: None,
        }
    }
    pub fn matches(&self, layer: u64, e: &EffectInstance) -> bool {
        self.layer == layer
            && self.instance == e.id
            && self.plugin == e.plugin
            && self.effect == e.effect
            && self.version == e.version
            && self.hash == e.hash
            && self
                .param_ids
                .iter()
                .map(String::as_str)
                .eq(e.params.keys().map(String::as_str))
    }
}
pub(crate) fn dependencies<'a>(layers: impl IntoIterator<Item = &'a Layer>) -> Vec<PluginDependency> {
    layers
        .into_iter()
        .flat_map(|l| l.effects.iter().map(EffectInstance::dependency))
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect()
}
