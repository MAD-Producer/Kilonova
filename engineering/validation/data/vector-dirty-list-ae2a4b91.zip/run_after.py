from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
out=Path(__file__).resolve().parent;work=Path.cwd()
assert work==Path('E:/Dev/aem/.worktrees/vector-dirty-list')
old=json.loads((out/'before-source-freeze.json').read_text(encoding='utf-8'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def freeze():return {p:digest(work/p) for p in old['hashes']}
current=freeze();assert [p for p in current if current[p]!=old['hashes'][p]]==['crates/motion-render/src/layer_gpu.rs']
assert digest(work/'crates/motion-render/examples/vector_dirty_comparison.rs')==old['benchmark_sha256']
(out/'after-source-freeze.json').write_text(json.dumps(dict(head=old['head'],hashes=current,benchmark_sha256=old['benchmark_sha256']),indent=2),encoding='utf-8')
env=os.environ.copy();env.pop('WGPU_BACKEND',None);env.pop('MOTION_LOG',None);env['CARGO_TERM_COLOR']='never'
cmd=json.loads((out/'before-build-receipt.json').read_text(encoding='utf-8'))['command'];start=time.monotonic()
with (out/'after-build.log').open('w',encoding='utf-8') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
r=dict(head=old['head'],command=cmd,exit_code=p.returncode,seconds=round(time.monotonic()-start,2),source_unchanged=freeze()==current,log_sha256=digest(out/'after-build.log'))
(out/'after-build-receipt.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
assert p.returncode==0 and r['source_unchanged'],r
binary=out/'after.exe';shutil.copyfile(Path(env['CARGO_TARGET_DIR'])/'debug/examples/vector_dirty_comparison.exe',binary)
r['binary_sha256']=digest(binary);start=time.monotonic()
with (out/'after-run.log').open('w',encoding='utf-8') as log:p=subprocess.run([str(binary),str(out/'after')],stdout=log,stderr=subprocess.STDOUT,env=env)
r.update(run_exit_code=p.returncode,run_seconds=round(time.monotonic()-start,2),source_unchanged=freeze()==current,run_log_sha256=digest(out/'after-run.log'))
(out/'after-receipt.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
assert p.returncode==0 and r['source_unchanged'],r
before=json.loads((out/'before/report.json').read_text(encoding='utf-8'));after=json.loads((out/'after/report.json').read_text(encoding='utf-8'))
cases=[]
for a,b in zip(before,after,strict=True):
 for key in ['layers','captures','texture_bytes','reduced_texture_bytes','empty_texture_bytes','texture_breakdown','encoded_upload_bytes','static_repeated_frames','static_encoded_upload_unchanged']:
  assert a[key]==b[key],(key,a[key],b[key])
 for phase in ['warm_upload_info','animated_upload_info']:
  for key in ['destinationBuffersCreatedTotal','vertexCapacityBytes','opacityCapacityBytes','encodedUploadBytesTotal']:
   assert a[phase][key]==b[phase][key],(phase,key,a[phase][key],b[phase][key])
 cases.append(dict(layers=a['layers'],captures=a['captures'],before_allocations=a['allocations'],after_allocations=b['allocations'],before_allocated_bytes=a['allocated_bytes'],after_allocated_bytes=b['allocated_bytes'],encoded_upload_bytes=a['encoded_upload_bytes'],destination_buffers_created_total=b['animated_upload_info']['destinationBuffersCreatedTotal']))
pixels=[]
for p in sorted((out/'before').rglob('*.rgba')):
 relative=p.relative_to(out/'before');target=out/'after'/relative
 assert p.read_bytes()==target.read_bytes(),str(relative)
 pixels.append(dict(file=relative.as_posix(),bytes=p.stat().st_size,sha256=digest(p)))
assert len(pixels)==72
(out/'comparison.json').write_text(json.dumps(dict(cases=cases,pixels=pixels,all_pixels_and_texture_accounting_identical=True,destination_buffers_and_encoded_bytes_identical=True,static_control_uploads_unchanged=True,counting='current-thread Rust alloc/alloc_zeroed/realloc requests during 20 actual animated captures; Scene sampling, fixture setup, assertions and file IO outside counter; dev build, not all native allocations or an FPS claim'),indent=2),encoding='utf-8')
print(json.dumps(cases),flush=True)
print('72 full RGBA buffers, texture accounting and destination buffers matched',flush=True)
