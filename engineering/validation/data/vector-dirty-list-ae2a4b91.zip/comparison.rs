use motion_core::{vector::{ShapeKind, VectorContent}, Content, Ease, Layer, Project, Track};
use motion_render::{Renderer, Scene};
use std::{alloc::{GlobalAlloc, Layout, System}, cell::Cell, path::PathBuf};

thread_local! {
    static MEASURING: Cell<bool> = const { Cell::new(false) };
    static ALLOCS: Cell<u64> = const { Cell::new(0) };
    static BYTES: Cell<u64> = const { Cell::new(0) };
}
struct Allocator;
fn record(bytes: usize) {
    if MEASURING.try_with(Cell::get).unwrap_or(false) {
        let _ = ALLOCS.try_with(|n| n.set(n.get().saturating_add(1)));
        let _ = BYTES.try_with(|n| n.set(n.get().saturating_add(bytes as u64)));
    }
}
unsafe impl GlobalAlloc for Allocator {
    unsafe fn alloc(&self, l: Layout) -> *mut u8 { record(l.size()); unsafe { System.alloc(l) } }
    unsafe fn alloc_zeroed(&self, l: Layout) -> *mut u8 { record(l.size()); unsafe { System.alloc_zeroed(l) } }
    unsafe fn dealloc(&self, p: *mut u8, l: Layout) { unsafe { System.dealloc(p, l) } }
    unsafe fn realloc(&self, p: *mut u8, l: Layout, n: usize) -> *mut u8 { record(n); unsafe { System.realloc(p, l, n) } }
}
#[global_allocator] static ALLOCATOR: Allocator = Allocator;
struct Measure;
impl Drop for Measure { fn drop(&mut self) { MEASURING.set(false); } }

fn project(layers: usize) -> Project {
    let mut p = Project::new(128, 128, 30, 60).unwrap();
    p.background = [0.; 4];
    for i in 0..layers {
        let mut layer = Layer::solid(i as u64 + 1, "animated vector fixture", [8.; 2],
            [(i % 16) as f32 * 8. + 4., (i / 16) as f32 * 8. + 4., 0.], [1.; 4]);
        let mut vector = VectorContent::shape(ShapeKind::Rectangle);
        let mut fill = Track::constant([0.1, 0.25, 0.5, 1.]);
        fill.upsert(0, [0.1, 0.25, 0.5, 1.], Ease::Linear).unwrap();
        fill.upsert(30, [0.9, 0.25, 0.5, 1.], Ease::Linear).unwrap();
        vector.fill = Some(fill);
        vector.stroke = None;
        layer.content = Content::Vector { vector };
        p.layers.push(layer);
    }
    p.validate().unwrap(); p
}
fn sample(p: &Project, frame: f64) -> Scene {
    let mut s = Scene::new(p).unwrap();
    s.sample(p, frame, None, &motion_core::ExpressionEvaluator).unwrap(); s
}
fn main() {
    let out = PathBuf::from(std::env::args_os().nth(1).expect("output directory"));
    std::fs::create_dir_all(&out).unwrap();
    let mut reports = Vec::new();
    let mut one_layer_upload = None;
    for layers in [1, 64, 128] {
        let case = out.join(layers.to_string()); std::fs::create_dir_all(&case).unwrap();
        let p = project(layers);
        let mut renderer = pollster::block_on(Renderer::headless()).unwrap();
        let target = renderer.capture_target(128, 128).unwrap();
        let mut s = sample(&p, 0.);
        let initial = renderer.capture(&s, &target).unwrap().0;
        assert!(initial.chunks_exact(4).any(|v| v[3] != 0));
        std::fs::write(case.join("00-initial.rgba"), &initial).unwrap();
        for _ in 0..3 { assert_eq!(renderer.capture(&s, &target).unwrap().0, initial); }
        let warm = renderer.vector_upload_info().unwrap();
        let texture_bytes = renderer.texture_bytes();
        let texture_breakdown = serde_json::to_value(renderer.texture_memory_breakdown()).unwrap();
        let mut previous = initial;
        let mut cumulative = Vec::with_capacity(20);
        ALLOCS.set(0); BYTES.set(0);
        for frame in 1..=20 {
            s.sample(&p, frame as f64, None, &motion_core::ExpressionEvaluator).unwrap();
            let before = renderer.vector_upload_info().unwrap().encoded_upload_bytes_total;
            MEASURING.set(true); let guard = Measure;
            let pixels = renderer.capture(&s, &target).unwrap().0;
            drop(guard);
            cumulative.push((ALLOCS.get(), BYTES.get()));
            assert_ne!(pixels, previous, "animation did not change frame {frame}");
            assert!(renderer.vector_upload_info().unwrap().encoded_upload_bytes_total > before,
                "frame {frame} never entered actual vector upload/draw");
            std::fs::write(case.join(format!("{frame:02}-animated.rgba")), &pixels).unwrap();
            previous = pixels;
        }
        let allocations = ALLOCS.get(); let allocated_bytes = BYTES.get();
        let animated = renderer.vector_upload_info().unwrap();
        assert_eq!(animated.destination_buffers_created_total, warm.destination_buffers_created_total);
        assert_eq!(animated.vertex_capacity_bytes, warm.vertex_capacity_bytes);
        assert_eq!(renderer.texture_bytes(), texture_bytes);
        assert_eq!(serde_json::to_value(renderer.texture_memory_breakdown()).unwrap(), texture_breakdown);
        let uploaded = animated.encoded_upload_bytes_total - warm.encoded_upload_bytes_total;
        if layers == 1 { one_layer_upload = Some(uploaded); }
        assert_eq!(uploaded, one_layer_upload.unwrap() * layers as u64, "not all requested vector layers were drawn");
        for _ in 0..3 { assert_eq!(renderer.capture(&s, &target).unwrap().0, previous); }
        assert_eq!(renderer.vector_upload_info().unwrap().encoded_upload_bytes_total, animated.encoded_upload_bytes_total,
            "static cache control unexpectedly uploaded vectors");
        let mut reduced = p.clone(); reduced.layers.truncate(layers / 2);
        let removed = renderer.capture(&sample(&reduced, 20.), &target).unwrap().0;
        let reduced_bytes = renderer.texture_bytes(); assert!(reduced_bytes < texture_bytes);
        std::fs::write(case.join("21-removed.rgba"), &removed).unwrap();
        assert_eq!(renderer.capture(&s, &target).unwrap().0, previous);
        reduced.layers.clear();
        let empty = renderer.capture(&sample(&reduced, 20.), &target).unwrap().0;
        assert!(empty.iter().all(|v| *v == 0)); assert_eq!(renderer.texture_bytes(), 4);
        std::fs::write(case.join("22-empty.rgba"), empty).unwrap();
        renderer.clear_assets();
        let recovered = renderer.capture(&s, &target).unwrap().0;
        assert_eq!(recovered, previous);
        std::fs::write(case.join("23-recovered.rgba"), recovered).unwrap();
        renderer.check_health().unwrap();
        reports.push(serde_json::json!({"layers":layers,"captures":20,"allocations":allocations,
            "allocated_bytes":allocated_bytes,"cumulative":cumulative,"texture_bytes":texture_bytes,
            "reduced_texture_bytes":reduced_bytes,"empty_texture_bytes":4,"texture_breakdown":texture_breakdown,
            "warm_upload_info":warm,"animated_upload_info":animated,"encoded_upload_bytes":uploaded,
            "static_repeated_frames":3,"static_encoded_upload_unchanged":true}));
    }
    std::fs::write(out.join("report.json"), serde_json::to_vec_pretty(&reports).unwrap()).unwrap();
}
