from pathlib import Path
import hashlib, json, os, subprocess, time

out = Path(__file__).resolve().parent
work = Path.cwd()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == 'eb1e37b303b8fd942f53becd678d902c06db1ef4'
source = work / 'crates/motion-render/src/layer_gpu.rs'
source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
env = os.environ.copy()
env.pop('WGPU_BACKEND', None)
env.pop('MOTION_LOG', None)
env['CARGO_TERM_COLOR'] = 'never'
common = ['cargo', 'test', '-p', 'motion-render', '--no-default-features', '--features', 'gpu-tests', '--locked', '--offline', '-j1']
commands = [
    ('integrated-unit-vector', common + ['--lib', 'vector', '--', '--test-threads=1']),
    ('integrated-regressions', common + sum((['--test', name] for name in ['vector_upload_reuse', 'vector_groups', 'vector_adjustment', 'vector_budget_alignment', 'vector_error_boundaries', 'working_precision', 'precision_switch']), []) + ['--', '--test-threads=1']),
    ('integrated-fixture-build', ['cargo', 'build', '-p', 'motion-render', '--example', 'vector_dirty_comparison', '--no-default-features', '--features', 'gpu-tests', '--locked', '--offline', '-j1']),
    ('integrated-fixture-run', [str(Path(env['CARGO_TARGET_DIR']) / 'debug/examples/vector_dirty_comparison.exe'), str(out / 'integrated')]),
]
for name, command in commands:
    receipt = out / (name + '-receipt.json')
    assert not receipt.exists(), f'Already attempted: {name}'
    start = time.monotonic()
    log_path = out / (name + '.log')
    with log_path.open('w', encoding='utf-8') as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
    record = dict(head=head, source_sha256=source_hash, command=command, exit_code=result.returncode,
                  seconds=round(time.monotonic()-start, 2), log_sha256=hashlib.sha256(log_path.read_bytes()).hexdigest(),
                  source_unchanged=hashlib.sha256(source.read_bytes()).hexdigest() == source_hash)
    receipt.write_text(json.dumps(record, indent=2), encoding='utf-8')
    print(json.dumps(dict(name=name, **record)), flush=True)
    assert result.returncode == 0 and record['source_unchanged'], record
