from pathlib import Path
import hashlib, json, re, subprocess, zipfile

out = Path(__file__).resolve().parent
work = Path('E:/Dev/aem/.worktrees/vector-dirty-list')
dest = work / 'engineering/validation'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
comparison = json.loads((out/'comparison.json').read_text(encoding='utf-8'))
receipts = {}
tests = []
for name in ['integrated-unit-vector', 'integrated-regressions', 'integrated-fixture-build', 'integrated-fixture-run']:
    receipts[name] = json.loads((out/(name+'-receipt.json')).read_text(encoding='utf-8'))
    assert receipts[name]['exit_code'] == 0 and receipts[name]['source_unchanged']
    if name in ['integrated-unit-vector', 'integrated-regressions']:
        log = (out/(name+'.log')).read_text(encoding='utf-8')
        rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
        assert rows
        tests.append(dict(name=name, targets=len(rows), passed=sum(int(r[0]) for r in rows),
                          failed=sum(int(r[1]) for r in rows), ignored=sum(int(r[2]) for r in rows)))
assert all(r['failed']==0 for r in tests)
assert sum(len(list((out/p).rglob('*.rgba'))) for p in ['before','after']) == 144
integrated = json.loads((out/'integrated/report.json').read_text(encoding='utf-8'))
assert [r['layers'] for r in integrated] == [1,64,128]
assert all(r['static_encoded_upload_unchanged'] for r in integrated)
record = dict(issue=126, comparison_base='ae2a4b91591812acd190629dc0dade6377095072',
              integrated_base='7bd4d86003b21dd02483e73cbccac730df7036a7',
              integrated_product_head=receipts['integrated-regressions']['head'],
              source_sha256=digest(work/'crates/motion-render/src/layer_gpu.rs'),
              comparison=comparison, tests=tests, receipts=receipts,
              limits=['Comparison is against the frozen older base, not the later integrated main.',
                      'Current-thread Rust allocation requests only; no FPS claim; whole-frame allocations still scale with layer count.',
                      'Original GPU-buffer reuse is existing coverage, not introduced by this patch.',
                      'No new logging or failure swallowing. Error, empty scene, oversized list and release drop retained CPU storage.',
                      'First prototype compile failure is preserved; fixed by using existing motion_model dependency.'])
items = ['comparison.rs','run_baseline.py','run_after.py','run_integrated.py','package_evidence.py',
         'before-build.log','before-build-receipt.json','before-run.log','before-receipt.json','before-source-freeze.json',
         'after-build.log','after-build-receipt.json','after-run.log','after-receipt.json','after-source-freeze.json',
         'comparison.json','original-layer-gpu.rs','first-prototype-layer-gpu.rs','first-prototype-source-freeze.json',
         'first-compile-failure.log','first-compile-failure-receipt.json']
items += [name+suffix for name in receipts for suffix in ['.log','-receipt.json']]
items += [p.relative_to(out).as_posix() for folder in ['before','after','integrated'] for p in sorted((out/folder).rglob('*')) if p.is_file()]
assert all(not p.endswith(('.exe','.dll')) for p in items)
archive = dest/'data/vector-dirty-list-ae2a4b91.zip'
archive.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in items:
        z.write(out/name,name)
record['archive'] = dict(file=archive.name, bytes=archive.stat().st_size,sha256=digest(archive),files=len(items))
(dest/'vector-dirty-list-results.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rows='\n'.join(f"| {r['layers']} | {r['before_allocations']} → {r['after_allocations']} | {r['before_allocated_bytes']} → {r['after_allocated_bytes']} | {r['encoded_upload_bytes']} |" for r in comparison['cases'])
test_rows='\n'.join(f"- `{r['name']}`：{r['targets']} 个目标，{r['passed']} 通过、{r['failed']} 失败、{r['ignored']} 忽略。" for r in tests)
text=f'''# 矢量重绘临时列表复用验收

日期：2026-10-25。关联 #126，仅覆盖 `LayerGpu::prepare_vectors` 的 CPU 重绘索引列表，不关闭合集。

## 实现与边界

主线已有指纹判断、矢量目标缓冲复用与静态帧不重绘；本次只让重绘索引列表复用空的存储。判断仍在纹理替换之前完成，后面的 GPU 绘制、上传、指纹更新及返回值保持原语义。成功后清空索引，仅在非空场景且容量不超过 `motion_model::MAX_LAYERS` 时保留；当前上限 128，在 64 位平台最多保留 1 KiB。失败、空场景、超大列表及显式 release 均释放这部分存储；组合展开超过上限时仍正确处理，只放弃保留容量。没有额外 GPU 资源、重试、吞错或新依赖。

开始前审计 406 个引用、114 个工作树，15 个文件版本、8 个重绘判断版本；没有重复方案。原有同文件精度 PR #489 修改格式与字节预算，不修改重绘判断和绘制循环。其后 #484、#488、#489、#490、#491 均已合并，补丁已无冲突移植到 `7bd4d860`，产品提交 `{record['integrated_product_head']}` 的集成验证另列如下。

## 冻结基线的前后对照

对照基线 `ae2a4b91591812acd190629dc0dade6377095072`，相同工具链、相同临时程序、相同开发构建。每组先预热，再真实 capture 20 个填充动画帧；Scene 采样、断言和文件写入不在计数区间。只统计调用线程的 Rust alloc / alloc_zeroed / realloc 请求及请求字节，不统计驱动、其他线程和全部原生分配；不推断帧率。

| 矢量层数 | 20 帧分配请求：前 → 后 | 请求字节：前 → 后 | 实际新增编码上传字节 |
| --- | --- | --- | --- |
{rows}

每帧像素实际变化，上传字节随层数精确增长，确认所有请求图层进入上传/绘制。全帧统计可能包含其他路径的波动，不把差值归结为固定每帧节省。整体分配仍随层数增长，这是局部改进。

每侧 72 个完整 RGBA 缓冲、4,718,592 字节逐字节一致，包括初始帧、20 个动画帧、删除图层、空场景和清理恢复。纹理记账、顶点容量、目标缓冲创建计数和上传字节一致。三次静态重复帧不上传，属于已有行为。清空场景后透明输出与默认 4 字节资源记账均由程序断言。

## 最新主线集成验证

Windows 本机真实 GPU，明确启用 `gpu-tests`，离线锁定依赖、串行运行。执行命令、源码散列、完整日志和退出码见 [结果清单](vector-dirty-list-results.json)。集成运行与上述旧基线对照分开记录，不把旧基线的数值冒充最新主线的性能。

{test_rows}
- 七个集成目标覆盖矢量上传复用、分组、调整、精确预算、错误边界、四档工作精度与同设备精度切换；已有断言全部保留。
- 同一 1/64/128 层动画程序在最新集成提交再次运行成功，覆盖上传、静态对照、删层、空场景、clear_assets 与恢复。该次没有对应的新主线未改版本配对，不作新的性能对比。
- 首次原型编译因误用仅在测试依赖中可用的 `motion_core::MAX_LAYERS` 失败，原始失败日志和原型源码保留。已改为现有常规依赖 `motion_model::MAX_LAYERS`，未添加依赖或放宽检查。

## 审计分类与剩余工作

| ID | 处置 | 证据与边界 |
| --- | --- | --- |
| VDL-01 | 新增局部优化 | 有界空 CPU 列表复用；冻结版本前后实测、源码散列与完整像素对照。 |
| VDL-02 | 既有覆盖复验 | GPU 目标缓冲和指纹缓存已存在；不记为本次修复。 |
| VDL-03 | 正常分支 | 静态重复帧、空场景和主动释放不当作故障。 |
| VDL-04 | 功能与错误边界保持 | 原 `?` 错误传播、预算拒绝及恢复回归通过；没有新日志、超时、线程重启或返回值变更。未对新增日志作完成声明。 |
| VDL-05 | 待后续 | 全帧按层数增长的分配、#126 其余任务、跨 GPU 厂商和平台均未由本次完成。 |
| VDL-06 | 设计范围保持 | 不改 panels、属性行、主题、命中区或布局。DESIGN §0.7 各行 retained with reason：后端存储改动不涉及其文件；§12 产品界面视觉验收仍待对应任务验证。 |

程序、原始日志、首轮失败、完整像素与前后报告打包于 [验收原始材料](data/{archive.name})，SHA-256 `{digest(archive)}`。只包含独立编写的夹具和自产渲染数据，无可执行文件、DLL、第三方素材或 Adobe 资源。
'''
(dest/'vector-dirty-list-completed.md').write_text(text,encoding='utf-8')
print(json.dumps(dict(tests=tests,archive=record['archive']),ensure_ascii=False))
