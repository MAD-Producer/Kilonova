from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
out=Path(__file__).resolve().parent;work=Path.cwd()
assert work==Path('E:/Dev/aem/.worktrees/vector-dirty-list')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='ae2a4b91591812acd190629dc0dade6377095072'
assert subprocess.check_output(['git','status','--porcelain'],text=True).strip()==''
example=work/'crates/motion-render/examples/vector_dirty_comparison.rs';assert not example.exists()
shutil.copyfile(out/'comparison.rs',example)
files=subprocess.check_output(['git','ls-files','-z']).decode('utf-8').strip('\0').split('\0')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def freeze():return {p:digest(work/p) for p in files}
original=freeze();(out/'before-source-freeze.json').write_text(json.dumps(dict(head=head,hashes=original,benchmark_sha256=digest(example)),indent=2),encoding='utf-8')
env=os.environ.copy();env.pop('WGPU_BACKEND',None);env.pop('MOTION_LOG',None);env['CARGO_TERM_COLOR']='never'
cmd=['cargo','build','-p','motion-render','--example','vector_dirty_comparison','--no-default-features','--features','gpu-tests','--locked','--offline','-j1']
start=time.monotonic()
with (out/'before-build.log').open('w',encoding='utf-8') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
record=dict(head=head,command=cmd,exit_code=p.returncode,seconds=round(time.monotonic()-start,2),source_unchanged=freeze()==original,log_sha256=digest(out/'before-build.log'))
(out/'before-build-receipt.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
assert p.returncode==0 and record['source_unchanged'],record
binary=out/'before.exe';shutil.copyfile(Path(env['CARGO_TARGET_DIR'])/'debug/examples/vector_dirty_comparison.exe',binary)
record['binary_sha256']=digest(binary);start=time.monotonic()
with (out/'before-run.log').open('w',encoding='utf-8') as log:p=subprocess.run([str(binary),str(out/'before')],stdout=log,stderr=subprocess.STDOUT,env=env)
record.update(run_exit_code=p.returncode,run_seconds=round(time.monotonic()-start,2),run_log_sha256=digest(out/'before-run.log'),source_unchanged=freeze()==original)
(out/'before-receipt.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
assert p.returncode==0 and record['source_unchanged'],record
report=json.loads((out/'before/report.json').read_text(encoding='utf-8'))
print(json.dumps(record),flush=True)
print(json.dumps([{k:r[k] for k in ['layers','captures','allocations','allocated_bytes','encoded_upload_bytes']} for r in report]),flush=True)
