"""Serial, source-bound negative/fixed native proof; no P95 acceptance implied."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/prerender-input-priority'
OUT = ROOT / 'artifacts/pr-queue/prerender-input-priority-v1'
MAIN = WORK / 'desktop/app/src/main.rs'
INPUT = WORK / 'desktop/app/src/shell/prerender_input.rs'
HOOK = b'''        if self.window.as_ref().is_some_and(|window| window.id() == id)
            || self.floating.contains_key(&id)
        {
            self.observe_prerender_input(&event);
        }
'''
NAME = 'engine::prerender::tests::input_priority::native_input_preempts_before_action_generation_and_waits_for_its_present'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()

def sources():
    paths = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'], cwd=WORK).decode().split('\0')
    return {p:hashlib.sha256((WORK / p).read_bytes()).hexdigest() for p in paths
            if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml','.md')) or p == 'Cargo.lock')}

# Bind the existing controller handle now; do not overlap the active full gate.
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE,wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
owner = kernel.OpenProcess(0x100000,False,25708)
expected_head = git('rev-parse','HEAD')
fixed = sources()
original = MAIN.read_bytes()
input_original = INPUT.read_bytes()
# Git checkouts may use CRLF: preserve the file byte-for-byte in the finally block.
hook = HOOK if HOOK in original else HOOK.replace(b'\n',b'\r\n')
assert original.count(hook) == 1
redraw = b'                self.redraw();\n'
if redraw not in input_original:
    redraw = redraw.replace(b'\n',b'\r\n')
assert input_original.count(redraw) == 1
print(json.dumps(dict(waitingForOwner=25708,head=expected_head,sourceFiles=len(fixed))),flush=True)
if owner:
    try:
        while True:
            wait = kernel.WaitForSingleObject(owner,10000)
            if wait == 0:
                break
            assert wait == 258, f'owner wait failed: {wait}'
    finally:
        kernel.CloseHandle(owner)

previous = json.loads((ROOT / 'artifacts/pr-queue/prerender-combined-v4/exit.json').read_text(encoding='utf-8'))
assert previous.get('completedUtc') and previous['status'] != 'running'
assert sources() == fixed and git('rev-parse','HEAD') == expected_head
active = subprocess.check_output(['powershell','-NoProfile','-Command',
    "@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('cargo.exe','rustc.exe','link.exe') -and $_.CommandLine -match 'gltf-animation87-contract' }).Count"]).decode().strip()
assert active == '0', f'owned target still active: {active}'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
(OUT / 'main-fixed-source.rs').write_bytes(original)
(OUT / 'observer-fixed-source.rs').write_bytes(input_original)
env = os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',LOCALAPPDATA=str(OUT / 'owned-profile'),
           MOTION_PRERENDER_PRIORITY_ARTIFACTS=str(OUT / 'negative/native'))
Path(env['LOCALAPPDATA']).mkdir()
report = dict(head=expected_head,source=fixed,steps=[],status='running',startedUtc=datetime.now(timezone.utc).isoformat(),
              limits='Controlled token native routing plus separate real warmup recovery. Existing input/playback P95 failures remain failures; not crash causality, whole-app or cross-platform acceptance.')
desktop = ['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--bin','motion-studio']

def save():
    (OUT / 'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')

def step(name,args,expected_source,expected_count=None,negative_reason=None):
    print(json.dumps(dict(start=name)),flush=True)
    folder = OUT / name
    folder.mkdir()
    started = datetime.now(timezone.utc).isoformat()
    with (folder / 'stdout.log').open('wb') as stdout, (folder / 'stderr.log').open('wb') as stderr:
        code = subprocess.run(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr).returncode
    raw = (folder / 'stdout.log').read_text(encoding='utf-8') + (folder / 'stderr.log').read_text(encoding='utf-8')
    counts = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',raw)
    unchanged = sources() == expected_source and git('rev-parse','HEAD') == expected_head
    if negative_reason:
        good = (code != 0 and counts == [('0','1','0'),('0','1','0')]
                and negative_reason in raw)
    else:
        good = code == 0 and (expected_count is None or counts == [(str(expected_count),'0','0')])
    row = dict(name=name,command=args,exitCode=code,counts=counts,passed=good and unchanged,sourceUnchanged=unchanged,
               startedUtc=started,completedUtc=datetime.now(timezone.utc).isoformat())
    report['steps'].append(row)
    save()
    print(json.dumps(row),flush=True)
    assert row['passed'], name

save()
try:
    try:
        # Remove only the main native routing hook; all assertions and signal/runtime
        # implementations remain identical in the negative and fixed phases.
        MAIN.write_bytes(original.replace(hook,b'',1))
        negative = sources()
        report['negativeSource'] = negative
        step('negative', [*desktop,NAME,'--','--ignored','--exact','--test-threads=1'],negative,
             negative_reason='input must preempt without waiting for action generation or Engine dispatch')
    finally:
        assert MAIN.read_bytes() in (original,original.replace(hook,b'',1)), 'unexpected main edit retained; fixed bytes saved in main-fixed-source.rs'
        MAIN.write_bytes(original)
        assert sources() == fixed, 'fixed source was not restored exactly'
    try:
        # Independently prove acknowledgment liveness. Remove only the observer's
        # native redraw request; leave native input routing and all assertions.
        INPUT.write_bytes(input_original.replace(redraw,b'',1))
        no_redraw = sources()
        report['negativeRedrawSource'] = no_redraw
        env['MOTION_PRERENDER_PRIORITY_ARTIFACTS'] = str(OUT / 'negative-redraw/native')
        step('negative-redraw', [*desktop,NAME,'--','--ignored','--exact','--test-threads=1'],no_redraw,
             negative_reason='input observer must request its acknowledgment redraw without UI translation')
    finally:
        assert INPUT.read_bytes() in (input_original,input_original.replace(redraw,b'',1)), 'unexpected observer edit retained'
        INPUT.write_bytes(input_original)
        assert sources() == fixed, 'observer source was not restored exactly'
    env['MOTION_PRERENDER_PRIORITY_ARTIFACTS'] = str(OUT / 'fixed/native')
    step('fixed', [*desktop,NAME,'--','--ignored','--exact','--test-threads=1'],fixed,expected_count=1)
    step('input-gate', [*desktop,'engine::prerender::input::tests::','--','--test-threads=1'],fixed,expected_count=2)
    step('signals', [*desktop,'engine::prerender::signals::tests::','--','--test-threads=1'],fixed,expected_count=5)
    step('inventory', [sys.executable,'tools/validation_inventory.py'],fixed)
    step('provenance', [sys.executable,'tools/validate_provenance.py'],fixed)
    report['status'] = 'accepted_priority_component_only'
except BaseException:
    report['status'] = 'failed_not_accepted'
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    save()
    raise
report['completedUtc'] = datetime.now(timezone.utc).isoformat()
save()
print(json.dumps(dict(status=report['status'])),flush=True)
