from pathlib import Path
import hashlib,json,subprocess
from PIL import Image
root=Path('E:/Dev/aem/.tools/ai-depth74/natural-domain')
out=root/'cases-v2';out.mkdir(exist_ok=False)
ffbin=Path('E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
for row in manifest['sources']:assert hashlib.sha256((root/row['file']).read_bytes()).hexdigest()==row['sha256']
colour_command=[str(ffbin/'ffprobe.exe'),'-v','error','-select_streams','v:0','-show_entries',
    'stream=color_space,color_transfer,color_primaries,color_range,pix_fmt','-of','json',str(root/'tour.mp4')]
colour=json.loads(subprocess.check_output(colour_command,timeout=20))['streams'][0]
assert colour==dict(pix_fmt='yuv420p',color_range='tv',color_space='bt709',color_transfer='bt709',color_primaries='bt709')
numbers=list(range(450,462))+[900,1350,2250,3600]
select='+'.join('eq(n\\,'+str(n)+')' for n in numbers)
filter='select='+select+',zscale=primaries=bt709:transfer=iec61966-2-1:matrix=gbr:range=full,format=gbrp,format=rgb24'
command=[str(ffbin/'ffmpeg.exe'),'-v','error','-nostdin','-i',str(root/'tour.mp4'),'-an',
    '-vf',filter,'-fps_mode','passthrough','-frames:v',str(len(numbers)),str(out/'decoded-%02d.png')]
subprocess.run(command,check=True,timeout=60)
rows=[]
photo=Image.open(root/'interior.jpg').convert('RGB').resize((321,219),Image.Resampling.LANCZOS)
photo.save(out/'natural-interior.png')
rows.append(dict(name='natural-interior',file='natural-interior.png',ticks=0,timescale=1,
    source='iss007e11800',modification='Untagged JPEG interpreted as sRGB; independently resized to 321x219 with Lanczos; derivative fixture has its own pixel geometry'))
pts=json.loads((root/'tour-frames.json').read_text(encoding='utf-8'))['frames']
for i,number in enumerate(numbers):
    name=f'live-{number:05}'
    original=out/f'decoded-{i+1:02}.png'
    original.rename(out/(name+'.png'))
    assert pts[number]['pts']==number*1000
    rows.append(dict(name=name,file=name+'.png',ticks=pts[number]['pts'],timescale=15000,
        source='Step_Inside_the_Station-4K-Clean~mobile',frame=number,
        consecutive=450<=number<=461,modification='FFmpeg decodes tagged limited-range BT.709 YUV420p and zscale explicitly converts BT.709 transfer to sRGB RGB24; no crop, resize or audio'))
for row in rows:
    path=out/row['file'];im=Image.open(path).convert('RGB');data=im.tobytes()
    im.save(path);(out/(row['name']+'.rgb')).write_bytes(data)
    row.update(size=list(im.size),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),rgbSha256=hashlib.sha256(data).hexdigest())
result=dict(caseDirectory=out.name,sourceManifest=manifest,colour=colour,commands=[colour_command,command],
    ffmpegVersion=subprocess.check_output([str(ffbin/'ffmpeg.exe'),'-version'],text=True).splitlines()[0],
    ffmpegSha256=hashlib.sha256((ffbin/'ffmpeg.exe').read_bytes()).hexdigest(),cases=rows)
(root/'cases.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(dict(cases=len(rows),consecutiveFrames=12,ptsTimescale=15000,colour=colour)),flush=True)
