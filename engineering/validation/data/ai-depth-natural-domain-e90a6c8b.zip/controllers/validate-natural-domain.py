"""Real-model/reference evaluation on credited natural indoor/video fixtures."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path('E:/Dev/aem');home=root/'.tools/ai-depth74';work=root/'.worktrees/ai-depth'
fixtures=home/'natural-domain';manifest=json.loads((fixtures/'cases.json').read_text(encoding='utf-8'))
out=root/'artifacts/pr-queue/issue74-natural-domain-v1';out.mkdir(exist_ok=False)
for name in ['TEMP','TMP','TORCH_HOME','HF_HOME','TORCHINDUCTOR_CACHE_DIR']:
    path=home/'natural-temp'/name.lower();path.mkdir(parents=True,exist_ok=True);os.environ[name]=str(path)
os.environ.pop('MOTION_LOG',None);os.environ['CUDA_VISIBLE_DEVICES']=''
import cv2,numpy as np,torch
from PIL import Image,ImageDraw
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['crates/motion-host/src/depth.rs','crates/motion-host/src/depth/onnx.rs','tools/ai_depth_onnx.py']
frozen={n:sha(work/n) for n in names}
frozen['external-probe/main.rs']=sha(home/'rust-probe/src/main.rs')
binary=root/'target/ai-depth74-contract/debug/motion-depth74-native-probe.exe'
binary_hash=sha(binary)
ref=home/'official-reference';revision='a561b849ebae10a6f5ef49e26c83cbbcd36c71bf'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ref,text=True).strip()==revision
subprocess.run(['git','diff','--quiet','HEAD','--'],cwd=ref,check=True)
weights=home/'models/depth_anything_v2_vits.pth'
assert sha(weights)=='715fade13be8f229f8a70cc02066f656f2423a59effd0579197bbf57860e1378'
assert sha(home/'models/depth_anything_v2_vits_518.onnx')=='274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
sys.path.insert(0,str(ref))
from depth_anything_v2.dpt import DepthAnythingV2
torch.set_num_threads(1);torch.set_num_interop_threads(1)
model=DepthAnythingV2(encoder='vits',features=64,out_channels=[48,96,192,384]).cpu().eval()
model.load_state_dict(torch.load(weights,map_location='cpu',weights_only=True),strict=True)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
(out/'probe.rs').write_bytes((home/'rust-probe/src/main.rs').read_bytes())
(out/'fixtures.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
rows=[];thumbs=[];sequence=[]
for entry in manifest['cases']:
    name=entry['name'];folder=out/name;folder.mkdir()
    original=fixtures/manifest['caseDirectory']/entry['file']
    assert sha(original)==entry['sha256']
    rgb=np.asarray(Image.open(original).convert('RGB'));h,w=rgb.shape[:2]
    assert hashlib.sha256(rgb.tobytes()).hexdigest()==entry['rgbSha256']
    Image.fromarray(rgb).save(folder/'input.png');rgb.tofile(folder/'input.rgb')
    if w>=h:rw=518;rh=max(1,(h*518+w//2)//w)
    else:rh=518;rw=max(1,(w*518+h//2)//h)
    bx,by=(518-rw)//2,(518-rh)//2
    boxed=np.zeros((518,518,3),dtype=np.uint8)
    boxed[by:by+rh,bx:bx+rw]=cv2.resize(rgb,(rw,rh),interpolation=cv2.INTER_CUBIC)
    tensor,_=model.image2tensor(boxed[:,:,::-1].copy(),input_size=518)
    with torch.no_grad():
        prediction=model(tensor).unsqueeze(1)
        reference=torch.nn.functional.interpolate(prediction[:,:,by:by+rh,bx:bx+rw],size=(h,w),mode='bilinear',align_corners=True)[0,0].numpy()
    reference.astype('<f4').tofile(folder/'official-reference.f32')
    native=folder/'native';native.mkdir()
    command=[str(binary),str(native),'success',str(w),str(h),str(folder),str(entry['ticks']),str(entry['timescale'])]
    with (native/'stdout.log').open('wb') as stdout,(native/'stderr.log').open('wb') as stderr:
        process=subprocess.run(command,cwd=work,env=os.environ,stdout=stdout,stderr=stderr,timeout=180)
    assert process.returncode==0,(name,'actual Rust/ONNX probe failed')
    assert (native/'stdout.log').read_bytes()==b'' and (native/'stderr.log').read_bytes()==b''
    log=(native/'logs/motion-studio.log').read_text(encoding='utf-8')
    assert 'logging initialized level=INFO' in log and 'start #' in log and 'actual_provider=CPUExecutionProvider' in log
    row=json.loads((native/'accepted.json').read_text(encoding='utf-8'))['positive']
    actual=np.fromfile(native/'actual.f32',dtype='<f4').reshape(h,w)
    amplitude=max(float(np.abs(reference).max()),1e-6)
    maximum=float(np.max(np.abs(actual.astype(np.float64)-reference)))/amplitude
    mean=float(np.mean(np.abs(actual.astype(np.float64)-reference)))/amplitude
    assert maximum<=2e-4 and mean<=2e-5
    edge_errors=[np.abs(np.diff(actual.astype(np.float64),axis=a)-np.diff(reference.astype(np.float64),axis=a))/amplitude for a in [0,1]]
    edge_max=max(float(e.max()) for e in edge_errors)
    assert edge_max<=4e-4,'derivative bound implied by unchanged pixel-error bound'
    shifted=float(np.max(np.abs(actual[:,:-1].astype(np.float64)-reference[:,1:])))/amplitude
    assert shifted>2e-4,'one-pixel registration control must fail the original bound'
    row.update(name=name,pts=dict(ticks=entry['ticks'],timescale=entry['timescale']),command=command,
        maxNormalized=maximum,meanNormalized=mean,edgeMaxNormalized=edge_max,shiftedControlMaxNormalized=shifted)
    rows.append(row)
    lo,hi=np.percentile(reference,[1,99])
    for suffix,values in [('actual',actual),('reference',reference)]:
        gray=np.rint(np.clip((values-lo)/max(hi-lo,1e-6),0,1)*255).astype(np.uint8)
        Image.fromarray(gray).save(folder/(suffix+'.png'))
    if entry.get('consecutive'):
        normalized=(actual-lo)/max(hi-lo,1e-6);sequence.append((rgb,normalized))
    canvas=Image.new('RGB',(384,150),'white')
    for i,im in enumerate([Image.fromarray(rgb),Image.open(folder/'reference.png').convert('RGB'),Image.open(folder/'actual.png').convert('RGB')]):canvas.paste(im.resize((128,128)),(i*128,20))
    ImageDraw.Draw(canvas).text((3,2),name+' | NASA / official / Rust',fill='black');thumbs.append(canvas)
    assert all(sha(work/n)==frozen[n] for n in names) and sha(home/'rust-probe/src/main.rs')==frozen['external-probe/main.rs'] and sha(binary)==binary_hash
    (out/'progress.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    print(json.dumps(dict(completed=name,maxNormalized=maximum,edgeMaxNormalized=edge_max)),flush=True)
sheet=Image.new('RGB',(384*3,150*6),'white')
for i,thumb in enumerate(thumbs):sheet.paste(thumb,((i%3)*384,(i//3)*150))
sheet.save(out/'comparison.png')
temporal=[]
for (before,a),(after,b) in zip(sequence,sequence[1:]):
    first=cv2.cvtColor(before,cv2.COLOR_RGB2GRAY);second=cv2.cvtColor(after,cv2.COLOR_RGB2GRAY)
    flow=cv2.calcOpticalFlowFarneback(second,first,None,.5,3,15,3,5,1.2,0)
    h,w=first.shape;yy,xx=np.mgrid[:h,:w].astype(np.float32)
    mx,my=xx+flow[:,:,0],yy+flow[:,:,1]
    valid=(mx>=1)&(my>=1)&(mx<w-2)&(my<h-2)
    warped=cv2.remap(a.astype(np.float32),mx,my,cv2.INTER_LINEAR)
    residual=np.abs(warped-b)[valid]
    temporal.append(dict(mean=float(residual.mean()),p95=float(np.percentile(residual,95)),validFraction=float(valid.mean())))
receipt=dict(source=frozen,binarySha256=binary_hash,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
    fixtures=manifest,rows=rows,temporalDiagnostic=temporal,
    limits='Finite natural indoor and short 12-frame real-video probes, plus four spaced anchors; no metric ground truth or universal contour/temporal guarantee. Optical-flow residual includes motion, occlusion, lighting, relative-scale changes and flow errors; not a pure flicker score. No accelerated provider or GUI/Session acceptance.')
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,cases=len(rows))),flush=True)
