from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/ai-depth';home=root/'.tools/ai-depth74'
run=root/'artifacts/pr-queue/issue74-natural-domain-v1';fixtures=home/'natural-domain'
sha=lambda b:hashlib.sha256(b).hexdigest()
receipt=json.loads((run/'accepted.json').read_text(encoding='utf-8'))
assert len(receipt['rows'])==17 and len(receipt['temporalDiagnostic'])==11
for name,digest in receipt['source'].items():
    path=home/'rust-probe/src/main.rs' if name=='external-probe/main.rs' else work/name
    assert sha(path.read_bytes())==digest,name
assert all(r['maxNormalized']<=2e-4 and r['meanNormalized']<=2e-5 and r['shiftedControlMaxNormalized']>2e-4 for r in receipt['rows'])
payload={}
def add(name,path):
    assert path.is_file() and path.stat().st_size<16<<20,path
    assert path.suffix not in {'.onnx','.pth','.exe','.dll','.mp4'},path
    assert name not in payload,name
    payload[name]=path.read_bytes()
for path in sorted(run.rglob('*')):
    if path.is_file():add('run/'+path.relative_to(run).as_posix(),path)
for name in ['manifest.json','cases.json','contact.json','tour-stream.json','interior.jpg.headers','tour.mp4.headers']:
    add('provenance/'+name,fixtures/name)
for name in ['interior-metadata.json','video-metadata.json']:
    data=json.loads((fixtures/name).read_text(encoding='utf-8'))
    selected={k:v for k,v in data.items() if k.startswith('AVAIL:') and any(s in k.lower() for s in ['title','description','date','creator','credit','copyright','rights'])}
    payload['provenance/'+name]=(json.dumps(selected,indent=2)+'\n').encode()
for name in ['download-natural-fixtures.py','prepare-natural-contact-sheet.py','extract-natural-frames.py','validate-natural-domain.py']:
    add('controllers/'+name,home/name)
for name in ['ATTRIBUTION.md','PROVENANCE.md','NOTICE','crates/motion-host/src/depth.rs','crates/motion-host/src/depth/onnx.rs','tools/ai_depth_onnx.py']:
    add('source/'+name,work/name)
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
    add('external-probe/'+name,home/'rust-probe'/name)
for name in ['issue74-natural-download.log','issue74-natural-probe-build.log','issue74-natural-validation-v1.log',
    'issue74-natural-extraction-red.log','issue74-natural-extraction-v2.log']:
    add('logs/'+name,root/'artifacts/pr-queue'/name)
add('controllers/archive.py',Path(__file__))
manifest=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
    scope='17 actual CPU host/reference comparisons on natural indoor/real-video inputs; NASA-credit technical evidence only; no runtime/model/original media redistribution',
    licenseSource='https://www.nasa.gov/nasa-brand-center/images-and-media/',
    licensePageSha256=sha((fixtures/'nasa-media-guidelines.html').read_bytes()),
    limits=receipt['limits'],files={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(payload.items())})
payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=work/'engineering/validation/data/ai-depth-natural-domain-e90a6c8b.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(payload.items()):archive.writestr(name,data)
assert dest.stat().st_size<64<<20
with zipfile.ZipFile(dest) as archive:
    assert set(archive.namelist())==set(payload)
    for name,data in payload.items():assert sha(archive.read(name))==sha(data),name
result=dict(file=dest.name,bytes=dest.stat().st_size,files=len(payload),sha256=sha(dest.read_bytes()))
(root/'artifacts/pr-queue/issue74-natural-archive.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
