from pathlib import Path
import hashlib,json,subprocess
from PIL import Image,ImageDraw
root=Path('E:/Dev/aem/.tools/ai-depth74/natural-domain')
ffbin=Path('E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')
frames=[150,450,900,1350,1800,2250,2700,3600,4500,5400,7200,9000]
folder=root/'contact';folder.mkdir(exist_ok=False)
select='+'.join('eq(n\\,'+str(n)+')' for n in frames)
command=[str(ffbin/'ffmpeg.exe'),'-v','error','-nostdin','-i',str(root/'tour.mp4'),'-an','-vf','select='+select,
         '-fps_mode','passthrough','-frames:v',str(len(frames)),str(folder/'frame-%02d.png')]
subprocess.run(command,check=True,timeout=60)
image=Image.new('RGB',(320*3,205*4),'white')
for i,number in enumerate(frames):
    frame=Image.open(folder/f'frame-{i+1:02}.png').convert('RGB')
    image.paste(frame,((i%3)*320,(i//3)*205+25))
    ImageDraw.Draw(image).text(((i%3)*320+4,(i//3)*205+5),f'NASA ISS tour frame {number}, {number/15:g}s',fill='black')
image.save(root/'contact.png')
command=[str(ffbin/'ffprobe.exe'),'-v','error','-select_streams','v:0','-show_entries','frame=pts,best_effort_timestamp','-of','json',str(root/'tour.mp4')]
data=subprocess.check_output(command,timeout=60);assert len(data)<8<<20
(root/'tour-frames.json').write_bytes(data)
rows=json.loads(data)['frames'];assert len(rows)==13453
assert all(row['pts']==row['best_effort_timestamp']==i*1000 for i,row in enumerate(rows))
(root/'contact.json').write_text(json.dumps(dict(frameNumbers=frames,timebase='1/15000',constantPtsStep=1000,
    originalSha256=hashlib.sha256((root/'tour.mp4').read_bytes()).hexdigest(),commands=[command]),indent=2),encoding='utf-8')
print(json.dumps(dict(frames=len(rows),constantPtsStep=1000,contact=str(root/'contact.png'))),flush=True)
