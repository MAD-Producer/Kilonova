from pathlib import Path
import hashlib,json,subprocess
root=Path('E:/Dev/aem/.tools/ai-depth74/natural-domain')
ffprobe=Path('E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffprobe.exe')
rows=[]
for name,url,limit,revision in [
    ('interior.jpg','https://images-assets.nasa.gov/image/iss007e11800/iss007e11800~orig.jpg',16<<20,'ISS007-E-11800, 2003-08-03'),
    ('tour.mp4','https://images-assets.nasa.gov/video/Step_Inside_the_Station-4K-Clean/Step_Inside_the_Station-4K-Clean~mobile.mp4',40<<20,'NASA library 2025-12-17, variant modified 2026-07-22')]:
    target=root/name
    assert not target.exists()
    subprocess.run(['curl.exe','--fail','--location','--proto','=https','--proto-redir','=https',
        '--connect-timeout','10','--max-time','120','--max-filesize',str(limit),'--silent','--show-error',
        '--dump-header',str(root/(name+'.headers')),'--output',str(target),url],check=True,timeout=125)
    data=target.read_bytes();assert 0<len(data)<=limit
    rows.append(dict(file=name,source=url,author='NASA / ISS crew',revision=revision,
        license='NASA media guidelines, factual technical evaluation, no endorsement',
        licenseSource='https://www.nasa.gov/nasa-brand-center/images-and-media/',
        bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),modification='Original downloaded variant; extracted frames recorded separately'))
    print(json.dumps(rows[-1]),flush=True)
command=[str(ffprobe),'-v','error','-select_streams','v:0','-show_entries',
    'stream=codec_name,width,height,r_frame_rate,avg_frame_rate,time_base,start_pts,duration_ts,nb_frames',
    '-of','json',str(root/'tour.mp4')]
metadata=subprocess.check_output(command,timeout=30);(root/'tour-stream.json').write_bytes(metadata)
(root/'manifest.json').write_text(json.dumps(dict(sources=rows,ffprobeCommand=command),indent=2),encoding='utf-8')
print(metadata.decode(),flush=True)
