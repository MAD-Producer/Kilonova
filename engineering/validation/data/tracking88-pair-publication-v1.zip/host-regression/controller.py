from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-pair-host-regression-v1';OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
source={p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in set(paths) if p.startswith('crates/') and (WORK/p).is_file()}
command=['cargo','test','-p','motion-host','--lib','--locked','--offline','--','--test-threads=1']
report=dict(status='running',pid=os.getpid(),startedUtc=datetime.now(timezone.utc).isoformat(),source=source,command=command)
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2))
env=os.environ.copy();env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full')
save()
try:
    with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);report['childPid']=child.pid;save();report['exitCode']=child.wait()
    for p,h in source.items():assert hashlib.sha256((WORK/p).read_bytes()).hexdigest()==h,p
    assert report['exitCode']==0,report['exitCode']
    report['status']='passed_full_host_unit_regression_with_pair_publication_controls'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=datetime.now(timezone.utc).isoformat();save()


