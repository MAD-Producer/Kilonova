from pathlib import Path
import json
out=Path(__file__).resolve().parent
names={'motion-render','motion-graph','motion-host','motion-ui','motion-desktop','motion-desktop-media'}
for mode in ['cpu','gpu']:
 data=json.loads((out/(mode+'-metadata.log')).read_text(encoding='utf-8'))
 packages={p['id']:p['name'] for p in data['packages']}
 resolved={packages[n['id']]:n['features'] for n in data['resolve']['nodes']}
 features={name:resolved[name] for name in sorted(names)}
 assert all(('gpu-tests' in values)==(mode=='gpu') for values in features.values())
 assert 'noop' not in resolved['wgpu']
 (out/(mode+'-features.json')).write_text(json.dumps(dict(gpu=features,wgpu=resolved['wgpu']),indent=2),encoding='utf-8')
 print(mode+': six GPU feature selections verified; wgpu NOOP backend absent')
