from pathlib import Path
import hashlib,json,os,shutil,subprocess
out=Path(__file__).resolve().parent
directory=out/'runtime-probe';directory.mkdir(exist_ok=True)
exe=Path('E:/Dev/aem/target/debug/deps/motion_desktop_media-46fff8939efa93ea.exe')
runtime=Path('E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin').resolve()
target=directory/exe.name
assert directory.resolve().is_relative_to(out.resolve())
shutil.copy2(exe,target)
assert hashlib.sha256(target.read_bytes()).digest()==hashlib.sha256(exe.read_bytes()).digest()
env=os.environ.copy();env['PATH']=str(runtime)+os.pathsep+env.get('PATH','')
records=[]
def probe(name):
 result=subprocess.run([str(target),'--list'],capture_output=True,env=env)
 records.append(dict(mode=name,exit_code=result.returncode,listed_tests=result.stdout.count(b': test')))
probe('isolated executable with PATH')
names=['avutil-60.dll','swresample-6.dll','avcodec-62.dll','avformat-62.dll','swscale-9.dll']
for name in names:shutil.copy2(runtime/name,directory/name)
probe('same executable with adjacent existing runtime')
for name in names:
 old=exe.parent/name
 print(json.dumps(dict(name=name,existing_in_target=old.exists(),same_as_runtime=old.is_file() and hashlib.sha256(old.read_bytes()).digest()==hashlib.sha256((runtime/name).read_bytes()).digest())))
record=dict(executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),probes=records)
(out/'application-runtime-probe.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record))
