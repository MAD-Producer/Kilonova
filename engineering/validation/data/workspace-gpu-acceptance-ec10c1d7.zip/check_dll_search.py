from pathlib import Path
import hashlib,json,os,subprocess
out=Path(__file__).resolve().parent
exe=Path('E:/Dev/aem/target/debug/deps/motion_desktop_media-46fff8939efa93ea.exe')
runtime=Path('E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin').resolve()
results=[]
for name,prefix in [('forward_slashes',runtime.as_posix()),('native_path',str(runtime))]:
 env=os.environ.copy();env['PATH']=prefix+os.pathsep+env.get('PATH','')
 result=subprocess.run([str(exe),'--list'],capture_output=True,env=env)
 record=dict(mode=name,prefix=prefix,exit_code=result.returncode,listed_test_lines=result.stdout.count(b': test'),stdout_sha256=hashlib.sha256(result.stdout).hexdigest())
 results.append(record);print(json.dumps(record))
(out/'dll-search-control.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
