from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,time
out=Path(__file__).resolve().parent;work=Path.cwd()
assert work==Path('E:/Dev/aem/.worktrees/workspace-gpu-acceptance')
original=json.loads((out/'acceptance-receipt.json').read_text())
assert original['stages'][-1]['name']=='workspace-cpu' and original['stages'][-1]['exit_code']==101 and original['stages'][-1]['source_unchanged']
path='crates/motion-render/tests/command_timing_markers.rs'
old=subprocess.check_output(['git','show','HEAD:'+path])
new=(work/path).read_bytes().replace(b'\r\n',b'\n')
attribute=b'#[cfg_attr(not(feature = "gpu-tests"), ignore = "requires an actual GPU")]\n'
assert new.count(attribute)==1 and new.replace(attribute,b'',1)==old
assert subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()==[path]
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
paths=[p for p in subprocess.check_output(['git','ls-files','-z']).decode('utf-8').split('\0') if p]
def freeze():return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
source=freeze();(out/'corrected-source-freeze.json').write_text(json.dumps(dict(head=head,hashes=source),indent=2),encoding='utf-8')
runtime=Path(os.environ['FFMPEG_DIR']).resolve();deps=Path('E:/Dev/aem/target/debug/deps').resolve()
assert deps.is_relative_to(Path('E:/Dev/aem').resolve()) and deps.is_dir()
copies=[]
for name in ['avutil-60.dll','swresample-6.dll','avcodec-62.dll','avformat-62.dll','swscale-9.dll']:
 src=runtime/'bin'/name;dst=deps/name;digest=hashlib.sha256(src.read_bytes()).hexdigest()
 if dst.exists():assert hashlib.sha256(dst.read_bytes()).hexdigest()==digest,'Refusing to overwrite a different runtime: '+str(dst)
 else:shutil.copy2(src,dst)
 assert hashlib.sha256(dst.read_bytes()).hexdigest()==digest
 copies.append(dict(source=str(src),destination=str(dst),sha256=digest))
version=subprocess.check_output([str(runtime/'bin/ffmpeg.exe'),'-version'],stderr=subprocess.STDOUT,text=True).splitlines()[0]
shutil.copy2(runtime/'LICENSE.txt',out/'existing-ffmpeg-runtime-license.txt')
(out/'runtime-staging.json').write_text(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),version=version,scope='Existing local development runtime copied unchanged only into ignored test artifacts; no product asset or dependency added',files=copies),indent=2),encoding='utf-8')
env=os.environ.copy();env['CARGO_TERM_COLOR']='never';env['PYTHONIOENCODING']='utf-8'
env['PYTHONPATH']='E:/Dev/aem/.tools/build-validation-python'+os.pathsep+env.get('PYTHONPATH','')
env.pop('MOTION_LOG',None);env.pop('MOTION_UPDATE_SHORTCUT_DOCS',None)
receipts=[]
def run(name,cmd,expected=0,backend=None):
 print('Starting '+name,flush=True);start=time.monotonic();current=env.copy()
 if backend is None:current.pop('WGPU_BACKEND',None)
 else:current['WGPU_BACKEND']=backend
 log=out/(name+'.log')
 with log.open('w',encoding='utf-8') as stream:result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,env=current)
 text=log.read_text(encoding='utf-8',errors='replace')
 record=dict(name=name,command=cmd,seconds=round(time.monotonic()-start,2),exit_code=result.returncode,expected_exit=expected,backend=backend,source_unchanged=freeze()==source,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
 receipts.append(record);(out/'corrected-acceptance-receipt.json').write_text(json.dumps(dict(head=head,stages=receipts),indent=2),encoding='utf-8')
 assert result.returncode==expected,(name,result.returncode,text[-4000:])
 assert record['source_unchanged'],name
 print(json.dumps(record),flush=True);return text
common=['--locked','--offline','-j1']
marker='pass_timestamp_boundaries_enclose_real_commands_without_encoder_timestamp_feature'
target=['cargo','test','-p','motion-render','--no-default-features','--test','command_timing_markers',*common]
text=run('marker-cpu',target+['--','--test-threads=1','--nocapture'],backend='noop')
assert '0 passed; 0 failed; 1 ignored' in text
gpu=target+['--features','gpu-tests',marker,'--','--exact','--test-threads=1','--nocapture']
text=run('marker-missing-adapter',gpu,expected=101,backend='noop')
assert 'NotFound' in text and '0 passed; 1 failed; 0 ignored' in text
text=run('marker-native',gpu)
assert '1 passed; 0 failed; 0 ignored' in text
probe=re.search(r'GPU_COMMAND_MARKER_PROBE=(\{[^\r\n]+\})',text);assert probe
(out/'marker-native-capability.json').write_text(json.dumps(json.loads(probe.group(1)),indent=2),encoding='utf-8')
profile=['--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256']
text=run('workspace-cpu-corrected',['cargo','test','--workspace','--no-default-features','--features','motion-desktop/ffmpeg,motion-host/diagnostics',*profile,*common,'--no-fail-fast','--','--test-threads=1'],backend='noop')
chunks=re.split(r'(?m)^((?: {5}Running | {3}Doc-tests )[^\r\n]+)',text);suites=[]
for i in range(1,len(chunks),2):
 summaries=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',chunks[i+1],re.M)
 assert summaries,(chunks[i],chunks[i+1][-1500:])
 passed,failed,ignored=map(int,summaries[-1]);assert failed==0
 suites.append(dict(target=chunks[i],passed=passed,failed=failed,ignored=ignored,nested_summaries_excluded=len(summaries)-1))
assert suites and sum(s['passed'] for s in suites)>0 and sum(s['ignored'] for s in suites)>0
(out/'cpu-suites.json').write_text(json.dumps(dict(suites=suites,passed=sum(s['passed'] for s in suites),ignored=sum(s['ignored'] for s in suites)),indent=2),encoding='utf-8')
analytic=['cargo','test','-p','motion-ui','--no-default-features','--features','gpu-tests','--test','analytic',*common]
text=run('missing-adapter',analytic+['procedural_patterns_and_fractional_dpi_borders_render_actual_pixels','--','--exact','--test-threads=1','--nocapture'],expected=101,backend='noop')
assert 'NotFound' in text and '0 passed; 1 failed; 0 ignored' in text
text=run('gpu-recovery',analytic+['--','--test-threads=1','--nocapture'])
assert '3 passed; 0 failed; 0 ignored' in text
(out/'complete.json').write_text(json.dumps(dict(head=head,source_unchanged=freeze()==source,all_expected_results=True,original_failed_run_preserved=True,product_change='one GPU test-selection attribute; original test body unchanged'),indent=2),encoding='utf-8')
print('Corrected full workspace CPU acceptance and GPU controls complete',flush=True)
