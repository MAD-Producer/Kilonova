import copy,importlib.util,json,pathlib,shlex,sys,unittest.mock
work=pathlib.Path.cwd();out=pathlib.Path(__file__).resolve().parent
sys.path[:0]=[str(work/'tools'),'E:/Dev/aem/.tools/build-validation-python']
import test_ci_workflow as policy
policy.WorkflowPolicyTest.setUpClass()
results=[]
packages=['motion-render','motion-graph','motion-host','motion-ui','motion-desktop','motion-desktop-media']
for package in packages:
 case=policy.WorkflowPolicyTest('test_native_and_workspace_jobs_partition_all_supported_packages')
 case.workflow=copy.deepcopy(policy.WorkflowPolicyTest.workflow)
 case.checks=case.workflow['jobs']['checks']
 job='checks' if package in ['motion-render','motion-graph'] else 'desktop'
 label='Run Rust and software Vulkan tests' if job=='checks' else 'Run desktop unit tests'
 step=next(s for s in case.workflow['jobs'][job]['steps'] if s.get('name')==label)
 args=shlex.split(step['run']);index=args.index('--features')+1
 features=args[index].split(',');features.remove(package+'/gpu-tests');args[index]=','.join(features)
 step['run']=shlex.join(args)
 try:case.test_native_and_workspace_jobs_partition_all_supported_packages()
 except AssertionError as error:results.append(dict(defect='missing CI feature '+package,rejected=True,cause=str(error)[:1200]))
 else:raise AssertionError('workflow guard did not reject '+package)
original_loads=policy.tomllib.loads
for defect in ['disabled GPU default','reenabled internal GPU default']:
 def altered(text,*args,**kwargs):
  data=original_loads(text,*args,**kwargs)
  name=data.get('package',{}).get('name')
  if defect=='disabled GPU default' and name=='motion-ui':data['features']['default'].remove('gpu-tests')
  if defect=='reenabled internal GPU default' and name=='motion-desktop':data['dependencies']['motion-render']['default-features']=True
  return data
 case=policy.WorkflowPolicyTest('test_cpu_only_feature_is_not_reenabled_by_internal_dependencies')
 with unittest.mock.patch.object(policy.tomllib,'loads',side_effect=altered):
  try:case.test_cpu_only_feature_is_not_reenabled_by_internal_dependencies()
  except AssertionError as error:results.append(dict(defect=defect,rejected=True,cause=str(error)[:1200]))
  else:raise AssertionError('manifest guard did not reject '+defect)
assert len(results)==8
(out/'ci-controls.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print('8 controlled configuration defects rejected by unchanged existing assertions')
