from pathlib import Path
import ctypes,json,os,subprocess
out=Path(__file__).resolve().parent
runtime=Path('E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin').resolve()
records=[]
with os.add_dll_directory(str(runtime)):
 for name in ['avutil-60.dll','swresample-6.dll','avcodec-62.dll','avformat-62.dll','swscale-9.dll']:
  try:
   handle=ctypes.WinDLL(str(runtime/name))
   records.append(dict(name=name,loaded=True))
  except OSError as error:records.append(dict(name=name,loaded=False,winerror=error.winerror,cause=str(error)))
(out/'runtime-load-probe.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
print(json.dumps(records))
env=os.environ.copy();env['PATH']=str(runtime)+os.pathsep+env.get('PATH','')
result=subprocess.run(['where.exe','avcodec-62.dll'],capture_output=True,env=env)
print(json.dumps(dict(where_exit=result.returncode,found=result.stdout.decode(errors='replace').splitlines())))
