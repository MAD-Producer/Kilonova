from pathlib import Path
import hashlib,json,os,re,subprocess,time
out=Path(__file__).resolve().parent;work=Path.cwd()
assert work==Path('E:/Dev/aem/.worktrees/workspace-gpu-acceptance')
frozen=json.loads((out/'corrected-source-freeze.json').read_text())
def freeze():return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in frozen['hashes']}
assert freeze()==frozen['hashes']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==frozen['head']
for record in json.loads((out/'runtime-staging.json').read_text())['files']:
 assert hashlib.sha256(Path(record['destination']).read_bytes()).hexdigest()==record['sha256']
meta=json.loads((out/'cpu-metadata.log').read_text(encoding='utf-8'))
packages=[p for p in meta['packages'] if p['id'] in meta['workspace_members']]
by_name={p['name'].replace('-','_'):p['name'] for p in packages}
owners={}
for p in packages:
 for target in p['targets']:
  if not (set(target['kind']) & {'test','bench','custom-build'}):
   owners.setdefault(target['name'].replace('-','_'),set()).add(p['name'])
def suites(text,allow_incomplete=False):
 chunks=re.split(r'(?m)^((?: {5}Running | {3}Doc-tests )[^\r\n]+)',text);result={};package=None
 for i in range(1,len(chunks),2):
  header=chunks[i];body=chunks[i+1]
  if 'Doc-tests ' in header:
   owner=by_name[header.strip().split()[-1]];name='doc'
  elif 'Running unittests ' in header:
   name=re.search(r'[/\\]([^/\\]+)-[0-9a-f]+\.exe',header).group(1)
   assert len(owners[name])==1,(header,owners[name]);package=next(iter(owners[name]));owner=package
  else:
   assert package,header
   owner=package;name=Path(header.strip().removeprefix('Running ').split(' (')[0].replace('\\','/')).stem
  summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',body,re.M)
  key=owner+'::'+name;assert key not in result,key
  if summaries:
   status,passed,failed,ignored=summaries[-1]
   result[key]=dict(target=header,package=owner,name=name,status=status,passed=int(passed),failed=int(failed),ignored=int(ignored),nested_summaries_excluded=len(summaries)-1)
  else:
   assert allow_incomplete,header
   result[key]=dict(target=header,package=owner,name=name,status='incomplete')
 return result
partial=(out/'workspace-cpu-corrected.log').read_text(encoding='utf-8')
assert not re.search(r'^test .+? \.\.\. FAILED$',partial,re.M)
prefix=suites(partial,True)
completed={k:v for k,v in prefix.items() if v['status']=='ok'}
assert len(completed)==58 and {v['package'] for v in completed.values()}=={'motion-core','motion-android'}
expected={p['name']+'::'+t['name'].replace('-','_') for p in packages if p['name'] in {'motion-core','motion-android'} for t in p['targets'] if t['test'] and not(set(t['kind'])&{'bench','custom-build'})}
assert set(completed)==expected
assert sum(v['passed'] for v in completed.values())==291 and all(v['failed']==0 for v in completed.values())
reference=suites((out/'workspace-cpu.log').read_text(encoding='utf-8'),True)
old=json.loads((out/'source-freeze.json').read_text())
for path,digest in old['hashes'].items():
 if path.startswith(('crates/motion-core/','crates/motion-android/')):
  assert frozen['hashes'][path]==digest
for package in ['motion-core','motion-android']:
 key=package+'::doc';row=reference[key]
 assert row['status']=='ok' and (row['passed'],row['failed'],row['ignored'])==(0,0,0)
 completed[key]=row
(out/'resume-reused-results.json').write_text(json.dumps(dict(source_head=frozen['head'],completed_targets=completed,interrupted_target_not_counted=True,notes='58 complete Android/core targets reused; their two unchanged empty doc harnesses reused from the complete initial traversal; no test skip filter added'),indent=2),encoding='utf-8')
env=os.environ.copy();env['CARGO_TERM_COLOR']='never';env['PYTHONIOENCODING']='utf-8';env.pop('MOTION_LOG',None);env.pop('MOTION_UPDATE_SHORTCUT_DOCS',None)
records=[]
def run(name,cmd,expected=0,backend=None):
 print('Starting '+name,flush=True);start=time.monotonic();current=env.copy()
 if backend is None:current.pop('WGPU_BACKEND',None)
 else:current['WGPU_BACKEND']=backend
 path=out/(name+'.log')
 with path.open('w',encoding='utf-8') as stream:p=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,env=current)
 text=path.read_text(encoding='utf-8',errors='replace')
 record=dict(name=name,command=cmd,seconds=round(time.monotonic()-start,2),exit_code=p.returncode,expected_exit=expected,backend=backend,source_unchanged=freeze()==frozen['hashes'],sha256=hashlib.sha256(path.read_bytes()).hexdigest())
 records.append(record);(out/'resume-acceptance-receipt.json').write_text(json.dumps(dict(head=frozen['head'],stages=records),indent=2),encoding='utf-8')
 assert p.returncode==expected,(name,p.returncode,text[-4000:]);assert record['source_unchanged']
 print(json.dumps(record),flush=True);return text
common=['--locked','--offline','-j1'];profile=['--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256']
text=run('workspace-cpu-remainder',['cargo','test','--workspace','--exclude','motion-core','--exclude','motion-android','--no-default-features','--features','motion-desktop/ffmpeg,motion-host/diagnostics',*profile,*common,'--no-fail-fast','--','--test-threads=1'],backend='noop')
remaining=suites(text);assert not(set(completed)&set(remaining))
combined={**completed,**remaining};assert set(combined)==set(reference),(sorted(set(reference)-set(combined)),sorted(set(combined)-set(reference)))
assert all(r['status']=='ok' and r['failed']==0 for r in combined.values())
data=dict(head=frozen['head'],suites=list(combined.values()),passed=sum(v['passed'] for v in combined.values()),ignored=sum(v['ignored'] for v in combined.values()),verified_by_resumed_package_union=True)
(out/'cpu-suites.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
analytic=['cargo','test','-p','motion-ui','--no-default-features','--features','gpu-tests','--test','analytic',*common]
text=run('missing-adapter',analytic+['procedural_patterns_and_fractional_dpi_borders_render_actual_pixels','--','--exact','--test-threads=1','--nocapture'],expected=101,backend='noop')
assert 'NotFound' in text and '0 passed; 1 failed; 0 ignored' in text
text=run('gpu-recovery',analytic+['--','--test-threads=1','--nocapture']);assert '3 passed; 0 failed; 0 ignored' in text
(out/'complete.json').write_text(json.dumps(dict(head=frozen['head'],source_unchanged=freeze()==frozen['hashes'],all_expected_results=True,original_failed_and_interrupted_runs_preserved=True,resumed_without_repeating_complete_packages=True),indent=2),encoding='utf-8')
print('Resumed workspace CPU coverage and GPU controls complete',flush=True)
