"""Archive the terminal original CI result without replacing its failed gate."""
from pathlib import Path
import hashlib,json,re,zipfile
ROOT=Path('E:/Dev/aem'); BASE=ROOT/'artifacts/pr-queue'
DEST=ROOT/'.worktrees/depth-adapter-memory75/engineering/validation/data'
run=json.loads((BASE/'depth75-ci-9784a9f1-terminal.json').read_text(encoding='utf-8-sig'))
assert run['status']=='completed' and run['conclusion']=='failure'
assert run['headSha']=='9784a9f1455207e709b1cfcfd99580399fd6e48e'
assert len([j for j in run['jobs'] if j['name'].startswith('Desktop tests') and j['conclusion']=='success'])==3
assert len([j for j in run['jobs'] if j['name'].startswith('Desktop build') and j['conclusion']=='success'])==3
files={n.name:n for n in [BASE/'depth75-ci-9784a9f1-terminal.json',BASE/'depth75-ci-9784a9f1-rust-gpu.log']}
summaries={}
for platform in ['windows','macos','linux']:
    path=BASE/f'depth75-ci-9784a9f1-{platform}-tests.log';files[path.name]=path
    matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;.*?finished in ([\d.]+)s',path.read_text(encoding='utf-8-sig'))
    assert matches and all(int(row[1])==0 for row in matches)
    summaries[platform]=dict(target_summaries=len(matches),passed=sum(int(row[0]) for row in matches),
        failed=0,ignored=sum(int(row[2]) for row in matches),
        limits='Includes nested child summaries when printed; not a distinct test inventory')
failure=files['depth75-ci-9784a9f1-rust-gpu.log'].read_text(encoding='utf-8-sig')
assert 'test_ci_metric_depth_export.py' in failure and 'unclassified' in failure
report=dict(run=run['databaseId'],head=run['headSha'],conclusion=run['conclusion'],url=run['url'],
    jobs=[{k:j[k] for k in ['databaseId','name','status','conclusion']} for j in run['jobs']],
    raw_log_summaries=summaries,
    limits=['Three platform test/build jobs succeeded on this old source; original Rust/GPU inventory failure remains',
        'Local inventory fix and 159-tool discovery are separately source-bound',
        'No arm64, release packaging, publication, model quality or native failure qualification'])
target=BASE/'depth75-ci-9784a9f1-summary.json';target.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');files[target.name]=target
files[Path(__file__).name]=Path(__file__)
archive=DEST/'depth75-ci-9784a9f1-terminal-v1.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for name,path in files.items():z.writestr(name,path.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(files)
    for name,path in files.items():assert z.read(name)==path.read_bytes()
manifest=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    members={n:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for n,p in files.items()},
    source=run['headSha'],verdict='failed_original_inventory_gate_three_platform_components_passed')
archive.with_suffix('.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(archive=str(archive),bytes=manifest['bytes'],sha256=manifest['sha256'],summary=summaries)))
