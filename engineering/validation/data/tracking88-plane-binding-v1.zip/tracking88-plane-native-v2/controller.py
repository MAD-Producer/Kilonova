"""Own serial executable acceptance: original video PTS -> independent projective plane -> actual builtin corner-pin GPU output."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,struct,subprocess,copy
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-plane-native-v2'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def now():return datetime.now(timezone.utc).isoformat()
names=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
sources={n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (WORK/n).is_file()}
report=dict(status='running',controllerPid=os.getpid(),startedUtc=now(),source=sources,steps=[],scope='New plane-binding executable target, not a retry or repair of earlier full-host native crashes or MCP test compilation fault')
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def identity():
 for n,h in sources.items():assert hashlib.sha256((WORK/n).read_bytes()).hexdigest()==h,n
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'local-appdata'))
EXE=ROOT/'target/gltf-animation87-contract/debug/motion-studio.exe';project_root=OUT/'project';active=[]
def build():
 identity();args=['cargo','build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline']
 row=dict(name='ffmpeg-build',command=args,startedUtc=now());report['steps'].append(row);save()
 with (OUT/'build.stdout.log').open('wb') as stdout,(OUT/'build.stderr.log').open('wb') as stderr:
  p=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait()
 row['completedUtc']=now();save();assert row['exitCode']==0,row
class Rpc:
 def __init__(self,name,readonly=False):
  identity();self.name=name;self.inputs=[];self.raw=[];self.next_id=0
  args=[str(EXE),'--mcp','--project',str(project_root)]+(['--mcp-read-only'] if readonly else [])
  self.row=dict(name=name,command=args,startedUtc=now(),exeSha256=hashlib.sha256(EXE.read_bytes()).hexdigest());report['steps'].append(self.row)
  self.stderr=(OUT/f'{name}.stderr.log').open('wb')
  self.p=subprocess.Popen(args,cwd=WORK,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr,text=True,encoding='utf-8');active.append(self)
  self.row['pid']=self.p.pid;save()
  self.request('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='owned-plane-binding-proof',version='1')))
  self.send(dict(jsonrpc='2.0',method='notifications/initialized'))
 def send(self,message):
  self.inputs.append(message);self.p.stdin.write(json.dumps(message)+'\n');self.p.stdin.flush()
 def request(self,method,params):
  self.next_id+=1;self.send(dict(jsonrpc='2.0',id=self.next_id,method=method,params=params))
  line=self.p.stdout.readline();self.raw.append(line);assert line,f'{self.name}: stdout closed'
  reply=json.loads(line);assert reply['jsonrpc']=='2.0' and reply['id']==self.next_id and 'error' not in reply,reply
  return reply['result']
 def call(self,name,args):return self.request('tools/call',dict(name=name,arguments=args))
 def ok(self,name,args):
  result=self.call(name,args);assert not result['isError'],result;return result['structuredContent']
 def state(self):return self.ok('motion_state',{})
 def close(self):
  if self.p.stdin and not self.p.stdin.closed:self.p.stdin.close()
  trailing=self.p.stdout.read();assert not trailing,repr(trailing)
  self.row['exitCode']=self.p.wait();self.stderr.close();self.row['completedUtc']=now()
  (OUT/f'{self.name}.stdin.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in self.inputs),encoding='utf-8')
  (OUT/f'{self.name}.stdout.jsonl').write_text(''.join(self.raw),encoding='utf-8')
  log=OUT/'local-appdata/MotionStudio/logs/motion-studio.log'
  if log.exists():(OUT/f'{self.name}.file.log').write_bytes(log.read_bytes())
  active.remove(self);save();assert self.row['exitCode']==0,self.name
save()
try:
 build()
 boot=Rpc('bootstrap');project=boot.state()['project'];boot.close();assert project['version']==34
 project.update(width=640,height=480,fps=24,frames=96,work_area=dict(in_frame=0,out_frame=96),background=[0.02,0.02,0.02,1.])
 name='video-ctts.mp4';folder=WORK/'crates/motion-media/tests/fixtures/video';timing=json.loads((folder/'native-timing.json').read_text(encoding='utf-8'))[name]
 ticks=timing['timescale'];pts=sorted(s[0] for s in timing['samples']);assert ticks==1_000_000 and len(pts)==72
 source=project_root/'assets/plate.mp4';source.parent.mkdir(exist_ok=True);shutil.copyfile(folder/name,source)
 end=max(s[0]+s[1] for s in timing['samples'])
 project['video_assets']=[dict(id=1,path='assets/plate.mp4',bytes=source.stat().st_size,mime='video/avc',track=0,width=256,height=144,rotation=0,display_width=256,display_height=144,video_start_us=pts[0],video_end_us=end,duration_us=end,frame_count=len(pts),variable_frame_rate=True,nominal_frame_rate=24.,color_standard=1,color_range=2,audio_asset=None)]
 (project_root/'project.json').write_text(json.dumps(project),encoding='utf-8')
 cache=project_root/'cache/video-v2/plate/index.pts';cache.parent.mkdir(parents=True)
 cache.write_bytes(b'MSVID001'+struct.pack('<Q',source.stat().st_size)+b''.join(struct.pack('<Q',v) for v in pts))
 def matrix(t):return [[1.,0.12*t,60.*t],[0.08*t,1.,30.*t],[0.0015*t,0.0008*t,1.]]
 solve=dict(version=1,source_id='independently-authored perspective control on repo original video',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),source_extent=[256,144],coordinates='right_down_forward',ticks_per_second=ticks,nominal_rate=[24,1],source_pts=pts,meters_per_world_unit=None,tracks=[dict(id='plane-motion',kind='plane',reference_index=0,samples=[dict(source_index=i,visibility='visible',confidence=1.,manual_correction=i==24,observation=dict(kind='plane',matrix=matrix((v-pts[0])/(pts[-1]-pts[0])))) for i,v in enumerate(pts)])])
 original=b' \n'+json.dumps(solve,indent=2).encode()+b'\r\n';document=OUT/'original.mstrack';document.write_bytes(original)
 live=Rpc('plane-binding');before=live.state()
 imported=live.ok('import_tracking',dict(path=str(document),source=dict(kind='video',id=1),expectedRevision=before['revision'],expectedDocumentGeneration=before['document_generation']))
 descriptor=imported['project']['tracking_assets'][0];assert descriptor['id']==2 and (project_root/descriptor['path']).read_bytes()==original
 # Independent flat solid and existing builtin package; no external assets or copied resources.
 template=json.loads((ROOT/'artifacts/pr-queue/tracking88-point-native-v1/project/project.json').read_text(encoding='utf-8'))['layers'][0]
 layer=copy.deepcopy(template);layer.update(id=700,name='Original-PTS projective plane',content=dict(kind='solid',color=[0.05,0.65,0.9,1.]),size=[256.,144.],three_d=False,parent=None,effects=[])
 layer.pop('tracking_point',None);layer.pop('tracking_plane',None)
 layer['transform']['anchor']=[0.5,0.5];layer['transform']['position']['value']=[300.,240.,0.];layer['transform']['rotation']['value']=[0.,0.,0.]
 manifest=json.loads((WORK/'crates/motion-effects/builtin-library/manifest.json').read_text(encoding='utf-8'))
 definition=next(e for e in manifest['effects'] if e['id']=='corner_pin')
 package=WORK/'crates/motion-effects/builtin-library/builtin-effects.msfx'
 params={}
 for p in definition['params']:
  value=p['default'].copy()
  if 'relative_default' in p and p['relative_default'] is not None:
   value[:2]=[p['relative_default'][i]*layer['size'][i] for i in range(2)]
  params[p['id']]=dict(kind=p['kind'],animatable=p['animatable'],min=p['min'],max=p['max'],implemented=p['implemented'],default=value,track=dict(value=value,keys=[]))
 effect=dict(id=99,plugin=manifest['id'],effect='corner_pin',version=manifest['version'],hash=hashlib.sha256(package.read_bytes()).hexdigest(),enabled=True,seed=99,params=params)
 layer['effects']=[effect]
 def edit(commands):
  current=live.state();return live.ok('motion_edit',dict(commands=commands,expectedRevision=current['revision']))
 edit([dict(op='add',layer=layer)])
 binding=dict(asset=2,track='plane-motion',effect=99,anchor_local_frame=0,source_anchor_pts=pts[0],speed_numerator=1,speed_denominator=1,reference_quad=[[0.,0.],[256.,0.],[256.,144.],[0.,144.]],crop=[0.,0.,256.,144.],rotation='none',interpolation='linear',max_gap_ticks=100000,minimum_confidence=0.8,missing='error')
 before=live.state();bad=copy.deepcopy(binding);bad['track']='absent'
 rejected=live.call('motion_edit',dict(commands=[dict(op='set_tracking_plane',object=700,binding=bad)],expectedRevision=before['revision']))
 assert rejected['isError'] and 'phase=binding object=700 asset=2 track=absent' in rejected['content'][0]['text'],rejected
 unchanged=live.state();assert unchanged['project']==before['project'] and unchanged['revision']==before['revision']
 bound=edit([dict(op='set_tracking_plane',object=700,binding=binding)])
 def expected(frame):
  # Independent direct projective evaluation at a source sample. No production helper is called.
  h=matrix((frame/24.*ticks)/(pts[-1]-pts[0]));result=[]
  for x,y in binding['reference_quad']:
   w=h[2][0]*x+h[2][1]*y+h[2][2]
   result.append([(h[0][0]*x+h[0][1]*y+h[0][2])/w,(h[1][0]*x+h[1][1]*y+h[1][2])/w])
  return result
 rows=[]
 def capture(frame,name,correction=False):
  sampled=live.ok('motion_seek',dict(frame=frame));values=next(e['values'] for e in sampled['sampledEffects'] if e['layer']==700 and e['instance']==99)
  quad=expected(frame)
  if correction:quad[0]=[quad[0][0]+5.,quad[0][1]-3.]
  for id,point in zip(['tl','tr','br','bl'],quad):assert all(abs(values[id][i]-point[i])<0.0001 for i in range(2)),(values,quad)
  c=live.ok('render_preview',dict(frame=frame));destination=OUT/(name+'.png');shutil.copyfile(c['path'],destination)
  rows.append(dict(frame=frame,quad=quad,worldQuad=[[x+172.,y+168.] for x,y in quad],sampled=values,path=str(destination)))
 capture(0.,'reference');capture(30.,'perspective')
 document.unlink()
 undone=live.ok('motion_history',dict(operation='undo'));assert next(l for l in undone['project']['layers'] if l['id']==700).get('tracking_plane') is None
 redone=live.ok('motion_history',dict(operation='redo'));assert redone['project']==bound['project']
 # A genuinely keyed manual corner correction remains independent from the raw solve.
 edit([dict(op='effect',object=700,action=dict(kind='animate',effect=99,param='tl',frame=0,enabled=True)),dict(op='effect',object=700,action=dict(kind='set',effect=99,param='tl',frame=30,value=[5.,-3.,0.,0.]))])
 capture(30.,'corrected',True)
 corrected=live.state()['project'];authored=next(l for l in corrected['layers'] if l['id']==700)['effects'][0]['params']['tl']['track'];assert len(authored['keys'])==2,authored
 live.ok('motion_seek',dict(frame=0.))
 strict=copy.deepcopy(binding);strict['max_gap_ticks']=0
 strict_state=edit([dict(op='set_tracking_plane',object=700,binding=strict)])
 failed=live.call('motion_seek',dict(frame=0.5));assert failed['isError'] and 'plane interpolation gap exceeds policy' in failed['content'][0]['text'],failed
 recovered=live.ok('motion_edit',dict(commands=[dict(op='set_tracking_plane',object=700,binding=binding)],expectedRevision=strict_state['revision']))
 assert recovered['project']==corrected
 live.ok('motion_save',{});live.close()
 saved=json.loads((project_root/'project.json').read_text(encoding='utf-8'));assert saved['version']==34 and saved['tracking_assets'][0]['data']['tracks'][0]['samples'][24]['manual_correction'] is True
 reopen=Rpc('readonly-reopen',True);assert reopen.state()['project']==corrected;reopen.close()
 from PIL import Image
 import math
 for row in rows:
  img=Image.open(row['path']).convert('RGB');assert img.size==(640,480)
  quad=row['worldQuad'];errors=inside=outside=0
  for y in range(480):
   for x in range(640):
    distances=[]
    for i in range(4):
     a,b=quad[i],quad[(i+1)%4];dx,dy=b[0]-a[0],b[1]-a[1]
     distances.append((dx*(y+0.5-a[1])-dy*(x+0.5-a[0]))/math.hypot(dx,dy))
    if min(abs(d) for d in distances)<2.:continue
    wanted=min(distances)>0.;color=img.getpixel((x,y));seen=color[2]>120 and color[1]>80 and color[0]<100
    inside+=wanted;outside+=not wanted;errors+=wanted!=seen
  row['oracle']=dict(interior=inside,exterior=outside,mismatched=errors,edgeExclusionPixels=2.)
  assert inside>10000 and outside>200000 and errors==0,row
 report['samples']=rows
 log=(OUT/'plane-binding.file.log').read_text(encoding='utf-8');stderr=(OUT/'plane-binding.stderr.log').read_text(encoding='utf-8',errors='replace')
 for sink in [log,stderr]:
  assert 'phase=binding object=700 asset=2 track=absent' in sink and re.search(r'error #\d+',sink),sink[-4000:]
  assert 'phase=sample object=700 asset=2 track=plane-motion frame=0.5' in sink and 'plane interpolation gap exceeds policy' in sink,sink[-4000:]
 assert ' INFO ' in log and re.search(r'start #\d+ import_tracking',log)
 identity();report.update(status='accepted_native_plane_increment_not_full_issue',originalSha256=hashlib.sha256(original).hexdigest(),frames=len(pts),sourceSha256=solve['source_sha256'])
except BaseException as error:report.update(status='failed',failure=repr(error));raise
finally:
 for rpc in list(active):
  try:rpc.close()
  except BaseException as secondary:report.setdefault('cleanupFailures',[]).append(repr(secondary))
 report['completedUtc']=now();save()
