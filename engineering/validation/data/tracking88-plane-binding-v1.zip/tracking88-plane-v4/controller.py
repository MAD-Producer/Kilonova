"""Source-bound serial regression for the new planar binding increment."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88';OUT=ROOT/'artifacts/pr-queue/tracking88-plane-v4'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def now():return datetime.now(timezone.utc).isoformat()
names=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
sources={n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (WORK/n).is_file()}
report=dict(status='running',controllerPid=os.getpid(),source=sources,startedUtc=now(),steps=[],scope='Plane increment only; previous native/compiler crashes and strict #82 performance failures remain unresolved')
def save():
 p=OUT/'pending.json'
 with p.open('w',encoding='utf-8') as f:json.dump(report,f,indent=2);f.flush();os.fsync(f.fileno())
 p.replace(OUT/'exit.json')
def identity():
 for n,h in sources.items():assert hashlib.sha256((WORK/n).read_bytes()).hexdigest()==h,n
env=os.environ.copy();env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',PYTHONUTF8='1')
steps=[('model',['cargo','test','-p','motion-model','--locked','--offline']),('core',['cargo','test','-p','motion-core','--locked','--offline']),('host-tracking',['cargo','test','-p','motion-host','tracking','--locked','--offline','--','--test-threads=1']),('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg','--locked','--offline']),('provenance',['python','tools/validate_provenance.py'])]
save()
try:
 for name,args in steps:
  identity();row=dict(name=name,command=args,startedUtc=now());report['steps'].append(row);save()
  with (OUT/(name+'.log')).open('wb') as output:
   p=subprocess.Popen(args,cwd=WORK,env=env,stdout=output,stderr=subprocess.STDOUT);row['pid']=p.pid;save();row['exitCode']=p.wait()
   output.flush();os.fsync(output.fileno())
  row['completedUtc']=now();save();assert row['exitCode']==0,row
 identity();report['status']='accepted_targeted_plane_increment_not_full_issue'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=now();save()
