"""Archive terminal exact-source receipts; partial logs are never acceptance."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, subprocess, zipfile
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88';BASE=ROOT/'artifacts/pr-queue'
native=BASE/'tracking88-plane-native-v2';regression=BASE/'tracking88-plane-v4'
n=json.loads((native/'exit.json').read_text(encoding='utf-8'));r=json.loads((regression/'exit.json').read_text(encoding='utf-8'))
assert n['status']=='accepted_native_plane_increment_not_full_issue',n['status']
assert r['status']=='accepted_targeted_plane_increment_not_full_issue',r['status']
assert n['source']==r['source']
for name,h in r['source'].items():assert hashlib.sha256((WORK/name).read_bytes()).hexdigest()==h,name
assert len(r['steps'])==5 and all(s['exitCode']==0 for s in r['steps'])
assert all(s['exitCode']==0 for s in n['steps'])
counts={}
for name in ['model','core','host-tracking']:
 text=(regression/(name+'.log')).read_text(encoding='utf-8');assert '\x00' not in text
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
 assert rows,name
 counts[name]=[sum(int(t[i]) for t in rows) for i in range(3)]
assert counts['model']==[232,0,0] and counts['core']==[481,0,1] and counts['host-tracking']==[49,0,0],counts
assert all(x['oracle']['mismatched']==0 for x in n['samples'])
archive=WORK/'engineering/validation/data/tracking88-plane-binding-v1.zip'
files={}
for label in ['tracking88-plane-v1','tracking88-plane-v2','tracking88-plane-v3','tracking88-plane-v4','tracking88-plane-native-v1','tracking88-plane-native-v2']:
 base=BASE/label
 for p in base.rglob('*'):
  if not p.is_file():continue
  relative=p.relative_to(base)
  # Existing builtin caches are reproducible dependencies, not new evidence.
  if relative.parts[0]=='plugins':continue
  assert p.stat().st_size<10*1024*1024,(p,p.stat().st_size)
  files[label+'/'+relative.as_posix()]=p
for name in r['source']:files['source/'+name]=WORK/name
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(files)
 for name,p in files.items():assert z.read(name)==p.read_bytes(),name
archive_info=dict(path=archive.name,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size,members=len(files))
closeout=dict(status='accepted_planar_runtime_increment_not_full_issue',createdUtc=datetime.now(timezone.utc).isoformat(),parentCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),source=r['source'],archive=archive_info,counts=counts,nativeExeSha256=n['steps'][1]['exeSha256'],nativeStatus=n['status'],regressionStatus=r['status'],pending=['calibrated camera runtime','known-camera and real-footage reprojection','lens/output and relink/cache/exposure integration','full maintained desktop/workspace and cross-platform CI','previous native/compiler fault causes','#82 strict P95 and GPU coverage'])
receipt=WORK/'engineering/validation/data/tracking88-plane-binding-closeout.json'
with receipt.open('x',encoding='utf-8') as f:json.dump(closeout,f,indent=2);f.write('\n')
doc=(ROOT/'.tools/issue-closure-review/tracking88-plane-draft.md').read_text(encoding='utf-8')
summary='''Local exact-source regression completed with model **232 passed / 0 failed /
0 ignored**, core **481 passed / 0 failed / 1 ignored** (the existing manual
large-document history benchmark), and selected host tracking **49 passed /
0 failed / 0 ignored**. Full model/core tests include their doc tests. The
FFmpeg-enabled desktop check and provenance guard passed. No new ignore or
weakened existing assertion was added. These selected host controls are not a
full-host rerun or native-crash repair.
'''
doc=doc.replace('REGRESSION_RESULTS_PENDING',summary)
doc+='\nArchive: `'+archive_info['path']+'`, '+str(archive_info['bytes'])+' bytes, '+str(archive_info['members'])+' members; SHA-256 `'+archive_info['sha256']+'`. Every archived member was read back and byte-compared. Exact source hashes are in `data/tracking88-plane-binding-closeout.json`.\n'
with (WORK/'engineering/validation/tracking88-plane-binding-current.md').open('x',encoding='utf-8') as f:f.write(doc)
print(json.dumps(closeout,indent=2))
