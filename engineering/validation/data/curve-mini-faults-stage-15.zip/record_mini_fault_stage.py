from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges';out=root/'.tools/curve-view-ranges';attempt=sys.argv[1]
stage=out/('app-stage-'+attempt);r=json.loads((stage/'receipt.json').read_text(encoding='utf8'))
assert r['build_exit_code']==0 and r['source_unchanged'] and len(r['runs'])==9 and all(run['exit_code']==0 for run in r['runs'])
assert all(hashlib.sha256((work/path).read_bytes()).hexdigest()==digest for path,digest in r['sources'].items())
inventory=json.loads((out/'graph-observation-inventory.json').read_text(encoding='utf8'));assert inventory['head']==r['head']
names=[];counts={}
for run in r['runs']:
 found=re.findall(r'^test ([a-zA-Z0-9_:]+) \.\.\. ',(stage/(run['name']+'.log')).read_text(encoding='utf8'),re.M)
 assert run['summary'][-1]==['ok',str(len(found)),'0','0'];names.extend(found);counts[run['name']]=len(found)
assert len(names)==len(set(names))==131
processes=[]
for run in ['first-process','reset-process']:
 folder=stage/'mini-default-info'/run;e=json.loads((folder/'result.json').read_text(encoding='utf8'))
 assert set(e['sites'])==set(inventory['verified_new_sites'])
 assert all(e[key] for key in ['sameSourceFailuresCached','firstWarnAndErrorAtLifetime60','suppressedAfter60','healthyRecoveryPreservesCounterScope','actualConsumers','normalMissingAndNoIntervalQuiet','originalCausesRetained','sourceUnchanged'])
 file=(folder/'motion-studio.log').read_text(encoding='utf8');stderr=(folder/'stderr.log').read_text(encoding='utf8');stdout=(folder/'stdout.log').read_text(encoding='utf8')
 for site in inventory['verified_new_sites']:
  lines=[line for line in file.splitlines() if 'site='+site+' ' in line]
  assert len(lines)==2 and 'WARN' in lines[0] and 'count=1 ' in lines[0] and 'ERROR' in lines[1] and 'count=60 ' in lines[1]
  assert sum('site='+site+' ' in line for line in stderr.splitlines())==1
 assert len(stderr.splitlines())==4 and 'WARN' not in stderr and 'ERROR' not in stdout and 'panel degradation' not in stdout
 processes.append(dict(run=run,verified_sites=e['sites'],file_sha256=hashlib.sha256((folder/'motion-studio.log').read_bytes()).hexdigest(),stderr_errors=4,stdout_diagnostics=0))
guide=root/'.tools/viewer-guides';merged=json.loads((guide/'merged-receipt.json').read_text(encoding='utf8'));cleanup=json.loads((guide/'remote-cleanup-receipt.json').read_text(encoding='utf8'))
assert merged['verification_passed'] and merged['actual_tree']==merged['expected_tree'] and cleanup['deleted']
assert merged['final']['mergeCommit']['oid']==inventory['base_main']
delta=subprocess.check_output(['git','diff','--name-only','origin/main...HEAD'],cwd=work,encoding='utf8').splitlines()
assert not any(path.startswith(('crates/','desktop/app/src/panels/viewer_guides','engineering/validation/viewer-guides')) for path in delta)
files={name:out/name for name in ['verify_app_stage.py','discover_graph_observations.py','graph-observation-inventory.json','resolve_guides_squash.py','guides-main-merge-resolution.json','record_mini_fault_stage.py']}
for folder in sorted(out.glob('app-stage-*')):
 if 14<=int(folder.name.rsplit('-',1)[1])<=int(attempt):
  files.update({str(p.relative_to(out)).replace('\\','/'):p for p in folder.rglob('*') if p.is_file()})
for name in ['ci-success-receipt.json','desktop-cases-ci-receipt.json','merged-receipt.json','remote-cleanup-receipt.json']:
 files['related-guides/'+name]=guide/name
archive=work/('engineering/validation/data/curve-mini-faults-stage-'+attempt+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in files.items():z.write(p,name)
 z.writestr('manifest.json',json.dumps({name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in files.items()},indent=2))
record=dict(head=r['head'],binary_sha256=r['binary_sha256'],base_main=inventory['base_main'],source_unchanged=True,stage=stage.name,counts=counts,unique_cases=131,cases=names,
 new_sites=inventory['sites'],verified_new_sites=inventory['verified_new_sites'],pending_new_sites=inventory['pending_new_sites'],fault_processes=processes,
 guide_pr=dict(number=519,state='MERGED',commit=inventory['base_main'],tree=merged['actual_tree'],five_checks_verified=True,portable_cases_each_desktop=130,remote_deleted=True),
 status='MINI_FOUR_DEFAULT_FAILURE_SITES_VERIFIED; ISSUE259_INCOMPLETE; no259 PR or closure',
 remaining=['16 other new observation sites need actual failure evidence or justified boundary dispositions','Full new range native EN/ZH main/float/min/default/DPI/high-zoom/IME/cancel/stale acceptance','Actual saved-file byte invariance and performance; final all-targets/current-main/CI checks before259PR'],
 archive=dict(path='data/'+archive.name,bytes=archive.stat().st_size,entries=len(files)+1,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
(work/'engineering/validation/curve-mini-faults-progress-results.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
rows='\n'.join('| `'+entry['site']+'` | `'+entry['path']+':'+str(entry['line'])+'` | '+('新增，默认信道实际验证' if entry['site'] in inventory['verified_new_sites'] else '新增，待验证/边界处置' if entry['new_in_issue259'] else '原有，只记回归覆盖')+' |' for entry in inventory['sites'])
prior=work/'engineering/validation/curve-mini-ranges-progress.md';previous=prior.read_text(encoding='utf8')
baseline=previous.split('| 基线 | 处置与原因 |',1)[1].split('[结构化结果]',1)[0]
doc=f'''# Mini默认故障信道、缓存恢复与主分支接续（#259，未完成）

接续[Mini范围阶段](curve-mini-ranges-progress.md)。当前实际编译源码 `{r['head']}`、二进制SHA-256 `{r['binary_sha256']}`，Rust/WGSL/Cargo/样式来源哈希前后相同；本阶段131个不同桌面用例通过，仍未完成完整#259。无新增依赖或第三方资产。

## 交付与真实合并边界

[PR #519](https://github.com/MAD-Producer/Kilonova/pull/519)五项非跳过检查全部通过；三平台Desktop日志各确认130项既有相关回归。五项实际checkout同为7a4ae98541f7c2d47e795760cd73900f73c2c633、树1df38885a6ba3b37ae9f61cfdf97e5c3c6d7e586，与当时完整合并结果相同后才执行中文squash。实际提交 `{inventory['base_main']}`，唯一父为4184f0c8，树与预检相同，#263自动关闭。仅自己的远端codex/viewer-guides按精确head租约删除，保留本地工作树。

曲线分支合入该主分支时，DESIGN/keyboard/mod的冲突保留完整范围规则、输入门控和overlay；完成文档保留主分支新增场景验证链接。逐块检查后，三个产品/设计文件与合入前本分支的规范化内容一致，没有借机删掉新菜单路由；再编译运行131项。当前与main差异没有参考线模块或crates文件。这只证明本阶段接续和所列回归，不把#519 CI冒称#259 CI或完整组合验收。

## 默认信道实际证据

新增测试直接走View.draw、实际Data解码、Core导数和物理单位采样，不调用假的observe结果或改模型返回值。删除MOTION_LOG覆盖，以默认Info运行两次独立子进程。健康分支先显式flush，然后核对只有logger初始化Info一条；正常缺失通道/无输出区间不计为故障。

| 站点 | 实际触发 | 验证 |
|---|---|---|
| curve.mini.fit_all | 零高度绘图区造成真实InvalidGeometry；后续更换几何、恢复有效几何 | 相同失败几何缓存；成功后恢复折线。 |
| curve.mini.readout_load | provider快照关键帧frame改为not-a-frame，实际serde/Track解码失败 | 相同失败来源120次仍只一次观测；换revision重新加载，恢复正确数据。 |
| curve.mini.readout_fps | provider快照fps=0 | 显示实际读数不可用，正确fps恢复物理单位。 |
| curve.mini.readout_sample | provider携带有限但非法的1e308fps，真实导数转f32物理样本溢出 | Data返回原始non-finite错误，不显示部分成功卡片，正确fps恢复。 |

零几何是显示边界，0/1e308fps是降级provider快照故障，不声称是合法工程值。每站点在文件保留首Warn和进程寿命累计第60次Error，此后抑制；交错成功不重置既有寿命计数。stderr恰好各站点1条Error、没有Warn；stdout没有诊断。每进程4条Error、两进程独立从首Warn起步，证明进程重置。保留原始not-a-frame、fps缺失、模型non-finite和geometry原因；新增phase、目标、generation/revision与可测的耗时上下文。没有新增线程、重试、恢复动作或改变模型返回值。

新增正常行为验证覆盖未变视图120次复用几何、缩放仅重建折线、尺寸/模式变更、移出归一化域的正常空折线；选区区分Unowned/Empty/Stale和双端点；中英主/浮窗Ctrl X、Ctrl+Alt Y指针锚定缩放、Shift X平移，面板滚动和共享时间轴不动。用例总数131包含一次父测试，两个故障子进程不是额外两个测试数。

stage14也通过131项，并显式重跑既有忽略的原生剪贴板回归1项/6截图（源码6230f8f3）。stage15在合入main并强化flush核对后重编译运行131项；没有在stage15重跑该原生用例，保留其准确来源，不用旧截图证明新增菜单原生验收。旧stage13及更早证据仍是历史记录。

## 完整站点处置表

以当前main72d23d74的同名调用点为原有覆盖，四个相关渲染器共计20个新增站点，4个已实际验证默认信道、16个待故障证据或有根据的边界处置；没有把待验证站点标成修复。旧加载故障、纯细分测试或本阶段四站点不能替代其证据。

| 站点 | 当前源码位置 | 处置 |
|---|---|---|
{rows}

## DESIGN §0.7逐项处置及余项

本阶段改观察上下文和测试；不改面板行/颜色/尺寸，既有12处继续逐项保留，不宣称修复。

| 基线 | 处置与原因 |{baseline}

完整新范围菜单原生中英主/浮窗、最小/default/DPI、高倍率、IME/失效/取消、实际保存文件字节、性能、最终all-targets/main组合和#259自身CI仍待完成。完整DESIGN12未通过，不提交完成PR或关闭#259。

[结构化结果](curve-mini-faults-progress-results.json) · [原始证据包]({record['archive']['path']})：{record['archive']['entries']}项/{record['archive']['bytes']}字节，SHA-256 `{record['archive']['sha256']}`。
'''
(work/'engineering/validation/curve-mini-faults-progress.md').write_text(doc,encoding='utf8')
marker='后续四个Mini默认故障站点、缓存恢复及已合并519主分支接续见[故障阶段](curve-mini-faults-progress.md)；其余新增站点和完整#259验收仍待完成。'
if marker not in previous:prior.write_text(previous.replace('\n\n','\n\n'+marker+'\n\n',1),encoding='utf8')
print(json.dumps({key:value for key,value in record.items() if key not in ['cases','new_sites']},ensure_ascii=False))
