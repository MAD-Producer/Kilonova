from pathlib import Path
import json,re,subprocess
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges';out=root/'.tools/curve-view-ranges'
base=subprocess.check_output(['git','rev-parse','origin/main'],cwd=work,encoding='utf8').strip()
paths=['desktop/app/src/panels/timeline_graph.rs','desktop/app/src/panels/effect_timeline/graph.rs','desktop/app/src/panels/curve_comparison/view.rs','desktop/app/src/panels/animation_controls/mini.rs']
pattern=re.compile(r'observe!\(\s*"([^"]+)"')
verified={'curve.mini.fit_all','curve.mini.readout_load','curve.mini.readout_fps','curve.mini.readout_sample'}
records=[]
for path in paths:
 result=subprocess.run(['git','show',base+':'+path],cwd=work,encoding='utf8',stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 assert result.returncode==0 or result.returncode==128 and path.endswith('animation_controls/mini.rs'),(path,result.returncode)
 existing=set(pattern.findall(result.stdout))
 source=(work/path).read_text(encoding='utf8')
 for match in pattern.finditer(source):
  site=match.group(1);new=site not in existing
  disposition='new observation: actual default channels verified' if site in verified else 'new observation: pending actual failure/channel evidence' if new else 'existing observation: regression evidence only'
  records.append(dict(site=site,path=path,line=source[:match.start()].count('\n')+1,new_in_issue259=new,disposition=disposition))
assert verified.issubset({r['site'] for r in records})
record=dict(base_main=base,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,encoding='utf8').strip(),sites=records,
 verified_new_sites=sorted(verified),pending_new_sites=sorted({r['site'] for r in records if r['new_in_issue259'] and r['site'] not in verified}),
 limits='Existing sites are identified by exact literal call-site names in main. This inventory is not a claim that all graph faults are fixed or exercised. Mini adaptive and normalized-readout guard branches remain pending, not inferred covered by fit/readout-load tests.')
(out/'graph-observation-inventory.json').write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps(record,indent=2))
