from pathlib import Path
import re,subprocess,json
work=Path('E:/Dev/aem/.worktrees/curve-view-ranges')
def git(*args):return subprocess.check_output(['git',*args],cwd=work,encoding='utf8').strip()
assert git('rev-parse','MERGE_HEAD')=='72d23d740f7885d7a3c1d118fd5e547564e3ccc1'
pattern=re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> origin/main\n',re.M|re.S)
items={'DESIGN.md':(0,1),'desktop/app/src/panels/keyboard.rs':(0,1),'desktop/app/src/panels/mod.rs':(0,5),'engineering/validation/viewer-guides-completion.md':(1,1)}
records=[]
for path,(side,expected) in items.items():
 p=work/path;text=p.read_text(encoding='utf8');matches=list(pattern.finditer(text));assert len(matches)==expected,(path,len(matches))
 # These exact hunks were inspected: graph input/overlay/lock additions are
 # retained; the guide completion document gains its new scene-proof link.
 result=pattern.sub(lambda m:m.group(side+1),text)
 assert not re.search(r'^<<<<<<<|^=======|^>>>>>>>',result,re.M)
 p.write_text(result,encoding='utf8')
 same_as_before=git('show','HEAD:'+path).replace('\r\n','\n')==result.strip()
 if side==0:assert same_as_before,path
 records.append(dict(path=path,hunks=expected,selected='graph additions' if side==0 else 'latest scene proof link',same_as_before=same_as_before))
(Path('E:/Dev/aem/.tools/curve-view-ranges')/'guides-main-merge-resolution.json').write_text(json.dumps(records,indent=2),encoding='utf8')
print(json.dumps(records))
