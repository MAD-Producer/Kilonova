"""Verify and retain actual worker/default-sink IR failure acceptance."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/render-dag'
LABEL = sys.argv[1]
assert re.fullmatch(r'ir-output-v[0-9]+', LABEL)
OUT = ROOT / 'artifacts/pr-queue' / ('issue78-numeric-' + LABEL)
accepted = json.loads((OUT / 'accepted.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()


def current_source():
    names = set()
    for args in [('diff', '--name-only', '-z', '302a15bfb0a69b52df89c69da63bd7bbd25e3e1e'),
                 ('ls-files', '--others', '--exclude-standard', '-z')]:
        names.update(p.decode() for p in subprocess.check_output(['git', *args], cwd=WORK).split(b'\0') if p)
    return {p: sha((WORK / p).read_bytes()) for p in sorted(names)
            if (WORK / p).is_file() and (p.endswith('.rs') or p.endswith('Cargo.toml') or p == 'Cargo.lock')}


assert accepted['sourceUnchanged'] and accepted['source'] == current_source()
steps = accepted['steps']
assert [s['name'] for s in steps] == ['desktop-check', 'ir-default-output', 'render-no-diagnostics-check',
                                     'render-ir', 'existing-compiler-output', 'existing-worker-api']
for step in steps:
    assert step['exitCode'] == 0 and step['sourceUnchanged']
    for stream in ['stdout', 'stderr']:
        assert sha((OUT / step['name'] / (stream + '.log')).read_bytes()) == step[stream + 'Sha256']
    if not step['name'].endswith('check'):
        assert step['totals']['passed'] > 0 and step['totals']['failed'] == step['totals']['ignored'] == 0

case = OUT / 'output-artifacts/default-ir-faults'
receipt = json.loads((case / 'receipt.json').read_text())
assert receipt['recoveries'] == 6 and receipt['same_renderer'] and receipt['healthy_pixels_equal']
assert receipt['pipeline_builds_added'] == 0
assert [f['mode'] for f in receipt['failures']] == [0, 1, 2, 0, 1, 2]
assert all(f['pixels_preserved'] and f['pipeline_builds_added'] == 0 for f in receipt['failures'])
file = (case / 'logs/motion-studio.log').read_text()
console = (case / 'stderr.log').read_text()
stdout = (case / 'stdout.log').read_text()
for output, count in [(file, 6), (console, 6), (stdout, 0)]:
    errors = [line for line in output.splitlines() if 'error #' in line and 'phase=effect_ir_check' in line]
    assert len(errors) == count
    for error in errors:
        assert 'layer=47' in error and 'effect=Some(11)' in error and 'ms:' in error
        request = error.split('error #', 1)[1].split()[0]
        assert file.index(f'start #{request} test_study') < file.index(error.split('error #', 1)[1])
for phase in ['phase=topology: cycle', 'phase=value_contract:', 'phase=admission:']:
    assert sum('error #' in line and phase in line for line in file.splitlines()) == 2
    assert phase in console and phase not in stdout
assert 'start #' not in console and 'start #' not in stdout

command = ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--check',
           'crates/motion-render/src/effect_plan/execution_fault.rs',
           'crates/motion-render/src/effect_plan/effect_execution.rs',
           'desktop/app/src/logging/execution_ir_tests.rs']
subprocess.run(command, cwd=WORK, check=True, capture_output=True)
rebase = ROOT / '.tools/issue-closure-review/issue78-pre-rebase-20261025'
rebase_proof = json.loads((rebase / 'rebase-proof.json').read_text())
assert not subprocess.check_output(['git', 'diff', '--name-only', rebase_proof['main'], '--',
                                    'desktop/app/src/panels', 'android'], cwd=WORK).strip()
files = {}
attempts = []
for folder in sorted((ROOT / 'artifacts/pr-queue').glob('issue78-numeric-ir-output-v*')):
    attempt = json.loads((folder / 'exit.json').read_text())
    success = (folder / 'accepted.json').exists()
    assert success or attempt['steps'][-1]['exitCode'] != 0, 'A live attempt cannot be archived'
    assert all(s['sourceUnchanged'] for s in attempt['steps'])
    attempts.append(dict(label=folder.name, accepted=success, lastExitCode=attempt['steps'][-1]['exitCode']))
    for path in sorted(folder.rglob('*')):
        if path.is_file() and path.name != 'archive-verification.json':
            files['attempts/' + folder.name + '/' + path.relative_to(folder).as_posix()] = path.read_bytes()
files['controller/archive.py'] = Path(__file__).read_bytes()
files['patch/tracked.patch'] = subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=WORK)
assert accepted['head'] == rebase_proof['head']
subprocess.run(['git', 'merge-base', '--is-ancestor', rebase_proof['main'], 'HEAD'], cwd=WORK, check=True)
for path in sorted(rebase.rglob('*')):
    if path.is_file():
        files['main-rebase/' + path.relative_to(rebase).as_posix()] = path.read_bytes()
total = sum(s.get('totals', {}).get('passed', 0) for s in steps)
manifest = dict(createdUtc=datetime.now(timezone.utc).isoformat(), head=accepted['head'], mainRebase=rebase_proof,
                source=accepted['source'], attempts=attempts, distinctPasses=total,
                scope='Actual cycle/type/pass-budget checks through worker, default file/Error stderr, stdout isolation, same-renderer pixels/recovery; targeted desktop checkpoint',
                limitations=['The diagnostic gateway injects actual negative IR inputs and is absent from release',
                             'This is not final full-workspace or cross-platform acceptance',
                             'Initial semantic frontend, typed imports, bounded parallel CPU preparation and measured end-to-end costs remain pending',
                             'All Android work excluded by user instruction'],
                files={name: sha(data) for name, data in sorted(files.items())})
archive = WORK / ('engineering/validation/data/typed-render-dag-ir-output-' + accepted['head'][:8] + '.zip')
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(files.items()):
        z.writestr(name, data)
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(files) | {'manifest.json'}
    assert all(sha(z.read(name)) == digest for name, digest in manifest['files'].items())
assert accepted['source'] == current_source()
result = dict(archive=str(archive), bytes=archive.stat().st_size, files=len(files), sha256=sha(archive.read_bytes()),
              sourcesVerified=len(accepted['source']), distinctPasses=total)
(OUT / 'archive-verification.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
