from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/professional-api86-matte-default-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
prior = json.loads((root / 'artifacts/pr-queue/professional-api86-matte-final-v1/exit.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(work / p) == digest for p, digest in prior['sources'].items())
command = ['cargo','test','-p','motion-host','-p','motion-desktop-media','--test','layer_time_mapping','--test','professional_mattes','--no-default-features','--features','motion-desktop-media/gpu-tests','--locked','--offline','--','--test-threads=1']
report = dict(scope='Native public mask/matte/precompose and original host integration tests with FFmpeg disabled', command=command, sources=prior['sources'], status='running')
os.environ['MOTION_PROFESSIONAL_MATTE_ARTIFACTS'] = str(out / 'matte-shot')
started = time.monotonic()
with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
    report['exitCode'] = subprocess.call(command, cwd=work, stdout=stdout, stderr=stderr)
report['elapsedSeconds'] = round(time.monotonic()-started, 3)
report['sourceUnchanged'] = all(sha(work / p) == digest for p, digest in prior['sources'].items())
report['status'] = 'passed' if report['exitCode'] == 0 and report['sourceUnchanged'] else 'failed'
(out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='sources'}), flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
