from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/professional-api86-ci-policy-v2'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
prior = json.loads((root / 'artifacts/pr-queue/professional-api86-matte-final-v1/exit.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(work / p) == digest for p, digest in prior['sources'].items())
command = [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_ci_*.py', '-v']
report = dict(scope='Original Python CI policy tests after installing existing CI pin PyYAML 6.0.3 and materializing sparse-excluded Android test inventory; inventory only, no Android execution', command=command, sources=prior['sources'], prior='professional-api86-matte-final-v1', status='running')
started = time.monotonic()
with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
    report['exitCode'] = subprocess.call(command, cwd=work, stdout=stdout, stderr=stderr)
report['elapsedSeconds'] = round(time.monotonic()-started, 3)
report['sourceUnchanged'] = all(sha(work / p) == digest for p, digest in prior['sources'].items())
report['status'] = 'passed' if report['exitCode'] == 0 and report['sourceUnchanged'] else 'failed'
(out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='sources'}), flush=True)
sys.exit(0 if report['status']=='passed' else 1)
