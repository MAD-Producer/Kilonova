from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/professional-api86-matte-final-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = {p.relative_to(work).as_posix():sha(p) for folder in ['crates','desktop','tools','.github'] for p in (work / folder).rglob('*') if p.is_file() and (p.suffix in ['.rs','.wgsl','.py','.yml','.toml'])}; sources['Cargo.lock']=sha(work/'Cargo.lock'); sources['Cargo.toml']=sha(work/'Cargo.toml')
report = dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),sources=sources,results=[],
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),
    scope='Final config after explicitly disabling local graph dev-dependency defaults: actual matte/node/camera/FFmpeg/color-output and mask cache/admission plus existing composition contracts and original CI policy tests; hashes include Rust, WGSL, Python, workflows, manifests and lockfile. Not full workspace/desktop or complete issue86')
save = lambda: (out / 'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
os.environ['MOTION_PROFESSIONAL_MATTE_ARTIFACTS'] = str(out / 'matte-shot')
started = time.monotonic()
save()
try:
    commands = [('native-matte-shot-and-host-contract', ['cargo', 'test', '-p', 'motion-host', '-p', 'motion-render', '-p', 'motion-desktop-media', '--test', 'color_output', '--test', 'layer_time_mapping', '--test', 'professional_mattes', '--test', 'node_parameter_animation', '--test', 'professional_compositing', '--no-default-features', '--features', 'motion-desktop-media/ffmpeg,motion-desktop-media/gpu-tests,motion-render/gpu-tests', '--locked', '--offline', '--', '--test-threads=1']), ('mask-cache-and-admission', ['cargo', 'test', '-p', 'motion-host', '-p', 'motion-render', '--lib', 'mask_gpu::reuse_tests', '--no-default-features', '--features', 'motion-render/gpu-tests', '--locked', '--offline', '--', '--test-threads=1']), ('existing-composition-and-matte-contracts', ['cargo', 'test', '-p', 'motion-core', '-p', 'motion-host', '-p', 'motion-render', '--test', 'compositions', '--test', 'layer_masks', '--test', 'track_mattes', '--test', 'layer_time_mapping', '--no-default-features', '--features', 'motion-render/gpu-tests', '--locked', '--offline', '--', '--test-threads=1']), ('ci-policy', ['E:\\Dev\\aem\\.tools\\ai-depth74\\venv\\Scripts\\python.exe', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_ci_*.py', '-v'])]
    for name,command in commands:
        item = dict(name=name,command=command,status='running')
        report['results'].append(item)
        save()
        began = time.monotonic()
        with (out / f'{name}.stdout.log').open('wb') as stdout,(out / f'{name}.stderr.log').open('wb') as stderr:
            child = subprocess.Popen(command,cwd=work,env=os.environ.copy(),stdout=stdout,stderr=stderr)
            item['pid'] = child.pid
            save()
            item['exitCode'] = child.wait()
        item['elapsedSeconds'] = round(time.monotonic()-began,3)
        item['summaries'] = re.findall(r'^test result: .+$',(out / f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
        item['status'] = 'passed' if item['exitCode'] == 0 else 'failed'
        save()
        print(json.dumps(item),flush=True)
    report['sourceUnchanged'] = all(sha(work / path) == digest for path,digest in sources.items())
    assert report['sourceUnchanged'] and all(item['exitCode'] == 0 for item in report['results']), 'host parameter gate failed; original logs retained'
    assert all(len(item['summaries']) == {'native-matte-shot-and-host-contract':5,'mask-cache-and-admission':2,'existing-composition-and-matte-contracts':6}[item['name']] and all('0 failed; 0 ignored' in summary for summary in item['summaries']) for item in report['results'] if item['name']!='ci-policy')
    report['status'] = 'matte_final_contract_passed_full_issue_acceptance_pending'
except BaseException as cause:
    report.update(status='failed',failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-started,3))
    save()
    print(json.dumps({key:report.get(key) for key in ['status','sourceUnchanged','elapsedSeconds','failure']}),flush=True)
