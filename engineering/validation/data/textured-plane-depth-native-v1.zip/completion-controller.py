"""Archive only executed source-bound acceptance, then commit the owned increment."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/textured-plane-depth'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
gate = root / 'artifacts/pr-queue/textured-plane-depth-native-v2'
receipt = json.loads((gate / 'accepted.json').read_text(encoding='utf-8'))
assert receipt['sourceUnchanged']
assert all(sha(work / p) == h for p, h in receipt['source'].items())
assert all(step['exitCode'] == 0 and step['sourceUnchanged'] for step in receipt['steps'])
native = receipt['nativeAcceptance']
assert native['totals']['failed'] == 0 and native['totals']['ignored'] == 0
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip() == '2d4553077d00f98047177453c0a3cabb2e85078f'
out = root / 'artifacts/pr-queue/textured-plane-depth-complete-v1'
out.mkdir(exist_ok=False)
archive = work / 'engineering/validation/data/textured-plane-depth-native-v1.zip'
assert not archive.exists()
evidence = {}
for name in ['textured-plane-depth-red-v1', 'textured-plane-depth-green-v1', 'textured-plane-depth-green-v2', 'textured-plane-depth-native-v1', 'textured-plane-depth-native-v2']:
    base = root / 'artifacts/pr-queue' / name
    for p in base.rglob('*'):
        if p.is_file():
            assert p.suffix not in ['.exe', '.dll', '.pyc']
            evidence[name + '/' + p.relative_to(base).as_posix()] = p.read_bytes()
evidence['completion-controller.py'] = Path(__file__).read_bytes()
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=work)
evidence['tracked-source.patch'] = patch
manifest = {name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in evidence.items()}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in evidence.items():
        z.writestr(name, data)
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(manifest) + 1 and z.testzip() is None
    for name, info in manifest.items():
        data = z.read(name)
        assert len(data) == info['bytes'] and hashlib.sha256(data).hexdigest() == info['sha256']
digest = sha(archive)
passed = native['totals']['passed']
doc = work / 'engineering/validation/textured-plane-depth-current.md'
assert not doc.exists()
doc.write_text(f'''# Opaque static-image planes in native shared geometry depth

## Behavior and ownership

This increment is based on the exact published PR528 head
`2d4553077d00f98047177453c0a3cabb2e85078f`. Contiguous meshes, solid planes,
and proven opaque static-image planes use one camera and hardware fragment
depth. Image UVs use perspective interpolation with authored image Y direction.
Layer order no longer replaces physical occlusion for these compatible runs.
Pure-plane scenes retain the original BSP path.

Opacity is recorded once from actual uploaded alpha bytes, with no per-frame
readback or image scan. A successful native image-plane encode freezes that
source revision. Its next upload admits a replacement texture before changing
the cache. Existing allocation-encoder reservations retain earlier revisions
until submission or abandonment, so queued frames keep their original pixels.
There is no per-frame texture copy or unbounded retired-image map. A revision
stays frozen until replaced even after GPU completion; the extra allocation
occurs on a later source upload, never on a healthy unchanged frame.

Solid vertices retain their existing 192-byte per-plane contract. Textured
vertices require 240 bytes. The pipeline cache has at most 16 keys: four working
formats, two sample counts, and two source kinds. Image IDs and animation do not
add cache keys. Generated images, vectors, video, effects and masks receive no
opaque-source fact by inference.

## Actual acceptance

The unchanged parent product fails both original GPU regressions: an image
covers the nearer mesh, and an in-place upload changes an already encoded
frame. The initial green attempt fails compilation on a missing generated-image
metadata initializer and temporary vertex attributes. Product compilation is
corrected; neither original regression test nor its assertions are changed.
The same two GPU tests then pass. Expanded coverage appends another module.
Its first run has 412 passes and one failure in the new retirement fixture:
it wrongly classifies the permanent white texture as a static image. The
existing breakdown explicitly records it as a system texture. Only that new
fixture is corrected to compare both categories against its actual initial
empty-catalog baseline. Product code, budgets, tolerances, original regressions
and pre-existing assertions remain unchanged; the failure history is retained.

Final source-bound acceptance has **{passed} passed, 0 failed, 0 ignored**
across {native['targets']} native targets: the 12 successful unchanged targets
(382 tests) are retained, and the complete corrected model target reruns with
31 passes. Source hashes prove the only intervening change is that new fixture.
Provenance, panel-style validation and desktop FFmpeg/AI-depth compilation
also pass. These are combined source-bound results, not one all-green original
controller execution. The six new native tests
cover saved/reopened real PNGs with deleted source files, both authored orders,
reverse submission and abandonment, all four working precisions at 1x/4x MSAA,
independent f64 camera/parent rays and multiple image regions, transparent-source
fallback and opaque recovery, exact one-byte-short texture/vertex refusals,
unchanged output after failure, successful recovery and deletion retirement.
Existing renderer, scene, mask, matte, composition, effect, exposure and nested
regressions are included as appropriate. Overlapping red/green counts are not
added to this final total.

## Remaining boundaries

This implements opaque static-image planes. Transparent planes still use the
existing independent composition path; their depth behavior is not claimed as
completed. Effects, masks, mattes, nesting, nonnormal blends and incompatible
sampling retain existing boundaries. Imported-camera project selection and
tracks, persisted current-frame depth calibration/reprojection and DOF remain
open with #74/#87. These tests do not constitute new full-workspace, GUI or
cross-platform acceptance. PR528's CI belongs to its own published head.

No UI/panel/style changes, dependencies or third-party assets are added.
Android is retired and excluded. Existing assertions, tolerances, budgets,
timeouts and ignored-test policy are unchanged. #74 and #87 remain open.

## Evidence

[Source-bound failures and final acceptance](data/textured-plane-depth-native-v1.zip): SHA-256 `{digest}`,
{archive.stat().st_size} bytes, {len(manifest) + 1} entries. Every entry is read
back and hash-verified. Only changed source is copied; complete source hashes
identify the executed baseline. Binaries and shared libraries are excluded.
''', encoding='utf-8', newline='\n')
assert not any(p.startswith('desktop/app/src/panels/') for p in receipt['changedSource'])
subprocess.run(['git', 'diff', '--check'], cwd=work, check=True)
subprocess.run(['git', 'diff', '--stat'], cwd=work, check=True)
paths = receipt['changedSource'] + [str(doc.relative_to(work)).replace('\\', '/'), str(archive.relative_to(work)).replace('\\', '/')]
subprocess.run(['git', 'add', '--', *paths], cwd=work, check=True)
message = out / 'commit-message.txt'
message.write_text('feat(render): 支持纹理平面共享深度与待提交帧独立图像\n\n- 接入不透明图片的逐片元深度与透视纹理坐标\n- 保留已编码帧引用的图片版本并纳入统一预算\n- 验证四种精度和透明回退及预算拒绝恢复\n- 归档真实失败和回归验收并记录剩余边界\n\nRefs #87\n', encoding='utf-8', newline='\n')
subprocess.run(['git', 'commit', '-F', str(message)], cwd=work, check=True)
subprocess.run(['git', 'show', '--stat', '--oneline', 'HEAD'], cwd=work, check=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=work).strip()
assert all(sha(work / p) == h for p, h in receipt['source'].items())
result = dict(completedUtc=datetime.now(timezone.utc).isoformat(), branch='feat/87-textured-plane-depth', head=head, parent='2d4553077d00f98047177453c0a3cabb2e85078f', totals=native['totals'], archiveSha256=digest, archiveBytes=archive.stat().st_size, entries=len(manifest) + 1, clean=True, published=False)
(out / 'completed.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result), flush=True)
