"""Correct an independently verified new fixture classification; retain actual failures."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

root = Path('E:/Dev/aem')
work = root / '.worktrees/textured-plane-depth'
prior_dir = root / 'artifacts/pr-queue/textured-plane-depth-native-v1'
prior = json.loads((prior_dir / 'exit.json').read_text(encoding='utf-8'))
original = next(s for s in prior['steps'] if s['name'] == 'native')
assert original['exitCode'] == 101 and original['sourceUnchanged']
assert original['targets'] == 13 and original['totals'] == dict(passed=412, failed=1, ignored=0)
fixture = 'crates/motion-render/tests/model_layers/textured_plane_contracts.rs'
old = (prior_dir / 'source' / fixture).read_text(encoding='utf-8')
marker = 'fn textured_plane_vertex_and_copy_on_write_budget_refuse_then_recover()'
start = old.index(marker)
end = old.index('\n#[test]', start)
part = old[start:end]
part = part.replace('    prepare(&mut renderer, &project, root.path());', '    let initial_memory = renderer.texture_memory_breakdown();\n    prepare(&mut renderer, &project, root.path());', 1)
part = part.replace('''    assert_eq!(
        memory.static_images, 4,
        "only the permanent white source remains"
    );''', '''    assert_eq!(
        memory.static_images, initial_memory.static_images,
        "static source bytes must return to the empty-catalog baseline"
    );
    assert_eq!(
        memory.system_textures, initial_memory.system_textures,
        "system textures, including the permanent white source, remain owned"
    );''')
assert (work / fixture).read_text(encoding='utf-8') == old[:start] + part + old[end:]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = {p: sha(work / p) for p in prior['source']}
assert [p for p, h in source.items() if h != prior['source'][p]] == [fixture]
text = (prior_dir / 'native.stdout.log').read_text(encoding='utf-8')
assert len(re.findall(r'test .* \.\.\. FAILED', text)) == 1
assert 'only the permanent white source remains' in text
assert 'TextureKey::Static(0) => memory.system_textures += image.bytes' in (work / 'crates/motion-render/src/renderer.rs').read_text(encoding='utf-8')
assert 'TextureKey::Static(_) => memory.static_images += image.bytes' in (work / 'crates/motion-render/src/renderer.rs').read_text(encoding='utf-8')

out = root / 'artifacts/pr-queue/textured-plane-depth-native-v2'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
dest = out / 'source' / fixture
dest.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(work / fixture, dest)
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG', None)
receipt = dict(startedUtc=datetime.now(timezone.utc).isoformat(), source=source, changedSource=prior['changedSource'], steps=[], originalNative=original,
    previousFailure='textured-plane-depth-native-v1: new fixture expected white texture in wrong disjoint category; raw failure retained',
    productUnchanged=True, fixtureChanges='Only empty-catalog baseline and system category checks in the new retirement fixture; original red and pre-existing assertions unchanged')
steps = [('provenance', [sys.executable, 'tools/validate_provenance.py']),
         ('panel-style', [sys.executable, '-c', "import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
         ('model-recheck', ['cargo', 'test', '-p', 'motion-render', '--features', 'gpu-tests', '--test', 'model_layers', '--locked', '--offline', '--', '--test-threads=1']),
         ('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline'])]
for name, cmd in steps:
    print(json.dumps(dict(start=name)), flush=True)
    with (out / (name + '.stdout.log')).open('wb') as so, (out / (name + '.stderr.log')).open('wb') as se:
        code = subprocess.run(cmd, cwd=work, env=env, stdout=so, stderr=se).returncode
    row = dict(name=name, command=cmd, exitCode=code, sourceUnchanged=all(sha(work / p) == h for p, h in source.items()))
    output = (out / (name + '.stdout.log')).read_text(encoding='utf-8')
    if name == 'model-recheck':
        results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', output)
        row['totals'] = dict(zip(('passed', 'failed', 'ignored'), map(int, results[0]))) if len(results) == 1 else None
    receipt['steps'].append(row)
    (out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], name
    if name == 'model-recheck':
        assert row['totals'] == dict(passed=31, failed=0, ignored=0)
        assert len(re.findall(r'test project_shared::mixed_planes::textured_planes::.* \.\.\. ok', output)) == 6
        assert len(re.findall(r'test project_shared::mixed_planes::mixed_plane_.* \.\.\. ok', output)) == 5
results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
assert len(results) == 13 and sum(int(v[1]) for v in results) == 1
failed = [tuple(map(int, v)) for v in results if int(v[1])]
assert failed == [(30, 1, 0)]
retained = sum(int(v[0]) for v in results if int(v[1]) == 0)
assert retained == 382
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=True,
    nativeAcceptance=dict(targets=13, totals=dict(passed=retained + 31, failed=0, ignored=0),
        retainedUnchangedTargets=12, retainedTests=retained, correctedModelTarget=31,
        evidence=['textured-plane-depth-native-v1: twelve successful targets with unchanged product source', 'textured-plane-depth-native-v2: full corrected model target and desktop check']))
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True, totals=receipt['nativeAcceptance']['totals'])), flush=True)
