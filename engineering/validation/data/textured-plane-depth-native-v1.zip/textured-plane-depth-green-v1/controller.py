"""Run the unchanged actual GPU red tests against the native image-plane bridge."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

root = Path('E:/Dev/aem')
work = root / '.worktrees/textured-plane-depth'
out = root / 'artifacts/pr-queue/textured-plane-depth-green-v1'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
red = json.loads((root / 'artifacts/pr-queue/textured-plane-depth-red-v1/reproduced.json').read_text(encoding='utf-8'))
for p in ['crates/motion-render/tests/model_layers/mixed_planes.rs', 'crates/motion-render/tests/model_layers/textured_planes.rs']:
    assert sha(work / p) == red['source'][p], p
paths = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard', '-z'], cwd=work).decode().split('\0')
source = {p: sha(work / p) for p in sorted(set(paths)) if p and (p.endswith(('.rs', '.toml', '.wgsl')) or p == 'Cargo.lock')}
changed = subprocess.check_output(['git', 'ls-files', '-mo', '--exclude-standard', '-z'], cwd=work).decode().split('\0')
for p in sorted(set(changed)):
    if p and (work / p).is_file():
        dest = out / 'source' / p
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(work / p, dest)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG', None)
cmd = ['cargo', 'test', '-p', 'motion-render', '--features', 'gpu-tests', '--test', 'model_layers', '--locked', '--offline', '--', 'textured_plane_', '--test-threads=1']
receipt = dict(startedUtc=datetime.now(timezone.utc).isoformat(), source=source, command=cmd, originalRed='textured-plane-depth-red-v1')
with (out / 'stdout.log').open('wb') as so, (out / 'stderr.log').open('wb') as se:
    receipt['exitCode'] = subprocess.run(cmd, cwd=work, env=env, stdout=so, stderr=se).returncode
text = (out / 'stdout.log').read_text(encoding='utf-8')
results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
if results:
    receipt['totals'] = dict(zip(('passed', 'failed', 'ignored'), map(int, results[0])))
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=all(sha(work / p) == h for p, h in source.items()))
(out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
assert len(results) == 1 and receipt['sourceUnchanged'] and receipt['exitCode'] == 0
assert receipt['totals'] == dict(passed=2, failed=0, ignored=0)
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True, totals=receipt['totals'])), flush=True)
