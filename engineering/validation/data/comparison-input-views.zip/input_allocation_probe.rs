use super::*;

#[test]
fn comparison_render_input_allocation_probe() {
    let directory = std::path::PathBuf::from(std::env::var_os("COMPARISON_PROBE_DIR").unwrap());
    std::fs::create_dir_all(&directory).unwrap();
    let engine = fixture();
    let state = state(&engine);
    let original = state.clone();
    let mut results = vec![];
    for locale in [Locale::En, Locale::Zh] {
        for width in [360., 1200.] {
            for mode in 0..4 {
                for modified in 0..4 {
                    let mut panels = setup(&state, locale);
                    let mut atlas = TextAtlas::from_system(12.).unwrap();
                    let input = Input {
                        text: "输入压力载荷".repeat(2048),
                        keys: vec![(Key::A, Modifiers::default()); 128],
                        key_repeats: vec![false; 128],
                        held_keys: vec![Key::A; 128],
                        released_keys: vec![Key::B; 128],
                        composing: mode == 1,
                        ime_consumed: mode == 2,
                        focus_lost: mode == 3,
                        modifiers: Modifiers {
                            control: modified == 1,
                            alt: modified == 2,
                            shift: modified == 3,
                            ..Default::default()
                        },
                        mouse: [100., 100.],
                        wheel: [0., -12.],
                        ..Default::default()
                    };
                    let before_input = format!("{:?}", motion_ui::input::InputSource::input_view(&input));
                    let mut final_paint = String::new();
                    let mut costs = (0, 0);
                    for frame in 0..13 {
                        let mut list = PaintList::default();
                        let mut actions = vec![];
                        if frame >= 3 { crate::comparison_allocation_probe::start(); }
                        view::render(&mut list, &mut atlas, Rect::new(0., 0., width, 180.),
                            &mut panels, &state, &input, 0., 3., &mut actions);
                        if frame >= 3 {
                            let counts = crate::comparison_allocation_probe::finish();
                            costs.0 += counts.0;
                            costs.1 += counts.1;
                        }
                        assert!(actions.is_empty());
                        let marks: Vec<_> = panels.timeline.comparison.marks.iter()
                            .map(|(channel, frame, point)| (&channel.target, channel.component, frame, point)).collect();
                        final_paint = format!("{:?}\n{:?}\n{:?}\n{:?}\n{:?}\n{:?}\n{:?}\n{:?}",
                            list.shapes, list.colors, list.glyphs, list.images, list.order,
                            marks, panels.timeline.comparison.range_hits,
                            (panels.timeline.comparison.legend.offset, panels.timeline.comparison.groups.offset));
                    }
                    assert_eq!(format!("{:?}", motion_ui::input::InputSource::input_view(&input)), before_input);
                    let name = format!("{locale:?}-{width}-{mode}-{modified}");
                    std::fs::write(directory.join(format!("{name}.paint")), final_paint).unwrap();
                    results.push(serde_json::json!({"name":name,"frames":10,"requests":costs.0,"bytes":costs.1}));
                }
            }
        }
    }
    assert_eq!(state, original);
    std::fs::write(directory.join("costs.json"), serde_json::to_vec_pretty(&results).unwrap()).unwrap();
}
