use std::alloc::{GlobalAlloc, Layout, System};
use std::cell::Cell;

thread_local! {
    static COUNTS: Cell<Option<(u64, u64)>> = const { Cell::new(None) };
}
struct Counter;
unsafe impl GlobalAlloc for Counter {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let _ = COUNTS.try_with(|c| {
            if let Some((n, bytes)) = c.get() {
                c.set(Some((n + 1, bytes + layout.size() as u64)));
            }
        });
        System.alloc(layout)
    }
    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        System.dealloc(pointer, layout)
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let _ = COUNTS.try_with(|c| {
            if let Some((n, bytes)) = c.get() {
                c.set(Some((n + 1, bytes + layout.size() as u64)));
            }
        });
        System.alloc_zeroed(layout)
    }
    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let _ = COUNTS.try_with(|c| {
            if let Some((n, bytes)) = c.get() {
                c.set(Some((n + 1, bytes + size as u64)));
            }
        });
        System.realloc(pointer, layout, size)
    }
}
#[global_allocator]
static ALLOCATOR: Counter = Counter;
pub(crate) fn start() { COUNTS.with(|c| c.set(Some((0, 0)))); }
pub(crate) fn finish() -> (u64, u64) { COUNTS.with(|c| c.replace(None).unwrap()) }
