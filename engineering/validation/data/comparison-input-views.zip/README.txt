First-party verification evidence only. No executable or FFmpeg runtime is included.
Baseline: 82633385658dcc616edacbcd557f0f477a6f57c1.
Temporary allocator source: desktop/app/src/comparison_allocation_probe.rs; add cfg(test) mod comparison_allocation_probe to main.rs.
Temporary probe source: desktop/app/src/panels/curve_comparison/tests/input_allocation_probe.rs; add mod input_allocation_probe to tests.rs.
Set COMPARISON_PROBE_DIR to the before/after output directory. Run comparison_render_input_allocation_probe using a freshly built FFmpeg-enabled motion-desktop test executable and adjacent FFmpeg runtime DLLs.
Each of 64 scenes warms 3 frames and counts allocation requests/bytes on the test thread over 10 render calls. Paint files record each scene final frame only. Each render checks empty actions; each scene checks input immutability. Stress payload: 36864 text bytes and 128 entries per key vector. Wheel clamps to offset zero in this matrix.
All temporary instrumentation was removed before final regression and product builds. Raw unsuccessful probe-build and missing-DLL runs are retained.
