"""Serial source-bound native source-watch qualification; never whole #82."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
from ctypes import wintypes
import hashlib,json,os,re,subprocess,tomllib
ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/native-prerender-runtime'
OUT=ROOT/'artifacts/pr-queue/prerender-engine-source-v1'
def git(*args):
    return subprocess.check_output(['git',*args],cwd=WORK).decode().strip()
def sources():
    names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=WORK).decode().split('\0')
    return {p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in names if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml','.md')) or p in ('Cargo.lock','NOTICE'))}


head=git('rev-parse','HEAD');original=sources();OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy();env.pop('MOTION_LOG',None);env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',LOCALAPPDATA=str(OUT/'owned-profile'),MOTION_PRERENDER_SOURCE_ARTIFACTS=str(OUT/'native'))
report=dict(head=head,status='running',source=original,steps=[],startedUtc=datetime.now(timezone.utc).isoformat(),limits='Native Engine source gate only. Does not repair original native crashes, strict P95 failures or final full/head CI gates.')
def save(): (OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def step(name,args,expected=None):
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/(name+'.stdout.log')).open('wb') as out,(OUT/(name+'.stderr.log')).open('wb') as err: code=subprocess.run(args,cwd=WORK,env=env,stdout=out,stderr=err).returncode
    text=(OUT/(name+'.stdout.log')).read_text(encoding='utf-8');counts=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',text)
    unchanged=sources()==original;passed=code==0 and unchanged and (expected is None or counts==[(str(expected),'0','0')]);row=dict(name=name,command=args,exitCode=code,counts=counts,passed=passed,sourceUnchanged=unchanged);report['steps'].append(row);save();print(json.dumps(row),flush=True);assert passed,name
save()
try:
    step('native-engine',['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--bin','motion-studio','engine::prerender::tests::source_freshness::native_source_change_bypasses_blocked_engine_and_replaces_cached_pixels_without_edit','--','--ignored','--exact','--test-threads=1'],1)
    step('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'])
    step('provenance',[os.sys.executable,'tools/validate_provenance.py'])
    step('inventory',[os.sys.executable,'tools/validation_inventory.py'])
    report['status']='accepted_engine_source_component_only'
except BaseException:
    report['status']='failed_not_accepted';report['completedUtc']=datetime.now(timezone.utc).isoformat();save();raise
report['completedUtc']=datetime.now(timezone.utc).isoformat();save();print(json.dumps(dict(status=report['status'])),flush=True)
