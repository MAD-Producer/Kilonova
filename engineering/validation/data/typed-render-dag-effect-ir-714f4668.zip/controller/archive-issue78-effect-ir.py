"""Archive retained red/green attempts and verify final source-bound acceptance."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/render-dag'
BASE = '302a15bfb0a69b52df89c69da63bd7bbd25e3e1e'
LABELS = ['effect-ir-v1', 'effect-ir-v2', 'effect-ir-boundary-red', 'effect-ir-v3']
OUT = ROOT / 'artifacts/pr-queue/issue78-numeric-effect-ir-v3'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def sources():
    names = set()
    for args in [('diff', '--name-only', '-z', BASE),
                 ('ls-files', '--others', '--exclude-standard', '-z')]:
        names.update(p.decode() for p in subprocess.check_output(
            ['git', *args], cwd=WORK).split(b'\0') if p)
    return {p: sha((WORK / p).read_bytes()) for p in sorted(names)
            if (WORK / p).is_file() and
            (p.endswith('.rs') or p.endswith('Cargo.toml') or p == 'Cargo.lock')}


receipt = json.loads((OUT / 'accepted.json').read_text(encoding='utf-8'))
assert receipt['sourceUnchanged'] and receipt['source'] == sources()
steps = {s['name']: s for s in receipt['steps']}
assert list(steps) == ['desktop-check', 'effect-ir-focus', 'render-library',
                       'render-all-integration', 'compiler-default-output',
                       'desktop-nodes']
for name, step in steps.items():
    assert step['exitCode'] == 0 and step['sourceUnchanged'], name
    for stream in ['stdout', 'stderr']:
        data = (OUT / name / (stream + '.log')).read_bytes()
        assert sha(data) == step[stream + 'Sha256'], (name, stream)
    if name != 'desktop-check':
        text = (OUT / name / 'stdout.log').read_text(encoding='utf-8')
        matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
        observed = dict(passed=sum(int(x[0]) for x in matches),
                        failed=sum(int(x[1]) for x in matches),
                        ignored=sum(int(x[2]) for x in matches), targets=len(matches))
        assert observed == step['totals'], (name, observed)
assert steps['effect-ir-focus']['totals']['passed'] == 8
assert steps['render-library']['totals']['passed'] == 238
assert steps['render-all-integration']['totals']['targets'] == 101
assert steps['render-all-integration']['totals']['ignored'] == 1
assert all(s.get('totals', {}).get('ignored', 0) == 0
           for n, s in steps.items() if n != 'render-all-integration')
native_log = (OUT / 'render-all-integration/stdout.log').read_text(encoding='utf-8')
ignored = re.findall(r'^test (.+) \.\.\. ignored.*$', native_log, re.M)
assert ignored == ['optional_local_original_image_probe'], ignored

channels = []
for stdout_path in sorted((OUT / 'compiler-output-artifacts').rglob('stdout.txt')):
    folder = stdout_path.parent
    stdout = stdout_path.read_text(encoding='utf-8')
    stderr = (folder / 'stderr.txt').read_text(encoding='utf-8')
    lines = (folder / 'logs/motion-studio.log').read_text(encoding='utf-8').splitlines()
    records = [line for line in lines if 'motion_render::pointwise_compile:' in line]
    errors = [line for line in records if 'phase=failure' in line]
    starts = [line for line in records if ' INFO ' in line and 'phase=start' in line]
    assert starts and len(errors) == 1 and ' ERROR ' in errors[0]
    assert 'motion_render::pointwise_compile:' in stderr and 'ERROR' in stderr
    assert 'motion_render::pointwise_compile:' not in stdout and 'pointwise_diagnostic_invalid' not in stdout
    channels.append(dict(mode=folder.relative_to(OUT / 'compiler-output-artifacts').as_posix(),
                         infoStarts=len(starts), fileErrors=len(errors),
                         stderrError=True, stdoutIsolated=True))
assert len(channels) == 4
(OUT / 'default-output-review.json').write_text(json.dumps(channels, indent=2), encoding='utf-8')

# The focused eight are a subset of render-library, not eight more passes.
distinct_passes = sum(steps[name]['totals']['passed'] for name in [
    'render-library', 'render-all-integration', 'compiler-default-output', 'desktop-nodes'])
formatted = [
    'crates/motion-render/src/effect_plan/effect_execution.rs',
    'crates/motion-render/src/effect_plan/effect_execution/tests.rs',
    'crates/motion-render/src/effect_plan/pointwise.rs',
    'crates/motion-render/tests/image_input_order_allocations.rs',
]
command = ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--check', *formatted]
fmt = subprocess.run(command, cwd=WORK, capture_output=True)
assert fmt.returncode == 0, (fmt.stdout, fmt.stderr)
(OUT / 'format.json').write_text(json.dumps(dict(command=command, exitCode=0), indent=2), encoding='utf-8')
assert not subprocess.check_output(['git', 'diff', '--name-only', BASE, '--',
                                    'desktop/app/src/panels'], cwd=WORK).strip()

files = {}
attempts = []
for label in LABELS:
    folder = ROOT / 'artifacts/pr-queue' / ('issue78-numeric-' + label)
    attempts.append(dict(label=label, accepted=(folder / 'accepted.json').exists()))
    if label != 'effect-ir-v3':
        failed = json.loads((folder / 'exit.json').read_text(encoding='utf-8'))
        last = failed['steps'][-1]
        assert last['exitCode'] == 101 and last['sourceUnchanged'], label
        log = (folder / last['name'] / 'stdout.log').read_text(encoding='utf-8')
        if label == 'effect-ir-v1':
            assert 'test result: FAILED. 5 passed; 1 failed; 0 ignored;' in log
            assert 'effect_cycle_is_diagnosed_before_native_preparation_and_healthy_input_recovers ... FAILED' in log
        elif label == 'effect-ir-v2':
            error = (folder / last['name'] / 'stderr.log').read_text(encoding='utf-8')
            assert "missing field `instance_data` in initializer of `EffectPass`" in error
            assert 'image_input_order_allocations.rs:78:17' in error
        else:
            assert 'test result: FAILED. 6 passed; 2 failed; 0 ignored;' in log
            assert 'invalid_origins_are_bounded_and_rejected_before_code_preparation ... FAILED' in log
            assert 'virtual_source_views_do_not_inherit_physical_texture_limits ... FAILED' in log
    for path in sorted(folder.rglob('*')):
        if path.is_file() and path.name != 'archive-verification.json':
            files['attempts/' + label + '/' + path.relative_to(folder).as_posix()] = path.read_bytes()
files['controller/archive-issue78-effect-ir.py'] = Path(__file__).read_bytes()
files['patch/tracked-render.patch'] = subprocess.check_output([
    'git', 'diff', '--binary', '--', 'crates/motion-render'], cwd=WORK)
manifest = dict(
    createdUtc=datetime.now(timezone.utc).isoformat(), base=receipt['head'],
    scope='Actual effect-level image IR, checked grouping and native task/snapshot consumers; partial issue #78',
    source=receipt['source'], attempts=attempts,
    testTotals={n: s.get('totals') for n, s in steps.items()},
    distinctPasses=distinct_passes,
    countLimit='Focused eight are a subset of the 238 library tests; earlier attempts are retained evidence, not additional final passes',
    ignored='Existing optional_local_original_image_probe needs external MOTION_IMAGE_SOURCE; no new skip was added',
    limitations=['Initial lowering still follows native drafts and CPU preparation',
                 'External package/image/LUT/mask/ShaderData imports still use native admission',
                 'Packaged IR/portable overflow, bounded CPU parallelism and full cost metrics remain pending',
                 'All-precision private numeric instances, full IR production failure channels and final integrated/cross-platform acceptance remain pending'],
    files={name: sha(data) for name, data in sorted(files.items())},
)
archive = WORK / 'engineering/validation/data/typed-render-dag-effect-ir-714f4668.zip'
assert not archive.exists(), 'Never overwrite retained checkpoint archives'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, data in sorted(files.items()):
        zipped.writestr(name, data)
    zipped.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    assert set(zipped.namelist()) == set(files) | {'manifest.json'}
    for name, digest in manifest['files'].items():
        assert sha(zipped.read(name)) == digest, name
assert sources() == receipt['source']
summary = dict(archive=str(archive), bytes=archive.stat().st_size, files=len(files),
               sha256=sha(archive.read_bytes()), sourcesVerified=len(receipt['source']),
               distinctPasses=distinct_passes, testTotals=manifest['testTotals'])
(OUT / 'archive-verification.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary))
