"""Retain compact terminal evidence without duplicating source assets/binaries."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
OUT = ART / 'tracking88-terminal-public-v1'
WORK = ROOT / '.worktrees/planar-tracker88'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
terminal = json.loads((ART / 'tracking88-prototype-workspace-terminal-v3/receipt.json').read_text())
assert terminal['originalStatus'] == 'failed_original_outputs_retained'
assert terminal['totals']['failed'] == 1 and terminal['fullTargetCoverageAccounted']
diagnostic = json.loads((ART / 'tracking88-publication-same-binary-v1/receipt.json').read_text())
assert diagnostic['status'] == 'original_failure_not_reproduced_cause_unresolved'
files = {}
for version in (1, 2, 3):
    folder = ART / f'tracking88-prototype-workspace-integration-v{version}'
    for name in ('exit.json', 'controller.py', 'stdout.log', 'stderr.log', 'cargo-metadata.json'):
        p = folder / name
        if p.is_file(): files[f'executions/v{version}/{name}'] = p
for folder_name in ('tracking88-prototype-workspace-terminal-v3',
                    'tracking88-publication-same-binary-v1'):
    for p in (ART / folder_name).iterdir():
        assert p.suffix in ('.json', '.log', '.py'), p
        files[f'executions/{folder_name}/{p.name}'] = p
failure = ART / 'tracking88-workspace-v3-publication-failure-v1'
for name in ('receipt.json', 'original-failure.log'):
    files['original-failure/' + name] = failure / name
for p in (failure / 'sources').rglob('*'):
    if p.is_file(): files['original-failure/sources/' + p.relative_to(failure / 'sources').as_posix()] = p
files['private-full-archive-manifest.json'] = ART / 'tracking88-prototype-workspace-archive-v3/manifest.json'
files['archive-controller.py'] = Path(__file__)
entries = {name: dict(bytes=p.stat().st_size, sha256=sha(p)) for name,p in sorted(files.items())}
OUT.mkdir(exist_ok=False)
archive = OUT / 'tracking88-terminal-public-v1.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name,p in sorted(files.items()): z.writestr(name, p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(entries)
    for name,entry in entries.items():
        raw=z.read(name)
        assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
manifest=dict(status='failed_full_run_and_unresolved_diagnostic_archived',
              createdUtc=datetime.now(timezone.utc).isoformat(), source=terminal['source'],
              totals=terminal['totals'], elapsedSeconds=terminal['elapsedSeconds'],
              archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), entries=entries,
              limits=['Original full run failed; a single passing diagnostic is not a repair or full pass',
                      'Private full-source archive and retained exe/PDB are identified by hashes, not duplicated',
                      'No later-main test coverage or photographed tracking quality acceptance is claimed'])
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for p in (archive,OUT/'manifest.json'):
    destination=WORK/'engineering/validation/data'/p.name
    assert not destination.exists()
    destination.write_bytes(p.read_bytes())
    assert sha(destination)==sha(p)
print(json.dumps({k:v for k,v in manifest.items() if k!='entries'}))
