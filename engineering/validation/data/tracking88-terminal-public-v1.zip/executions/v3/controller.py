"""Run the complete maintained workspace after latest-main integration."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, time, traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/planar-tracker88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-prototype-workspace-integration-v3'
import shutil
assert shutil.disk_usage(ROOT).free >= 10 * 1024**3, 'Need original 10 GiB before starting full combined regression; no test process launched'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert head == '270840919743570dad144ec3a7e609eac91fe1db'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
names = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def identity():
    return {n: sha(WORK / n) for n in names if (WORK / n).is_file() and
            (n.startswith(('crates/', 'desktop/', 'sdk/')) or n in ('Cargo.toml', 'Cargo.lock', 'ATTRIBUTION.md', 'PROVENANCE.md', 'NOTICE'))}
assert all((WORK / n).is_file() for n in names), 'Complete tracked checkout required before full regression'
source = identity()
import shutil
assert shutil.disk_usage(ROOT).free >= 10 * 1024**3, 'Need at least 10 GiB before complete workspace gate; no cleanup or source changes performed'
env = os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'):
        env.pop(name, None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT / 'target/colmap88-isolated-check'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT / 'appdata'),
           TEMP=str(ROOT / 'target/colmap88-isolated-check/tmp'),
           TMP=str(ROOT / 'target/colmap88-isolated-check/tmp'))
Path(env['TEMP']).mkdir(parents=True, exist_ok=True)
metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--no-deps', '--format-version', '1', '--locked'], cwd=WORK, env=env))
(OUT / 'cargo-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
command = ['cargo', 'test', '--workspace', '--exclude', 'motion-android', '--features',
           'motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth',
           '--no-fail-fast', '--locked', '--', '--test-threads=1']
report = dict(status='running', baseCommit=head, main='26c1d2d2bc83c8073d85a200a7cc78cd6284d4f4', userSpaceCleared=True, freeBytesBefore=shutil.disk_usage(ROOT).free, source=source, command=command,
              targetDirectory=env['CARGO_TARGET_DIR'], temporaryDirectory=env['TEMP'], priorEnvironmentFailure='v1 missing shared TEMP retained; v2 fixture type error before tests retained, now corrected only integer constructor argument without assertion/product changes', startedUtc=datetime.now(timezone.utc).isoformat(),
              limits=['Complete maintained workspace, Android excluded by user; original failures retained, a pass does not establish a crash repair',
                      'Dedicated target only for this integration tree, no foreign worktree compilation',
                      'Cargo default codegen, dev/test debug0, no incremental, one build job, one serial own GPU workload',
                      'Original assertions, ignores, stack/backend preserved; default Info and controlled temp/cache E',
                      'FFmpeg and optional ai-depth enabled with default GPU controls; unchanged original manual ignores remain reported separately',
                      'Combined source includes current-main dependency storage/text caches, professional/imported-camera route, exact reference-depth branch and frozen prototype/Surface tests; full tracked checkout including SDK',
                      'Cleanup replies do not waive the original measured 10GiB start gate; no local cleanup performed by this controller'])
def save():
    pending = OUT / 'exit.pending.json'
    pending.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    os.replace(pending, OUT / 'exit.json')
save()
began = time.monotonic()
try:
    with (OUT / 'stdout.log').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
        process = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = process.pid
        save()
        code = process.wait()
    assert identity() == source and subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == head
    stdout = (OUT / 'stdout.log').read_text(encoding='utf-8', errors='replace')
    stderr = (OUT / 'stderr.log').read_text(encoding='utf-8', errors='replace')
    summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', stdout, re.M)
    invocations = re.findall(r'^\s*(?:Running|Doc-tests) .+$', stderr, re.M)
    report.update(exitCode=code, sourceUnchanged=True, summaries=summaries, invocations=invocations)
    if code == 0:
        expected = []
        for package in metadata['packages']:
            if package['id'] in metadata['workspace_members'] and package['name'] != 'motion-android':
                expected.extend((t['name'], t['kind'][0]) for t in package['targets'] if t['test'])
                if any(t['doctest'] for t in package['targets']):
                    expected.append((package['name'].replace('-', '_'), 'doc'))
        assert len(summaries) == len(invocations) == len(expected), (len(summaries), len(invocations), len(expected))
        assert all(s[0] == 'ok' and s[2] == s[5] == '0' for s in summaries)
        for name, kind in expected:
            assert any((f'Doc-tests {name}' if kind == 'doc' else name.replace('-', '_') + '-') in i for i in invocations), name
        report.update(status='complete_maintained_workspace_passed', totals=dict(passed=sum(int(s[1]) for s in summaries),
                      failed=0, originalIgnored=sum(int(s[3]) for s in summaries), filtered=0, targets=len(summaries)))
    else:
        report['status'] = 'failed_original_outputs_retained'
except BaseException:
    report.update(status='observer_failed_original_outputs_retained', traceback=traceback.format_exc())
    raise
finally:
    report.update(elapsedSeconds=round(time.monotonic() - began, 3), completedUtc=datetime.now(timezone.utc).isoformat())
    save()
print(json.dumps({k: v for k, v in report.items() if k != 'source'}))
raise SystemExit(0 if report['status'] == 'complete_maintained_workspace_passed' else 1)
