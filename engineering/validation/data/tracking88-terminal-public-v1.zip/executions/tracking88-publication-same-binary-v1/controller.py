"""One post-gate reproduction attempt; retain the original full-run failure."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time
import traceback

ROOT = Path('E:/Dev/aem')
FULL = ROOT / 'artifacts/pr-queue/tracking88-prototype-workspace-integration-v3'
ORIGINAL = ROOT / 'artifacts/pr-queue/tracking88-workspace-v3-publication-failure-v1'
OUT = ROOT / 'artifacts/pr-queue/tracking88-publication-same-binary-v1'
WORK = ROOT / '.worktrees/planar-tracker88'
TEST = 'unsupported_versions_cannot_load_or_replace_an_existing_project'
HEAD = '270840919743570dad144ec3a7e609eac91fe1db'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

full = json.loads((FULL / 'exit.json').read_text(encoding='utf-8'))
assert full['status'] != 'running' and 'completedUtc' in full, 'Keep original full regression running undisturbed'
assert full['baseCommit'] == HEAD and full['sourceUnchanged']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK).strip()
original = json.loads((ORIGINAL / 'receipt.json').read_text(encoding='utf-8'))
binary = ORIGINAL / 'format_version_boundaries-2b346f8cb3c84e06.exe'
assert sha(binary) == original['files'][binary.name]['sha256']
for name, entry in original['files'].items():
    if name.startswith('sources/'):
        assert sha(WORK / name.removeprefix('sources/')) == entry['sha256']
assert TEST in (FULL / 'stdout.log').read_text(encoding='utf-8', errors='replace')
env = os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'):
        env.pop(name, None)
env.update(TEMP=full['temporaryDirectory'], TMP=full['temporaryDirectory'],
           RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT / 'appdata'))
Path(env['TEMP']).mkdir(parents=True, exist_ok=True)
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
command = [str(binary), '--exact', TEST, '--nocapture', '--test-threads=1']
report = dict(status='running_one_same_binary_diagnostic',
              startedUtc=datetime.now(timezone.utc).isoformat(),
              originalFullStatus=full['status'], originalHead=HEAD,
              binarySha256=sha(binary), command=command,
              temporaryDirectory=env['TEMP'],
              limits=['One explicitly filtered diagnostic, not a replacement complete regression',
                      'Uses retained exact failing binary; original assertions and executable unchanged',
                      'Original MoveFileExW code 5 PermissionDenied failure remains recorded regardless of this outcome',
                      'A successful reproduction attempt does not identify the cause or establish a repair',
                      'No retry loop, source modification, ACL mutation, cleanup, backend, stack or budget changes'])

def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

save()
began = time.monotonic()
try:
    with (OUT / 'stdout.log').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
        process = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = process.pid
        save()
        code = process.wait()
    report.update(exitCode=code, status='original_failure_not_reproduced_cause_unresolved' if code == 0 else
                  'same_binary_failure_reproduced_inspect_original_outputs')
except BaseException:
    report.update(status='diagnostic_observation_failed_outputs_retained', traceback=traceback.format_exc())
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),
                  elapsedSeconds=round(time.monotonic() - began, 3),
                  binaryUnchanged=sha(binary) == original['files'][binary.name]['sha256'])
    save()
print(json.dumps(report))
