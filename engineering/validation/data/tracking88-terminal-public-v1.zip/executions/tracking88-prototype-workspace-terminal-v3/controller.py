"""Terminal full-gate accounting, including all failures and original scope gaps."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import re

ROOT=Path('E:/Dev/aem')
RUN=ROOT/'artifacts/pr-queue/tracking88-prototype-workspace-integration-v3'
OUT=ROOT/'artifacts/pr-queue/tracking88-prototype-workspace-terminal-v3'
execution=json.loads((RUN/'exit.json').read_text(encoding='utf-8'))
assert execution['status']!='running' and 'completedUtc' in execution and execution['sourceUnchanged']
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
metadata=json.loads((RUN/'cargo-metadata.json').read_text(encoding='utf-8'))
stdout=(RUN/'stdout.log').read_text(encoding='utf-8',errors='replace')
stderr=(RUN/'stderr.log').read_text(encoding='utf-8',errors='replace')
rows=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
running=re.findall(r'^\s*Running .+?\([^\r\n]*[\\/]([^\\/()]+)-[a-f0-9]+\.exe\)',stderr,re.M)
docs=re.findall(r'^\s*Doc-tests (\S+)\s*$',stderr,re.M)
expected=[]
for package in metadata['packages']:
    if package['id'] not in metadata['workspace_members'] or package['name']=='motion-android': continue
    expected.extend(t['name'].replace('-','_') for t in package['targets'] if t['test'])
    if any(t['doctest'] for t in package['targets']): expected.append('doc:'+package['name'].replace('-','_'))
actual=running+['doc:'+n for n in docs]
counts=Counter(expected); observed=Counter(actual)
failures=re.findall(r'^test ([^\r\n]+?) \.\.\. FAILED\s*$',stdout,re.M)
failure_headers=re.findall(r'^---- ([^\r\n]+) stdout ----\s*$',stdout,re.M)
report=dict(status='terminal_original_full_execution_accounted',createdUtc=datetime.now(timezone.utc).isoformat(),
            originalStatus=execution['status'],exitCode=execution['exitCode'],source=execution['baseCommit'],
            sourceUnchanged=execution['sourceUnchanged'],elapsedSeconds=execution['elapsedSeconds'],
            totals=dict(passed=sum(int(r[1]) for r in rows),failed=sum(int(r[2]) for r in rows),
                        originalIgnored=sum(int(r[3]) for r in rows),measured=sum(int(r[4]) for r in rows),
                        filtered=sum(int(r[5]) for r in rows),summaryCount=len(rows),invocations=len(actual),expectedInvocations=len(expected)),
            missingInvocations=dict(counts-observed),unexpectedInvocations=dict(observed-counts),
            fullTargetCoverageAccounted=counts==observed and len(rows)==len(actual),
            failedTestNames=failures,failureOutputHeaders=failure_headers,
            originalCommand=execution['command'],
            logs={n:dict(bytes=(RUN/n).stat().st_size,sha256=hashlib.sha256((RUN/n).read_bytes()).hexdigest())
                  for n in ('stdout.log','stderr.log','exit.json','cargo-metadata.json')},
            limits=['Complete frozen27084091 tree only; does not cover later main source additions',
                    'Later main video_retirement_export.rs and video_retirement_pressure.rs require actual integrated-source acceptance',
                    'Original MoveFileExW publish PermissionDenied failure cannot be erased by a filtered passing reproduction',
                    'No assertion, timeout, backend, stack, test filter or original ignore was changed',
                    'Photographed tracker 15-pixel quality and coverage are independent outstanding gates',
                    'Android excluded by maintained user scope'])
(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
assert report['fullTargetCoverageAccounted'], 'Do not call incomplete target coverage a complete regression'
assert report['totals']['failed']==len(failure_headers)==len(failures), 'Inspect unmatched failure accounting'
