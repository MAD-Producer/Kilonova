"""Current-main union: actual model receivers, temporal exposure and depth seed."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

root = Path('E:/Dev/aem')
work = root / '.worktrees/depth-calibration'
out = root / 'artifacts/pr-queue/depth-model-main-v1'
target = root / 'target/gltf-scene87-contract'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=work).decode().strip()

def source():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=work).decode().split('\0')
    return {p: sha(work / p) for p in paths if p and
            (p.endswith(('.rs', '.py', '.toml', '.wgsl', '.gltf', '.obj', '.json')) or
             p == 'Cargo.lock')}

alignment = json.loads((root / 'artifacts/pr-queue/depth-model-main-alignment-v1.json').read_text(encoding='utf-8'))
assert alignment['exitCode'] == 0 and alignment['ownPatchGitBlobsUnchanged'] and alignment['ownProductSourceUnchanged']
assert git('status', '--porcelain') == '' and git('rev-parse', 'HEAD') == alignment['head']
before = source()
receipt = dict(startedUtc=datetime.now(timezone.utc).isoformat(), head=git('rev-parse', 'HEAD'),
               main=alignment['main'], source=before, steps=[],
               scope='Maintained-main source including morph/skin plus calibration and model receiver repairs; native union, not automatic project depth routing')
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
changed = git('diff', '--name-only', '9ffe5ea529e0671ccc922d1dba7115521ecd3916', 'HEAD').splitlines()
for p in changed:
    if (work / p).is_file() and not p.endswith('.zip'):
        dest = out / 'changed-source' / p
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(work / p, dest)

env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true',
           LOCALAPPDATA=str(out / 'appdata'))
env.pop('MOTION_LOG', None)

def run(name, command, expected_targets=None):
    print(json.dumps(dict(start=name)), flush=True)
    began = datetime.now(timezone.utc)
    with (out / (name + '.stdout.log')).open('wb') as so, (out / (name + '.stderr.log')).open('wb') as se:
        code = subprocess.run(command, cwd=work, env=env, stdout=so, stderr=se).returncode
    text = (out / (name + '.stdout.log')).read_text(encoding='utf-8')
    row = dict(name=name, command=command, exitCode=code, sourceUnchanged=source() == before,
               elapsedSeconds=(datetime.now(timezone.utc) - began).total_seconds())
    for stream in ('stdout', 'stderr'):
        row[stream + 'Sha256'] = sha(out / (name + '.' + stream + '.log'))
    results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    if results:
        row['totals'] = dict(zip(('passed', 'failed', 'ignored'),
                                [sum(int(v[i]) for v in results) for i in range(3)]))
        row['targets'] = len(results)
    receipt['steps'].append(row)
    (out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], name
    if results:
        assert row['totals']['failed'] == row['totals']['ignored'] == 0
    if expected_targets is not None:
        assert row.get('targets') == expected_targets, row
    return text

run('provenance', [sys.executable, 'tools/validate_provenance.py'])
run('panel-style', [sys.executable, '-c', "import runpy; runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"])
run('model-tests', ['cargo', 'test', '-p', 'motion-model', '--locked', '--offline', '--', '--test-threads=1'])
command = ['cargo', 'test', '-p', 'motion-render', '--features', 'gpu-tests', '--locked', '--offline', '--lib']
targets = ('scene_gpu', 'model_layers', 'exposure_frame', 'exposure_allocation_budget',
           'exposure_accumulation', 'nested_exposure', 'exposure_sdr', 'exposure_scenes',
           'layer_rasters', 'layer_masks', 'mask_error_boundaries', 'scene_effects',
           'typed_snapshot_execution', 'effects')
for name in targets:
    command += ['--test', name]
text = run('native', command + ['--no-fail-fast', '--', '--test-threads=1'], 15)
for name in ('cold_model_receivers_materialize_each_pose_and_keep_earlier_snapshots',
             'model_receiver_shutter_matches_independent_native_sample_average',
             'calibrated_depth_occludes_real_meshes_in_four_precisions_and_both_sample_counts',
             'calibrated_depth_admission_rolls_back_and_pending_frames_keep_immutable_inputs',
             'calibrated_depth_failure_observation_keeps_sample_context_and_recovers_at_default_level',
             'wrapped_native_calibrated_depth_keeps_original_typed_resource_refusal'):
    assert re.search(r'test .*' + name + r' \.\.\. ok', text), name
run('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features',
                      'ffmpeg,motion-host/ai-depth', '--locked', '--offline'])
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=source() == before,
               totals=dict(passed=sum(s.get('totals', {}).get('passed', 0) for s in receipt['steps']),
                           failed=0, ignored=0))
assert receipt['sourceUnchanged'] and receipt['totals']['passed'] >= 496
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True, totals=receipt['totals'])), flush=True)
