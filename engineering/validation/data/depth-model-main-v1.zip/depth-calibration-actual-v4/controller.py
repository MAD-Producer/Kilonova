"""Actual maintained Session/FFmpeg/ONNX prediction into native shared depth."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess
root=Path('E:/Dev/aem');work=root/'.worktrees/depth-calibration'
probe=root/'.tools/ai-depth74/calibration-probe'
gate=root/'artifacts/pr-queue/depth-model-main-v1'
native=json.loads((gate/'accepted.json').read_text(encoding='utf-8'))
assert native['sourceUnchanged'] and all(s['exitCode']==0 for s in native['steps'])
assert (root/'artifacts/pr-queue/issue87-skin-main-full-v2/accepted.json').is_file()
build=json.loads((root/'artifacts/pr-queue/depth-calibration-actual-probe-build-v6/built.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert build['productSource']==native['source']
assert all(sha(probe/p)==h for p,h in build['source'].items())
assert all(sha(work/p)==h for p,h in native['source'].items())
binary=root/'target/ai-depth74-contract/debug/motion-depth74-calibration-probe.exe'
assert sha(binary)==build['binarySha256']
out=root/'artifacts/pr-queue/depth-calibration-actual-v4';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
for p in build['source']:
    dest=out/'probe-source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(probe/p,dest)
old=root/'artifacts/pr-queue/issue3d-final-native-depth-v1'
reference=json.loads((old/'verified.json').read_text(encoding='utf-8'))
reference['artifacts']={k.replace(chr(92),'/'):v for k,v in reference['artifacts'].items()}
assert reference['sourceUnchanged'] and reference['acceptedSrgbInputBitExact']
fixture=old/'project/assets/source.mp4'
assert sha(fixture)==reference['artifacts']['project/assets/source.mp4']
dest=out/'project/assets/source.mp4';dest.parent.mkdir(parents=True);shutil.copyfile(fixture,dest)
home=root/'.tools/ai-depth74'
assert sha(home/'models/depth_anything_v2_vits_518.onnx')==reference['onnxSha256']
env=os.environ.copy();env.pop('MOTION_LOG',None);env['CUDA_VISIBLE_DEVICES']=''
for key,folder in [('TEMP','temp'),('TMP','temp'),('PYTHONPYCACHEPREFIX','pycache')]:
    p=home/folder;p.mkdir(exist_ok=True);env[key]=str(p)
receipt=dict(startedUtc=datetime.now(timezone.utc).isoformat(),source=native['source'],probe=build,binarySha256=sha(binary),motionLog=None,nativeDlls=[])
ffbin=root/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
for dll in ffbin.glob('*.dll'):
    destination=binary.parent/dll.name
    if not destination.exists():shutil.copyfile(dll,destination)
    assert sha(destination)==sha(dll);receipt['nativeDlls'].append(dict(file=dll.name,sha256=sha(dll)))
env['PATH']=str(ffbin)+os.pathsep+env['PATH']
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:
    process=subprocess.Popen([str(binary),str(out)],cwd=work,env=env,stdout=so,stderr=se)
    receipt['pid']=process.pid;(out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    try:
        receipt['exitCode']=process.wait(timeout=180)
    except subprocess.TimeoutExpired:
        receipt['timedOut']=True
        cleanup=subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
        receipt['cleanupExitCode']=cleanup.returncode
        receipt['exitCode']=process.wait(timeout=15)
(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
assert not receipt.get('timedOut'), 'actual depth calibration probe exceeded the deadline'
assert receipt['exitCode']==0
assert not (out/'stdout.log').read_bytes()
result=json.loads((out/'result.json').read_text(encoding='utf-8'))
proof=json.loads((out/'calibrated-proof.json').read_text(encoding='utf-8'))
assert result['actualInference'] and result['actualNativeFfmpeg'] and result['actualSession'] and result['renderDepthBound']
assert proof['actualSessionOnnxResource'] and proof['actualNativeGpu'] and proof['pixelsVerified']==6144
assert proof['visibleInsideCrop']>0 and proof['occludedInsideCrop']>0 and proof['outsideCrop']==1984
assert proof['maxHardwareDepthAbsoluteError']<1e-6 and proof['anchorsAreSuppliedIllustrationNotMetricAccuracy']
assert not proof['guiEngine'] and not proof['projectRenderIntegration']
assert (out/'input.rgb').read_bytes()==(old/'input.rgb').read_bytes()
assert (out/'output.f32').read_bytes()==(old/'output.f32').read_bytes()
assert sha(old/'official-reference.f32')==reference['artifacts']['official-reference.f32']
assert reference['maxNormalized']<=2e-4 and reference['meanNormalized']<=2e-5
log=(out/'logs/motion-studio.log').read_text(encoding='utf-8');stderr=(out/'stderr.log').read_text(encoding='utf-8')
assert 'logging initialized level=INFO' in log and 'start #1 depth_infer asset=74' in log
for stream in (log,stderr):
    for part in ('ERROR','scene_shared_pass #740087 source=74','phase=calibrated_depth','stale depth source/revision/PTS','elapsed_ms=','asset: 74',f'ticks: {result["actualPtsUs"]}'):
        assert part in stream,part
assert 'start #1' not in stderr and 'logging initialized' not in stderr
assert all(sha(work/p)==h for p,h in native['source'].items())
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),result=result,proof=proof,sourceUnchanged=True,stdoutEmpty=True,
    defaultErrorFileAndStderr=True,rawInferenceBitExactToPriorOfficialReferenceGate=True,priorReferenceGateSha256=sha(old/'verified.json'),priorMaxNormalized=reference['maxNormalized'],priorMeanNormalized=reference['meanNormalized'])
receipt['artifacts']={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()}
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,pixels=proof['pixelsVerified'],maxHardwareDepthAbsoluteError=proof['maxHardwareDepthAbsoluteError'],sourceUnchanged=True)))
