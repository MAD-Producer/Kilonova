from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
out=Path(__file__).resolve().parent;work=Path.cwd()
assert work==Path('E:/Dev/aem/.worktrees/mask-membership-reuse')
old=json.loads((out/'before-source-freeze.json').read_text(encoding='utf-8'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def freeze():return {p:digest(work/p) for p in old['hashes']}
current=freeze()
assert [p for p in current if current[p]!=old['hashes'][p]]==['crates/motion-render/src/mask_gpu.rs']
assert digest(work/'crates/motion-render/examples/mask_membership_comparison.rs')==old['benchmark_sha256']
(out/'after-source-freeze.json').write_text(json.dumps(dict(head=old['head'],hashes=current,benchmark_sha256=old['benchmark_sha256']),indent=2),encoding='utf-8')
env=os.environ.copy();env.pop('WGPU_BACKEND',None);env.pop('MOTION_LOG',None);env['CARGO_TERM_COLOR']='never'
cmd=json.loads((out/'before-build-receipt.json').read_text(encoding='utf-8'))['command']
start=time.monotonic()
with (out/'after-build.log').open('w',encoding='utf-8') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
receipt=dict(command=cmd,exit_code=p.returncode,seconds=round(time.monotonic()-start,2),source_unchanged=freeze()==current,log_sha256=digest(out/'after-build.log'))
(out/'after-build-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
assert p.returncode==0 and receipt['source_unchanged'],receipt
binary=out/'after.exe';shutil.copyfile(Path(env['CARGO_TARGET_DIR'])/'debug/examples/mask_membership_comparison.exe',binary)
receipt['binary_sha256']=digest(binary);start=time.monotonic()
with (out/'after-run.log').open('w',encoding='utf-8') as log:p=subprocess.run([str(binary),str(out/'after')],stdout=log,stderr=subprocess.STDOUT,env=env)
receipt.update(run_exit_code=p.returncode,run_seconds=round(time.monotonic()-start,2),source_unchanged=freeze()==current,run_log_sha256=digest(out/'after-run.log'))
(out/'after-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
assert p.returncode==0 and receipt['source_unchanged'],receipt
before=json.loads((out/'before/report.json').read_text(encoding='utf-8'));after=json.loads((out/'after/report.json').read_text(encoding='utf-8'))
comparisons=[]
for a,b in zip(before,after,strict=True):
 for key in ['layers','masks_per_layer','captures','texture_bytes','reduced_texture_bytes','empty_texture_bytes','texture_breakdown']:
  assert a[key]==b[key],(key,a[key],b[key])
 comparisons.append(dict(layers=a['layers'],masks_per_layer=a['masks_per_layer'],captures=a['captures'],before_allocations=a['allocations'],after_allocations=b['allocations'],before_allocated_bytes=a['allocated_bytes'],after_allocated_bytes=b['allocated_bytes']))
pixels=[]
for path in sorted((out/'before').glob('*.rgba')):
 target=out/'after'/path.name
 assert path.read_bytes()==target.read_bytes(),path.name
 pixels.append(dict(file=path.name,bytes=path.stat().st_size,sha256=digest(path)))
assert len(pixels)==9
(out/'comparison.json').write_text(json.dumps(dict(cases=comparisons,pixels=pixels,all_pixels_and_texture_accounting_identical=True,counting='current-thread Rust alloc/alloc_zeroed/realloc requests during 20 actual captures after 3 warm captures; not all process/native allocations or a timing claim'),indent=2),encoding='utf-8')
print(json.dumps(comparisons),flush=True)
print('9 full pixel buffers and all texture accounting matched',flush=True)
