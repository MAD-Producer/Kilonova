use motion_core::{masks::LayerMask, vector::{PathNode, VectorPath}, Layer, Project, Track};
use motion_render::{Renderer, Scene};
use std::{alloc::{GlobalAlloc, Layout, System}, cell::Cell, path::PathBuf};

thread_local! {
    static MEASURING: Cell<bool> = const { Cell::new(false) };
    static ALLOCS: Cell<u64> = const { Cell::new(0) };
    static BYTES: Cell<u64> = const { Cell::new(0) };
}
struct Allocator;
fn record(bytes: usize) {
    if MEASURING.try_with(Cell::get).unwrap_or(false) {
        let _ = ALLOCS.try_with(|n| n.set(n.get().saturating_add(1)));
        let _ = BYTES.try_with(|n| n.set(n.get().saturating_add(bytes as u64)));
    }
}
unsafe impl GlobalAlloc for Allocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 { record(layout.size()); unsafe { System.alloc(layout) } }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 { record(layout.size()); unsafe { System.alloc_zeroed(layout) } }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) { unsafe { System.dealloc(ptr, layout) } }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 { record(size); unsafe { System.realloc(ptr, layout, size) } }
}
#[global_allocator] static ALLOCATOR: Allocator = Allocator;
struct Measure;
impl Drop for Measure { fn drop(&mut self) { MEASURING.set(false); } }

fn project(layers: usize, masks: usize) -> Project {
    let mut p = Project::new(128, 128, 30, 60).unwrap();
    p.background = [0.; 4];
    for i in 0..layers {
        let mut layer = Layer::solid(i as u64 + 1, "mask membership fixture", [8.; 2],
            [(i % 16) as f32 * 8. + 4., (i / 16) as f32 * 8. + 4., 0.], [1., 0.25, 0.5, 1.]);
        for m in 0..masks {
            let mut mask = LayerMask::new(m as u64 + 1, VectorPath {
                id: m as u64 + 1, closed: true,
                nodes: [[1., 1.], [7., 1.], [7., 7.], [1., 7.]].into_iter().enumerate().map(|(i, v)| PathNode {
                    id: i as u64 + 1, geometry: Track::constant([v[0], v[1], 0., 0., 0., 0.]),
                }).collect(),
            });
            mask.opacity.value = 75.;
            layer.masks.push(mask);
        }
        p.layers.push(layer);
    }
    p.validate().unwrap();
    p
}
fn scene(p: &Project) -> Scene {
    let mut s = Scene::new(p).unwrap();
    s.sample(p, 0., None, &motion_core::ExpressionEvaluator).unwrap();
    s
}
fn main() {
    let out = PathBuf::from(std::env::args_os().nth(1).expect("output directory"));
    std::fs::create_dir_all(&out).unwrap();
    let mut reports = Vec::new();
    for (layers, masks) in [(1, 1), (64, 1), (128, 16)] {
        let mut renderer = pollster::block_on(Renderer::headless()).unwrap();
        let mut p = project(layers, masks);
        let s = scene(&p);
        let target = renderer.capture_target(128, 128).unwrap();
        let expected = renderer.capture(&s, &target).unwrap().0;
        assert!(expected.chunks_exact(4).any(|p| p[3] != 0));
        for _ in 0..3 { assert_eq!(renderer.capture(&s, &target).unwrap().0, expected); }
        let initial_bytes = renderer.texture_bytes();
        let initial_breakdown = serde_json::to_value(renderer.texture_memory_breakdown()).unwrap();
        ALLOCS.set(0); BYTES.set(0);
        let mut measured = Vec::with_capacity(20);
        for _ in 0..20 {
            MEASURING.set(true);
            let guard = Measure;
            let pixels = renderer.capture(&s, &target).unwrap().0;
            drop(guard);
            assert_eq!(pixels, expected);
            measured.push((ALLOCS.get(), BYTES.get()));
        }
        assert_eq!(renderer.texture_bytes(), initial_bytes);
        assert_eq!(serde_json::to_value(renderer.texture_memory_breakdown()).unwrap(), initial_breakdown);
        std::fs::write(out.join(format!("{layers}-{masks}-original.rgba")), &expected).unwrap();
        let restored = p.clone();
        p.layers.truncate(layers / 2);
        let reduced = renderer.capture(&scene(&p), &target).unwrap().0;
        let reduced_bytes = renderer.texture_bytes();
        assert!(reduced_bytes < initial_bytes);
        std::fs::write(out.join(format!("{layers}-{masks}-removed.rgba")), reduced).unwrap();
        assert_eq!(renderer.capture(&scene(&restored), &target).unwrap().0, expected);
        p.layers.clear();
        let empty = renderer.capture(&scene(&p), &target).unwrap().0;
        assert!(empty.iter().all(|p| *p == 0));
        assert_eq!(renderer.texture_bytes(), 4);
        std::fs::write(out.join(format!("{layers}-{masks}-empty.rgba")), empty).unwrap();
        renderer.clear_assets();
        assert_eq!(renderer.capture(&s, &target).unwrap().0, expected);
        renderer.check_health().unwrap();
        reports.push(serde_json::json!({"layers":layers,"masks_per_layer":masks,"captures":20,
            "allocations": ALLOCS.get(), "allocated_bytes":BYTES.get(), "cumulative":measured,
            "texture_bytes":initial_bytes,"reduced_texture_bytes":reduced_bytes,
            "empty_texture_bytes":4,"texture_breakdown":initial_breakdown}));
    }
    std::fs::write(out.join("report.json"), serde_json::to_vec_pretty(&reports).unwrap()).unwrap();
}
