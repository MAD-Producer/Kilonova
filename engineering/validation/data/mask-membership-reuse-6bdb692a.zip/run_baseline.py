from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
out=Path(__file__).resolve().parent;work=Path.cwd()
assert work==Path('E:/Dev/aem/.worktrees/mask-membership-reuse')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='6bdb692a7f6878dc8c78742a80561ee28937d145'
assert subprocess.check_output(['git','status','--porcelain'],text=True).strip()==''
example=work/'crates/motion-render/examples/mask_membership_comparison.rs'
assert not example.exists();shutil.copyfile(out/'comparison.rs',example)
files=subprocess.check_output(['git','ls-files','-z']).decode('utf-8').strip('\0').split('\0')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def freeze():return {p:digest(work/p) for p in files}
original=freeze()
(out/'before-source-freeze.json').write_text(json.dumps(dict(head=head,hashes=original,benchmark_sha256=digest(example)),indent=2),encoding='utf-8')
env=os.environ.copy();env.pop('WGPU_BACKEND',None);env.pop('MOTION_LOG',None);env['CARGO_TERM_COLOR']='never'
command=['cargo','build','-p','motion-render','--example','mask_membership_comparison','--no-default-features','--features','gpu-tests','--locked','--offline','-j1']
start=time.monotonic()
with (out/'before-build.log').open('w',encoding='utf-8') as log:
 p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
receipt=dict(head=head,command=command,exit_code=p.returncode,seconds=round(time.monotonic()-start,2),source_unchanged=freeze()==original,log_sha256=digest(out/'before-build.log'))
(out/'before-build-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
assert p.returncode==0 and receipt['source_unchanged'],receipt
binary=out/'before.exe';shutil.copyfile(Path(env['CARGO_TARGET_DIR'])/'debug/examples/mask_membership_comparison.exe',binary)
receipt['binary_sha256']=digest(binary)
start=time.monotonic()
with (out/'before-run.log').open('w',encoding='utf-8') as log:
 p=subprocess.run([str(binary),str(out/'before')],stdout=log,stderr=subprocess.STDOUT,env=env)
receipt.update(run_exit_code=p.returncode,run_seconds=round(time.monotonic()-start,2),source_unchanged=freeze()==original,run_log_sha256=digest(out/'before-run.log'))
(out/'before-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
assert p.returncode==0 and receipt['source_unchanged'],receipt
print(json.dumps(receipt),flush=True)
print((out/'before/report.json').read_text(encoding='utf-8'),flush=True)
