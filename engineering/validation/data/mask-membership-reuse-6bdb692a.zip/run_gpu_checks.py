from pathlib import Path
import hashlib,json,os,re,subprocess,time
out=Path(__file__).resolve().parent;work=Path.cwd()
assert work==Path('E:/Dev/aem/.worktrees/mask-membership-reuse')
frozen=json.loads((out/'after-source-freeze.json').read_text(encoding='utf-8'))
def freeze():return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in frozen['hashes']}
assert freeze()==frozen['hashes']
env=os.environ.copy();env.pop('WGPU_BACKEND',None);env.pop('MOTION_LOG',None);env['CARGO_TERM_COLOR']='never'
base=['cargo','test','-p','motion-render','--no-default-features','--features','gpu-tests','--locked','--offline','-j1']
stages=[('mask-unit-tests',base+['--lib','mask_gpu::reuse_tests','--','--test-threads=1']),('mask-integration-tests',base+['--test','layer_masks','--test','mask_error_boundaries','--','--test-threads=1'])]
receipts=[]
for name,cmd in stages:
 start=time.monotonic();log=out/(name+'.log')
 with log.open('w',encoding='utf-8') as stream:p=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,env=env)
 summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(encoding='utf-8'),re.M)
 record=dict(name=name,command=cmd,seconds=round(time.monotonic()-start,2),exit_code=p.returncode,source_unchanged=freeze()==frozen['hashes'],sha256=hashlib.sha256(log.read_bytes()).hexdigest(),results=summaries)
 receipts.append(record);(out/'gpu-checks-receipt.json').write_text(json.dumps(receipts,indent=2),encoding='utf-8')
 assert p.returncode==0 and record['source_unchanged'] and summaries,record
 assert all(s[0]=='ok' and s[2]=='0' and s[3]=='0' for s in summaries),summaries
 print(json.dumps(record),flush=True)
