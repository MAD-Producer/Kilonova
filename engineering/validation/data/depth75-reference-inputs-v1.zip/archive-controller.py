"""Retain selected input identities and authored preparation, no pixel arrays."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('E:/Dev/aem')
WORK = ROOT/'.worktrees/depth-wgsl-cache75'
OUT = ROOT/'artifacts/pr-queue/depth75-reference-inputs-v1'
r = json.loads((OUT/'receipt.json').read_text(encoding='utf-8'))
assert json.loads((OUT/'session-consumed.json').read_text()) == dict(session=50754, consumed=True, exit_code=0)
assert r['status'] == 'complete32_registered_pairs_frozen_no_model_predictions' and r['source_unchanged']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == r['head']


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


for name, digest in r['source_sha256'].items():
    assert sha((WORK/name).read_bytes()) == digest, name
assert sha((OUT/'selection.json').read_bytes()) == r['selection_sha256']
assert sha((OUT/'inputs.json').read_bytes()) == r['inputs_sha256']
selected = json.loads((OUT/'selection.json').read_text())
prepared = json.loads((OUT/'inputs.json').read_text())
assert len(selected) == len(prepared) == 32
assert r['valid_sensor_pixels'] + r['missing_sensor_pixels'] == 32 * 640 * 480
for index, (before, after) in enumerate(zip(selected, prepared)):
    assert all(after[name] == value for name, value in before.items())
    assert before['index'] == index and before['split'] == ('calibration' if index < 8 else 'evaluation')
    assert abs(before['difference_ns']) <= 20_000_000
    for kind in ('rgb', 'depth'):
        identity = after[kind+'_input']
        raw = (OUT/identity['filename']).read_bytes()
        assert len(raw) == identity['bytes'] and sha(raw) == identity['sha256']
members = {'native/'+name: (OUT/name).read_bytes()
           for name in ('controller.py', 'receipt.json', 'session-consumed.json')}
members.update({'identities/'+name: (OUT/name).read_bytes() for name in ('selection.json', 'inputs.json')})
for name in ('depth_reference_inputs.py', 'test_depth_reference_inputs.py',
             'depth_reference_metrics.py', 'test_depth_reference_metrics.py'):
    members['source/tools/'+name] = (WORK/'tools'/name).read_bytes()
members['archive-controller.py'] = Path(__file__).read_bytes()
data = WORK/'engineering/validation/data'
archive = data/'depth75-reference-inputs-v1.zip'
manifest = data/'depth75-reference-inputs-v1.json'
assert not archive.exists() and not manifest.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, raw in sorted(members.items()):
        zipped.writestr(name, raw)
with zipfile.ZipFile(archive) as zipped:
    assert sorted(zipped.namelist()) == sorted(members)
    for name, raw in members.items():
        assert zipped.read(name) == raw
value = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
             members=[dict(path=name, bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(members.items())],
             preparation={name: r[name] for name in ('head', 'status', 'source_unchanged', 'selected_pairs',
                 'calibration_pairs', 'evaluation_pairs', 'maximum_association_difference_ns', 'decoded_pngs',
                 'decoder', 'valid_sensor_pixels', 'missing_sensor_pixels', 'selection_sha256', 'inputs_sha256')},
             limits=r['limits'] + ['All64 retained local input hashes independently read back before archiving',
                 'Only authored code and factual timestamp/content identities are public; no image or sensor payloads',
                 'This is deterministic input preparation, not model inference or measured quality'])
manifest.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')
print(json.dumps({name: value[name] for name in ('archive', 'bytes', 'sha256')}))
