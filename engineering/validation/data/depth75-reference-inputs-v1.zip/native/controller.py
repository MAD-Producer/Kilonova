"""Freeze the timestamp-selected32 RGB/sensor pairs; no model inference."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
import tarfile
import traceback

ROOT = Path('E:/Dev/aem')
BASE = ROOT/'artifacts/pr-queue'
WORK = ROOT/'.worktrees/depth-wgsl-cache75'
PARENT = BASE/'depth75-reference-acquisition-v1'
OUT = BASE/'depth75-reference-inputs-v1'
PREFIX = 'rgbd_dataset_freiburg1_desk/'
assert json.loads((PARENT/'session-consumed.json').read_text()) == dict(session=65494, consumed=True, exit_code=0)
acquired = json.loads((PARENT/'receipt.json').read_text())
assert acquired['source_unchanged'] and not acquired['sequence_notice_files']
assert not json.loads((BASE/'depth75-resume-current.json').read_text())['versionedCache75']['ownHeavyWorkloads']
assert shutil.disk_usage(ROOT).free >= 10 << 30
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
assert not OUT.exists()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


paths = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()


def hashes():
    return {name: digest(WORK/name) for name in paths}


OUT.mkdir()
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
(OUT/'tmp').mkdir()
os.environ.update(TEMP=str(OUT/'tmp'), TMP=str(OUT/'tmp'),
                  OPENCV_OPENCL_RUNTIME='disabled', PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0, str(WORK/'tools'))
import depth_reference_inputs as inputs

report = dict(status='running', phase='source_identity',
              head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip(),
              source_sha256=hashes(), started_utc=datetime.now(timezone.utc).isoformat(),
              limits=['Exact first32 timestamp-selected pairs; no image-based selection, retry or replacement',
                      'No learned-model predictions, quality tier or temporal-stability result',
                      'Full registered source640x480 retained; no crop, undistortion or extra sensor-scale correction',
                      'Source RGB decoded bytes used directly; no ICC or display conversion. Model RGB8 encoding assumption remains explicit',
                      'Private raw RGB and sensor arrays are local inputs, never evidence-archive members'])


def save():
    temporary = OUT/'receipt.pending.json'
    temporary.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    os.replace(temporary, OUT/'receipt.json')


save()
try:
    archive = PARENT/'dataset.tgz'
    assert digest(archive) == acquired['sha256'] == 'e983d6830916e66dc4a46a71368046b149b283de87769690e7aa4e0b9483530c'
    for name, identity in acquired['timestamp_lists'].items():
        assert digest(PARENT/name) == identity['sha256']
    rgb = inputs.parse((PARENT/'rgb.txt').read_text(), 'rgb')
    depth = inputs.parse((PARENT/'depth.txt').read_text(), 'depth')
    pairs = inputs.associate(rgb, depth)
    selected = [dict(index=i, rgb_ns=p.rgb.timestamp_ns, depth_ns=p.depth.timestamp_ns,
                     difference_ns=p.signed_difference_ns, rgb=p.rgb.relative, depth=p.depth.relative,
                     split='calibration' if i < 8 else 'evaluation') for i, p in enumerate(pairs)]
    # Seal the complete timestamp-only selection before importing the decoder
    # or reading even one PNG member. Content cannot choose or replace frames.
    selection = OUT/'selection.json'
    selection.write_text(json.dumps(selected, indent=2)+'\n', encoding='utf-8')
    report.update(phase='selected_before_any_png_read', selection_sha256=digest(selection),
                  selected_pairs=32, calibration_pairs=8, evaluation_pairs=24,
                  maximum_association_difference_ns=max(abs(p.signed_difference_ns) for p in pairs))
    save()
    import cv2
    import numpy as np
    cv2.ocl.setUseOpenCL(False)
    cv2.setNumThreads(1)
    report.update(phase='decode', decoder={'opencv': cv2.__version__, 'numpy': np.__version__,
                                        'opencl': False, 'threads': 1})
    save()
    required = {PREFIX+row[kind]: (row['index'], kind) for row in selected for kind in ('rgb', 'depth')}
    assert len(required) == 64
    prepared = [dict(row) for row in selected]
    seen = set()
    with tarfile.open(archive, 'r|gz') as tar:
        for member in tar:
            if member.name not in required:
                continue
            assert member.name not in seen and member.isfile() and member.size <= 4 << 20
            seen.add(member.name)
            index, kind = required[member.name]
            stream = tar.extractfile(member)
            assert stream is not None
            raw = stream.read(member.size+1)
            assert len(raw) == member.size and raw[:8] == b'\x89PNG\r\n\x1a\n'
            assert raw[8:16] == b'\x00\x00\x00\rIHDR'
            width, height, bits, color = struct.unpack('>IIBB', raw[16:26])
            assert (width, height, bits, color) == (640, 480, 8 if kind == 'rgb' else 16, 2 if kind == 'rgb' else 0)
            image = cv2.imdecode(np.frombuffer(raw, dtype=np.uint8), cv2.IMREAD_UNCHANGED)
            assert image is not None
            if kind == 'rgb':
                assert image.shape == (480, 640, 3) and image.dtype == np.uint8
                payload = image[:, :, ::-1].tobytes(order='C')
                filename = f'{index:02}.rgb'
            else:
                assert image.shape == (480, 640) and image.dtype == np.uint16
                payload = image.astype('<u2', copy=False).tobytes(order='C')
                filename = f'{index:02}.depth.u16le'
                valid = image[image != 0]
                prepared[index].update(valid_sensor_pixels=int(valid.size),
                                       missing_sensor_pixels=int(image.size-valid.size),
                                       minimum_nonzero_sensor=int(valid.min()) if valid.size else None,
                                       maximum_sensor=int(image.max()))
            (OUT/filename).write_bytes(payload)
            prepared[index][kind+'_input'] = dict(filename=filename, bytes=len(payload),
                  sha256=hashlib.sha256(payload).hexdigest(), source_png_sha256=hashlib.sha256(raw).hexdigest())
    assert seen == set(required) and digest(selection) == report['selection_sha256']
    manifest = OUT/'inputs.json'
    manifest.write_text(json.dumps(prepared, indent=2)+'\n', encoding='utf-8')
    report.update(status='complete32_registered_pairs_frozen_no_model_predictions', phase='completed',
                  inputs_sha256=digest(manifest), decoded_pngs=64,
                  valid_sensor_pixels=sum(row['valid_sensor_pixels'] for row in prepared),
                  missing_sensor_pixels=sum(row['missing_sensor_pixels'] for row in prepared))
    save()
except BaseException:
    report['status'] = 'failed_original_preparation_retained'
    report['cause'] = traceback.format_exc()
    save()
    raise
finally:
    report['source_unchanged'] = hashes() == report['source_sha256']
    report['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    assert report['source_unchanged'], 'Source changed during original input preparation'
