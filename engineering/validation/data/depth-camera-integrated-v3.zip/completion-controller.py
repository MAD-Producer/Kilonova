from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

root=Path('E:/Dev/aem');work=root/'.worktrees/depth-authoring'
gate=root/'artifacts/pr-queue/depth-camera-integrated-v3'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
r=json.loads((gate/'accepted.json').read_text(encoding='utf-8'))
assert git('rev-parse','HEAD')==r['head'] and not git('status','--porcelain')
assert all(sha(work/p)==h for p,h in r['source'].items())
assert all(s['exitCode']==0 and s['sourceUnchanged'] for s in r['steps'])
counts={s['name']:s['totals'] for s in r['steps'] if 'totals' in s}
assert sum(v['passed'] for v in counts.values())==879,counts
assert all(v['failed']==0 and v['ignored']==0 for v in counts.values())
workflow=(gate/'workflow.stderr.log').read_text(encoding='utf-8')
assert 'Ran 13 tests' in workflow and workflow.rstrip().endswith('OK')
out=root/'artifacts/pr-queue/depth-camera-integrated-complete-v1';out.mkdir(exist_ok=False)
archive=work/'engineering/validation/data/depth-camera-integrated-v3.zip'
payload={}
for name in ('frozen-camera-focused-v1','depth-camera-integrated-v1','depth-camera-integrated-v2','depth-camera-integrated-v3'):
    directory=root/'artifacts/pr-queue'/name
    for p in directory.rglob('*'):
        if p.is_file():payload[name+'/'+p.relative_to(directory).as_posix()]=p.read_bytes()
payload['completion-controller.py']=Path(__file__).read_bytes()
payload['source.patch']=subprocess.check_output(['git','diff','--binary',r['main'],r['head']],cwd=work)
manifest={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in payload.items()}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for k,v in payload.items():z.writestr(k,v)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(manifest)+1
    for k,v in manifest.items():
        data=z.read(k);assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
doc=work/'engineering/validation/depth-camera-integrated-current.md'
text='''# Integrated camera and depth authoring regression

## Accepted local source

The frozen affected-suite regression passes **879 Rust tests, 0 failed, 0
ignored**, plus **13 Python workflow tests**. Counts are scene 85 across nine
targets, model 96 across 25, core 88 across 17, native renderer 450 across 18,
and host 160 across ten. Host depth-disabled compilation and desktop
FFmpeg/AI-depth compilation, provenance and panel-style checks also pass.
Earlier checkpoint counts overlap and must not be added to these totals.

The tested main baseline is `2af21061ec2a8f8ebf465dd083d29ba5ea4099e1`
and implementation head is `a451d80de80b7cc7473330d645f4a5bcdfd0a36f`.
This includes the accepted camera ancestry source from PR535, the persisted
calibration/current-input stage and frozen video camera-source ownership, plus
the main CI/acceptance updates. The ancestry-aware preparation callback retains
both the current camera resolver and candidate depth-calibration validation;
neither was dropped during conflict resolution. Every step verifies source
hashes. The later completion amendment changes documents/evidence only.

## Covered behavior

The gate reruns actual GPU model, imported camera, parent, alpha, image, mask,
effect, nested composition, resource-refusal and immutable upload regression
suites. New camera ancestry, actual host drag/align, persisted calibration,
actual prepared RGB hash and frozen-reader CPU/GPU tests all execute.

The frozen reader owns the snapshot's immutable catalog and independent source
clock after live camera edits, session close and source-file removal. Native
pixels at frames 0 and 30 match live sampling at all four precisions, while
animation visibly changes the mesh output. The final reader release drops its
last retained parsed source. Snapshot wire messages, reader capacities and
sequence/failure recovery behavior remain unchanged.

Saved calibration is admitted against actual prepared RGB, exact source time,
model/geometry/interpretation and the separately guarded current session
result. Commands use ordinary history and rollback. Fresh requests after
commit/reopen rebuild a live revision-bound calibration; changed pixels with
unchanged predictions are refused. No old runtime revision guard was removed.

Two preliminary combined invocations stopped before Rust tests because the
local Python invocation lacked its existing pinned PyYAML path, then the tools
discovery path. The final invocation uses the repository's documented unittest
discovery and the already installed dependency on E. No test, assertion,
threshold, budget, timeout or skip was changed to address those environment
errors. Their raw loader output is retained rather than counted as coverage.

## Limits and remaining work

These are source-bound affected suites, not complete workspace, cross-platform
or final #87 acceptance. PR535 retains its separate cross-platform CI. Native
frozen-frame output is covered; encoded video/container output still needs
end-to-end acceptance. Persisted calibration remains authoring/admission data:
ordinary preview/capture does not yet consume it as native geometry depth.

The actual current-frame render bridge, source-camera and transformed-plane
reprojection, multiple calibrated layers and units, native seed budget/error
recovery, actual reprojection/DOF output, complex effect/mask/matte/nested depth,
intersecting transparency and final maintained-desktop acceptance remain open.
Neither #74 nor #87 closes. Android is retired and excluded. No UI or new
third-party asset changes are included.
'''
text+=f'''\n[Exact-source evidence](data/depth-camera-integrated-v3.zip), SHA-256
`{sha(archive)}`, {archive.stat().st_size} bytes. The archive retains source,
the patch against the tested main, commands, controllers, raw native output,
exit receipts and the preliminary invocation failures. Every archive entry was
read back and SHA-256 verified.\n'''
doc.write_text(text,encoding='utf-8',newline='\n')
frozen=work/'engineering/validation/frozen-camera-source-current.md'
s=frozen.read_text(encoding='utf-8')
old='''The focused result is not a full affected-suite or cross-platform acceptance.
Combined regression with persisted calibration and camera ancestry editing on
the current main baseline is pending.'''
assert old in s
s=s.replace(old,'''The focused result was followed by the source-bound combined regression with
persisted calibration, camera ancestry editing and main 2af21061: 879 Rust tests
and 13 workflow tests pass, with zero failed/ignored Rust tests. See
[integrated evidence](depth-camera-integrated-current.md). This is selected
affected regression, not complete workspace or cross-platform acceptance.''')
frozen.write_text(s,encoding='utf-8',newline='\n')
depth=work/'engineering/validation/depth-calibration-authoring-current.md'
s=depth.read_text(encoding='utf-8')
s+='''\n## Subsequent integration\n\nThe authoring stage above was subsequently integrated with camera ancestry
editing and frozen source ownership against main 2af21061, retaining both
candidate-calibration validation and the actual camera resolver. The expanded
gate passes 879 Rust tests and 13 workflow tests; see
[combined evidence and limits](depth-camera-integrated-current.md). This
supersedes the earlier separate-source integration status, without changing the
historical 317-test receipt or claiming the native depth frame bridge is done.\n'''
depth.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['git','diff','--check'],cwd=work,check=True)
subprocess.run(['git','add','--',str(doc.relative_to(work)),str(archive.relative_to(work)),str(depth.relative_to(work)),str(frozen.relative_to(work))],cwd=work,check=True)
subprocess.run(['git','commit','--amend','--no-edit'],cwd=work,check=True)
subprocess.run(['git','show','--stat','--oneline','HEAD'],cwd=work,check=True)
assert not git('status','--porcelain') and all(sha(work/p)==h for p,h in r['source'].items())
result=dict(head=git('rev-parse','HEAD'),testedHead=r['head'],main=r['main'],
    completedUtc=datetime.now(timezone.utc).isoformat(),totals=counts,workflowTests=13,
    archiveSha256=sha(archive),published=False,nativeDepthBridgeComplete=False)
(out/'completed.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
