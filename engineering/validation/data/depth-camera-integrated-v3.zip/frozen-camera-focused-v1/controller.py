from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess

root=Path('E:/Dev/aem'); work=root/'.worktrees/frozen-camera-export'
out=root/'artifacts/pr-queue/frozen-camera-focused-v1'; out.mkdir(exist_ok=False)
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (root/'artifacts/pr-queue/depth-calibration-authoring-v2/accepted.json').exists()
assert git('rev-parse','HEAD')=='a6be80a2ecbd552b66af932d53e1ee2a2373c849'
paths=git('ls-files','-co','--exclude-standard','-z').split('\0')
source={p:sha(work/p) for p in sorted(set(paths)) if p and
        (p.endswith(('.rs','.toml','.py','.json','.wgsl')) or p=='Cargo.lock')}
# Cargo's shared target records relative dep paths. Invalidate mtime fingerprints
# when switching own workspaces while keeping all source bytes unchanged.
for p in source:os.utime(work/p,None)
for p in git('diff','--name-only','HEAD').splitlines():
    dest=out/'source'/p; dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/p,dest)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',
    CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG',None)
command=['cargo','test','-p','motion-host','--features','gpu-tests,ai-depth','--lib',
    'ops::media::frozen::tests','--locked','--offline','--','--test-threads=1']
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
    code=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
receipt=dict(utc=datetime.now(timezone.utc).isoformat(),base=git('rev-parse','HEAD'),command=command,
    exitCode=code,source=source,sourceUnchanged=all(sha(work/p)==h for p,h in source.items()))
(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='source'}),flush=True)
assert code==0 and receipt['sourceUnchanged']
