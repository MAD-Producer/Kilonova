"""Independent f64 ray/triangle oracle; never reads production mesh vertices.

Declared before native execution: 3-byte RGB budget, alpha 255, both occlusion
classes >=30 pixels. Nine within-pixel rays must agree, have >2 scene-unit
depth separation, remain inside the inference crop, and span <=2 RGB bytes.
This intentionally excludes unresolved AA/color boundaries, and reports counts.
Authored calibration is not a measurement of real physical scene distances.
"""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
from PIL import Image


def linear(rgb):
    rgb = np.asarray(rgb, dtype=np.float64) / 255
    return np.where(rgb <= .04045, rgb / 12.92, ((rgb + .055) / 1.055) ** 2.4)


def encoded(rgb):
    rgb = np.clip(rgb, 0, 1)
    return np.rint(255 * np.where(rgb <= .0031308, rgb * 12.92,
                                  1.055 * rgb ** (1 / 2.4) - .055)).astype(int)


def ray_triangle(eye, direction, vertices):
    # A physical triangle-plane intersection, independent of raster depth rules.
    a, b, c = vertices
    n = np.cross(b - a, c - a)
    denominator = np.dot(n, direction)
    assert abs(denominator) > 1e-12
    return np.dot(n, a - eye) / denominator


def self_test():
    eye = np.array([0., 0., 0.])
    tri = np.array([[-1., -1., 4.], [1., -1., 4.], [0., 1., 4.]])
    assert ray_triangle(eye, np.array([0., 0., 1.]), tri) == 4
    # Sloped surface z=4+x: ray (x,z)=(t/10,t) meets it at 40/9.
    tilted = np.array([[-1., -1., 3.], [1., -1., 5.], [0., 1., 4.]])
    assert abs(ray_triangle(eye, np.array([.1, 0., 1.]), tilted) - 40 / 9) < 1e-12
    assert np.max(np.abs(encoded(linear(np.arange(256))) - np.arange(256))) == 0


def verify(root):
    project = json.loads((root / 'calibrated-project.json').read_text())
    layer = next(l for l in project['layers'] if l['id'] == 1)
    assert layer['depth_calibration'] is None
    assert len(layer['video_depth_calibration']) == 1
    cal = layer['video_depth_calibration'][0]['calibration']
    ref = cal['reference']
    desc = cal['interpretation']
    dw, dh = desc['size']
    geom = desc['geometry']
    assert geom['quarter_turns'] == 1 and geom['mirror_x']
    depth = np.fromfile(root / 'output.f32', dtype='<f4').reshape(dh, dw).astype(float)
    rgb = linear(np.fromfile(root / 'input.rgb', dtype=np.uint8).reshape(dh, dw, 3))
    vp = np.asarray(ref['camera']['view_projection']).reshape(4, 4, order='F')
    inv_vp = np.linalg.inv(vp)
    world = np.asarray(ref['world']).reshape(4, 4, order='F')
    inv_world = np.linalg.inv(world)
    eye = np.asarray(ref['camera']['eye'], dtype=float)
    forward = np.asarray(ref['camera']['target'], dtype=float) - eye
    forward /= np.linalg.norm(forward)
    sw, sh = geom['source_size']
    cx, cy, cw, ch = geom['crop']
    # Odd rotation: source-horizontal inference centres run down the depth image.
    xs = np.r_[0., cx / sw, (cx + (np.arange(dh) + .5) * cw / dh) / sw,
               (cx + cw) / sw, 1.]
    ys = np.r_[0., cy / sh, (cy + (np.arange(dw) + .5) * ch / dw) / sh,
               (cy + ch) / sh, 1.]
    anchors = cal['anchors']
    lo, hi = [a['value'] for a in anchors]
    assert cal['curve'] == 'camera_z' and cal['pixels_per_metre'] == 20

    def prepared_uv(u, v):
        # Clockwise quarter-turn then horizontal mirror => (v, u).
        return np.array([(v * sh - cy) / ch, (u * sw - cx) / cw])

    def world_vertex(u, v):
        flat = world @ np.array([(u - .5) * ref['size'][0],
                                 (.5 - v) * ref['size'][1], 0., 1.])
        q = prepared_uv(u, v)
        if np.any(q < 0) or np.any(q > 1):
            return flat[:3]
        ix, iy = np.minimum((q * [dw, dh]).astype(int), [dw - 1, dh - 1])
        value = depth[iy, ix] * desc['scale'] + desc['offset']
        z = (anchors[0]['camera_z_meters'] + (value - lo) / (hi - lo)
             * (anchors[1]['camera_z_meters'] - anchors[0]['camera_z_meters'])) * 20
        return eye + (flat[:3] - eye) * z / np.dot(flat[:3] - eye, forward)

    vertices = np.array([[world_vertex(u, v) for u in xs] for v in ys])

    def sample(px, py):
        ndc = np.array([2 * px / 96 - 1, 1 - 2 * py / 64, .5, 1.])
        point = inv_vp @ ndc
        direction = point[:3] / point[3] - eye
        direction /= np.dot(direction, forward)  # ray parameter = camera Z
        o = inv_world @ np.r_[eye, 1.]
        d = inv_world @ np.r_[direction, 0.]
        t = -o[2] / d[2]
        local = o[:3] + d[:3] * t
        u, v = .5 + local[0] / ref['size'][0], .5 - local[1] / ref['size'][1]
        q = prepared_uv(u, v)
        if np.any(q < .03) or np.any(q > .97):
            return None
        ix, iy = np.searchsorted(xs, u) - 1, np.searchsorted(ys, v) - 1
        fx = (u - xs[ix]) / (xs[ix + 1] - xs[ix])
        fy = (v - ys[iy]) / (ys[iy + 1] - ys[iy])
        tri = ([vertices[iy, ix], vertices[iy + 1, ix], vertices[iy + 1, ix + 1]]
               if fy >= fx else
               [vertices[iy, ix], vertices[iy + 1, ix + 1], vertices[iy, ix + 1]])
        z = ray_triangle(eye, direction, tri)
        if abs(z - 120) <= 2:
            return None
        if z > 120:
            return 0, np.array([0, 0, 255])
        x, y = q * [dw, dh] - .5
        x0, y0 = int(np.floor(x)), int(np.floor(y))
        fx, fy = x - x0, y - y0
        color = (rgb[y0, x0] * (1 - fx) * (1 - fy) + rgb[y0, x0 + 1] * fx * (1 - fy)
                 + rgb[y0 + 1, x0] * (1 - fx) * fy + rgb[y0 + 1, x0 + 1] * fx * fy)
        return 1, encoded(color)

    actual = np.array(Image.open(root / 'inferred-3d.png').convert('RGBA'))
    flat = np.array(Image.open(root / 'flat-control.png').convert('RGBA'))
    assert actual.shape == flat.shape == (64, 96, 4)
    counts = [0, 0]
    maximum = 0
    checked = []
    for y in range(64):
        for x in range(96):
            rays = [sample(x + .5 + dx, y + .5 + dy)
                    for dy in [-.49, 0., .49] for dx in [-.49, 0., .49]]
            if any(r is None for r in rays) or len({r[0] for r in rays}) != 1:
                continue
            colors = np.array([r[1] for r in rays])
            if np.max(np.ptp(colors, axis=0)) > 2:
                continue
            kind, expected = rays[4]
            error = int(np.max(abs(actual[y, x, :3].astype(int) - expected)))
            assert error <= 3 and actual[y, x, 3] == 255, (x, y, kind, expected.tolist(), actual[y, x].tolist())
            assert np.max(abs(flat[y, x].astype(int) - [0, 0, 255, 255])) <= 1, (x, y, 'flat')
            counts[kind] += 1
            maximum = max(maximum, error)
            checked.append([x, y, kind, error])
    assert min(counts) >= 30, counts
    report = dict(status='independent_ray_oracle_passed', countsFarNear=counts,
                  maxByteError=maximum, checked=checked, excluded=6144-sum(counts),
                  sourceSha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in [root/'output.f32', root/'input.rgb', root/'calibrated-project.json']},
                  limits=['Authored calibration, not physical depth accuracy',
                          'Stable crop interiors only; nine rays must agree', 'No GUI/Surface claim'])
    (root / 'independent-render-oracle.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'checked'}))


if __name__ == '__main__':
    self_test()
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path, nargs='?')
    args = parser.parse_args()
    if args.root:
        verify(args.root)
    else:
        print('Analytic ray/color oracle self-checks passed; no native acceptance executed')
