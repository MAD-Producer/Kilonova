"""Actual ONNX -> authored calibration -> frozen 3D output, with retained failures."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, time
import numpy as np

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-colmap88'
probe = root / '.tools/ai-depth74/inferred-render-probe'
out = root / 'artifacts/pr-queue/depth74-inferred-render-v2'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
binary = root / 'target/colmap88-isolated-check/debug/motion-depth74-integration-probe.exe'

def source():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=work).decode().split('\0')
    files = {p: sha(work / p) for p in names if p and
             (p.startswith(('crates/', 'desktop/')) or p in ('Cargo.toml', 'Cargo.lock'))
             and (work / p).is_file()}
    files.update({'external-probe/' + p: sha(probe / p)
                  for p in ('Cargo.toml', 'Cargo.lock', 'src/main.rs', 'verify.py')})
    return files

report = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip(),
              source=source(), binarySha256=sha(binary),
              startedUtc=datetime.now(timezone.utc).isoformat(), commands=[],
              status='running', limits=['Authored calibration, not physical depth accuracy',
              'Default Rust Session ownership thread; no GUI or Surface claim',
              'Does not replace the disk-blocked full workspace regression'])
before = report['source']
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
for p in ('Cargo.toml', 'Cargo.lock', 'src/main.rs', 'verify.py'):
    dest = out / 'probe' / p
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((probe / p).read_bytes())

def save():
    (out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

env = os.environ.copy()
env.pop('MOTION_LOG', None)
env['CUDA_VISIBLE_DEVICES'] = ''
home = root / '.tools/ai-depth74'
for key, folder in [('TEMP', 'temp'), ('TMP', 'temp'), ('TORCH_HOME', 'torch-cache'),
                    ('HF_HOME', 'hf-cache'), ('TORCHINDUCTOR_CACHE_DIR', 'inductor-cache'),
                    ('PYTHONPYCACHEPREFIX', 'pycache')]:
    env[key] = str(home / folder)
ffbin = root / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
env['PATH'] = str(ffbin) + os.pathsep + env['PATH']
report['runtimeDlls'] = {}
for dll in ffbin.glob('*.dll'):
    dest = binary.parent / dll.name
    if not dest.exists():
        dest.write_bytes(dll.read_bytes())
    assert sha(dest) == sha(dll)
    report['runtimeDlls'][dll.name] = sha(dest)

def run(name, cmd):
    assert before == source()
    row = dict(name=name, command=cmd)
    report['commands'].append(row)
    save()
    with (out / (name + '.stdout.log')).open('wb') as stdout, (out / (name + '.stderr.log')).open('wb') as stderr:
        p = subprocess.Popen(cmd, cwd=work, env=env, stdout=stdout, stderr=stderr)
        row['pid'] = p.pid
        save()
        row['exitCode'] = p.wait()
    save()
    assert row['exitCode'] == 0, (name, row['exitCode'])

started = time.monotonic()
save()
try:
    color = root / 'artifacts/pr-queue/issue3d-final-color-staging-v1'
    receipt = json.loads((color / 'verified.json').read_text())
    fixture = color / 'known/project/assets/source.mp4'
    assert sha(fixture) == receipt['artifacts']['known/project/assets/source.mp4']
    dest = out / 'native/project/assets/source.mp4'
    dest.parent.mkdir(parents=True)
    dest.write_bytes(fixture.read_bytes())
    report['fixtureSha256'] = sha(fixture)
    report['onnxSha256'] = sha(home / 'models/depth_anything_v2_vits_518.onnx')
    assert report['onnxSha256'] == '274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
    run('native', [str(binary), str(out / 'native'), 'inference', 'cpu'])
    assert not (out / 'native.stdout.log').read_bytes()
    log = (out / 'native/logs/motion-studio.log').read_text()
    stderr = (out / 'native.stderr.log').read_text()
    assert 'logging initialized level=INFO' in log
    assert log.index('start #1 depth_infer asset=74') < log.index('ERROR')
    for stream in (log, stderr):
        assert 'request=1 operation=depth_infer asset=74' in stream and 'video cache missing' in stream
    expected_rgb = color / 'known/input.rgb'
    assert sha(expected_rgb) == receipt['artifacts']['known/input.rgb']
    assert (out / 'native/input.rgb').read_bytes() == expected_rgb.read_bytes()
    golden = root / 'artifacts/pr-queue/issue3d-final-native-depth-v1/official-reference.f32'
    assert sha(golden) == '2695b67c87473b1d89fb56763d24ce87836983c5082a77ef5a72f0d4858eb546'
    reference = np.fromfile(golden, dtype='<f4').astype(float)
    actual = np.fromfile(out / 'native/output.f32', dtype='<f4').astype(float)
    assert len(actual) == 52 * 80 and np.isfinite(actual).all()
    error = np.abs(reference - actual) / max(float(np.max(abs(reference))), 1e-6)
    assert error.max() <= 2e-4 and error.mean() <= 2e-5
    report['retainedReference'] = dict(mode='Pinned historical independent golden, not a fresh PyTorch run',
                                     maxNormalized=float(error.max()), meanNormalized=float(error.mean()),
                                     maxBound=2e-4, meanBound=2e-5, rgbBitExact=True)
    run('independent-oracle', [str(home / 'venv/Scripts/python.exe'), str(probe / 'verify.py'), str(out / 'native')])
    report['status'] = 'passed_native_and_independent_oracle'
except BaseException as error:
    report.update(status='failed_original_outputs_retained', failure=repr(error))
    raise
finally:
    report.update(sourceUnchanged=before == source(), elapsedSeconds=time.monotonic() - started,
                  completedUtc=datetime.now(timezone.utc).isoformat())
    save()
assert report['sourceUnchanged']
print(json.dumps({k: v for k, v in report.items() if k not in ('source', 'runtimeDlls')}))
