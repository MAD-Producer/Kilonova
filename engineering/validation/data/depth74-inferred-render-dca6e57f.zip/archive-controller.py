from pathlib import Path
import hashlib, json, zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-colmap88'
base = root / 'artifacts/pr-queue'
dest = work / 'engineering/validation/data/depth74-inferred-render-dca6e57f.zip'
sha = lambda data: hashlib.sha256(data).hexdigest()
entries = {}
for folder in ('depth74-inferred-render-v1', 'depth74-inferred-render-v2', 'depth74-inferred-render-v3'):
    for p in (base / folder).rglob('*'):
        rel = p.relative_to(base / folder)
        if p.is_file() and not any(part in ('plugins', 'cache', 'scratch') for part in rel.parts):
            assert p.suffix.lower() not in ('.exe', '.dll', '.onnx', '.pth', '.pdb')
            entries['runs/' + folder + '/' + rel.as_posix()] = p.read_bytes()
for folder in ('tracking88-workspace-main-integration-v1', 'tracking88-workspace-main-integration-v2'):
    for name in ('controller.py', 'exit.json', 'stdout.log', 'stderr.log'):
        p = base / folder / name
        if p.exists():
            entries['workspace/' + folder + '/' + name] = p.read_bytes()
probe = root / '.tools/ai-depth74/inferred-render-probe'
for name in ('check.exit.json', 'check.stdout.log', 'check.stderr.log',
             'build.exit.json', 'build.stdout.log', 'build.stderr.log',
             'build-v2.exit.json', 'build-v2.stdout.log', 'build-v2.stderr.log',
             'build-v3.exit.json', 'build-v3.stdout.log', 'build-v3.stderr.log'):
    entries['build/' + name] = (probe / name).read_bytes()
for name in ('issue3d-final-native-depth-v1/official-reference.f32',
             'issue3d-final-native-depth-v1/verified.json',
             'issue3d-final-color-staging-v1/known/input.rgb',
             'issue3d-final-color-staging-v1/verified.json'):
    entries['reference/' + name] = (base / name).read_bytes()
entries['archive-controller.py'] = Path(__file__).read_bytes()
manifest = {p: dict(bytes=len(data), sha256=sha(data)) for p, data in sorted(entries.items())}
entries['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
with zipfile.ZipFile(dest, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p, data in sorted(entries.items()):
        z.writestr(p, data)
with zipfile.ZipFile(dest) as z:
    assert set(z.namelist()) == set(entries)
    for p, data in entries.items():
        assert z.read(p) == data
receipt = dict(archive=dest.name, bytes=dest.stat().st_size, sha256=sha(dest.read_bytes()),
               members=len(entries), everyMemberReadBack=True, manifest=manifest,
               exclusions=['Reproducible installed plugin/cache/scratch directories',
                           'No native binary, DLL, model weight or inference runtime'])
dest.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in receipt.items() if k != 'manifest'}))
