import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

repo = Path('E:/Dev/aem/.worktrees/animation-presets')
out = Path('E:/Dev/aem/artifacts/pr-ci-followups')
build = (out / 'animation-presets-desktop-test-build-accepted.log').read_text(encoding='utf-8-sig')
match = re.search(r'Executable unittests .*\(([^\r\n]+motion_studio-[0-9a-f]+\.exe)\)', build)
if not match:
    raise SystemExit('Current successful build did not report a desktop test executable')
binary = Path(match[1])
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
source_paths = subprocess.check_output(
    ['git', 'diff', '--name-only', 'origin/feat/layer-playback-switches', '--', 'crates', 'desktop/app'],
    cwd=repo, text=True, encoding='utf-8').splitlines()
sources = {name: sha(repo / name) for name in source_paths}
result = {'binary': str(binary), 'exeSha256': sha(binary), 'sourceHashes': sources, 'rows': []}
environment = os.environ.copy()
environment.pop('MOTION_LOG', None)
environment['MOTION_ANIMATION_PRESET_FAILURE_ARTIFACTS'] = str(out / 'animation-presets-default-failures-accepted')
environment['MOTION_ANIMATION_PRESET_UI_ARTIFACTS'] = str(out / 'animation-presets-native-accepted')
cases = [
    ('desktop-functional', ['animation_presets::tests::', '--nocapture', '--test-threads=1']),
    ('native-ui', ['--exact', 'animation_presets::tests::native::native_preset_and_effect_context_menus_use_bilingual_main_and_floating_windows', '--ignored', '--nocapture', '--test-threads=1']),
    ('effect-controls-regression', ['panels::effect_controls::', '--nocapture', '--test-threads=1']),
    ('recent-menu-regression', ['recent_effect_menu_tests::', '--nocapture', '--test-threads=1']),
    ('library-recent-shell-regression', ['shell::effect_application::tests::recent_menu::', '--nocapture', '--test-threads=1']),
]
for name, args in cases:
    began = time.monotonic()
    completed = subprocess.run([str(binary), *args], cwd=repo, env=environment, capture_output=True)
    (out / f'animation-presets-accepted-{name}.stdout.log').write_bytes(completed.stdout)
    (out / f'animation-presets-accepted-{name}.stderr.log').write_bytes(completed.stderr)
    stdout = completed.stdout.decode('utf-8', errors='replace')
    stderr = completed.stderr.decode('utf-8', errors='replace')
    row = {'name': name, 'returncode': completed.returncode,
           'elapsedSeconds': round(time.monotonic() - began, 2),
           'summary': re.findall(r'test result: [^\r\n]+', stdout + stderr),
           'exeUnchanged': sha(binary) == result['exeSha256']}
    result['rows'].append(row)
    (out / 'animation-presets-accepted-desktop-results.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(row, ensure_ascii=False), flush=True)
    if completed.returncode or not row['exeUnchanged']:
        raise SystemExit(f'Validation stopped at {name}; raw output retained')
if sources != {name: sha(repo / name) for name in source_paths}:
    raise SystemExit('Sources changed during verification')
