"""Full FFmpeg library regression and actual four-precision frozen outputs."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

root=Path('E:/Dev/aem')
work=root/'.worktrees/frozen-camera-movie'
assert (root/'artifacts/pr-queue/frozen-imported-camera-red-v2/reproduced.json').exists()
out=root/'artifacts/pr-queue/frozen-imported-camera-native-v1'
out.mkdir(exist_ok=False)
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
paths=git('ls-files','-co','--exclude-standard','-z').split('\0')
source={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json')) or p=='Cargo.lock')}
changed=git('diff','--name-only','HEAD').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
for p in changed:
    if p not in source:continue
    dest=out/'source'/p
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(work/p,dest)
shutil.copyfile(__file__,out/'controller.py')
env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true',
    MOTION_IMPORTED_CAMERA_OUTPUT_ARTIFACTS=str(out/'renders'))
env.pop('MOTION_LOG',None)
steps=[
    ('provenance',['python','tools/validate_provenance.py']),
    ('style',['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
    ('media-ffmpeg',['cargo','test','-p','motion-desktop-media','--lib','--features','ffmpeg,gpu-tests',
        '--locked','--offline','--no-fail-fast','--','--test-threads=1','--include-ignored']),
    ('png-without-ffmpeg',['cargo','test','-p','motion-desktop-media','--lib','--features','gpu-tests','--locked','--offline',
        'movie::imported_camera_tests::frozen_imported_camera_png_matches_native_after_live_clock_edit_and_source_removal',
        '--','--test-threads=1']),
    ('media-without-ffmpeg',['cargo','check','-p','motion-desktop-media','--no-default-features','--locked','--offline']),
    ('desktop',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),
]
receipt=dict(baseHead=git('rev-parse','HEAD'),main=git('rev-parse','8c271bd3'),source=source,
    startedUtc=datetime.now(timezone.utc).isoformat(),steps=[],
    scope='Actual frozen imported-camera PNG and persisted/restored MP4 outputs at four precisions, complete 31-frame decoding, source and live-session removal; not calibrated-video depth or final workspace acceptance')
for name,cmd in steps:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        code=subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
    row=dict(name=name,command=cmd,exitCode=code,sourceUnchanged=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in source.items()))
    if name=='media-ffmpeg':
        text=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
        results=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
        row['results']=results
    receipt['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    assert code==0 and row['sourceUnchanged'],name
    if name=='media-ffmpeg':
        assert len(results)==1 and results[0][1:]==('0','0')
        for test in ('frozen_imported_camera_mp4_restores_after_source_and_session_removal_at_all_precisions',
            'frozen_imported_camera_png_matches_native_after_live_clock_edit_and_source_removal'):
            assert f'test movie::imported_camera_tests::{test} ... ok' in text
        assert 'test movie::keyframe_timing_tests::frozen_keyframe_timing_matches_reopened_pixels_and_differs_from_linear_and_removed_layer ... ok' in text
    if name=='png-without-ffmpeg':
        text=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
        assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in text
renders=out/'renders'
assert len(list(renders.rglob('*.mp4')))==4
assert len(list(renders.rglob('comparison.json')))==8
for p in renders.glob('*-mp4/comparison.json'):
    comparison=json.loads(p.read_text(encoding='utf-8'))
    assert comparison['sourceRemoved'] and comparison['restored'] and len(comparison['frames'])==31
for p in renders.glob('*-png/comparison.json'):
    comparison=json.loads(p.read_text(encoding='utf-8'))
    assert comparison['exactNativePixels'] and comparison['sourceRemoved'] and comparison['frame']==15
receipt['completedUtc']=datetime.now(timezone.utc).isoformat()
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True)),flush=True)
