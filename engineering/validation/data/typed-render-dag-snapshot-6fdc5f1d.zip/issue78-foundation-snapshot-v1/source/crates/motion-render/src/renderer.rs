use crate::resource_ledger::{DeviceTextureExt, OwnedTexture};
use motion_model::{Project, MAX_LAYERS};
use crate::{PlaneCompositor, ResourceBudgetScope, ResourceRejection, Scene};
mod compositing;
mod gpu_failure;
mod frame_blend;
mod exposure;
mod layer_raster;
mod phase_adjustment;
mod exposure_frame;
mod nested_exposure;
mod working_precision;
pub use working_precision::WorkingPrecisionChange;
pub use exposure_frame::{ExposureFrame, ExposurePoll, ExposureProgress, ExposureStage};
pub use layer_raster::LayerRaster;
pub use exposure::ExposureTarget;
use bytemuck::{Pod, Zeroable};
use image::ImageReader;
use std::{
    collections::HashMap,
    num::NonZeroU64,
    path::Path,
    sync::{mpsc, Arc, Mutex},
    time::Instant,
};

#[cfg(test)]
pub(crate) const TEXTURE_BUDGET: u64 = crate::resource_policy::DEFAULT_SOURCE_TEXTURE_BUDGET;
pub(crate) const CAPTURE_PIXEL_LIMIT: u64 = 16 * 1024 * 1024;
// Retain at most 16 KiB of CPU eviction scratch between trims.
const MAX_IMAGE_TRIM_CANDIDATES: usize = 1024;
const DRAW_SIZE: u64 = std::mem::size_of::<DrawUniform>() as u64;
const GEOMETRY_VERTICES: u64 = 65_536;
const UNIFORM_ALIGNMENT: u64 = wgpu::Limits::downlevel_defaults().min_uniform_buffer_offset_alignment as u64;
/// Fixed logical descriptor capacity per renderer, excluding on-demand SDK
/// instances, scene resources, targets, staging and driver overhead.
pub const FIXED_RENDERER_ALLOCATION_BYTES: u64 =
    DRAW_SIZE.div_ceil(UNIFORM_ALIGNMENT) * UNIFORM_ALIGNMENT * MAX_LAYERS as u64
    + GEOMETRY_VERTICES * std::mem::size_of::<GeometryVertex>() as u64
    + crate::layer_gpu::CLEAR_VERTEX_BYTES + 4 + 4 + 1024;
#[cfg(test)]
mod plane_sampling_tests;
#[cfg(test)]
mod image_trim_tests;
#[cfg(test)]
mod admission_tests;
const TARGET_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Rgba8UnormSrgb;
fn cached_image_descriptor(width: u32, height: u32) -> wgpu::TextureDescriptor<'static> {
    wgpu::TextureDescriptor {
        label: Some("Motion Studio cached image"),
        size: wgpu::Extent3d { width, height, depth_or_array_layers: 1 },
        mip_level_count: 1, sample_count: 1, dimension: wgpu::TextureDimension::D2,
        format: TARGET_FORMAT,
        usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
        view_formats: &[],
    }
}
/// Restore valid snapshot pixels after a different draw reused this allocation.
fn restore_effect_snapshot(encoder: &mut wgpu::CommandEncoder, source: &wgpu::Texture,
    size: (u32, u32), destination: &crate::effect_gpu::FxTexture) {
    if size.0 < destination.texture.width() || size.1 < destination.texture.height() {
        drop(encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: Some("clear reused effect snapshot padding"),
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view: &destination.view, depth_slice: None, resolve_target: None,
                ops: wgpu::Operations { load: wgpu::LoadOp::Clear(wgpu::Color::TRANSPARENT), store: wgpu::StoreOp::Store },
            })],
            depth_stencil_attachment: None, timestamp_writes: None, occlusion_query_set: None, multiview_mask: None,
        }));
    }
    encoder.copy_texture_to_texture(
        wgpu::TexelCopyTextureInfo { texture: source, mip_level: 0, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
        wgpu::TexelCopyTextureInfo { texture: &destination.texture, mip_level: 0, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
        wgpu::Extent3d { width: size.0, height: size.1, depth_or_array_layers: 1 });
}
#[cfg(test)]
mod scratch_reuse_tests;
static PREFETCH_FAILURES: crate::observability::FailureCounter = crate::observability::FailureCounter::new();
static IMAGE_PENDING: crate::observability::FailureCounter = crate::observability::FailureCounter::new();
static TEXTURE_ACCOUNTING_MISMATCHES: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

#[derive(Debug, thiserror::Error)]
pub enum RenderError {
    #[error("no compatible GPU adapter: {0}")]
    Adapter(#[from] wgpu::RequestAdapterError),
    #[error("GPU poll failed: {0}")]
    Poll(#[from] wgpu::PollError),
    #[error(transparent)]
    Device(#[from] wgpu::RequestDeviceError),
    #[error(transparent)]
    Image(#[from] image::ImageError),
    #[error("{0}")]
    Effects(#[from] motion_effects::Error),
    #[error(transparent)]
    ExecutionPlan(#[from] motion_effects::execution_plan::ExecutionPlanError),
    #[error("{0}")]
    ImageFormat(#[from] crate::image_formats::UnsupportedStorage),
    #[error("{0}")]
    ImageContract(#[from] motion_effects::image_contract::ImageFormatError),
    #[error("{0}")]
    ImageSamples(#[from] crate::image_formats::UnsupportedSamples),
    #[error("{0}")]
    Model(#[from] motion_model::Error),
    #[error(transparent)]
    Io(#[from] std::io::Error),
    #[error("GPU validation: {0}")]
    ImageResource(#[from] crate::image_resources::Error),
    #[error(transparent)]
    VectorUpload(#[from] crate::VectorUploadError),
    #[error(transparent)]
    VectorGeometry(#[from] crate::VectorGeometryError),
    #[error("GPU validation: {0}")]
    Invalid(String),
    // Preserve the historical display text while callers inspect the refusal.
    #[error("GPU validation: {message}")]
    Resource { rejection: ResourceRejection, message: String },
    #[error("GPU readback failed: {0}")]
    Readback(String),
    #[error(transparent)]
    CompositionPlan(#[from] crate::composition_plan::CompositionPlanError),
    // Keep protocol-facing text independent of the original boxed source.
    #[error("{message}")]
    Context { message: String, #[source] cause: Box<RenderError> },
    #[error("GPU validation: {message}")]
    Diagnostic { message: String, #[source] cause: Box<RenderError> },
    /// Cached failures retain their original identity across repeated plans.
    #[error("{0}")]
    Shared(#[source] Arc<RenderError>),
}
pub(crate) type Result<T> = std::result::Result<T, RenderError>;

#[cfg(test)]
mod resource_rejection_tests;

impl RenderError {
    pub fn resource_rejection(&self) -> Option<&ResourceRejection> {
        let mut error = self;
        loop {
            match error {
                Self::Resource { rejection, .. } => return Some(rejection),
                Self::ImageResource(cause) => return cause.resource_rejection(),
                Self::Context { cause, .. } | Self::Diagnostic { cause, .. } => error = cause,
                Self::Shared(cause) => error = cause,
                Self::CompositionPlan(crate::composition_plan::CompositionPlanError::Encoding(cause)) => error = cause,
                _ => return None,
            }
        }
    }
    pub(crate) fn budget(scope: ResourceBudgetScope, required_bytes: u64, budget_bytes: u64, message: impl Into<String>) -> Self {
        Self::Resource { rejection: ResourceRejection::Budget { scope, required_bytes, budget_bytes }, message: message.into() }
    }
    // Nested diagnostics must retain typed resource refusals through the parent.
    pub(crate) fn with_diagnostic(self, message: String) -> Self {
        Self::Diagnostic { message, cause: Box::new(self) }
    }
    /// Existing plan diagnostics use the validation detail without a second
    /// renderer prefix; the returned error retains its complete typed cause.
    pub(crate) fn planning_message(&self) -> String {
        match self {
            Self::Invalid(message) | Self::Resource { message, .. } | Self::Diagnostic { message, .. } => message.clone(),
            Self::Shared(cause) => cause.planning_message(),
            _ => self.to_string(),
        }
    }
}

// Some CPU planning helpers still expose text-only validation errors. Convert
// only at those boundaries; native IO, image, effect and resource errors keep
// their own variants and original sources.
impl From<String> for RenderError {
    fn from(message: String) -> Self { Self::Invalid(message) }
}
impl From<&str> for RenderError {
    fn from(message: &str) -> Self { Self::Invalid(message.into()) }
}

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
pub(crate) struct DrawUniform {
    mvp: [[f32; 4]; 4],
    color: [f32; 4],
    extent_opacity: [f32; 4],
    uv_scale: [f32; 4],
    screen_uv: [[f32; 4]; 3],
}
#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct GeometryVertex {
    position: [f32; 3],
    uv: [f32; 2],
}
pub(crate) struct GpuImage {
    pub(crate) view: wgpu::TextureView,
    pub(crate) bind_group: wgpu::BindGroup,
    pub(crate) bytes: u64,
    pub(crate) size: (u32, u32),
    pub(crate) video_stamp: Option<(u64, u64)>,
    // Release views/bindings before their allocation reservation.
    pub(crate) _texture: OwnedTexture,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub(crate) enum TextureKey {
    Static(u64),
    Video(u64),
    VideoBlendSource(u64, u8),
    Vector(u64),
    Mask(u64),
    EffectInput(u64),
}
fn texture_key(layer: &crate::DrawLayer) -> TextureKey {
    if layer.vector.is_some() {
        TextureKey::Vector(layer.id)
    } else if layer.video.is_some() || layer.composition {
        TextureKey::Video(layer.id)
    } else {
        TextureKey::Static(layer.asset.unwrap_or(0))
    }
}
fn nested_size(parent:&Scene,child:&Scene,width:u32,height:u32)->(u32,u32) {
    let scale=(f64::from(width)/f64::from(parent.width)).min(f64::from(height)/f64::from(parent.height));
    ((f64::from(child.width)*scale).ceil().max(1.) as u32,(f64::from(child.height)*scale).ceil().max(1.) as u32)
}

#[derive(Clone, Copy, Debug, Default)]
pub struct RenderStats {
    pub cpu_prepare_us: u64,
    pub draw_calls: u32,
    pub texture_bytes: u64,
    pub parameter_upload_bytes: u64,
    pub parameter_resource_upload_bytes: u64,
    pub instance_upload_bytes: u64,
    pub particles_alive: u32,
    pub particles_visible: u32,
    pub particles_culled: u32,
}

impl RenderStats {
    fn add(&mut self,other:Self) {
        self.cpu_prepare_us+=other.cpu_prepare_us;self.draw_calls+=other.draw_calls;
        self.parameter_upload_bytes+=other.parameter_upload_bytes;self.parameter_resource_upload_bytes+=other.parameter_resource_upload_bytes;
        self.instance_upload_bytes+=other.instance_upload_bytes;self.particles_alive+=other.particles_alive;
        self.particles_visible+=other.particles_visible;self.particles_culled+=other.particles_culled;
        self.texture_bytes=self.texture_bytes.max(other.texture_bytes);
    }
}

pub struct Renderer {
    memory_pressure_probe: crate::memory_pressure::MemoryPressureProbe,
    allocation_budget: crate::AllocationBudget,
    pub(crate) allocation_owner: Arc<()>,
    command_profiler: Option<crate::gpu_commands::AttachedCommandProfiler>,
    submission_ledger: crate::submission_ledger::SubmissionLedger,
    preview_resource_guard: bool,
    pub adapter: wgpu::Adapter,
    pub device: wgpu::Device,
    pub queue: wgpu::Queue,
    pub adapter_info: wgpu::AdapterInfo,
    pub(crate) image_capabilities: Arc<crate::image_formats::ImageCapabilities>,
    pipeline: wgpu::RenderPipeline,
    additive_pipeline: wgpu::RenderPipeline,
    masked_pipeline: wgpu::RenderPipeline,
    image_layout: wgpu::BindGroupLayout,
    uniform_layout: wgpu::BindGroupLayout,
    sampler: wgpu::Sampler,
    uniform_group: wgpu::BindGroup,
    uniform_buffer: crate::allocation_buffer::AllocationBuffer,
    uniform_stride: usize,
    upload: Vec<u8>,
    compositor: PlaneCompositor,
    vertex_buffer: crate::allocation_buffer::AllocationBuffer,
    geometry_upload: Vec<GeometryVertex>,
    images: HashMap<TextureKey, GpuImage>,
    texture_bytes: u64,
    pub target_format: wgpu::TextureFormat,
    gpu_failure: Arc<Mutex<Option<String>>>,
    effect_gpu: crate::effect_gpu::EffectGpu,
    layer_gpu: crate::layer_gpu::LayerGpu,
    mask_gpu: crate::mask_gpu::MaskGpu,
    compositing_gpu: Option<crate::compositing_gpu::CompositingGpu>,
    compositing_pipeline_set_builds: u64,
    video_gpu: Option<crate::video_gpu::VideoGpu>,
    video_blend: Option<frame_blend::FrameBlendGpu>,
    exposure_gpu: Option<exposure::ExposureGpu>,
    exposure_bytes: Arc<std::sync::atomic::AtomicU64>,
    /// Source-cache copies and linear mixtures submitted over this renderer's lifetime.
    pub video_blend_submissions: u64,
    pub video_upload_bytes: u64,
    pub video_uploads: u64,
    pub video_gpu_conversions: u64,
    /// Explicit conversion-only submissions; excludes queue upload staging and readback.
    pub video_conversion_submissions: u64,
    pub video_encoded_conversions: u64,
    pub(crate) image_readback: crate::readback::ImageReadbackCounters,
    asset_order: Vec<u64>,
    image_sources: HashMap<u64, crate::image_resources::Source>,
    image_decode: crate::image_resources::DecodeTask,
    image_active: std::collections::BTreeSet<u64>,
    image_access: HashMap<u64, u64>,
    image_trim_candidates: Vec<(u64, u64)>,
    image_clock: u64,
    image_prefetch: Vec<u64>,
    image_prefetch_failed: std::collections::HashSet<u64>,
    image_cache_enabled: bool,
    pub image_decodes: u64,
    pub image_proxy_cache_hits: u64,
    pub image_upload_bytes: u64,
    pub image_memory_cache_hits: u64,
    pub image_prefetches: u64,
    pub effect_diagnostics: Vec<String>,
    snapshot_encodes: Vec<crate::effect_plan::SnapshotEncode>,
    composition_images: std::collections::HashSet<u64>,
    // Drop last: finish unsubmitted destination lifetimes after cache handles.
    allocation_uploads: Arc<crate::allocation_uploads::AllocationUploads>,
}

impl Renderer {
    pub async fn new(
        instance: &wgpu::Instance,
        surface: Option<&wgpu::Surface<'_>>,
        format: wgpu::TextureFormat,
    ) -> Result<Self> {
        Self::new_profiled(instance, surface, format, false).await
    }
    pub async fn new_profiled(
        instance: &wgpu::Instance,
        surface: Option<&wgpu::Surface<'_>>,
        format: wgpu::TextureFormat,
        timestamps: bool,
    ) -> Result<Self> {
        Self::new_profiled_with_allocation_budget(instance, surface, format, timestamps,
            crate::AllocationBudget::default()).await
    }
    pub async fn new_profiled_with_allocation_budget(
        instance: &wgpu::Instance,
        surface: Option<&wgpu::Surface<'_>>,
        format: wgpu::TextureFormat,
        timestamps: bool,
        allocation_budget: crate::AllocationBudget,
    ) -> Result<Self> {
        Self::new_profiled_with_options(instance, surface, format, timestamps, allocation_budget, false).await
    }
    /// Hosts offering live project precision changes enable the optional
    /// supported working-format features up front. Unsupported modes still fail
    /// explicitly when selected; other constructors retain their narrow request.
    pub async fn new_profiled_with_precision_changes(
        instance: &wgpu::Instance,
        surface: Option<&wgpu::Surface<'_>>,
        format: wgpu::TextureFormat,
        timestamps: bool,
        allocation_budget: crate::AllocationBudget,
    ) -> Result<Self> {
        Self::new_profiled_with_options(instance, surface, format, timestamps, allocation_budget, true).await
    }
    async fn new_profiled_with_options(
        instance: &wgpu::Instance,
        surface: Option<&wgpu::Surface<'_>>,
        format: wgpu::TextureFormat,
        timestamps: bool,
        allocation_budget: crate::AllocationBudget,
        precision_changes: bool,
    ) -> Result<Self> {
        let precision = crate::image_formats::color_precision(format)
            .ok_or_else(|| RenderError::Invalid(format!("unsupported working color target {format:?}")))?;
        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: surface,
                force_fallback_adapter: false,
                ..Default::default()
            })
            .await?;
        let adapter_info = adapter.get_info();
        let precision_features = crate::image_formats::working_features(precision);
        let missing = precision_features - adapter.features();
        if !missing.is_empty() {
            return Err(RenderError::Invalid(format!(
                "working precision {precision:?} requires adapter features {missing:?}; no precision fallback was applied")));
        }
        let supported = adapter.limits();
        let base = if supported.max_compute_workgroups_per_dimension == 0 {
            wgpu::Limits::downlevel_webgl2_defaults()
        } else { wgpu::Limits::downlevel_defaults() };
        let limits = base.using_resolution(supported);
        let (device, queue) = adapter
            .request_device(
                &wgpu::DeviceDescriptor {
                    label: Some("Motion Studio GPU"),
                    // Bounded exposure modes use UNORM16 means. Floating
                    // working modes retain floating storage and capabilities.
                    required_features: (adapter.features()
                        & (wgpu::Features::TEXTURE_FORMAT_16BIT_NORM
                            | wgpu::Features::TEXTURE_ADAPTER_SPECIFIC_FORMAT_FEATURES))
                        | precision_features
                        | if precision_changes {
                            adapter.features() & crate::image_formats::working_features(
                                motion_effects::image_contract::ChannelPrecision::Float32)
                        } else { wgpu::Features::empty() }
                        | if timestamps {
                            adapter.features() & wgpu::Features::TIMESTAMP_QUERY
                        } else {
                            wgpu::Features::empty()
                        },
                    required_limits: limits,
                    memory_hints: wgpu::MemoryHints::Performance,
                    ..Default::default()
                },
            )
            .await?;
        let image_capabilities = Arc::new(crate::image_formats::ImageCapabilities::query(&adapter, &device));
        for storage in [crate::image_formats::color_storage(precision),
            crate::image_formats::raster_storage(precision),
            motion_effects::image_contract::coverage_storage(precision)] {
            image_capabilities.require(storage, motion_effects::image_contract::ImageUsage::EFFECT_TARGET)?;
        }
        image_capabilities.require_msaa4(crate::image_formats::raster_storage(precision))?;
        let gpu_failure = Arc::new(Mutex::new(None));
        let observer = Arc::new(gpu_failure::Observation::new(gpu_failure.clone(), adapter_info.clone()));
        let lost = observer.clone();
        device.set_device_lost_callback(move |reason, message| {
            lost.device_lost(reason, message);
        });
        device.on_uncaptured_error(Arc::new(move |error| {
            observer.uncaptured(error);
        }));
        // Admit every fixed resource before any queue upload. Failed startup
        // then releases its complete reservation without a submission callback.
        let white_texture = device.create_admitted_texture(&cached_image_descriptor(1, 1), &allocation_budget, crate::TextureCategory::SystemTextures)
            .map_err(|error| {
                let message = format!("image key=Static(0) size=1x1 phase=allocate: {error}");
                error.with_diagnostic(message)
            })?;
        let alignment = device.limits().min_uniform_buffer_offset_alignment as usize;
        let uniform_stride = (DRAW_SIZE as usize).div_ceil(alignment) * alignment;
        let uniform_buffer = crate::allocation_buffer::AllocationBuffer::new(&device, &allocation_budget, &wgpu::BufferDescriptor {
            label: Some("Motion Studio reusable layer parameters"),
            size: (uniform_stride * MAX_LAYERS) as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        })?;
        let uniform_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("Motion Studio parameter layout"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX_FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: true,
                    min_binding_size: NonZeroU64::new(DRAW_SIZE),
                },
                count: None,
            }],
        });
        let uniform_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("Motion Studio parameter group"),
            layout: &uniform_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: wgpu::BindingResource::Buffer(wgpu::BufferBinding {
                    buffer: &uniform_buffer,
                    offset: 0,
                    size: NonZeroU64::new(DRAW_SIZE),
                }),
            }],
        });
        let vertex_buffer = crate::allocation_buffer::AllocationBuffer::new(&device, &allocation_budget, &wgpu::BufferDescriptor {
            label: Some("Motion Studio bounded planar geometry"),
            size: GEOMETRY_VERTICES * std::mem::size_of::<GeometryVertex>() as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        })?;
        let image_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("Motion Studio image layout"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
            ],
        });
        let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("Motion Studio linear image sampler"),
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            ..Default::default()
        });
        let (pipeline, additive_pipeline, masked_pipeline) = working_precision::pipelines(
            &device, &uniform_layout, &image_layout, format);
        let allocation_uploads = Arc::new(crate::allocation_uploads::AllocationUploads::new(queue.clone()));
        let layer_gpu = crate::layer_gpu::LayerGpu::new(&device, &uniform_layout, &image_layout, format, &allocation_budget)?;
        let mask_gpu=crate::mask_gpu::MaskGpu::with_precision(&device,&image_layout,
            allocation_budget.clone(), allocation_uploads.clone(), precision)?;
        let white_view = white_texture.create_view(&Default::default());
        let white_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("Motion Studio cached texture binding"),
            layout: &image_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&white_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&sampler) },
            ],
        });
        let mut effect_gpu = crate::effect_gpu::EffectGpu::new(&device, &queue, &image_layout,
            allocation_budget.clone(), allocation_uploads.clone(),
            image_capabilities.clone())?;
        effect_gpu.builder.set_precision(precision);
        let mut renderer = Self {
            memory_pressure_probe: Default::default(),
            allocation_budget,
            allocation_owner: Arc::new(()),
            command_profiler: None,
            preview_resource_guard: false,
            submission_ledger: Default::default(),
            adapter,
            device,
            queue,
            adapter_info,
            image_capabilities,
            pipeline,
            additive_pipeline,
            masked_pipeline,
            image_layout,
            uniform_layout,
            sampler,
            uniform_buffer,
            uniform_group,
            uniform_stride,
            upload: vec![0; uniform_stride * MAX_LAYERS],
            compositor: PlaneCompositor::new(),
            vertex_buffer,
            geometry_upload: Vec::with_capacity(MAX_LAYERS * 12),
            images: HashMap::from([(TextureKey::Static(0), GpuImage {
                view: white_view, bind_group: white_group, bytes: 4, size: (1, 1),
                video_stamp: None, _texture: white_texture,
            })]),
            texture_bytes: 4,
            target_format: format,
            composition_images: Default::default(),
            gpu_failure,
            effect_gpu,
            layer_gpu,
            mask_gpu,
            video_gpu: None,
            video_blend: None,
            exposure_gpu: None,
            exposure_bytes: Arc::new(std::sync::atomic::AtomicU64::new(0)),
            video_blend_submissions: 0,
            video_upload_bytes: 0,
            video_uploads: 0,
            image_readback: Default::default(),
            video_gpu_conversions: 0,
            video_conversion_submissions: 0,
            video_encoded_conversions: 0,
            asset_order: vec![0],
            image_sources: HashMap::new(),
            image_decode: Default::default(),
            image_active: Default::default(),
            image_access: Default::default(),
            image_trim_candidates: Vec::new(),
            image_clock: 0,
            image_prefetch: Vec::new(),
            image_prefetch_failed: Default::default(),
            image_cache_enabled: false,
            image_decodes: 0,
            image_proxy_cache_hits: 0,
            image_upload_bytes: 0,
            image_memory_cache_hits: 0,
            image_prefetches: 0,
            effect_diagnostics: Vec::new(),
            snapshot_encodes: Vec::new(),
            compositing_gpu: None,
            compositing_pipeline_set_builds: 0,
            allocation_uploads,
        };
        renderer.effect_gpu.builder.device_dimension =
            renderer.device.limits().max_texture_dimension_2d.min(8192);
        renderer.upload_image(0, 1, 1, &[255; 4])?;
        renderer.effect_gpu.invalidate();
        Ok(renderer)
    }
    pub async fn headless() -> Result<Self> {
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor::new_without_display_handle_from_env());
        Self::new(&instance, None, TARGET_FORMAT).await
    }
    pub async fn headless_with_allocation_budget(budget: crate::AllocationBudget) -> Result<Self> {
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor::new_without_display_handle_from_env());
        Self::new_profiled_with_allocation_budget(&instance, None, TARGET_FORMAT, false, budget).await
    }
    /// Project-owned headless work uses the requested mode from construction and
    /// enables supported features for later edits on this same device.
    pub async fn headless_with_working_precision(
        precision: motion_effects::image_contract::ChannelPrecision,
        budget: crate::AllocationBudget,
    ) -> Result<Self> {
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor::new_without_display_handle_from_env());
        let format = crate::image_formats::native_format(crate::image_formats::color_storage(precision));
        Self::new_profiled_with_precision_changes(&instance, None, format, false, budget).await
    }
    pub fn allocation_budget(&self) -> &crate::AllocationBudget { &self.allocation_budget }
    /// Successfully encoded snapshot draws in the latest local composition
    /// attempt. This counts native encode/copy calls, not predicted graph work.
    pub fn snapshot_encodes(&self) -> &[crate::effect_plan::SnapshotEncode] {
        &self.snapshot_encodes
    }
    pub(crate) fn allocation_uploads(&self) -> Arc<crate::allocation_uploads::AllocationUploads> {
        self.allocation_uploads.clone()
    }
    /// External resources share this renderer's native owner, live allowance
    /// and queued-upload retirement ledger, rather than a new independent budget.
    pub fn allocation_context(&self) -> crate::AllocationContext {
        crate::AllocationContext::new(self.device.clone(), self.queue.clone(),
            self.allocation_budget.clone(), self.allocation_uploads.clone(), self.allocation_owner.clone())
    }
    /// Explicit read-only probe on this renderer's adapter, cached for one second.
    /// Unknown means no native budget was obtained; application admission and
    /// preview/export quality are never changed by this observation.
    pub fn memory_pressure(&mut self) -> crate::MemoryPressureSnapshot {
        self.memory_pressure_probe.query(&self.adapter)
    }
    pub fn allocation_command_encoder(&self, descriptor: &wgpu::CommandEncoderDescriptor<'_>)
        -> Result<crate::AllocationEncoder>
    {
        self.allocation_command_encoder_for(crate::gpu_commands::CommandStage::Unclassified, descriptor)
    }
    pub fn allocation_command_encoder_for(&self, stage: crate::gpu_commands::CommandStage,
        descriptor: &wgpu::CommandEncoderDescriptor<'_>) -> Result<crate::AllocationEncoder>
    {
        match &self.command_profiler {
            Some(profiler) => profiler.encoder(self, descriptor, stage),
            None => self.unobserved_command_encoder(descriptor),
        }
    }
    pub(crate) fn unobserved_command_encoder(&self, descriptor: &wgpu::CommandEncoderDescriptor<'_>)
        -> Result<crate::AllocationEncoder>
    {
        self.allocation_budget.encoder(&self.device, self.allocation_owner.clone(), descriptor)
    }
    /// Observe the existing raw-submit route without changing its allocation
    /// reservation/upload retirement contract into the allocated-encoder route.
    pub fn tracked_command_encoder_for(&self, stage: crate::gpu_commands::CommandStage,
        descriptor: &wgpu::CommandEncoderDescriptor<'_>) -> crate::gpu_commands::TrackedCommandEncoder
    {
        let encoder = match &self.command_profiler {
            Some(profiler) => profiler.raw_encoder(self, descriptor, stage),
            None => crate::gpu_commands::ObservedEncoder::new(self.device.create_command_encoder(descriptor)),
        };
        crate::gpu_commands::TrackedCommandEncoder::new(encoder, self.allocation_owner.clone())
    }
    pub fn submit_observed(&self, buffer: crate::gpu_commands::TrackedCommandBuffer,
        extra_resources: impl FnOnce(&mut crate::TextureResourceLedger)) -> Result<wgpu::SubmissionIndex>
    {
        buffer.submit(&self.allocation_owner, |buffer| self.submit_tracked(buffer, extra_resources))
    }
    /// Explicitly allocate detailed timing. It is disabled by default and
    /// independent of the ordinary root timer. Failure leaves the old epoch.
    pub fn start_command_profiling(&mut self, slots: usize)
        -> Result<Option<crate::gpu_commands::GpuCommandObserver>>
    {
        let profiler = crate::gpu_commands::GpuCommandProfiler::new(self, slots)?;
        let observer = profiler.as_ref().map(|profiler| profiler.observer());
        self.command_profiler = profiler.map(|profiler| profiler.into_attached());
        Ok(observer)
    }
    pub fn command_observer(&self) -> Option<crate::gpu_commands::GpuCommandObserver> {
        self.command_profiler.as_ref().map(|profiler| profiler.observer())
    }
    /// Explicit fault injection for debug GPU-test sink acceptance only.
    /// Corrupts diagnostic readback words via a real native copy. Never called
    /// automatically and absent from Release builds, including Release studies.
    #[cfg(all(debug_assertions, feature = "gpu-tests"))]
    #[doc(hidden)]
    pub fn debug_inject_invalid_command_words(&self)
        -> Result<crate::gpu_commands::CommandIdentity>
    {
        self.command_profiler.as_ref()
            .ok_or_else(|| RenderError::Invalid("command profiling is disabled".into()))?
            .debug_inject_invalid_command_words(self)
    }
    /// Captures an actual host request/poll before entering media or encoding.
    /// Guard drop restores the enclosing scope on success, error and unwind.
    /// Disabled profiling creates no scope and takes no observation lock.
    pub fn exposure_command_scope(&self, context: crate::gpu_commands::ExposureCommandContext)
        -> Option<crate::gpu_commands::ExposureCommandScope>
    {
        self.command_profiler.as_ref().map(|profiler| profiler.exposure_scope(context))
    }
    /// Returns metadata for exact pending callbacks after retiring this epoch.
    /// Does not wait, retry or cancel render work, or attach it to a later epoch.
    pub fn stop_command_profiling(&mut self) -> Option<crate::gpu_commands::GpuCommandObserver> {
        self.command_profiler.take().map(|profiler| profiler.observer())
    }
    /// Retains allocation reservations through queue completion independently
    /// of whether optional diagnostic submission snapshots are enabled.
    pub fn submit_allocated(&self, buffer: crate::AllocatedCommandBuffer,
        extra_resources: impl FnOnce(&mut crate::TextureResourceLedger)) -> Result<wgpu::SubmissionIndex>
    {
        buffer.submit(&self.allocation_budget, &self.allocation_owner,
            |buffer| self.submit_tracked_inner(buffer, extra_resources), &self.queue, &self.allocation_uploads)
    }
    pub fn effect_plan_builds(&self) -> u64 {
        self.effect_gpu.builder.preview_plan_builds
    }
    pub fn set_scratch_budget(&mut self, bytes: u64) -> Result<()> {
        self.effect_gpu.builder.set_scratch_budget(bytes)
    }
    pub fn memory_policy(&self) -> crate::resource_policy::MemoryPolicy {
        self.effect_gpu.builder.memory_policy()
    }
    pub fn set_memory_policy(&mut self, policy: crate::resource_policy::MemoryPolicy) -> Result<()> {
        let decode_changed = self.memory_policy().decoded_image_budget_bytes != policy.decoded_image_budget_bytes;
        self.effect_gpu.builder.set_memory_policy(policy)?;
        if decode_changed {
            self.image_decode.cancel();
            self.image_prefetch_failed.clear();
        }
        Ok(())
    }
    pub fn set_preview_resource_guard(&mut self, enabled: bool) {
        self.preview_resource_guard = enabled;
        self.effect_gpu.builder.invalidate_preview_plan();
    }
    /// Drop only idle image cache ownership. Active inputs, pending conversions
    /// and the completed front are preserved. Returned bytes describe evicted
    /// cache entries; queued aliases may still retain admitted native capacity.
    pub fn evict_idle_preview_cache(&mut self) -> u64 {
        self.image_prefetch.clear();
        let idle: Vec<_> = self.image_access.keys().copied()
            .filter(|id| *id != 0 && !self.image_active.contains(id)).collect();
        let mut bytes = 0u64;
        for id in idle {
            bytes = bytes.saturating_add(self.images.get(&TextureKey::Static(id)).map_or(0, |image| image.bytes));
            self.remove_static_image(id);
        }
        bytes
    }
    /// Discard unsubmitted video tokens and their encoder before calling this.
    /// Retained presentation targets belong to the caller, not this working set.
    pub fn reclaim_preview_working_set(&mut self) -> Result<()> {
        if self.video_gpu.as_ref().is_some_and(|v| v.has_pending()) {
            return Err(RenderError::Invalid("cancel preview conversions before reclaiming resources".into()));
        }
        self.image_decode.cancel();
        self.image_prefetch.clear();
        self.image_trim_candidates = Vec::new();
        let idle: Vec<_> = self.image_access.keys().copied().filter(|id| !self.image_active.contains(id)).collect();
        for id in idle { self.remove_static_image(id); }
        let dynamic: Vec<_> = self.images.keys().copied().filter(|key| !matches!(key, TextureKey::Static(_))).collect();
        for key in dynamic {
            if let Some(image) = self.images.remove(&key) {
                self.texture_bytes = self.texture_bytes.saturating_sub(image.bytes);
            }
        }
        if let Some(video) = &mut self.video_gpu { video.clear(); }
        self.video_blend = None;
        self.composition_images.clear();
        self.mask_gpu.clear();
        self.layer_gpu.release();
        if let Some(compositing) = &mut self.compositing_gpu { compositing.release(); }
        self.effect_gpu.state.release_scratch();
        self.effect_gpu.invalidate();
        Ok(())
    }
    pub fn effect_plan_cache_hits(&self) -> u64 {
        self.effect_gpu.builder.preview_cache_hits
    }
    /// Successful native effect pipeline builds over this renderer's lifetime.
    pub fn effect_pipeline_builds(&self) -> u64 { self.effect_gpu.state.pipeline_builds }
    /// CPU time spent creating and validating native effect pipelines, including
    /// the validation wait. This is not GPU execution time or a driver-only timer.
    pub fn effect_pipeline_build_nanos(&self) -> u64 { self.effect_gpu.state.pipeline_build_nanos }
    pub fn set_pointwise_fusion(&mut self, enabled: bool) {
        self.effect_gpu.builder.set_pointwise_fusion(enabled);
    }
    pub fn pointwise_fusion_report(&self) -> &crate::effect_plan::FusionFrameReport {
        self.effect_gpu.builder.pointwise_fusion_report()
    }
    /// Corrupt one generated shader before its next uncached portable compile.
    /// Explicit diagnostics only; absent from release builds.
    #[cfg(all(debug_assertions, feature = "gpu-tests"))]
    #[doc(hidden)]
    pub fn debug_inject_pointwise_portable_failure(&mut self) {
        self.effect_gpu.builder.debug_inject_pointwise_portable_failure();
    }
    /// Corrupt one proved shader before its next uncached native validation.
    /// Uses a real device error scope; absent from release builds.
    #[cfg(all(debug_assertions, feature = "gpu-tests"))]
    #[doc(hidden)]
    pub fn debug_inject_pointwise_native_failure(&mut self) {
        self.effect_gpu.state.invalid_pointwise_source_once = true;
    }
    /// Compositing pipeline-set construction count, not driver compilation time.
    pub fn compositing_pipeline_set_builds(&self) -> u64 { self.compositing_pipeline_set_builds }
    pub fn texture_bytes(&self) -> u64 {
        self.texture_bytes
            + self.video_plane_bytes()
            + self.effect_gpu.state.bytes()
            + self.layer_gpu.bytes()
            + self.mask_gpu.scratch_bytes()
            + self.compositing_gpu.as_ref().map_or(0,|gpu|gpu.bytes())
    }
    /// Enable diagnostic snapshots for future submissions; pending records remain intact.
    pub fn set_submission_tracking(&self, enabled: bool) {
        self.submission_ledger.set_enabled(enabled);
    }
    /// Optional metadata instrumentation. Disabled submissions execute no ledger closure.
    /// Raw queue.submit calls, uploads and caller GPU resources are outside the
    /// optional diagnostic snapshot. Enrolled queued-upload destinations retire
    /// after this submission independently of diagnostic snapshots.
    pub fn submit_tracked(&self, buffer: wgpu::CommandBuffer,
        extra_resources: impl FnOnce(&mut crate::TextureResourceLedger)) -> wgpu::SubmissionIndex {
        let completion = self.allocation_budget.frame_submission();
        let index = self.submit_tracked_inner(buffer, extra_resources);
        let pending_uploads = self.allocation_uploads.take();
        if completion.is_tracked() || !pending_uploads.is_empty() {
            self.queue.on_submitted_work_done(move || {
                drop(pending_uploads);
                completion.complete();
            });
        }
        index
    }
    fn submit_tracked_inner(&self, buffer: wgpu::CommandBuffer,
        extra_resources: impl FnOnce(&mut crate::TextureResourceLedger)) -> wgpu::SubmissionIndex {
        let index = if !self.submission_ledger.enabled() { self.queue.submit(Some(buffer)) }
        else {
            let mut ledger = self.texture_resource_ledger();
            extra_resources(&mut ledger);
            self.submission_ledger.submit(&self.queue, buffer, ledger)
        };
        index
    }
    pub fn submission_memory_info(&self, current: &crate::TextureResourceLedger) -> crate::SubmissionMemoryInfo {
        self.submission_ledger.info(current)
    }
    pub fn vector_upload_info(&self) -> Result<crate::VectorUploadInfo> {
        self.layer_gpu.upload_info()
    }
    /// Explicit diagnostics only: clone bounded metadata, never GPU handles.
    pub fn submission_memory_snapshot(&self, current: &crate::TextureResourceLedger) -> crate::SubmissionMemorySnapshot {
        self.submission_ledger.snapshot(current)
    }
    /// Snapshot of application-owned textures; it does not keep GPU handles alive.
    pub fn texture_resource_ledger(&self) -> crate::TextureResourceLedger {
        use crate::TextureCategory::*;
        let mut ledger = crate::TextureResourceLedger::default();
        for (key, image) in &self.images {
            let category = match key {
                TextureKey::Static(0) => SystemTextures,
                TextureKey::Static(_) => StaticImages,
                TextureKey::Vector(_) => VectorSources,
                TextureKey::Mask(_) => MaskOutputs,
                TextureKey::EffectInput(_) => EffectInputSnapshots,
                TextureKey::Video(id) if self.composition_images.contains(id) => NestedCompositions,
                TextureKey::Video(_) | TextureKey::VideoBlendSource(..) => VideoRgba,
            };
            ledger.retained(&image._texture, category, format!("images/{key:?}"));
        }
        self.effect_gpu.state.collect_textures(&mut ledger);
        self.layer_gpu.collect_textures(&mut ledger);
        self.mask_gpu.collect_textures(&mut ledger);
        if let Some(gpu) = &self.compositing_gpu { gpu.collect_textures(&mut ledger); }
        if let Some(gpu) = &self.video_gpu { gpu.collect_textures(&mut ledger); }
        ledger
    }
    /// Explicit CPU decode observation; never polls a completion or touches GPU.
    pub fn image_decode_memory(&self) -> crate::image_resources::DecodeMemorySnapshot {
        self.image_decode.memory_info()
    }
    /// Borrowed CPU package owners; no readback or GPU allocation.
    pub fn compiled_shader_owners(&self) -> impl Iterator<Item = (&str, &std::sync::Arc<motion_effects::shader::CompiledShader>)> {
        self.effect_gpu.builder.compiled_shader_owners()
    }
    /// Borrowed CPU package owners; no readback or GPU allocation.
    pub fn package_memory_owners(&self) -> impl Iterator<Item = (
        motion_effects::memory::PackageOwner, &std::sync::Arc<motion_effects::EffectPackage>,
    )> {
        self.effect_gpu.builder.package_memory_owners()
    }
    pub fn texture_memory_breakdown(&self) -> crate::TextureMemoryBreakdown {
        let mut memory = crate::TextureMemoryBreakdown {
            video_planes: self.video_plane_bytes(),
            effect_scratch: self.effect_gpu.state.scratch_bytes(),
            plugin_resources: self.effect_gpu.state.resource_bytes,
            curve_luts: self.effect_gpu.state.curve_lut_bytes(),
            vector_raster_scratch: self.layer_gpu.raster_scratch_bytes(),
            vector_group_scratch: self.layer_gpu.group_scratch_bytes(),
            layer_compositing_scratch: self.layer_gpu.accumulator_bytes(),
            mask_scratch: self.mask_gpu.scratch_bytes(),
            matte_blend_scratch: self.compositing_gpu.as_ref().map_or(0,|g|g.bytes()),
            system_textures: self.effect_gpu.state.system_texture_bytes(),
            ..Default::default()
        };
        for (key, image) in &self.images {
            match key {
                TextureKey::Static(0) => memory.system_textures += image.bytes,
                TextureKey::Static(_) => memory.static_images += image.bytes,
                TextureKey::Vector(_) => memory.vector_sources += image.bytes,
                TextureKey::Mask(_) => memory.mask_outputs += image.bytes,
                TextureKey::EffectInput(_) => memory.effect_input_snapshots += image.bytes,
                TextureKey::Video(id) if self.composition_images.contains(id) =>
                    memory.nested_compositions += image.bytes,
                TextureKey::Video(_) | TextureKey::VideoBlendSource(..) => memory.video_rgba += image.bytes,
            }
        }
        memory
    }
    fn video_plane_bytes(&self) -> u64 {
        self.video_gpu.as_ref().map_or(0, |v| v.bytes())
    }
    pub fn set_effect_registry(&mut self, registry: motion_effects::Registry) {
        self.effect_gpu.set_registry(registry);
    }
    pub fn preflight_effects(&mut self, scene: &Scene, width: u32, height: u32) -> Result<()> {
        for node in &scene.nested {
            let (w,h)=nested_size(scene,&node.scene,width,height);
            self.preflight_effects(&node.scene,w,h)?;
        }
        self.effect_gpu
            .builder
            .build(scene, &self.asset_order, width, height, true)?;
        self.prepare_effect_images();
        self.effect_gpu.state.prepare(
            &self.device,
            &self.queue,
            &self.image_layout,
            &self.effect_gpu.builder,
            scene,
            self.texture_bytes + self.video_plane_bytes(),
            self.effect_gpu.builder.source_texture_budget,
        )?;
        if self.texture_bytes + self.video_plane_bytes() + self.effect_gpu.state.resource_bytes
            > self.effect_gpu.builder.source_texture_budget
        {
            return Err(RenderError::budget(ResourceBudgetScope::SourceTextures,
                self.texture_bytes + self.video_plane_bytes() + self.effect_gpu.state.resource_bytes,
                self.effect_gpu.builder.source_texture_budget, "images and plugin resources exceed configured source texture budget"));
        }
        Ok(())
    }
    pub fn gpu_error(&self) -> Option<String> {
        gpu_failure::read(&self.gpu_failure)
    }
    pub fn check_health(&self) -> Result<()> {
        if let Some(error) = self.gpu_error() {
            Err(RenderError::Invalid(error))
        } else {
            Ok(())
        }
    }
    pub fn image_count(&self) -> usize {
        self.images.len()
    }
    pub fn upload_image(&mut self, id: u64, width: u32, height: u32, rgba: &[u8]) -> Result<()> {
        self.upload_pixels(TextureKey::Static(id), width, height, rgba, true)
    }
    pub fn upload_video_frame(
        &mut self,
        object: u64,
        source: u64,
        pts: u64,
        width: u32,
        height: u32,
        rgba: &[u8],
    ) -> Result<()> {
        self.check_health()?;
        self.check_video_pending(object)?;
        if u64::from(width) * u64::from(height) * 4 != rgba.len() as u64 {
            return Err(RenderError::Invalid("video pixel length mismatch".into()));
        }
        if self
            .images
            .get(&TextureKey::Video(object))
            .is_some_and(|i| i.video_stamp == Some((source, pts)) && i.size == (width, height))
            && self.video_gpu.as_ref().is_none_or(|v| v.ready(object))
        {
            // A completed conversion already supplies these pixels. RGBA
            // handoff needs neither another upload nor the old YUV inputs.
            if let Some(video) = &mut self.video_gpu { video.remove(object); }
            return Ok(());
        }
        self.upload_pixels(TextureKey::Video(object), width, height, rgba, false)
            .map_err(|error| {
                if let Some(rejection) = error.resource_rejection() {
                    let message = format!("video object={object} source={source} pts_us={pts} phase=rgba_upload rejection={rejection:?}: {}", error.planning_message());
                    error.with_diagnostic(message)
                } else {
                    error
                }
            })?;
        // Keep cancellation/completion state until replacement succeeds.
        if let Some(video) = &mut self.video_gpu { video.remove(object); }
        self.video_uploads += 1;
        self.video_upload_bytes += rgba.len() as u64;
        self.images
            .get_mut(&TextureKey::Video(object))
            .unwrap()
            .video_stamp = Some((source, pts));
        self.invalidate_video_blend(object);
        Ok(())
    }
    pub fn upload_video_yuv(
        &mut self,
        object: u64,
        source: u64,
        pts: u64,
        frame: &crate::Yuv420Frame,
    ) -> Result<()> {
        self.upload_video_yuv_internal(object, source, pts, frame, None).map(|_| ())
    }
    /// Encode conversion before sampling video pixels in the same encoder.
    /// Submit that encoder before calling token.mark_submitted(). On abort,
    /// discard encoder and token. Each object accepts one unsubmitted upload.
    /// Nested scene rendering still submits separately; use upload_video_yuv
    /// for that path until nested passes share the encoder safely.
    pub fn encode_video_yuv(
        &mut self,
        object: u64,
        source: u64,
        pts: u64,
        frame: &crate::Yuv420Frame,
        encoder: &mut wgpu::CommandEncoder,
    ) -> Result<Option<crate::EncodedVideoUpload>> {
        self.upload_video_yuv_internal(object, source, pts, frame, Some(encoder))
    }
    fn check_video_pending(&self, object: u64) -> Result<()> {
        if self.video_gpu.as_ref().is_some_and(|v| v.pending(object)) {
            return Err(RenderError::Invalid(
                "video object has an unsubmitted conversion; submit or cancel its encoder and token".into(),
            ));
        }
        Ok(())
    }
    fn upload_video_yuv_internal(
        &mut self,
        object: u64,
        source: u64,
        pts: u64,
        frame: &crate::Yuv420Frame,
        encoder: Option<&mut wgpu::CommandEncoder>,
    ) -> Result<Option<crate::EncodedVideoUpload>> {
        self.check_health()?;
        frame.validate()?;
        self.check_video_pending(object)?;
        let (width, height) = frame.display_size();
        if width > self.device.limits().max_texture_dimension_2d
            || height > self.device.limits().max_texture_dimension_2d
        {
            return Err(RenderError::Invalid("video exceeds GPU dimensions".into()));
        }
        let key = TextureKey::Video(object);
        if self
            .images
            .get(&key)
            .is_some_and(|i| i.video_stamp == Some((source, pts)) && i.size == (width, height))
            && self.video_gpu.as_ref().is_none_or(|v| v.ready(object))
        {
            return Ok(None);
        }
        let bytes = u64::from(width) * u64::from(height) * 4;
        let previous = self.images.get(&key).map_or(0, |i| i.bytes);
        let reinterpret = self
            .adapter
            .get_downlevel_capabilities()
            .flags
            .contains(wgpu::DownlevelFlags::VIEW_FORMATS);
        let format = if reinterpret {
            wgpu::TextureFormat::Rgba8Unorm
        } else {
            TARGET_FORMAT
        };
        let planes = self
            .video_gpu
            .as_ref()
            .map_or(frame.bytes() as u64, |v| v.replacement_bytes(object, frame));
        self.trim_image_cache((bytes + planes).saturating_sub(previous + self.video_plane_bytes()));
        if self.texture_bytes - previous + bytes + planes + self.effect_gpu.state.resource_bytes
            > self.effect_gpu.builder.source_texture_budget
        {
            return Err(RenderError::budget(ResourceBudgetScope::SourceTextures,
                self.texture_bytes - previous + bytes + planes + self.effect_gpu.state.resource_bytes,
                self.effect_gpu.builder.source_texture_budget, "video planes and images exceed configured source texture budget"));
        }
        // Reserve the standalone encoding scope before replacing an existing
        // RGBA image. A scope-cap refusal must preserve its pixels and stamp.
        let mut standalone = if encoder.is_none() {
            Some(self.allocation_command_encoder_for(crate::gpu_commands::CommandStage::MediaPreparation, &wgpu::CommandEncoderDescriptor {
                label: Some("video GPU conversion"),
            }).map_err(|error| {
                let message = format!("video object={object} source={source} pts_us={pts} phase=conversion_encode: {error}");
                error.with_diagnostic(message)
            })?)
        } else { None };
        let encoder = match encoder {
            Some(encoder) => encoder,
            None => standalone.as_mut().map(|encoder| &mut **encoder).ok_or_else(||
                RenderError::Invalid("standalone video conversion encoder is missing".into()))?,
        };
        let replacement = if self.images.get(&key).is_none_or(|i| {
            i.size != (width, height)
                || i._texture.format() != format
                || !i
                    ._texture
                    .usage()
                    .contains(wgpu::TextureUsages::RENDER_ATTACHMENT)
        }) {
            // Write encoded RGB bytes to an UNORM attachment, then sample the
            // sRGB view in the same compositing space as existing RGBA uploads.
            let texture = self.device.create_admitted_texture(&wgpu::TextureDescriptor {
                label: Some("GPU converted video"),
                size: wgpu::Extent3d {
                    width,
                    height,
                    depth_or_array_layers: 1,
                },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format,
                view_formats: if reinterpret { &[TARGET_FORMAT] } else { &[] },
                usage: wgpu::TextureUsages::RENDER_ATTACHMENT
                    | wgpu::TextureUsages::TEXTURE_BINDING
                    | wgpu::TextureUsages::COPY_DST,
            }, &self.allocation_budget, crate::TextureCategory::VideoRgba).map_err(|error| {
                let message = format!("video object={object} source={source} pts_us={pts} phase=yuv_allocate: {error}");
                error.with_diagnostic(message)
            })?;
            let view = texture.create_view(&wgpu::TextureViewDescriptor {
                format: Some(TARGET_FORMAT),
                ..Default::default()
            });
            let bind_group = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: Some("converted video image"),
                layout: &self.image_layout,
                entries: &[
                    wgpu::BindGroupEntry {
                        binding: 0,
                        resource: wgpu::BindingResource::TextureView(&view),
                    },
                    wgpu::BindGroupEntry {
                        binding: 1,
                        resource: wgpu::BindingResource::Sampler(&self.sampler),
                    },
                ],
            });
            Some(GpuImage {
                    _texture: texture,
                    view,
                    bind_group,
                    bytes,
                    size: (width, height),
                    video_stamp: None,
                })
        } else { None };
        let image = replacement.as_ref().or_else(|| self.images.get(&key)).ok_or_else(||
            RenderError::Invalid("video conversion destination is missing".into()))?;
        let target = image
            ._texture
            .create_view(&wgpu::TextureViewDescriptor {
                format: Some(format),
                ..Default::default()
            });
        let new_converter = self.video_gpu.is_none()
            .then(|| crate::video_gpu::VideoGpu::new(&self.device, format));
        let converter = self.video_gpu.as_ref().or(new_converter.as_ref()).ok_or_else(||
            RenderError::Invalid("video converter is missing".into()))?;
        let prepared = converter.prepare_input(&self.device, &self.allocation_budget, object, frame)
            .and_then(|prepared| prepared.track(&self.allocation_uploads, &image._texture))
            .map_err(|error| {
                let message = format!("video object={object} source={source} pts_us={pts} phase=yuv_prepare: {error}");
                error.with_diagnostic(message)
            })?;
        if let Some(converter) = new_converter { self.video_gpu = Some(converter); }
        let converter = self.video_gpu.as_mut().ok_or_else(||
            RenderError::Invalid("prepared video converter is missing".into()))?;
        let upload = converter.encode_prepared(&self.queue, prepared,
            frame, &target, (width, height), encoder);
        let upload = if let Some(encoder) = standalone {
            self.submit_allocated(encoder.finish(), |_| {})?;
            upload.mark_submitted();
            self.video_conversion_submissions += 1;
            None
        } else {
            self.video_encoded_conversions += 1;
            Some(upload)
        };
        if let Some(image) = replacement {
            self.images.insert(key, image);
            self.texture_bytes = self.texture_bytes - previous + bytes;
            self.effect_gpu.invalidate();
        }
        self.images.get_mut(&key).unwrap().video_stamp = Some((source, pts));
        self.invalidate_video_blend(object);
        self.video_uploads += 1;
        self.video_upload_bytes += frame.bytes() as u64;
        self.video_gpu_conversions += 1;
        Ok(upload)
    }
    pub fn retain_video_instances(&mut self, scene: &Scene) {
        fn collect(scene:&Scene,ids:&mut std::collections::HashSet<u64>,compositions:&mut std::collections::HashSet<u64>){for l in &scene.layers{if l.video.is_some()||l.composition{ids.insert(l.id);}if l.composition{compositions.insert(l.id);}}for n in &scene.nested{collect(&n.scene,ids,compositions);}}
        let mut live=Default::default();let mut compositions=Default::default();collect(scene,&mut live,&mut compositions);
        let stale: Vec<_> = self
            .images
            .keys()
            .filter_map(|key| match key {
                TextureKey::Video(object)
                    if !live.contains(object)||self.composition_images.contains(object)!=compositions.contains(object) =>
                {
                    Some(*object)
                }
                _ => None,
            })
            .collect();
        for object in stale {
            if let Some(image) = self.images.remove(&TextureKey::Video(object)) {
                self.texture_bytes = self.texture_bytes.saturating_sub(image.bytes);
            }
            if let Some(video) = &mut self.video_gpu {
                video.remove(object);
            }
            self.effect_gpu.invalidate();
        }
        self.composition_images.retain(|id|compositions.contains(id));
        self.retain_video_blend_sources(scene);
    }
    fn upload_pixels(
        &mut self,
        id: TextureKey,
        width: u32,
        height: u32,
        rgba: &[u8],
        premultiply: bool,
    ) -> Result<()> {
        self.check_health()?;
        let bytes = u64::from(width) * u64::from(height) * 4;
        if width == 0
            || height == 0
            || width > self.device.limits().max_texture_dimension_2d
            || height > self.device.limits().max_texture_dimension_2d
            || rgba.len() as u64 != bytes
        {
            return Err(RenderError::Invalid(
                "invalid image dimensions or pixel length".into(),
            ));
        }
        let previous = self.images.get(&id).map_or(0, |t| t.bytes);
        // RGBA replaces this object's conversion inputs on successful commit.
        // Credit only its planes; other live objects still consume the budget.
        let retiring_planes = match id {
            TextureKey::Video(object) => self.video_gpu.as_ref().map_or(0, |v| v.input_bytes(object)),
            _ => 0,
        };
        self.trim_image_cache_except(bytes.saturating_sub(previous), Some(id), retiring_planes);
        let required = self.texture_bytes - previous
            + bytes
            + self.video_plane_bytes() - retiring_planes
            + self.effect_gpu.state.resource_bytes;
        if required > self.effect_gpu.builder.source_texture_budget
        {
            return Err(RenderError::budget(ResourceBudgetScope::SourceTextures,
                required,
                self.effect_gpu.builder.source_texture_budget, "decoded preview textures exceed configured source texture budget"));
        }
        let mut premultiplied = if premultiply {
            rgba.to_vec()
        } else {
            Vec::new()
        };
        for pixel in premultiplied.chunks_exact_mut(4) {
            let alpha = pixel[3] as f32 / 255.0;
            for channel in &mut pixel[..3] {
                *channel = (linear_to_srgb(srgb_to_linear(*channel as f32 / 255.0) * alpha) * 255.0)
                    .round() as u8;
            }
        }
        let pixels = if premultiply {
            premultiplied.as_slice()
        } else {
            rgba
        };
        if let Some(image) = self.images.get(&id).filter(|i| i.size == (width, height)) {
            self.allocation_uploads.track(image._texture.allocation()).map_err(|error| {
                let message = format!("image key={id:?} phase=upload_track: {error}");
                error.with_diagnostic(message)
            })?;
            self.queue.write_texture(
                wgpu::TexelCopyTextureInfo {
                    texture: &image._texture,
                    mip_level: 0,
                    origin: wgpu::Origin3d::ZERO,
                    aspect: wgpu::TextureAspect::All,
                },
                pixels,
                wgpu::TexelCopyBufferLayout {
                    offset: 0,
                    bytes_per_row: Some(width * 4),
                    rows_per_image: Some(height),
                },
                wgpu::Extent3d {
                    width,
                    height,
                    depth_or_array_layers: 1,
                },
            );
            return Ok(());
        }
        let category = match id {
            TextureKey::Static(_) => crate::TextureCategory::StaticImages,
            TextureKey::Video(_) | TextureKey::VideoBlendSource(_, _) => crate::TextureCategory::VideoRgba,
            TextureKey::Vector(_) => crate::TextureCategory::VectorSources,
            TextureKey::Mask(_) => crate::TextureCategory::MaskOutputs,
            TextureKey::EffectInput(_) => crate::TextureCategory::EffectInputSnapshots,
        };
        let texture = self.device.create_admitted_texture(&cached_image_descriptor(width, height), &self.allocation_budget, category).map_err(|error| {
            let message = format!("image key={id:?} size={width}x{height} phase=allocate: {error}");
            error.with_diagnostic(message)
        })?;
        self.allocation_uploads.track(texture.allocation()).map_err(|error| {
            let message = format!("image key={id:?} phase=upload_track: {error}");
            error.with_diagnostic(message)
        })?;
        self.queue.write_texture(
            wgpu::TexelCopyTextureInfo {
                texture: &texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            pixels,
            wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(width * 4),
                rows_per_image: Some(height),
            },
            wgpu::Extent3d {
                width,
                height,
                depth_or_array_layers: 1,
            },
        );
        let view = texture.create_view(&Default::default());
        let bind_group = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("Motion Studio cached texture binding"),
            layout: &self.image_layout,
            entries: &[
                wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::TextureView(&view),
                },
                wgpu::BindGroupEntry {
                    binding: 1,
                    resource: wgpu::BindingResource::Sampler(&self.sampler),
                },
            ],
        });
        if let TextureKey::Static(asset) = id {
            self.effect_gpu
                .builder
                .set_alpha(asset, width, height, rgba)?;
        }
        self.images.insert(
            id,
            GpuImage {
                _texture: texture,
                view,
                bind_group,
                bytes,
                size: (width, height),
                video_stamp: None,
            },
        );
        if let TextureKey::Static(asset) = id {
            if !self.asset_order.contains(&asset) {
                self.asset_order.push(asset);
            }
        }
        self.effect_gpu.invalidate();
        self.texture_bytes = self.texture_bytes - previous + bytes;
        Ok(())
    }
    pub fn synchronize_assets(&mut self, project: &Project, root: &Path) -> Result<()> {
        for asset in &project.assets {
            if self.images.contains_key(&TextureKey::Static(asset.id)) {
                continue;
            }
            let reader = ImageReader::open(root.join(&asset.path))?.with_guessed_format()?;
            let (width, height) = reader.into_dimensions()?;
            let bytes = u64::from(width) * u64::from(height) * 4;
            if width != asset.width
                || height != asset.height
            {
                return Err(RenderError::Invalid(
                    "asset metadata mismatch or texture budget exceeded".into(),
                ));
            }
            if bytes > self.effect_gpu.builder.source_texture_budget || self.texture_bytes + self.video_plane_bytes() + bytes > self.effect_gpu.builder.source_texture_budget {
                return Err(RenderError::budget(ResourceBudgetScope::SourceTextures,
                    self.texture_bytes + self.video_plane_bytes() + bytes, self.effect_gpu.builder.source_texture_budget,
                    "asset metadata mismatch or texture budget exceeded"));
            }
            let decoded = ImageReader::open(root.join(&asset.path))?
                .decode()?
                .into_rgba8();
            self.upload_image(asset.id, width, height, decoded.as_raw())?;
        }
        let remove: Vec<_> = self
            .images
            .keys()
            .copied()
            .filter(|id| match id {
                TextureKey::Static(id) => *id != 0 && !project.assets.iter().any(|a| a.id == *id),
                TextureKey::Video(_) | TextureKey::VideoBlendSource(..) => true,
                TextureKey::Vector(id) => !project
                    .layers
                    .iter()
                    .any(|l| l.id == *id && matches!(l.content, motion_model::Content::Vector { .. })),
                TextureKey::Mask(_) => true,
                TextureKey::EffectInput(_) => true,
            })
            .collect();
        for id in remove {
            if let TextureKey::Static(asset) = id {
                self.effect_gpu.builder.alpha_images.remove(&asset);
            }
            if let Some(image) = self.images.remove(&id) {
                self.texture_bytes = self.texture_bytes.saturating_sub(image.bytes);
            }
            if let TextureKey::Video(object) = id {
                if let Some(video) = &mut self.video_gpu {
                    video.remove(object);
                }
            }
            if let TextureKey::Static(asset) = id {
                self.asset_order.retain(|v| *v != asset);
            }
            self.effect_gpu.invalidate();
        }
        self.video_blend = None;
        Ok(())
    }
    /// Register the complete, stable asset table without decoding/uploading
    /// inactive images. Source files in a project are immutable; replacing a
    /// resource must use a new path (including when retaining its asset ID).
    pub fn configure_assets(&mut self, project: &Project, root: &Path) -> Result<()> {
        // Keep all fallible source resolution before any live cache/catalog
        // mutation: host command preparation relies on Err being non-destructive.
        let mut sources = HashMap::new();
        for asset in &project.assets {
            let source = crate::image_resources::Source::new(root, asset)?;
            sources.insert(asset.id, source);
        }
        let stale: Vec<_> = self.images.keys().filter_map(|key| match key {
            TextureKey::Static(id) if *id != 0 && self.image_sources.get(id) != sources.get(id) => Some(*id),
            _ => None,
        }).collect();
        for id in stale { self.remove_static_image(id); }
        self.image_decode.cancel();
        self.image_active.clear();
        self.image_prefetch.clear();
        self.image_prefetch_failed.clear();
        // Resource edits and project switches may reuse object/source IDs and
        // timestamps. Never carry a decoded video or vector across a new catalog.
        let dynamic: Vec<_> = self.images.keys().copied()
            .filter(|key| !matches!(key, TextureKey::Static(_))).collect();
        for key in dynamic {
            if let Some(image) = self.images.remove(&key) {
                self.texture_bytes = self.texture_bytes.saturating_sub(image.bytes);
                self.effect_gpu.invalidate();
            }
        }
        if let Some(video) = &mut self.video_gpu { video.clear(); }
        self.composition_images.clear();
        self.image_sources = sources;
        self.asset_order = std::iter::once(0).chain(project.assets.iter().map(|a| a.id)).collect();
        Ok(())
    }
    fn remove_static_image(&mut self, id: u64) {
        self.image_access.remove(&id);
        if let Some(image) = self.images.remove(&TextureKey::Static(id)) {
            self.texture_bytes = self.texture_bytes.saturating_sub(image.bytes);
            self.effect_gpu.builder.alpha_images.remove(&id);
            self.effect_gpu.invalidate();
        }
    }
    pub fn image_dimensions(&self, id: u64) -> Option<(u32, u32)> {
        self.images.get(&TextureKey::Static(id)).map(|i| i.size)
    }
    pub fn asset_ids(&self) -> &[u64] { &self.asset_order }
    pub fn image_idle_bytes(&self) -> u64 {
        self.image_access.keys().filter(|id| !self.image_active.contains(id))
            .filter_map(|id| self.images.get(&TextureKey::Static(*id))).map(|i| i.bytes).sum()
    }
    pub fn set_image_prefetch(&mut self, assets: Vec<u64>) { self.image_prefetch = assets; }
    /// Idle textures are expendable, and share (rather than extend) the source
    /// texture budget with videos, nested compositions and plugin resources.
    fn trim_image_cache(&mut self, additional: u64) {
        self.trim_image_cache_except(additional, None, 0);
    }
    fn check_texture_accounting(&self) {
        use std::sync::atomic::Ordering;
        // This is live residency. video_upload_bytes is cumulative traffic and
        // must not be compared with resident textures or decoder planes.
        let measured: u64 = self.images.values().map(|image| image.bytes).sum();
        if measured == self.texture_bytes {
            TEXTURE_ACCOUNTING_MISMATCHES.store(0, Ordering::Relaxed);
        } else {
            let previous = TEXTURE_ACCOUNTING_MISMATCHES.fetch_update(Ordering::Relaxed, Ordering::Relaxed,
                |value| Some(value.saturating_add(1))).unwrap_or_else(|value| value);
            if previous % 60 == 0 {
                log::warn!("texture accounting mismatch site=renderer.trim_image_cache count={} booked={} measured={} video_planes={} video_upload_bytes={}",
                    previous.saturating_add(1), self.texture_bytes, measured, self.video_plane_bytes(), self.video_upload_bytes);
            }
        }
    }
    fn trim_image_cache_except(&mut self, additional: u64, replacing: Option<TextureKey>, retiring_bytes: u64) {
        let limit = if self.image_cache_enabled { crate::image_resources::IDLE_TEXTURE_BYTES } else { 0 };
        let mut idle = self.image_idle_bytes();
        let mut total = self.texture_bytes + self.video_plane_bytes() + self.effect_gpu.state.resource_bytes + additional - retiring_bytes;
        if idle <= limit && total <= self.effect_gpu.builder.source_texture_budget {
            self.check_texture_accounting();
            return;
        }
        let mut victims = std::mem::take(&mut self.image_trim_candidates);
        victims.extend(self.image_access.iter()
            .filter(|(id, _)| !self.image_active.contains(id) && replacing != Some(TextureKey::Static(**id)))
            .map(|(id, time)| (*time, *id)));
        victims.sort_unstable();
        for &(_, id) in &victims {
            if idle <= limit && total <= self.effect_gpu.builder.source_texture_budget { break; }
            let bytes = self.images.get(&TextureKey::Static(id)).map_or(0, |i| i.bytes);
            self.remove_static_image(id);
            idle -= bytes;
            total = total.saturating_sub(bytes);
        }
        // Retain CPU storage, never textures or stale candidate IDs. Large
        // working sets can still evict fully without pinning their peak scratch.
        if victims.capacity() <= MAX_IMAGE_TRIM_CANDIDATES {
            victims.clear();
            self.image_trim_candidates = victims;
        }
        self.check_texture_accounting();
    }
    fn touch_image(&mut self, id: u64) {
        self.image_clock = self.image_clock.saturating_add(1);
        self.image_access.insert(id, self.image_clock);
    }
    fn prepare_effect_images(&mut self) {
        let extra = self.effect_gpu.state.pending_resource_bytes(&self.effect_gpu.builder);
        self.trim_image_cache(extra);
    }
    /// Preview polls a single bounded decode worker. Full capture/export uses
    /// synchronous preparation on its output worker, always at source size.
    pub fn prepare_scene_assets(
        &mut self,
        scene: &Scene,
        resolution: crate::image_resources::Resolution,
        asynchronous: bool,
    ) -> Result<bool> {
        use crate::image_resources::{decode_with_budget, scene_assets, Resolution};
        let decode_budget = self.effect_gpu.builder.decoded_image_budget;
        let wanted = scene_assets(scene);
        let mut required = 4u64;
        for id in &wanted {
            let source = self.image_sources.get(id)
                .ok_or_else(|| RenderError::Invalid(format!("image asset {id} is not registered")))?;
            let (w, h) = resolution.dimensions(source.width, source.height);
            if w > self.device.limits().max_texture_dimension_2d || h > self.device.limits().max_texture_dimension_2d {
                return Err(RenderError::Resource {
                    rejection: ResourceRejection::TextureDimensions { width: w, height: h, max_dimension: self.device.limits().max_texture_dimension_2d },
                    message: format!("image {id} exceeds device texture dimensions"),
                });
            }
            required += u64::from(w) * u64::from(h) * 4;
        }
        if required > self.effect_gpu.builder.source_texture_budget {
            return Err(RenderError::budget(ResourceBudgetScope::ActiveImages, required, self.effect_gpu.builder.source_texture_budget,
                "active image working set exceeds configured source texture budget; full output requires original resolution"));
        }
        self.image_cache_enabled = matches!(resolution, Resolution::Preview(_));
        for id in wanted.difference(&self.image_active) {
            if self.image_access.contains_key(id) && self.images.get(&TextureKey::Static(*id))
                .is_some_and(|i| resolution.dimensions(self.image_sources[id].width, self.image_sources[id].height) == i.size) {
                self.image_memory_cache_hits += 1;
            }
        }
        self.image_active = wanted.clone();
        for id in &wanted { if self.images.contains_key(&TextureKey::Static(*id)) { self.touch_image(*id); } }
        // Wrong-resolution images cannot survive a quality switch. Idle preview
        // images otherwise stay resident until LRU or resource pressure evicts.
        let stale: Vec<_> = self.images.keys().filter_map(|key| match key {
            TextureKey::Static(id) if *id != 0 && (self.image_sources.get(id)
                .is_none_or(|s| resolution.dimensions(s.width, s.height) != self.images[key].size)) => Some(*id),
            _ => None,
        }).collect();
        for id in stale { self.remove_static_image(id); }
        self.trim_image_cache(0);
        let demand_missing = wanted.iter().any(|id| !self.images.contains_key(&TextureKey::Static(*id)));
        let allowed = crate::image_resources::allowed_assets(&wanted, &self.image_prefetch,
            self.image_cache_enabled && asynchronous && !demand_missing);
        self.image_decode.cancel_unwanted_with_budget(&allowed, resolution, decode_budget);
        if let Some((source, mode, speculative, result)) = self.image_decode.poll() {
            if mode == resolution && allowed.contains(&source.id) && self.image_sources.get(&source.id) == Some(&source)
                && !self.images.contains_key(&TextureKey::Static(source.id)) {
                match result {
                Ok(pixels) => {
                    PREFETCH_FAILURES.success();
                    // Prefetch must never evict useful recent images or consume
                    // resources needed by an already active video/effect.
                    let cost = pixels.rgba.len() as u64;
                    if !wanted.contains(&source.id) && (cost + self.image_idle_bytes() > crate::image_resources::IDLE_TEXTURE_BYTES
                        || self.texture_bytes + self.video_plane_bytes() + self.effect_gpu.state.resource_bytes + cost > self.effect_gpu.builder.source_texture_budget) { IMAGE_PENDING.success(); return Ok(true); }
                self.upload_pixels(TextureKey::Static(source.id), pixels.width, pixels.height, &pixels.rgba, false)?;
                self.image_decodes += u64::from(!pixels.cached);
                self.image_proxy_cache_hits += u64::from(pixels.cached);
                self.image_upload_bytes += pixels.rgba.len() as u64;
                self.touch_image(source.id);
                }
                Err(crate::image_resources::Error::Cancelled) => {}
                Err(error) if !speculative => {
                    let message = format!("image {}: {error}", source.id);
                    return Err(RenderError::from(error).with_diagnostic(message));
                },
                Err(error) => {
                    PREFETCH_FAILURES.failure("renderer.image_prefetch", format_args!("source_id={} error={error}", source.id));
                    self.image_prefetch_failed.insert(source.id);
                }
                }
            }
        }
        drop(allowed);
        for id in wanted {
            if self.images.contains_key(&TextureKey::Static(id)) { continue; }
            let source = self.image_sources[&id].clone();
            if asynchronous {
                if !self.image_decode.busy() {
                    self.image_decode.start_with_budget(source, resolution, false, decode_budget)?;
                }
                IMAGE_PENDING.failure("renderer.prepare_scene_assets", format_args!(
                    "source_id={} prefetch_failed={} decoder_busy={}", id,
                    self.image_prefetch_failed.contains(&id), self.image_decode.busy()));
                return Ok(false);
            }
            let pixels = decode_with_budget(&source, resolution, decode_budget)
                .map_err(|error| {
                    let message = format!("image {id}: {error}");
                    RenderError::from(error).with_diagnostic(message)
                })?;
            self.upload_pixels(TextureKey::Static(id), pixels.width, pixels.height, &pixels.rgba, false)?;
            self.image_decodes += u64::from(!pixels.cached);
            self.image_proxy_cache_hits += u64::from(pixels.cached);
            self.image_upload_bytes += pixels.rgba.len() as u64;
            self.touch_image(id);
            PREFETCH_FAILURES.success();
        }
        IMAGE_PENDING.success();
        Ok(true)
    }
    /// Call after active image/video uploads. Speculation never precedes demand
    /// preparation, and at most one cancellable decode allocation exists.
    pub fn prefetch_scene_assets(&mut self, resolution: crate::image_resources::Resolution) -> Result<()> {
        if !self.image_cache_enabled || self.image_decode.busy() { return Ok(()); }
        for id in self.image_prefetch.clone().into_iter().filter(|id| !self.image_active.contains(id))
            .take(crate::image_resources::MAX_PREFETCH_IMAGES) {
            if self.images.contains_key(&TextureKey::Static(id)) { continue; }
            if self.image_prefetch_failed.contains(&id) { continue; }
            let Some(source) = self.image_sources.get(&id) else { continue; };
            let (w, h) = resolution.dimensions(source.width, source.height);
            let bytes = u64::from(w) * u64::from(h) * 4;
            if w > self.device.limits().max_texture_dimension_2d || h > self.device.limits().max_texture_dimension_2d
                || bytes + self.image_idle_bytes() > crate::image_resources::IDLE_TEXTURE_BYTES
                || self.texture_bytes + self.video_plane_bytes() + self.effect_gpu.state.resource_bytes + bytes > self.effect_gpu.builder.source_texture_budget { continue; }
            self.image_decode.start_with_budget(source.clone(), resolution, true, self.effect_gpu.builder.decoded_image_budget)?;
            self.image_prefetches += 1;
            break;
        }
        Ok(())
    }
    pub fn clear_assets(&mut self) {
        self.video_blend = None;
        self.layer_gpu.release();
        if let Some(gpu)=&mut self.compositing_gpu{gpu.release();}
        self.image_decode.cancel();
        self.image_active.clear();
        self.image_access.clear();
        self.image_trim_candidates = Vec::new();
        self.image_prefetch.clear();
        self.image_prefetch_failed.clear();
        self.mask_gpu.clear();
        self.composition_images.clear();
        if let Some(video) = &mut self.video_gpu {
            video.clear();
        }
        self.effect_gpu.builder.alpha_images.clear();
        self.images.retain(|id, _| *id == TextureKey::Static(0));
        self.asset_order.retain(|id| *id == 0);
        self.effect_gpu.invalidate();
        self.texture_bytes = self
            .images
            .get(&TextureKey::Static(0))
            .map_or(0, |t| t.bytes);
    }
    /// New projects may reuse asset IDs from another directory. Load into a
    /// separate cache and keep the visible project's resources on failure.
    pub fn replace_assets(&mut self, project: &Project, root: &Path) -> Result<()> {
        let previous_video_gpu = self.video_gpu.take();
        let previous_video_blend = self.video_blend.take();
        let mut previous = std::mem::take(&mut self.images);
        let previous_alpha = std::mem::take(&mut self.effect_gpu.builder.alpha_images);
        let previous_bytes = self.texture_bytes;
        let previous_order = self.asset_order.clone();
        self.asset_order = vec![0];
        self.effect_gpu.invalidate();
        self.images.insert(
            TextureKey::Static(0),
            previous
                .remove(&TextureKey::Static(0))
                .expect("solid texture exists"),
        );
        self.texture_bytes = 4;
        if let Err(error) = self.synchronize_assets(project, root) {
            previous.insert(
                TextureKey::Static(0),
                self.images
                    .remove(&TextureKey::Static(0))
                    .expect("solid texture exists"),
            );
            self.images = previous;
            self.video_gpu = previous_video_gpu;
            self.video_blend = previous_video_blend;
            self.effect_gpu.builder.alpha_images = previous_alpha;
            self.texture_bytes = previous_bytes;
            self.asset_order = previous_order;
            self.effect_gpu.invalidate();
            return Err(error);
        }
        Ok(())
    }
    pub fn draw(
        &mut self,
        scene: &Scene,
        view: &wgpu::TextureView,
        width: u32,
        height: u32,
    ) -> Result<RenderStats> {
        self.draw_internal(scene,view,width,height,false,crate::gpu_commands::CommandStage::Composition)
    }
    fn draw_internal(&mut self,scene:&Scene,view:&wgpu::TextureView,width:u32,height:u32,preview:bool,stage:crate::gpu_commands::CommandStage)->Result<RenderStats> {
        let mut encoder = self
            .allocation_command_encoder_for(stage, &wgpu::CommandEncoderDescriptor {
                label: Some("Motion Studio frame"),
            })?;
        let mut stats = self.encode_internal(scene, view, width, height, &mut encoder, None, preview)?;
        let submitted = Instant::now();
        self.submit_allocated(encoder.finish(), |_| {})?;
        stats.cpu_prepare_us += submitted.elapsed().as_micros() as u64;
        self.check_health()?;
        Ok(stats)
    }
    pub fn encode(
        &mut self,
        scene: &Scene,
        view: &wgpu::TextureView,
        width: u32,
        height: u32,
        encoder: &mut wgpu::CommandEncoder,
        timestamps: Option<wgpu::RenderPassTimestampWrites<'_>>,
    ) -> Result<RenderStats> {
        self.encode_internal(scene, view, width, height, encoder, timestamps, false)
    }
    /// Interactive preview, with conservative 2D effect density. `encode`,
    /// `draw`, and `capture` retain their formal-output behavior.
    pub fn encode_preview(
        &mut self,
        scene: &Scene,
        view: &wgpu::TextureView,
        width: u32,
        height: u32,
        encoder: &mut wgpu::CommandEncoder,
        timestamps: Option<wgpu::RenderPassTimestampWrites<'_>>,
    ) -> Result<RenderStats> {
        self.encode_internal(scene, view, width, height, encoder, timestamps, true)
    }
    fn encode_internal(
        &mut self,
        scene: &Scene,
        view: &wgpu::TextureView,
        width: u32,
        height: u32,
        encoder: &mut wgpu::CommandEncoder,
        timestamps: Option<wgpu::RenderPassTimestampWrites<'_>>,
        preview: bool,
    ) -> Result<RenderStats> {
        self.snapshot_encodes.clear();
        self.allocation_budget.check()?;
        let (child_stats, child_diagnostics) = self.prepare_nested(scene, width, height, preview)?;
        let mut stats=self.encode_local(scene,view,width,height,encoder,timestamps,preview)?;
        stats.add(child_stats);self.effect_diagnostics.extend(child_diagnostics);Ok(stats)
    }
    fn check_resident_sources(&mut self) -> Result<()> {
        // A reduced budget also applies to already-resident sources. It must
        // not be bypassed by a cached plan or a no-op upload.
        self.trim_image_cache(0);
        let resident = self.texture_bytes + self.video_plane_bytes() + self.effect_gpu.state.resource_bytes;
        if resident > self.effect_gpu.builder.source_texture_budget {
            return Err(RenderError::budget(ResourceBudgetScope::SourceTextures, resident,
                self.effect_gpu.builder.source_texture_budget, "resident sources exceed source texture budget"));
        }
        Ok(())
    }
    fn prepare_nested(&mut self, scene: &Scene, width: u32, height: u32, preview: bool) -> Result<(RenderStats, Vec<String>)> {
        self.check_health()?;
        self.check_resident_sources()?;
        if !scene.nested.is_empty() && self.video_gpu.as_ref().is_some_and(|v| v.has_pending()) {
            return Err(RenderError::Invalid(
                "nested video rendering requires standalone conversion submissions".into(),
            ));
        }
        let mut child_stats=RenderStats::default();let mut child_diagnostics=Vec::new();
        for node in &scene.nested {
            let (w,h)=nested_size(scene,&node.scene,width,height);
            let key=TextureKey::Video(node.layer);
            if self.images.get(&key).is_none_or(|image|image.size!=(w,h)||image._texture.format()!=self.target_format) {
                let bytes=u64::from(w)*u64::from(h)*crate::image_formats::color_storage(self.effect_gpu.builder.precision()).bytes_per_pixel();
                let previous=self.images.get(&key).map_or(0,|image|image.bytes);
                self.trim_image_cache(bytes.saturating_sub(previous));
                if self.texture_bytes-previous+self.video_plane_bytes()+self.effect_gpu.state.resource_bytes+bytes>self.effect_gpu.builder.source_texture_budget {
                    return Err(RenderError::budget(ResourceBudgetScope::SourceTextures,
                        self.texture_bytes-previous+self.video_plane_bytes()+self.effect_gpu.state.resource_bytes+bytes,
                        self.effect_gpu.builder.source_texture_budget, format!("composition {}: nested textures exceed configured source texture budget",node.composition)));
                }
                let target=self.render_target_in(w,h,crate::TextureCategory::NestedCompositions)?;
                let group=self.device.create_bind_group(&wgpu::BindGroupDescriptor {
                    label:Some("Composition reference"),layout:&self.image_layout,
                    entries:&[wgpu::BindGroupEntry{binding:0,resource:wgpu::BindingResource::TextureView(&target.view)},
                        wgpu::BindGroupEntry{binding:1,resource:wgpu::BindingResource::Sampler(&self.sampler)}],
                });
                self.images.insert(key,GpuImage {_texture:target.texture,view:target.view.view,bind_group:group,bytes,size:(w,h),video_stamp:None});
                self.texture_bytes=self.texture_bytes-previous+bytes;
                self.composition_images.insert(node.layer);
                self.effect_gpu.invalidate();
            }
            let view=self.images[&key].view.clone();
            let stats=self.draw_internal(&node.scene,&view,w,h,preview,crate::gpu_commands::CommandStage::NestedComposition).map_err(|e| {
                let message=node.scene.diagnostic(&e.to_string());
                e.with_diagnostic(message)
            })?;
            child_stats.add(stats);child_diagnostics.extend(self.effect_diagnostics.iter().map(|v|node.scene.diagnostic(v)));
        }
        Ok((child_stats, child_diagnostics))
    }
    fn encode_local(&mut self,scene:&Scene,view:&wgpu::TextureView,width:u32,height:u32,encoder:&mut wgpu::CommandEncoder,timestamps:Option<wgpu::RenderPassTimestampWrites<'_>>,preview:bool)->Result<RenderStats> {
        self.snapshot_encodes.clear();
        if width == 0 || height == 0 || scene.layers.len() > MAX_LAYERS {
            return Err(RenderError::Invalid(
                "invalid render target or layer count".into(),
            ));
        }
        let started = Instant::now();
        if scene.effects.iter().any(|e| e.enabled) || scene.layers.iter().any(|l|!l.masks.is_empty())
            || scene
                .layers
                .iter()
                .any(|l| l.vector.is_some() || l.adjustment || l.track_matte.is_some()
                    || l.blend != motion_model::compositing::LayerBlend::default() || !l.composite_visible)
        {
            return self.encode_effects(scene, Some(view), width, height, encoder, timestamps, preview, None, false);
        }
        // Direct drawing consumes neither mask coverage nor effect-input snapshots.
        // Release both without discarding reusable compositing pipelines.
        let obsolete_inputs:Vec<_>=self.images.keys().copied()
            .filter(|k|matches!(k,TextureKey::Mask(_) | TextureKey::EffectInput(_))).collect();
        if !obsolete_inputs.is_empty() {
            for key in obsolete_inputs {
                if let Some(image) = self.images.remove(&key) {
                    self.texture_bytes = self.texture_bytes.saturating_sub(image.bytes);
                }
            }
            self.mask_gpu.clear();self.effect_gpu.state.invalidate();
        }
        self.effect_diagnostics.clear();
        if let Some(gpu) = &mut self.compositing_gpu { gpu.release(); }
        let vector_other = self.effect_gpu.state.resource_bytes + self.video_plane_bytes();
        if self.layer_gpu.prepare_vectors(
            &self.device,
            encoder,
            &self.image_layout,
            &self.sampler,
            scene,
            &[],
            &mut self.images,
            &mut self.texture_bytes,
            vector_other,
            self.effect_gpu.builder.source_texture_budget,
        )? {
            self.effect_gpu.state.invalidate();
        }
        if self.composition_images.is_empty() { self.effect_gpu.state.release_scratch(); }
        self.layer_gpu.prepare_accumulators(
            &self.device,
            &self.image_layout,
            &self.sampler,
            self.target_format,
            None,
        )?;
        let [_, _, viewport_width, viewport_height] = crate::fit_viewport(
            [0., 0., width as f32, height as f32], [scene.width, scene.height]);
        self.compositor.set_coverage_viewport(Some([viewport_width, viewport_height]));
        self.compositor
            .prepare(scene)
            .map_err(|e| RenderError::Invalid(e.to_string()))?;
        self.geometry_upload.clear();
        self.geometry_upload
            .extend(self.compositor.vertices.iter().map(|v| GeometryVertex {
                position: v.position,
                uv: v.uv,
            }));
        if !self.geometry_upload.is_empty() {
            self.allocation_uploads.track(Some(self.vertex_buffer.allocation()))?;
            self.queue.write_buffer(
                &self.vertex_buffer,
                0,
                bytemuck::cast_slice(&self.geometry_upload),
            );
        }
        for (index, layer) in scene.layers.iter().enumerate() {
            let asset = texture_key(layer);
            if !self.images.contains_key(&asset) {
                return Err(RenderError::Invalid(format!("draw image is not uploaded")));
            }
            let mut color = layer.color;
            for c in &mut color[..3] {
                *c = srgb_to_linear(*c);
            }
            let uniform = DrawUniform {
                mvp: layer.view_projection.to_cols_array_2d(),
                color,
                extent_opacity: [layer.size[0], layer.size[1], layer.opacity, 0.0],
                uv_scale: [1.0, 1.0, 0.0, 0.0],
                screen_uv: crate::plane_coordinates::screen_map(self.compositor.uv_maps[index],
                    crate::fit_viewport([0., 0., width as f32, height as f32], [scene.width, scene.height]), layer.id)?,
            };
            let offset = index * self.uniform_stride;
            self.upload[offset..offset + DRAW_SIZE as usize]
                .copy_from_slice(bytemuck::bytes_of(&uniform));
        }
        let upload_bytes = scene.layers.len() * self.uniform_stride;
        if upload_bytes > 0 {
            self.allocation_uploads.track(Some(self.uniform_buffer.allocation()))?;
            self.queue
                .write_buffer(&self.uniform_buffer, 0, &self.upload[..upload_bytes]);
        }
        let alpha = scene.background[3];
        let clear = wgpu::Color {
            r: (srgb_to_linear(scene.background[0]) * alpha) as f64,
            g: (srgb_to_linear(scene.background[1]) * alpha) as f64,
            b: (srgb_to_linear(scene.background[2]) * alpha) as f64,
            a: alpha as f64,
        };
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                multiview_mask: None,
                label: Some("Motion Studio composition"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    depth_slice: None,
                    view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(clear),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: timestamps,
                occlusion_query_set: None,
            });
            let [vx, vy, vw, vh] = crate::fit_viewport(
                [0., 0., width as f32, height as f32], [scene.width, scene.height]);
            pass.set_viewport(
                vx,
                vy,
                vw,
                vh,
                0.0,
                1.0,
            );
            pass.set_pipeline(&self.pipeline);
            pass.set_vertex_buffer(0, self.vertex_buffer.slice(..));
            for batch in &self.compositor.batches {
                let index = batch.layer;
                let layer = &scene.layers[index];
                pass.set_bind_group(
                    0,
                    &self.uniform_group,
                    &[(index * self.uniform_stride) as u32],
                );
                pass.set_bind_group(1, &self.images[&texture_key(layer)].bind_group, &[]);
                pass.draw(batch.vertices.clone(), 0..1);
            }
        }
        Ok(RenderStats {
            cpu_prepare_us: started.elapsed().as_micros() as u64,
            draw_calls: self.compositor.batches.len() as u32,
            texture_bytes: self.texture_bytes + self.video_plane_bytes(),
            parameter_upload_bytes: (upload_bytes
                + self.geometry_upload.len() * std::mem::size_of::<GeometryVertex>())
                as u64,
            parameter_resource_upload_bytes: 0,
            instance_upload_bytes: 0,
            particles_alive: 0,
            particles_visible: 0,
            particles_culled: 0,
        })
    }
    fn prepare_input_snapshots(&mut self, input_order: &[usize])->Result<()> {
        let frame=&self.effect_gpu.builder.frame;
        let storage=crate::image_formats::color_storage(frame.precision);
        let format=crate::image_formats::native_format(storage);
        let pixel_bytes=storage.bytes_per_pixel();
        let specs=input_order.iter().copied().map(|i| {
            let draw=&frame.draws[i];let pass=&frame.passes[draw.pass_end-1];(TextureKey::EffectInput(draw.layer),draw.layer,pass.width,pass.height)
        }).collect::<Vec<_>>();
        let stale=self.images.keys().copied().filter(|key|matches!(key,TextureKey::EffectInput(_))&&!specs.iter().any(|v|v.0==*key)).collect::<Vec<_>>();
        for key in stale {
            if let Some(image) = self.images.remove(&key) {
                self.texture_bytes = self.texture_bytes.saturating_sub(image.bytes);
                self.effect_gpu.invalidate();
            }
        }
        let needed=specs.iter().filter(|(key,_,w,h)|self.images.get(key).is_none_or(|image|image.size!=(*w,*h)||image._texture.format()!=format))
            .map(|(_,_,w,h)|u64::from(*w)*u64::from(*h)*pixel_bytes).sum();
        self.trim_image_cache(needed);
        for (key,layer,width,height) in specs {
            if self.images.get(&key).is_some_and(|image|image.size==(width,height)&&image._texture.format()==format){continue;}
            let bytes=u64::from(width)*u64::from(height)*pixel_bytes;
            // Replacement must keep the old snapshot alive until allocation and
            // binding creation succeed. Admit the peak, not the final cache size.
            let required=self.texture_bytes.saturating_add(self.video_plane_bytes())
                .saturating_add(self.effect_gpu.state.resource_bytes).saturating_add(bytes);
            if required>self.effect_gpu.builder.source_texture_budget {
                return Err(RenderError::budget(ResourceBudgetScope::SourceTextures,
                    required,
                    self.effect_gpu.builder.source_texture_budget,
                    format!("input snapshot layer={layer} size={width}x{height} phase=source_budget: effect image snapshots exceed source texture budget")));
            }
            let texture=self.device.create_admitted_texture(&wgpu::TextureDescriptor {label:Some("same-frame effect image input"),size:wgpu::Extent3d{width,height,depth_or_array_layers:1},
                mip_level_count:1,sample_count:1,dimension:wgpu::TextureDimension::D2,format,usage:wgpu::TextureUsages::TEXTURE_BINDING|wgpu::TextureUsages::COPY_DST|wgpu::TextureUsages::COPY_SRC,view_formats:&[]}, &self.allocation_budget, crate::TextureCategory::EffectInputSnapshots)
                .map_err(|error| RenderError::Context {
                    message: format!("input snapshot layer={layer} size={width}x{height} phase=allocate: {error}"),
                    cause: Box::new(error),
                })?;
            let view=texture.create_view(&Default::default());
            let bind_group=self.device.create_bind_group(&wgpu::BindGroupDescriptor {label:None,layout:&self.image_layout,entries:&[
                wgpu::BindGroupEntry{binding:0,resource:wgpu::BindingResource::TextureView(&view)},wgpu::BindGroupEntry{binding:1,resource:wgpu::BindingResource::Sampler(&self.sampler)}]});
            if let Some(old)=self.images.insert(key,GpuImage{_texture:texture,view,bind_group,bytes,size:(width,height),video_stamp:None}){self.texture_bytes=self.texture_bytes.saturating_sub(old.bytes);}
            self.texture_bytes+=bytes;self.effect_gpu.invalidate();
        }
        Ok(())
    }
    fn encode_effects(
        &mut self,
        scene: &Scene,
        view: Option<&wgpu::TextureView>,
        width: u32,
        height: u32,
        encoder: &mut wgpu::CommandEncoder,
        timestamps: Option<wgpu::RenderPassTimestampWrites<'_>>,
        preview: bool,
        mut materialize: Option<(u64, &mut Option<LayerRaster>)>,
        prepare_only: bool,
    ) -> Result<RenderStats> {
        let started = Instant::now();
        self.effect_gpu.builder.enable_plane_coverage();
        self.snapshot_encodes.clear();
        let image_input_order = loop {
            if let Some((receiver, _)) = &materialize {
                self.effect_gpu.builder.build_materialized_checked(scene, &self.asset_order, width, height, *receiver, preview)
            } else if prepare_only {
                self.effect_gpu.builder.build_exposure_context_checked(scene, &self.asset_order, width, height, preview)
            } else if self.preview_resource_guard {
                self.effect_gpu.builder.build_preview_guarded(scene, &self.asset_order, width, height, preview)
            } else if preview {
                self.effect_gpu.builder.build_preview(scene, &self.asset_order, width, height)
            } else {
                self.effect_gpu.builder.build(scene, &self.asset_order, width, height, false)
            }
            ?;
            self.prepare_effect_images();
            let targets: Vec<_> = materialize.as_ref().map(|(id, _)| *id).into_iter().collect();
            let input_order = self.effect_gpu.builder.snapshot_execution(scene, &targets)?.draw_order().to_vec();
            self.prepare_input_snapshots(&input_order).map_err(|error| RenderError::Context {
                message: format!("effects frame={} phase=input_snapshots: {error}", scene.frame),
                cause: Box::new(error),
            })?;
            match self.effect_gpu.state.prepare(
                &self.device,
                &self.queue,
                &self.image_layout,
                &self.effect_gpu.builder,
                scene,
                self.texture_bytes + self.video_plane_bytes(),
            self.effect_gpu.builder.source_texture_budget,
            ) {
                Ok(()) => break input_order,
                Err(error) => {
                    if let Some((program, message)) = self.effect_gpu.state.failed_program.take() {
                        self.effect_gpu
                            .builder
                            .program_errors
                            .insert(program, message);
                        if !self.preview_resource_guard && materialize.is_none() && !prepare_only { continue; }
                    }
                    self.effect_diagnostics = vec![error.to_string()];
                    return Err(error);
                }
            }
        };
        let vector_bytes = self.layer_gpu.pending_vector_bytes(scene, &self.effect_gpu.builder.frame.vectors, &self.images);
        let mask_bytes = self.effect_gpu.builder.frame.masks
            .chunk_by(|a,b|a.layer==b.layer)
            .map(|group| {
                let first=&group[0];
                let cost=u64::from(first.width)*u64::from(first.height);
                let resident=self.images.get(&TextureKey::Mask(scene.layers[first.layer].id)).map_or(0,|image|image.bytes);
                cost.saturating_sub(resident)
            }).sum::<u64>();
        self.trim_image_cache(vector_bytes+mask_bytes);
        let mask_other=self.video_plane_bytes()+self.effect_gpu.state.resource_bytes;
        let frame = &self.effect_gpu.builder.frame;
        let masks_changed=self.mask_gpu.prepare(&self.device,&self.queue,encoder,&self.image_layout,scene,&frame.masks,
            &mut self.images,&mut self.texture_bytes,mask_other,self.effect_gpu.builder.source_texture_budget)?;
        if masks_changed {
            self.effect_gpu.state.invalidate();
        }
        let vector_other = self.effect_gpu.state.resource_bytes + self.video_plane_bytes();
        let vectors_changed = self.layer_gpu.prepare_vectors(
            &self.device,
            encoder,
            &self.image_layout,
            &self.sampler,
            scene,
            &frame.vectors,
            &mut self.images,
            &mut self.texture_bytes,
            vector_other,
            self.effect_gpu.builder.source_texture_budget,
        )?;
        let has_adjustment = materialize.is_none() && frame
            .draws
            .iter()
            .any(|d| d.words[31] == 2. && d.pass_start < d.pass_end);
        let has_transfer = materialize.is_none() && frame.compositing.iter().any(|c| c.visible && (c.blend != 0 || c.space != 0));
        let has_accumulator = has_adjustment || has_transfer;
        let has_compositing = has_transfer || frame.compositing.iter().any(|c| c.mode != 0);
        let render_scale = (width as f32 / scene.width as f32)
            .min(height as f32 / scene.height as f32)
            .min(1.)
            .max(0.001);
        let composition_size = [
            (scene.width as f32 * render_scale).ceil() as u32,
            (scene.height as f32 * render_scale).ceil() as u32,
        ];
        let accumulators_changed = self.layer_gpu.prepare_accumulators(
            &self.device,
            &self.image_layout,
            &self.sampler,
            self.target_format,
            has_accumulator.then_some(composition_size),
        ).map_err(|error| RenderError::Context {
            message: format!("compositing frame={} phase=accumulators: {error}", scene.frame),
            cause: Box::new(error),
        })?;
        if has_compositing {
            let source_bytes=self.texture_bytes + self.video_plane_bytes() + self.effect_gpu.state.resource_bytes;
            let needed: Vec<_> = frame.compositing.iter().filter(|c| c.matte >= 0)
                .map(|c| (frame.draws[c.matte as usize].layer, c.mode >= 3)).collect();
            self.ensure_compositing_gpu(scene.frame, "initialize")?;
            let gpu = self.compositing_gpu.as_mut().ok_or_else(||
                RenderError::Invalid("compositing initialization did not publish resources".into()))?;
            let changed = gpu.prepare_targets(&self.device, &self.image_layout, &self.sampler,
                composition_size, &needed, source_bytes, self.effect_gpu.builder.source_texture_budget,
                has_transfer).map_err(|error| RenderError::Context {
                    message: format!("compositing frame={} phase=targets: {error}", scene.frame),
                    cause: Box::new(error),
                })?;
            gpu.prepare_blend_inputs(&self.device, &self.queue, &self.sampler, &self.layer_gpu.accumulators,
                &scene.layers, changed || accumulators_changed)?;
        } else if let Some(gpu) = &mut self.compositing_gpu { gpu.release(); }
        if masks_changed || vectors_changed || accumulators_changed {
            self.effect_gpu.state.invalidate();
            self.effect_gpu.state.prepare(
                &self.device,
                &self.queue,
                &self.image_layout,
                &self.effect_gpu.builder,
                scene,
                self.texture_bytes + self.video_plane_bytes(),
            self.effect_gpu.builder.source_texture_budget,
            )?;
        }
        let frame = &self.effect_gpu.builder.frame;
        self.geometry_upload.clear();
        self.geometry_upload
            .extend(frame.vertices.iter().map(|v| GeometryVertex {
                position: v.position,
                uv: v.uv,
            }));
        if !self.geometry_upload.is_empty() {
            self.allocation_uploads.track(Some(self.vertex_buffer.allocation()))?;
            self.queue.write_buffer(
                &self.vertex_buffer,
                0,
                bytemuck::cast_slice(&self.geometry_upload),
            );
        }
        self.effect_diagnostics.clone_from(&frame.diagnostics);
        let viewport = if has_accumulator {composition_size.map(|v|v as f32)} else {
            let [_, _, w, h] = crate::fit_viewport(
                [0., 0., width as f32, height as f32], [scene.width, scene.height]);
            [w, h]
        };
        let viewport_origin=if has_accumulator {[0.;2]}else{[(width as f32-viewport[0])*0.5,(height as f32-viewport[1])*0.5]};
        for (i, draw) in frame.draws.iter().enumerate() {
            let w = &draw.words;
            let c=frame.compositing[i];
            let flags=u32::from(w[27]<0.&&!scene.layers[i].masks.is_empty())
                +2*u32::from(c.mode!=0)+4*u32::from(c.mode==2||c.mode==4);
            let uniform = DrawUniform {
                mvp: std::array::from_fn(|c| std::array::from_fn(|r| w[c * 4 + r])),
                color: w[16..20].try_into().unwrap(),
                extent_opacity: if has_compositing&&!scene.layers[i].adjustment {[viewport_origin[0],viewport_origin[1],w[22],flags as f32]}else{[w[20],w[21],w[22],0.]},
                uv_scale: [w[25], w[26], if has_compositing&&!scene.layers[i].adjustment{viewport[0]}else{scene.width as f32}, if has_compositing&&!scene.layers[i].adjustment{viewport[1]}else{scene.height as f32}],
                screen_uv: crate::plane_coordinates::screen_map(frame.uv_maps[i],
                    [viewport_origin[0], viewport_origin[1], viewport[0], viewport[1]], draw.layer)?,
            };
            self.upload[i * self.uniform_stride..i * self.uniform_stride + DRAW_SIZE as usize]
                .copy_from_slice(bytemuck::bytes_of(&uniform));
        }
        let bytes = frame.draws.len() * self.uniform_stride;
        if bytes > 0 {
            self.allocation_uploads.track(Some(self.uniform_buffer.allocation()))?;
            self.queue
                .write_buffer(&self.uniform_buffer, 0, &self.upload[..bytes]);
        }
        let alpha = scene.background[3];
        let clear = wgpu::Color {
            r: (srgb_to_linear(scene.background[0]) * alpha) as f64,
            g: (srgb_to_linear(scene.background[1]) * alpha) as f64,
            b: (srgb_to_linear(scene.background[2]) * alpha) as f64,
            a: alpha as f64,
        };
        if let Some(view) = view {
            let writes = timestamps
                .as_ref()
                .map(|t| wgpu::RenderPassTimestampWrites {
                    query_set: t.query_set,
                    beginning_of_pass_write_index: t.beginning_of_pass_write_index,
                    end_of_pass_write_index: None,
                });
            let _pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                multiview_mask: None,
                label: Some("effect composition clear"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    depth_slice: None,
                    view: if has_accumulator {
                        &self.layer_gpu.accumulators[0].view
                    } else {
                        view
                    },
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(if has_accumulator {
                            wgpu::Color::TRANSPARENT
                        } else {
                            clear
                        }),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: writes,
                occlusion_query_set: None,
            });
        }
        let mut materialized = None;
        let mut executed_passes = 0;
        let mut composition_draws = 0;
        let mut accumulator = 0;
        // Preserve each referenced source before another draw reuses scratch.
        // This is GPU-only and independent of the composition's stacking order.
        for i in image_input_order {
            let draw=&frame.draws[i];
            for p in draw.pass_start..draw.pass_end {
                self.effect_gpu.state.encode_pass(p,frame,&self.asset_order,
                    Some(texture_key(&scene.layers[i])),None,&self.images,&self.device,&self.queue,encoder)?;
                executed_passes+=1;
            }
            let output=&frame.passes[draw.pass_end-1];
            encoder.copy_texture_to_texture(
                wgpu::TexelCopyTextureInfo{texture:&self.effect_gpu.state.output(frame,i)?.texture,mip_level:0,origin:wgpu::Origin3d::ZERO,aspect:wgpu::TextureAspect::All},
                wgpu::TexelCopyTextureInfo{texture:&self.images[&TextureKey::EffectInput(draw.layer)]._texture,mip_level:0,origin:wgpu::Origin3d::ZERO,aspect:wgpu::TextureAspect::All},
                wgpu::Extent3d{width:output.width,height:output.height,depth_or_array_layers:1});
            self.snapshot_encodes.push(crate::effect_plan::SnapshotEncode {
                layer: draw.layer,
                encoded_passes: draw.pass_end - draw.pass_start,
            });
        }
        composition_draws += self.encode_track_mattes(encoder,composition_size)?;
        if materialize.is_some() || prepare_only {
            if let Some((receiver, output)) = materialize.take() {
                *output = Some(self.copy_layer_raster(scene, receiver, [width, height], composition_size, preview, encoder)?);
            }
            let stats = RenderStats {
                cpu_prepare_us: started.elapsed().as_micros() as u64,
                draw_calls: (composition_draws + executed_passes) as u32,
                texture_bytes: self.texture_bytes + self.video_plane_bytes() + self.effect_gpu.state.bytes()
                    + self.layer_gpu.bytes() + self.compositing_gpu.as_ref().map_or(0, |g| g.bytes()) + self.exposure_texture_bytes(),
                parameter_upload_bytes: (bytes + executed_passes * motion_effects::shader::UNIFORM_BYTES + frame.vertices.len() * 20) as u64,
                instance_upload_bytes: (frame.sprites.len() * 48) as u64,
                particles_alive: frame.generator_stats.alive,
                particles_visible: frame.generator_stats.visible,
                particles_culled: frame.generator_stats.culled,
                parameter_resource_upload_bytes: std::mem::take(&mut self.effect_gpu.state.parameter_resource_upload_bytes),
            };
            return Ok(stats);
        }
        let view = view.ok_or_else(|| RenderError::Invalid("missing composition render destination".into()))?;
        for (batch_index, batch) in frame.batches.iter().enumerate() {
            let i = batch.layer;
            let draw = &frame.draws[i];
            if !frame.compositing[i].visible {continue;}
            if materialized!=Some(i) {
                if let Some(cached)=self.images.get(&TextureKey::EffectInput(draw.layer)) {
                    restore_effect_snapshot(encoder, &cached._texture, cached.size,
                        self.effect_gpu.state.output(frame,i)?);
                    materialized=Some(i);
                }
            }
            for p in draw.pass_start..draw.pass_end {
                if materialized == Some(i) {
                    break;
                }
                self.effect_gpu.state.encode_pass(
                    p,
                    frame,
                    &self.asset_order,
                    (scene.layers[i].video.is_some() || scene.layers[i].vector.is_some() || scene.layers[i].composition)
                        .then(|| texture_key(&scene.layers[i])),
                    (scene.layers[i].adjustment && has_adjustment)
                        .then(|| &self.layer_gpu.accumulators[accumulator].view),
                    &self.images,
                    &self.device,
                    &self.queue,
                    encoder,
                )?;
                executed_passes += 1;
            }
            materialized = Some(i);
            if scene.layers[i].adjustment {
                if draw.pass_start == draw.pass_end || draw.words[22] <= 0. {
                    continue;
                }
                let next = self.encode_adjusted_backdrop(encoder, i, i, accumulator)?;
                composition_draws += 1;
                accumulator = next;
                continue;
            }
            let transfer=frame.compositing[i].blend!=0||frame.compositing[i].space!=0;
            let writes = if !has_accumulator && batch_index + 1 == frame.batches.len() {
                timestamps
                    .as_ref()
                    .map(|t| wgpu::RenderPassTimestampWrites {
                        query_set: t.query_set,
                        beginning_of_pass_write_index: None,
                        end_of_pass_write_index: t.end_of_pass_write_index,
                    })
            } else {
                None
            };
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                multiview_mask: None,
                label: Some("effect composition layer"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    depth_slice: None,
                    view: if transfer {
                        &self.compositing_gpu.as_ref().unwrap().source.as_ref().unwrap().view
                    } else if has_accumulator {
                        &self.layer_gpu.accumulators[accumulator].view
                    } else {
                        view
                    },
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: if transfer{wgpu::LoadOp::Clear(wgpu::Color::TRANSPARENT)}else{wgpu::LoadOp::Load},
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: writes,
                occlusion_query_set: None,
            });
            let (vw, vh) = if has_accumulator {
                (composition_size[0] as f32, composition_size[1] as f32)
            } else {
                (viewport[0], viewport[1])
            };
            pass.set_viewport(
                if has_accumulator {
                    0.
                } else {
                    (width as f32 - vw) / 2.0
                },
                if has_accumulator {
                    0.
                } else {
                    (height as f32 - vh) / 2.0
                },
                vw,
                vh,
                0.0,
                1.0,
            );
            let masked=draw.words[27]<0. && !scene.layers[i].masks.is_empty();
            pass.set_pipeline(if has_compositing {
                let gpu=self.compositing_gpu.as_ref().unwrap();
                if draw.words[23]>0.5&&!transfer{&gpu.additive}else{&gpu.normal}
            } else if masked {&self.masked_pipeline} else if draw.words[23] > 0.5 {
                &self.additive_pipeline
            } else {
                &self.pipeline
            });
            pass.set_vertex_buffer(0, self.vertex_buffer.slice(..));
            pass.set_bind_group(0, &self.uniform_group, &[(i * self.uniform_stride) as u32]);
            let group = if draw.words[27] >= 0.0 {
                &self.effect_gpu.state.output(frame,i)?.composite
            } else {
                &self.images[&texture_key(&scene.layers[i])].bind_group
            };
            pass.set_bind_group(1, group, &[]);
            if has_compositing {
                let gpu=self.compositing_gpu.as_ref().unwrap();let c=frame.compositing[i];
                pass.set_bind_group(2,if masked{&self.images[&TextureKey::Mask(scene.layers[i].id)].bind_group}else{&gpu.zero.composite},&[]);
                pass.set_bind_group(3,if c.matte>=0{&gpu.mattes[&(frame.draws[c.matte as usize].layer,c.mode>=3)].composite}else{&gpu.zero.composite},&[]);
            }else if masked {pass.set_bind_group(2,&self.images[&TextureKey::Mask(scene.layers[i].id)].bind_group,&[]);}
            pass.draw(batch.vertices.clone(), 0..1);
            drop(pass);
            composition_draws += 1;
            if transfer {
                let gpu=self.compositing_gpu.as_ref().unwrap();let next=1-accumulator;
                let mut pass=encoder.begin_render_pass(&wgpu::RenderPassDescriptor{ multiview_mask: None,label:Some("layer blend transfer"),
                    color_attachments:&[Some(wgpu::RenderPassColorAttachment{ depth_slice: None,view:&self.layer_gpu.accumulators[next].view,resolve_target:None,
                        ops:wgpu::Operations{load:wgpu::LoadOp::Clear(wgpu::Color::TRANSPARENT),store:wgpu::StoreOp::Store}})],
                    depth_stencil_attachment:None,timestamp_writes:None,occlusion_query_set:None});
                pass.set_pipeline(&gpu.blend);pass.set_bind_group(0,&gpu.blend_group,&[gpu.blend_offset(i)]);
                pass.set_bind_group(1,&gpu.blend_inputs[accumulator].group,&[]);pass.draw(0..3,0..1);
                accumulator=next;composition_draws+=1;
            }
        }
        if has_accumulator {
            let writes = timestamps
                .as_ref()
                .map(|t| wgpu::RenderPassTimestampWrites {
                    query_set: t.query_set,
                    beginning_of_pass_write_index: None,
                    end_of_pass_write_index: t.end_of_pass_write_index,
                });
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                multiview_mask: None,
                label: Some("present adjusted composition"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    depth_slice: None,
                    view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(clear),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: writes,
                occlusion_query_set: None,
            });
            let [vx, vy, vw, vh] = crate::fit_viewport(
                [0., 0., width as f32, height as f32], [scene.width, scene.height]);
            pass.set_viewport(
                vx,
                vy,
                vw,
                vh,
                0.,
                1.,
            );
            pass.set_pipeline(&self.layer_gpu.present);
            pass.set_bind_group(0, &self.uniform_group, &[0]);
            pass.set_bind_group(1, &self.layer_gpu.accumulators[accumulator].composite, &[]);
            pass.draw(0..3, 0..1);
            composition_draws += 1;
        }
        Ok(RenderStats {
            cpu_prepare_us: started.elapsed().as_micros() as u64,
            draw_calls: (composition_draws + executed_passes) as u32,
            texture_bytes: self.texture_bytes
                + self.video_plane_bytes()
                + self.effect_gpu.state.bytes()
                + self.layer_gpu.bytes()
                + self.compositing_gpu.as_ref().map_or(0,|g|g.bytes()),
            parameter_upload_bytes: (bytes
                + executed_passes * motion_effects::shader::UNIFORM_BYTES
                + frame.vertices.len() * 20) as u64,
            instance_upload_bytes: (frame.sprites.len() * 48) as u64,
            particles_alive: frame.generator_stats.alive,
            particles_visible: frame.generator_stats.visible,
            particles_culled: frame.generator_stats.culled,
            parameter_resource_upload_bytes: std::mem::take(
                &mut self.effect_gpu.state.parameter_resource_upload_bytes,
            ),
        })
    }
    pub fn render_target(&self, width: u32, height: u32) -> Result<RenderTarget> {
        self.render_target_in(width, height, crate::TextureCategory::CaptureTargets)
    }
    pub(crate) fn render_target_in(&self, width: u32, height: u32, category: crate::TextureCategory) -> Result<RenderTarget> {
        self.render_target_with_format(width, height, self.target_format, category)
    }
    pub(crate) fn render_target_with_format(&self, width: u32, height: u32, format: wgpu::TextureFormat,
        category: crate::TextureCategory) -> Result<RenderTarget> {
        self.check_health()?;
        if width == 0
            || height == 0
            || u64::from(width) * u64::from(height) > CAPTURE_PIXEL_LIMIT
            || width > self.device.limits().max_texture_dimension_2d
            || height > self.device.limits().max_texture_dimension_2d
        {
            return Err(RenderError::Invalid("invalid capture size".into()));
        }
        let texture = self.device.create_admitted_texture(&wgpu::TextureDescriptor {
            label: Some("Motion Studio reusable offscreen frame"),
            size: wgpu::Extent3d {
                width,
                height,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT
                | wgpu::TextureUsages::COPY_SRC
                | wgpu::TextureUsages::TEXTURE_BINDING,
            view_formats: &[],
        }, &self.allocation_budget, category)?;
        let view = texture.admitted_view()?;
        Ok(RenderTarget {
            texture,
            view,
            width,
            height,
            owner: self.allocation_owner.clone(),
        })
    }
    pub fn capture_target(&self, width: u32, height: u32) -> Result<CaptureTarget> {
        self.check_health()?;
        if !matches!(self.target_format, wgpu::TextureFormat::Rgba8Unorm | wgpu::TextureFormat::Rgba8UnormSrgb
            | wgpu::TextureFormat::Bgra8Unorm | wgpu::TextureFormat::Bgra8UnormSrgb) {
            return Err(RenderError::Invalid(format!(
                "PNG capture does not accept {:?}; use format-preserving readback or explicit output conversion",
                self.target_format,
            )));
        }
        let target = self.render_target(width, height)?;
        let row_stride = (width * 4).div_ceil(256) * 256;
        let buffer_allocation = self.allocation_budget.reserve_in(u64::from(row_stride) * u64::from(height), crate::AllocationCategory::ReadbackBuffers)?;
        let buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Motion Studio bounded frame readback"),
            size: u64::from(row_stride) * u64::from(height),
            usage: wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        Ok(CaptureTarget {
            texture: target.texture,
            view: target.view,
            buffer,
            width,
            height,
            row_stride,
            _buffer_allocation: buffer_allocation,
        })
    }
    /// Readback is for screenshots and a measured reference export path, never preview.
    pub fn capture(
        &mut self,
        scene: &Scene,
        target: &CaptureTarget,
    ) -> Result<(Vec<u8>, RenderStats)> {
        self.preflight_effects(scene, target.width, target.height)?;
        let stats = self.draw(scene, &target.view, target.width, target.height)?;
        Ok((self.read_target(target)?, stats))
    }
    pub fn read_target(&self, target: &CaptureTarget) -> Result<Vec<u8>> {
        let observation = self.image_readback.begin();
        self.check_health()?;
        let mut encoder = self
            .allocation_command_encoder_for(crate::gpu_commands::CommandStage::ReadbackCopy, &wgpu::CommandEncoderDescriptor {
                label: Some("Motion Studio screenshot copy"),
            })?;
        encoder.copy_texture_to_buffer(
            wgpu::TexelCopyTextureInfo {
                texture: &target.texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            wgpu::TexelCopyBufferInfo {
                buffer: &target.buffer,
                layout: wgpu::TexelCopyBufferLayout {
                    offset: 0,
                    bytes_per_row: Some(target.row_stride),
                    rows_per_image: Some(target.height),
                },
            },
            wgpu::Extent3d {
                width: target.width,
                height: target.height,
                depth_or_array_layers: 1,
            },
        );
        self.submit_allocated(encoder.finish(), |ledger| ledger.merge(target.texture_resource_ledger()))?;
        let row_bytes = u64::from(target.width) * 4;
        observation.submitted(row_bytes * u64::from(target.height),
            u64::from(target.row_stride) * u64::from(target.height.saturating_sub(1)) + row_bytes);
        let (send, recv) = mpsc::sync_channel(1);
        target
            .buffer
            .slice(..)
            .map_async(wgpu::MapMode::Read, move |result| {
                let _ = send.send(result);
            });
        self.device.poll(wgpu::PollType::wait_indefinitely())?;
        recv.recv()
            .map_err(|e| RenderError::Readback(e.to_string()))?
            .map_err(|e| RenderError::Readback(e.to_string()))?;
        let mut pixels = Vec::with_capacity((target.width * target.height * 4) as usize);
        {
            let mapped = target.buffer.slice(..).get_mapped_range().map_err(|e| RenderError::Readback(e.to_string()))?;
            observation.mapped(mapped.len() as u64);
            for row in mapped.chunks_exact(target.row_stride as usize) {
                pixels.extend_from_slice(&row[..target.width as usize * 4]);
            }
        }
        target.buffer.unmap();
        if matches!(
            self.target_format,
            wgpu::TextureFormat::Bgra8UnormSrgb | wgpu::TextureFormat::Bgra8Unorm
        ) {
            for pixel in pixels.chunks_exact_mut(4) {
                pixel.swap(0, 2);
            }
        }
        // PNG uses straight alpha. GPU compositing used linear premultiplied alpha.
        for rgba in pixels.chunks_exact_mut(4) {
            let alpha = rgba[3] as f32 / 255.0;
            if alpha == 0.0 {
                rgba[..3].fill(0);
            } else if alpha < 1.0 {
                for c in &mut rgba[..3] {
                    *c = (linear_to_srgb(
                        (srgb_to_linear(*c as f32 / 255.0) / alpha).clamp(0.0, 1.0),
                    ) * 255.0)
                        .round() as u8;
                }
            }
        }
        observation.completed(pixels.len() as u64);
        Ok(pixels)
    }
    /// Read-only cumulative image readback observations, per Renderer lifetime.
    pub fn image_readback_info(&self) -> crate::ImageReadbackInfo { self.image_readback.info() }
}

/// Convert straight-alpha sRGB bytes for correct filtered GPU compositing.
/// This work belongs to resource loading, never the preview frame loop.
pub fn premultiply_pixels(rgba: &mut [u8]) {
    for pixel in rgba.chunks_exact_mut(4) {
        let alpha = pixel[3] as f32 / 255.0;
        for c in &mut pixel[..3] {
            *c = (linear_to_srgb(srgb_to_linear(*c as f32 / 255.0) * alpha) * 255.0).round() as u8;
        }
    }
}

pub struct RenderTarget {
    texture: OwnedTexture,
    pub view: crate::AdmittedTextureView,
    pub width: u32,
    pub height: u32,
    owner: Arc<()>,
}
impl RenderTarget {
    pub(crate) fn texture(&self) -> &OwnedTexture { &self.texture }
    pub(crate) fn check_owner(&self, renderer: &Renderer) -> Result<()> {
        if Arc::ptr_eq(&renderer.allocation_owner, &self.owner) { Ok(()) }
        else { Err(RenderError::Invalid("render target belongs to another renderer".into())) }
    }
    pub fn collect_texture_resources(&self, ledger: &mut crate::TextureResourceLedger, owner: &str, state: crate::TextureState) {
        ledger.add(&self.texture, crate::TextureCategory::PreviewTargets, owner.into(), state);
    }
    pub fn texture_bytes(&self) -> u64 {
        // One mip/sample/layer, using the allocation's format (not the current
        // renderer setting). Unknown capacity must never count as zero.
        self.texture.format().block_copy_size(None)
            .map_or(u64::MAX, |bytes| u64::from(self.width) * u64::from(self.height) * u64::from(bytes))
    }
}
pub struct CaptureTarget {
    texture: OwnedTexture,
    pub view: crate::AdmittedTextureView,
    buffer: wgpu::Buffer,
    pub width: u32,
    pub height: u32,
    row_stride: u32,
    _buffer_allocation: crate::allocation_budget::AllocationLease,
}
impl CaptureTarget {
    pub fn texture_resource_ledger(&self) -> crate::TextureResourceLedger {
        let mut ledger = crate::TextureResourceLedger::default();
        ledger.retained(&self.texture, crate::TextureCategory::CaptureTargets, "capture/target".into());
        ledger
    }
}
pub(crate) fn srgb_to_linear(v: f32) -> f32 {
    if v <= 0.04045 {
        v / 12.92
    } else {
        ((v + 0.055) / 1.055).powf(2.4)
    }
}
pub(crate) fn linear_to_srgb(v: f32) -> f32 {
    if v <= 0.0031308 {
        v * 12.92
    } else {
        1.055 * v.powf(1.0 / 2.4) - 0.055
    }
}
