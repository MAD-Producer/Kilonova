from pathlib import Path
import hashlib, json, re, zipfile

root=Path('E:/Dev/aem')
work=root/'.worktrees/rational-frame-rates85'
folder=root/'artifacts/pr-queue/professional-api86-final-render-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((folder/'exit.json').read_text(encoding='utf-8'))
assert report['status']=='passed_scope_acceptance_pending' and report['sourceUnchanged'] and report['completedUtc']
assert report['head']=='b015ddad43ac8fc76b6ec049af2a3822edcbdc06'
assert all(sha(work/name)==digest for name,digest in report['sources'].items())
metadata=json.loads((folder/'expected-package-targets.json').read_text(encoding='utf-8'))
assert metadata['head']==report['head']
expected=metadata['packages']['motion-render']
render=next(item for item in report['results'] if item['name']=='render')
assert all(item['status']=='passed' and item['exitCode']==0 for item in report['results'])
log=(folder/'render.stderr.log').read_text(encoding='utf-8',errors='replace').replace('\\','/')
invoked=[line.strip() for line in log.splitlines() if re.search(r'Running (?:unittests |tests/)|Doc-tests motion_render',line)]
assert len(expected)==121 and len(invoked)==122 and len(render['summaries'])==122
for target in expected:
    path=target['src_path'].replace('\\','/')
    marker='unittests src/lib.rs' if 'lib' in target['kind'] else ('unittests examples/' if 'example' in target['kind'] else 'tests/')+path.rsplit('/',1)[-1]
    assert sum(marker in line for line in invoked)==1,marker
assert sum('Doc-tests motion_render' in line for line in invoked)==1
counts=[tuple(map(int,re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored;',line).groups())) for line in render['summaries']]
totals=dict(zip(('passed','failed','ignored'),map(sum,zip(*counts))))
assert totals==dict(passed=957,failed=0,ignored=1),totals
terminal=dict(originalSession=63700,terminalConsumed=True,exitCode=0,gateReportSha256=sha(folder/'exit.json'))
(folder/'terminal-consumed.json').write_text(json.dumps(terminal,indent=2)+'\n',encoding='utf-8')
# The actual terminal was consumed before issuing this release; CPU stages can proceed to one native GPU workload.
release=root/'artifacts/pr-queue/tracking583-current-main-v2/render-terminal-consumed.json'
assert not release.exists()
release.write_text(json.dumps(terminal,indent=2)+'\n',encoding='utf-8')
receipt=dict(status='complete_renderer_passed_full_desktop_and_latest_main_pending',head=report['head'],mainAtGateStart=report['main'],
             terminal=terminal,sourceUnchangedAtPublication=True,expectedTargets=121,docTargets=1,totals=totals,
             elapsedSeconds=render['elapsedSeconds'],limits=[
                 'Gate source includes the approved ten panel clocks, cold expression preparation and native clock regression',
                 'Own PR581 merged to main c0e25eda during this gate; this is not proof for a subsequent main merge',
                 'Complete desktop original precision stack overflow and the separately unauthorized graph fixture remain unresolved',
                 'Original ignores, assertions, budgets and all targets retained; no Android acceptance'])
(folder/'coverage-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
names=['exit.json','controller.py','terminal-consumed.json','coverage-receipt.json','expected-package-targets.json',
       'desktop-check-all-targets.stdout.log','desktop-check-all-targets.stderr.log','render.stdout.log','render.stderr.log']
entries={name:(folder/name).read_bytes() for name in names}
entries['environment/run.ps1']=(root/'.tools/issue-closure-review/run-professional-api86-final-render-v1.ps1').read_bytes()
entries['environment/recorder.py']=Path(__file__).read_bytes()
members={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in entries.items()}
entries['manifest.json']=(json.dumps(members,indent=2)+'\n').encode('utf-8')
dest=work/'engineering/validation/data/professional-api86-final-render-v1.zip'
assert not dest.exists()
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,data in sorted(entries.items()):archive.writestr(name,data)
with zipfile.ZipFile(dest) as archive:
    assert archive.testzip() is None and set(archive.namelist())==set(entries)
    for name,data in entries.items():assert archive.read(name)==data
receipt['archive']=dict(path=dest.name,bytes=dest.stat().st_size,sha256=sha(dest),members=len(entries))
dest.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
