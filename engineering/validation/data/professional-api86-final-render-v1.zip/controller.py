from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/professional-api86-final-render-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=work).strip()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
tracked = subprocess.check_output(['git', 'ls-files', '-z', 'crates', 'desktop', 'tools', '.github', 'Cargo.toml', 'Cargo.lock'], cwd=work).decode().split('\0')
sources = {name: sha(work/name) for name in tracked if name and (work/name).is_file()}
os.environ['LOCALAPPDATA'] = str(out/'local-app-data')
Path(os.environ['LOCALAPPDATA']).mkdir()
os.environ.pop('MOTION_LOG', None)
report = dict(status='running', head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip(), main='acaab00b74df3f61b278408050040d19133074be', startedUtc=datetime.now(timezone.utc).isoformat(), scope='Final-render scope after integrating approved ten panels, cold expression preparation and native clock readback test. Latest fetched main remains acaab00b. Complete model/core on preceding core-identical source: 880 pass, zero fail, one original ignore. This gate does not execute complete desktop: original precision stack overflow and pending fixture authorization remain unresolved. Real default GPU, no retries, filters, budget/assertion/ignore changes or Android acceptance.', sources=sources, results=[])
save = lambda: (out/'exit.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
commands = [
    ('desktop-check-all-targets', ['cargo', 'check', '-p', 'motion-desktop', '--all-targets', '--locked', '--offline']),
    ('render', ['cargo', 'test', '-p', 'motion-render', '--no-fail-fast', '--locked', '--offline', '--', '--test-threads=1']),
]

assert report['head'] == 'b015ddad43ac8fc76b6ec049af2a3822edcbdc06'
subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],cwd=work,check=True)
start = time.monotonic()
save()
try:
    for name, command in commands:
        item = dict(name=name, command=command, status='running', startedUtc=datetime.now(timezone.utc).isoformat())
        report['results'].append(item)
        save()
        began = time.monotonic()
        with (out/f'{name}.stdout.log').open('wb') as stdout, (out/f'{name}.stderr.log').open('wb') as stderr:
            child = subprocess.Popen(command, cwd=work, env=os.environ.copy(), stdout=stdout, stderr=stderr)
            item['pid'] = child.pid
            save()
            item['exitCode'] = child.wait()
        item['elapsedSeconds'] = round(time.monotonic()-began, 3)
        item['summaries'] = re.findall(r'^test result: .+$', (out/f'{name}.stdout.log').read_text(encoding='utf-8', errors='replace'), re.M)
        item['status'] = 'passed' if item['exitCode'] == 0 else 'failed'
        save()
        print(json.dumps(item), flush=True)
        if item['exitCode'] != 0:
            break
    report['sourceUnchanged'] = all(sha(work/name)==digest for name, digest in sources.items())
    report['status'] = 'passed_scope_acceptance_pending' if len(report['results']) == len(commands) and all(item['status']=='passed' for item in report['results']) and report['sourceUnchanged'] else 'failed_original_results_retained'
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic()-start, 3))
    save()
    print(json.dumps({k: v for k, v in report.items() if k!='sources'}), flush=True)
raise SystemExit(0 if report['status']=='passed_scope_acceptance_pending' else 1)
