"""Retain terminal exact-source CI; preserve the earlier partial snapshot."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess
import zipfile

ART = Path('E:/Dev/aem/artifacts/pr-queue')
OUT = ART / 'depth75-ci-d1975528-terminal-v1'
PARTIAL = ART / 'depth75-ci-d1975528-first-completed-v1'
REPO = 'MAD-Producer/Kilonova'
RUN = 42595433015
HEAD = 'd197552823bef0fe3bc192f01649753e059dbd8c'


def write(path, value):
    path.write_bytes((json.dumps(value, indent=2) + '\n').encode())


def api(path):
    return subprocess.check_output(['gh', 'api', path])


run = json.loads(api(f'repos/{REPO}/actions/runs/{RUN}'))
assert run['head_sha'] == HEAD and run['status'] == 'completed'
jobs = json.loads(api(f'repos/{REPO}/actions/runs/{RUN}/jobs?per_page=100'))['jobs']
assert len(jobs) == 10 and all(j['status'] == 'completed' and j['head_sha'] == HEAD for j in jobs)
assert run['conclusion'] == 'success'
assert sum(j['conclusion'] == 'success' for j in jobs) == 8
assert sum(j['conclusion'] == 'skipped' for j in jobs) == 2
OUT.mkdir(exist_ok=False)
write(OUT / 'run.json', run)
write(OUT / 'jobs.json', jobs)
prior = json.loads((PARTIAL / 'collection.json').read_text(encoding='utf-8-sig'))
assert prior['head'] == HEAD and prior['run'] == RUN
assert prior['status'] == 'partial_completed_jobs_retained_not_whole_run_acceptance'
records_by_id = {j['job']: j for j in prior['records']}
write(OUT / 'prior-partial-collection.json', prior)
write(OUT / 'partial-session-consumed.json', dict(
    session=83421, original_chunk_id='a253f1', exit_code=0,
    original_tool_result_consumed=True,
    limits='Earlier metadata remains partial; terminal metadata is collected separately',
))
names = [
    'owned_output_verifies_digest_and_preserves_an_existing_publication',
    'canceled_host_remap_does_not_read_input_or_create_an_output',
    'exact_endpoints_and_single_pixel_axes_do_not_sample_padding',
    'constant_and_affine_planes_follow_independent_source_coordinates',
    'wrong_extent_nonfinite_input_invalid_dimensions_and_cancellation_are_refused',
    'host_procedure_and_runtime_cannot_masquerade_as_the_python_only_mode',
    'host_remap_is_explicit_and_cannot_be_summed_as_a_separate_child',
    'schedule_requires_complete_cohorts_duration_and_refuses_a_short_capped_run',
]
records = []
for job in jobs:
    if job['conclusion'] == 'skipped':
        continue
    path = OUT / f'{job["id"]}.log'
    stderr_path = OUT / f'{job["id"]}.download.stderr.log'
    if job['id'] in records_by_id:
        previous = records_by_id[job['id']]
        raw = (PARTIAL / path.name).read_bytes()
        assert previous['download_exit'] == 0 and previous['bytes'] == len(raw)
        assert previous['sha256'] == hashlib.sha256(raw).hexdigest()
        path.write_bytes(raw)
        stderr_path.write_bytes((PARTIAL / stderr_path.name).read_bytes())
        origin = 'copied_verified_completed_job_from_partial_collection'
        code = 0
    else:
        with path.open('xb') as stdout, stderr_path.open('xb') as stderr:
            code = subprocess.run(['gh', 'api', f'repos/{REPO}/actions/jobs/{job["id"]}/logs'],
                                  stdout=stdout, stderr=stderr).returncode
        raw = path.read_bytes()
        origin = 'downloaded_after_terminal_run'
    assert code == 0 and raw
    record = dict(job=job['id'], name=job['name'], conclusion=job['conclusion'],
                  download_exit=code, origin=origin, bytes=len(raw),
                  sha256=hashlib.sha256(raw).hexdigest())
    if job['name'].startswith('Desktop tests ('):
        text = raw.decode('utf-8')
        record['named_passes'] = {
            name: len(re.findall(r'(?m)^.*?test (?:\S+::)?' + re.escape(name) + r' \.\.\. ok\s*$', text))
            for name in names
        }
        assert all(count == 1 for count in record['named_passes'].values())
    records.append(record)
assert len([r for r in records if 'named_passes' in r]) == 3
write(OUT / 'collection.json', dict(
    status='terminal_exact_head_ci_retained', run=RUN, head=HEAD,
    conclusion=run['conclusion'], records=records,
    observed_utc=datetime.now(timezone.utc).isoformat(),
    limits=[
        'Named controls are observations within existing totals, not 24 additional tests',
        'No model/runtime installation or live-model sustained/domain qualification is run by CI',
        'Native desktop matrix does not run all Windows graph/render integration targets',
        'Prior local failures remain failed; remote success does not identify their cause',
        'No CI dispatch, retry or cancellation',
    ],
))
members = {p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
members['collector.py'] = Path(__file__).read_bytes()
archive = OUT / 'depth75-ci-d1975528-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
    for name, raw in sorted(members.items()):
        target.writestr(name, raw)
manifest = dict(archive=archive.name, bytes=archive.stat().st_size,
                sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), source_head=HEAD, run=RUN,
                members={name: dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
                         for name, raw in members.items()})
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(members)
    for name, raw in members.items():
        assert target.read(name) == raw
write(OUT / 'depth75-ci-d1975528-v1.json', manifest)
print(json.dumps(dict(conclusion=run['conclusion'], jobs=len(jobs), applicable_passes=8,
                     policy_skips=2, archive=str(archive), bytes=manifest['bytes'],
                     sha256=manifest['sha256'], members=len(members))))
