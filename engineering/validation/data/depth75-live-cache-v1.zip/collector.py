"""Retain successful cache controls alongside the original native child fault."""
from pathlib import Path
import hashlib,json,zipfile
ART=Path('E:/Dev/aem/artifacts/pr-queue')
WORK=Path('E:/Dev/aem/.worktrees/depth-retained-context75')
OUT=ART/'depth75-live-cache-public-v1'
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(data):return hashlib.sha256(data).hexdigest()
members={}
for name,session,exit_code in [('depth75-live-cache-v1',79852,1),('depth75-live-cache-v2',89099,0)]:
    consumed=read(ART/name/'session-consumed.json')
    assert consumed['session']==session and consumed['consumed'] and consumed['exit_code']==exit_code
    receipt=read(ART/name/'receipt.json')
    assert receipt['source_unchanged']
    for path in (ART/name).rglob('*'):
        if path.is_file() and path.suffix in {'.json','.log','.rs','.py'}:
            assert path.stat().st_size<32<<20
            members[f'{name}/{path.relative_to(ART/name).as_posix()}']=path.read_bytes()
last=read(ART/'depth75-live-cache-v2/receipt.json')
assert last['status']=='actual_cache_case_passed_original_jobs_failure_retained'
assert sha((WORK/last['changed_test']).read_bytes())==last['changed_test_sha256']
for name,digest in last['unchanged_product_sha256'].items():
    assert sha((WORK/name).read_bytes())==digest
evidence=read(ART/'depth75-live-cache-v2/cache/evidence.json')
assert evidence['inference_calls']==2 and evidence['cache_entries']==2
assert evidence['reopened_service']['completed_inputs']==0 and evidence['corrupt_service']['completed_inputs']==0
assert evidence['first_service']['completed_inputs']==1
assert evidence['all_owned_service_directories_removed']
error=(ART/'depth75-live-cache-v1/jobs/stderr.log').read_text(encoding='utf-8')
assert 'phase=prepare' in error and '3221225477' in error
assert len(last['commands'])==1 and last['commands'][0]['exit_code']==0
members['collector.py']=Path(__file__).read_bytes()
OUT.mkdir(exist_ok=False)
archive=OUT/'depth75-live-cache-v1.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
manifest=dict(schema=1,archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
    members={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())})
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for name,data in members.items():assert z.read(name)==data and sha(z.read(name))==manifest['members'][name]['sha256']
(OUT/'depth75-live-cache-v1.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
print(json.dumps(dict(bytes=manifest['bytes'],sha256=manifest['sha256'],members=len(members),
    first_jobs_case='failed_original_child_access_violation',cache_case='passed_first_execution')))
