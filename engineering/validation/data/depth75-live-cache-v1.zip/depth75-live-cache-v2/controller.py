"""Real retained/cold Jobs cache controls, with an unchanged worker binary."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, time, traceback
from datetime import datetime, timezone
ROOT=Path('E:/Dev/aem')
ART=ROOT/'artifacts/pr-queue'
WORK=ROOT/'.worktrees/depth-retained-context75'
OUT=ART/'depth75-live-cache-v2'
PRIOR=ART/'depth75-live-service-v3'
TARGET=ROOT/'target/depth-wgsl-cache75-contract'
CP=ART/'depth75-resume-current.json'
def write(path,value): path.write_bytes((json.dumps(value,indent=2)+'\n').encode())
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=WORK,text=True).strip()
consumed=read(PRIOR/'session-consumed.json')
assert consumed['session']==87782 and consumed['consumed'] and consumed['exit_code']==0
refusals=read(ART/'depth75-live-mailbox-controls-v2/session-consumed.json')
assert refusals['session']==12787 and refusals['consumed'] and refusals['exit_code']==0
original=read(ART/'depth75-live-cache-v1/session-consumed.json')
assert original['session']==79852 and original['consumed'] and original['exit_code']==1 and original['cache_case_executed'] is False
state=read(CP)
assert state['versionedCache75']['activeController'] is None and not state['versionedCache75']['ownHeavyWorkloads']
assert shutil.disk_usage(ROOT).free>=10<<30
assert git('rev-parse','HEAD')=='ead5f81ceda884dab735349c99448f5fa356726e'
changed='crates/motion-host/tests/depth_wgsl_retained.rs'
assert git('diff','--name-only')==changed and git('ls-files','--others','--exclude-standard')==''
old=read(PRIOR/'receipt.json')
product={name:sha(WORK/name) for name in old['changed_source_sha256'] if name!=changed}
assert product=={name:digest for name,digest in old['changed_source_sha256'].items() if name!=changed}
fixture=read(PRIOR/'fixture.json')
assert sha(Path(fixture['worker']))==old['worker_sha256']
source=sha(WORK/changed)
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__,OUT/'controller.py')
shutil.copyfile(WORK/changed,OUT/'depth_wgsl_retained.rs')
env=os.environ.copy()
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),
    CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
    TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),RUST_BACKTRACE='full',
    LOCALAPPDATA=str(OUT/'appdata'),PYTHONDONTWRITEBYTECODE='1',
    LIBCLANG_PATH=str(ROOT/'.tools/python-libclang/clang/native'))
ffmpeg=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(FFMPEG_DIR=str(ffmpeg),FFMPEG_INCLUDE_DIR=str(ffmpeg/'include'),FFMPEG_LIB_DIR=str(ffmpeg/'lib'))
env['PATH']=str(ffmpeg/'bin')+os.pathsep+env['PATH']
env.pop('MOTION_LOG',None)
Path(env['LOCALAPPDATA']).mkdir()
report=dict(original_jobs_failure_retained='depth75-live-cache-v1/session-consumed.json', scope='First execution of previously unexecuted cache case only; not a Jobs retry or source acceptance', status='running',source_head=git('rev-parse','HEAD'),changed_test=changed,
    changed_test_sha256=source,unchanged_product_sha256=product,worker_sha256=old['worker_sha256'],
    commands=[],started_utc=datetime.now(timezone.utc).isoformat(),
    limits=['Two explicit installed-model native Jobs controls; no mocks or acquisition',
        'Full workspace regression, qualified Session/export, concurrent budgets and thermal quality remain open',
        'No Android, panels, existing assertion/deadline changes, retries or foreign process actions'])
state['versionedCache75'].update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(
    kind='actual retained/cold Jobs persistent cache controls',output=str(OUT),sourceFrozen=True)])
write(CP,state)
def save(): write(OUT/'receipt.json',report)
def frozen():
    return sha(WORK/changed)==source and git('rev-parse','HEAD')==report['source_head'] and all(
        sha(WORK/name)==digest for name,digest in product.items()) and sha(Path(fixture['worker']))==old['worker_sha256']
start=time.monotonic()
try:
    for label,test in [('cache','actual_retained_cache_reopens_without_inference_and_isolates_cold_execution')]:
        root=OUT/label
        root.mkdir()
        actual=dict(fixture,scratch=str(root/'scratch'),evidence=str(root/'evidence.json'))
        write(root/'fixture.json',actual)
        env['MOTION_DEPTH_RETAINED_TEST_FIXTURE']=str(root/'fixture.json')
        args=['cargo','test','-p','motion-host','--features','ai-depth','--test','depth_wgsl_retained',test,
            '--locked','--offline','--','--ignored','--exact','--test-threads=1']
        item=dict(label=label,args=args,timeout_seconds=300,started_utc=datetime.now(timezone.utc).isoformat())
        report['commands'].append(item)
        save()
        began=time.monotonic()
        with (root/'stdout.log').open('wb') as stdout,(root/'stderr.log').open('wb') as stderr:
            result=subprocess.run(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr,timeout=300)
        item.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-began)
        save()
        assert result.returncode==0 and frozen(),item
        assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in (root/'stdout.log').read_text(encoding='utf-8')
        evidence=read(root/'evidence.json')
        if label=='cache':
            assert evidence['inference_calls']==2 and evidence['cache_entries']==2
            assert evidence['all_owned_service_directories_removed']
            assert evidence['reopened_service']['completed_inputs']==0
            assert evidence['corrupt_service']['completed_inputs']==0
            assert 'content SHA-256 differs' in evidence['original_corruption_cause']
            assert 'content SHA-256 differs' in (root/'logs/motion-studio.log').read_text(encoding='utf-8')
            assert 'content SHA-256 differs' in (root/'stderr.log').read_text(encoding='utf-8')
        else:
            assert evidence['completed']==3 and evidence['canceled']==1 and evidence['failed']==1
    report['status']='actual_cache_case_passed_original_jobs_failure_retained'
except BaseException:
    report.update(status='failed_original_outcome_retained',failure=traceback.format_exc())
finally:
    report.update(source_unchanged=frozen(),elapsed_seconds=time.monotonic()-start,
        completed_utc=datetime.now(timezone.utc).isoformat())
    save()
    print(json.dumps(dict(status=report['status'],commands=report['commands'],source_unchanged=report['source_unchanged'])))
raise SystemExit(0 if report['status']=='actual_cache_case_passed_original_jobs_failure_retained' else 1)
