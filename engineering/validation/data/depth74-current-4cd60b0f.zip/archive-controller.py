from pathlib import Path
import hashlib,json,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-colmap88';base=root/'artifacts/pr-queue'
sha=lambda b:hashlib.sha256(b).hexdigest()
dest=work/'engineering/validation/data/depth74-current-4cd60b0f.zip'
assert not dest.exists()
folders=['depth74-colmap-current-build-v1','depth74-colmap-current-build-v2','depth74-colmap-current-build-v3','depth74-colmap-current-build-v4',
         'depth74-colmap-current-build-v5','depth74-colmap-current-build-v6','depth74-colmap-fallback-v1',
         'depth74-colmap-current-native-v1','depth74-colmap-current-native-v2','depth74-colmap-current-native-v3',
         'depth74-colmap-contracts-v1','depth74-colmap-contracts-v2']
entries={}
for name in folders:
    for p in (base/name).rglob('*'):
        if p.is_file():
            assert p.suffix.lower() not in ('.exe','.dll','.onnx','.pth','.pdb')
            entries['runs/'+p.relative_to(base).as_posix()]=p.read_bytes()
for name in ['issue3d-final-native-depth-v1/verified.json','issue3d-final-native-depth-v1/controller.py',
             'issue3d-final-native-depth-v1/official-reference.f32','issue3d-final-color-staging-v1/verified.json',
             'issue3d-final-color-staging-v1/known/input.rgb']:
    entries['reference/'+name]=(base/name).read_bytes()
for rel in ['desktop/app/src/logging.rs','crates/motion-host/src/depth.rs','crates/motion-host/src/depth/onnx.rs',
            'crates/motion-host/src/depth/video.rs','crates/motion-host/src/session.rs','tools/ai_depth_onnx.py',
            'crates/motion-host/tests/depth_jobs.rs','crates/motion-host/tests/depth_session.rs','crates/motion-host/tests/depth_video.rs']:
    entries['source/'+rel]=(work/rel).read_bytes()
entries['archive-controller.py']=Path(__file__).read_bytes()
manifest={p:dict(bytes=len(b),sha256=sha(b)) for p,b in sorted(entries.items())}
entries['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(dest) as z:
    assert set(z.namelist())==set(entries)
    for name,data in entries.items():assert z.read(name)==data
receipt=dict(archive=dest.name,bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),members=len(entries),
             everyMemberReadBack=True,manifest=manifest)
dest.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='manifest'}))
