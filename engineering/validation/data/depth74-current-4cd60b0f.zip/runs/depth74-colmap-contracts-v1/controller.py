from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,time
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-colmap88'
out=root/'artifacts/pr-queue/depth74-colmap-contracts-v1';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','-z'],cwd=work).decode().split('\0')
before={p:sha(work/p) for p in names if p and (p.startswith(('crates/','desktop/')) or p in ('Cargo.toml','Cargo.lock')) and (work/p).is_file()}
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(root/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(root/'target/colmap88-isolated-check'),
           CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
base=['cargo','test','-p','motion-host','--no-default-features','--features','ai-depth','--locked','--offline']
steps=[('jobs-session-video',base+['--test','depth_video','--test','depth_session','--test','depth_jobs','--','--test-threads=1']),
       ('onnx-unit',base+['--lib','depth::onnx::tests::','--','--test-threads=1'])]
report=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),source=before,steps=[],
            startedUtc=datetime.now(timezone.utc).isoformat(),scope='Complete optional depth jobs/session/video integration targets and ONNX unit module only; no full regression claim')
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
def save(): (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
started=time.monotonic()
try:
    for name,command in steps:
        row=dict(name=name,command=command);report['steps'].append(row);save()
        with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
            p=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait()
        row['summaries']=re.findall(r'^test result:.*$',(out/(name+'.stdout.log')).read_text(encoding='utf-8',errors='replace'),re.M)
        row['sourceUnchanged']=all(sha(work/p)==digest for p,digest in before.items())
        save();assert row['exitCode']==0 and row['sourceUnchanged'],name
        assert row['summaries'] and all('0 failed; 0 ignored;' in s for s in row['summaries']),name
    report['status']='passed'
except BaseException as error:
    report.update(status='failed_original_outputs_retained',failure=repr(error));raise
finally:
    report.update(elapsedSeconds=round(time.monotonic()-started,3),completedUtc=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({k:v for k,v in report.items() if k!='source'}))
