"""Actual unavailable-CUDA -> CPU provider fallback, with real native source preparation."""
from pathlib import Path
import hashlib,json,os,subprocess,time
import numpy as np
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-colmap88';home=root/'.tools/ai-depth74'
out=root/'artifacts/pr-queue/depth74-colmap-fallback-v1';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
probe=home/'colmap-current-probe';builddir=root/'artifacts/pr-queue/depth74-colmap-current-build-v6'
build=json.loads((builddir/'exit.json').read_text(encoding='utf-8'))
assert build['exitCode']==0 and build['sourceUnchanged']
binary=root/'target/colmap88-isolated-check/debug/motion-depth74-integration-probe.exe'
assert sha(binary)==build['binarySha256']
def frozen():
    return all((sha(probe/p.removeprefix('external-probe/')) if p.startswith('external-probe/') else sha(work/p))==v
               for p,v in build['source'].items())
assert frozen()
env=os.environ.copy();env.pop('MOTION_LOG',None);env['CUDA_VISIBLE_DEVICES']=''
for key,folder in [('TEMP','temp'),('TMP','temp'),('TORCH_HOME','torch-cache'),('HF_HOME','hf-cache'),('TORCHINDUCTOR_CACHE_DIR','inductor-cache'),('PYTHONPYCACHEPREFIX','pycache')]:env[key]=str(home/folder)
ffbin=root/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin';env['PATH']=str(ffbin)+os.pathsep+env['PATH']
report=dict(head=build['head'],source=build['source'],binarySha256=sha(binary),commands=[],
            limits=['Only unavailable CUDA fallback is tested; no accelerated provider execution',
                    'Default Rust Session worker thread; original process-main overflow not repaired',
                    'Pinned historical independent PyTorch golden; not a fresh PyTorch run',
                    'No full regression, GUI Engine, zero-copy or physical-depth claim'])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
(out/'build-receipt.json').write_bytes((builddir/'exit.json').read_bytes())
def save(): (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def run(name,command):
    assert frozen();row=dict(name=name,command=command);report['commands'].append(row);save()
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        p=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait(timeout=180)
    save();assert row['exitCode']==0,name
    return (out/(name+'.stdout.log')).read_bytes()
started=time.monotonic()
try:
    providers=json.loads(run('available-providers',[str(home/'venv/Scripts/python.exe'),'-c','import json,onnxruntime; print(json.dumps({"runtime":onnxruntime.__version__,"available":onnxruntime.get_available_providers()}))']))
    assert 'CUDAExecutionProvider' not in providers['available']
    assert 'CPUExecutionProvider' in providers['available']
    report['runtime']=providers
    color=root/'artifacts/pr-queue/issue3d-final-color-staging-v1';cr=json.loads((color/'verified.json').read_text())
    fixture=color/'known/project/assets/source.mp4';assert sha(fixture)==cr['artifacts']['known/project/assets/source.mp4']
    dest=out/'project/assets/source.mp4';dest.parent.mkdir(parents=True);dest.write_bytes(fixture.read_bytes())
    run('native-session',[str(binary),str(out),'inference','cuda'])
    assert not (out/'native-session.stdout.log').read_bytes()
    log=(out/'logs/motion-studio.log').read_text(encoding='utf-8');stderr=(out/'native-session.stderr.log').read_text(encoding='utf-8')
    assert 'logging initialized level=INFO' in log
    assert 'actual_provider=CPUExecutionProvider requested_provider=CUDAExecutionProvider cpu_fallback=true' in log
    assert log.index('start #1 depth_infer asset=74')<log.index('ERROR')
    for stream in (log,stderr):assert 'request=1 operation=depth_infer asset=74' in stream and 'stage=source_prepare' in stream and 'video cache missing' in stream
    assert 'start #1' not in stderr and 'actual_provider=' not in stderr
    result=json.loads((out/'result.json').read_text());costs=json.loads((out/'estimate-costs.json').read_text());session=json.loads((out/'session-costs.json').read_text())
    assert result['actualInference'] and result['actualNativeFfmpeg'] and result['actualSession'] and result['seekInvalidated']
    assert result['provider']=='CPUExecutionProvider' and result['actualPtsUs']==50000 and result['targetUs']==76667
    assert costs['actualProvider']=='CPUExecutionProvider' and session['actualProvider']=='CPUExecutionProvider' and session['requestedProvider']=='cuda'
    assert costs['inputHostCopyBytes']==3*518*518*4 and costs['outputHostCopyBytes']==518*518*4
    assert all(costs[k]>0 for k in ('loadNs','preprocessNs','inputCopyNs','inferenceNs','outputCopyNs','postprocessNs','hostTransportNs','totalNs'))
    assert session['sourcePrepareNs']>0 and session['sourceRgbBytes']==52*80*3 and session['totalNs']>=costs['inferenceNs']
    assert sha(color/'known/input.rgb')==cr['artifacts']['known/input.rgb'] and (out/'input.rgb').read_bytes()==(color/'known/input.rgb').read_bytes()
    old=root/'artifacts/pr-queue/issue3d-final-native-depth-v1';reference=json.loads((old/'verified.json').read_text())
    assert sha(old/'official-reference.f32')==reference['artifacts']['official-reference.f32']
    assert sha(home/'models/depth_anything_v2_vits_518.onnx')==reference['onnxSha256']
    a=np.fromfile(out/'output.f32','<f4');e=np.fromfile(old/'official-reference.f32','<f4')
    assert len(a)==52*80 and np.isfinite(a).all();err=np.abs(a.astype(np.float64)-e.astype(np.float64));scale=max(float(np.abs(e).max()),1e-6)
    maximum=float(err.max())/scale;mean=float(err.mean())/scale;assert maximum<=2e-4 and mean<=2e-5
    report.update(status='passed',result=result,costs=costs,sessionCosts=session,maxNormalized=maximum,meanNormalized=mean,
                  maxBound=2e-4,meanBound=2e-5,acceptedSrgbInputBitExact=True,defaultInfoFallbackVisible=True,
                  defaultInfoStart=True,errorFileAndStderr=True,stdoutEmpty=True)
except BaseException as error:
    report.update(status='failed_original_outputs_retained',failure=repr(error));raise
finally:
    report.update(sourceUnchanged=frozen(),elapsedSeconds=round(time.monotonic()-started,3));save()
assert report['sourceUnchanged']
report['artifacts']={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()}
(out/'verified.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('source','artifacts','commands')}))
