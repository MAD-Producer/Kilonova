from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, time

root = Path('E:/Dev/aem')
work = root/'.worktrees/tracking-colmap88'
probe = root/'.tools/ai-depth74/colmap-current-probe'
out = root/'artifacts/pr-queue/depth74-colmap-current-build-v1'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def source():
    names = subprocess.check_output(['git','ls-files','-z'],cwd=work).decode().split('\0')
    result = {p:sha(work/p) for p in names if p and (p.endswith(('.rs','.toml','.py')) or p=='Cargo.lock')}
    result.update({'external-probe/'+p:sha(probe/p) for p in ('Cargo.toml','Cargo.lock','src/main.rs')})
    return result
before = source()
env = os.environ.copy()
env.update(CARGO_HOME=str(root/'.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(root/'target/colmap88-isolated-check'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
command = ['cargo','build','--manifest-path',str(probe/'Cargo.toml'),'--locked','--offline']
report = dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
              source=before,command=command,startedUtc=datetime.now(timezone.utc).isoformat())
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
for p in ('Cargo.toml','Cargo.lock','src/main.rs'):
    dest=out/'probe'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((probe/p).read_bytes())
def save(): (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
started=time.monotonic();save()
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
    process=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr)
    report['pid']=process.pid;save();report['exitCode']=process.wait()
report.update(elapsedSeconds=round(time.monotonic()-started,3),sourceUnchanged=before==source())
if report['exitCode']==0:
    binary=Path(env['CARGO_TARGET_DIR'])/'debug/motion-depth74-integration-probe.exe'
    report['binarySha256']=sha(binary)
save();print(json.dumps({k:v for k,v in report.items() if k!='source'}))
raise SystemExit(0 if report['exitCode']==0 and report['sourceUnchanged'] else 1)
