"""Current real Session/FFmpeg/CPU ONNX against a pinned previous independent golden.

This deliberately does not claim a fresh PyTorch run or a full regression.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, time
import numpy as np
from PIL import Image

root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-colmap88'
out=root/'artifacts/pr-queue/depth74-colmap-current-native-v3';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
builddir=root/'artifacts/pr-queue/depth74-colmap-current-build-v4'
build=json.loads((builddir/'exit.json').read_text(encoding='utf-8'))
assert build['exitCode']==0 and build['sourceUnchanged']
probe=root/'.tools/ai-depth74/colmap-current-probe'
binary=root/'target/colmap88-isolated-check/debug/motion-depth74-integration-probe.exe'
assert sha(binary)==build['binarySha256']
def source():
    return {p:sha(probe/p.removeprefix('external-probe/')) if p.startswith('external-probe/') else sha(work/p)
            for p in build['source']}
assert source()==build['source']
color=root/'artifacts/pr-queue/issue3d-final-color-staging-v1'
old=root/'artifacts/pr-queue/issue3d-final-native-depth-v1'
color_receipt=json.loads((color/'verified.json').read_text(encoding='utf-8'))
old_receipt=json.loads((old/'verified.json').read_text(encoding='utf-8'))
assert sha(color/'verified.json')==old_receipt['colorReceiptSha256']
def verified(base,receipt,rel):
    p=base/rel;assert sha(p)==receipt['artifacts'][rel],str(p);return p
golden=verified(old,old_receipt,'official-reference.f32')
assert sha(golden)=='2695b67c87473b1d89fb56763d24ce87836983c5082a77ef5a72f0d4858eb546'
env=os.environ.copy();env.pop('MOTION_LOG',None);env['CUDA_VISIBLE_DEVICES']=''
home=root/'.tools/ai-depth74'
for key,folder in [('TEMP','temp'),('TMP','temp'),('TORCH_HOME','torch-cache'),('HF_HOME','hf-cache'),('TORCHINDUCTOR_CACHE_DIR','inductor-cache'),('PYTHONPYCACHEPREFIX','pycache')]:
    env[key]=str(home/folder)
ffbin=root/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
env['PATH']=str(ffbin)+os.pathsep+env['PATH']
report=dict(head=build['head'],source=build['source'],binarySha256=sha(binary),commands=[],
            startedUtc=datetime.now(timezone.utc).isoformat(),referenceMode='Pinned independent PyTorch golden; not executed again',
            referenceReceiptSha256=sha(old/'verified.json'),referenceGoldenSha256=sha(golden),
            limits=['Actual Session pipeline, not the GUI Engine or render-depth binding',
                    'Default Rust Session worker thread; earlier Windows process-main stack overflow remains retained, not repaired',
                    'CPU provider only; no Android, GPU provider, zero-copy or calibrated physical depth claim',
                    'Does not replace failed full host/media or desktop regression'])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
(out/'build-receipt.json').write_bytes((builddir/'exit.json').read_bytes())
for rel in ('Cargo.toml','Cargo.lock','src/main.rs'):
    dest=out/'probe'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((probe/rel).read_bytes())
report['runtimeDlls']={}
for dll in ffbin.glob('*.dll'):
    dest=binary.parent/dll.name
    if not dest.exists():dest.write_bytes(dll.read_bytes())
    assert sha(dest)==sha(dll)
    report['runtimeDlls'][dll.name]=sha(dest)
assert sha(home/'models/depth_anything_v2_vits_518.onnx')==old_receipt['onnxSha256']
assert sha(home/'models/depth_anything_v2_vits.pth')==old_receipt['weightSha256']
report.update(onnxSha256=old_receipt['onnxSha256'],weightSha256=old_receipt['weightSha256'])
def save(): (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def run(name,cmd,timeout=180):
    assert source()==build['source']
    row=dict(name=name,command=cmd);report['commands'].append(row);save()
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        p=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr)
        row['pid']=p.pid;save();row['exitCode']=p.wait(timeout=timeout)
    save();assert row['exitCode']==0,name
    return (out/(name+'.stdout.log')).read_bytes()
started=time.monotonic()
try:
    for name,fixture,mode in [('known','known/project/assets/source.mp4','inspect-color'),
                              ('unknown','unknown/project/assets/source.mp4','reject-color'),
                              ('inference','known/project/assets/source.mp4','inference')]:
        dest=out/name/'project/assets/source.mp4';dest.parent.mkdir(parents=True)
        dest.write_bytes(verified(color,color_receipt,fixture).read_bytes())
        run(name,[str(binary),str(out/name),mode])
        assert not (out/(name+'.stdout.log')).read_bytes()
        log=(out/name/'logs/motion-studio.log').read_text(encoding='utf-8')
        stderr=(out/(name+'.stderr.log')).read_text(encoding='utf-8')
        assert 'logging initialized level=INFO' in log
        assert log.index('start #1 depth_infer asset=74')<log.index('ERROR')
        for stream in (log,stderr):
            assert 'request=1 operation=depth_infer asset=74' in stream
            assert 'stage='+('backend' if name=='known' else 'source_prepare') in stream
        assert 'start #1' not in stderr and 'logging initialized' not in stderr
    expected_rgb=verified(color,color_receipt,'known/input.rgb').read_bytes()
    assert (out/'known/input.rgb').read_bytes()==expected_rgb
    assert (out/'inference/input.rgb').read_bytes()==expected_rgb
    assert not (out/'unknown/input.rgb').exists()
    result=json.loads((out/'inference/result.json').read_text())
    assert result['actualSession'] and result['actualNativeFfmpeg'] and result['actualInference'] and result['seekInvalidated']
    assert result['provider']=='CPUExecutionProvider' and result['targetUs']==76667 and result['actualPtsUs']==50000
    assert 'video cache missing' in result['negative']
    expected=np.fromfile(golden,'<f4');actual=np.fromfile(out/'inference/output.f32','<f4')
    assert len(actual)==52*80 and np.isfinite(actual).all()
    error=np.abs(actual.astype(np.float64)-expected.astype(np.float64));amp=max(float(np.abs(expected).max()),1e-6)
    maximum=float(error.max())/amp;mean=float(error.mean())/amp
    assert maximum<=2e-4 and mean<=2e-5,(maximum,mean)
    Image.fromarray(np.frombuffer(expected_rgb,np.uint8).reshape(80,52,3)).save(out/'prepared-source.png')
    Image.fromarray(np.rint((actual-actual.min())/max(float(np.ptp(actual)),1e-6)*255).astype(np.uint8).reshape(80,52)).save(out/'relative-depth.png')
    report.update(result=result,maxNormalized=maximum,meanNormalized=mean,maxBound=2e-4,meanBound=2e-5,
                  acceptedSrgbInputBitExact=True,unknownRejectedBeforeBackend=True,
                  defaultInfoStart=True,errorFileAndStderr=True,stdoutEmpty=True,status='passed')
except BaseException as error:
    report.update(status='failed_original_outputs_retained',failure=repr(error));raise
finally:
    report.update(sourceUnchanged=source()==build['source'],elapsedSeconds=round(time.monotonic()-started,3),
                  completedUtc=datetime.now(timezone.utc).isoformat())
    save()
assert report['sourceUnchanged']
report['artifacts']={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()}
(out/'verified.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('source','artifacts','commands')}))
