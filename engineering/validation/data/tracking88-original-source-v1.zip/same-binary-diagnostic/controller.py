"""Observe original child modes on the retained binary, never rerun acceptance."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,subprocess

ROOT=Path('E:/Dev/aem')
GATE=ROOT/'artifacts/pr-queue/tracking88-source-v1'
OUT=ROOT/'artifacts/pr-queue/tracking88-pressure-child-diagnostic-v1'
PRIVATE=GATE/'private-native-failure'
rows=json.loads((PRIVATE/'retention.json').read_text(encoding='utf-8'))
exe=next(x for x in rows if x['name'].endswith('.exe'))
binary=PRIVATE/exe['name']
assert hashlib.sha256(binary.read_bytes()).hexdigest()==exe['sha256']
gate=json.loads((GATE/'exit.json').read_text(encoding='utf-8'))
assert gate.get('completedUtc') and gate['status']=='failed'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='diagnosing_retained_binary_not_acceptance',startedUtc=datetime.now(timezone.utc).isoformat(),
    binarySha256=exe['sha256'],steps=[],originalGate='failed_178_passed_1_failed',
    limits='One observation per original child mode; records actual ExitStatus. Later passes cannot establish the cause of the original access violation or qualify host regression.')
env=os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(TEMP=str(ROOT/'target/ci-policy-validation-tmp'),TMP=str(ROOT/'target/ci-policy-validation-tmp'),RUST_BACKTRACE='full')
name='session::preview_pressure::tests::default_pressure_events_are_bounded_reset_and_leave_session_locks_before_logging'
for mode in ['return','panic']:
    childenv=env.copy();childenv['MOTION_PREVIEW_PRESSURE_SCOPE_CHILD']=mode
    args=[str(binary),'--exact',name,'--nocapture','--test-threads=1']
    with (OUT/f'{mode}.stdout.log').open('wb') as stdout,(OUT/f'{mode}.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(args,cwd=ROOT/'.worktrees/tracking-import88',env=childenv,stdout=stdout,stderr=stderr)
        code=child.wait()
    row=dict(mode=mode,pid=child.pid,exitCode=code,exitHex=f'0x{code&0xffffffff:08x}')
    report['steps'].append(row)
    print(json.dumps(row),flush=True)
report.update(status='diagnostic_collected_original_regression_still_failed',completedUtc=datetime.now(timezone.utc).isoformat())
(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
