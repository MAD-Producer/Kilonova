from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, shutil, zipfile

root = Path('E:/Dev/aem')
work = root/'.worktrees/native-camera-dof'
out = root/'artifacts/pr-queue/scene87-composition-disposition-v1'
prior_path = root/'artifacts/pr-queue/native-camera-dof-regression-v2/accepted.json'
prior = json.loads(prior_path.read_text(encoding='utf-8'))
head = '594e810df818bdafe34f0b9c08455828168b634a'
assert prior['head'] == head and prior['sourceUnchanged'] and prior['distinctPassed'] == 1041
assert not prior['unexecutedIgnored'] and all(step['exitCode'] == 0 for step in prior['steps'])
for path, digest in prior['source'].items():
    assert hashlib.sha256((work/path).read_bytes()).hexdigest() == digest, path
ci = json.loads((out/'own-ci-run.json').read_text(encoding='utf-8-sig'))
job = json.loads((out/'own-ci-job.json').read_text(encoding='utf-8-sig'))
assert ci['head_sha'] == head and ci['conclusion'] == 'success' and ci['status'] == 'completed'
assert job['id'] == 123355344568 and job['conclusion'] == 'success' and job['status'] == 'completed'
native = (root/'artifacts/pr-queue/native-camera-dof-regression-v2/render-regression.stdout.log').read_text(encoding='utf-8')
logs = dict(native=native, ci=(out/'own-ci-rust-gpu.log').read_text(encoding='utf-8-sig'))
rows = [
    ('A2.mix', 'native', 'project_shared::mixed_planes::mixed_plane_mesh_intersections_use_fragment_depth_in_both_authored_orders', 'tests/model_layers/mixed_planes.rs', 'Actual opaque plane/mesh intersection in both authored orders'),
    ('A2.parent-camera', 'native', 'project_shared::mixed_planes::mixed_plane_camera_and_parent_depth_match_independent_world_ray_intersections', 'tests/model_layers/mixed_planes.rs', 'Independent world-ray intersections after camera and shared parent transforms'),
    ('A2.precision-msaa', 'native', 'project_shared::mixed_planes::mixed_plane_four_precisions_and_msaa_match_independent_surface_colors', 'tests/model_layers/mixed_planes.rs', 'Four working precisions and one/four samples against independent colors'),
    ('A2.pending', 'native', 'project_shared::mixed_planes::mixed_plane_pending_animated_geometry_remains_immutable_for_reverse_and_abandoned_frames', 'tests/model_layers/mixed_planes.rs', 'Reverse/abandoned frames retain their own geometry and reservations'),
    ('A2.imported-rig', 'native', 'imported_cameras::imported_camera_resolves_parent_rig_children_layer_clock_and_observer', 'tests/model_layers/imported_cameras.rs', 'Imported camera rig, child, clock and observer are explicit'),
    ('A2.imported-nesting', 'native', 'imported_cameras::imported_camera_catalog_follows_nested_composition_fps_and_exposure_receiver_clocks', 'tests/model_layers/imported_cameras.rs', 'Imported source clocks through nested composition and exposure receivers'),
    ('A2.matte-modes', 'native', 'calibrated_mattes::calibrated_receiver_four_matte_modes_use_screen_coverage_before_depth', 'tests/depth_surface/calibrated_mattes.rs', 'Alpha/luma/inverted matte coverage precedes physical depth'),
    ('A2.matte-projection', 'native', 'ordinary_calibrated_mattes::ordinary_receiver_reads_independent_calibrated_matte_after_camera_edits', 'tests/depth_surface/ordinary_calibrated_mattes.rs', 'Ordinary receiver reads independent calibrated matte after camera edits'),
    ('A2.shared-matte', 'native', 'shared_matte_inputs::shared_matte_image_feeds_ordinary_and_calibrated_receivers_in_four_precisions', 'tests/depth_surface/shared_matte_inputs.rs', 'Independent processed inputs retain shared-source physical depth'),
    ('A2.2d-mask', 'native', 'composition_boundaries::unrelated_masked_2d_overlay_preserves_shared_depth_and_its_own_coverage', 'tests/depth_surface/composition_boundaries.rs', 'Unrelated masked 2D overlay preserves its own coverage'),
    ('A2.2d-matte', 'native', 'composition_boundaries::unrelated_matte_2d_overlay_keeps_source_and_depth_rasters_independent', 'tests/depth_surface/composition_boundaries.rs', 'Unrelated 2D matte stays independent of shared depth'),
    ('A2.2d-inputs', 'native', 'composition_effects::unrelated_external_image_inputs_keep_source_and_effects_stages_independent', 'tests/depth_surface/composition_effects.rs', 'External-input source and effects-stage rasters remain distinct'),
    ('A2.2d-blend', 'native', 'composition_blend::unrelated_blend_preserves_depth_and_authored_order_in_both_color_spaces', 'tests/depth_surface/composition_blend.rs', 'Unrelated 2D blend keeps stacking in both blend spaces'),
    ('A2.bsp-rays', 'ci', 'independently_sampled_cameras_sort_intersections_by_projected_depth_in_direct_and_effect_paths', 'tests/projected_planes.rs', 'Existing plane BSP matches independent depth/alpha rays across camera modes, effects and authored orders'),
    ('A2.bsp-uv', 'ci', 'split_perspective_uvs_match_an_unsplit_textured_plane_without_changing_the_vertex_abi', 'tests/projected_planes.rs', 'Existing perspective UV split and vertex ABI controls'),
    ('A2.bsp-clip', 'ci', 'homogeneous_clipping_handles_camera_plane_crossings_and_culls_normal_outside_geometry', 'tests/projected_planes.rs', 'Existing homogeneous clipping at camera boundaries'),
    ('A2.bsp-matte', 'ci', 'rotated_three_d_matte_uses_the_same_camera_projection_as_the_target', 'tests/layer_compositing.rs', 'Existing rotated spatial matte projection'),
    ('87.4.zero-aperture', 'native', 'depth_of_field::a_single_owned_model_uses_saved_camera_aperture_and_disabled_aperture_is_exact', 'tests/model_layers/depth_of_field.rs', 'Saved aperture and exact disabled-aperture recovery'),
    ('87.4.calibrated-aperture', 'native', 'depth_of_field::saved_animated_aperture_focuses_calibrated_near_and_far_surface_in_four_precisions', 'tests/depth_surface/depth_of_field.rs', 'Actual calibrated near/far geometry and animated focus in four precisions'),
]
cases = []
for identity, log, test, source, scope in rows:
    assert re.search(r'\btest '+re.escape(test)+r' \.\.\. ok\s*$', logs[log], re.M), (identity, test)
    path = 'crates/motion-render/'+source
    data = (work/path).read_bytes()
    assert ('fn '+test.rsplit('::', 1)[-1]).encode() in data, path
    cases.append(dict(id=identity, source=path, sourceSha256=hashlib.sha256(data).hexdigest(),
        test=test, actualLog=log, scope=scope, status='executed-pass'))
    dest = out/'source'/path
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(work/path, dest)
for path in ['crates/motion-render/src/renderer/model_layers/shared.rs', 'crates/motion-render/src/renderer/model_layers.rs']:
    if (work/path).is_file():
        dest = out/'source'/path
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(work/path, dest)
shutil.copyfile(__file__, out/'controller.py')
shutil.copyfile(prior_path, out/'source-bound-related-receipt.json')
shutil.copyfile(root/'artifacts/pr-queue/native-camera-dof-regression-v2/render-regression.stdout.log', out/'native-related.stdout.log')
receipt = dict(completedUtc=datetime.now(timezone.utc).isoformat(), head=head,
    acceptedMain='ed1a84a4d22465601564c761ebdf3a8b01db88de', cases=cases,
    sourceUnchanged=True, independentNewTestCount=0,
    relatedReceipt='native-camera-dof-regression-v2/accepted.json',
    ownCiRun=40846551127, ownCiJob=123355344568,
    scope='Original87 mixed/parent/camera/matte/BSP representative acceptance and explicit profile disposition; execution excerpts are reused, never added as new test coverage',
    limitations=['General intersecting translucency retains sorted-alpha limitations',
        'Unproven calibrated nested/effect/exposure combinations are not claimed implemented',
        'Positive aperture with blended or orthographic geometry remains explicitly unsupported',
        'New desktop model import and the full local maintained workspace remain separate pending gates',
        'No Android acceptance; later optional scene nodes, RT and volumes are excluded'])
(out/'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
archive = root/'artifacts/pr-queue/scene87-final-acceptance-staging/data/scene3d-composition-disposition-v1.zip'
assert not archive.exists()
files = sorted(path for path in out.rglob('*') if path.is_file())
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in files:
        z.write(path, path.relative_to(out).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for path in files:
        assert z.read(path.relative_to(out).as_posix()) == path.read_bytes()
print(json.dumps(dict(accepted=True, verifiedExistingCases=len(cases), newTestCoverage=0,
    archive=str(archive), bytes=archive.stat().st_size, entries=len(files),
    sha256=hashlib.sha256(archive.read_bytes()).hexdigest())), flush=True)
