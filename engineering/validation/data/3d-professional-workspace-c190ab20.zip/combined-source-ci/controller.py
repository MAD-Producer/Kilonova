from pathlib import Path
from datetime import datetime,timezone
import concurrent.futures, hashlib,json,subprocess

root=Path('E:/Dev/aem')
out=root/'artifacts/pr-queue/tracking88-ci-green-c190ab20-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
repo='repos/MAD-Producer/motion-studio'
run_id=42015343857
head='c190ab209abdefce4511486f1f51020599312e8a'
def api(path):
    failures=[]
    for attempt in range(1,4):
        try:
            return subprocess.check_output(['gh','api',repo+path],stderr=subprocess.PIPE,timeout=45)
        except (subprocess.CalledProcessError,subprocess.TimeoutExpired) as error:
            failures.append(dict(attempt=attempt,error=type(error).__name__,
                                 stderr=(error.stderr or b'').decode(errors='replace')[:2048]))
    raise RuntimeError('Remote metadata retrieval failed, not workflow failure: '+json.dumps(failures))
run=api(f'/actions/runs/{run_id}')
metadata=json.loads(run)
(out/'run.json').write_bytes(run)
assert metadata['status']=='completed' and metadata['conclusion']=='success' and metadata['head_sha']==head
jobs=api(f'/actions/runs/{run_id}/jobs')
(out/'jobs.json').write_bytes(jobs)
report=dict(head=head,run=run_id,runConclusion='success',status='collecting',jobs=[],startedUtc=datetime.now(timezone.utc).isoformat(),
            limits=['Original remote head only, not rebased/local later source',
                    'PR workflow omits FFmpeg/model runtime acceptance; feature-enabled local execution is independently recorded'])
def save():
    (out/'receipt.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def collect(job):
    assert job['status']=='completed' and job['conclusion'] in ('success','skipped')
    row=dict(id=job['id'],name=job['name'],conclusion=job['conclusion'])
    if job['conclusion']=='success':
        p=out/f"job-{job['id']}.log"
        row['retrievalAttempts']=[]
        for attempt in range(1,4):
            attempt_path=out/f"job-{job['id']}.attempt-{attempt}.log"
            with attempt_path.open('wb') as log:
                try:
                    result=subprocess.run(['gh','api',repo+f"/actions/jobs/{job['id']}/logs"],stdout=log,stderr=subprocess.PIPE,timeout=60)
                    code,details=result.returncode,result.stderr
                except subprocess.TimeoutExpired as error:
                    code,details=124,b'Retrieval observation timed out; original workflow is already successful\n'+(error.stderr or b'')
            row['retrievalAttempts'].append(dict(attempt=attempt,exit=code,bytes=attempt_path.stat().st_size,
                                                 sha256=hashlib.sha256(attempt_path.read_bytes()).hexdigest()))
            if code==0:
                p.write_bytes(attempt_path.read_bytes())
                break
            (out/f"job-{job['id']}.attempt-{attempt}.stderr.log").write_bytes(details)
        assert code==0,(job['id'],details.decode(errors='replace'))
        row.update(log=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),retrievalExit=result.returncode)
    return row
save()
try:
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for row in pool.map(collect,json.loads(jobs)['jobs']):
            report['jobs'].append(row)
            save()
    report['status']='prior_remote_run_green_logs_collected'
except BaseException as error:
    report.update(status='retrieval_failed_original_outputs_retained',failure=repr(error))
    raise
finally:
    report['completedUtc']=datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps(report))
