from pathlib import Path
import hashlib,json,re
root=Path('E:/Dev/aem/artifacts/pr-queue/tracking88-ci-green-c190ab20-v1')
receipt=json.loads((root/'receipt.json').read_text(encoding='utf-8'))
tests=['photographed_screen_opacity_history_reopen_and_frozen_output_match_independent_reference','chroma_sample_public_api_preserves_alpha_local_animation_history_reopen_and_frozen_output','footage::photographed_key_with_manual_holdout_history_reopen_and_frozen_png_keep_fixed_controls']
tests += [
 'depth::onnx::tests::actual_child_keeps_protocol_and_diagnostics_in_separate_pipes',
 'depth::onnx::tests::actual_failed_child_retains_exit_response_and_bounded_diagnostic_tail',
 'depth::onnx::tests::actual_protocol_overflow_terminates_the_child_and_reaps_its_pipes',
 'depth::onnx::tests::cancellation_after_real_child_entry_reaps_the_process_before_returning',
 'parameter_animation::declared_parameter_matrix_matches_actual_key_and_expression_admission',
 'parameter_animation::numeric_and_discrete_tracks_keep_offsets_atomic_history_and_reopen_contract',
 'parameter_animation::curve_tracks_advertise_lut_interpolation_and_sample_it_after_reopen',
 'parameter_animation::enum_keys_hold_until_the_boundary_and_layer_lock_is_separate_from_schema_support',
 'parameter_animation::declared_cross_parameter_references_use_local_keys_and_reject_cycles_atomically',
 'project_clock::tests::canonical_and_reduced_snapshot_rates_keep_exact_clock_identity',
 'project_clock::tests::component_errors_identify_the_field_without_rendering_user_payloads',
 'project_clock::tests::composition_bounds_compare_exact_ratios_instead_of_integer_truncation',
 'project_clock::tests::incomplete_numeric_and_unknown_field_clocks_never_become_thirty_fps',
 'project_clock::tests::zero_and_component_limit_failures_retain_the_native_rate_cause',
]
assert receipt['head']=='c190ab209abdefce4511486f1f51020599312e8a' and receipt['run']==42015343857
assert receipt['status']=='prior_remote_run_green_logs_collected'
rows=[]
for job in receipt['jobs']:
 if not job['name'].startswith('Desktop tests'):continue
 assert job['conclusion']=='success'
 p=root/job['log'];assert hashlib.sha256(p.read_bytes()).hexdigest()==job['sha256']
 lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
 selected=list(tests)
 if 'windows-2022' in job['name']:
  selected += ['shell::rational_clock_native_tests::fractional_project_clocks_render_native_readouts_in_both_locales',
               'shell::rational_clock_native_tests::settings::rational_rate_settings_native_dropdown_cancel_apply_and_history']
 evidence={name:[line for line in lines if 'test '+name+' ... ok' in line] for name in selected}
 assert all(len(hits)==1 for hits in evidence.values()),evidence
 command=[line for line in lines if 'cargo test -p motion-desktop -p motion-host -p motion-ui -p motion-desktop-media --locked --features' in line]
 assert command
 summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',p.read_text(encoding='utf-8',errors='replace'))
 assert all(s[1]=='0' for s in summaries)
 rows.append(dict(job=job['id'],name=job['name'],evidence=evidence,command=command[0],observedSummaries=len(summaries),observedPassed=sum(int(s[0]) for s in summaries),observedOriginalIgnores=sum(int(s[2]) for s in summaries)))
assert len(rows)==3
report=dict(head=receipt['head'],run=receipt['run'],status='seventeen_named_key_clock_parameter_and_child_controls_pass_on_three_native_platforms_with_two_additional_Windows_Surface_controls',platforms=rows,limits=['Exact combined c190ab20 only; whole run completed success, all eight required jobs succeeded','Observed log totals include platform GPU/memory adapter prechecks and desktop packages; not entire workspace','PR excludes FFmpeg runtime and actual ONNX model; original native failures remain historical unresolved failures'])
assert not (root/'requirement-controls-execution-coverage.json').exists()
(root/'requirement-controls-execution-coverage.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='platforms'}));print([(r['name'],r['observedPassed'],r['observedSummaries']) for r in rows])
