"""Bind named requirement controls to terminal source-bound execution evidence.

This receipt is a navigation/coverage check, never whole-issue completion or a
substitute for reviewing numerical/image evidence and the failed tracker gate.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-colmap88'
ART = ROOT / 'artifacts/pr-queue'
HEAD = 'c190ab209abdefce4511486f1f51020599312e8a'
GATE = ART / 'tracking88-workspace-main-integration-v4'
OUT = ART / '3d-route-c190ab20-requirement-evidence-v1'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
full = json.loads((GATE / 'exit.json').read_text(encoding='utf-8'))
assert full['status'] == 'complete_maintained_workspace_passed'
assert full['exitCode'] == 0 and full['sourceUnchanged'] and full['baseCommit'] == HEAD
assert full['totals']['failed'] == full['totals']['filtered'] == 0
assert full['totals']['targets'] == 417
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == HEAD
ci_path = ART / 'tracking88-ci-green-c190ab20-v1/receipt.json'
ci = json.loads(ci_path.read_text(encoding='utf-8'))
assert ci['head'] == HEAD and ci['run'] == 42015343857
assert ci['status'] == 'prior_remote_run_green_logs_collected'
inference_path = ART / 'depth74-inferred-render-c190ab20-v1/exit.json'
inference = json.loads(inference_path.read_text(encoding='utf-8'))
assert inference['head'] == HEAD and inference['status'] == 'passed_native_and_independent_oracle'
assert inference['sourceUnchanged'] and inference['fullWorkspaceSourceMatches']
controls = [
    (74, 'async flight before blocking backend', 'crates/motion-host/tests/depth_jobs.rs', 'blocked_depth_publishes_flight_before_backend_and_retains_only_latest_pending_sample'),
    (74, 'cancel and recovery', 'crates/motion-host/tests/depth_jobs.rs', 'cancel_without_replacement_rejects_late_success_then_recovers'),
    (74, 'source/revision/seek/model admission', 'crates/motion-host/tests/depth_jobs.rs', 'live_source_revision_seek_model_processing_and_geometry_are_checked_at_installation'),
    (74, 'actual image preparation', 'crates/motion-host/tests/depth_session.rs', 'actual_managed_png_is_cropped_rotated_mirrored_off_owner_thread'),
    (74, 'seek rejects stale success', 'crates/motion-host/tests/depth_session.rs', 'seek_cancels_blocked_inference_and_same_static_key_cannot_install_old_ticket'),
    (74, 'video original PTS/geometry', 'crates/motion-host/tests/depth_video.rs', 'variable_rate_sample_uses_actual_decoder_pts_and_explicit_crop_orientation'),
    (85, 'bounded canonical clock and strict wire', 'crates/motion-model/tests/frame_rate.rs', 'canonical_rates_have_exact_identity_and_strict_validated_wire_format'),
    (85, 'integer timestamp preservation', 'crates/motion-model/tests/rational_project_clock.rs', 'integer_project_output_timestamps_keep_the_original_rounding_at_every_frame'),
    (85, 'long sequence/audio exact clock', 'crates/motion-model/tests/frame_rate.rs', 'ntsc_rates_map_long_sequences_and_audio_without_accumulated_drift'),
    (85, 'independent drop-label enumeration', 'crates/motion-model/tests/timecode.rs', 'every_drop_label_in_one_hour_matches_an_independent_forward_label_counter'),
    (85, 'one media-leaf rounding', 'crates/motion-model/tests/rational_project_clock.rs', 'nested_fractional_frames_quantize_once_at_the_media_leaf'),
    (85, 'nested absolute PCM sample edges', 'crates/motion-model/tests/rational_project_clock.rs', 'nested_audio_origins_and_work_area_use_exact_absolute_sample_edges'),
    (85, 'explicit frame/seconds edit policy', 'crates/motion-model/tests/rational_project_clock.rs', 'fps_changes_require_an_explicit_policy_and_keep_frames_or_seconds'),
    (85, 'actual encoded native timestamps/audio', 'crates/motion-desktop-media/tests/rational_export_clock.rs', 'fractional_rates_survive_native_mp4_timestamps_and_audio_boundaries'),
    (86, 'advertised parameter types match admission', 'crates/motion-host/tests/layer_time_mapping/parameter_animation.rs', 'declared_parameter_matrix_matches_actual_key_and_expression_admission'),
    (86, 'discrete/numeric offsets/history/reopen', 'crates/motion-host/tests/layer_time_mapping/parameter_animation.rs', 'numeric_and_discrete_tracks_keep_offsets_atomic_history_and_reopen_contract'),
    (86, 'enum keys hold', 'crates/motion-host/tests/layer_time_mapping/parameter_animation.rs', 'enum_keys_hold_until_the_boundary_and_layer_lock_is_separate_from_schema_support'),
    (86, 'cross-parameter local clock and cycle rejection', 'crates/motion-host/tests/layer_time_mapping/parameter_animation.rs', 'declared_cross_parameter_references_use_local_keys_and_reject_cycles_atomically'),
    (86, 'compiled node parameters/native/frozen', 'crates/motion-desktop-media/tests/node_parameter_animation.rs', 'compiled_node_parameters_animate_render_reopen_and_freeze_with_owned_runtime'),
    (86, 'MG camera/native frozen movie', 'crates/motion-desktop-media/tests/professional_compositing.rs', 'host_camera_effect_animation_matches_reopened_and_frozen_outputs_after_live_edits'),
    (86, 'animated source masks/four mattes/precompose', 'crates/motion-desktop-media/tests/professional_mattes.rs', 'animated_source_masks_and_four_mattes_preserve_goldens_through_precompose_and_freeze'),
    (86, 'real image relink/history/frozen ownership', 'crates/motion-desktop-media/tests/professional_relink.rs', 'public_relink_refreshes_pixels_and_preserves_history_missing_recovery_and_frozen_sources'),
    (86, 'animated supplied screen corners', 'crates/motion-desktop-media/tests/professional_screen.rs', 'animated_screen_insert_matches_independent_projective_goldens_and_frozen_outputs'),
    (86, 'photographed static screen independent reference', 'crates/motion-desktop-media/tests/professional_screen_photo.rs', 'photographed_screen_opacity_history_reopen_and_frozen_output_match_independent_reference'),
    (86, 'chroma SDK sample/public history/reopen/frozen', 'crates/motion-desktop-media/tests/professional_key.rs', 'chroma_sample_public_api_preserves_alpha_local_animation_history_reopen_and_frozen_output'),
    (88, 'canonical imported camera/original document/time', 'crates/motion-model/tests/tracking_colmap.rs', 'exact_original_bytes_clock_identity_and_missing_frames_survive_canonical_roundtrip'),
    (88, 'world-to-camera inversion', 'crates/motion-model/tests/tracking_colmap.rs', 'hamilton_world_to_camera_is_inverted_instead_of_relabelled'),
    (88, 'axes/units/origin exactly once', 'crates/motion-model/tests/tracking_colmap.rs', 'declared_world_axes_scale_and_origin_are_applied_once'),
    (88, 'declared lens coefficients', 'crates/motion-model/tests/tracking_colmap.rs', 'five_supported_models_preserve_pixel_origin_and_all_declared_coefficients'),
    (88, 'fractional PTS/off-centre camera reprojection', 'crates/motion-model/tests/tracking_camera.rs', 'off_centre_anisotropic_intrinsics_and_original_fractional_pts_reproject_known_world_points'),
    (88, 'crop/rotation/depth independent camera control', 'crates/motion-model/tests/tracking_camera.rs', 'calibrated_projection_matches_independent_crop_rotation_and_near_far_depth'),
    (88, 'manual correction and parent/focal composition', 'crates/motion-model/tests/tracking_camera.rs', 'authored_keyed_corrections_parent_and_focal_multiplier_are_composed_once'),
    (88, 'independent photographed GPU/lens controls', 'crates/motion-render/tests/tracking_lens/photographed.rs', 'photographed_board_replacement_and_held_out_corners_match_native_gpu_output'),
]
stdout = (GATE / 'stdout.log').read_text(encoding='utf-8', errors='replace')
rows = []
for issue, requirement, source, name in controls:
    text = (WORK / source).read_text(encoding='utf-8')
    assert sha(WORK / source) == full['source'][source]
    assert re.search(r'\bfn\s+' + re.escape(name) + r'\s*\(', text), (source, name)
    matches = re.findall(r'^test ((?:[A-Za-z_0-9]+::)*' + re.escape(name) + r') \.\.\. ok\s*$', stdout, re.M)
    assert len(matches) == 1, (issue, name, matches)
    rows.append(dict(issue=issue, requirement=requirement, source=source,
                     sourceSha256=sha(WORK / source), actualPassedTest=matches[0]))
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='named_source_bound_controls_verified_not_whole_issue_completion', head=HEAD,
              observedUtc=datetime.now(timezone.utc).isoformat(),
              fullWorkspaceReceiptSha256=sha(GATE / 'exit.json'),
              fullStdoutSha256=sha(GATE / 'stdout.log'), ciReceiptSha256=sha(ci_path),
              actualInferenceReceiptSha256=sha(inference_path), controls=rows,
              limitations=['Test names are navigation evidence; original numerical, image, provenance and API limits remain required',
                           'Retained full real-sequence tracker quality remains failed, not accepted by import controls',
                           'Historical domain/reference studies retain their original sources, not a newly executed matrix',
                           'Original ignores and failures are retained; no Android acceptance',
                           'No claim of full 3D solver, arbitrary footage/HDR equivalence, automatic roto or entire 3D-route completion'])
(OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k != 'controls'}))
