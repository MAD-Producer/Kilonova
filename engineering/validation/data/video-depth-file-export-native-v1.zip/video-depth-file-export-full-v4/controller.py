from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,re,shutil,subprocess
root=Path('E:/Dev/aem'); work=root/'.worktrees/video-depth-geometry'
out=root/'artifacts/pr-queue/video-depth-file-export-full-v4'; out.mkdir(exist_ok=False)
env=os.environ.copy(); env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true',MOTION_VIDEO_DEPTH_TIMELINE_ARTIFACTS=str(out/'timeline-renders'),MOTION_REAL_VIDEO_DEPTH_ARTIFACTS=str(out/'codec-renders'),MOTION_FROZEN_DEPTH_ARTIFACTS=str(out/'static-renders'),MOTION_KEY_TIMING_MOVIE_ARTIFACTS=str(out/'manual-renders'))
env.pop('MOTION_LOG',None)
git=lambda *args:subprocess.check_output(['git',*args],cwd=work).decode().strip()
def sources():
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=work).decode().split('\0')
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml')) or p=='Cargo.lock')}
source=sources()
for p in set(git('diff','--name-only','HEAD').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()):
    if p in source:
        dest=out/'source'/p; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(work/p,dest)
shutil.copyfile(__file__,out/'controller.py')
report=dict(base=git('rev-parse','HEAD'),source=source,steps=[],scope='Archived scalar snapshot capture, streaming bounded file-plane persistence and independent real-codec PNG/MP4 after live eviction and original/session removal; five-second beyond-cache fixture, not sustained playback, trained model quality, complex depth, DOF or final full-workspace/cross-platform acceptance')
tests=lambda *args:['cargo','test',*args,'--locked','--offline','--','--test-threads=1']
steps=[
 ('host-library',tests('-p','motion-host','--features','ai-depth','--lib')),
 ('video',tests('-p','motion-host','--features','ai-depth','--test','depth_video')),
 ('session',tests('-p','motion-host','--features','ai-depth','--test','depth_session')),
 ('jobs',tests('-p','motion-host','--features','ai-depth','--test','depth_jobs')),
 ('media',tests('-p','motion-desktop-media','--lib','--features','ffmpeg,gpu-tests,ai-depth')),
 ('manual-key-timing',['cargo','test','-p','motion-desktop-media','--lib','--features','ffmpeg,gpu-tests,ai-depth','--locked','--offline','--','--ignored','--exact','movie::keyframe_timing_tests::frozen_keyframe_timing_matches_reopened_pixels_and_differs_from_linear_and_removed_layer','--test-threads=1']),
 ('model',tests('-p','motion-model','--test','depth_saved','--test','depth_video_track','--test','depth_prepared')),
 ('without-depth',['cargo','check','-p','motion-host','--no-default-features','--locked','--offline']),
 ('desktop',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),
 ('style',['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
 ('provenance',['python','tools/validate_provenance.py']),
]
minimum={'host-library':124,'video':22,'session':17,'jobs':8,'media':59,'manual-key-timing':1,'model':8}
previous=root/'artifacts/pr-queue/video-depth-file-export-full-v3'
prior=json.loads((previous/'exit.json').read_text(encoding='utf-8'))
assert prior['source']==source
completed={row['name']:row for row in prior['steps']}
for name,command in steps:
    if name in completed:
        row=completed[name]
        assert row['command']==command and row['exitCode']==0 and row['sourceUnchanged']
        for stream in ['stdout','stderr']:
            shutil.copyfile(previous/f'{name}.{stream}.log',out/f'{name}.{stream}.log')
        row=dict(row, importedFrom=str(previous), logsSha256={stream:hashlib.sha256((out/f'{name}.{stream}.log').read_bytes()).hexdigest() for stream in ['stdout','stderr']})
        report['steps'].append(row)
        continue
    print(json.dumps(dict(start=name)),flush=True)
    with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
        code=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
    row=dict(name=name,command=command,exitCode=code,sourceUnchanged=sources()==source)
    if name in minimum: row['counts']=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',(out/f'{name}.stdout.log').read_text(encoding='utf-8'))
    report['steps'].append(row); report['completedUtc']=datetime.now(timezone.utc).isoformat()
    (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8'); print(json.dumps(row),flush=True)
    assert code==0 and row['sourceUnchanged'],name
    if name in minimum:
        assert row['counts'] and sum(int(p) for p,_,_ in row['counts'])>=minimum[name],row
        assert all(int(f)==0 and int(i)==(1 if name=='media' else 0) for _,f,i in row['counts']),row
report['mediaIgnoredManualExecuted']=True
report['distinctPassed']=sum(int(p) for row in report['steps'] for p,_,_ in row.get('counts',[]))
comparison=json.loads((out/'codec-renders/temporal-150/comparison.json').read_text(encoding='utf-8'))
assert comparison['frames']==comparison['storedSamples']==len(comparison['absoluteDifferences'])==150
assert comparison['backendCalls']==300 and comparison['liveSamples']==128 and comparison['sessionAndOriginalGone'] and comparison['persistentRestore']
report['temporal150Comparison']=comparison
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
