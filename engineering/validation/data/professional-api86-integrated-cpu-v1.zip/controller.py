from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, sys, time
root=Path('E:/Dev/aem')
work=root/'.worktrees/rational-frame-rates85'
out=root/'artifacts/pr-queue/professional-api86-integrated-cpu-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','-z','crates','desktop','Cargo.toml','Cargo.lock'],cwd=work).decode().split('\0')
sources={name:sha(work/name) for name in names if name and (work/name).is_file()}
report=dict(status='running',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),sources=sources,results=[],startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Complete model/core targets plus desktop all-target check and helper check; no GPU execution, no final desktop/render regression or cross-platform acceptance claim','No assertions, budgets, ignore markers, retries or filters changed'])
assert report['head'].startswith('7f40d752')
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n')
commands=[('model-core',['cargo','test','-p','motion-model','-p','motion-core','--no-fail-fast','--locked','--offline','--','--test-threads=1']),('desktop-check',['cargo','check','-p','motion-desktop','--all-targets','--locked','--offline']),('helper-check',[sys.executable,'tools/build_desktop.py','--task','check','--debug','--target-dir',os.environ['CARGO_TARGET_DIR'],'--','--offline'])]
save()
try:
    for name,command in commands:
        item=dict(name=name,command=command,status='running')
        report['results'].append(item);save();began=time.monotonic()
        with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
            process=subprocess.Popen(command,cwd=work,stdout=stdout,stderr=stderr,env=os.environ.copy())
            item['pid']=process.pid;save();item['exitCode']=process.wait()
        item.update(status='passed' if item['exitCode']==0 else 'failed',elapsedSeconds=round(time.monotonic()-began,3),summaries=re.findall(r'^test result: .+$',(out/f'{name}.stdout.log').read_text(errors='replace'),re.M))
        save();print(json.dumps(item),flush=True)
        if item['exitCode']:break
    report['sourceUnchanged']=all(sha(work/name)==value for name,value in sources.items())
    report['status']='passed_scoped_final_acceptance_pending' if len(report['results'])==len(commands) and all(i['exitCode']==0 for i in report['results']) and report['sourceUnchanged'] else 'failed_original_outputs_retained'
finally:
    report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
raise SystemExit(0 if report['status']=='passed_scoped_final_acceptance_pending' else 1)
