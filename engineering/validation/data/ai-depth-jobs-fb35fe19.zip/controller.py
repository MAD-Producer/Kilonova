from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/ai-depth';out=root/'artifacts/pr-queue'/('issue74-jobs-'+sys.argv[1]);out.mkdir(exist_ok=False)
def source():
 names=set()
 for args in [('ls-files','-z'),('ls-files','--others','--exclude-standard','-z')]:
  names.update(p.decode() for p in subprocess.check_output(['git',*args],cwd=work).split(b'\0') if p)
 return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(names) if (work/p).is_file() and (p.endswith(('.rs','.wgsl','.glsl','.toml')) or p=='Cargo.lock')}
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/original-source-memory-b273180a'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true');env.pop('MOTION_LOG',None)
cmd=['cargo','test','-p','motion-host','--no-default-features','--features','ai-depth','--test','depth_jobs','--locked','--offline','--','--test-threads=1']
receipt=dict(source=source(),command=cmd)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 process=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr);receipt['pid']=process.pid;(out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');code=process.wait()
receipt.update(exitCode=code,sourceUnchanged=receipt['source']==source())
(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');assert receipt['sourceUnchanged']
if code:sys.exit(code)
assert '6 passed; 0 failed; 0 ignored;' in (out/'stdout.log').read_text(encoding='utf-8')
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print('accepted: six controlled asynchronous depth tests',flush=True)
