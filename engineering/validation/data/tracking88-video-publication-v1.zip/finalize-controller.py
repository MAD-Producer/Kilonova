"""Archive success and failure evidence without rewriting their reports."""
from pathlib import Path
import hashlib, json, zipfile
ROOT=Path('E:/Dev/aem'); WORK=ROOT/'.worktrees/tracking-import88'
names=['tracking88-video-baseline-v1','tracking88-video-baseline-v2',
       'tracking88-video-native-v1','tracking88-video-native-v2',
       'tracking88-video-native-v3','tracking88-video-native-v4',
       'tracking88-video-regression-v1','tracking88-video-regression-v2']
accepted=ROOT/'artifacts/pr-queue/tracking88-video-regression-v2/exit.json'
report=json.loads(accepted.read_text(encoding='utf-8'))
assert report['status']=='accepted_selected_video_publication_increment_full_issue_pending'
assert len(report['steps'])==10 and all(step['exitCode']==0 for step in report['steps'])
for path,digest in report['source'].items():
    assert hashlib.sha256((WORK/path).read_bytes()).hexdigest()==digest,path
members={}
for name in names:
    folder=ROOT/'artifacts/pr-queue'/name
    for p in sorted(folder.rglob('*')):
        if p.is_file(): members[f'{name}/{p.relative_to(folder).as_posix()}']=p.read_bytes()
check=ROOT/'artifacts/pr-queue/tracking88-video-check-v1.log'
members['tracking88-video-check-v1.log']=check.read_bytes()
members['finalize-controller.py']=Path(__file__).read_bytes()
dest=WORK/'engineering/validation/data/tracking88-video-publication-v1.zip'
assert not dest.exists()
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in members.items(): archive.writestr(name,data)
with zipfile.ZipFile(dest) as archive:
    assert archive.testzip() is None
    assert sorted(archive.namelist())==sorted(members)
    for name,data in members.items(): assert archive.read(name)==data,name
closeout=dict(status='accepted_selected_increment_full_issue_pending',
    sourceParent=report['head'],branch='fix/88-tracked-video-replacement',
    evidence='tracking88-video-regression-v2/exit.json',
    archive=dict(path=dest.name,bytes=dest.stat().st_size,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
        members={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in members.items()}),
    selectedCommandCounts={'media_video':13,'host_tracking':51,'host_media':15,'host_image_relink':7,'host_registration':8,'desktop_image':1,'desktop_video':1},
    overlappingTests=['host stream-identity test appears in tracking and ops::media filters'],
    limits=['No successful pre-change native defect reproduction','Full workspace/desktop and cross-platform CI pending','Retained interactive Surface cache unqualified','New plate plus new solve and tracker prototype pending','No permanent filesystem lease','Android excluded','Previous compiler/native/external-calibration/performance failures unresolved'])
(dest.parent/'tracking88-video-publication-closeout.json').write_text(json.dumps(closeout,indent=2),encoding='utf-8')
print(json.dumps(dict(archive=str(dest),bytes=dest.stat().st_size,members=len(members),sha256=closeout['archive']['sha256'])))
