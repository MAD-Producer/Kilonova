"""Capture the regression source before executing the actual native video route."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess
ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-video-baseline-v1'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
paths = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
sources = {p: hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if (WORK/p).is_file() and (p.startswith(('crates/','desktop/')) or p in ('Cargo.toml','Cargo.lock'))}
for path in ['desktop/app/src/engine.rs','desktop/app/src/engine/tracking_video_replacement_tests.rs','crates/motion-host/src/ops/media.rs','crates/motion-media/src/video.rs']:
    destination = OUT/'source'/path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((WORK/path).read_bytes())
(OUT/'changes.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=WORK))
env = os.environ.copy()
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',MOTION_TRACKING_VIDEO_NATIVE_DIR=str(OUT))
env.pop('MOTION_LOG',None)
command = ['cargo','test','-p','motion-desktop','--features','ffmpeg','--bin','motion-studio','--locked','--offline','engine::tracking_video_replacement_tests::tracked_video_replacement_refuses_changed_plate_and_preserves_identical_source','--','--exact','--test-threads=1','--nocapture']
report = dict(status='running',source=sources,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),command=command,startedUtc=datetime.now(timezone.utc).isoformat(),controllerPid=os.getpid())
def save(): (OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
save()
try:
    with (OUT/'stdout.log').open('wb') as out, (OUT/'stderr.log').open('wb') as err:
        child = subprocess.Popen(command,cwd=WORK,env=env,stdout=out,stderr=err)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    for path, digest in sources.items():
        assert hashlib.sha256((WORK/path).read_bytes()).hexdigest() == digest, path
    report['status'] = 'terminal_review_output_not_assumed_defect_proof'
except BaseException as cause:
    report.update(status='controller_failed',failure=repr(cause))
    raise
finally:
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    save()
