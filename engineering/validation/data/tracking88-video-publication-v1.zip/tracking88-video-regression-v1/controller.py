"""Serial final-source qualification; selected scopes, never whole issue closure."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess
ROOT=Path('E:/Dev/aem'); WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-video-regression-v1'
OUT.mkdir(exist_ok=False); (OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def now(): return datetime.now(timezone.utc).isoformat()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
sources={p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in sorted(set(paths)) if (WORK/p).is_file() and (p.startswith(('crates/','desktop/')) or p in ('Cargo.toml','Cargo.lock'))}
changed=subprocess.check_output(['git','diff','--name-only'],cwd=WORK,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
for p in changed:
    if p in sources:
        dest=OUT/'source'/p; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes((WORK/p).read_bytes())
(OUT/'changes.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=WORK))
env=os.environ.copy(); env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full')
def cargo(package, selection): return ['cargo','test','-p',package,'--locked','--offline']+selection+['--','--test-threads=1','--nocapture']
steps=[
 ('media-video',cargo('motion-media',['--lib','video::'])),
 ('host-tracking',cargo('motion-host',['--lib','tracking'])),
 ('host-media',cargo('motion-host',['--lib','ops::media'])),
 ('host-image-relink',cargo('motion-host',['--test','tracking_relink'])),
 ('host-registration',cargo('motion-host',['--test','asset_registration'])),
 ('desktop-image',cargo('motion-desktop',['--features','ffmpeg','--bin','motion-studio','engine::tracking_relink_tests::tracked_image_relink_keeps_native_output_and_records_wrong_source','--','--exact'])[:-4]+['--exact','--test-threads=1','--nocapture']),
 ('desktop-video',cargo('motion-desktop',['--features','ffmpeg','--bin','motion-studio','engine::tracking_video_replacement_tests::tracked_video_replacement_refuses_changed_plate_and_preserves_identical_source','--','--exact'])[:-4]+['--exact','--test-threads=1','--nocapture']),
 ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg','--locked','--offline']),
 ('provenance',['python','tools/validate_provenance.py']),
 ('style',['python','-c','import sys;sys.path.insert(0,"tools");import ci_desktop;ci_desktop.verify_style_consumers()']),
]
# Construct exact test commands directly: only one libtest separator is valid.
for index,module in [(5,'tracking_relink_tests::tracked_image_relink_keeps_native_output_and_records_wrong_source'),(6,'tracking_video_replacement_tests::tracked_video_replacement_refuses_changed_plate_and_preserves_identical_source')]:
    steps[index]=(steps[index][0], ['cargo','test','-p','motion-desktop','--features','ffmpeg','--bin','motion-studio','--locked','--offline','engine::'+module,'--','--exact','--test-threads=1','--nocapture'])
report=dict(status='running',controllerPid=os.getpid(),startedUtc=now(),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),source=sources,steps=[],scope='Selected media/host regressions, actual desktop native image/video capture and FFmpeg check. Not full desktop/workspace, interactive Surface, Android, or cross-platform CI.')
def save(): (OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def identity():
    for p,digest in sources.items(): assert hashlib.sha256((WORK/p).read_bytes()).hexdigest()==digest,p
save()
try:
    for name,args in steps:
        identity(); step=dict(name=name,command=args,startedUtc=now()); report['steps'].append(step);save()
        current=env.copy()
        if name=='desktop-image': current['MOTION_TRACKING_RELINK_NATIVE_DIR']=str(OUT/'image')
        if name=='desktop-video': current['MOTION_TRACKING_VIDEO_NATIVE_DIR']=str(OUT/'video')
        with (OUT/(name+'.stdout.log')).open('wb') as out,(OUT/(name+'.stderr.log')).open('wb') as err:
            child=subprocess.Popen(args,cwd=WORK,env=current,stdout=out,stderr=err);step['pid']=child.pid;save();step['exitCode']=child.wait()
        step['completedUtc']=now();save();assert step['exitCode']==0,step
    for name,folder,operation,request in [('desktop-image','image','asset relink','desktop-relink-wrong'),('desktop-video','video','media replacement','tracked-video-wrong')]:
        text=(OUT/folder/'logs/motion-studio.log').read_text(encoding='utf-8')
        stderr=(OUT/(name+'.stderr.log')).read_text(encoding='utf-8',errors='replace')
        stdout=(OUT/(name+'.stdout.log')).read_text(encoding='utf-8',errors='replace')
        for sink in (text,stderr): assert f'{operation} tracking failed request={request}' in sink
        assert f'{operation} tracking start request={request}' in text
        assert 'tracking failed request=' not in stdout
    identity();report['status']='accepted_selected_video_publication_increment_full_issue_pending'
except BaseException as cause:
    report.update(status='failed',failure=repr(cause));raise
finally:
    report['completedUtc']=now();save()
