"""Independently check static lifetime intervals and operator requirements."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import onnx

ROOT = Path('E:/Dev/aem')
SOURCE = ROOT / 'artifacts/pr-queue/depth75-static-model-audit-v3'
OUT = ROOT / 'artifacts/pr-queue/depth75-operator-requirements-v1'
MODEL = ROOT / '.tools/ai-depth74/models/depth_anything_v2_vits_518.onnx'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
report = json.loads((SOURCE / 'receipt.json').read_text(encoding='utf-8'))
assert report['unknownTensorCount'] == 0 and report['modelUnchanged'] and not report['inferenceExecuted']
assert sha(MODEL) == report['modelSha256']
assert sha(SOURCE / 'tensor-inventory.json') == report['inventorySha256']
inventory = json.loads((SOURCE / 'tensor-inventory.json').read_text(encoding='utf-8'))
graph = onnx.load(str(MODEL), load_external_data=False).graph
assert len(inventory) == len(graph.node) == report['nodes']
values = {r['name']: r for row in inventory for r in row['outputs']}
values.update({r['name']: r for r in report['inputs']})
persistent = {t.name for t in graph.initializer}
persistent.update(n for node in graph.node if node.op_type == 'Constant' for n in node.output)
producer = {n: index for index, node in enumerate(graph.node) for n in node.output if n not in persistent}
producer.update({r['name']: -1 for r in report['inputs']})
last_use = dict(producer)
for index, node in enumerate(graph.node):
    for name in node.input:
        if name in producer:
            last_use[name] = max(last_use[name], index)
for value in graph.output:
    last_use[value.name] = len(graph.node)
peaks = [dict(nodeIndex=index, bytes=sum(values[n]['bytes'] for n, first in producer.items()
                                        if first <= index <= last_use[n]))
         for index in range(-1, len(graph.node))]
independent = max(peaks, key=lambda r: r['bytes'])
assert independent['bytes'] == report['naiveMaterializedActivationPeak']['bytes']
assert independent['nodeIndex'] == report['naiveMaterializedActivationPeak']['nodeIndex']

def attributes(node):
    result = {}
    for a in node.attribute:
        if a.type == onnx.AttributeProto.INT:
            result[a.name] = a.i
        elif a.type == onnx.AttributeProto.INTS:
            result[a.name] = list(a.ints)
        elif a.type == onnx.AttributeProto.FLOAT:
            result[a.name] = a.f
        elif a.type == onnx.AttributeProto.STRING:
            result[a.name] = a.s.decode('utf-8')
    return result

requirements = []
for kind in ('Conv', 'ConvTranspose', 'LayerNormalization', 'Resize', 'Softmax', 'Transpose'):
    counts = Counter(json.dumps(attributes(n), sort_keys=True) for n in graph.node if n.op_type == kind)
    requirements.append(dict(operation=kind, variants=[dict(count=count, attributes=json.loads(attrs))
                                                     for attrs, count in sorted(counts.items())]))
result = dict(status='static_memory_intervals_verified_operator_requirements_retained',
              completedUtc=datetime.now(timezone.utc).isoformat(), sourceModelSha256=sha(MODEL),
              sourceReceiptSha256=sha(SOURCE / 'receipt.json'), sourceInventorySha256=sha(SOURCE / 'tensor-inventory.json'),
              independentActivationPeak=independent, persistentBytes=report['persistentConstantBytes'],
              naiveCombinedBytes=independent['bytes'] + report['persistentConstantBytes'],
              learnedWeightDtype='FLOAT', quantizationOperators=[], operatorRequirements=requirements,
              limits=['Independent inclusive producer/last-use intervals verify the earlier consumption-counter simulation',
                      'The naive memory schedule is fully static and ignores allocator reuse/fusion/alignment and host/GPU duplication',
                      'No learned operator, model inference, GPU, latency, power or accuracy comparison executed',
                      'No operator kernels or backend scheduling are implemented by this analysis'])
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
(OUT / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k != 'operatorRequirements'}))
