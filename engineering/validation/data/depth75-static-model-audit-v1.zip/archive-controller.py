"""Publish small independently generated audit records, never model payloads."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile
import subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/reference-depth76'
ART = ROOT / 'artifacts/pr-queue'
OUT = WORK / 'engineering/validation/data'
BASE = '1aa57293a84e70734ff414e9450f1e880c62139d'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == BASE
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=WORK, text=True).strip() == 'docs/75-wgsl-depth-audit'
final = json.loads((ART / 'depth75-static-model-audit-v3/receipt.json').read_text())
verified = json.loads((ART / 'depth75-operator-requirements-v1/receipt.json').read_text())
assert final['unknownTensorCount'] == 0 and not final['inferenceExecuted']
assert verified['independentActivationPeak']['bytes'] == final['naiveMaterializedActivationPeak']['bytes']
assert sha(ART / 'depth75-static-model-audit-v3/receipt.json') == verified['sourceReceiptSha256']
files = {}
for version in (1, 2, 3):
    name = 'depth75-static-model-audit-v' + str(version)
    folder = ART / name
    receipt = json.loads((folder / 'receipt.json').read_text())
    assert receipt['status'] == 'static_inventory_complete_not_a_backend_or_runtime_measurement'
    assert receipt['modelSha256'] == final['modelSha256']
    assert sha(folder / 'tensor-inventory.json') == receipt['inventorySha256']
    for path in ('controller.py', 'receipt.json', 'tensor-inventory.json'):
        files[name + '/' + path] = folder / path
for path in ('controller.py', 'receipt.json'):
    files['depth75-operator-requirements-v1/' + path] = ART / 'depth75-operator-requirements-v1' / path
files['archive-controller.py'] = Path(__file__)
entries = {name: dict(bytes=p.stat().st_size, sha256=sha(p)) for name, p in sorted(files.items())}
archive = OUT / 'depth75-static-model-audit-v1.zip'
manifest = OUT / 'depth75-static-model-audit-v1.json'
assert not archive.exists() and not manifest.exists()
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(files.items()):
        assert path.suffix in ('.py', '.json')
        z.writestr(name, path.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(entries)
    for name, entry in entries.items():
        data = z.read(name)
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
record = dict(status='static_audit_archived_readback_verified',
              createdUtc=datetime.now(timezone.utc).isoformat(), sourceBaseline=BASE,
              modelSha256=final['modelSha256'], archive=archive.name,
              bytes=archive.stat().st_size, sha256=sha(archive), entries=entries,
              nodes=final['nodes'], unknownShapesByStage=[242, 2, 0],
              activationPeakBytes=verified['independentActivationPeak']['bytes'],
              persistentBytes=verified['persistentBytes'], naiveCombinedBytes=verified['naiveCombinedBytes'],
              limits=['Only independent controllers, integer-shape/static-memory reports and metadata are included',
                      'No ONNX model, weights, upstream implementation, model-card prose, pictures or dataset assets',
                      'Does not implement WGSL kernels or qualify any inference backend',
                      'No model inference or additional GPU device was started during the live #88 full regression',
                      'Source branch contains documentation/evidence only; the separate frozen tracking source is unchanged'])
manifest.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k != 'entries'}))
