"""Static inspection of the already attributed model; never performs inference."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
import time

os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import onnx

ROOT = Path('E:/Dev/aem')
MODEL = ROOT / '.tools/ai-depth74/models/depth_anything_v2_vits_518.onnx'
OUT = ROOT / 'artifacts/pr-queue/depth75-static-model-audit-v3'
EXPECTED = '274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(MODEL) == EXPECTED
assert MODEL.stat().st_size < 2 * 1024**3
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='running_static_model_inspection',
              startedUtc=datetime.now(timezone.utc).isoformat(),
              modelSha256=EXPECTED, modelBytes=MODEL.stat().st_size,
              onnxVersion=onnx.__version__, inferenceExecuted=False,
              license='Apache-2.0 for this pinned Small model only',
              referenceRevision='a561b849ebae10a6f5ef49e26c83cbbcd36c71bf',
              originalWeightsSha256='715fade13be8f229f8a70cc02066f656f2423a59effd0579197bbf57860e1378',
              limits=[
                  'No model/weights/reference source added to repository or default distribution',
                  'Static graph sizes are not measured allocator, latency, thermal, quality or power results',
                  'Naive materialization accounts for overlap during one node, no aliasing, reuse, tiling or fusion',
                  'Device limits below are comparison baselines, not a queried adapter capability',
                  'No new backend, operator implementation or WGSL/ONNX equivalence is claimed',
                  'Existing optional CPU ONNX backend remains the only actual measured inference route',
                  'Android is retired and excluded by user instruction'])

def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

save()
began = time.monotonic()
model = onnx.load(str(MODEL), load_external_data=False)
assert not model.functions, 'Inventory local functions explicitly before memory analysis'
assert all(t.data_location != onnx.TensorProto.EXTERNAL for t in model.graph.initializer)
onnx.checker.check_model(model, full_check=False)
inferred = onnx.shape_inference.infer_shapes(model, check_type=True, strict_mode=True, data_prop=True)
graph = inferred.graph
report['opsets'] = [{'domain': x.domain or 'ai.onnx', 'version': x.version} for x in model.opset_import]
report['operators'] = dict(sorted(Counter((n.domain + '::' if n.domain else '') + n.op_type for n in graph.node).items()))
report['nodes'] = len(graph.node)

def item_size(dtype):
    try:
        return onnx.helper.tensor_dtype_to_np_dtype(dtype).itemsize
    except (TypeError, ValueError):
        return None

values = {}
for value in list(graph.input) + list(graph.value_info) + list(graph.output):
    if not value.type.HasField('tensor_type'):
        values[value.name] = dict(type='non-tensor', bytes=None)
        continue
    tensor = value.type.tensor_type
    shape = [d.dim_value if d.HasField('dim_value') else d.dim_param or None for d in tensor.shape.dim]
    count = math.prod(shape) if tensor.HasField('shape') and all(isinstance(d, int) for d in shape) else None
    size = item_size(tensor.elem_type)
    values[value.name] = dict(dtype=onnx.TensorProto.DataType.Name(tensor.elem_type), shape=shape,
                              bytes=count * size if count is not None and size is not None else None)
for value in graph.initializer:
    size = item_size(value.data_type)
    values[value.name] = dict(dtype=onnx.TensorProto.DataType.Name(value.data_type), shape=list(value.dims),
                              bytes=math.prod(value.dims) * size if size is not None else None)

# Resolve the two residual symbolic shapes from a bounded, input-free integer
# shape program. This evaluates no image, learned operator or model weights.
from onnx.reference import ReferenceEvaluator
import numpy as np
by_output = {name: node for node in graph.node for name in node.output}
expanded = next(n for n in graph.node if n.op_type == 'Expand')
needed, ordered = set(), []
def ancestors(name):
    if name in needed:
        return
    needed.add(name)
    node = by_output[name]
    assert not node.domain and node.op_type in ('Constant', 'ConstantOfShape', 'Mul', 'Equal', 'Where')
    for parent in node.input:
        ancestors(parent)
    ordered.append(node)
ancestors(expanded.input[1])
assert len(ordered) <= 16 and all(not n.domain for n in ordered)
shape_graph = onnx.helper.make_graph(ordered, 'bounded-static-shape-program', [],
    [onnx.helper.make_tensor_value_info(expanded.input[1], onnx.TensorProto.INT64, [3])])
shape_model = onnx.helper.make_model(shape_graph, opset_imports=list(model.opset_import), ir_version=model.ir_version)
onnx.checker.check_model(shape_model)
shape_value = ReferenceEvaluator(shape_model).run(None, {})[0]
assert shape_value.dtype == np.int64 and shape_value.size <= 64 and np.all(shape_value >= 0)
base_shape = values[expanded.input[0]]['shape']
assert all(isinstance(d, int) for d in base_shape)
expanded_shape = list(np.broadcast_shapes(tuple(base_shape), tuple(int(v) for v in shape_value)))
fixes = []
def resolve(name, dimensions):
    old = values[name]
    assert len(old['shape']) == len(dimensions)
    assert all(not isinstance(a, int) or a == b for a, b in zip(old['shape'], dimensions))
    fixes.append(dict(name=name, original=old['shape'], resolved=dimensions))
    old['shape'] = dimensions
    old['bytes'] = math.prod(dimensions) * item_size(onnx.TensorProto.DataType.Value(old['dtype']))
resolve(expanded.output[0], expanded_shape)
concatenated = next(n for n in graph.node if n.op_type == 'Concat' and expanded.output[0] in n.input)
axis = next(a.i for a in concatenated.attribute if a.name == 'axis')
shapes = [values[n]['shape'] for n in concatenated.input]
assert all(all(isinstance(d, int) for d in s) for s in shapes)
assert all(len(s) == len(shapes[0]) for s in shapes)
assert all(all(s[i] == shapes[0][i] for i in range(len(s)) if i != axis) for s in shapes)
combined = list(shapes[0]); combined[axis] = sum(s[axis] for s in shapes)
resolve(concatenated.output[0], combined)
consumer = next(n for n in graph.node if n.op_type == 'Add' and concatenated.output[0] in n.input)
assert values[consumer.output[0]]['shape'] == combined, 'Independent downstream shape disagrees'
report['staticShapeResolution'] = dict(programNodes=len(ordered), tensorElements=int(shape_value.size),
    programHasInputs=False, learnedOperatorsEvaluated=False, fixes=fixes,
    downstreamShapeCrosscheck=True)

persistent = {t.name for t in graph.initializer}
for node in graph.node:
    assert not any(a.type in (onnx.AttributeProto.GRAPH, onnx.AttributeProto.GRAPHS) for a in node.attribute), 'Subgraph lifetime analysis unsupported'
    if node.op_type == 'Constant' and not node.domain:
        persistent.update(node.output)
output_names = {v.name for v in graph.output}
all_outputs = {name for node in graph.node for name in node.output if name}
referenced = all_outputs | {v.name for v in graph.input} | persistent
unknown = sorted(name for name in referenced if values.get(name, {}).get('bytes') is None)
report['unknownTensorCount'] = len(unknown)
report['unknownTensorExamples'] = unknown[:20]
report['initializerCount'] = len(graph.initializer)
report['initializerDtypes'] = dict(Counter(onnx.TensorProto.DataType.Name(x.data_type) for x in graph.initializer))
report['initializerElements'] = sum(math.prod(t.dims) for t in graph.initializer)
report['initializerBytes'] = sum(values[t.name]['bytes'] or 0 for t in graph.initializer)
report['persistentConstantBytes'] = sum(values.get(n, {}).get('bytes') or 0 for n in persistent)
report['inputs'] = [dict(name=v.name, **values[v.name]) for v in graph.input if v.name not in persistent]
report['outputs'] = [dict(name=v.name, **values[v.name]) for v in graph.output]

uses = Counter(name for node in graph.node for name in node.input if name)
uses.update(output_names)
live = {v.name for v in graph.input if v.name not in persistent}
known_bytes = lambda names: sum(values.get(n, {}).get('bytes') or 0 for n in names)
peak = dict(bytes=known_bytes(live), nodeIndex=-1, operation='input', liveTensorCount=len(live))
produced = set(persistent) | {v.name for v in graph.input}
inventory = []
for index, node in enumerate(graph.node):
    assert all(name in produced for name in node.input if name), 'Graph must be topologically ordered'
    assert not (set(node.output) - persistent) & produced, 'Tensor identity reused'
    outputs = {name for name in node.output if name and name not in persistent}
    live.update(outputs)
    produced.update(node.output)
    current = known_bytes(live)
    if current > peak['bytes']:
        peak = dict(bytes=current, nodeIndex=index, operation=node.op_type, liveTensorCount=len(live))
    inventory.append(dict(index=index, operation=node.op_type, domain=node.domain or 'ai.onnx',
                          outputs=[dict(name=name, **values.get(name, {'bytes': None})) for name in node.output if name]))
    for name in node.input:
        if name:
            uses[name] -= 1
            if uses[name] == 0:
                live.discard(name)
    for name in outputs:
        if uses[name] == 0:
            live.discard(name)

largest = sorted((dict(name=n, **v) for n, v in values.items() if n not in persistent and v.get('bytes') is not None),
                 key=lambda r: r['bytes'], reverse=True)[:20]
report['largestNonconstantTensors'] = largest
report['naiveMaterializedActivationPeak'] = dict(**peak, completeStaticShapes=not unknown,
                                               includesConstantsAndWeights=False,
                                               assumption='All known node outputs materialized before releasing last-use inputs')
report['comparisonBaselines'] = dict(storageBindingBytes=128 * 1024**2, bufferBytes=256 * 1024**2,
                                     workgroupStorageBytes=16384, workgroupInvocations=256,
                                     largestTensorExceedsStorageBinding=bool(largest and largest[0]['bytes'] > 128 * 1024**2),
                                     limitsAreMeasured=False)
(OUT / 'tensor-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n', encoding='utf-8')
report.update(status='static_inventory_complete_not_a_backend_or_runtime_measurement',
              completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - began, 3),
              modelUnchanged=sha(MODEL) == EXPECTED,
              inventorySha256=sha(OUT / 'tensor-inventory.json'))
assert report['modelUnchanged']
save()
print(json.dumps({k: v for k, v in report.items() if k not in ('largestNonconstantTensors', 'unknownTensorExamples', 'limits')}))
