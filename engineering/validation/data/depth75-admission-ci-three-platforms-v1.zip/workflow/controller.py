"""Observe one existing exact-head CI run; never cancel/restart/push/merge."""
from datetime import datetime, timezone
from pathlib import Path
import json
import subprocess
import time

BASE = Path('E:/Dev/aem/artifacts/pr-queue')
OUT = BASE / 'depth75-ci-terminal-watch-v1'
HEAD = '369a4e7de1aa30b54837fb0d69eed8f5f083136a'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='observing_existing_run', run=42320228605, sourceCommit=HEAD,
              startedUtc=datetime.now(timezone.utc).isoformat(), pid=__import__('os').getpid())

def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

def api(path):
    return json.loads(subprocess.check_output(
        ['gh', 'api', 'repos/MAD-Producer/Kilonova' + path], encoding='utf-8'))

save()
try:
    while True:
        run = api('/actions/runs/42320228605')
        assert run['head_sha'] == HEAD and run['event'] == 'pull_request'
        report.update(runStatus=run['status'], conclusion=run['conclusion'],
                      observedUtc=datetime.now(timezone.utc).isoformat())
        save()
        if run['status'] == 'completed':
            (OUT / 'terminal-run.json').write_text(json.dumps(run, indent=2) + '\n', encoding='utf-8')
            jobs = api('/actions/runs/42320228605/jobs')
            (OUT / 'terminal-jobs.json').write_text(json.dumps(jobs, indent=2) + '\n', encoding='utf-8')
            assert run['conclusion'] == 'success', 'Existing CI terminal state retained; do not restart or publish over it'
            break
        time.sleep(45)
    prior = json.loads((BASE / 'depth75-admission-ci-linux-v1/receipt.json').read_text(encoding='utf-8'))
    command = ['python', str(BASE / 'depth75-admission-ci-linux-v1/controller.py'),
               '--run', '42320228605', '--head', HEAD,
               '--job', 'windows:128242724899', '--output', str(BASE / 'depth75-admission-ci-windows-v1')]
    for name in prior['invocation']['test']:
        command.extend(['--test', name])
    with (OUT / 'collector.stdout.log').open('wb') as stdout, (OUT / 'collector.stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, stdout=stdout, stderr=stderr)
        report['collectorPid'] = child.pid
        save()
        report['collectorExit'] = child.wait()
    assert report['collectorExit'] == 0
    report['status'] = 'existing_workflow_passed_and_windows23_named_tests_verified'
except BaseException as error:
    report.update(status='failed_original_terminal_state_retained', cause=repr(error))
finally:
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps(report))
raise SystemExit(0 if report['status'].startswith('existing_workflow_passed') else 1)
