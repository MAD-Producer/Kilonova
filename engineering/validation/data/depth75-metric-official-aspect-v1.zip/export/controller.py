from pathlib import Path
import hashlib,json,subprocess,os,datetime,traceback
ROOT=Path('E:/Dev/aem');SRC=ROOT/'.worktrees/depth-adapter-memory75';TOOLS=ROOT/'.tools/depth75-metric-export-v1';OUT=ROOT/'artifacts/pr-queue/depth75-metric-official-aspect-export-v1';OUT.mkdir(exist_ok=False)
env=os.environ.copy();env.update(TEMP=str(TOOLS/'tmp'),TMP=str(TOOLS/'tmp'),PYTHONDONTWRITEBYTECODE='1',PIP_DISABLE_PIP_VERSION_CHECK='1')
py=TOOLS/'venv/Scripts/python.exe';script=SRC/'tools/export_ai_depth.py';target=TOOLS/'metric-onnx-native686x518-v1'
assert not target.exists()
assert json.loads((ROOT/'artifacts/pr-queue/depth75-metric-local-install-v2/receipt.json').read_text())['status']=='local_cpu_environment_verified_not_model_qualification'
report=dict(status='running',scope='Explicit changed official-aspect profile for original640x480; same pinned weights/reference and numerical gates; square-profile failure retained',sourceHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SRC,text=True).strip(),sourceSha256=hashlib.sha256(script.read_bytes()).hexdigest(),output=str(target),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save():
 with (OUT/'receipt.json').open('w',encoding='utf-8') as stream:
  json.dump(report,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
save()
try:
 cmd=list(map(str,[py,'-B',script,'--reference',TOOLS/'reference','--weights',TOOLS/'depth_anything_v2_metric_hypersim_vits.pth','--output',target,'--metric-hypersim','--metric-native-aspect']))
 report['command']=cmd;save()
 with (OUT/'export.stdout.log').open('xb') as a,(OUT/'export.stderr.log').open('xb') as b:
  child=subprocess.Popen(cmd,cwd=SRC,env=env,stdout=a,stderr=b);report['pid']=child.pid;save();report['exit_code']=child.wait();save()
 if report['exit_code']:raise RuntimeError('actual metric export failed '+str(report['exit_code']))
 assert hashlib.sha256(script.read_bytes()).hexdigest()==report['sourceSha256']
 report['manifest']=json.loads((target/'model.json').read_text());report['stdoutBytes']=(OUT/'export.stdout.log').stat().st_size
 report['status']='actual_cpu_numerical_export_passed_not_sensor_or_domain_qualification'
except BaseException:
 report.update(status='failed',cause=traceback.format_exc());raise
finally:
 report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({k:report.get(k) for k in ('status','exit_code','cause')}))
