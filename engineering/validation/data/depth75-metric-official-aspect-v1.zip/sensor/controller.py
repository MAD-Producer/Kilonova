from pathlib import Path
import sys,os,json,hashlib,datetime,time,traceback,math
R=Path('E:/Dev/aem');S=R/'.worktrees/depth-adapter-memory75';T=R/'.tools/depth75-metric-export-v1';A=R/'artifacts/pr-queue';O=A/'depth75-metric-official-aspect-sensor-v1';I=A/'depth75-reference-inputs-v1';O.mkdir(exist_ok=False)
sys.dont_write_bytecode=True;sys.path.insert(0,str(S/'tools'))
from ai_depth_onnx import resize_align_corners
from export_ai_depth import preprocess_metric_native,METRIC_NATIVE_PROCESSING
from depth_reference_metrics import Calibration,score,summarize
report=dict(status='running',phase='preflight',scope='One explicit official-aspect profile, same pinned metric weights and original32 TUM inputs; first8 diagnostic, next24 primary; no fitting or residual trimming',bounds=dict(normalized_rms=.01,normalized_maximum=.05),normalization='exactly one inverse metre',measure='camera_z_metres',rows=[],started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_hashes={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in ['tools/ai_depth_onnx.py','tools/depth_reference_metrics.py','tools/export_ai_depth.py']})
def save():
 with (O/'receipt.json').open('w') as f:json.dump(report,f,indent=2);f.flush();os.fsync(f.fileno())
def phase(s):
 report['phase']=s;save()
 with (O/'phases.log').open('a') as f:f.write('INFO start '+s+'\n');f.flush();os.fsync(f.fileno())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
save()
try:
 import numpy as np,cv2,onnxruntime as ort,torch
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 sys.path.insert(0,str(T/'reference/metric_depth'))
 from depth_anything_v2.util.transform import Resize,NormalizeImage,PrepareForNet
 from torchvision.transforms import Compose
 official=Compose([Resize(width=518,height=518,resize_target=False,keep_aspect_ratio=True,ensure_multiple_of=14,resize_method='lower_bound',image_interpolation_method=cv2.INTER_CUBIC),NormalizeImage(mean=[.485,.456,.406],std=[.229,.224,.225]),PrepareForNet()])
 m=json.loads((T/'metric-onnx-native686x518-v1/model.json').read_text());model=T/'metric-onnx-native686x518-v1'/m['file'];assert digest(model)==m['sha256'];assert m['measure']=='metric' and m['metersPerUnit']==1 and m['axis']=='camera_z' and m['processing']==METRIC_NATIVE_PROCESSING and m['sourceExtent']==[640,480]
 inputs=json.loads((I/'inputs.json').read_text());assert len(inputs)==32
 report.update(model_sha256=m['sha256'],input_manifest_sha256=digest(I/'inputs.json'),processing=m['processing'],runtime=ort.__version__)
 for i,row in enumerate(inputs):
  assert row['index']==i and row['split']==('calibration' if i<8 else 'evaluation')
  for field in ('rgb_input','depth_input'):
   p=I/row[field]['filename'];assert p.stat().st_size==row[field]['bytes'] and digest(p)==row[field]['sha256']
 phase('load_exclusive_cpu_session');opts=ort.SessionOptions();opts.intra_op_num_threads=opts.inter_op_num_threads=1
 session=ort.InferenceSession(str(model),sess_options=opts,providers=['CPUExecutionProvider']);session.disable_fallback();assert session.get_providers()==['CPUExecutionProvider']
 for i,row in enumerate(inputs):
  phase('frame_'+str(i)+'_preprocess_infer_remap_score');began=time.monotonic()
  rgb=np.fromfile(I/row['rgb_input']['filename'],dtype=np.uint8).reshape(480,640,3)
  tensor=preprocess_metric_native(rgb,np,cv2)
  expected=official({'image':rgb.astype(np.float64)/255.})['image'][None]
  assert tensor.shape==(1,3,518,686) and np.array_equal(tensor,expected),'independent preprocessing differs from pinned official transforms' 
  raw=session.run(['camera_z_metres'],{'rgb':tensor.copy(order='C')})[0];assert raw.shape==(1,518,686) and np.isfinite(raw).all() and raw.min()>0 and raw.max()<=20
  predicted=torch.nn.functional.interpolate(torch.from_numpy(raw[:,None]),(480,640),mode='bilinear',align_corners=True)[0,0].numpy()
  remapped=resize_align_corners(raw[0],640,480,np)
  delta=np.abs(predicted.astype(np.float64)-remapped.astype(np.float64));amplitude=max(float(np.abs(predicted).max()),1e-6)
  assert float(delta.max())/amplitude<=2e-4 and float(delta.mean())/amplitude<=2e-5,'independent source remap differs from official interpolation'
  assert np.isfinite(predicted).all() and predicted.min()>0
  out=O/(str(i).zfill(2)+'.metres.f32');predicted.astype('<f4').tofile(out)
  sensor=np.fromfile(I/row['depth_input']['filename'],dtype='<u2');assert sensor.size==640*480
  metrics=score(Calibration(1.,0.,1.,0,0),(1./predicted.astype(np.float64)).ravel().tolist(),sensor.astype(int).tolist())
  report['rows'].append(dict(index=i,split=row['split'],metrics=metrics,output_sha256=digest(out),elapsed_seconds=time.monotonic()-began));save()
 report['primary']=summarize([row['metrics'] for row in report['rows'][8:]],Calibration(1.,0.,1.,0,0))
 report['qualified']=report['primary']['normalized_rms']<=.01 and report['primary']['normalized_maximum']<=.05
 report['source_unchanged']=all(digest(S/n)==v for n,v in report['source_hashes'].items());assert report['source_unchanged']
 report['status']='fixed_sensor_evaluation_complete_passed' if report['qualified'] else 'fixed_sensor_evaluation_complete_rejected_original_bounds'
except BaseException:
 report.update(status='failed',cause=traceback.format_exc());raise
finally:
 report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({k:report.get(k) for k in ('status','primary','cause')}))
