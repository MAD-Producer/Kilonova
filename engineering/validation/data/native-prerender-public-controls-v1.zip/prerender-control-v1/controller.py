"""Exact-source public prerender routing gate; actual stdio follows compilation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess
ROOT=Path('E:/Dev/aem'); WORK=ROOT/'.worktrees/native-prerender-runtime'
OUT=ROOT/'artifacts/pr-queue/prerender-control-v1'
def git(*args):
    return subprocess.check_output(['git',*args],cwd=WORK).decode().strip()
assert not git('status','--porcelain')
source={p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in git('ls-files','-z').split('\0') if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml')) or p=='Cargo.lock')}
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__,OUT/'controller.py')
report=dict(head=git('rev-parse','HEAD'),source=source,status='running',steps=[])
env=os.environ.copy(); env.pop('MOTION_LOG',None)
env.update(CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full')
def step(name,args,passed=None):
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/(name+'.stdout.log')).open('wb') as so,(OUT/(name+'.stderr.log')).open('wb') as se:
        code=subprocess.run(args,cwd=WORK,env=env,stdout=so,stderr=se).returncode
    counts=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',(OUT/(name+'.stdout.log')).read_text(encoding='utf-8'))
    unchanged=all(hashlib.sha256((WORK/p).read_bytes()).hexdigest()==digest for p,digest in source.items())
    row=dict(name=name,command=args,exitCode=code,counts=counts,sourceUnchanged=unchanged)
    report['steps'].append(row)
    report['status']='failed' if code else 'running'
    (OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    assert code==0 and unchanged
    if passed is not None:
        assert counts and all(int(f)==0 and int(i)==0 for p,f,i in counts)
        assert sum(int(p) for p,f,i in counts)>=passed
common=['--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--bin','motion-studio']
step('mcp-routing',['cargo','test','-p','motion-desktop',*common,'mcp::','--','--test-threads=1'],2)
step('desktop-binary',['cargo','build','-p','motion-desktop',*common])
binary=ROOT/'target/gltf-animation87-contract/debug/motion-studio.exe'
report['binarySha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
def request(number,method,params=None):
    result={'jsonrpc':'2.0','method':method}
    if number is not None: result['id']=number
    if params is not None: result['params']=params
    return result
def call(number,name,arguments):
    return request(number,'tools/call',dict(name=name,arguments=arguments))
messages=[request(1,'initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='prerender-control',version='1'))),request(None,'notifications/initialized'),request(2,'tools/list'),call(3,'motion_state',{}),call(4,'configure_prerender',dict(enabled=True,window=2,idleDelayMs=0)),call(5,'configure_prerender',dict(enabled=False,window=9)),call(6,'motion_state',{}),call(7,'configure_prerender',dict(enabled=False)),call(8,'motion_state',{})]
for readonly in (False,True):
    name='readonly' if readonly else 'edit'
    args=[str(binary),'--mcp','--project',str(OUT/(name+'-project'))]
    if readonly: args.append('--mcp-read-only')
    payload=''.join(json.dumps(message)+'\n' for message in messages)
    with (OUT/(name+'.stderr.log')).open('wb') as errors:
        result=subprocess.run(args,cwd=WORK,env=env,input=payload.encode(),stdout=subprocess.PIPE,stderr=errors,timeout=90)
    (OUT/(name+'.stdout.jsonl')).write_bytes(result.stdout)
    assert result.returncode==0,result.returncode
    replies=[json.loads(line) for line in result.stdout.decode().splitlines()]
    assert [reply['id'] for reply in replies]==list(range(1,9))
    assert all(reply['jsonrpc']=='2.0' and 'error' not in reply for reply in replies)
    tools=replies[1]['result']['tools']; names={tool['name'] for tool in tools}
    assert names=={'motion_state','motion_edit','motion_seek','motion_history','motion_save','command_list','command_run','command_batch','render_preview','import_model','configure_prerender'}
    before=replies[2]['result']['structuredContent']; after=replies[7]['result']['structuredContent']
    assert before['desktop']['prerender']['enabled'] is False
    assert replies[3]['result']['isError'] is readonly
    assert replies[4]['result']['isError'] is True
    assert replies[5]['result']['structuredContent']['desktop']['prerender']['enabled'] is (not readonly)
    assert replies[6]['result']['isError'] is readonly
    assert after['desktop']['prerender']['enabled'] is False
    assert after['desktop']['headless'] is True
    for key in ('project','revision','canUndo','canRedo','frame','document_generation'):
        assert before[key]==after[key],key
    report['steps'].append(dict(name='actual-stdio-'+name,exitCode=result.returncode,replies=len(replies),defaultLogLevel=True,stdoutJsonOnly=True))
report.update(status='accepted',completedUtc=datetime.now(timezone.utc).isoformat(),scope='Public routing, permissions, policy bounds, actual binary headless stdio transport and exact catalogue; native cache and performance remain separate gates')
(OUT/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True)),flush=True)
