"""Explicit native policy-pressure and project lifecycle measurement."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess
ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/native-prerender-runtime'
OUT = ROOT / 'artifacts/pr-queue/prerender-lifecycle-v1'
NAME = 'engine::prerender::tests::pressure_lifecycle::native_pressure_holds_admission_and_project_reopen_preserves_pixel_ownership'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()
def sources():
    return {p: hashlib.sha256((WORK / p).read_bytes()).hexdigest()
            for p in git('ls-files', '-z').split('\0') if p and
            (p.endswith(('.rs', '.toml', '.wgsl', '.py', '.json', '.yml', '.yaml')) or p == 'Cargo.lock')}
assert not git('status', '--porcelain')
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'controller.py')
source = sources()
report = dict(head=git('rev-parse', 'HEAD'), source=source, status='running')
(OUT / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0',
           CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full', MOTION_PRERENDER_LIFECYCLE_ARTIFACTS=str(OUT / 'native'))
command = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth',
           '--locked', '--offline', '--bin', 'motion-studio', NAME, '--', '--ignored', '--exact', '--test-threads=1']
print(json.dumps(dict(start='native-pressure-lifecycle', head=report['head'])), flush=True)
with (OUT / 'stdout.log').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
    code = subprocess.run(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr).returncode
counts = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored', (OUT / 'stdout.log').read_text(encoding='utf-8'))
report.update(command=command, exitCode=code, counts=counts, sourceUnchanged=sources() == source,
              completedUtc=datetime.now(timezone.utc).isoformat(), status='failed' if code else 'passed')
(OUT / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
assert code == 0 and counts == [('1', '0', '0')] and report['sourceUnchanged'], report['status']
assert (OUT / 'native/report.json').is_file()
report.update(status='accepted', scope='Actual native frame-cache consumption, explicit typed preview budget refusal, no new jobs during policy hold, exact pixels after fixture release and document switch/reopen. No physical low-memory-device or automatic recovery qualification; no whole-issue closure.')
(OUT / 'accepted.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True)), flush=True)
