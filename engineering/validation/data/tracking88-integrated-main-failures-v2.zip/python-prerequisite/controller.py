"""One full original workspace command after integrating the fetched main."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import traceback

ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/planar-tracker88'
ART=ROOT/'artifacts/pr-queue'
OUT=ART/'tracking88-current-main-workspace-v1'
TARGET=ROOT/'target/depth-wgsl-cache75-contract'
CP=ART/'depth75-resume-current.json'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    tmp=p.with_suffix(p.suffix+'.pending')
    tmp.write_bytes((json.dumps(v,indent=2)+'\n').encode())
    tmp.replace(p)
state=read(CP)
v=state['versionedCache75']
assert v['activeController'] is None and not v['ownHeavyWorkloads']
assert read(ART/'tracking88-residual-context-v1/session-consumed.json')['original_tool_result_consumed']
assert shutil.disk_usage(ROOT).free>=10<<30
assert not {'RUST_MIN_STACK','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'} & os.environ.keys()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert head=='365de8e7a4647d600af8d816850c9f944cf1a522'
main=subprocess.check_output(['git','rev-parse','origin/main'],cwd=WORK,text=True).strip()
assert main=='ac65d279c57626d7aa7e28061a1a7fdf7889c68a'
subprocess.run(['git','merge-base','--is-ancestor',main,head],cwd=WORK,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
assert not subprocess.check_output(['git','diff','--name-only',main,'--','desktop/app/src/panels'],cwd=WORK)
paths=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def hashes():
    return {n:sha(WORK/n) for n in paths}
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
ff=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),
    CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
    TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),LOCALAPPDATA=str(OUT/'appdata'),
    RUST_BACKTRACE='full',PYTHONDONTWRITEBYTECODE='1',
    LIBCLANG_PATH=str(ROOT/'.tools/python-libclang/clang/native'),FFMPEG_DIR=str(ff),
    FFMPEG_INCLUDE_DIR=str(ff/'include'),FFMPEG_LIB_DIR=str(ff/'lib'))
env['PATH']=str(ff/'bin')+os.pathsep+env['PATH']
for name,folder in [('SAMPLING_PLAYBACK','sampling-playback'),('FRAME_UI','frame-export'),
    ('POINT_SELECTION','path-selection'),('FROZEN_DEPTH','frozen-depth'),
    ('IMPORTED_CAMERA_OUTPUT','imported-camera'),('TRACKED_PROTOTYPE_SURFACE','prototype-surface')]:
    env['MOTION_'+name+'_ARTIFACTS']=str(OUT/'outputs'/folder)
report=dict(status='running',head=head,main=main,source_sha256=hashes(),stages=[],in_flight=None,
    started_utc=datetime.now(timezone.utc).isoformat(),limits=[
        'Fresh integrated main source; original failures and narrow prior passes remain separate',
        'One owned heavy controller; source and HEAD frozen until original terminal tool result is consumed',
        'Full maintained workspace with original GPU/FFmpeg/AI-depth features; Android retired',
        'No changed assertions, waits, filters, ignores, stack size, runtime or GPU backend',
        'No retry, asset acquisition, cleanup, foreign process inspection or interference'])
v.update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(kind='tracking full integrated-main regression',
    head=head,sourceFrozen=True,output=str(OUT))])
v['currentTrackerNativeRun']=dict(head=head,main=main,status='running_unconsumed',output=str(OUT))
write(CP,state)
def save():
    write(OUT/'receipt.json',report)
def run(name,args):
    assert shutil.disk_usage(ROOT).free>=10<<30,'Original disk admission; no next command started'
    report['in_flight']=name
    row=dict(name=name,command=args,started_utc=datetime.now(timezone.utc).isoformat())
    report['stages'].append(row)
    save()
    with (OUT/(name+'.stdout.log')).open('xb') as stdout,(OUT/(name+'.stderr.log')).open('xb') as stderr:
        p=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        row['pid']=p.pid
        save()
        row['exit_code']=p.wait()
    row['completed_utc']=datetime.now(timezone.utc).isoformat()
    save()
    return row
save()
try:
    runtime=read(ART/'depth75-cache-regression-v3/receipt.json')['validationRuntime']
    expected={Path(p['source']).name:p['sha256'] for p in runtime}
    report['validation_runtime']=[]
    for name in ('avutil-60.dll','swresample-6.dll','avcodec-62.dll','avformat-62.dll','swscale-9.dll','avfilter-11.dll','avdevice-62.dll'):
        origin=ff/'bin'/name
        digest=sha(origin)
        assert digest==expected[name]
        for folder in ('debug','debug/deps'):
            dest=TARGET/folder/name
            dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.exists():
                assert sha(dest)==digest,'Refusing to overwrite different local runtime'
            else:
                shutil.copy2(origin,dest)
            assert sha(dest)==digest
            report['validation_runtime'].append(dict(source=str(origin),destination=str(dest),sha256=digest))
    save()
    assert run('python-ci-controls',[sys.executable,'-B','-m','unittest','discover','-s','tools','-p','test_ci_*.py','-v'])['exit_code']==0
    assert run('optional-cv-controls',['E:/Dev/aem/.tools/ai-depth74/venv/Scripts/python.exe','-B','-m','unittest','discover','-s','tools/tracking','-p','test*.py','-v'])['exit_code']==0
    assert run('desktop-check',[sys.executable,'-B','tools/build_desktop.py','--task','check','--debug','--locked','--target-dir',str(TARGET),'--','--offline'])['exit_code']==0
    metadata=subprocess.check_output(['cargo','metadata','--locked','--offline','--no-deps','--format-version','1'],cwd=WORK,env=env)
    (OUT/'cargo-metadata.json').write_bytes(metadata)
    metadata=json.loads(metadata)
    row=run('workspace',['cargo','test','--workspace','--exclude','motion-android','--locked','--offline',
        '--features','motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth,motion-host/gpu-tests,motion-render/gpu-tests,motion-ui/gpu-tests,motion-desktop/gpu-tests,motion-desktop-media/gpu-tests,motion-graph/gpu-tests',
        '--no-fail-fast','--','--test-threads=1'])
    stdout=(OUT/'workspace.stdout.log').read_text(encoding='utf-8',errors='replace')
    stderr=(OUT/'workspace.stderr.log').read_text(encoding='utf-8',errors='replace')
    summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
    expected_targets=[]
    by_name={}
    doc_owners={}
    for package in metadata['packages']:
        if package['id'] not in metadata['workspace_members'] or package['name']=='motion-android':continue
        for target in package['targets']:
            if not target['test']:continue
            relative=Path(target['src_path']).relative_to(WORK).as_posix()
            key=package['name']+'::'+target['kind'][0]+'::'+relative
            expected_targets.append(key)
            by_name.setdefault(target['name'].replace('-','_'),[]).append((relative,key))
        if any(t['doctest'] for t in package['targets']):
            key='doc::'+package['name']
            expected_targets.append(key)
            doc_owners[package['name'].replace('-','_')]=key
    observed=[]
    bound=[]
    for exe in re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)',stderr,re.M):
        path=Path(exe)
        raw=path.with_suffix('.d').read_bytes()
        line=raw.decode('utf-8').splitlines()[0].split(': ',1)[1].replace('\\','/')
        name=re.sub(r'-[a-f0-9]+$','',path.stem)
        owners=[key for relative,key in by_name[name] if re.search(r'(?<!\S)'+re.escape(relative)+r'(?!\S)',line)]
        assert len(owners)==1,(exe,owners)
        observed.extend(owners)
        bound.append(dict(executable=exe,target=owners[0],dep_info_sha256=hashlib.sha256(raw).hexdigest()))
    observed.extend(doc_owners[n] for n in re.findall(r'^\s*Doc-tests (\S+)\s*$',stderr,re.M))
    required='engine::tracking_video_replacement_tests::paired::surface::prototype::frozen_prototype_observations_present_retain_refuse_missing_and_recover'
    report.update(totals=dict(passed=sum(int(s[1]) for s in summaries),failed=sum(int(s[2]) for s in summaries),
        original_ignored=sum(int(s[3]) for s in summaries),filtered=sum(int(s[5]) for s in summaries),
        summary_count=len(summaries),observed_invocations=len(observed),expected_invocations=len(expected_targets)),
        source_bound_invocations=bound,missing_targets=dict(Counter(expected_targets)-Counter(observed)),
        unexpected_targets=dict(Counter(observed)-Counter(expected_targets)),
        full_target_coverage=Counter(expected_targets)==Counter(observed) and len(summaries)==len(observed),
        abnormal_target_exits=[s for s in stderr.splitlines() if "process didn't exit successfully:" in s],
        failed_test_names=re.findall(r'^test ([^\r\n]+?) \.\.\. FAILED\s*$',stdout,re.M),
        tracking_surface_control_passes=len(re.findall(r'^test '+re.escape(required)+r' \.\.\. ok$',stdout,re.M)))
    assert row['exit_code']==0 and report['full_target_coverage'] and not report['totals']['failed'] and not report['totals']['filtered'] and not report['abnormal_target_exits'] and report['tracking_surface_control_passes']==1
    report['status']='full_integrated_main_workspace_verified_original_failures_not_waived'
except BaseException:
    report.update(status='failed_original_outputs_retained',cause=traceback.format_exc())
finally:
    report.update(in_flight=None,completed_utc=datetime.now(timezone.utc).isoformat(),
        source_unchanged=hashes()==report['source_sha256'] and subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,
        logs={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in OUT.glob('*.log')})
    save()
    print(json.dumps({k:report.get(k) for k in ('status','head','totals','failed_test_names','abnormal_target_exits','source_unchanged','cause')}))
raise SystemExit(0 if report['status'].startswith('full_integrated_main_workspace_verified') and report['source_unchanged'] else 1)
