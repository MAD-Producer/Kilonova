from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
art=Path('E:/Dev/aem/artifacts/pr-queue')
out=art/'tracking88-current-main-workspace-v1'
work=Path('E:/Dev/aem/.worktrees/planar-tracker88')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=read(out/'receipt.json')
assert r['status']=='failed_original_outputs_retained' and r['source_unchanged']
assert len(r['stages'])==1 and r['stages'][0]['name']=='python-ci-controls' and r['stages'][0]['exit_code']==1
assert all(sha(work/n)==h for n,h in r['source_sha256'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==r['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work,text=True).strip()
log=(out/'python-ci-controls.stderr.log').read_text(encoding='utf-8')
assert log.count("ModuleNotFoundError: No module named 'yaml'")==2
assert 'FAILED (errors=2, skipped=1)' in log
proof=dict(session=22089,original_chunk_id='653466',exit_code=1,original_tool_result_consumed=True,
    source_unchanged=True,source_freeze_released=True,native_command_started=False,
    cause='Standard-library-only interpreter lacks the main workflow tests PyYAML prerequisite; two import errors',
    consumed_utc=datetime.now(timezone.utc).isoformat(),
    files={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()})
(out/'session-consumed.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
cp=art/'depth75-resume-current.json'
s=read(cp)
v=s['versionedCache75']
assert v['activeController']==str(art/'tracking88-current-main-workspace-v1-controller.py')
v.update(activeController=None,ownHeavyWorkloads=[],currentTrackerNativeRun=proof)
cp.write_bytes((json.dumps(s,indent=2)+'\n').encode())
print(json.dumps({k:proof[k] for k in ('session','exit_code','native_command_started','cause')}))
