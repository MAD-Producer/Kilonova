from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
art=Path('E:/Dev/aem/artifacts/pr-queue')
out=art/'tracking88-all-target-types-v1'
work=Path('E:/Dev/aem/.worktrees/planar-tracker88')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=read(out/'receipt.json')
assert r['status']=='failed_original_outputs_retained' and r['cargo_exit_code']==101 and r['source_unchanged']
assert all(sha(work/n)==h for n,h in r['source_sha256'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==r['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work,text=True).strip()
stderr=(out/'check.stderr.log').read_text(encoding='utf-8')
assert 'rustc.exe --crate-name ffmpeg_sys_next' in stderr
assert '(exit code: 0xc0000005, STATUS_ACCESS_VIOLATION)' in stderr
proof=dict(session=6510,original_chunk_id='52ef7f',exit_code=1,cargo_exit_code=101,
    original_tool_result_consumed=True,source_unchanged=True,source_freeze_released=True,
    consumed_utc=datetime.now(timezone.utc).isoformat(),
    cause='rustc access violation while emitting ffmpeg-sys-next metadata; no type-check completion or root-cause claim',
    files={p.name:sha(p) for p in out.iterdir() if p.is_file()})
(out/'session-consumed.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
cp=art/'depth75-resume-current.json'
s=read(cp)
v=s['versionedCache75']
assert v['activeController']==str(art/'tracking88-all-target-types-v1-controller.py')
v.update(activeController=None,ownHeavyWorkloads=[],currentTrackerTypeCheck=proof)
v['currentGoalTurnAudit']=dict(classification='progress',goal_complete=False,issue75_complete=False,issue88_complete=False,
    new_evidence=proof,previous_goal_turn='progress: committed observations, full-core equivalence and main integration; CI activated',
    no_subagents=True,no_panels_changes=True,no_asset_acquisition=True,
    remaining=['Current exact-head CI outcomes','Original compiler/runtime failures','Depth/tracker actual domain and quality acceptance'])
cp.write_bytes((json.dumps(s,indent=2)+'\n').encode())
print(json.dumps({k:proof[k] for k in ('session','cargo_exit_code','cause')}))
