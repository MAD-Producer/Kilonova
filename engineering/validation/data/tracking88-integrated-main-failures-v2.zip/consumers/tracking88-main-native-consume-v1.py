from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
art=Path('E:/Dev/aem/artifacts/pr-queue')
out=art/'tracking88-current-main-native-v1'
work=Path('E:/Dev/aem/.worktrees/planar-tracker88')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=read(out/'receipt.json')
assert r['status']=='failed_original_outputs_retained' and r['source_unchanged']
assert [s['exit_code'] for s in r['stages']]==[0,0,101]
assert all(sha(work/n)==h for n,h in r['source_sha256'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()==r['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work,text=True).strip()
assert r['totals']['observed_invocations']==r['totals']['summary_count']==0
assert r['totals']['expected_invocations']==447
assert len(r['abnormal_target_exits'])==1 and 'rustc.exe --crate-name motion_core' in r['abnormal_target_exits'][0]
assert '0xc0000005, STATUS_ACCESS_VIOLATION' in r['abnormal_target_exits'][0]
assert (out/'workspace.stdout.log').stat().st_size==0
proof=dict(session=85743,original_chunk_id='13946e',exit_code=1,cargo_exit_code=101,
    original_tool_result_consumed=True,source_unchanged=True,source_freeze_released=True,
    expected_test_invocations=447,started_test_invocations=0,desktop_check_exit=0,optional_cv_passes=10,
    cause='rustc crashed with access violation while compiling motion-core; no test executable started; no source/root-cause inference',
    consumed_utc=datetime.now(timezone.utc).isoformat(),
    files={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()})
(out/'session-consumed.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
cp=art/'depth75-resume-current.json'
s=read(cp)
v=s['versionedCache75']
assert v['activeController']==str(art/'tracking88-current-main-native-v1-controller.py')
v.update(activeController=None,ownHeavyWorkloads=[],currentTrackerNativeRun=proof)
v['currentGoalTurnAudit'].update(native_regression_running=False,
    source_frozen_until_original_tool_result_consumed=False,native_regression_failed=proof)
cp.write_bytes((json.dumps(s,indent=2)+'\n').encode())
print(json.dumps({k:proof[k] for k in ('session','exit_code','cargo_exit_code','started_test_invocations','cause')}))
