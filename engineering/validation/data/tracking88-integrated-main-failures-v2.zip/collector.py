"""Archive three original failures independently; do not retry them."""
from pathlib import Path
import hashlib
import json
import zipfile

ART = Path('E:/Dev/aem/artifacts/pr-queue')
OUT = ART / 'tracking88-main-failure-public-v2'
HEAD = '365de8e7a4647d600af8d816850c9f944cf1a522'
OUT.mkdir(exist_ok=False)
files = {}
records = []
for label, directory in [
    ('python-prerequisite', 'tracking88-current-main-workspace-v1'),
    ('native', 'tracking88-current-main-native-v1'),
    ('all-target-types', 'tracking88-all-target-types-v1'),
]:
    root = ART / directory
    receipt = json.loads((root / 'receipt.json').read_text(encoding='utf-8-sig'))
    consumed = json.loads((root / 'session-consumed.json').read_text(encoding='utf-8-sig'))
    assert receipt['head'] == HEAD
    assert consumed['original_tool_result_consumed'] and consumed['source_freeze_released']
    assert consumed['exit_code'] == 1
    for name, sha in consumed['files'].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha
    for path in root.iterdir():
        if path.is_file() and path.suffix in ('.json', '.py', '.log'):
            files[label + '/' + path.name] = path.read_bytes()
    records.append(dict(scope=label, session=consumed.get('session'),
                        original_chunk=consumed.get('original_chunk_id'), exit_code=1))
for name in ('tracking88-main-preflight-consume-v1.py',
             'tracking88-main-native-consume-v1.py',
             'tracking88-all-target-types-consume-v1.py'):
    files['consumers/' + name] = (ART / name).read_bytes()
files['collector.py'] = Path(__file__).read_bytes()
archive = OUT / 'tracking88-integrated-main-failures-v2.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
    for name, raw in sorted(files.items()):
        target.writestr(name, raw)
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(files)
    assert all(target.read(name) == raw for name, raw in files.items())
manifest = dict(archive=archive.name, bytes=archive.stat().st_size,
                sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), members=len(files),
                head=HEAD, main='ac65d279c57626d7aa7e28061a1a7fdf7889c68a',
                result='Three original failures retained; no complete native regression or type-check pass',
                sessions=records,
                files={name: dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
                       for name, raw in sorted(files.items())})
(OUT / 'tracking88-integrated-main-failures-v2.json').write_bytes(
    (json.dumps(manifest, indent=2) + '\n').encode())
print(json.dumps({k: manifest[k] for k in ('archive', 'bytes', 'sha256', 'members', 'sessions')}))
