"""Type-check test-bearing sources; no code generation or behavioral claim."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,traceback
ROOT=Path('E:/Dev/aem')
ART=ROOT/'artifacts/pr-queue'
WORK=ROOT/'.worktrees/planar-tracker88'
OUT=ART/'tracking88-all-target-types-v1'
TARGET=ROOT/'target/depth-wgsl-cache75-contract'
CP=ART/'depth75-resume-current.json'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    tmp=p.with_suffix(p.suffix+'.pending')
    tmp.write_bytes((json.dumps(v,indent=2)+'\n').encode())
    tmp.replace(p)
s=read(CP)
v=s['versionedCache75']
assert v['activeController'] is None and not v['ownHeavyWorkloads']
prior=read(ART/'tracking88-current-main-native-v1/session-consumed.json')
assert prior['original_tool_result_consumed'] and prior['exit_code']==1 and prior['started_test_invocations']==0
assert shutil.disk_usage(ROOT).free>=10<<30
assert not {'RUST_MIN_STACK','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'} & os.environ.keys()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert head=='365de8e7a4647d600af8d816850c9f944cf1a522'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
names=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
source={n:sha(WORK/n) for n in names}
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
ff=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),
    CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
    TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),LOCALAPPDATA=str(OUT/'appdata'),RUST_BACKTRACE='full',
    LIBCLANG_PATH=str(ROOT/'.tools/python-libclang/clang/native'),FFMPEG_DIR=str(ff),
    FFMPEG_INCLUDE_DIR=str(ff/'include'),FFMPEG_LIB_DIR=str(ff/'lib'))
env['PATH']=str(ff/'bin')+os.pathsep+env['PATH']
command=['cargo','check','--workspace','--exclude','motion-android','--all-targets','--locked','--offline',
    '--features','motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth,motion-host/gpu-tests,motion-render/gpu-tests,motion-ui/gpu-tests,motion-desktop/gpu-tests,motion-desktop-media/gpu-tests,motion-graph/gpu-tests']
report=dict(status='running',head=head,source_sha256=source,command=command,in_flight='all_target_type_check',
    started_utc=datetime.now(timezone.utc).isoformat(),prior_failed_native_receipt_sha256=sha(ART/'tracking88-current-main-native-v1/receipt.json'),
    scope='Test-bearing source type checking only; original code-generation failure remains failed; no test execution')
v.update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(kind='all-target source type check',head=head,sourceFrozen=True,output=str(OUT))])
write(CP,s)
write(OUT/'receipt.json',report)
try:
    with (OUT/'check.stdout.log').open('xb') as stdout,(OUT/'check.stderr.log').open('xb') as stderr:
        p=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        report['pid']=p.pid
        write(OUT/'receipt.json',report)
        report['cargo_exit_code']=p.wait()
    assert report['cargo_exit_code']==0,'All-target type checking failed; original output retained'
    report['status']='all_target_types_checked_no_behavioral_or_full_regression_claim'
except BaseException:
    report.update(status='failed_original_outputs_retained',cause=traceback.format_exc())
finally:
    report.update(in_flight=None,completed_utc=datetime.now(timezone.utc).isoformat(),
        source_unchanged=all(sha(WORK/n)==h for n,h in source.items()) and
        subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,
        logs={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in OUT.glob('*.log')})
    write(OUT/'receipt.json',report)
    print(json.dumps({k:report.get(k) for k in ('status','cargo_exit_code','source_unchanged','cause')}))
raise SystemExit(0 if report['status'].startswith('all_target_types_checked') and report['source_unchanged'] else 1)
