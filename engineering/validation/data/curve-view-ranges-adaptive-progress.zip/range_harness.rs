#[path = "E:/Dev/aem/.worktrees/curve-view-ranges/desktop/app/src/panels/graph_view.rs"]
mod graph_view;
