from pathlib import Path
import subprocess,hashlib,json,time
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges';out=root/'.tools/curve-view-ranges'
folder=out/'axis-stage-01';folder.mkdir(exist_ok=False)
source=work/'desktop/app/src/panels/graph_view.rs';before=hashlib.sha256(source.read_bytes()).hexdigest()
binary=folder/'range-tests.exe';start=time.monotonic()
build=['rustc','--edition=2024','--test',str(out/'range_harness.rs'),'-o',str(binary)]
with (folder/'compile.log').open('w',encoding='utf8') as sink:compiled=subprocess.run(build,stdout=sink,stderr=subprocess.STDOUT)
result=None
if compiled.returncode==0:
 with (folder/'tests.log').open('w',encoding='utf8') as sink:result=subprocess.run([str(binary),'--test-threads=1'],stdout=sink,stderr=subprocess.STDOUT)
record=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),source_sha256=before,
 source_unchanged=before==hashlib.sha256(source.read_bytes()).hexdigest(),compile_exit_code=compiled.returncode,
 test_exit_code=result.returncode if result else None,seconds=round(time.monotonic()-start,2),command=build,
 scope='Seven standalone range/lock/anchored-navigation primitive tests only; module not wired into panels, no full desktop/UI/issue259 completion claim.')
(folder/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8');print(json.dumps(record),flush=True)
if result:print((folder/'tests.log').read_text(encoding='utf8'),flush=True)
assert compiled.returncode==0 and result and result.returncode==0 and record['source_unchanged']
