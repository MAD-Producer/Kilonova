from pathlib import Path
import subprocess,hashlib,json,time,sys,re
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges';out=root/'.tools/curve-view-ranges'
attempt=sys.argv[1];folder=out/('adaptive-stage-'+attempt);folder.mkdir(exist_ok=False)
paths=['desktop/app/src/panels/graph_view.rs','desktop/app/src/panels/graph_adaptive.rs']
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
before=freeze()
for path in paths:(folder/Path(path).name).write_bytes((work/path).read_bytes())
binary=folder/'tests.exe';start=time.monotonic()
command=['rustc','--edition=2024','--test',str(out/'adaptive_harness.rs'),'-o',str(binary)]
with (folder/'compile.log').open('w',encoding='utf8') as sink:build=subprocess.run(command,stdout=sink,stderr=subprocess.STDOUT)
result=None
if build.returncode==0:
 with (folder/'tests.log').open('w',encoding='utf8') as sink:result=subprocess.run([str(binary),'--test-threads=1'],stdout=sink,stderr=subprocess.STDOUT)
record=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),sources=before,source_unchanged=before==freeze(),
 build_exit_code=build.returncode,test_exit_code=result.returncode if result else None,seconds=round(time.monotonic()-start,2),command=command,
 scope='Standalone actual graph range/adaptive code only; dense analytic oracle is not a native UI or complete issue259 acceptance.')
if result:record['summary']=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',(folder/'tests.log').read_text(encoding='utf8'))
(folder/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8');print(json.dumps(record),flush=True)
print((folder/('tests.log' if result else 'compile.log')).read_text(encoding='utf8')[-4000:],flush=True)
raise SystemExit(0 if build.returncode==0 and result and result.returncode==0 and record['source_unchanged'] else 1)
