from pathlib import Path
import subprocess,hashlib,json,time,re,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges';out=root/'.tools/curve-view-ranges'
attempt=sys.argv[1];folder=out/('app-stage-'+attempt);folder.mkdir(exist_ok=False)
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','*.rs','*.wgsl','*.toml','Cargo.lock','desktop/ui/styles/dark.json'],cwd=work,text=True).splitlines()
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths};sources=freeze()
roots=[p for p in paths if p.endswith('/src/lib.rs')]+['desktop/app/src/main.rs'] if attempt=='01' else ['desktop/app/src/main.rs']
for p in roots:(work/p).touch()
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1','--no-run']
start=time.monotonic();print('Frozen actual desktop adaptive stage build started.',flush=True)
with (folder/'build.log').open('w',encoding='utf8') as sink:build=subprocess.run(command,cwd=work,stdout=sink,stderr=subprocess.STDOUT)
records=[];digest=None
if build.returncode==0:
 text=(folder/'build.log').read_text(encoding='utf8');binary=Path(re.search(r'Executable unittests[^\n]*\(([^\n]+\.exe)\)',text).group(1));digest=hashlib.sha256(binary.read_bytes()).hexdigest()
 for name,filter in [('adaptive','panels::graph_adaptive::'),('sampling','panels::graph_sampling::'),('timeline','panels::timeline_shortcuts_tests::'),('handles','panels::graph_handles::')]:
  began=time.monotonic()
  with (folder/(name+'.log')).open('w',encoding='utf8') as sink:result=subprocess.run([str(binary),filter,'--nocapture','--test-threads=1'],cwd=work,stdout=sink,stderr=subprocess.STDOUT)
  text=(folder/(name+'.log')).read_text(encoding='utf8');summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
  record=dict(name=name,filter=filter,exit_code=result.returncode,seconds=round(time.monotonic()-began,2),summary=summary);records.append(record);print(json.dumps(record),flush=True)
record=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),build_exit_code=build.returncode,seconds=round(time.monotonic()-start,2),command=command,runs=records,binary_sha256=digest,source_unchanged=freeze()==sources,sources=sources,forced_roots=roots,
 scope='Actual current-worktree desktop compile; adaptive primitive+actualCoremodel dense samples and existing timeline/handle regressions only. Fit-selection, axis-lock GUI, mini/effect/comparison integration and native acceptance are still incomplete; no issue259completion claim.')
(folder/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in record.items() if k not in ['sources','forced_roots','command']}),flush=True)
raise SystemExit(0 if build.returncode==0 and len(records)==4 and all(x['exit_code']==0 for x in records) and record['source_unchanged'] else 1)
