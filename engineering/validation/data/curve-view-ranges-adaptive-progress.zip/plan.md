# #259 完整范围与执行边界

独立分支 codex/curve-view-ranges，工作树 E:/Dev/aem/.worktrees/curve-view-ranges，起点02e56f47（接续本人待合并519/518）。开始前核对开放PR只有518、519；本地相关curve-comparison/curve-input-views/旧curve-hold分支的能力已在当前基线中，没有正在开发的同一范围。根用户9个修改不动。共享target当前无本人运行中的Cargo；下一次切换工作树构建需强制model/core/ui/app等lib根以免复用结构不同的旧产物。

原issue259的范围保持：1核验已有Fit/缩放/平移，补选区适配与锁轴；2迷你图和时间轴图统一范围控制及明确单位读数；3高倍率误差驱动采样或精确曲线绘制。验收包括播放/滚动不打破轴锁、视图不写工程历史、主窗/原生浮窗与中英文一致、成功/取消/失效可复现；有持久数据变动才涉及保存重开/撤销数据契约。不能用只提高固定采样数、只实现一张图或孤立数学测试冒称完成。

当前实际调查：timeline_graph.rs与effect_timeline/graph.rs每次视图用256间隔采样，自动Y范围会随可见时间变化；curve_comparison/view.rs也缓存固定256采样，分组按实际Unit；animation_controls.rs迷你缓动图80间隔、归一化t/进度或速度，不能误把颜色CurveObject编辑器当成时间曲线。graph_workspace是现有Timeline路由，不是独立模型。参考线工作不改这些渲染器；519本地涉及的panels/mod.rs、types.rs、dark.json后续只在本分支增加范围状态/令牌并明确组合验收。

实施顺序：

1. 共享有限Range与AxisView。锁轴捕获当前实际显示范围，锁定期间自动范围、滚动、Fit不改该轴；解除锁定保持显示以避免跳轴，显式Fit All恢复自动范围。手工pan/zoom使用数据单位、指针锚定，非法/无法表示输入保持原视图。独立数学测试仅证明这些原语，不证明UI已可用。
2. 集成Timeline、效果Timeline与按Unit分组的comparison；范围按工程/合成/目标/单位/值或速度身份隔离，沿用现有横轴导航及选择所有权，不能在播放重绘时清空或跨图组串用锁定范围。菜单提供Fit Selection/Fit All/原生Checkbox锁X锁Y，关闭帧独占输入，不加属性行或缩小命中区。
3. 迷你缓动图使用相同范围/锁轴/读数契约，明确其归一化或物理单位映射。控制点编辑仍以真实模型参数提交，不能把进度误作像素/速度，零幅度、负幅度和不同时间跨度必须有回归。
4. 共享有界屏幕误差驱动细分，包含关键帧/不连续边界；保留模型真实采样/物理导数，选区Fit包含真实局部极值。观察功能边界分开：错误保留原因并复用有界observe，正常空选择/无目标/被锁住不算故障；不添worker/retry/timeout。
5. 实际Core采样密集参考对照、缩放/pan/锁范围不漂移、真实键与控制柄输入、Ctrl/Alt/Shift修饰、IME/modal/focus/跨窗失效、历史/文件字节不变；当前源码完整回归及中英主/浮窗最小/default/DPI截图。保留失败，不削弱旧断言，逐项DESIGN0.7与12范围报告。
6. 只有完整259本地验收后才创建PR/关闭issue；中文commit/title，5项真实CI，核对当前完整组合树，中文squash，保留本地并清理自己的远端。

2026-10-27 初步新增graph_view.rs仅是未接线原语，尚未加入panels/mod.rs，尚未Cargo编译或UI验证，无本项PR。下一步先跑独立数学测试，再接第2步，不能在此停成一个范围更窄的交付。
