Actual render/host readback acceptance source: 6230bdb9dcdfdab9f5dd62abf2b1adac2e8ed520
Actual combined desktop correctness source: 7e694cce803afd4b30951b1ea083249b09450005
Native application-budget measurement source: 53f2b24ef3bfc8c97811a3cd6748f8e0949cbfa0
Bundles require existing main ancestor 869042cefe820280014e21bd5414d52b13ae955a.
Renderer/host results are reused only with exhaustive unchanged-input proof.
No performance rerun at the combined source, full GPU stage coverage, physical pressure, Android acceptance or whole issue60 completion is claimed.
