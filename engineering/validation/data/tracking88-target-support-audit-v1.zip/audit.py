"""Retained-point diagnostic only: no decode, CV, tracker run or gate change."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,math,statistics,zipfile

BASE=Path('E:/Dev/aem/artifacts/pr-queue');OUT=BASE/'tracking88-target-support-audit-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inside(p,quad):
    cross=[]
    for a,b in zip(quad,quad[1:]+quad[:1]):
        cross.append((b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]))
    return all(v>=-1e-7 for v in cross) or all(v<=1e-7 for v in cross)
square=[[0.,0.],[4.,0.],[4.,3.],[0.,3.]]
for q in (square,list(reversed(square))):
    assert inside([2.,1.],q) and inside([0.,0.],q) and inside([4.,1.],q)
    assert not inside([4.1,1.],q) and not inside([-1.,-1.],q)
projective=[[2.,1.],[6.,2.],[5.,5.],[1.,4.]]
assert inside([3.,3.],projective) and not inside([7.,3.],projective)
path=BASE/'tracking88-low-order-reference-probe-v1/blind-correspondences.json'
truth=BASE/'tracking88-real-planar-acquisition-v1/phone-gt.zip'
assert sha(truth)=='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
with zipfile.ZipFile(truth) as z:
    assert z.getinfo('img_00200.txt').file_size<=1024
    values=list(map(float,z.read('img_00200.txt').decode('ascii').split()))
    assert len(values)==8 and all(map(math.isfinite,values))
    quad=[[values[4+k]-1,values[k]-1] for k in range(4)]
rows=json.loads(path.read_text(encoding='utf-8'));assert [r['index'] for r in rows]==list(range(1801,1831))
summary=[]
for row in rows:
    if not row['baselineVisible']:continue
    reference=row['reference'];holdout=row['holdout']
    assert len(reference)==len(holdout)==len(row['points']) and 16<=len(reference)<=200
    assert all(len(p)==2 and all(map(math.isfinite,p)) for p in reference)
    fit=[p for p,h in zip(reference,holdout) if not h]
    held=[p for p,h in zip(reference,holdout) if h]
    summary.append(dict(features=len(reference),fit=len(fit),holdout=len(held),
        outside_initial_annotated_target=sum(not inside(p,quad) for p in reference),
        outside_fit=sum(not inside(p,quad) for p in fit),outside_holdout=sum(not inside(p,quad) for p in held)))
assert summary
report=dict(status='retained_reference_support_membership_diagnostic_not_tracker_acceptance',
 observed_utc=datetime.now(timezone.utc).isoformat(),annotation_sha256=sha(truth),correspondences_sha256=sha(path),
 script_sha256=sha(Path(__file__)),segment=dict(first=1801,last=1830,visible=len(summary),lost=len(rows)-len(summary)),
 aggregates=dict(feature_min=min(r['features'] for r in summary),feature_max=max(r['features'] for r in summary),
 fit_min=min(r['fit'] for r in summary),holdout_min=min(r['holdout'] for r in summary),
 total_retained_points=sum(r['features'] for r in summary),
 outside_initial_target=sum(r['outside_initial_annotated_target'] for r in summary),
 outside_fit=sum(r['outside_fit'] for r in summary),outside_holdout=sum(r['outside_holdout'] for r in summary),
 frames_with_outside_points=sum(r['outside_initial_annotated_target']!=0 for r in summary)),
 limits=['Historical30-frame diagnostic correspondences, not the complete2300-frame acceptance output',
 'Membership refers to reference coordinates and the initial four-corner annotation; it cannot establish actual feature identity, nonplanarity, reflection or annotation correctness',
 'No video/CV/model/GPU work, feature recomputation, tracker mutation, threshold/coverage tuning or new native/CI qualification',
 'No third-party annotation arrays, point coordinates, media or per-frame rows are redistributed'])
OUT.mkdir(exist_ok=False);(OUT/'audit.py').write_bytes(Path(__file__).read_bytes())
(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'segment':report['segment'],'aggregates':report['aggregates']},indent=2))
