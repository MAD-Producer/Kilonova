from pathlib import Path
import json,hashlib,sys,math
from PIL import Image
out=Path('E:/Dev/aem/.tools/viewer-guides')/sys.argv[1]
r=json.loads((out/'receipt.json').read_text(encoding='utf8'))
assert r['build_exit_code']==0 and r['source_unchanged']
native=[run for run in r['runs'] if run['name']=='native']
assert len(native)==1 and native[0]['exit_code']==0 and native[0]['summary'][-1]==['ok','1','0','0']
root=out/'native';e=json.loads((root/'measurements.json').read_text(encoding='utf8'))
expected={'en-main-fit':(0,1.),'zh-main-zoom':(0,1.5),'en-float-min':(1,2.),'zh-float-zoom':(1,1.)}
assert {case['case'] for case in e['cases']}==set(expected) and len(e['cases'])==4
assert e['production_png_export_rgba_equal'] and not e['physical_os_input']
pngs=[];maximum=0.
for case in e['cases']:
 assert (case['window'],case['pixel_ratio'])==expected[case['case']]
 assert all(case[field] for field in ['guide_commit_undo','cancel','foreign_input_cancel','stale_revision_cancel','handle_toggle','grid_checkbox','scale_snap_undo','move_snap_undo'])
 assert len(case['measurements'])==6
 for m in case['measurements']:
  error=abs(m['expected_physical']-m['actual_physical']);assert math.isfinite(error) and error<1.5
  maximum=max(maximum,error)
 for suffix in ['overlays','menu','preview','scale','handles']:
  p=root/(case['case']+'-'+suffix+'.png');assert p.is_file()
  im=Image.open(p);assert im.size==tuple(round(v*case['pixel_ratio']) for v in case['logical_size'])
  pngs.append(dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),width=im.width,height=im.height))
for filename in ['export-before.png','export-after.png']:
 p=root/filename;assert p.is_file();im=Image.open(p);assert im.size==(640,480)
 pngs.append(dict(path=filename,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),width=im.width,height=im.height))
assert Image.open(root/'export-before.png').convert('RGBA').tobytes()==Image.open(root/'export-after.png').convert('RGBA').tobytes()
record=dict(binary_sha256=r['binary_sha256'],native_cases=4,png_count=len(pngs),maximum_line_centroid_error_physical_pixels=maximum,
 export_rgba_equal=True,controlled_pixel_ratios=[1.,1.5,2.],physical_os_input=False,pngs=pngs,
 scope='Actual hidden native main/floating surfaces with shared presentation, chrome Input routing and production capture export. Controlled scale ratios; no physical OS mouse or foreground input.')
(out/'native-verified.json').write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in record.items() if k!='pngs'}),flush=True)
