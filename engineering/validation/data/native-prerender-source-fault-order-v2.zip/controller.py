"""Queue three genuine negative controls, then qualify only the source-fault fix."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
from ctypes import wintypes as w
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/prerender-source-fault-order'
OUT = ROOT / 'artifacts/pr-queue/prerender-source-fault-order-v2'
PATCH = ROOT / '.tools/issue-closure-review/source-fault-order-fix.patch'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode('utf-8').strip()

def sources():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {p: hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in names
            if p and (p.endswith(('.rs', '.toml', '.wgsl', '.py', '.json', '.yml', '.yaml', '.md'))
                      or p in ('Cargo.lock', 'NOTICE'))}

head = git('rev-parse', 'HEAD')
assert head == '510484160fde38d18b177ba8c69baf19af1730dc'
original = sources()
tests = {p: h for p, h in original.items() if '/tests/' in p or p.endswith('/tests.rs')}
patch_bytes = PATCH.read_bytes()
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT/'controller.py')
(OUT/'fix.patch').write_bytes(patch_bytes)
report = dict(status='queued', head=head, source=original, steps=[],
              startedUtc=datetime.now(timezone.utc).isoformat(), waitingForOwner=73536,
              limits='Source-fault ordering component only. The prior complete-source P95 failures, abnormal native exits and all workspace receipts remain independent. This fix does not claim to resolve those failures. No panel, assertion or performance threshold changed.')

def save():
    (OUT/'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

save()
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
kernel.OpenProcess.restype = w.HANDLE
kernel.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]
kernel.WaitForSingleObject.restype = w.DWORD
kernel.CloseHandle.argtypes = [w.HANDLE]
kernel.CloseHandle.restype = w.BOOL
owner = kernel.OpenProcess(0x100000, False, 73536)
print(json.dumps(dict(waitingForOwner=73536, sourceFiles=len(original))), flush=True)

env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0', RUST_BACKTRACE='full',
           LOCALAPPDATA=str(OUT/'owned-profile'),
           MOTION_SOURCE_WATCH_LOG_ARTIFACTS=str(OUT/'default-logs'))
fixed = original

def step(name, args, expected=None, negative=None):
    print(json.dumps(dict(start=name)), flush=True)
    began = datetime.now(timezone.utc).isoformat()
    with (OUT/(name+'.stdout.log')).open('wb') as out, (OUT/(name+'.stderr.log')).open('wb') as err:
        code = subprocess.run(args, cwd=WORK, env=env, stdout=out, stderr=err).returncode
    stdout = (OUT/(name+'.stdout.log')).read_text(encoding='utf-8')
    stderr = (OUT/(name+'.stderr.log')).read_text(encoding='utf-8')
    counts = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored', stdout)
    unchanged = sources() == fixed and git('rev-parse', 'HEAD') == head
    if negative:
        # The isolated logging test forwards its child's failure in the parent assertion.
        # Verify BOTH real failures, rather than rejecting the intended negative proof.
        expected_counts = [('0', '1', '0')] * (2 if name == 'negative-logging' else 1)
        passed = code == 101 and counts == expected_counts and negative in stdout+stderr and unchanged
    else:
        passed = code == 0 and unchanged and (expected is None or counts == expected)
    row = dict(name=name, command=args, exitCode=code, counts=counts, passed=passed,
               sourceUnchanged=unchanged, startedUtc=began,
               completedUtc=datetime.now(timezone.utc).isoformat(), expectedNegative=negative)
    report['steps'].append(row)
    save()
    print(json.dumps(row), flush=True)
    assert passed, name

try:
    if owner:
        try:
            while True:
                result = kernel.WaitForSingleObject(owner, 10000)
                if result == 0:
                    break
                assert result == 258, f'owner wait failed: {result}'
        finally:
            kernel.CloseHandle(owner)
    previous = json.loads((ROOT/'artifacts/pr-queue/prerender-combined-v5/exit.json').read_text(encoding='utf-8'))
    assert previous.get('completedUtc') and previous['status'] != 'running', 'combined gate still active'
    assert previous['head'] == head
    assert sources() == original and PATCH.read_bytes() == patch_bytes, 'queued source changed'
    report.update(status='running', priorCombinedStatus=previous['status'])
    save()
    desktop = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--bin', 'motion-studio']
    media = ['cargo', 'test', '-p', 'motion-desktop-media', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--lib']
    controls = [
        ('state', 'movie::prerender::source_watch::tests::a_normal_change_cannot_hide_a_later_watcher_fault_before_retirement', 'a prior normal change must not hide a real fault'),
        ('logging', 'movie::prerender::source_watch::tests::fault_after_change_is_logged_once_at_info_without_holding_observation_lock', 'one change and one terminal fault only'),
        ('native', 'movie::prerender::coordinator::tests::source_freshness::a_change_followed_by_watcher_failure_stays_faulted_after_real_ack', 'a normal change must not mask the later watcher fault'),
    ]
    for label, name, reason in controls:
        step('negative-'+label, [*media, name, '--', '--exact', '--test-threads=1'], negative=reason)
    report['negativeControlsConfirmed'] = True
    save()
    for p in ('crates/motion-desktop-media/src/movie/prerender/source_watch.rs',
              'crates/motion-desktop-media/src/movie/prerender/coordinator.rs'):
        (OUT/(Path(p).stem+'.before.rs')).write_bytes((WORK/p).read_bytes())
    subprocess.run(['git', 'apply', '--check', str(PATCH)], cwd=WORK, check=True)
    subprocess.run(['git', 'apply', str(PATCH)], cwd=WORK, check=True)
    fixed = sources()
    assert all(fixed[p] == h for p, h in tests.items()), 'a regression assertion changed'
    changed = {p for p in fixed if fixed[p] != original[p]}
    assert changed == {'crates/motion-desktop-media/src/movie/prerender/source_watch.rs',
                       'crates/motion-desktop-media/src/movie/prerender/coordinator.rs'}
    report['fixedSource'] = fixed
    save()
    for label, name, _ in controls:
        step('fixed-'+label, [*media, name, '--', '--exact', '--test-threads=1'], expected=[('1', '0', '0')])
    step('all-source-watch', [*media, 'movie::prerender::source_watch::', '--', '--test-threads=1'], expected=[('10', '0', '0')])
    step('all-native-source', [*media, 'movie::prerender::coordinator::tests::source_freshness::', '--', '--test-threads=1'], expected=[('4', '0', '0')])
    step('media-prerender-regression', [*media, 'movie::prerender::', '--', '--test-threads=1'], expected=[('43', '0', '1')])
    step('default-source-logs', [*desktop, 'engine::pending_video_tests::prerender_logging::source_watch_records_default_info_and_setup_error_without_stdout_pollution', '--', '--exact', '--test-threads=1'], expected=[('1', '0', '0')])
    step('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline'])
    step('provenance', [sys.executable, 'tools/validate_provenance.py'])
    step('tool-inventory', [sys.executable, 'tools/validation_inventory.py'])
    report.update(status='accepted_source_fault_order_component_only', completedUtc=datetime.now(timezone.utc).isoformat())
    save()
    print(json.dumps(dict(status=report['status'])), flush=True)
except BaseException:
    report.update(status='failed_not_accepted', completedUtc=datetime.now(timezone.utc).isoformat())
    save()
    raise
