from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,re
root=Path("E:/Dev/aem")
w=root/".worktrees/depth-transition75"
out=root/"artifacts/pr-queue/depth75-worker-alignment-host-v2"
assert shutil.disk_usage(root).free>=10<<30
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=w,text=True).strip()=="878e1c301a1f71ff95b1f14eace72016d5cb4888"
files=subprocess.check_output(["git","ls-files"],cwd=w,text=True).splitlines()+["crates/motion-host/src/depth/transition/admission.rs","crates/motion-host/tests/depth_aligned_admission.rs","crates/motion-host/tests/depth_worker_alignment.rs"]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
snapshot=lambda:{n:sha(w/n) for n in sorted(set(files))}
before=snapshot()
targets=["depth_alignment","depth_transition","depth_transition_jobs","depth_routing","depth_aligned_admission","depth_worker_alignment"]
names=[]
for name in targets:
 names+=re.findall(r"#\[test\]\s*fn (\w+)",(w/f"crates/motion-host/tests/{name}.rs").read_text())
assert len(names)==len(set(names))==48
previous=root/"artifacts/pr-queue/depth75-worker-alignment-host-v1"
old=json.loads((previous/"receipt.json").read_text(encoding="utf-8"))
assert json.loads((previous/"session-consumed.json").read_text())["session"]==43268
assert json.loads((previous/"session-consumed.json").read_text())["exitCode"]==0
assert old["status"]=="full_host_and48_named_controls_passed" and old["sourceUnchanged"]
assert old["totals"]==dict(passed=443,failed=0,ignored=0,measured=0,filtered=0)
subprocess.run(["git","merge-base","--is-ancestor","adf529314647e559fad57a7da2107a1a3c4ffc92","HEAD"],cwd=w,check=True)
for name in ("crates/motion-host/src/depth.rs","crates/motion-host/src/depth/onnx.rs","crates/motion-host/src/depth/transition.rs","crates/motion-host/src/depth/transition/admission.rs","crates/motion-host/tests/depth_aligned_admission.rs","crates/motion-host/tests/depth_worker_alignment.rs","desktop/app/src/logging/sink.rs"):
 assert before[name]==old["source"][name], name
assert "RUSTC_WORKSPACE_WRAPPER" not in os.environ and "RUSTC_WRAPPER" not in os.environ
out.mkdir(exist_ok=False)
(out/"controller.py").write_bytes(Path(__file__).read_bytes())
env=os.environ.copy()
env.update(CARGO_HOME=str(root/".tools/prerender-cargo-home"),CARGO_TARGET_DIR=str(root/"target/colmap88-isolated-check"),CARGO_INCREMENTAL="0",CARGO_BUILD_JOBS="1",CARGO_PROFILE_DEV_DEBUG="0",CARGO_PROFILE_TEST_DEBUG="0",TEMP=str(out/"tmp"),TMP=str(out/"tmp"),LOCALAPPDATA=str(out/"appdata"))
(out/"tmp").mkdir()
command=["cargo","test","--locked","-p","motion-host","--features","ai-depth","--no-fail-fast","--","--test-threads=1"]
r=dict(status="running",base="878e1c301a1f71ff95b1f14eace72016d5cb4888",source=before,rebasedMain="adf529314647e559fad57a7da2107a1a3c4ffc92",changedSincePrevious=[n for n in before if before[n]!=old["source"].get(n)],command=command,expectedNames=names,startedUtc=datetime.now(timezone.utc).isoformat())
def save(): (out/"receipt.json").write_text(json.dumps(r,indent=2)+"\n")
save()
with (out/"stdout.log").open("wb") as stdout,(out/"stderr.log").open("wb") as stderr:
 child=subprocess.Popen(command,cwd=w,env=env,stdout=stdout,stderr=stderr)
 r["pid"]=child.pid;save();r["exitCode"]=child.wait()
text=(out/"stdout.log").read_text(encoding="utf-8",errors="replace")
r["sourceUnchanged"]=snapshot()==before
r["namedPasses"]=[n for n in names if len(re.findall(r"(?m)^test "+re.escape(n)+r" \.\.\. ok$",text))==1]
summaries=re.findall(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out",text)
r["testSummaries"]=[dict(status=row[0],passed=int(row[1]),failed=int(row[2]),ignored=int(row[3]),measured=int(row[4]),filtered=int(row[5])) for row in summaries]
r["totals"]={name:sum(row[name] for row in r["testSummaries"]) for name in ("passed","failed","ignored","measured","filtered")}
r["expectedIntegrationTargets"]=sorted(p.stem for p in (w/"crates/motion-host/tests").glob("*.rs"))
err=(out/"stderr.log").read_text(encoding="utf-8",errors="replace")
r["observedIntegrationTargets"]=re.findall(r"Running tests[\\/]([\w]+)\.rs",err)
r["allIntegrationTargetsAccounted"]=sorted(r["observedIntegrationTargets"])==r["expectedIntegrationTargets"]
r["completedUtc"]=datetime.now(timezone.utc).isoformat()
r["status"]="full_host_and48_named_controls_passed" if r["exitCode"]==0 and len(r["namedPasses"])==48 and r["sourceUnchanged"] and summaries and all(row[0]=="ok" for row in summaries) and r["totals"]["failed"]==0 and r["totals"]["filtered"]==0 and r["allIntegrationTargetsAccounted"] else "failed_original_outputs_retained"
save()
print(json.dumps({k:v for k,v in r.items() if k not in ("source","expectedNames","command","testSummaries","expectedIntegrationTargets","observedIntegrationTargets")}))
raise SystemExit(0 if r["status"]=="full_host_and48_named_controls_passed" else 1)
