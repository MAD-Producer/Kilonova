"""Archive actual post-rebase host results without relabeling older evidence."""
from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile

root = Path('E:/Dev/aem')
base = root / 'artifacts/pr-queue'
work = root / '.worktrees/depth-transition75'
directory = base / 'depth75-worker-alignment-host-v2'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda raw: hashlib.sha256(raw).hexdigest()
report = read(directory / 'receipt.json')
assert report['base'] == '878e1c301a1f71ff95b1f14eace72016d5cb4888'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip() == report['base']
assert report['status'] == 'full_host_and48_named_controls_passed' and report['sourceUnchanged']
assert report['allIntegrationTargetsAccounted'] and len(report['namedPasses']) == 48
assert report['totals']['failed'] == report['totals']['filtered'] == 0
consumed = read(directory / 'session-consumed.json')
assert consumed['session'] == 62805 and consumed['exitCode'] == 0
members = {name: (directory / name).read_bytes() for name in
           ('controller.py', 'receipt.json', 'session-consumed.json', 'stdout.log', 'stderr.log')}
names = ('crates/motion-host/src/depth.rs', 'crates/motion-host/src/depth/onnx.rs',
         'crates/motion-host/src/depth/transition.rs', 'crates/motion-host/src/depth/transition/admission.rs',
         'crates/motion-host/tests/depth_aligned_admission.rs', 'crates/motion-host/tests/depth_worker_alignment.rs',
         'desktop/app/src/logging/sink.rs')
prior = read(base / 'depth75-worker-alignment-native-v2/receipt.json')
for name in names:
    raw = (work / name).read_bytes()
    assert sha(raw) == report['source'][name] == prior['source'][name]
    members['source/' + name] = raw
members['archive-controller.py'] = Path(__file__).read_bytes()
manifest = dict(schema=1, status='post_rebase_complete_host_and48_named_controls_passed',
    sourceCommit=report['base'], rebasedMain=report['rebasedMain'], command=report['command'],
    totals=report['totals'], namedControls=48, integrationTargets=len(report['observedIntegrationTargets']),
    sourceDelta={name: report['source'][name] for name in names}, limits=[
        'Actual complete host command after rebase to main-adf52931; older workspace5002 and host443 keep their earlier source boundaries',
        'The original default-file RED/GREEN and final48 have identical selected code bytes and remain in the separate worker archive',
        'Cross-platform CI for the new head and a fresh complete maintained workspace are separate qualifications',
        'No Session automatic installation, persistent policy/cache/export, scene-quality tiers, video stability or thermal claim',
        'No panel/UI, dependency, asset, Android, assertion, feature, ignore, GPU/backend, timeout or resource-admission change',
    ], members={name: dict(bytes=len(raw), sha256=sha(raw)) for name, raw in members.items()})
out = base / 'depth75-worker-rebased-host-public-v1'
out.mkdir(exist_ok=False)
archive = out / 'depth75-worker-rebased-host-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
    for name, raw in members.items(): z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == {'manifest.json', *members}
    for name, raw in members.items(): assert z.read(name) == raw
manifest['archive'] = dict(file=archive.name, bytes=archive.stat().st_size,
                           sha256=sha(archive.read_bytes()), verifiedMembers=len(members) + 1)
sidecar = out / 'depth75-worker-rebased-host-v1.json'
sidecar.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
for source in (archive, sidecar): shutil.copyfile(source, work / 'engineering/validation/data' / source.name)
print(json.dumps(manifest['archive']))
