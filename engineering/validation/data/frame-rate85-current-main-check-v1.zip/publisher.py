from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/rational-frame-rates85'
base=root/'artifacts/pr-queue/frame-rate85-current-main-check-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((base/'exit.json').read_text(encoding='utf-8'))
assert report['status']=='passed_scoped_final_acceptance_pending' and report['sourceUnchanged']
assert all(sha(work/n)==digest for n,digest in report['sources'].items())
assert all(i['exitCode']==0 for i in report['results'])
scope=['crates/motion-render','crates/motion-core','crates/motion-model','desktop/app/src/panels','desktop/app/src/shell/rational_clock_native_tests.rs','desktop/app/src/shell/mod.rs']
assert not subprocess.check_output(['git','diff','b015ddad',report['head'],'--',*scope],cwd=work).strip()
terminal=dict(originalSession=61191,terminalConsumed=True,exitCode=0,reportSha256=sha(base/'exit.json'))
(base/'terminal-consumed.json').write_text(json.dumps(terminal,indent=2)+'\n',encoding='utf-8')
entries={p.name:p.read_bytes() for p in base.iterdir() if p.is_file()}
entries['environment.ps1']=(root/'.tools/issue-closure-review/run-clock-current-main-check-v1.ps1').read_bytes()
entries['publisher.py']=Path(__file__).read_bytes()
entries['manifest.json']=(json.dumps({n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in entries.items()},indent=2)+'\n').encode('utf-8')
archive=work/'engineering/validation/data/frame-rate85-current-main-check-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in entries.items():z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    for name,data in entries.items():assert z.read(name)==data
receipt=dict(head=report['head'],main='c0e25eda7c469c62ee94135e380647d818921662',status=report['status'],
             terminal=terminal,unchangedComparedToB015=scope,commands=report['results'],limits=report['limits'],
             archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members=len(entries)))
archive.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='commands'}))
