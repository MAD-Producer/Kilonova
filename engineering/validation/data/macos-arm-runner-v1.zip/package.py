import hashlib
import json
import zipfile
from pathlib import Path

out = Path(__file__).parent
root = Path.cwd()
meta = json.loads((out / 'workflow-policy.json').read_text(encoding='utf-8'))
assert meta['exit_code'] == 0
assert meta['source_before'] == meta['source_after']
assert meta['yaml'] == '6.0.3'
cases = json.loads((out / 'matrix-comparison.json').read_text(encoding='utf-8'))
assert len(cases) == 6
raw = out.parent / 'desktop-error-transport'
members = {name: (out / name).read_bytes() for name in [
    'validate.py', 'package.py', 'workflow-policy.json', 'workflow-policy.stdout',
    'workflow-policy.stderr', 'matrix-comparison.json',
]}
for name in ['main-arm-job.json', 'main-arm-check.json', 'main-arm-annotations.json']:
    members[name] = (raw / name).read_bytes()
for name in ['.github/workflows/ci.yml', 'tools/test_ci_workflow.py']:
    data = (root / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == meta['source_after'][name]
    members['source/' + name] = data
members['SHA256.json'] = json.dumps({name: hashlib.sha256(data).hexdigest()
    for name, data in sorted(members.items())}, indent=2).encode()
target = root / 'engineering/validation/data/macos-arm-runner-v1.zip'
target.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    checks = json.loads(archive.read('SHA256.json'))
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == sha for name, sha in checks.items())
print(json.dumps({'path': str(target), 'members':len(members), 'bytes':target.stat().st_size,
    'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
