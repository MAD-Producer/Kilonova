import copy, hashlib, json, os, subprocess, sys, time
from pathlib import Path

root = Path.cwd()
out = Path(__file__).parent
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, encoding='utf-8')

# The lightweight worktree contains CI/tools plus byte-identical manifests;
# existing workflow policy tests inspect all workspace package feature gates.
manifests = [p for p in git('ls-tree', '-r', '--name-only', 'HEAD').splitlines()
             if p.endswith('/Cargo.toml')]
for name in manifests:
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(subprocess.check_output(['git', 'show', 'HEAD:' + name], cwd=root))

sys.path.insert(0, str(root / 'tools'))
from test_ci_workflow import UniqueKeyLoader, expression_value
import yaml
old_text = git('show', 'HEAD:.github/workflows/ci.yml')
new_text = (root / '.github/workflows/ci.yml').read_text(encoding='utf-8')
assert old_text.count('"os":"macos-14"') == 2
assert new_text == old_text.replace('"os":"macos-14"', '"os":"macos-15"')
old = yaml.load(old_text, Loader=UniqueKeyLoader)
new = yaml.load(new_text, Loader=UniqueKeyLoader)
cases = []
normalized = copy.deepcopy(new)
for job in ['desktop-tests', 'desktop']:
    old_matrix = old['jobs'][job]['strategy']['matrix']['include']
    new_matrix = new['jobs'][job]['strategy']['matrix']['include']
    for event in ['pull_request', 'push', 'workflow_dispatch']:
        context = {'github': {'event_name': event}}
        before = expression_value(old_matrix, context)
        actual = expression_value(new_matrix, context)
        expected = copy.deepcopy(before)
        for row in expected:
            if row['platform'] == 'macos-arm64':
                assert row['os'] == 'macos-14'
                row['os'] = 'macos-15'
        assert actual == expected, (job, event, actual)
        assert expression_value(new['jobs'][job]['timeout-minutes'], {'matrix': {'os':'macos-15'}}) == 60
        cases.append({'job': job, 'event': event, 'before': before, 'after': actual})
    normalized['jobs'][job]['strategy']['matrix']['include'] = old_matrix
assert normalized == old, 'An unrelated gate, budget, permission or command changed'
(out / 'matrix-comparison.json').write_text(json.dumps(cases, indent=2), encoding='utf-8')

names = git('ls-files', '.github', 'tools', 'Cargo.toml', 'Cargo.lock').splitlines() + manifests
def sources():
    return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (root/n).is_file()}
command = [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_ci_workflow.py', '-v']
meta = {'head':git('rev-parse','HEAD').strip(), 'command':command, 'cwd':str(root),
        'source_before':sources(), 'python':sys.version, 'yaml':yaml.__version__}
began = time.monotonic()
with (out/'workflow-policy.stdout').open('wb') as stdout, (out/'workflow-policy.stderr').open('wb') as stderr:
    result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr)
meta.update(exit_code=result.returncode, elapsed_seconds=time.monotonic()-began, source_after=sources())
(out/'workflow-policy.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
print(json.dumps({'matrix_cases':len(cases),'unchanged_non_matrix_policy':True,'exit_code':result.returncode,
                  'elapsed_seconds':meta['elapsed_seconds'],'unchanged_source':meta['source_before']==meta['source_after']}))
raise SystemExit(result.returncode)
