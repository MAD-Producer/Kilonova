"""Check real v10 pass mappings against the independently retained v9 uses."""
from pathlib import Path
import hashlib
import json
import os
import struct
import sys

root = Path(os.environ.get('MOTION_SCRATCH_EVIDENCE_ROOT', 'E:/Dev/aem/artifacts/pr-queue'))
baseline, candidate, label = sys.argv[1:4]
dirs = [root / f'issue67-stage-{x}' / 'output' for x in (baseline, candidate)]
report = json.loads((dirs[0]/'report.json').read_text(encoding='utf-8'))
rows = []
for row in report['rows']:
    name = row['name']
    old, new = [(p/f'{name}.plan').read_bytes() for p in dirs]
    def word(data, offset): return struct.unpack_from('<I',data,offset)[0]
    def signed(data, offset): return struct.unpack_from('<i',data,offset)[0]
    def floats(data, offset, n): return struct.unpack_from('<'+'f'*n,data,offset)
    assert word(old,4)==9 and word(new,4)==10
    assert word(old,8)==word(new,8) and word(old,12)==word(new,12)
    allocations = [struct.unpack_from('<8I',new,word(new,140)+32*i) for i in range(word(new,144))]
    resources = []
    cursor = 0
    for draw in range(word(old,8)):
        before = floats(old,word(old,16)+128*draw,32)
        after = floats(new,word(new,16)+128*draw,32)
        begin, end = map(int,before[28:30])
        assert (begin,end)==tuple(map(int,after[28:30])) and begin==cursor
        values = {}
        final = None
        for index in range(begin,end):
            a = word(old,20)+40*index; b = word(new,20)+40*index
            point = index+draw
            for field in (4,8):
                semantic = signed(old,a+field); physical = signed(new,b+field)
                if semantic<0:
                    assert physical==semantic
                else:
                    resource = resources[values[semantic]]
                    assert physical==resource['physical']
                    resource['last']=point
            physical = word(new,b+12)
            assert 0<=physical<len(allocations)
            assert physical not in (signed(new,b+4), signed(new,b+8))
            semantic = word(old,a+12)
            w,h = word(old,a+16),word(old,a+20)
            assert (w,h)==(word(new,b+16),word(new,b+20))
            assert word(old,a)==word(new,b)
            assert old[word(old,a+24):word(old,a+24)+624]==new[word(new,b+24):word(new,b+24)+624]
            # Host utilities 0/2 output linear premultiplied pixels directly;
            # their shader ignores inherited output_mode.xy (unlike conversion1).
            modes = (0,0) if word(old,a) in (0,2) else floats(old,word(old,a+24)+96,2)
            fmt = 0 if semantic in (0,4,5,6) else 2 if semantic==7 else 1
            descriptor = allocations[physical]
            assert w<=descriptor[0] and h<=descriptor[1]
            assert fmt==descriptor[2] and descriptor[5]==15
            assert descriptor[3] & (1 << int(modes[0]))
            assert descriptor[4] & (1 << int(modes[1]))
            final = len(resources)
            resources.append(dict(first=point,last=point,physical=physical))
            values[semantic]=final
        if final is not None:
            resources[final]['last']=end+draw
            assert int(after[27])==resources[final]['physical']
            d = allocations[int(after[27])]
            assert abs(after[25]-w/d[0])<1e-6 and abs(after[26]-h/d[1])<1e-6
        else:
            assert before[27]==after[27]
        cursor=end
    assert cursor==word(old,12)
    for i,a in enumerate(resources):
        for b in resources[i+1:]:
            if a['physical']==b['physical']:
                assert a['last']<b['first'] or b['last']<a['first'], (name,a,b)
    rows.append(dict(name=name,logicalResources=len(resources),physicalAllocations=len(allocations),inclusiveLifetimeAliasing=False))
out = root/f'issue67-packed-lifetimes-{label}.json'
assert not out.exists()
out.write_text(json.dumps(dict(accepted=True,baseline=baseline,candidate=candidate,rows=rows,
    verifierSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    scope='All original input/source uses and uniforms retained; no physical overlap through terminal consumers'),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(receipt=str(out),cases=len(rows))))
