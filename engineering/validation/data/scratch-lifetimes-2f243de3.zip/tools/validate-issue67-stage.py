"""Run one actual bounded issue67 gate, retaining its exact dirty inputs."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import sys

root = Path('E:/Dev/aem')
work = root / '.worktrees/scratch-lifetime-sizing'
label, phase = sys.argv[1:3]
assert re.fullmatch(r'[a-z0-9-]+', label)
out = root / 'artifacts/pr-queue' / f'issue67-stage-{label}'
if phase == 'baseline-native':
    work = root / '.worktrees/scratch-lifetime-baseline'
commands = {
    'check': ['cargo', 'check', '-p', 'motion-render', '--lib', '--offline'],
    'unit': ['cargo', 'test', '-p', 'motion-render', '--lib', 'effect_plan::scratch', '--offline', '--', '--test-threads=1', '--nocapture'],
    'native-basic': ['cargo', 'test', '-p', 'motion-render', '--test', 'effects', '--offline', '--', '--test-threads=1', '--nocapture'],
    'render-all': ['cargo', 'test', '-p', 'motion-render', '--offline', '--no-fail-fast', '--', '--test-threads=1'],
    'budget': ['cargo', 'test', '-p', 'motion-render', '--test', 'device_scratch_budget', '--offline', '--', '--test-threads=1'],
    'poison': ['cargo', 'test', '-p', 'motion-render', '--lib', 'restored_effect_snapshots_clear_poisoned_padding', '--offline', '--', '--test-threads=1', '--nocapture'],
    'planning': ['cargo', 'test', '-p', 'motion-render', '--test', 'scratch_planning', '--offline', '--', '--test-threads=1', '--nocapture'],
    'dynamic-native': ['cargo', 'test', '-p', 'motion-render', '--lib', 'renderer::scratch_reuse_tests', '--offline', '--', '--test-threads=1', '--nocapture'],
    'phase-adjustments': ['cargo', 'test', '-p', 'motion-render', '--test', 'phase_adjustments', '--offline', '--', '--test-threads=1'],
    'host-contract': ['cargo', 'test', '-p', 'motion-host', '--test', 'failure_boundaries', 'portable_buffer_hint_and_physical_table', '--offline', '--', '--test-threads=1', '--nocapture'],
    'host-all': ['cargo', 'test', '-p', 'motion-host', '--offline', '--no-fail-fast', '--', '--test-threads=1'],
    'desktop-check': ['cargo', 'check', '-p', 'motion-desktop', '--offline'],
    'desktop-policy-check': [sys.executable, 'tools/build_desktop.py', '--task', 'check', '--target-dir', str(root / 'target/original-source-memory-b273180a'), '--report', str(out / 'desktop-build.json')],
    'desktop-all': ['cargo', 'test', '-p', 'motion-desktop', '--offline', '--no-fail-fast', '--', '--test-threads=1'],
    'integrated-all': ['cargo', 'test', '-p', 'motion-render', '-p', 'motion-host', '-p', 'motion-desktop', '--features', 'motion-host/diagnostics', '--offline', '--no-fail-fast', '--', '--test-threads=1'],
    'baseline-native': ['cargo', 'run', '-p', 'motion-render', '--example', 'scratch_native_comparison', '--offline', '--', str(out / 'output')],
    'candidate-native': ['cargo', 'run', '-p', 'motion-render', '--example', 'scratch_native_comparison', '--offline', '--', str(out / 'output')],
}
command = commands[phase]
out.mkdir(exist_ok=False)
paths = set()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip()
integration_base = subprocess.check_output(['git', 'merge-base', head, 'origin/main'], cwd=work, text=True).strip()
for args in [('diff', '--name-only', '-z'), ('ls-files', '--others', '--exclude-standard', '-z')]:
    paths.update(p.decode() for p in subprocess.check_output(['git', *args], cwd=work).split(b'\0') if p)
paths.update(p.decode() for p in subprocess.check_output(
    ['git', 'diff', '--name-only', '-z', integration_base, head], cwd=work).split(b'\0') if p)
inputs = {}
for name in sorted(paths):
    source = work / name
    if source.is_file():
        data = source.read_bytes()
        dest = out / 'source' / name
        dest.parent.mkdir(exist_ok=True, parents=True)
        dest.write_bytes(data)
        inputs[name] = hashlib.sha256(data).hexdigest()
(out / 'tracked.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=work))
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root / 'target/original-source-memory-b273180a'),
    CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_NET_OFFLINE='true',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', RUST_BACKTRACE='full')
receipt = dict(command=command, cwd=str(work), sourceSha256=inputs,
    dirtySource=bool(subprocess.check_output(['git', 'status', '--porcelain'], cwd=work)),
    base=head, integrationBase=integration_base,
    sourceTree=subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=work, text=True).strip(),
    target=env['CARGO_TARGET_DIR'], temp=env.get('TEMP'),
    startedUtc=datetime.now(timezone.utc).isoformat())
env['MOTION_SCRATCH_NATIVE_REVISION'] = receipt['base'] + ':' + label
(out / 'started.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
with (out / 'stdout.log').open('xb') as stdout, (out / 'stderr.log').open('xb') as stderr:
    result = subprocess.run(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(), exitCode=result.returncode)
(out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
assert all(hashlib.sha256((work / name).read_bytes()).hexdigest() == h for name, h in inputs.items()), 'Source changed during validation'
print((out / 'stderr.log').read_text(errors='replace')[-5000:])
print((out / 'stdout.log').read_text(errors='replace')[-5000:])
if result.returncode:
    raise SystemExit(result.returncode)
if phase in {'unit', 'native-basic', 'render-all', 'budget', 'poison', 'planning', 'dynamic-native', 'phase-adjustments', 'host-contract', 'host-all', 'desktop-all', 'integrated-all'}:
    text = (out / 'stdout.log').read_text(errors='replace')
    receipt['summaries'] = [dict(passed=int(a), failed=int(b), ignored=int(c)) for a,b,c in
        re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', text)]
    assert receipt['summaries']
if phase in {'baseline-native', 'candidate-native'}:
    report = json.loads((out / 'output/report.json').read_text(encoding='utf-8'))
    assert len(report['rows']) == 8
    expected_version = 9 if phase == 'baseline-native' else 10
    assert all(row['packedPlanVersion'] == expected_version for row in report['rows']), 'Wrong renderer artifact reused across worktrees'
    executable = Path(env['CARGO_TARGET_DIR']) / 'debug/examples/scratch_native_comparison.exe'
    receipt['executableSha256'] = hashlib.sha256(executable.read_bytes()).hexdigest()
    receipt['nativeReport'] = report
receipt['accepted'] = True
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
