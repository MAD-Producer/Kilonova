"""Independently verify native output bytes and physical top-pool allocation."""
from pathlib import Path
import hashlib
import json
import os
import sys
from PIL import Image

root = Path(os.environ.get('MOTION_SCRATCH_EVIDENCE_ROOT', 'E:/Dev/aem/artifacts/pr-queue'))
baseline, candidate, label = sys.argv[1:4]
assert label.replace('-', '').isalnum()
dirs = [root / f'issue67-stage-{name}' for name in (baseline, candidate)]
reports = [json.loads((p / 'output/report.json').read_text(encoding='utf-8')) for p in dirs]
receipts = [json.loads((p / 'accepted.json').read_text(encoding='utf-8')) for p in dirs]
assert all(r['accepted'] and r['exitCode'] == 0 for r in receipts)
assert receipts[0]['executableSha256'] != receipts[1]['executableSha256']
driver = 'crates/motion-render/examples/scratch_native_comparison.rs'
assert receipts[0]['sourceSha256'][driver] == receipts[1]['sourceSha256'][driver]
assert reports[0]['adapter'] == reports[1]['adapter']
assert len(reports[0]['rows']) == len(reports[1]['rows']) == 8
rows = []
for old, new in zip(*(r['rows'] for r in reports)):
    name = old['name']
    assert new['name'] == name
    assert old['projectSha256'] == new['projectSha256']
    assert old['packedPlanVersion'] == 9 and new['packedPlanVersion'] == 10
    pixels = []
    for row, directory in zip((old, new), dirs):
        data = (directory / 'output' / f'{name}.rgba').read_bytes()
        assert len(data) == 512 * 512 * 4
        assert hashlib.sha256(data).hexdigest() == row['rgbaSha256']
        with Image.open(directory / 'output' / f'{name}.png') as im:
            assert im.size == (512, 512) and im.convert('RGBA').tobytes() == data
        assert row['actualTopScratchBytes'] == row['plannedTopScratchBytes']
        pixels.append(data)
    assert pixels[0] == pixels[1], f'{name}: native pixels changed'
    visibility = None
    if name == 'generator-matte-nested':
        controls = []
        for row, directory, combined in zip((old, new), dirs, pixels):
            assert row['generatorContributionVerified'] is True
            control = (directory / 'output/generator-disabled.rgba').read_bytes()
            assert len(control) == len(combined) and control != combined
            with Image.open(directory / 'output/generator-disabled.png') as im:
                assert im.size == (512, 512) and im.convert('RGBA').tobytes() == control
            controls.append(control)
        assert controls[0] == controls[1], 'Generator-disabled control changed'
        combined, control = pixels[1], controls[1]
        visibility = dict(
            generatorChangedPixels=sum(combined[i:i+4] != control[i:i+4]
                for i in range(0, len(control), 4)),
            nestedMatteControlVisiblePixels=sum(control[i+3] > 0 and any(control[i:i+3])
                for i in range(0, len(control), 4)),
            nestedMattePixelsPreservedWithGenerator=sum(control[i+3] > 0
                and any(control[i:i+3]) and combined[i:i+4] == control[i:i+4]
                for i in range(0, len(control), 4)))
        assert all(value > 0 for value in visibility.values()), 'Combined fixture must visibly retain both inputs'
    descriptors = new['physicalOrSemanticDescriptors']
    resources = new['textureLedger']['resources'].values()
    actual = {}
    for resource in resources:
        for reference in resource['references']:
            owner = reference['owner']
            if reference['category'] == 'effectScratch' and owner.startswith('effects/pool/'):
                index = int(owner.removeprefix('effects/pool/'))
                assert index not in actual
                actual[index] = resource
    assert len(actual) == len(descriptors)
    capacity = 0
    formats = ['Rgba8UnormSrgb', 'Rgba8Unorm', 'Rgba16Float']
    for index, d in enumerate(descriptors):
        w, h, fmt, working, alpha, usage, bpp, reserved = d
        assert w > 0 and h > 0 and fmt in range(3)
        assert working in range(1,4) and alpha in range(1,4)
        assert usage == 15 and bpp == (8 if fmt == 2 else 4) and reserved == 0
        resource = actual[index]
        assert (resource['width'], resource['height'], resource['format'], resource['logicalBytes']) == (w, h, formats[fmt], w*h*bpp)
        capacity += resource['logicalBytes']
    assert capacity == new['actualTopScratchBytes']
    rows.append(dict(name=name, exactPixels=True, projectSha256=old['projectSha256'],
        rgbaSha256=new['rgbaSha256'], baselineBytes=old['actualTopScratchBytes'],
        candidateBytes=capacity, physicalAllocations=len(descriptors),
        reductionFraction=1-capacity/old['actualTopScratchBytes'],
        generatorVisibility=visibility))
result = dict(accepted=True, baseline=baseline, candidate=candidate,
    verifierSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    sourceReceipts=[dict(base=r['base'], sourceSha256=r['sourceSha256']) for r in receipts],
    adapter=reports[0]['adapter'], driverSha256=receipts[0]['sourceSha256'][driver],
    rows=rows, scope='Debug native pixel equivalence and exact top-pool descriptor bytes; no physical VRAM, universal savings or latency claim',
    limits=['Only the measured fixtures and top-level active scratch pool are compared',
            'These eight captures do not establish all boundary, BSP, failure/recovery or consumer cases'])
out = root / f'issue67-native-comparison-{label}.json'
assert not out.exists()
out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(receipt=str(out), cases=len(rows), exactPixels=True)))
