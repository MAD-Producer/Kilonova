"""Archive actual completed issue67 gates; reject missing or mismatched evidence."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys
import zipfile

root = Path('E:/Dev/aem')
records = root / 'artifacts/pr-queue'
scripts = root / '.tools/issue-closure-review'
source = '2f243de3176ed4714ee9dae17f20f3b0acefdf80'
baseline_source = '1d1f284245fcd50391f672ef79653d09d432e219'
baseline, candidate, label = sys.argv[1:4]
files = {}

def add(path, name):
    assert name not in files and path.is_file(), name
    files[name] = path.read_bytes()

def gate(name, expected_source=None, expected_count=None):
    folder = records / f'issue67-stage-{name}'
    accepted = json.loads((folder / 'accepted.json').read_text(encoding='utf-8'))
    assert accepted['accepted'] and accepted['exitCode'] == 0
    if expected_source:
        assert accepted['base'] == expected_source
    if 'summaries' in accepted:
        assert sum(row['failed'] for row in accepted['summaries']) == 0
        if expected_count is not None:
            assert sum(row['passed'] for row in accepted['summaries']) == expected_count
            assert sum(row['ignored'] for row in accepted['summaries']) == 0
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            add(path, 'records/' + path.relative_to(records).as_posix())
    return accepted

full = gate('integrated-all-v1', source)
gate('integrated-phase-adjustments-v1', source, 9)
gate('integrated-dynamic-native-v1', source, 2)
gate('integrated-host-contract-v1', source, 1)
gate('integrated-desktop-check-v1', source)
gate('integrated-desktop-policy-check-v1', source)
old = gate(baseline, baseline_source)
new = gate(candidate, source)
assert old['executableSha256'] != new['executableSha256']

for filename in [f'issue67-native-comparison-{label}.json', f'issue67-packed-lifetimes-{label}.json']:
    path = records / filename
    receipt = json.loads(path.read_text(encoding='utf-8'))
    assert receipt['accepted'] and receipt['baseline'] == baseline and receipt['candidate'] == candidate
    add(path, 'records/' + filename)

jvm = records / 'issue67-jvm-v3'
jvm_receipt = json.loads((jvm / 'accepted.json').read_text(encoding='utf-8'))
assert jvm_receipt['accepted'] and jvm_receipt['testCount'] == 5
assert jvm_receipt['androidDeviceValidated'] is False
for name, digest in jvm_receipt['sourceSha256'].items():
    assert new['sourceSha256'][name] == digest, name
for path in sorted(jvm.rglob('*')):
    if path.is_file():
        add(path, 'records/' + path.relative_to(records).as_posix())

# Historical failed/invalid attempts retain their exact state and source.
# Their old accepted wrapper is not current acceptance: invalidation is retained.
for name in ['native-baseline-v1', 'native-candidate-v1', 'native-regression-v1',
             'native-budget-recovery-v2', 'native-regression-v2']:
    folder = records / f'issue67-stage-{name}'
    assert (folder / 'exit.json').is_file()
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            add(path, 'history/' + path.relative_to(records).as_posix())

bundle = records / 'issue67-source-2f243de3.bundle'
assert hashlib.sha256(bundle.read_bytes()).hexdigest() == 'f3186bdfadc3eaee35ef7468f485ceaeec9bcf1ffeb72b338e34b98a62402e73'
add(bundle, 'source/issue67-source-2f243de3.bundle')
for name in ['validate-issue67-stage.py', 'validate-issue67-jvm.py',
             'verify-issue67-native-comparison.py', 'verify-issue67-packed-lifetimes.py',
             'archive-issue67-evidence.py']:
    add(scripts / name, 'tools/' + name)
readme = f'''# Issue 67 source-bound evidence

Candidate source: {source}
Baseline source and bundle prerequisite: {baseline_source}
Native adapter/backend/driver and fixture parameters are in each report.
This is Debug pixel/capacity correctness, not a Release performance comparison
or physical VRAM measurement. Android device/GL validation was excluded.

The source bundle contains the candidate commit, requiring the public baseline
commit. Verify it with git bundle verify after fetching that prerequisite.
Native source-identical fixture drivers, project files, packed plans, raw RGBA,
decoded PNGs, descriptor/native ownership ledgers and exact source hashes live
in the two native stage directories under records. The generator-disabled
control must differ visibly from the combined nested/matte/generator frame.

Set MOTION_SCRATCH_EVIDENCE_ROOT to the extracted records directory, install
Pillow if unavailable, then run the two independent verifier scripts with
arguments {baseline} {candidate} replay. They create new replay receipts and
must not overwrite the archived originals. Their scripts' own SHA is recorded.

Historical failed gates are deliberately retained under history. In particular,
the old candidate-v1 reused a baseline binary and is INVALID; it is not native
candidate acceptance even if the original weak wrapper said accepted. Later
passing tests do not rewrite any earlier failure or prove its source passed.

The current complete test gate is integrated-all-v1. Focused tests overlap it.
Final PR CI and maintained-scope issue closure are separate delivery states;
this raw archive alone does not claim that CI or the issue is complete.
'''
files['README.md'] = readme.encode('utf-8')
inventory = {name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
             for name, data in sorted(files.items())}
files['inventory.json'] = json.dumps(inventory, indent=2).encode('utf-8')
out = records / f'issue67-scratch-lifetimes-{source[:8]}.zip'
assert not out.exists()
with zipfile.ZipFile(out, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(files.items()):
        archive.writestr(name, data)
# Read the finished artifact independently rather than trusting the write loop.
with zipfile.ZipFile(out) as archive:
    actual = json.loads(archive.read('inventory.json'))
    assert set(archive.namelist()) == set(actual) | {'inventory.json'}
    for name, item in actual.items():
        data = archive.read(name)
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], name
receipt = dict(recordedUtc=datetime.now(timezone.utc).isoformat(), source=source,
    baselineSource=baseline_source, archive=str(out), bytes=out.stat().st_size,
    sha256=hashlib.sha256(out.read_bytes()).hexdigest(), inventoryEntries=len(inventory),
    inventoryReadbackVerified=True, androidDeviceValidated=False,
    issueComplete=False, fullGateSummaries=full['summaries'])
receipt_path = records / f'issue67-scratch-lifetimes-{source[:8]}-archive.json'
assert not receipt_path.exists()
receipt_path.write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt, indent=2))
