"""Offline production Kotlin compilation and actual JVM descriptor parser tests."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET

root=Path('E:/Dev/aem')
work=root/'.worktrees/scratch-lifetime-sizing'
out=root/'artifacts/pr-queue'/f'issue67-jvm-{sys.argv[1]}'
out.mkdir(exist_ok=False)
paths=['android/app/src/main/java/com/motionstudio/editor/'+name+'.kt' for name in
    ['RenderPlanBudget','GlEffects','VideoExporter']]
paths+=['android/app/src/test/java/com/motionstudio/editor/RenderPlanBudgetTest.kt']
inputs={}
for name in paths:
    data=(work/name).read_bytes(); p=out/'source'/name
    p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data)
    inputs[name]=hashlib.sha256(data).hexdigest()
env=os.environ.copy()
env.update(JAVA_HOME=str(root/'.tools/jdk/jdk-21.0.12.1+1'),
    ANDROID_HOME=str(root/'.tools/android-sdk'),GRADLE_USER_HOME=str(root/'.tools/gradle-cache'),
    JAVA_TOOL_OPTIONS='-Djava.io.tmpdir=E:/Dev/aem/target/ci-policy-validation-tmp')
command=[str(root/'.tools/gradle-8.11.1/bin/gradle.bat'),'-p',str(work/'android'),
    '--offline','--no-daemon','--max-workers=1','testDebugUnitTest',
    '--tests','com.motionstudio.editor.RenderPlanBudgetTest']
receipt=dict(cwd=str(work),command=command,sourceSha256=inputs,startedUtc=datetime.now(timezone.utc).isoformat(),
    androidDeviceValidated=False)
(out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
    result=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr)
receipt.update(exitCode=result.returncode,completedUtc=datetime.now(timezone.utc).isoformat())
(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
assert all(hashlib.sha256((work/name).read_bytes()).hexdigest()==h for name,h in inputs.items())
print((out/'stderr.log').read_text(errors='replace')[-2400:])
print((out/'stdout.log').read_text(errors='replace')[-3000:])
if result.returncode: raise SystemExit(result.returncode)
xml=work/'android/app/build/test-results/testDebugUnitTest/TEST-com.motionstudio.editor.RenderPlanBudgetTest.xml'
data=xml.read_bytes(); (out/'RenderPlanBudgetTest.xml').write_bytes(data)
suite=ET.fromstring(data)
assert int(suite.attrib['tests'])==5 and int(suite.attrib['failures'])==0 and int(suite.attrib['errors'])==0 and int(suite.attrib['skipped'])==0
receipt.update(accepted=True,testCount=5,tests=[t.attrib['name'] for t in suite.findall('testcase')])
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
