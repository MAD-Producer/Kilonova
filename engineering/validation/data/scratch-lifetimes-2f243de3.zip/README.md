# Issue 67 source-bound evidence

Candidate source: 2f243de3176ed4714ee9dae17f20f3b0acefdf80
Baseline source and bundle prerequisite: 1d1f284245fcd50391f672ef79653d09d432e219
Native adapter/backend/driver and fixture parameters are in each report.
This is Debug pixel/capacity correctness, not a Release performance comparison
or physical VRAM measurement. Android device/GL validation was excluded.

The source bundle contains the candidate commit, requiring the public baseline
commit. Verify it with git bundle verify after fetching that prerequisite.
Native source-identical fixture drivers, project files, packed plans, raw RGBA,
decoded PNGs, descriptor/native ownership ledgers and exact source hashes live
in the two native stage directories under records. The generator-disabled
control must differ visibly from the combined nested/matte/generator frame.

Set MOTION_SCRATCH_EVIDENCE_ROOT to the extracted records directory, install
Pillow if unavailable, then run the two independent verifier scripts with
arguments integrated-baseline-native-v1 integrated-candidate-native-v1 replay. They create new replay receipts and
must not overwrite the archived originals. Their scripts' own SHA is recorded.

Historical failed gates are deliberately retained under history. In particular,
the old candidate-v1 reused a baseline binary and is INVALID; it is not native
candidate acceptance even if the original weak wrapper said accepted. Later
passing tests do not rewrite any earlier failure or prove its source passed.

The current complete test gate is integrated-all-v1. Focused tests overlap it.
Final PR CI and maintained-scope issue closure are separate delivery states;
this raw archive alone does not claim that CI or the issue is complete.
