use super::*;

#[test]
#[cfg_attr(not(feature = "gpu-tests"), ignore = "requires an actual GPU")]
fn restored_effect_snapshots_clear_poisoned_padding_and_preserve_valid_pixels() {
    let mut renderer = pollster::block_on(Renderer::headless()).unwrap();
    let package = motion_effects::builtin::package().unwrap();
    let definition = package.manifest.effects.iter().find(|e| e.id == "tint").unwrap();
    let mut project = Project::new(8, 8, 30, 1).unwrap();
    let mut layer = motion_core::Layer::solid(1, "snapshot restore", [8.; 2], [4., 4., 0.], [1.; 4]);
    layer.effects.push(motion_core::EffectInstance::new(1, &package.manifest.id,
        &package.manifest.version, &package.hash, definition, [8.; 2]));
    project.layers.push(layer);
    project.rebuild_plugin_dependencies();
    let mut scene = Scene::new(&project).unwrap();
    scene.sample(&project, 0., None, &motion_core::ExpressionEvaluator).unwrap();
    renderer.preflight_effects(&scene, 8, 8).unwrap();
    let frame = &renderer.effect_gpu.builder.frame;
    let output = renderer.effect_gpu.state.output(frame, 0).unwrap();
    assert_eq!((output.texture.width(), output.texture.height()), (8, 8));
    assert_eq!(output.texture.format(), wgpu::TextureFormat::Rgba8UnormSrgb);
    let mut readback = renderer.capture_target(8, 8).unwrap();
    readback.texture = output.texture.clone();
    readback.view = output.texture.admitted_view().unwrap();
    // Both padded restoration and full-size copies use the production helper.
    for size in [(2, 2), (8, 8), (2, 2)] {
        let source = renderer.capture_target(size.0, size.1).unwrap();
        let mut encoder = renderer.allocation_command_encoder(&Default::default()).unwrap();
        for (view, color) in [(&*source.view, wgpu::Color::RED),
            (&output.view, wgpu::Color { r: 1., g: 0., b: 1., a: 1. })] {
            drop(encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("poison scratch before snapshot restoration"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view, depth_slice: None, resolve_target: None,
                    ops: wgpu::Operations { load: wgpu::LoadOp::Clear(color), store: wgpu::StoreOp::Store },
                })], depth_stencil_attachment: None, timestamp_writes: None, occlusion_query_set: None, multiview_mask: None,
            }));
        }
        restore_effect_snapshot(&mut encoder, &source.texture, size, output);
        renderer.submit_allocated(encoder.finish(), |_| {}).unwrap();
        let pixels = renderer.read_target(&readback).unwrap();
        for (index, pixel) in pixels.chunks_exact(4).enumerate() {
            let expected = if index % 8 < size.0 as usize && index / 8 < size.1 as usize {
                [255, 0, 0, 255]
            } else { [0; 4] };
            assert_eq!(pixel, expected, "size={size:?}, pixel={index}");
        }
    }
    renderer.check_health().unwrap();
}
