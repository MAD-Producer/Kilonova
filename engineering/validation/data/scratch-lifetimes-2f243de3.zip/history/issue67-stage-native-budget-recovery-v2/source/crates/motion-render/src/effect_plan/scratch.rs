//! Explicit physical scratch descriptors shared by admission, native allocation
//! and the packed plan. Semantic slots remain local names while constructing
//! effects; they are never physical allocation identities.
use super::{scratch_graph as graph, scratch_lifetimes as placement, EffectFramePlan};
use crate::RenderError;
use serde::Serialize;
use std::ops::Range;

pub const MAX_SCRATCH_PASSES: usize = motion_model::MAX_LAYERS
    * (motion_effects::MAX_EFFECTS_PER_LAYER * (motion_effects::MAX_PASSES + 3) + 1);
pub const SCRATCH_RECORD_BYTES: usize = 32;
/// Portable usage bits: attachment, sampled, copy source, copy destination.
pub const SCRATCH_USAGE: u32 = 15;

#[repr(u32)]
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub enum ScratchFormat {
    Rgba8UnormSrgb = 0,
    Rgba8Unorm = 1,
    Rgba16Float = 2,
}
impl ScratchFormat {
    pub fn native(self) -> wgpu::TextureFormat {
        match self {
            Self::Rgba8UnormSrgb => wgpu::TextureFormat::Rgba8UnormSrgb,
            Self::Rgba8Unorm => wgpu::TextureFormat::Rgba8Unorm,
            Self::Rgba16Float => wgpu::TextureFormat::Rgba16Float,
        }
    }
    pub fn bytes_per_pixel(self) -> u32 {
        match self {
            Self::Rgba8UnormSrgb | Self::Rgba8Unorm => 4,
            Self::Rgba16Float => 8,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub struct ScratchClass {
    pub format: ScratchFormat,
    /// 0 = linear, 1 = sRGB numeric values. Independent of storage encoding.
    pub working_space: u32,
    /// 0 = premultiplied, 1 = straight.
    pub alpha: u32,
    pub usage: u32,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub struct ScratchAllocation {
    pub width: u32,
    pub height: u32,
    pub class: ScratchClass,
}
impl ScratchAllocation {
    pub fn bytes(self) -> u64 {
        u64::from(self.width) * u64::from(self.height)
            * u64::from(self.class.format.bytes_per_pixel())
    }
    pub fn words(self) -> [u32; 8] {
        [self.width, self.height, self.class.format as u32,
         self.class.working_space, self.class.alpha, self.class.usage,
         self.class.format.bytes_per_pixel(), 0]
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ScratchBinding {
    pub input: i32,
    pub source: i32,
    pub output: u32,
}

#[derive(Default, Debug)]
pub(super) struct Layout {
    pub allocations: Vec<ScratchAllocation>,
    pub bindings: Vec<ScratchBinding>,
    pub outputs: Vec<Option<u32>>,
    pub bytes: u64,
}

/// Derive execution lifetimes for atomic draw/replay units. Each unit includes
/// its terminal snapshot copy or composition consumer. Third image-input
/// bindings refer to independently owned images, never scratch from that draw.
pub(super) fn layout(
    frame: &EffectFramePlan,
    current: Option<Range<usize>>,
) -> Result<Layout, RenderError> {
    if frame.passes.len() > MAX_SCRATCH_PASSES {
        return Err(format!("effect scratch pass limit exceeded ({MAX_SCRATCH_PASSES})").into());
    }
    let mut passes = Vec::with_capacity(frame.passes.len());
    for (index, p) in frame.passes.iter().enumerate() {
        let format = match p.output {
            0 | 4..=6 => ScratchFormat::Rgba8UnormSrgb,
            1..=3 => ScratchFormat::Rgba8Unorm,
            7 => ScratchFormat::Rgba16Float,
            other => return Err(format!("effect pass {index} semantic output {other} is invalid").into()),
        };
        let semantic = |value: f32, name: &str| -> Result<u32, RenderError> {
            if value == 0. { Ok(0) } else if value == 1. { Ok(1) }
            else { Err(format!("effect pass {index} {name} semantic {value} is invalid").into()) }
        };
        // Host raster/masked-raster utilities return linear premultiplied
        // pixels directly. Their inherited output_mode.xy is not evaluated by
        // the utility shader; it describes the following plugin conversion.
        let (working_space, alpha) = if matches!(p.program, 0 | 2) {
            (0, 0)
        } else {
            (semantic(p.uniform.output_mode[0], "working-space")?,
             semantic(p.uniform.output_mode[1], "alpha")?)
        };
        passes.push(graph::Pass {
            input: p.input, source: p.source, output: p.output as usize,
            descriptor: placement::Descriptor {
                class: ScratchClass {
                    format, working_space, alpha, usage: SCRATCH_USAGE,
                },
                width: p.width, height: p.height, bytes_per_pixel: format.bytes_per_pixel(),
            },
            // Native effect passes clear the entire attachment, including
            // sprite passes. Blending inside one sprite pass is not a later load.
            load: graph::Load::Clear,
        });
    }
    let mut draws: Vec<_> = frame.draws.iter().map(|d| d.pass_start..d.pass_end).collect();
    if let Some(current) = current { draws.push(current); }
    let graph = graph::build(&passes, &draws, 8, MAX_SCRATCH_PASSES)
        .map_err(|error| RenderError::Invalid(error.to_string()))?;
    let placement = placement::place(&graph.resources, placement::Limits {
        resources: MAX_SCRATCH_PASSES, allocations: MAX_SCRATCH_PASSES, bytes: u64::MAX,
    }).map_err(|error| RenderError::Invalid(error.to_string()))?;
    let input = |value| match value {
        graph::Input::External(token) => token,
        graph::Input::Resource(id) => placement.assignments[id] as i32,
    };
    Ok(Layout {
        allocations: placement.allocations.iter().map(|d| ScratchAllocation {
            width: d.width, height: d.height, class: d.class,
        }).collect(),
        bindings: graph.passes.iter().map(|p| ScratchBinding {
            input: input(p.input), source: input(p.source), output: placement.assignments[p.output] as u32,
        }).collect(),
        outputs: graph.draw_outputs.iter().map(|id| id.map(|id| placement.assignments[id] as u32)).collect(),
        bytes: placement.bytes,
    })
}
