from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

root = Path('E:/Dev/aem'); work = root/'.worktrees/static-depth-playback'
out = root/'artifacts/pr-queue/owned-depth-image-green-v1'; out.mkdir(exist_ok=False)
assert (root/'artifacts/pr-queue/owned-depth-image-red-v1/reproduced.json').exists()
git = lambda *args: subprocess.check_output(['git', *args], cwd=work).decode().strip()
paths = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'], cwd=work).decode().split('\0')
source = {p: hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml')) or p=='Cargo.lock')}
for p in git('diff','--name-only','HEAD').splitlines() + git('ls-files','--others','--exclude-standard').splitlines():
    if p in source:
        dest = out/'source'/p; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(work/p, dest)
shutil.copyfile(__file__, out/'controller.py')
env = os.environ.copy(); env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true', MOTION_DEPTH_ACCEPTANCE_DIR=str(out/'renders')); env.pop('MOTION_LOG', None)
steps = [
 ('host', ['cargo','test','-p','motion-host','--lib','--test','depth_session','--test','depth_video','--features','gpu-tests,ai-depth','--locked','--offline','--no-fail-fast','--','--test-threads=1']),
 ('render-image-unit', ['cargo','test','-p','motion-render','--lib','--locked','--offline','depth_image::','--','--test-threads=1']),
 ('render-depth-native', ['cargo','test','-p','motion-render','--test','depth_surface','--locked','--offline','--','--test-threads=1']),
 ('host-without-depth', ['cargo','check','-p','motion-host','--no-default-features','--locked','--offline']),
 ('style', ['python','-c',"import runpy; runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
 ('provenance', ['python','tools/validate_provenance.py']),
]
receipt = dict(base=git('rev-parse','HEAD'), startedUtc=datetime.now(timezone.utc).isoformat(), source=source, steps=[], scope='Owned exact original image and depth pairing under combined session budget; frame/revision guards unchanged, not continuous playback reuse or final workspace acceptance')
for name,cmd in steps:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as stdout, (out/(name+'.stderr.log')).open('wb') as stderr:
        code = subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
    row = dict(name=name, command=cmd, exitCode=code, sourceUnchanged=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in source.items()))
    if name in ('host','render-image-unit','render-depth-native'):
        row['results'] = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (out/(name+'.stdout.log')).read_text(encoding='utf-8'))
    receipt['steps'].append(row); (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8'); print(json.dumps(row),flush=True)
    assert code==0 and row['sourceUnchanged'], name
    if 'results' in row:
        assert row['results'] and all(int(p)>0 and f==i=='0' for p,f,i in row['results'])
        if name=='host': assert row['results']==[('108','0','0'),('16','0','0'),('13','0','0')]
        if name=='render-image-unit': assert row['results']==[('1','0','0')]
receipt['completedUtc']=datetime.now(timezone.utc).isoformat(); (out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print('accepted',flush=True)
