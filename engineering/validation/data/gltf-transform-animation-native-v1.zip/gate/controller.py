from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess
root=Path('E:/Dev/aem');work=root/'.worktrees/gltf-transform-animation'
assert (root/'artifacts/pr-queue/issue3d-combined-main-full-v1/accepted.json').is_file()
assert (root/'artifacts/pr-queue/issue3d-final-native-depth-v1/verified.json').is_file(), 'release numerical-model acceptance before native animation tests'
out=root/'artifacts/pr-queue/issue87-transform-animation-native-v1';out.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=work).decode().strip()
def source():
    paths=set(git('ls-files','-co','--exclude-standard','-z').split('\0'))
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(paths) if p and
        (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
before=source();base=git('rev-parse','HEAD');assert base=='06d1c71675de2e29a93d88bae520bdb341977169'
assert not git('diff','--name-only','HEAD','--','desktop/app/src/panels')
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-scene87-contract'),CARGO_BUILD_JOBS='1',
    CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
    LOCALAPPDATA=str(out/'appdata'),MOTION_MODEL_UI_ARTIFACTS=str(out/'model-editor-fixture'))
for key in ('MOTION_LOG','MOTION_MODEL_UI_PROJECT','VK_DRIVER_FILES','VK_ICD_FILENAMES'):env.pop(key,None)
receipt=dict(base=base,source=before,controllerPid=os.getpid(),steps=[],scope='Explicit imported transform clips; native/project time consumer, static-scene regression and desktop model controls; Android excluded')
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
commands=[('provenance',['python','tools/validate_provenance.py']),
    ('scene-cpu',['cargo','test','-p','motion-scene','--locked','--offline','--','--test-threads=1']),
    ('core-model',['cargo','test','-p','motion-core','--test','model_layers','--locked','--offline','--','--test-threads=1']),
    ('native-model',['cargo','test','-p','motion-render','--features','gpu-tests','--test','model_layers','--test','scene_gpu','--locked','--offline','--','--test-threads=1']),
    ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),
    ('desktop-model',['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','model_layer_tests','--','--test-threads=1'])]
for name,command in commands:
    print(json.dumps(dict(start=name)),flush=True)
    row=dict(name=name,command=command)
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        process=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr)
        row['pid']=process.pid;row['exitCode']=process.wait()
    row['sourceUnchanged']=source()==before
    for stream in ('stdout','stderr'):row[stream+'Sha256']=hashlib.sha256((out/(name+'.'+stream+'.log')).read_bytes()).hexdigest()
    text=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
    totals=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    if totals:row['totals']=dict(zip(('passed','failed','ignored'),(sum(int(v[i]) for v in totals) for i in range(3))))
    receipt['steps'].append(row);(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(dict(done=name,exit=row['exitCode'],totals=row.get('totals'))),flush=True)
    assert row['exitCode']==0 and row['sourceUnchanged']
    if totals: assert row['totals']['failed']==row['totals']['ignored']==0
    if name=='scene-cpu':assert row['totals']['passed']==60
    if name=='core-model':assert row['totals']['passed']==5
    if name=='native-model':
        assert row['totals']['passed']==22
        for test in ('imported_gltf_clips_render_from_saved_owned_data_and_reject_missing_selection',
                     'imported_clip_time_uses_layer_local_frames_without_rewriting_euler_keys'):
            assert re.search(r'test '+test+r' \.\.\. ok',text),test
    if name=='desktop-model':
        assert row['totals']['passed']>=1
        assert 'saved_model_keyframes_render_inside_the_editor ... ok' in text
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=source()==before)
assert receipt['sourceUnchanged']
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True)))
