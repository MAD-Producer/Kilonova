from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess
root=Path('E:/Dev/aem');work=root/'.worktrees/static-depth-playback';out=root/'artifacts/pr-queue/static-depth-playback-green-v1';out.mkdir(exist_ok=False)
assert (root/'artifacts/pr-queue/static-depth-playback-red-v1/reproduced.json').exists()
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=work).decode().split('\0')
source={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml')) or p=='Cargo.lock')}
for p in git('diff','--name-only','HEAD').splitlines()+git('ls-files','--others','--exclude-standard').splitlines():
    if p in source:
        dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/p,dest)
shutil.copyfile(__file__,out/'controller.py')
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true',MOTION_FROZEN_DEPTH_ARTIFACTS=str(out/'renders'),MOTION_IMPORTED_CAMERA_OUTPUT_ARTIFACTS=str(out/'camera-renders'));env.pop('MOTION_LOG',None)
steps=[('host',['cargo','test','-p','motion-host','--lib','--test','depth_session','--test','depth_video','--features','gpu-tests,ai-depth','--locked','--offline','--no-fail-fast','--','--test-threads=1']),('media',['cargo','test','-p','motion-desktop-media','--lib','--features','ffmpeg,gpu-tests,ai-depth','--locked','--offline','--no-fail-fast','--','--test-threads=1','--include-ignored']),('host-without-depth',['cargo','check','-p','motion-host','--no-default-features','--locked','--offline']),('desktop',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),('style',['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),('provenance',['python','tools/validate_provenance.py'])]
r=dict(base=git('rev-parse','HEAD'),startedUtc=datetime.now(timezone.utc).isoformat(),source=source,steps=[],scope='Static image reuse across composition clock changes with separately strict pending worker frame admission; real camera animation vs independent frozen geometry, original-color ownership and explicit cancellation; not calibrated video, complex depth, DOF or final workspace')
for name,cmd in steps:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:code=subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
    row=dict(name=name,command=cmd,exitCode=code,sourceUnchanged=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in source.items()))
    if name in ('host','media'):row['results']=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (out/(name+'.stdout.log')).read_text(encoding='utf-8'))
    r['steps'].append(row);(out/'exit.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(row),flush=True)
    assert code==0 and row['sourceUnchanged'],name
    if name=='host':assert row['results']==[('109','0','0'),('17','0','0'),('13','0','0')]
    if name=='media':assert row['results']==[('56','0','0')]
for folder in ('renders','camera-renders'):
    assert len(list((out/folder).rglob('*.mp4')))==4
    assert len(list((out/folder).rglob('comparison.json')))==8
r['completedUtc']=datetime.now(timezone.utc).isoformat();(out/'accepted.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print('accepted',flush=True)
