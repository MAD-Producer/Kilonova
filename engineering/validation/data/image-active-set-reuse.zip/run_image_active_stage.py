from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
root=Path('E:/Dev/aem');work=root/'.worktrees/image-active-set';out=root/'.tools/image-active-set';phase=sys.argv[1];assert phase in ['before','after']
path=out/(phase+'-receipt.json');assert not path.exists()
def freeze():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=work,text=True).splitlines()
 return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in names if p.startswith(('crates/','desktop/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']}
sources=freeze();record=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),phase=phase,status='running',sources=sources,runs=[])
def save():record['source_unchanged']=freeze()==sources;path.write_text(json.dumps(record,indent=2),encoding='utf8')
for p in sources:
 if p.endswith('/src/lib.rs'):(work/p).touch()
base=['cargo','test','-p','motion-render','--features','gpu-tests','--locked','--offline','-j1']
if phase=='before':steps=[('allocation',['--test','image_allowed_sets'])]
else:
 steps=[('images',sum([['--test',n] for n in ['image_allowed_sets','image_decode_budget_native','image_error_identity','image_preview_cache','image_working_set','prepared_resources','resource_rejections']],[])),('membership',['--lib','image_resources::allowed::tests::'])]
env=os.environ.copy();env.pop('MOTION_LOG',None)
for name,args in steps:
 record['active']=name;save();print('Started image active '+phase+' '+name,flush=True);began=time.monotonic();command=base+args+['--','--nocapture','--test-threads=1']
 with (out/(phase+'-'+name+'.log')).open('w',encoding='utf8') as sink:r=subprocess.run(command,cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT,timeout=3600)
 text=(out/(phase+'-'+name+'.log')).read_text(encoding='utf8');summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
 counts=re.findall(r'64 ready images / 20 preparations ([^\n]+): allocations=(\d+) reference_per_preparation=(\d+)',text)
 item=dict(name=name,command=command,exit_code=r.returncode,summary=summary,allocation_samples=counts,seconds=round(time.monotonic()-began,2));record['runs'].append(item);save();print(json.dumps(item),flush=True)
 assert record['source_unchanged'] and summary
 if phase=='before':assert r.returncode==101 and summary==[('FAILED','0','1','0')] and len(counts)==2 and 'unchanged active-set allocation' in text
 else:assert r.returncode==0 and all(s[0]=='ok' and s[2]=='0' and s[3]=='0' for s in summary)
if phase=='after':
 command=['cargo','check','-p','motion-host','-p','motion-desktop-media','-p','motion-desktop','--all-targets','--features','motion-desktop/ffmpeg','--locked','--offline','-j1'];record['active']='consumer-check';save();print('Started image active consumer check',flush=True);began=time.monotonic()
 with (out/'after-consumer-check.log').open('w',encoding='utf8') as sink:r=subprocess.run(command,cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT,timeout=3600)
 record['consumer_check']=dict(command=command,exit_code=r.returncode,seconds=round(time.monotonic()-began,2));save();assert r.returncode==0 and record['source_unchanged']
record.update(status='completed',active=None);save();print('Completed image active '+phase,flush=True)
