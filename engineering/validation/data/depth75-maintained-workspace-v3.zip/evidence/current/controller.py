"""One complete maintained-workspace run of the committed optional backend."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, os, re, shutil, subprocess, time, traceback, ctypes

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/reference-depth76'
OUT = ROOT / 'artifacts/pr-queue/depth75-backend-workspace-v8'
assert shutil.disk_usage(ROOT).free >= 10 << 30, 'Original 10 GiB admission; no test started'

previous=ROOT/'artifacts/pr-queue/depth75-backend-workspace-v6'
previous_result=json.loads((previous/'receipt.json').read_text(encoding='utf-8'))
previous_consumed=json.loads((previous/'session-consumed.json').read_text(encoding='utf-8'))
assert previous_consumed['session']==6448 and previous_consumed['exitCode']==1
assert previous_result['status']=='failed_original_outputs_retained' and previous_result['sourceUnchanged']
assert previous_result['allSourceInvocationsStarted']
assert previous_result['totals']['observedInvocations']==previous_result['totals']['expectedInvocations']==430
assert previous_result['totals']['summaryCount']==429
assert len(previous_result['abnormalTargetExits'])==1
assert 'nested_exposure-2bfd40cfb4ecd7eb.exe' in previous_result['abnormalTargetExits'][0]
assert '0xc0000005, STATUS_ACCESS_VIOLATION' in previous_result['abnormalTargetExits'][0]
# These diagnosed observations do not waive the old crash or prove its cause.
for path, expected in (
    ('depth75-nested-access-probe-v1','diagnostic_completed_original_failure_not_waived'),
    ('depth75-native-startup-observation-v1','fixed_startup_and_target_observations_completed_original_crash_unresolved')):
    diagnostic=ROOT/'artifacts/pr-queue'/path
    outcome=json.loads((diagnostic/'receipt.json').read_text(encoding='utf-8'))
    assert outcome['status']==expected and outcome['executableUnchanged'] and outcome['sourceUnchanged']
    assert json.loads((diagnostic/'session-consumed.json').read_text(encoding='utf-8'))['exitCode']==0
assert all(row['exitCode']==0 for row in outcome['stages'])
fault=json.loads((ROOT/'artifacts/pr-queue/depth75-observer-fault-control-v1/receipt.json').read_text(encoding='utf-8'))
assert fault['status']=='real_fault_two_chances_dump_stack_and_unhandled_exit_verified'

assert previous_result['totals']['failed']==1
assert previous_result['failedTestNames']==['production_dependencies_keep_data_render_and_media_outside_the_editing_runtime']
restore=ROOT/'artifacts/pr-queue/depth75-locked-cache-restore-v1'
restored=json.loads((restore/'receipt.json').read_text(encoding='utf-8'))
assert restored['status']=='all_locked_registry_archives_verified_offline_metadata_and_test_pending'
assert restored['lockUnchanged']
assert json.loads((restore/'session-consumed.json').read_text(encoding='utf-8'))['exitCode']==0
assert hashlib.sha256((WORK/'Cargo.lock').read_bytes()).hexdigest()==restored['lockSha256']
for row in restored['packages']:
    archive=Path(restored['cache'])/(row['name']+'-'+row['version']+'.crate')
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==row['sha256']

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
main = subprocess.check_output(['git','rev-parse','origin/main'],cwd=WORK,text=True).strip()
assert subprocess.run(['git','merge-base','--is-ancestor',main,head],cwd=WORK).returncode == 0
assert subprocess.check_output(['git','branch','--show-current'],cwd=WORK,text=True).strip() == 'feat/75-wgsl-depth-backend'
assert head == '5fb253a48b204c0fd52c97669f7c2bf01c401c13'
assert main == '5a025a2d23f2cc35ee4d306550861b086e0b2378'
probe = ROOT/'artifacts/pr-queue/depth75-file-probe-resume-v1'
pr = json.loads((probe/'receipt.json').read_text(encoding='utf-8'))
assert pr['status']=='actual_default_file_before_return_and_error_stderr_stdout_isolation_passed'
assert pr['sourceUnchanged'] and pr['probeSourceUnchanged'] and all(s['exitCode']==0 for s in pr['stages'])
assert (probe/'process-completion-observed.json').is_file()
transition = ROOT/'artifacts/pr-queue/depth75-resume-transition-native-v1'
tr = json.loads((transition/'receipt.json').read_text(encoding='utf-8'))
assert tr['exitCode']==0 and len(tr['namedPasses'])==30
assert json.loads((transition/'session-consumed.json').read_text(encoding='utf-8'))['exitCode']==0
runtime=json.loads((ROOT/'artifacts/pr-queue/depth75-runtime-placement-v1/receipt.json').read_text(encoding='utf-8'))
assert len(runtime['placements'])==14
for item in runtime['placements']:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
integration=json.loads((WORK/'engineering/validation/data/depth75-rebase-integration-v1.json').read_text(encoding='utf-8'))
for item in integration['files']:
    raw=subprocess.check_output(['git','show',head+':'+item['path']],cwd=WORK)
    blob=subprocess.check_output(['git','rev-parse',head+':'+item['path']],cwd=WORK,text=True).strip()
    assert blob==item['integratedBlob']
    old=subprocess.check_output(['git','show',item['qualifiedCommit']+':'+item['path']],cwd=WORK)
    if item['path']=='crates/motion-host/src/depth/onnx.rs':
        needle=b'fn capture(command: &mut Command, cancellation: &Cancellation) -> Result<(Vec<u8>, String)> {'
        assert old.count(needle)==1
        assert raw==old.replace(needle,b'pub(super) '+needle)
    else: assert raw==old
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
names = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()
assert all((WORK / n).is_file() for n in names)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def identity():
    return {n: sha(WORK/n) for n in names if (WORK/n).is_file()}
source = identity()
assert source == pr['source']
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'): env.pop(name, None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),
    CARGO_TARGET_DIR=str(ROOT/'target/colmap88-isolated-check'),
    CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT/'appdata'),
    TEMP=str(ROOT/'target/colmap88-isolated-check/tmp'), TMP=str(ROOT/'target/colmap88-isolated-check/tmp'))
Path(env['TEMP']).mkdir(parents=True, exist_ok=True)

# A full original offline metadata command now precedes the native run. This
# exercises the cache requirement missed by the original no-deps inventory.
preflight=dict(status='running', sourceCommit=head, lockSha256=restored['lockSha256'],
    previousFailureReceiptSha256=hashlib.sha256((previous/'receipt.json').read_bytes()).hexdigest(),
    restoredArchives=sum(row['restored'] for row in restored['packages']))
def preflight_save():
    (OUT/'cache-preflight.json').write_text(json.dumps(preflight,indent=2)+'\n',encoding='utf-8')
preflight_save()
try:
    with (OUT/'offline-metadata.json').open('wb') as output,(OUT/'offline-metadata.stderr.log').open('wb') as errors:
        process=subprocess.Popen(['cargo','metadata','--format-version','1','--locked','--offline'],cwd=WORK,env=env,stdout=output,stderr=errors)
        preflight['metadataPid']=process.pid;preflight_save()
        preflight['metadataExit']=process.wait()
    assert preflight['metadataExit']==0
    target_key='motion-model::test::crates/motion-model/tests/dependency_boundaries.rs'
    targets=[row['executable'] for row in previous_result['sourceBoundInvocations'] if row['target']==target_key]
    assert len(targets)==1
    preflight['boundaryExecutableSha256']=sha(Path(targets[0]))
    with (OUT/'boundary.stdout.log').open('wb') as output,(OUT/'boundary.stderr.log').open('wb') as errors:
        process=subprocess.Popen([targets[0],'--test-threads=1'],cwd=WORK,env=env,stdout=output,stderr=errors)
        preflight['boundaryPid']=process.pid;preflight_save()
        preflight['boundaryExit']=process.wait()
    assert preflight['boundaryExit']==0
    boundary=(OUT/'boundary.stdout.log').read_text(encoding='utf-8')
    assert 'test production_dependencies_keep_data_render_and_media_outside_the_editing_runtime ... ok' in boundary
    assert 'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in boundary
    preflight['status']='full_offline_metadata_and_unchanged_original_boundary_passed'
except BaseException as cause:
    preflight.update(status='failed_original_outputs_retained',cause=repr(cause));raise
finally:
    preflight['sourceUnchanged']=identity()==source
    preflight_save()
assert preflight['sourceUnchanged']

metadata = json.loads(subprocess.check_output(['cargo','metadata','--no-deps','--format-version','1','--locked'],cwd=WORK,env=env))
(OUT/'cargo-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
command = ['cargo','test','--workspace','--exclude','motion-android','--features',
    'motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth',
    '--no-fail-fast','--locked','--','--test-threads=1']
report = dict(status='running',baseCommit=head,main=main,
    startedUtc=datetime.now(timezone.utc).isoformat(),source=source,command=command,
    freeBytesBefore=shutil.disk_usage(ROOT).free,targetDirectory=env['CARGO_TARGET_DIR'],temporaryDirectory=env['TEMP'],
    limits=['No assertion, original ignore, GPU/backend, stack, feature or admission budget changes',
            'Complete maintained workspace; Android excluded by user',
            'One own serial native workload; no foreign process stopped or cache deleted',
            'Default Info; all controlled temp/cache/output on E',
            'Earlier #88 and committed438a47eb full failures remain separate source-bound results; no retry or waiver',
            'This run qualifies exact integrated5fb source after main fetch, the pinned loader correction and actual default file probe; original failed full runs remain authoritative for their source/environment',
            'A native compilation failure or missing target cannot be called a full pass',
            'v3 DLL failures and both v6 failures retained; corrected exact lock cache receives full offline metadata and original boundary preflight; native access violation remains unexplained despite bounded diagnostic passes; no common cause inferred',
            'This is a fresh normal full command after the documented cache correction, without a debugger or runner override; no automatic retry, assertion/feature/ignore/backend/GPU/timeout waiver'])
def save():
    pending=OUT/'receipt.pending.json'
    pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    os.replace(pending,OUT/'receipt.json')
save(); began=time.monotonic()

class HostMemory(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(name,ctypes.c_ulonglong) for name in
        ('totalPhysical','availablePhysical','totalPageFile','availablePageFile','totalVirtual','availableVirtual','availableExtendedVirtual')]
get_memory=ctypes.WinDLL('kernel32',use_last_error=True).GlobalMemoryStatusEx
get_memory.argtypes=[ctypes.POINTER(HostMemory)];get_memory.restype=ctypes.c_int
def observe_host_memory():
    memory=HostMemory();memory.length=ctypes.sizeof(memory)
    row=dict(utc=datetime.now(timezone.utc).isoformat(),stderrBytes=(OUT/'stderr.log').stat().st_size)
    if get_memory(ctypes.byref(memory)):
        row.update(loadPercent=memory.load,totalPhysical=memory.totalPhysical,availablePhysical=memory.availablePhysical,
            totalPageFile=memory.totalPageFile,availablePageFile=memory.availablePageFile)
    else:row['error']=ctypes.get_last_error()
    with (OUT/'host-memory.jsonl').open('a',encoding='utf-8') as file:file.write(json.dumps(row)+'\n')

try:
    with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        report['pid']=child.pid;save();observe_host_memory()
        while True:
            try:
                code=child.wait(timeout=30)
                break
            except subprocess.TimeoutExpired:
                observe_host_memory()
        observe_host_memory()
    report['exitCode']=code
    stdout=(OUT/'stdout.log').read_text(encoding='utf-8',errors='replace')
    stderr=(OUT/'stderr.log').read_text(encoding='utf-8',errors='replace')
    summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
    executables=re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)',stderr,re.M)
    docs=re.findall(r'^\s*Doc-tests (\S+)\s*$',stderr,re.M)
    expected=[];by_name={};doc_owners={}
    for package in metadata['packages']:
        if package['id'] not in metadata['workspace_members'] or package['name']=='motion-android':continue
        for target in package['targets']:
            if not target['test']:continue
            relative=Path(target['src_path']).relative_to(WORK).as_posix()
            key=package['name']+'::'+target['kind'][0]+'::'+relative
            expected.append(key);by_name.setdefault(target['name'].replace('-','_'),[]).append((relative,key))
        if any(t['doctest'] for t in package['targets']):
            key='doc::'+package['name'];expected.append(key);doc_owners[package['name'].replace('-','_')]=key
    observed=[];bound=[]
    for executable in executables:
        path=Path(executable);dependency=path.with_suffix('.d');raw=dependency.read_bytes()
        line=raw.decode('utf-8').splitlines()[0].split(': ',1)[1].replace('\\','/')
        name=re.sub(r'-[a-f0-9]+$','',path.stem)
        owners=[key for relative,key in by_name[name] if re.search(r'(?<!\S)'+re.escape(relative)+r'(?!\S)',line)]
        assert len(owners)==1,(executable,owners)
        observed.extend(owners)
        bound.append(dict(executable=executable,target=owners[0],depInfoSha256=hashlib.sha256(raw).hexdigest()))
    observed.extend(doc_owners[name] for name in docs)
    report.update(totals=dict(passed=sum(int(s[1]) for s in summaries),failed=sum(int(s[2]) for s in summaries),
        originalIgnored=sum(int(s[3]) for s in summaries),filtered=sum(int(s[5]) for s in summaries),
        summaryCount=len(summaries),observedInvocations=len(observed),expectedInvocations=len(expected)),
        sourceBoundInvocations=bound,missingSourceTargets=dict(Counter(expected)-Counter(observed)),
        unexpectedSourceTargets=dict(Counter(observed)-Counter(expected)),
        fullTargetCoverageAccounted=Counter(expected)==Counter(observed) and len(summaries)==len(observed),
        allSourceInvocationsStarted=Counter(expected)==Counter(observed),
        abnormalTargetExits=[line for line in stderr.splitlines() if "process didn't exit successfully:" in line],
        failedTestNames=re.findall(r'^test ([^\r\n]+?) \.\.\. FAILED\s*$',stdout,re.M))
    report['status']='complete_maintained_workspace_passed' if code==0 and report['fullTargetCoverageAccounted'] and not report['totals']['failed'] and not report['totals']['filtered'] else 'failed_original_outputs_retained'
except BaseException as error:
    report.update(status='observer_failed_original_outputs_retained',failure=repr(error),traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=identity()==source and subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,
        completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3),freeBytesAfter=shutil.disk_usage(ROOT).free)
    report['logs']={n:dict(bytes=(OUT/n).stat().st_size,sha256=sha(OUT/n)) for n in ('stdout.log','stderr.log','cargo-metadata.json') if (OUT/n).exists()}
    save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','sourceBoundInvocations')}))
raise SystemExit(0 if report['status']=='complete_maintained_workspace_passed' and report['sourceUnchanged'] else 1)
