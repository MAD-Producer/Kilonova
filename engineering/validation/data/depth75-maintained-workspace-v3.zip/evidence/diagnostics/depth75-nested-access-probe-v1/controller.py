"""Observe the unchanged failing executable before introducing any correction."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/reference-depth76'
OUT = BASE / 'depth75-nested-access-probe-v1'
prior = json.loads((BASE / 'depth75-backend-workspace-v6/receipt.json').read_text(encoding='utf-8'))
assert json.loads((BASE / 'depth75-backend-workspace-v6/session-consumed.json').read_text(encoding='utf-8'))['exitCode'] == 1
assert prior['sourceUnchanged'] and prior['exitCode'] == 101
assert shutil.disk_usage(ROOT).free >= 10 << 30
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(WORK / name) == value for name, value in prior['source'].items())
key = 'motion-render::test::crates/motion-render/tests/nested_exposure.rs'
matches = [row['executable'] for row in prior['sourceBoundInvocations'] if row['target'] == key]
assert len(matches) == 1
exe = Path(matches[0])
runtime = json.loads((BASE / 'depth75-runtime-placement-v1/receipt.json').read_text(encoding='utf-8'))
assert all(sha(Path(item['path'])) == item['sha256'] for item in runtime['placements'])
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = {k: v for k, v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), RUST_BACKTRACE='full',
           TEMP=str(OUT / 'tmp'), TMP=str(OUT / 'tmp'), LOCALAPPDATA=str(OUT / 'appdata'))
Path(env['TEMP']).mkdir()
report = dict(status='observing_original_binary', sourceCommit=prior['baseCommit'],
              executable=str(exe), executableSha256=sha(exe), startedUtc=datetime.now(timezone.utc).isoformat(), stages=[],
              limits=['Original backend, executable, source, assertions, ignores and thresholds retained',
                      'List and uncaptured-output diagnostic only; a pass cannot erase the original native crash',
                      'No product retry, driver change, debugger, source edit, foreign process stop or cache deletion'])
def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
save()
try:
    for name, arguments in [('list', ['--list']), ('uncaptured-original-target', ['--test-threads=1', '--nocapture'])]:
        row = dict(name=name, command=[str(exe), *arguments], startedUtc=datetime.now(timezone.utc).isoformat())
        report['stages'].append(row)
        save()
        began = time.monotonic()
        with (OUT / (name + '.stdout.log')).open('wb') as output, (OUT / (name + '.stderr.log')).open('wb') as errors:
            process = subprocess.Popen(row['command'], cwd=WORK, env=env, stdout=output, stderr=errors)
            row['pid'] = process.pid
            save()
            row['exitCode'] = process.wait()
        row.update(elapsedSeconds=time.monotonic() - began,
                   stdoutSha256=sha(OUT / (name + '.stdout.log')),
                   stderrSha256=sha(OUT / (name + '.stderr.log')))
        save()
        if row['exitCode'] != 0:
            break
    report['status'] = 'diagnostic_completed_original_failure_not_waived'
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), executableUnchanged=sha(exe) == report['executableSha256'],
                  sourceUnchanged=all(sha(WORK / name) == value for name, value in prior['source'].items()))
    save()
print(json.dumps(report))
