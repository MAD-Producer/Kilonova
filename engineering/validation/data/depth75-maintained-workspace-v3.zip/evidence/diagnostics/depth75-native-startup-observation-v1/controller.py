"""Fixed-budget startup/exception observation; never retry a failure into a pass."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/reference-depth76'
OUT = BASE / 'depth75-native-startup-observation-v1'
SOURCE = BASE / 'depth75-native-crash-observer.cpp'
assert shutil.disk_usage(ROOT).free >= 10 << 30
assert json.loads((BASE / 'depth75-backend-workspace-v6/session-consumed.json').read_text(encoding='utf-8'))['exitCode'] == 1
assert json.loads((BASE / 'depth75-nested-access-probe-v1/session-consumed.json').read_text(encoding='utf-8'))['exitCode'] == 0
prior = json.loads((BASE / 'depth75-backend-workspace-v6/receipt.json').read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(WORK / name) == value for name, value in prior['source'].items())
exe = ROOT / 'target/colmap88-isolated-check/debug/deps/nested_exposure-2bfd40cfb4ecd7eb.exe'
assert sha(exe) == 'd4850102a968f821cc496c127a603469110177c53ad3014e637f72cf9c78760b'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
(OUT / SOURCE.name).write_bytes(SOURCE.read_bytes())
env = {k: v for k, v in os.environ.items() if not k.startswith('MOTION_')}
env.update(TEMP=str(OUT / 'tmp'), TMP=str(OUT / 'tmp'), LOCALAPPDATA=str(OUT / 'appdata'),
           CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), RUST_BACKTRACE='full')
Path(env['TEMP']).mkdir()
observer = OUT / 'observer.exe'
report = dict(status='compiling_local_sdk_observer', startedUtc=datetime.now(timezone.utc).isoformat(),
              sourceCommit=prior['baseCommit'], executable=str(exe), executableSha256=sha(exe),
              observerSourceSha256=sha(SOURCE), listBudget=32, fullTargetBudget=1, stages=[],
              limits=['Fixed32 startup listings then one original serial target; stop on first failure',
                      'Native Debug API observation can affect timing; no ordinary full pass or fixed cause is inferred',
                      'Only owned fixture child; no foreign attach, disassembly, registry, backend or assertion changes',
                      'First-chance exceptions are distinguished from unhandled process failure',
                      'Compiler, temp, symbols, output and any minidumps remain on E',
                      'Official portable debugger download failed403; use already installed Windows SDK APIs, no new dependency'])
def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
def run(name, command, directory=OUT):
    row = dict(name=name, command=list(map(str, command)), startedUtc=datetime.now(timezone.utc).isoformat())
    report['stages'].append(row)
    save()
    began = time.monotonic()
    with (directory / 'host.stdout.log').open('wb') as output, (directory / 'host.stderr.log').open('wb') as errors:
        child = subprocess.Popen(row['command'], cwd=WORK, env=env, stdin=subprocess.DEVNULL, stdout=output, stderr=errors)
        row['pid'] = child.pid
        save()
        row['exitCode'] = child.wait()
    row['elapsedSeconds'] = time.monotonic() - began
    save()
    return row
save()
try:
    compilation = run('compile-observer', ['cl.exe', '/nologo', '/std:c++17', '/EHsc', '/W4', '/MT', '/Zi',
        str(SOURCE), '/Fo' + str(OUT / 'observer.obj'), '/Fd' + str(OUT / 'observer.compiler.pdb'),
        '/Fe' + str(observer), '/link', '/DEBUG', '/INCREMENTAL:NO', '/PDB:' + str(OUT / 'observer.pdb'), 'dbghelp.lib'])
    assert compilation['exitCode'] == 0
    report.update(status='observing_fixed_startup_budget', observerExecutableSha256=sha(observer))
    for index, (name, arguments) in enumerate([(f'list-{i:02d}', ['--list']) for i in range(32)] +
                                            [('original-target', ['--test-threads=1'])]):
        directory = OUT / name
        directory.mkdir()
        (directory / 'symbols').mkdir()
        row = run(name, [observer, exe, directory, *arguments], directory)
        text = (directory / 'events.log').read_text(encoding='utf-8', errors='replace')
        row['targetPid'] = int(re.search(r'owned target pid=(\d+)', text)[1])
        exits = re.findall(r'target exit=0x([a-f0-9]+) captures=(\d+)', text)
        row['eventsSha256'] = sha(directory / 'events.log')
        row['dumps'] = [dict(file=file.name, bytes=file.stat().st_size, sha256=sha(file)) for file in directory.glob('*.dmp')]
        if exits:
            assert len(exits) == 1
            row.update(targetExit=int(exits[0][0], 16), captures=int(exits[0][1]))
        if row['exitCode'] != 0:
            report.update(status='native_failure_or_observer_error_retained_stop_without_retry', stoppedAt=name)
            save()
            break
        assert exits and row['targetExit'] == 0
        target = (directory / 'target.stdout.log').read_text(encoding='utf-8')
        if index < 32:
            assert '9 tests, 0 benchmarks' in target
        else:
            assert 'test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in target
        save()
    else:
        report['status'] = 'fixed_startup_and_target_observations_completed_original_crash_unresolved'
except BaseException as cause:
    report.update(status='observer_failed_original_outputs_retained', cause=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),
                  executableUnchanged=sha(exe) == report['executableSha256'],
                  sourceUnchanged=all(sha(WORK / name) == value for name, value in prior['source'].items()))
    save()
print(json.dumps({k: report.get(k) for k in ('status', 'stoppedAt', 'cause', 'sourceUnchanged', 'executableUnchanged')}))
