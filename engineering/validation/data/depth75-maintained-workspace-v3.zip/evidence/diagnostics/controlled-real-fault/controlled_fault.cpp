int main() { volatile long* address = nullptr; *address = 7; return 0; }
