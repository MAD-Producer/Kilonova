"""A real fault in an owned toy process verifies the diagnostic exception path."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

BASE = Path('E:/Dev/aem/artifacts/pr-queue')
PRIOR = BASE / 'depth75-native-startup-observation-v1'
OUT = BASE / 'depth75-observer-fault-control-v1'
assert json.loads((PRIOR / 'session-consumed.json').read_text(encoding='utf-8'))['exitCode'] == 0
prior = json.loads((PRIOR / 'receipt.json').read_text(encoding='utf-8'))
observer = PRIOR / 'observer.exe'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(observer) == prior['observerExecutableSha256']
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
source = OUT / 'controlled_fault.cpp'
source.write_text('int main() { volatile long* address = nullptr; *address = 7; return 0; }\n', encoding='utf-8')
env = os.environ.copy()
env.update(TEMP=str(OUT / 'tmp'), TMP=str(OUT / 'tmp'))
Path(env['TEMP']).mkdir()
exe = OUT / 'controlled_fault.exe'
command = ['cl.exe', '/nologo', '/Od', '/MT', '/Zi', str(source), '/Fo' + str(OUT / 'controlled_fault.obj'),
           '/Fd' + str(OUT / 'compiler.pdb'), '/Fe' + str(exe), '/link', '/DEBUG', '/INCREMENTAL:NO',
           '/PDB:' + str(OUT / 'controlled_fault.pdb')]
report = dict(status='compiling_real_fault_fixture', sourceSha256=sha(source), observerSha256=sha(observer),
              startedUtc=datetime.now(timezone.utc).isoformat(), command=command,
              limits=['Intentional actual hardware fault in an isolated owned toy process only',
                      'No renderer/source/backend/assertion change or claim about the original crash cause',
                      'Diagnostic verifies dump/stack capture and unhandled exit; no forced failure in the product'])
def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
save()
try:
    with (OUT / 'compile.stdout.log').open('wb') as output, (OUT / 'compile.stderr.log').open('wb') as errors:
        report['compileExit'] = subprocess.call(command, env=env, stdout=output, stderr=errors)
    assert report['compileExit'] == 0
    run = OUT / 'observed'
    run.mkdir()
    (run / 'symbols').mkdir()
    with (OUT / 'observer.stdout.log').open('wb') as output, (OUT / 'observer.stderr.log').open('wb') as errors:
        process = subprocess.Popen([str(observer), str(exe), str(run)], env=env, stdin=subprocess.DEVNULL,
                                   stdout=output, stderr=errors)
        report['observerPid'] = process.pid
        save()
        report['observerExit'] = process.wait()
    text = (run / 'events.log').read_text(encoding='utf-8')
    assert report['observerExit'] == 1
    assert 'target exit=0xc0000005 captures=2' in text
    assert len(re.findall(r'code=0xc0000005 first=[01]', text)) == 2
    assert text.count('minidump wrote=1 error=0') == 2
    assert 'module=controlled_fault' in text
    dumps = sorted(run.glob('*.dmp'))
    assert len(dumps) == 2 and all(p.read_bytes()[:4] == b'MDMP' for p in dumps)
    report.update(status='real_fault_two_chances_dump_stack_and_unhandled_exit_verified',
                  dumps=[dict(name=p.name, bytes=p.stat().st_size, sha256=sha(p)) for p in dumps],
                  eventsSha256=sha(run / 'events.log'))
except BaseException as cause:
    report.update(status='observer_control_failed_original_outputs_retained', cause=repr(cause))
    raise
finally:
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps(report))
