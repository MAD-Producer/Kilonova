// Local diagnostic of one explicitly named owned Rust fixture, using SDK APIs.
// No registry settings, installation, foreign process attach or disassembly.
#include <windows.h>
#include <dbghelp.h>
#include <filesystem>
#include <fstream>
#include <string>
#include <cstdint>
#include <cstddef>

static_assert(sizeof(void*) == 8 && sizeof(DEBUG_EVENT) == 176);
static_assert(offsetof(CONTEXT, Rip) == 248);
static std::string utf8(const wchar_t* text) {
    int n = WideCharToMultiByte(CP_UTF8, 0, text, -1, nullptr, 0, nullptr, nullptr);
    if (n <= 0 || n > 4096) return "unavailable";
    std::string result(n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, text, -1, result.data(), n, nullptr, nullptr);
    result.pop_back(); return result;
}
static std::wstring quote(const wchar_t* text) {
    std::wstring out = L"\""; size_t slashes = 0;
    for (; *text; ++text) {
        if (*text == L'\\') { ++slashes; continue; }
        if (*text == L'\"') { out.append(slashes * 2 + 1, L'\\'); out += *text; }
        else { out.append(slashes, L'\\'); out += *text; }
        slashes = 0;
    }
    out.append(slashes * 2, L'\\'); out += L'\"'; return out;
}
static void file_event(std::ofstream& log, HANDLE file, const char* kind, void* base) {
    wchar_t name[1024] = {};
    DWORD n = file ? GetFinalPathNameByHandleW(file, name, 1024, FILE_NAME_NORMALIZED) : 0;
    log << kind << " base=" << base << " file=" << ((n && n < 1024) ? utf8(name) : "unavailable") << '\n';
    if (file) CloseHandle(file);
}
static void capture(PROCESS_INFORMATION& pi, DEBUG_EVENT& ev, const std::filesystem::path& out,
                    std::ofstream& log, unsigned index) {
    const auto& exception = ev.u.Exception;
    const auto& record = exception.ExceptionRecord;
    log << "exception index=" << index << " code=0x" << std::hex << record.ExceptionCode
        << " first=" << exception.dwFirstChance << " tid=" << std::dec << ev.dwThreadId
        << " address=" << record.ExceptionAddress << " flags=" << record.ExceptionFlags << '\n';
    for (DWORD i = 0; i < record.NumberParameters && i < EXCEPTION_MAXIMUM_PARAMETERS; ++i)
        log << " parameter" << i << "=0x" << std::hex << record.ExceptionInformation[i] << '\n';
    MEMORY_BASIC_INFORMATION memory = {};
    if (VirtualQueryEx(pi.hProcess, record.ExceptionAddress, &memory, sizeof memory))
        log << "memory allocation=" << memory.AllocationBase << " base=" << memory.BaseAddress
            << " size=0x" << memory.RegionSize << " state=0x" << memory.State
            << " protect=0x" << memory.Protect << " type=0x" << memory.Type << '\n';
    HANDLE thread = OpenThread(THREAD_GET_CONTEXT | THREAD_QUERY_INFORMATION, FALSE, ev.dwThreadId);
    CONTEXT context = {}; context.ContextFlags = CONTEXT_FULL;
    if (!thread || !GetThreadContext(thread, &context)) {
        log << "context unavailable error=" << std::dec << GetLastError() << '\n';
        if (thread) CloseHandle(thread); return;
    }
    log << "registers rip=0x" << std::hex << context.Rip << " rsp=0x" << context.Rsp
        << " rbp=0x" << context.Rbp << '\n';
    // Exception pointers below refer to this observer's local copies.
    EXCEPTION_RECORD copied = record;
    EXCEPTION_POINTERS pointers = {&copied, &context};
    MINIDUMP_EXCEPTION_INFORMATION information = {ev.dwThreadId, &pointers, FALSE};
    auto dump = out / (L"exception-" + std::to_wstring(index) + L".dmp");
    HANDLE file = CreateFileW(dump.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file != INVALID_HANDLE_VALUE) {
        BOOL wrote = MiniDumpWriteDump(pi.hProcess, pi.dwProcessId, file,
            static_cast<MINIDUMP_TYPE>(MiniDumpNormal | MiniDumpWithThreadInfo | MiniDumpWithUnloadedModules),
            &information, nullptr, nullptr);
        DWORD error = wrote ? 0 : GetLastError(); CloseHandle(file);
        log << "minidump wrote=" << wrote << " error=" << std::dec << error << '\n';
    } else log << "minidump create error=" << std::dec << GetLastError() << '\n';
    SymSetOptions(SYMOPT_DEFERRED_LOADS | SYMOPT_UNDNAME | SYMOPT_FAIL_CRITICAL_ERRORS | SYMOPT_NO_PROMPTS);
    auto symbols = out / L"symbols";
    bool initialized = SymInitializeW(pi.hProcess, symbols.c_str(), TRUE) != FALSE;
    if (initialized) {
        STACKFRAME64 frame = {};
        frame.AddrPC = {context.Rip, 0, AddrModeFlat};
        frame.AddrFrame = {context.Rbp, 0, AddrModeFlat};
        frame.AddrStack = {context.Rsp, 0, AddrModeFlat};
        for (unsigned i = 0; i < 64; ++i) {
            if (!StackWalk64(IMAGE_FILE_MACHINE_AMD64, pi.hProcess, thread, &frame, &context,
                            nullptr, SymFunctionTableAccess64, SymGetModuleBase64, nullptr)) break;
            if (!frame.AddrPC.Offset) break;
            IMAGEHLP_MODULEW64 module = {}; module.SizeOfStruct = sizeof module;
            log << "stack " << std::dec << i << " pc=0x" << std::hex << frame.AddrPC.Offset
                << " sp=0x" << frame.AddrStack.Offset;
            if (SymGetModuleInfoW64(pi.hProcess, frame.AddrPC.Offset, &module))
                log << " module=" << utf8(module.ModuleName) << "+0x" << frame.AddrPC.Offset - module.BaseOfImage;
            log << '\n';
        }
        SymCleanup(pi.hProcess);
    } else log << "symbols unavailable error=" << std::dec << GetLastError() << '\n';
    CloseHandle(thread); log.flush();
}
int wmain(int argc, wchar_t** argv) {
    if (argc < 3) return 2;
    std::filesystem::path out(argv[2]);
    if (!std::filesystem::exists(out)) return 3;
    std::ofstream log(out / L"events.log", std::ios::binary);
    SECURITY_ATTRIBUTES attributes = {sizeof attributes, nullptr, TRUE};
    HANDLE stdout_file = CreateFileW((out / L"target.stdout.log").c_str(), GENERIC_WRITE, FILE_SHARE_READ,
        &attributes, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
    HANDLE stderr_file = CreateFileW((out / L"target.stderr.log").c_str(), GENERIC_WRITE, FILE_SHARE_READ,
        &attributes, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (!log || stdout_file == INVALID_HANDLE_VALUE || stderr_file == INVALID_HANDLE_VALUE) return 4;
    std::wstring command = quote(argv[1]);
    for (int i = 3; i < argc; ++i) { command += L' '; command += quote(argv[i]); }
    STARTUPINFOW startup = {}; startup.cb = sizeof startup;
    startup.dwFlags = STARTF_USESTDHANDLES;
    startup.hStdOutput = stdout_file; startup.hStdError = stderr_file;
    startup.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
    PROCESS_INFORMATION pi = {};
    if (!CreateProcessW(argv[1], command.data(), nullptr, nullptr, TRUE,
                        DEBUG_ONLY_THIS_PROCESS | CREATE_NO_WINDOW, nullptr, nullptr, &startup, &pi)) {
        log << "create error=" << GetLastError() << '\n';
        CloseHandle(stdout_file); CloseHandle(stderr_file); return 5;
    }
    log << "owned target pid=" << pi.dwProcessId << '\n'; log.flush();
    CloseHandle(stdout_file); CloseHandle(stderr_file);
    bool initial_breakpoint = false, exited = false; unsigned captured = 0, modules = 0;
    DWORD actual_exit = STILL_ACTIVE;
    while (!exited) {
        DEBUG_EVENT event = {};
        if (!WaitForDebugEvent(&event, 1000)) {
            DWORD error = GetLastError();
            if (error == ERROR_SEM_TIMEOUT) continue;
            log << "wait error=" << error << '\n'; return 6;
        }
        if (event.dwProcessId != pi.dwProcessId) { log << "unexpected foreign event\n"; return 7; }
        DWORD disposition = DBG_CONTINUE;
        switch (event.dwDebugEventCode) {
        case CREATE_PROCESS_DEBUG_EVENT:
            file_event(log, event.u.CreateProcessInfo.hFile, "image", event.u.CreateProcessInfo.lpBaseOfImage); break;
        case LOAD_DLL_DEBUG_EVENT:
            if (modules++ < 512) file_event(log, event.u.LoadDll.hFile, "dll", event.u.LoadDll.lpBaseOfDll);
            else if (event.u.LoadDll.hFile) CloseHandle(event.u.LoadDll.hFile);
            break;
        case EXCEPTION_DEBUG_EVENT: {
            DWORD code = event.u.Exception.ExceptionRecord.ExceptionCode;
            if (code == EXCEPTION_BREAKPOINT && !initial_breakpoint) { initial_breakpoint = true; break; }
            disposition = DBG_EXCEPTION_NOT_HANDLED;
            if ((code == EXCEPTION_ACCESS_VIOLATION || code == EXCEPTION_STACK_OVERFLOW ||
                 code == EXCEPTION_ILLEGAL_INSTRUCTION || !event.u.Exception.dwFirstChance) &&
                (captured < 4 || !event.u.Exception.dwFirstChance))
                capture(pi, event, out, log, ++captured);
            break;
        }
        case EXIT_PROCESS_DEBUG_EVENT:
            actual_exit = event.u.ExitProcess.dwExitCode;
            log << "target exit=0x" << std::hex << actual_exit << " captures=" << std::dec << captured << '\n';
            exited = true; break;
        }
        log.flush();
        if (!ContinueDebugEvent(event.dwProcessId, event.dwThreadId, disposition)) {
            log << "continue error=" << GetLastError() << '\n'; return 8;
        }
    }
    WaitForSingleObject(pi.hProcess, INFINITE);
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    return actual_exit == 0 ? 0 : 1;
}
