"""Restore missing registry archives only at the existing lockfile checksums.

No compilation, test execution, resolution, dependency update or source edit.
Original failed offline boundary test remains failed in its own full-run output.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import tomllib
import urllib.request

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/reference-depth76'
CACHE = ROOT / '.tools/prerender-cargo-home/registry/cache/index.crates.io-1949cf8c6b5b557f'
OUT = BASE / 'depth75-locked-cache-restore-v1'
assert shutil.disk_usage(ROOT).free >= 10 << 30
lock_bytes = (WORK / 'Cargo.lock').read_bytes()
sha = lambda data: hashlib.sha256(data).hexdigest()
lock = tomllib.loads(lock_bytes.decode('utf-8'))
packages = [p for p in lock['package'] if p.get('source', '').startswith('registry+')]
assert len(packages) <= 2048
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='restoring_only_missing_locked_archives', startedUtc=datetime.now(timezone.utc).isoformat(),
              lockSha256=sha(lock_bytes), cache=str(CACHE), packages=[], downloadedBytes=0,
              limits=['IO-only restoration while existing serial native tests finish; no Cargo or other heavy workload',
                      'Official crates.io archives at original lock identities; no dependency additions or updates',
                      'No test assertion, ignore, environment gate or original failed result changed',
                      'Offline metadata and actual original boundary test still require separate execution'])
def save():
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
save()
try:
    for package in packages:
        name, version, checksum = (package[k] for k in ('name', 'version', 'checksum'))
        assert re.fullmatch(r'[A-Za-z0-9_-]+', name)
        assert re.fullmatch(r'[A-Za-z0-9_.+\-]+', version)
        assert re.fullmatch(r'[a-f0-9]{64}', checksum)
        assert package['source'] == 'registry+https://github.com/rust-lang/crates.io-index'
        archive = CACHE / f'{name}-{version}.crate'
        row = dict(name=name, version=version, sha256=checksum, restored=False)
        report['packages'].append(row)
        if not archive.exists():
            temporary = archive.with_suffix('.crate.depth75-partial')
            address = f'https://static.crates.io/crates/{name}/{name}-{version}.crate'
            row['source'] = address
            save()
            digest = hashlib.sha256()
            size = 0
            with urllib.request.urlopen(address, timeout=45) as response, temporary.open('xb') as destination:
                while block := response.read(64 << 10):
                    size += len(block)
                    assert size <= 256 << 20
                    assert report['downloadedBytes'] + size <= 1 << 30
                    digest.update(block)
                    destination.write(block)
            assert digest.hexdigest() == checksum, (name, version)
            assert not archive.exists(), 'Another task published this cache entry; retain partial for review'
            os.rename(temporary, archive)
            row.update(restored=True, bytes=size)
            report['downloadedBytes'] += size
        else:
            assert sha(archive.read_bytes()) == checksum, (name, version)
            row['bytes'] = archive.stat().st_size
        save()
    report['status'] = 'all_locked_registry_archives_verified_offline_metadata_and_test_pending'
except BaseException as cause:
    report.update(status='failed_original_outputs_retained', cause=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),
                  lockUnchanged=(WORK / 'Cargo.lock').read_bytes() == lock_bytes)
    save()
print(json.dumps(dict(status=report['status'], packages=len(packages),
                     restored=sum(p['restored'] for p in report['packages']), downloadedBytes=report['downloadedBytes'])))
