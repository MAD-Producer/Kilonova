"""Archive a consumed original full run, retaining previous failure authority.

This prepares evidence only. A failed or incomplete run cannot become acceptance.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, subprocess, zipfile

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/reference-depth76'
RUN = BASE / 'depth75-backend-workspace-v8'
OUT = BASE / 'depth75-maintained-workspace-public-v2'
report = json.loads((RUN / 'receipt.json').read_text(encoding='utf-8'))
consumed = json.loads((RUN / 'session-consumed.json').read_text(encoding='utf-8'))
assert consumed['session'] == 91059
assert report['status'] in ('complete_maintained_workspace_passed', 'failed_original_outputs_retained', 'observer_failed_original_outputs_retained')
assert report['baseCommit'] == '5fb253a48b204c0fd52c97669f7c2bf01c401c13'
accepted = (consumed['exitCode'] == 0 and report['status'] == 'complete_maintained_workspace_passed'
            and report['sourceUnchanged'] and report['fullTargetCoverageAccounted']
            and report['exitCode'] == 0 and not report['abnormalTargetExits']
            and report['totals']['summaryCount'] == report['totals']['expectedInvocations']
            and not report['totals']['failed'] and not report['totals']['filtered'])
assert (consumed['exitCode'] == 0) == accepted
sha = lambda raw: hashlib.sha256(raw).hexdigest()
members = {}
def add(directory, files, prefix, records=None):
    for name in files:
        data = (directory / name).read_bytes()
        if records and name in records:
            assert len(data) == records[name]['bytes'] and sha(data) == records[name]['sha256']
        members[prefix + '/' + name] = data
add(RUN, ('controller.py','receipt.json','stdout.log','stderr.log','cargo-metadata.json',
          'cache-preflight.json','boundary.stdout.log','boundary.stderr.log',
          'offline-metadata.json','offline-metadata.stderr.log',
          'session-consumed.json','host-memory.jsonl'),
    'evidence/current', report['logs'])
previous = BASE / 'depth75-backend-workspace-v6'
failed = json.loads((previous / 'receipt.json').read_text(encoding='utf-8'))
assert failed['status'] == 'failed_original_outputs_retained'
assert failed['sourceUnchanged'] and failed['exitCode'] == 101
assert failed['totals']['failed'] == 1 and len(failed['abnormalTargetExits']) == 1
add(previous, ('controller.py','receipt.json','stdout.log','stderr.log','cargo-metadata.json','session-consumed.json'),
    'evidence/previous-failed-full', failed['logs'])
add(BASE / 'depth75-locked-cache-restore-v1', ('controller.py','receipt.json','session-consumed.json'),
    'evidence/exact-locked-cache-correction')
for directory, status in (
    ('depth75-nested-access-probe-v1','diagnostic_completed_original_failure_not_waived'),
    ('depth75-native-startup-observation-v1','fixed_startup_and_target_observations_completed_original_crash_unresolved'),
):
    path = BASE / directory
    diagnostic = json.loads((path / 'receipt.json').read_text(encoding='utf-8'))
    assert diagnostic['status'] == status and diagnostic['executableUnchanged'] and diagnostic['sourceUnchanged']
    add(path, ('controller.py','receipt.json','session-consumed.json'), 'evidence/diagnostics/' + directory)
add(BASE / 'depth75-observer-fault-control-v1', ('controller.py','receipt.json','controlled_fault.cpp'),
    'evidence/diagnostics/controlled-real-fault')
members['evidence/diagnostics/native-observer.cpp'] = (BASE / 'depth75-native-crash-observer.cpp').read_bytes()
members['evidence/pinned-runtime-placement.json'] = (BASE / 'depth75-runtime-placement-v1/receipt.json').read_bytes()
placements = json.loads(members['evidence/pinned-runtime-placement.json'])['placements']
assert len(placements) == 14
runtime_observed = []
for item in placements:
    path = Path(item['path'])
    actual = sha(path.read_bytes())
    assert actual == item['sha256'], str(path)
    runtime_observed.append(dict(path=str(path), bytes=path.stat().st_size, sha256=actual))
members['evidence/runtime-at-archive.json'] = (json.dumps(dict(
    observedUtc=datetime.now(timezone.utc).isoformat(), placements=runtime_observed,
    scope='Endpoint hash verification; not a continuous runtime observation'), indent=2)+'\n').encode('utf-8')
audit_path = 'engineering/validation/data/depth75-rebase-integration-v1.json'
audit_bytes = subprocess.check_output(['git','show',report['baseCommit'] + ':' + audit_path], cwd=WORK)
assert sha(audit_bytes) == report['source'][audit_path]
members['evidence/integration.json'] = audit_bytes
for item in json.loads(audit_bytes)['files']:
    path = item['path']
    raw = subprocess.check_output(['git','show',report['baseCommit'] + ':' + path], cwd=WORK)
    assert sha(raw) == report['source'][path]
    members['source/' + path] = raw
members['archive-controller.py'] = Path(__file__).read_bytes()
manifest = dict(schema=2, sourceCommit=report['baseCommit'], mainAtAdmission=report['main'],
                observedUtc=datetime.now(timezone.utc).isoformat(), command=report['command'],
                status=('actual_complete_maintained_workspace_passed_consumed_exit0' if accepted
                        else 'original_full_failure_retained_not_accepted'),
                accepted=accepted, totals=report.get('totals'), elapsedSeconds=report['elapsedSeconds'],
                previousFailedRun=dict(status=failed['status'], exitCode=failed['exitCode'], totals=failed['totals'],
                    abnormalTargetExits=failed['abnormalTargetExits']),
                limits=['Exact Windows parent source only; later transition admission/routing code is outside this full run',
                    'Original assertions, ignores, features, GPU/backend, timeouts and10GiB admission retained',
                    'Offline cache correction passed the actual unchanged original boundary; previous full failure is not relabeled',
                    'Original native access violation cause remains unresolved; bounded diagnostic passes do not waive it',
                    'Passive host memory observations establish no memory root cause or thermal qualification',
                    'No Android, real-video quality, automatic capability/quality/cache/export claim',
                    'No model, source image, tensor, binary, symbol file or minidump included'],
                members={name:dict(bytes=len(raw), sha256=sha(raw)) for name,raw in members.items()})
OUT.mkdir(exist_ok=False)
archive = OUT / 'depth75-maintained-workspace-v2.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
    for name,raw in members.items(): z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == {'manifest.json',*members}
    assert json.loads(z.read('manifest.json')) == manifest
    for name,item in manifest['members'].items():
        raw = z.read(name)
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256'], name
manifest['archive'] = dict(file=archive.name, bytes=archive.stat().st_size,
    sha256=sha(archive.read_bytes()), verifiedMembers=len(members)+1)
(OUT / 'depth75-maintained-workspace-v2.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:manifest[key] for key in ('status','accepted','sourceCommit','totals','archive')}))
