"""Archive qualified profile evidence, excluding models, images and tensors."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/depth-resolution75';ART=ROOT/'artifacts/pr-queue'
HEAD='d9443b566595eb6bf5314f4f4bf46744e8a7d214'
DATA=WORK/'engineering/validation/data';ARCHIVE=DATA/'depth75-resolution-qualification-v1.zip'
MANIFEST=DATA/'depth75-resolution-qualification-v1.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
assert not ARCHIVE.exists() and not MANIFEST.exists()
models=json.loads((ART/'depth75-resolution-models-v1/receipt.json').read_text(encoding='utf-8'))
jobs=json.loads((ART/'depth75-resolution-jobs-v2/receipt.json').read_text(encoding='utf-8'))
assert models['completedUtc'] and models['sourceUnchanged'] and len(models['profiles'])==9
assert jobs['completedUtc'] and jobs['sourceUnchanged'] and jobs['probeSourceUnchanged'] and len(jobs['profiles'])==3
assert jobs['status']=='native_profile_contracts_and_actual_jobs_passed_quality_policy_and_full_regression_pending'
for directory in ('depth75-resolution-models-v1','depth75-resolution-jobs-v2'):
    assert json.loads((ART/directory/'session-consumed.json').read_text(encoding='utf-8'))['exitCode']==0
for name,digest in {**models['source'],**jobs['source']}.items():assert sha(WORK/name)==digest
members={}

def add(path,name):
    assert path.is_file() and name not in members and not name.startswith('/') and '..' not in Path(name).parts
    assert path.suffix not in ('.onnx','.pth','.f32','.rgb','.png','.exe','.dll')
    members[name]=path.read_bytes()

for directory in ('depth75-resolution-admission-v1','depth75-resolution-python-v2','depth75-resolution-report-contract-v1',
                  'depth75-resolution-models-v1','depth75-resolution-jobs-v1','depth75-resolution-jobs-v2'):
    base=ART/directory
    for path in sorted(base.iterdir()):
        if path.is_file() and (path.suffix in ('.json','.log','.py') or path.name=='Cargo.lock'):
            add(path,'evidence/'+directory+'/'+path.name)
for side in (266,392,518):
    model_root=ART/'depth75-resolution-models-v1'/str(side)
    add(model_root/'export/model.json',f'evidence/models/{side}/model.json')
    add(model_root/'references.json',f'evidence/models/{side}/references.json')
    for case in ('153x101','101x153','1x53'):
        case_root=model_root/case
        add(case_root/'request.json',f'evidence/models/{side}/{case}/request.json')
        for path in sorted(case_root.glob('ort-profile*.json')):
            add(path,f'evidence/models/{side}/{case}/'+path.name)
    native=ART/'depth75-resolution-jobs-v2'/str(side)
    add(native/'receipt.json',f'evidence/jobs/{side}/receipt.json')
    add(native/'logs/motion-studio.log',f'evidence/jobs/{side}/motion-studio.log')
for name in ('Cargo.toml','Cargo.lock','src/main.rs'):
    add(ROOT/'.tools/ai-depth74/resolution-probe'/name,'native-probe/'+name)
for name in ('crates/motion-host/src/depth.rs','crates/motion-host/src/depth/onnx.rs','tools/ai_depth_onnx.py',
             'tools/export_ai_depth.py','tools/test_ci_depth_export.py','tools/validation_inventory.json','desktop/app/src/logging.rs','Cargo.lock'):
    add(WORK/name,'qualified-source/'+name)
add(ROOT/'.tools/issue-closure-review/observe-depth75-resolution-differences-v1.py','observers/observe-resolution-differences.py')
add(Path(__file__),'observers/archive.py')
inventory={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in members.items()}
summary=dict(schema=1,sourceCommit=HEAD,createdUtc=datetime.now(timezone.utc).isoformat(),
             source={name:sha(WORK/name) for name in jobs['source']},
             actualModelProfiles=3,actualPythonComparisons=9,actualJobsComparisons=9,actualExpectedProfileFailures=3,
             gates=models['gates'],worstMaxNormalized=max(row['maxNormalized'] for row in models['profiles']),
             worstMeanNormalized=max(row['meanNormalized'] for row in models['profiles']),
             limits=['Explicit ONNX resolution candidates, not fast/standard/high quality tiers',
                     'Existing attributed static photo crops; no depth truth or actual video switching qualification',
                     'Native contracts and Jobs passed; external probe v1 compiler failure remains retained',
                     'Separate full workspace source064 run failed 16 loader targets; no full regression pass claimed',
                     'No model weights, ONNX graphs, original images, tensors or binaries included'],members=inventory)
members['manifest.json']=(json.dumps(summary,indent=2)+'\n').encode('utf-8')
with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in members.items():archive.writestr(name,data)
with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None
    for name,expected in inventory.items():
        actual=archive.read(name)
        assert len(actual)==expected['bytes'] and hashlib.sha256(actual).hexdigest()==expected['sha256']
assert all(sha(WORK/name)==digest for name,digest in jobs['source'].items())
summary.pop('members');summary.update(archive=ARCHIVE.name,archiveBytes=ARCHIVE.stat().st_size,archiveSha256=sha(ARCHIVE),memberCount=len(members))
MANIFEST.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
