"""Bounded scalar analysis of completed profile outputs; no model/CV/GPU run.

These are resolution-dependent predictions, not a same-model numerical error
test or temporal/physical depth ground truth. No fitting or rescaling is used.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, math, struct

ROOT=Path('E:/Dev/aem/artifacts/pr-queue/depth75-resolution-models-v1')
receipt=json.loads((ROOT/'receipt.json').read_text(encoding='utf-8'))
assert receipt['sourceUnchanged'] and receipt['completedUtc']
assert json.loads((ROOT/'session-consumed.json').read_text(encoding='utf-8'))['exitCode']==0
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def read(row):
    width,height=row['size'];case=ROOT/str(row['side'])/f'{width}x{height}'
    path=case/'output.f32'
    assert sha(path)==row['outputSha256'] and path.stat().st_size==width*height*4
    values=[value for (value,) in struct.iter_unpack('<f',path.read_bytes())]
    assert all(map(math.isfinite,values))
    return values,sha(case/'input.rgb')

rows=[]
for size in ([153,101],[101,153],[1,53]):
    controls=[r for r in receipt['profiles'] if r['side']==518 and r['size']==size]
    assert len(controls)==1
    canonical,input_sha=read(controls[0]);amplitude=max(max(map(abs,canonical)),1e-6)
    for side in (266,392):
        candidates=[r for r in receipt['profiles'] if r['side']==side and r['size']==size]
        assert len(candidates)==1
        values,other_input=read(candidates[0]);assert input_sha==other_input
        differences=[abs(a-b) for a,b in zip(values,canonical,strict=True)]
        rows.append(dict(size=size,side=side,canonicalSide=518,inputSha256=input_sha,
                         canonicalOutputSha256=controls[0]['outputSha256'],outputSha256=candidates[0]['outputSha256'],
                         maxDifferenceOverCanonicalAmplitude=max(differences)/amplitude,
                         meanDifferenceOverCanonicalAmplitude=sum(differences)/len(differences)/amplitude,
                         mean=sum(values)/len(values),canonicalMean=sum(canonical)/len(canonical),
                         minimum=min(values),maximum=max(values),canonicalMinimum=min(canonical),canonicalMaximum=max(canonical)))
result=dict(observedUtc=datetime.now(timezone.utc).isoformat(),sourceCommit=receipt['sourceCommit'],
            modelReceiptSha256=sha(ROOT/'receipt.json'),observations=rows,
            limits=['Same input crops; independent resolution-dependent predictions, not a backend-equivalence error gate',
                    'No fitting, affine adjustment, output replacement, threshold or quality ranking',
                    'Not a temporal switching experiment or physical ground truth; quality policy remains unqualified'])
out=ROOT/'cross-resolution-observation.json';assert not out.exists()
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows))
