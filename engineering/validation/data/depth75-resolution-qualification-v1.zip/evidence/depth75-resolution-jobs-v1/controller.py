"""Deferred source-bound Rust contract tests and actual ONNX Jobs qualification."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess, time, traceback

ROOT=Path('E:/Dev/aem'); WORK=ROOT/'.worktrees/depth-resolution75'
OUT=ROOT/'artifacts/pr-queue/depth75-resolution-jobs-v1'
MODELS=ROOT/'artifacts/pr-queue/depth75-resolution-models-v1'
PROBE=ROOT/'.tools/ai-depth74/resolution-probe'
HEAD='d9443b566595eb6bf5314f4f4bf46744e8a7d214'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()

full=ROOT/'artifacts/pr-queue/depth75-backend-workspace-v3'
prior=json.loads((full/'receipt.json').read_text(encoding='utf-8'))
assert prior.get('completedUtc') and prior['sourceUnchanged']
assert json.loads((full/'session-consumed.json').read_text(encoding='utf-8'))['exitCode'] is not None
models=json.loads((MODELS/'receipt.json').read_text(encoding='utf-8'))
assert models['status']=='real_exports_and_python_reference_paths_passed_rust_jobs_quality_policy_pending'
assert models['sourceUnchanged'] and models['sourceCommit']==HEAD and models['completedUtc']
assert json.loads((MODELS/'session-consumed.json').read_text(encoding='utf-8'))['exitCode']==0
assert shutil.disk_usage(ROOT).free>=10<<30, 'Original 10 GiB native admission'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
for name,digest in models['source'].items(): assert sha(WORK/name)==digest
source_names=['crates/motion-host/src/depth.rs','crates/motion-host/src/depth/onnx.rs','tools/ai_depth_onnx.py','desktop/app/src/logging.rs','Cargo.lock']
source={name:sha(WORK/name) for name in source_names}
probe_source={name:sha(PROBE/name) for name in ('Cargo.toml','src/main.rs')}
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'):env.pop(name)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/colmap88-isolated-check'),
           CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
           TEMP=str(ROOT/'target/colmap88-isolated-check/tmp'),TMP=str(ROOT/'target/colmap88-isolated-check/tmp'),
           LOCALAPPDATA=str(OUT/'appdata'),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',RUST_BACKTRACE='full')
report=dict(status='running',sourceCommit=HEAD,source=source,probeSource=probe_source,stages=[],profiles=[],
            startedUtc=datetime.now(timezone.utc).isoformat(),modelReceiptSha256=sha(MODELS/'receipt.json'),
            limits=['Focused new host contract tests and actual Jobs; not complete workspace regression',
                    'Each request starts a cold owned CPU process; no warm/steady-state/thermal claim',
                    'Existing NASA photo crops; independent PyTorch same-model reference, not depth truth',
                    'Original numerical gates 2e-4/2e-5, no per-frame normalization or fit',
                    'No original assertion, skip, backend, stack or feature gate changed',
                    'Original full failure remains retained; explicit profiles are not quality tiers'])

def save():
    pending=OUT/'receipt.pending.json';pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(pending,OUT/'receipt.json')

def run(name,command,cwd=WORK):
    row=dict(name=name,command=list(map(str,command)),status='running');report['stages'].append(row);save();began=time.monotonic()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(row['command'],cwd=cwd,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();code=child.wait()
    row.update(exitCode=code,status='passed' if code==0 else 'failed',wallSeconds=time.monotonic()-began);save()
    if code!=0:raise RuntimeError(f'{name} exit={code}; original output retained')

save();began=time.monotonic()
try:
    run('host-profile-contracts',['cargo','test','-p','motion-host','--features','ai-depth','--lib','depth::onnx::profile_tests::','--locked','--','--test-threads=1'])
    text=(OUT/'host-profile-contracts.stdout.log').read_text(encoding='utf-8')
    assert 'test result: ok. 2 passed; 0 failed;' in text
    lock=PROBE/'Cargo.lock'
    assert not lock.exists(), 'Never overwrite an earlier probe lock'
    shutil.copyfile(WORK/'Cargo.lock',lock)
    run('probe-offline-metadata',['cargo','metadata','--manifest-path',PROBE/'Cargo.toml','--offline','--format-version','1'])
    report['probeLockSha256']=sha(lock);shutil.copyfile(lock,OUT/'Cargo.lock');save()
    metadata=json.loads((OUT/'probe-offline-metadata.stdout.log').read_text(encoding='utf-8'))
    for name in ('motion-host','motion-model'):
        entries=[p for p in metadata['packages'] if p['name']==name]
        assert len(entries)==1 and Path(entries[0]['manifest_path']).resolve()==(WORK/'crates'/name/'Cargo.toml').resolve()
    run('probe-build',['cargo','build','--manifest-path',PROBE/'Cargo.toml','--offline','--locked'])
    binary=ROOT/'target/colmap88-isolated-check/debug/motion-depth75-resolution-probe.exe'
    report['probeBinarySha256']=sha(binary);save()
    for side in (266,392,518):
        profile=MODELS/str(side);native_out=OUT/str(side)
        run(f'{side}-actual-jobs',[binary,profile,native_out])
        result=json.loads((native_out/'receipt.json').read_text(encoding='utf-8'))
        assert result['completed']==3 and result['failed']==1 and result['inFlightClear'] and result['scratchEmpty'] and result['queueDepth']==0
        assert len(result['reports'])==3 and all(r['inFlightObserved'] for r in result['reports'])
        stdout=(OUT/f'{side}-actual-jobs.stdout.log').read_text(encoding='utf-8')
        stderr=(OUT/f'{side}-actual-jobs.stderr.log').read_text(encoding='utf-8')
        assert json.loads(stdout)['expectedFailures']==1, 'stdout must contain only the probe protocol'
        log=(native_out/'logs/motion-studio.log').read_text(encoding='utf-8')
        assert 'logging initialized level=INFO' in log
        assert all(f'start #{n} depth_infer' in log for n in range(1,5))
        assert 'ERROR' in stderr and 'operation=depth_infer' in stderr and 'model input differs from requested' in stderr
        assert 'ERROR' in log and 'phase=session' in log
        report['profiles'].append(result);save()
    report['status']='native_profile_contracts_and_actual_jobs_passed_quality_policy_and_full_regression_pending'
except BaseException as error:
    report.update(status='failed_original_outputs_retained',failure=repr(error),traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=all(sha(WORK/name)==digest for name,digest in source.items()) and subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==HEAD,
                  probeSourceUnchanged=all(sha(PROBE/name)==digest for name,digest in probe_source.items()),completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-began)
    save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','probeSource','profiles','stages')}))
raise SystemExit(0 if report['status'].startswith('native_profile_contracts_') and report['sourceUnchanged'] and report['probeSourceUnchanged'] else 1)
