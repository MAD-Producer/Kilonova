"""Serial, source-bound real exports and independent reference comparisons.

Deferred until the existing full native session is terminal AND consumed.
This qualifies three explicit ONNX profiles, not a quality-tier scheduler.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/depth-resolution75'
OUT = ROOT / 'artifacts/pr-queue/depth75-resolution-models-v1'
HOME = ROOT / '.tools/ai-depth74'
PYTHON = HOME / 'venv/Scripts/python.exe'
HEAD = 'd9443b566595eb6bf5314f4f4bf46744e8a7d214'
REVISION = 'a561b849ebae10a6f5ef49e26c83cbbcd36c71bf'
WEIGHT_SHA = '715fade13be8f229f8a70cc02066f656f2423a59effd0579197bbf57860e1378'
PHOTO_SHA = 'e8ed893f990ba8850000064e153d57b84e6e1d5c0a0aa2ccc8dfd1254b2e379d'
MAXIMUM = 2e-4
MEAN = 2e-5


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reference(side):
    """Independent official normalization/model and PyTorch output resampling."""
    import cv2
    import numpy as np
    import torch
    from PIL import Image
    sys.path.insert(0, str(HOME / 'official-reference'))
    from depth_anything_v2.dpt import DepthAnythingV2
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    photo = WORK / 'crates/motion-desktop-media/tests/fixtures/professional-screen/destiny-screen.png'
    assert sha(photo) == PHOTO_SHA
    image = np.asarray(Image.open(photo).convert('RGB'))
    assert image.shape == (654, 960, 3)
    profile = OUT / str(side)
    model = DepthAnythingV2(encoder='vits', features=64, out_channels=[48, 96, 192, 384]).cpu().eval()
    model.load_state_dict(torch.load(HOME / 'models/depth_anything_v2_vits.pth', map_location='cpu', weights_only=True), strict=True)
    records = []
    for width, height in [(153, 101), (101, 153), (1, 53)]:
        case = profile / f'{width}x{height}'
        case.mkdir()
        rgb = image[80:80+height, 100:100+width].copy()
        (case / 'input.rgb').write_bytes(rgb.tobytes())
        # Ratio is independently calculated from integer source dimensions;
        # do not call the owned worker's geometry, normalization or resampler.
        denominator = max(width, height)
        rw = max(1, (width * side * 2 + denominator) // (2 * denominator))
        rh = max(1, (height * side * 2 + denominator) // (2 * denominator))
        x, y = (side-rw)//2, (side-rh)//2
        boxed = np.zeros((side, side, 3), dtype=np.uint8)
        boxed[y:y+rh, x:x+rw] = cv2.resize(rgb, (rw, rh), interpolation=cv2.INTER_CUBIC)
        tensor, _ = model.image2tensor(boxed[:, :, ::-1].copy(), input_size=side)
        assert tuple(tensor.shape) == (1, 3, side, side)
        began = time.perf_counter_ns()
        with torch.no_grad():
            plane = model(tensor).unsqueeze(1)
            value = torch.nn.functional.interpolate(plane[:, :, y:y+rh, x:x+rw], size=(height, width), mode='bilinear', align_corners=True)[0, 0].numpy()
        assert value.shape == (height, width) and np.isfinite(value).all()
        value.astype('<f4').tofile(case / 'official-reference.f32')
        records.append(dict(size=[width, height], rectangle=[x, y, rw, rh], inputSha256=sha(case/'input.rgb'), referenceSha256=sha(case/'official-reference.f32'), referenceWallNs=time.perf_counter_ns()-began))
    (profile/'references.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')


def main():
    full = ROOT/'artifacts/pr-queue/depth75-backend-workspace-v3'
    prerequisite = json.loads((full/'receipt.json').read_text(encoding='utf-8'))
    consumed = json.loads((full/'session-consumed.json').read_text(encoding='utf-8'))
    assert prerequisite.get('completedUtc') and prerequisite['status'] != 'running' and prerequisite['sourceUnchanged']
    assert consumed['exitCode'] is not None, 'Consume the full native session first; never overlap native workloads'
    assert shutil.disk_usage(ROOT).free >= 10 << 30, 'Original disk admission; no model execution started'
    assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=WORK, text=True).strip() == HEAD
    assert not subprocess.check_output(['git','status','--porcelain'], cwd=WORK)
    ref = HOME/'official-reference'
    assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=ref, text=True).strip() == REVISION
    subprocess.run(['git','diff','--quiet','HEAD','--'], cwd=ref, check=True)
    weights = HOME/'models/depth_anything_v2_vits.pth'
    assert weights.stat().st_size == 99218434 and sha(weights) == WEIGHT_SHA
    paths = ['tools/export_ai_depth.py','tools/ai_depth_onnx.py','crates/motion-host/src/depth/onnx.rs']
    source = {name:sha(WORK/name) for name in paths}
    OUT.mkdir(exist_ok=False)
    (OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
    env = os.environ.copy()
    for name in list(env):
        if name.startswith('MOTION_'): env.pop(name)
    for name in ('TEMP','TMP','TORCH_HOME','HF_HOME','TORCHINDUCTOR_CACHE_DIR'):
        directory = OUT/name.lower(); directory.mkdir()
        env[name] = str(directory)
    env.update(PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='')
    receipt = dict(status='running', sourceCommit=HEAD, source=source, referenceRevision=REVISION, weightsSha256=WEIGHT_SHA,
                   startedUtc=datetime.now(timezone.utc).isoformat(), stages=[], profiles=[],
                   gates=dict(maxNormalized=MAXIMUM, meanNormalized=MEAN),
                   previousFullStatus=prerequisite['status'], previousFullReceiptSha256=sha(full/'receipt.json'),
                   limits=['Three cold ONNX candidates, not measured quality tiers or interactive/thermal claims',
                           'Existing credited NASA photo crops, not ground-truth depth or actual video',
                           'Independent official model/PyTorch reference; no fit or per-frame normalization',
                           'No native Rust/Jobs qualification supplied by this Python-only controller',
                           'Original full failures remain retained; no assertions/ignores/budgets/backend changes'])

    def save():
        temporary = OUT/'receipt.pending.json'
        temporary.write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
        os.replace(temporary, OUT/'receipt.json')

    def run(name, command):
        stage = dict(name=name, command=list(map(str, command)), status='running')
        receipt['stages'].append(stage); save()
        began = time.monotonic()
        with (OUT/(name+'.stdout.log')).open('wb') as stdout, (OUT/(name+'.stderr.log')).open('wb') as stderr:
            child = subprocess.Popen(stage['command'], cwd=WORK, env=env, stdout=stdout, stderr=stderr)
            stage['pid'] = child.pid; save()
            code = child.wait()
        stage.update(status='passed' if code == 0 else 'failed', exitCode=code, wallSeconds=time.monotonic()-began); save()
        if code != 0: raise RuntimeError(f'{name} exited {code}; original output retained')

    save(); began = time.monotonic()
    try:
        import numpy as np
        for side in (266, 392, 518):
            profile = OUT/str(side); profile.mkdir()
            destination = profile/'export'
            run(f'{side}-export', [PYTHON, '-B', WORK/'tools/export_ai_depth.py', '--reference', ref, '--weights', weights, '--output', destination, '--side', side])
            manifest = json.loads((destination/'model.json').read_text(encoding='utf-8'))
            model = destination/manifest['file']; digest = sha(model)
            processing = f'dav2-small-rgb8-letterbox{side}-align-corners-relative-v1'
            assert manifest['sha256'] == digest and manifest['weightsSha256'] == WEIGHT_SHA
            assert manifest['processing'] == processing and manifest['inputShape'] == [1,3,side,side] and manifest['outputShape'] == [1,side,side]
            assert manifest['referenceProbe']['maxNormalized'] <= MAXIMUM and manifest['referenceProbe']['meanNormalized'] <= MEAN
            run(f'{side}-reference', [PYTHON, '-B', Path(__file__).resolve(), '--reference-fixtures', side])
            records = json.loads((profile/'references.json').read_text(encoding='utf-8'))
            for row in records:
                width, height = row['size']; case = profile/f'{width}x{height}'
                request = dict(schema=1, model=str(model), sha256=digest, processing=processing, width=width, height=height, provider='CPUExecutionProvider')
                (case/'request.json').write_text(json.dumps(request)+'\n', encoding='utf-8')
                name = f'{side}-{width}x{height}-worker'
                run(name, [PYTHON, '-I', '-B', WORK/'tools/ai_depth_onnx.py', case])
                actual = json.loads((OUT/(name+'.stdout.log')).read_text(encoding='utf-8'))
                assert actual['processing'] == processing and actual['sha256'] == digest
                assert actual['providers'] == ['CPUExecutionProvider'] and not actual['cpu_fallback']
                assert actual['letterbox'] == row['rectangle']
                assert actual['input_host_copy_bytes'] == 3*side*side*4 and actual['output_host_copy_bytes'] == side*side*4
                assert actual['resource_bytes'] == width*height*4
                expected = np.fromfile(case/'official-reference.f32', dtype='<f4')
                result = np.fromfile(case/'output.f32', dtype='<f4')
                assert expected.shape == result.shape == (width*height,) and np.isfinite(result).all()
                error = np.abs(result.astype(np.float64)-expected.astype(np.float64))
                amplitude = max(float(np.abs(expected).max()), 1e-6)
                maximum, mean = float(error.max())/amplitude, float(error.mean())/amplitude
                assert maximum <= MAXIMUM and mean <= MEAN, (side, width, height, maximum, mean)
                receipt['profiles'].append(dict(side=side, processing=processing, modelSha256=digest, size=[width,height], maxNormalized=maximum, meanNormalized=mean, outputSha256=sha(case/'output.f32'), report=actual))
                save()
        receipt['status'] = 'real_exports_and_python_reference_paths_passed_rust_jobs_quality_policy_pending'
    except BaseException as error:
        receipt.update(status='failed_original_outputs_retained', failure=repr(error), traceback=traceback.format_exc())
    finally:
        receipt.update(sourceUnchanged=all(sha(WORK/name) == digest for name,digest in source.items()) and subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip() == HEAD,
                       completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=time.monotonic()-began)
        save()
    print(json.dumps({key:value for key,value in receipt.items() if key not in ('source','profiles','stages')}))
    return 0 if receipt['status'].startswith('real_exports_') and receipt['sourceUnchanged'] else 1


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--reference-fixtures':
        reference(int(sys.argv[2]))
    else:
        raise SystemExit(main())
