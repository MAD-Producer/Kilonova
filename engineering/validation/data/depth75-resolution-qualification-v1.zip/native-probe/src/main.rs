//! External acceptance probe. Actual Jobs, embedded ONNX worker and file sink.
#[path = "E:/Dev/aem/.worktrees/depth-resolution75/desktop/app/src/logging.rs"]
mod logging;
mod engine {
    pub fn current_command() -> Option<(u64, &'static str, std::time::Duration)> {
        None
    }
}
use motion_host::depth::{
    onnx::{processing_side, Config, Onnx, Provider},
    Input, Jobs, Key,
};
use motion_model::depth::{DepthGeometry, DepthModel, DepthSource, DepthTime};
use std::{
    fs,
    path::PathBuf,
    sync::Arc,
    thread,
    time::{Duration, Instant},
};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;

fn wait(
    jobs: &mut Jobs,
    key: &Key,
    ticket: u64,
) -> Result<(
    motion_host::depth::Result<motion_host::depth::Estimate>,
    bool,
)> {
    let began = Instant::now();
    let mut saw_flight = false;
    loop {
        if let Some(flight) = jobs.in_flight()? {
            assert_eq!(flight.request, ticket);
            assert!(flight
                .source
                .as_ref()
                .expect("a direct sample flight must publish its source")
                .same_sample(&key.source));
            saw_flight = true;
        }
        match jobs.take_ready(key) {
            Ok(Some(value)) => return Ok((Ok(value), saw_flight)),
            Err(error) => return Ok((Err(error), saw_flight)),
            Ok(None) => {}
        }
        if began.elapsed() > Duration::from_secs(120) {
            jobs.cancel()?;
            return Err("real ONNX job exceeded the original probe deadline".into());
        }
        thread::sleep(Duration::from_millis(2));
    }
}

fn main() -> Result<()> {
    let args: Vec<String> = std::env::args().collect();
    assert_eq!(args.len(), 3);
    let profile = PathBuf::from(&args[1]);
    let out = PathBuf::from(&args[2]);
    assert!(profile.is_absolute() && out.is_absolute() && !out.exists());
    fs::create_dir_all(&out)?;
    let _logger = logging::init(out.join("logs"))?;
    let manifest: serde_json::Value =
        serde_json::from_slice(&fs::read(profile.join("export/model.json"))?)?;
    let digest = manifest["sha256"].as_str().ok_or("missing model digest")?;
    assert_eq!(digest.len(), 64);
    let hash: Vec<u8> = (0..64)
        .step_by(2)
        .map(|i| u8::from_str_radix(&digest[i..i + 2], 16))
        .collect::<std::result::Result<_, _>>()?;
    let model = DepthModel {
        id: manifest["id"].as_str().ok_or("missing model id")?.into(),
        revision: manifest["revision"]
            .as_str()
            .ok_or("missing model revision")?
            .into(),
        processing: manifest["processing"]
            .as_str()
            .ok_or("missing processing")?
            .into(),
        sha256: hash.try_into().map_err(|_| "invalid digest length")?,
    };
    let side = processing_side(&model.processing).ok_or("unsupported profile")?;
    let scratch = out.join("scratch");
    let mut jobs = Jobs::start(Onnx::new(Config {
        python: PathBuf::from("E:/Dev/aem/.tools/ai-depth74/venv/Scripts/python.exe"),
        model: profile
            .join("export")
            .join(manifest["file"].as_str().ok_or("missing file")?),
        scratch: scratch.clone(),
        provider: Provider::Cpu,
    })?)?;
    let mut reports = Vec::new();
    for (index, [width, height]) in [[153, 101], [101, 153], [1, 53]].into_iter().enumerate() {
        let case = profile.join(format!("{width}x{height}"));
        let key = Key {
            source: DepthSource {
                asset: 7515,
                revision: 1,
                pts: DepthTime {
                    ticks: index as i64 * 1001,
                    timescale: 24000,
                },
            },
            geometry: DepthGeometry {
                source_size: [960, 654],
                crop: [100, 80, width, height],
                quarter_turns: 0,
                mirror_x: false,
            },
            model: model.clone(),
        };
        let ticket = jobs.request(Input::new(
            key.clone(),
            [width, height],
            Arc::from(fs::read(case.join("input.rgb"))?),
        )?)?;
        let (result, saw_flight) = wait(&mut jobs, &key, ticket)?;
        assert!(
            saw_flight,
            "flight must be published before learned inference returns"
        );
        let value = result?;
        assert_eq!(value.provider, "CPUExecutionProvider");
        assert_eq!(value.resource.descriptor().size, [width, height]);
        assert_eq!(value.resource.descriptor().model, model);
        assert_eq!(value.resource.descriptor().geometry, key.geometry);
        assert!(value.resource.descriptor().source.same_sample(&key.source));
        assert_eq!(
            value.costs.input_bytes,
            3 * u64::from(side) * u64::from(side) * 4
        );
        assert_eq!(
            value.costs.output_bytes,
            u64::from(side) * u64::from(side) * 4
        );
        assert!(
            value.costs.inference > Duration::ZERO && value.costs.total >= value.costs.inference
        );
        assert!(
            value.costs.host_transport > Duration::ZERO
                && value.costs.host_transport <= value.costs.total
        );
        let bytes = fs::read(case.join("official-reference.f32"))?;
        assert_eq!(bytes.len(), value.resource.values().len() * 4);
        let expected: Vec<f32> = bytes
            .chunks_exact(4)
            .map(|b| f32::from_le_bytes(b.try_into().unwrap()))
            .collect();
        assert!(expected.iter().all(|v| v.is_finite()));
        let amplitude = expected
            .iter()
            .map(|v| f64::from(v.abs()))
            .fold(1e-6, f64::max);
        let errors: Vec<f64> = value
            .resource
            .values()
            .iter()
            .zip(expected)
            .map(|(a, b)| (f64::from(*a) - f64::from(b)).abs())
            .collect();
        let maximum = errors.iter().copied().fold(0., f64::max) / amplitude;
        let mean = errors.iter().sum::<f64>() / errors.len() as f64 / amplitude;
        assert!(
            maximum <= 2e-4 && mean <= 2e-5,
            "side={side} error={maximum}/{mean}"
        );
        fs::write(
            out.join(format!("{width}x{height}.f32")),
            value
                .resource
                .values()
                .iter()
                .flat_map(|v| v.to_le_bytes())
                .collect::<Vec<_>>(),
        )?;
        reports.push(serde_json::json!({"size":[width,height],"request":ticket,"inFlightObserved":saw_flight,
            "maxNormalized":maximum,"meanNormalized":mean,"provider":value.provider,
            "costsNs":{"total":value.costs.total.as_nanos(),"sourcePrepare":value.costs.source_prepare.as_nanos(),
                "hostTransport":value.costs.host_transport.as_nanos(),"load":value.costs.load.as_nanos(),
                "preprocess":value.costs.preprocess.as_nanos(),"inputCopy":value.costs.input_copy.as_nanos(),
                "inference":value.costs.inference.as_nanos(),"outputCopy":value.costs.output_copy.as_nanos(),
                "postprocess":value.costs.postprocess.as_nanos()},
            "inputBytes":value.costs.input_bytes,"outputBytes":value.costs.output_bytes}));
    }
    // Execute an actual known-but-mismatched processing request against the same
    // owned model bytes. It must retain the original shape-contract failure.
    let mut wrong = model.clone();
    let other = if side == 518 { 266 } else { 518 };
    wrong.processing = format!("dav2-small-rgb8-letterbox{other}-align-corners-relative-v1");
    let key = Key {
        source: DepthSource {
            asset: 7515,
            revision: 1,
            pts: DepthTime {
                ticks: 4004,
                timescale: 24000,
            },
        },
        geometry: DepthGeometry {
            source_size: [960, 654],
            crop: [100, 80, 153, 101],
            quarter_turns: 0,
            mirror_x: false,
        },
        model: wrong,
    };
    let ticket = jobs.request(Input::new(
        key.clone(),
        [153, 101],
        Arc::from(fs::read(profile.join("153x101/input.rgb"))?),
    )?)?;
    let (failed, saw_flight) = wait(&mut jobs, &key, ticket)?;
    assert!(saw_flight);
    let cause = failed
        .expect_err("cross-profile substitution must fail")
        .to_string();
    assert!(
        cause.contains("phase=session") && cause.contains("model input differs from requested"),
        "{cause}"
    );
    assert_eq!(jobs.counts()?.completed, 3);
    assert_eq!(jobs.counts()?.failed, 1);
    assert_eq!(jobs.queue_depth()?, 0);
    assert!(jobs.in_flight()?.is_none());
    drop(jobs);
    assert_eq!(fs::read_dir(&scratch)?.count(), 0);
    let summary = serde_json::json!({"processing":model.processing,"modelSha256":digest,"reports":reports,
        "negative":{"request":ticket,"inFlightObserved":saw_flight,"cause":cause},
        "completed":3,"failed":1,"queueDepth":0,"inFlightClear":true,"scratchEmpty":true});
    fs::write(
        out.join("receipt.json"),
        serde_json::to_vec_pretty(&summary)?,
    )?;
    println!(
        "{}",
        serde_json::json!({"processing":model.processing,"completed":3,"expectedFailures":1})
    );
    Ok(())
}
