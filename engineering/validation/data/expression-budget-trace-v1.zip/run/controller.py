from pathlib import Path
from datetime import datetime, timezone
import subprocess, hashlib, json, os, re, time

root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-import88'
out=root/'artifacts/pr-queue/clock85-expression-budget-trace-v1';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','crates','desktop','Cargo.toml','Cargo.lock'],cwd=work).decode().splitlines()
names.append('crates/motion-core/src/expressions/runtime/budget_trace.rs')
sources={name:sha(work/name) for name in names if (work/name).is_file() and (name.endswith(('.rs','.wgsl','Cargo.toml','Cargo.lock')))}
env=os.environ.copy();env.pop('MOTION_LOG',None)
command=['cargo','test','-p','motion-core','--lib','--test','expression_preparation','--test','expression_sample_time','--test','expression_sandbox','--test','expression_references','--locked','--offline','--','--test-threads=1']
report=dict(status='queued_for_existing_cargo_target_lock',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),source=sources,command=command,startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Only specified expression targets plus complete core lib; no second GPU run, unchanged 20ms/100ms deadlines and original assertions','Observation increment is not a fix for earlier CI timeout or native product/compiler faults','Shares E target and waits for original full desktop/UI Cargo gate; child source tree is untouched'])
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
try:
 with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
  p=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);report['cargoPid']=p.pid;save();report['exitCode']=p.wait()
 report['summaries']=re.findall(r'^test result: .+$',(out/'stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
 report['sourceUnchanged']=all(sha(work/name)==digest for name,digest in sources.items());save()
 assert report['exitCode']==0 and report['sourceUnchanged'] and len(report['summaries'])==5
 assert all('0 failed; 0 ignored; 0 measured; 0 filtered out' in summary for summary in report['summaries'])
 report['status']='scoped_budget_observation_gate_passed_original_ci_timeout_unresolved'
except BaseException as cause:report.update(status='failed_original_outputs_retained',failure=repr(cause));raise
finally:report.update(elapsedSeconds=round(time.monotonic()-began,3),completedUtc=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({k:v for k,v in report.items() if k!='source'}),flush=True)
