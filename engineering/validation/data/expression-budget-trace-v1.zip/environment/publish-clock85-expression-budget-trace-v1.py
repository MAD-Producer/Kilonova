from pathlib import Path
import json,hashlib,re,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-import88'
out=root/'artifacts/pr-queue/clock85-expression-budget-trace-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((out/'exit.json').read_text());assert r['exitCode']==0 and r['sourceUnchanged'] and r['status']=='failed_original_outputs_retained'
assert all(sha(work/n)==h for n,h in r['source'].items())
counts=[tuple(map(int,re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',s).groups())) for s in r['summaries']]
assert counts==[(43,0,1,0,0),(4,0,0,0,0),(8,0,0,0,0),(2,0,0,0,0),(7,0,0,0,0)],counts
audit=dict(status='rust_targets_passed_original_controller_receipt_assertion_failed',passed=64,failed=0,originalIgnored=1,filtered=0,reason='Controller incorrectly required zero ignored tests for the complete core unit target. Its original manual performance ignore remains unchanged. No tests were rerun, ignored, edited or reclassified. Original controller exit1 and raw receipt retained.',counts=counts,sourceUnchanged=True,limits=['Earlier PR597 CI timeout remains unresolved; no source failure phase was captured before this observation increment','No deadline, memory/stack budget, test assertion or functional return behavior changes','This is a selected core expression gate, not desktop sink/complete workspace/cross-platform acceptance'])
(out/'independent-summary-audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
entries={f'run/{p.name}':p for p in out.iterdir() if p.is_file()}
ci=root/'artifacts/pr-queue/clock85-current-ci-failure-v1/597-rust-gpu.log';entries['original-ci/597-rust-gpu.log']=ci
for name in ['run-clock85-expression-budget-trace-v1.ps1','publish-clock85-expression-budget-trace-v1.py']:
 entries['environment/'+name]=root/'.tools/issue-closure-review'/name
for name in ['runtime.rs','runtime/references.rs','runtime/budget_trace.rs']:
 entries['validated-source/'+name]=work/'crates/motion-core/src/expressions'/name
entries['validated-source/expression_preparation.rs']=work/'crates/motion-core/tests/expression_preparation.rs'
manifest=dict(audit=audit,head=r['head'],command=r['command'],source=r['source'],entries={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in entries.items()})
archive=work/'engineering/validation/data/expression-budget-trace-v1.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
 for n,p in entries.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,p in entries.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(p)
receipt=dict(audit=audit,archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members=len(entries)+1)
archive.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
doc=work/'engineering/validation/expression-budget-observations-current.md'
doc.write_text('''# Expression interruption failure phases

Status: observation increment verified on the parent clock branch. The original
PR 597 CI timeout remains unresolved; this is not a deadline or scheduling fix.

At head `644c6396`, CI job 126486711281 failed in the unchanged
`deferred_nonfinite_sampling_reports_error_without_poisoning_later_evaluation_or_history`
test while admitting a valid frame-zero expression. The generic interruption
error did not distinguish cancellation, the frame deadline, or the execution
deadline. The complete original job log is retained in the archive below.

The same error now carries the first observed phase (`context_setup`,
`bindings_and_module`, or `execution`), interruption condition, elapsed
microseconds, and frame time remaining at entry. The condition follows the
existing cancellation/frame/execution check order; elapsed wall time does not
prove CPU cost or the original CI root cause. No expression source or user text
is recorded. Formatting occurs only on failure. Existing deadlines remain
20 ms per root execution and 100 ms per frame; memory/stack ceilings,
cancellation, reference-failure precedence, return values and recovery policy
are unchanged. There is no file IO or unconditional logging in this helper.
The contextual error continues through the existing host/worker error sinks.

A real infinite expression verifies interruption details, unchanged project
state and successful later evaluation. A deterministic unit test verifies
first-phase/cause retention and exact elapsed context. All original assertions
remain unchanged. Complete core unit tests and the four selected expression
integration targets executed: **64 passed, zero failed, one original manual
performance test ignored, zero filtered**.

The Cargo process exited zero. The controller subsequently exited one because
its receipt assertion incorrectly required zero original ignores in the core
unit target. An independent audit parsed all five target summaries and checked
the frozen source hashes without rerunning any tests. Both original failure
receipt and additive audit remain in the
[archive](data/expression-budget-trace-v1.zip), with a
[hash receipt](data/expression-budget-trace-v1.json). This is not complete
desktop sink validation, full workspace regression, cross-platform acceptance
or completion of issues 85/86/88. The concurrently running full desktop/UI gate
uses its unchanged earlier child source and does not cover this increment.
''',encoding='utf-8')
print(json.dumps(receipt))
