"""Retain the complete failed command; never relabel it as a regression pass."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib, json, re, subprocess, zipfile

ROOT=Path('E:/Dev/aem'); WORK=ROOT/'.worktrees/depth-wgsl-cache75'
OUT=ROOT/'artifacts/pr-queue/depth75-qualified-runtime-binding-v1'
r=json.loads((OUT/'receipt.json').read_text(encoding='utf-8'))
assert json.loads((OUT/'session-consumed.json').read_text())==dict(session=33029,consumed=True,exit_code=1)
assert r['status']=='failed_original_outputs_retained' and r['source_unchanged']
assert len(r['stages'])==1 and r['stages'][0]['exit_code']==101
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==r['head']
def sha(raw):return hashlib.sha256(raw).hexdigest()
for name,digest in r['source_sha256'].items():assert sha((WORK/name).read_bytes())==digest,name
stdout=(OUT/'changed-crates.stdout.log').read_text(encoding='utf-8')
stderr=(OUT/'changed-crates.stderr.log').read_text(encoding='utf-8')
metadata=json.loads((OUT/'cargo-metadata.json').read_text(encoding='utf-8'))
expected=[];by_name={};docs={}
for package in metadata['packages']:
    if package['name'] not in ('motion-host','motion-render','motion-desktop-media'):continue
    for target in package['targets']:
        if not target['test']:continue
        relative=Path(target['src_path']).relative_to(WORK).as_posix()
        key=package['name']+'::'+target['kind'][0]+'::'+relative
        expected.append(key);by_name.setdefault(target['name'].replace('-','_'),[]).append((relative,key))
    if any(t['doctest'] for t in package['targets']):
        key='doc::'+package['name'];expected.append(key);docs[package['name'].replace('-','_')]=key
observed=[];bound=[]
for executable in re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)',stderr,re.M):
    path=Path(executable);raw=path.with_suffix('.d').read_bytes()
    dependencies=raw.decode('utf-8').splitlines()[0].split(': ',1)[1].replace('\\','/')
    name=re.sub(r'-[a-f0-9]+$','',path.stem)
    owners=[key for relative,key in by_name[name] if re.search(r'(?<!\S)'+re.escape(relative)+r'(?!\S)',dependencies)]
    assert len(owners)==1,(executable,owners)
    observed.extend(owners);bound.append(dict(executable=executable,target=owners[0],dep_info_sha256=sha(raw)))
observed.extend(docs[n] for n in re.findall(r'^\s*Doc-tests (\S+)\s*$',stderr,re.M))
summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
assert Counter(expected)==Counter(observed) and len(summaries)==len(observed)==175
totals=dict(passed=sum(int(s[1]) for s in summaries),failed=sum(int(s[2]) for s in summaries),
 original_ignored=sum(int(s[3]) for s in summaries),filtered=sum(int(s[5]) for s in summaries))
failure='transitions::qualified::qualified_session_changed_runtime_cannot_freeze_old_reference_or_retry_settled_backend'
assert re.findall(r'^test (\S+) \.\.\. FAILED$',stdout,re.M)==[failure]
assert totals['failed']==1 and totals['filtered']==0
assert 'called `Option::unwrap()` on a `None` value' in stdout
assert 'qualified.rs:248:10' in stdout.replace('\\','/')
names=[]
for name,prefix in [('crates/motion-host/tests/depth_capability.rs',''),
 ('crates/motion-host/tests/depth_capability/bindings.rs','bindings::'),
 ('crates/motion-host/tests/depth_session/transitions/qualified.rs','transitions::qualified::')]:
    names.extend(prefix+n for n in re.findall(r'#\[test\]\s*fn ([a-z_]+)\(', (WORK/name).read_text(encoding='utf-8')))
assert len(names)==39
for name in names:
    expected_result='FAILED' if name==failure else 'ok'
    assert len(re.findall(r'^test '+re.escape(name)+r' \.\.\. '+expected_result+r'$',stdout,re.M))==1,name
audit=dict(status='complete175_target_command_failed_new_fixture_before_settled_submission',head=r['head'],
 totals=totals,expected_targets=expected,observed_targets=observed,source_bound_invocations=bound,
 full_target_coverage=True,source_unchanged=True,
 controls_passed=[n for n in names if n!=failure],controls_failed=[failure],
 cause='First Idle400 tick starts idle_since at400; no settled request yet. The new fixture unwraps None before reaching the changed-runtime guard.',
 repair='Add initial Idle100 tick as in positive control; preserve every existing assertion, count, frozen guard, policy limit and product return value',
 actual_product_build='not run because original command failed; remains required',
 qualification='Not a complete green regression, not a failed model inference and not #75 completion',
 verified_utc=datetime.now(timezone.utc).isoformat())
(OUT/'independent-failure-audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
members={}
for name in ('controller.py','receipt.json','session-consumed.json','cargo-metadata.json',
 'changed-crates.stdout.log','changed-crates.stderr.log','independent-failure-audit.json'):
    members['native/'+name]=(OUT/name).read_bytes()
for name in ('crates/motion-host/src/depth.rs','crates/motion-host/src/depth/capability/policy.rs',
 'crates/motion-host/src/session/depth.rs','crates/motion-host/tests/depth_capability.rs',
 'crates/motion-host/tests/depth_capability/bindings.rs','crates/motion-host/tests/depth_session/transitions.rs',
 'crates/motion-host/tests/depth_session/transitions/qualified.rs','crates/motion-host/src/depth/transition.rs'):
    members['source/'+name]=(WORK/name).read_bytes()
members['archive-controller.py']=Path(__file__).read_bytes()
data=WORK/'engineering/validation/data';archive=data/'depth75-qualified-runtime-binding-failure-v1.zip'
manifest=data/'depth75-qualified-runtime-binding-failure-v1.json'
assert not archive.exists() and not manifest.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(members.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
    assert sorted(z.namelist())==sorted(members)
    for name,raw in members.items():assert z.read(name)==raw
value=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
 members=[dict(path=n,bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(members.items())],audit=audit,
 limits=['Original failed command, authored sources and bounded text only; no binaries, model weights, video, RGB or depth tensor payloads',
 'No thresholds/assertions/ignores changed, no retry and no relabeled pass',
 'External admission reports remain controlled fixtures; actual model/device qualification and issues75/88 remain open'])
manifest.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:value[k] for k in ('archive','bytes','sha256')},indent=2))
