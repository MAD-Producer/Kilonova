"""One source-frozen native workload; preserve every original failure output."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, traceback

ROOT=Path('E:/Dev/aem'); BASE=ROOT/'artifacts/pr-queue'
WORK=ROOT/'.worktrees/depth-wgsl-cache75'
TARGET=ROOT/'target/depth-wgsl-cache75-contract'
OUT=BASE/'depth75-qualified-runtime-binding-v1'
checkpoint=json.loads((BASE/'depth75-resume-current.json').read_text(encoding='utf-8-sig'))['versionedCache75']
assert checkpoint['activeController'] is None
assert shutil.disk_usage(ROOT).free>=10<<30
assert not {'RUST_MIN_STACK','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'} & os.environ.keys()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert HEAD.startswith('6d3798d9')
parent=json.loads((BASE/'depth75-measured-capability-v1/receipt.json').read_text(encoding='utf-8'))
previous=json.loads((BASE/'depth75-measured-capability-v3/receipt.json').read_text(encoding='utf-8'))

# Existing test assertions are byte-identical; only child-module declarations
# were added to the parent targets. No filtering/ignore/budget edits.
for name,addition in [
 ('crates/motion-host/tests/depth_capability.rs','\n#[path = "depth_capability/bindings.rs"]\nmod bindings;\n'),
 ('crates/motion-host/tests/depth_session/transitions.rs','#[path = "transitions/qualified.rs"]\nmod qualified;\n')]:
    original=subprocess.check_output(['git','show','b9490e06:'+name],cwd=WORK).decode('utf-8').replace('\r\n','\n')
    current=(WORK/name).read_text(encoding='utf-8')
    assert current.count(addition)==1 and current.replace(addition,'')==original, name

OUT.mkdir(exist_ok=False); (OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def hashes(): return {p:sha(WORK/p) for p in paths}
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),
 CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
 TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),LOCALAPPDATA=str(OUT/'appdata'),RUST_BACKTRACE='full')
runtime=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
env['PATH']=str(runtime)+';'+env['PATH']
report=dict(status='running',head=HEAD,source_sha256=hashes(),stages=[],
 started_utc=datetime.now(timezone.utc).isoformat(),
 limits=['One own heavy native workload; source frozen until original handle terminal and consumed',
 'Original three-crate command, GPU/FFmpeg features, assertions, ignores and deadlines unchanged',
 'External admission reports in new controls are fixtures, not real model/device qualification',
 'No Android, panel changes, foreign process inspection/stops, cache deletion or automatic fallback'])
def save():
    pending=OUT/'receipt.pending.json'; pending.write_text(json.dumps(report,indent=2),encoding='utf-8')
    os.replace(pending,OUT/'receipt.json')
def run(name,command):
    assert shutil.disk_usage(ROOT).free>=10<<30
    row=dict(name=name,command=[str(x) for x in command]);report['stages'].append(row);save()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        row['pid']=child.pid;save();row['exit_code']=child.wait()
    save();assert row['exit_code']==0,(name,'original failed outputs retained; no retry')
    return row
save()
try:
    for item in previous['runtime_colocation']: assert sha(Path(item['path']))==item['sha256']
    report['runtime_colocation']=previous['runtime_colocation'];save()
    metadata_raw=subprocess.check_output(['cargo','metadata','--locked','--offline','--no-deps','--format-version','1'],cwd=WORK,env=env)
    (OUT/'cargo-metadata.json').write_bytes(metadata_raw);metadata=json.loads(metadata_raw)
    features='motion-host/ai-depth,motion-host/gpu-tests,motion-render/gpu-tests,motion-desktop-media/ai-depth,motion-desktop-media/gpu-tests,motion-desktop-media/ffmpeg'
    run('changed-crates',['cargo','test','--locked','--offline','-p','motion-host','-p','motion-render','-p','motion-desktop-media','--features',features,'--no-fail-fast','--','--test-threads=1'])
    stdout=(OUT/'changed-crates.stdout.log').read_text(encoding='utf-8',errors='replace')
    stderr=(OUT/'changed-crates.stderr.log').read_text(encoding='utf-8',errors='replace')
    expected=[];by_name={};docs={}
    for package in metadata['packages']:
        if package['name'] not in ('motion-host','motion-render','motion-desktop-media'):continue
        for target in package['targets']:
            if not target['test']:continue
            relative=Path(target['src_path']).relative_to(WORK).as_posix()
            key=package['name']+'::'+target['kind'][0]+'::'+relative
            expected.append(key);by_name.setdefault(target['name'].replace('-','_'),[]).append((relative,key))
        if any(t['doctest'] for t in package['targets']):
            key='doc::'+package['name'];expected.append(key);docs[package['name'].replace('-','_')]=key
    observed=[];bound=[]
    for executable in re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)',stderr,re.M):
        path=Path(executable);raw=path.with_suffix('.d').read_bytes()
        dependencies=raw.decode('utf-8').splitlines()[0].split(': ',1)[1].replace('\\','/')
        name=re.sub(r'-[a-f0-9]+$','',path.stem)
        owners=[key for relative,key in by_name[name] if re.search(r'(?<!\S)'+re.escape(relative)+r'(?!\S)',dependencies)]
        assert len(owners)==1,(executable,owners)
        observed.extend(owners);bound.append(dict(executable=executable,target=owners[0],dep_info_sha256=hashlib.sha256(raw).hexdigest()))
    observed.extend(docs[n] for n in re.findall(r'^\s*Doc-tests (\S+)\s*$',stderr,re.M))
    summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
    new=[]
    for name,prefix in [('crates/motion-host/tests/depth_capability/bindings.rs','bindings::'),
                        ('crates/motion-host/tests/depth_session/transitions/qualified.rs','transitions::qualified::')]:
        new.extend(prefix+n for n in re.findall(r'#\[test\]\s*fn ([a-z_]+)\(', (WORK/name).read_text(encoding='utf-8')))
    assert len(new)==11
    named=parent['qualified_named_controls']+new
    for n in named:assert len(re.findall(r'^test '+re.escape(n)+r' \.\.\. ok$',stdout,re.M))==1,n
    report.update(expected_targets=expected,observed_targets=observed,source_bound_invocations=bound,
      full_target_coverage=Counter(expected)==Counter(observed) and len(summaries)==len(observed),
      qualified_named_controls=named,new_binding_controls=new,
      totals=dict(passed=sum(int(s[1]) for s in summaries),failed=sum(int(s[2]) for s in summaries),
      original_ignored=sum(int(s[3]) for s in summaries),filtered=sum(int(s[5]) for s in summaries)))
    save()
    assert report['full_target_coverage'] and not report['totals']['failed'] and not report['totals']['filtered']
    assert "process didn't exit successfully:" not in stderr
    run('actual-product-build',['cargo','build','--locked','--offline','-p','motion-host','-p','motion-desktop','-p','motion-desktop-media',
      '--example','depth_capability','--example','depth_video_capability','--bin','motion-depth-wgsl',
      '--features','motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth'])
    report['status']='native_changed_crates_and_actual_product_build_passed'
except BaseException:
    report['status']='failed_original_outputs_retained';report['cause']=traceback.format_exc();save();raise
finally:
    report['source_unchanged']=hashes()==report['source_sha256']
    report['finished_utc']=datetime.now(timezone.utc).isoformat();save()
    assert report['source_unchanged'],'frozen source changed during native qualification'
