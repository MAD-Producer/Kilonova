from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, shutil
root=Path('E:/Dev/aem');work=root/'.worktrees/calibrated-depth-mattes'
broad=root/'artifacts/pr-queue/calibrated-material-regression-v1'
accepted=json.loads((broad/'accepted.json').read_text(encoding='utf-8'))
assert accepted['sourceUnchanged'] and all(s['exitCode']==0 and s['sourceUnchanged'] for s in accepted['steps'])
def git(*args):return subprocess.check_output(['git',*args],cwd=work).decode().strip()
def sources():
 paths=git('ls-files','--cached','--others','--exclude-standard','-z').split('\0')
 return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml')) or p=='Cargo.lock')}
assert sources()==accepted['source']
out=root/'artifacts/pr-queue/calibrated-material-camera-v1';out.mkdir(exist_ok=False)
fixture='crates/motion-render/tests/depth_surface/calibrated_materials.rs'
p=work/fixture
shutil.copyfile(p,out/'fixture-before.rs')
s=p.read_text(encoding='utf-8');needle='        for tinted in [false, true] {\n'
assert s.count(needle)==1
s=s.replace(needle,needle+'            p.camera.position.set_at(0, [48., 32., -100.]).unwrap();\n')
p.write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(p,out/'fixture-after.rs')
source=sources();changed=[p for p in set(source)|set(accepted['source']) if source.get(p)!=accepted['source'].get(p)]
assert changed==[fixture],changed
report=dict(head=git('rev-parse','HEAD'),main=git('rev-parse','origin/main'),source=source,steps=[],broaderReceipt=str(broad/'accepted.json'),equivalence=dict(changedFiles=changed,productionAndConfigurationUnchanged=True,reason='Reset camera before every new Tint/Invert fixture case, preserving all independent expected values, pixel tolerances and assertions; focused tests overlap broader gate'))
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='1',MOTION_DEPTH_ACCEPTANCE_DIR=str(out/'native-renders'));env.pop('MOTION_LOG',None)
for name,command,count in [('native',['cargo','test','-p','motion-render','--test','depth_surface','calibrated_material','--locked','--offline','--','--test-threads=1'],6),('proof',['cargo','test','-p','motion-render','--lib','depth_material','--locked','--offline','--','--test-threads=1'],2)]:
 print(json.dumps(dict(start=name)),flush=True)
 with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
  code=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
 counts=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',(out/f'{name}.stdout.log').read_text(encoding='utf-8'))
 row=dict(name=name,command=command,exitCode=code,counts=counts,sourceUnchanged=sources()==source)
 report['steps'].append(row);(out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(row),flush=True)
 assert code==0 and row['sourceUnchanged'] and counts==[(str(count),'0','0')],row
report.update(sourceUnchanged=sources()==source,focusedPassed=8,distinctBroaderPassed=accepted['distinctPassed'],additionalUniqueTests=0,completedUtc=datetime.now(timezone.utc).isoformat())
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
