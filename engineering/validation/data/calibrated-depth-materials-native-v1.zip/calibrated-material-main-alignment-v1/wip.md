wip(render): 暂存标定逐像素材质以对齐主分支
