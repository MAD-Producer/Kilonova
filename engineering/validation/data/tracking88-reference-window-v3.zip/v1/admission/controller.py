from pathlib import Path
import subprocess,json,os,sys,hashlib
r=Path('E:/Dev/aem');s=r/'.worktrees/planar-tracker88';o=r/'artifacts/pr-queue/tracking88-reference-window-admission-v1';o.mkdir(exist_ok=False);env=os.environ.copy();env.update(TEMP=str(o),TMP=str(o),PYTHONDONTWRITEBYTECODE='1');rows=[]
for label,pat,directory in [('plate','test_ci_plate_tracking.py','tools'),('calibration','test_ci_tracking_calibration.py','tools'),('diagnostics','test_plane_diagnostics.py','tools/tracking')]:
 cmd=[sys.executable,'-B','-m','unittest','discover','-s',directory,'-p',pat,'-v'];row=dict(label=label,command=cmd);rows.append(row)
 with (o/(label+'.stdout.log')).open('xb') as a,(o/(label+'.stderr.log')).open('xb') as b:
  c=subprocess.Popen(cmd,cwd=s,env=env,stdout=a,stderr=b);row['pid']=c.pid;(o/'receipt.json').write_text(json.dumps(rows,indent=2));row['exit_code']=c.wait()
 (o/'receipt.json').write_text(json.dumps(rows,indent=2));print(label,row['exit_code']);print((o/(label+'.stderr.log')).read_text(errors='replace')[-1400:])
 if row['exit_code']:raise SystemExit(row['exit_code'])
