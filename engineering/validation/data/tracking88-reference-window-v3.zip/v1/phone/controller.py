from pathlib import Path
import subprocess,os,sys,json,hashlib,datetime,zipfile,traceback,math
R=Path('E:/Dev/aem');S=R/'.worktrees/planar-tracker88';A=R/'artifacts/pr-queue';D=A/'tracking88-real-planar-acquisition-v1';B=A/'tracking88-photographed-prototype-v6';O=A/'tracking88-reference-window-phone-v1';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=['tools/tracking/plate_flow.py','tools/tracking/plate_contract.py','tools/tracking/track_plate.py'];frozen={n:sha(S/n) for n in files};source=D/'phone.avi';truth=D/'phone-gt.zip'
assert sha(source)=='c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
assert sha(truth)=='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
report=dict(status='running',scope='One fixed full-resolution reference-window geometric candidate; original phone2300 and two modes; no gate or annotation selection changes',protocol=dict(frames=2300,modes=['no-corrections','periodic-manual-200'],maximum_corner_error_pixels=15,labels='Only frozen initial/scheduled-manual requests before sealed blind outputs; all quality labels read afterwards',limit='Adjacent pyramidal LK support is not certified by full-resolution reference mask'),source_hashes=frozen,input_hash=sha(source),annotation_hash=sha(truth),runs=[])
def save():
 with (O/'receipt.json').open('w',encoding='utf-8') as f:json.dump(report,f,indent=2);f.flush();os.fsync(f.fileno())
def phase(s):
 report['phase']=s;save()
 with (O/'phases.log').open('a') as f:f.write('INFO start '+s+'\n');f.flush();os.fsync(f.fileno())
save();env=os.environ.copy();env.update(TEMP=str(O),TMP=str(O),PYTHONDONTWRITEBYTECODE='1');ff=R/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
try:
 for mode in report['protocol']['modes']:
  request=B/(mode+'.request.json');config=O/(mode+'.request.json');config.write_bytes(request.read_bytes());j=json.loads(config.read_text());assert j['source_sha256']==report['input_hash'];assert next(t for t in j['tracks'] if t['kind']=='plane')['roi']==[160.,180.,340.,210.]
  phase(mode+'_original_complete_video');cmd=[sys.executable,'-B',str(S/'tools/tracking/track_plate.py'),'--source',str(source),'--request',str(config),'--output',str(O/mode),'--ffmpeg',str(ff),'--ffprobe',str(ff.with_name('ffprobe.exe'))]
  row=dict(mode=mode,request_sha256=sha(config),command=cmd);report['runs'].append(row);save()
  with (O/(mode+'.stdout.log')).open('xb') as a,(O/(mode+'.stderr.log')).open('xb') as b:
   child=subprocess.Popen(cmd,cwd=S,env=env,stdout=a,stderr=b);row['pid']=child.pid;save();row['exit_code']=child.wait()
  save();assert row['exit_code']==0,mode;assert (O/(mode+'.stdout.log')).stat().st_size==0
  asset=O/mode/'tracks.mstrack';row['blind_sha256']=sha(asset);save()
 phase('both_blind_outputs_sealed_then_score_all_original_labels')
 import numpy as np
 with zipfile.ZipFile(truth) as z:
  names=[f'img_{i:05d}.txt' for i in range(200,2500)];assert sorted(n for n in z.namelist() if not n.endswith('/'))==names
  corners=[]
  for name in names:
   a=np.array([float(v) for v in z.read(name).decode('ascii').split()]).reshape(2,4);corners.append(np.column_stack((a[1]-1,a[0]-1)))
  corners=np.array(corners)
 for row in report['runs']:
  asset=O/row['mode']/'tracks.mstrack';assert sha(asset)==row['blind_sha256'];j=json.loads(asset.read_text());assert j['source_pts']==list(range(2300)) and j['ticks_per_second']==100;row['metrics']=[]
  for track in j['tracks']:
   errors=[];lost=[];manual=0;points=[]
   for i,sample in enumerate(track['samples']):
    assert sample['source_index']==i
    if sample['manual_correction']:manual+=1;continue
    if i==0:continue
    if sample['visibility']!='visible':lost.append(i);continue
    ob=sample['observation']
    if track['kind']=='point':e=float(np.linalg.norm(np.array(ob['pixels'])-corners[i,0]))
    else:
     h=np.column_stack((corners[0],np.ones(4)))@np.array(ob['matrix']).T;assert np.isfinite(h).all() and np.all(abs(h[:,2])>1e-10);e=float(np.linalg.norm(h[:,:2]/h[:,2:]-corners[i],axis=1).max())
    assert math.isfinite(e);errors.append(e);points.append(dict(index=i,error=e))
   row['metrics'].append(dict(track=track['id'],automatic_visible=len(errors),automatic_lost=len(lost),manual=manual,first_lost=lost[0] if lost else None,over_15=sum(e>15 for e in errors),maximum=max(errors) if errors else None,rms=math.sqrt(sum(e*e for e in errors)/len(errors)) if errors else None))
   (O/(row['mode']+'-'+track['id']+'-errors.json')).write_text(json.dumps(points))
 report['source_unchanged']=all(sha(S/n)==h for n,h in frozen.items());assert report['source_unchanged'];report['status']='complete_original_two_mode_measurement_not_complete_tracker_qualification'
except BaseException:
 report.update(status='failed',cause=traceback.format_exc());raise
finally:
 report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({k:report.get(k) for k in ('status','cause')}))
