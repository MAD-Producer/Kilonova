from pathlib import Path
import subprocess,os,sys,json,hashlib,zipfile,math,datetime,traceback
R=Path('E:/Dev/aem');S=R/'.worktrees/planar-tracker88';A=R/'artifacts/pr-queue';B=A/'tracking88-mousepad-full-core-v1';D=A/'tracking88-real-planar-acquisition-v1';O=A/'tracking88-reference-window-mousepad-v2';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();driver=A/'tracking88-mousepad-full-core-v1-controller.py'
frozen={n:sha(S/n) for n in ['tools/tracking/plate_flow.py','tools/tracking/plate_contract.py','tools/tracking/track_plate.py']};source=D/'mouse-pad.avi';truth=D/'mouse-pad-gt.zip';assert sha(source)=='f7cfe7d11fb64111777b6074a21bc58de7fc500ebce15f26577ee0ba2c4f890f';assert sha(truth)=='532e0091d649f26d2158261ce1b42e4775fc91bb73c3502d23ed9744b67dba7a'
report=dict(status='running',scope='Original6946-frame core-only diagnostic, not a waiver of4096-frame prototype/native limit',bounds=dict(maximum_corner_error_pixels=15),source_hashes=frozen,driver_sha256=sha(driver),input_sha256=sha(source),annotation_sha256=sha(truth),runs=[])
def save():
 with (O/'receipt.json').open('w') as f:json.dump(report,f,indent=2);f.flush();os.fsync(f.fileno())
env=os.environ.copy();env.update(TEMP=str(O),TMP=str(O),PYTHONDONTWRITEBYTECODE='1');save()
try:
 for mode in ['no-corrections','periodic-manual-200']:
  request=B/(mode+'.request.json');config=O/(mode+'.request.json');config.write_bytes(request.read_bytes());j=json.loads(config.read_text());assert j['diagnostic_frame_count']==6946 and j['source_sha256']==report['input_sha256']
  cmd=[sys.executable,'-B',str(driver),'--core',str(config),str(O/mode)];row=dict(mode=mode,command=cmd,request_sha256=sha(config));report['runs'].append(row);save()
  with (O/(mode+'.stdout.log')).open('xb') as a,(O/(mode+'.stderr.log')).open('xb') as b:
   c=subprocess.Popen(cmd,cwd=S,env=env,stdout=a,stderr=b);row['pid']=c.pid;save();row['exit_code']=c.wait()
  save();assert row['exit_code']==0 and (O/(mode+'.stdout.log')).stat().st_size==0;row['blind_sha256']=sha(O/mode/'observations.jsonl');save()
 import numpy as np
 with zipfile.ZipFile(truth) as z:
  names=[f'img_{i:05d}.txt' for i in range(100,7046)];assert sorted(n for n in z.namelist() if not n.endswith('/'))==names;corners=[]
  for n in names:
   v=np.array([float(x) for x in z.read(n).decode('ascii').split()]).reshape(2,4);corners.append(np.column_stack((v[1]-1,v[0]-1)))
  corners=np.array(corners)
 for run in report['runs']:
  blind=O/run['mode']/'observations.jsonl';assert sha(blind)==run['blind_sha256'];rows=[json.loads(l) for l in blind.read_text().splitlines()];assert len(rows)==6946
  metrics={t:dict(errors=[],lost=[],manual=0) for t in ['feature','plane']}
  for i,row in enumerate(rows):
   assert row['source_index']==i
   for t in row['tracks']:
    m=metrics[t['id']]
    if t['manual']:m['manual']+=1;continue
    if i==0:continue
    if t['visibility']!='visible':m['lost'].append(i);continue
    if t['kind']=='point':e=float(np.linalg.norm(np.array(t['observation']['pixels'])-corners[i,0]))
    else:
     h=np.column_stack((corners[0],np.ones(4)))@np.array(t['observation']['matrix']).T;e=float(np.linalg.norm(h[:,:2]/h[:,2:]-corners[i],axis=1).max())
    assert math.isfinite(e);m['errors'].append(e)
  run['metrics']=[dict(track=t,automatic_visible=len(m['errors']),automatic_lost=len(m['lost']),manual=m['manual'],first_lost=m['lost'][0] if m['lost'] else None,over_15=sum(e>15 for e in m['errors']),maximum=max(m['errors']) if m['errors'] else None,rms=math.sqrt(sum(e*e for e in m['errors'])/len(m['errors'])) if m['errors'] else None) for t,m in metrics.items()]
 report['source_unchanged']=all(sha(S/n)==h for n,h in frozen.items());assert report['source_unchanged'];report['status']='full_two_mode_core_diagnostic_complete_not_native_or_quality_qualification'
except BaseException:
 report.update(status='failed',cause=traceback.format_exc());raise
finally:
 report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps({k:report.get(k) for k in ['status','cause']}))
