from pathlib import Path
import subprocess,json,os,hashlib,datetime
r=Path('E:/Dev/aem');s=r/'.worktrees/planar-tracker88';o=r/'artifacts/pr-queue/tracking88-reference-window-controls-v3';o.mkdir(exist_ok=False)
files=['tools/tracking/plate_flow.py','tools/tracking/test_flow.py'];hashes={n:hashlib.sha256((s/n).read_bytes()).hexdigest() for n in files}
env=os.environ.copy();env.update(TEMP=str(o),TMP=str(o),PYTHONDONTWRITEBYTECODE='1')
cmd=[str(r/'.tools/depth75-metric-export-v1/venv/Scripts/python.exe'),'-B','-m','unittest','discover','-s','tools/tracking','-p','test_flow.py','-v']
report=dict(status='running',command=cmd,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),source_hashes=hashes)
(o/'receipt.json').write_text(json.dumps(report,indent=2))
with (o/'stdout.log').open('xb') as a,(o/'stderr.log').open('xb') as b:
 child=subprocess.Popen(cmd,cwd=s,env=env,stdout=a,stderr=b);report['pid']=child.pid;(o/'receipt.json').write_text(json.dumps(report,indent=2));report['exit_code']=child.wait()
report.update(status='controls_passed' if report['exit_code']==0 else 'controls_failed',source_unchanged=all(hashlib.sha256((s/n).read_bytes()).hexdigest()==h for n,h in hashes.items()),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(o/'receipt.json').write_text(json.dumps(report,indent=2));print(json.dumps(report));print((o/'stderr.log').read_text(errors='replace'))
