"""Sequential native validation. Refuses to run before original regression consumption."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
import os
import re
import shutil
import struct
import subprocess
import time
import traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/depth-retained-context75'
ART = ROOT / 'artifacts/pr-queue'
OUT = ART / 'depth75-retained-context-v1'
BASE = 'ad799f2f634b5a3897c7df2e06053216db9e86a4'
PROGRAM = ART / 'depth75-wgsl-cache-resources-v2/program.json'
PROGRAM_SHA = '2ec1d8012905198cfd5af1430f88d1770edbf752531fe817dfcc65e1477fef6a'
TARGET = ROOT / 'target/depth-wgsl-cache75-contract'
PYTHON = ROOT / '.tools/ai-depth74/venv/Scripts/python.exe'
EXE = TARGET / 'debug/motion-depth-wgsl.exe'
FFMPEG = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
CHANGED = {
    'desktop/app/Cargo.toml',
    'desktop/app/src/depth_worker/graph_runtime_impl.rs',
    'desktop/app/src/depth_worker/main.rs',
    'desktop/app/src/depth_worker/batch_admission.rs',
    'desktop/app/src/depth_worker/tests/batch_admission.rs',
    'engineering/validation/depth75-retained-context-protocol.md',
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK, text=True).strip()

def source():
    assert git('rev-parse', 'HEAD') == BASE
    changed = set(git('diff', '--name-only').splitlines())
    changed.update(git('ls-files', '--others', '--exclude-standard').splitlines())
    assert changed == CHANGED, changed
    return {name: sha(WORK / name) for name in sorted(CHANGED)}

def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')

# Fail before creating an output/build directory if the original handle is live.
consumed_path = ART / 'depth75-memory-current-workspace-v1/session-consumed.json'
consumed = json.loads(consumed_path.read_text())
assert consumed['session'] == 87729 and consumed['consumed'] is True
baseline = json.loads((consumed_path.parent / 'receipt.json').read_text())
assert baseline.get('completed_utc') and baseline.get('source_unchanged') is True
assert baseline['head'] == BASE
assert shutil.disk_usage(ROOT).free >= 10 << 30
bindings = source()
assert sha(PROGRAM) == PROGRAM_SHA
OUT.mkdir(exist_ok=False)
shutil.copyfile(Path(__file__), OUT / 'controller.py')
env = os.environ.copy()
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
    CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    TEMP=str(TARGET / 'tmp'), TMP=str(TARGET / 'tmp'),
    LOCALAPPDATA=str(OUT / 'appdata'), PYTHONDONTWRITEBYTECODE='1',
    LIBCLANG_PATH=str(ROOT / '.tools/python-libclang/clang/native'),
    FFMPEG_DIR=str(FFMPEG), FFMPEG_INCLUDE_DIR=str(FFMPEG / 'include'),
    FFMPEG_LIB_DIR=str(FFMPEG / 'lib'), RUST_BACKTRACE='full')
env['PATH'] = str(FFMPEG / 'bin') + os.pathsep + env['PATH']
env.pop('MOTION_LOG', None)
Path(env['TEMP']).mkdir(exist_ok=True, parents=True)
Path(env['LOCALAPPDATA']).mkdir()
report = dict(status='running', source_head=BASE, changed_source_sha256=bindings,
    controller_sha256=sha(OUT / 'controller.py'),
    original_regression_status=baseline['status'],
    original_regression_exit_code=baseline.get('exit_code'),
    original_consumed_receipt_sha256=sha(consumed_path),
    started_utc=datetime.now(timezone.utc).isoformat(), commands=[],
    limits=['One owned heavy workload', 'Original 60-second native-child allowance',
        'No Android, panels, downloads, retries or threshold changes',
        'Finite research context is not automatic application backend selection',
        'Queried self-process peaks are cumulative, incomplete lifetime observations'])
began = time.monotonic()

def save():
    write(OUT / 'receipt.json', report)

def command(label, args, expected=0, timeout=None, observe=None):
    record = dict(label=label, args=[str(arg) for arg in args],
        expected_exit=expected, timeout_seconds=timeout,
        started_utc=datetime.now(timezone.utc).isoformat())
    report['commands'].append(record)
    save()
    start = time.monotonic()
    with (OUT / (label + '.stdout.log')).open('wb') as stdout, (OUT / (label + '.stderr.log')).open('wb') as stderr:
        child = subprocess.Popen(args, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        record['pid'] = child.pid
        save()
        try:
            deadline = None if timeout is None else start + timeout
            if observe:
                observe(child, deadline)
            remaining = None if deadline is None else max(0, deadline - time.monotonic())
            record['exit_code'] = child.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            # Only this directly owned comparison child is terminated/reaped.
            # The failed original allowance is retained, never retried.
            child.kill()
            child.wait()
            record.update(timed_out=True, exit_code=child.returncode)
            raise
        except BaseException:
            record['controller_failure'] = traceback.format_exc()
            if child.poll() is None:
                child.kill()
            child.wait()
            record['exit_code'] = child.returncode
            raise
        finally:
            record['elapsed_seconds'] = time.monotonic() - start
            for stream in ('stdout', 'stderr'):
                record[stream + '_sha256'] = sha(OUT / (label + '.' + stream + '.log'))
            save()
    assert record['exit_code'] == expected, record
    return record

def native(label, manifest, batch=False, expected=0, completed=0, observe=None):
    path = OUT / (label + '.json')
    if isinstance(manifest, bytes):
        path.write_bytes(manifest)
    else:
        write(path, manifest)
    output = OUT / label
    args = [EXE]
    if batch:
        args.append('--research-batch')
    args.extend([path, output])
    record = command(label, args, expected, 60, observe)
    assert (OUT / (label + '.stdout.log')).stat().st_size == 0
    result = json.loads((output / 'receipt.json').read_text())
    log = (output / 'logs/motion-studio.log').read_text()
    assert 'start #0' in log
    if expected:
        assert result['status'] == 'failed_original_cause_retained'
        assert result['failure'] in log
        assert result['failure'] in (OUT / (label + '.stderr.log')).read_text()
        failure_lines = [line for line in log.splitlines()
            if 'composed GPU research failed request=' in line]
        assert len(failure_lines) == 1
        assert all(field in failure_lines[0]
            for field in ('operation=', 'phase=', 'input_index=', 'elapsed_ms=', 'cause='))
        assert result.get('completed_inputs', 0) == completed
    return result, output, record

def output(path, receipt):
    raw = (path / 'relative_inverse_depth.f32').read_bytes()
    assert len(raw) == 518 * 518 * 4 == receipt['output_bytes']
    assert all(math.isfinite(value[0]) for value in struct.iter_unpack('<f', raw))
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == receipt['output_sha256']
    assert receipt['actual_retained_buffer_capacity_bytes'] == 227968156
    assert receipt['encoded_operations'] == 429 and receipt['final_readbacks'] == 1
    return digest


def pre_gpu_rejection(receipt, path):
    assert receipt['encoded_operations'] == 0
    assert 'adapter' not in receipt and 'context_preparations' not in receipt
    assert receipt.get('completed_inputs', 0) == 0
    log = (path / 'logs/motion-studio.log').read_text()
    assert 'request_explicit_hardware_adapter' not in log
    assert 'allocate_fixed_pool_and_upload_resources' not in log
    assert not (path / 'relative_inverse_depth.f32').exists()

try:
    save()
    features = 'motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth'
    command('admission-tests', ['cargo', 'test', '-p', 'motion-desktop', '--features', features,
        '--test', 'depth-worker-batch-admission', '--test', 'depth-worker-admission',
        '--test', 'depth-worker-convolution-admission', '--test', 'depth-worker-index-admission',
        '--test', 'depth-worker-graph-admission', '--test', 'depth-worker-panic',
        '--locked', '--offline', '--', '--test-threads=1'])
    command('build', ['cargo', 'build', '-p', 'motion-desktop', '--bin', 'motion-depth-wgsl',
        '--features', features, '--locked', '--offline'])
    report['binary_sha256'] = sha(EXE)
    inputs = json.loads((ART / 'depth75-reference-inputs-v1/inputs.json').read_text())
    tensors = []
    for index in range(2):
        directory = OUT / ('prepare-' + str(index))
        directory.mkdir()
        original = ART / 'depth75-reference-inputs-v1' / inputs[index]['rgb_input']['filename']
        assert sha(original) == inputs[index]['rgb_input']['sha256']
        assert original.stat().st_size == 640 * 480 * 3
        shutil.copyfile(original, directory / 'input.rgb')
        for name in ('depth_tensor.py', 'ai_depth_onnx.py'):
            shutil.copyfile(WORK / 'tools' / name, directory / name)
        shared_source = (directory / 'ai_depth_onnx.py').read_text()
        # Read the authored literal without importing native numerical libraries
        # in this controller. The separately owned transform uses the real code.
        import ast
        module = ast.parse(shared_source)
        processing = next(ast.literal_eval(node.value) for node in module.body
            if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'PROCESSING' for target in node.targets))
        write(directory / 'transform.json', dict(schema=1, stage='prepare', processing=processing,
            width=640, height=480, rgb_sha256=sha(original), depth_sha256=None))
        command('prepare-' + str(index), [PYTHON, '-I', '-B', '-c',
            "import runpy,sys; root=sys.argv.pop(1); sys.path.insert(0,root); sys.argv[0]=root+'/depth_tensor.py'; runpy.run_path(sys.argv[0],run_name='__main__')",
            directory, directory], timeout=60)
        prepared = json.loads((OUT / ('prepare-' + str(index) + '.stdout.log')).read_text())
        tensor = OUT / ('tensor-' + str(index) + '.f32')
        shutil.copyfile(directory / 'tensor.f32', tensor)
        assert sha(tensor) == prepared['output_sha256']
        tensors.append(dict(name='rgb', dtype='float32', shape=[1, 3, 518, 518],
            file=tensor.name, sha256=sha(tensor)))
    assert tensors[0]['sha256'] != tensors[1]['sha256']
    report['prepared_tensors'] = tensors
    common = dict(version=1, program=str(PROGRAM), program_sha256=PROGRAM_SHA,
        requested_backend='vulkan')
    old_root = ART / 'depth75-sustained-reference-v1/cohort-00'
    old_measurements = json.loads((old_root / 'measurements.json').read_text())
    assert old_measurements['status'] == 'completed'
    report['prior_cold_reference_measurements_sha256'] = sha(old_root / 'measurements.json')
    cold = []
    for index in range(2):
        result, path, record = native('cold-' + str(index), dict(common, input=tensors[index]))
        digest = output(path, result)
        original = old_measurements['samples'][index]
        assert original['index'] == index and original['input']['rgb_size'] == [640, 480]
        assert original['key']['source']['pts']['ticks'] == inputs[index]['rgb_ns']
        assert bytes(original['key']['model']['sha256']).hex() == result['model_sha256']
        assert original['execution']['provider'] == 'WGSL:Vulkan:' + result['adapter']['name']
        remap = OUT / ('remap-' + str(index))
        remap.mkdir()
        for name in ('depth_tensor.py', 'ai_depth_onnx.py'):
            shutil.copyfile(WORK / 'tools' / name, remap / name)
        shutil.copyfile(path / 'relative_inverse_depth.f32', remap / 'depth518.f32')
        write(remap / 'transform.json', dict(schema=1, stage='remap', processing=processing,
            width=640, height=480, rgb_sha256=inputs[index]['rgb_input']['sha256'],
            depth_sha256=digest))
        command('remap-' + str(index), [PYTHON, '-I', '-B', '-c',
            "import runpy,sys; root=sys.argv.pop(1); sys.path.insert(0,root); sys.argv[0]=root+'/depth_tensor.py'; runpy.run_path(sys.argv[0],run_name='__main__')",
            remap, remap], timeout=60)
        old_output = old_root / original['output']['filename']
        assert old_output.stat().st_size == original['output']['bytes'] == 640 * 480 * 4
        assert sha(old_output) == original['output']['sha256'] == sha(remap / 'output.f32')
        cold.append(dict(digest=digest, whole_seconds=record['elapsed_seconds'], receipt=result,
            prior_product_output_sha256=sha(old_output), remapped_output_sha256=sha(remap / 'output.f32')))
    report['cold_before_after_exact_equivalence'] = True
    assert cold[0]['digest'] != cold[1]['digest'], 'Distinct captured inputs produced identical cold outputs'
    result, path, record = native('retained-aba', dict(common, inputs=[tensors[0], tensors[1], tensors[0]]), True)
    assert result['context_preparations'] == 1 and result['completed_inputs'] == result['requested_inputs'] == 3
    assert result['product_cache_eligibility'] is False and result['research_batch'] is True
    batch_log = (path / 'logs/motion-studio.log').read_text()
    entries = re.findall(r'compile_graph_pipeline operation=(\S+)', batch_log)
    assert len(entries) == len(set(entries)) > 0
    assert batch_log.count(' upload_model_resource name=') == 282
    for index in range(2):
        cold_log = (OUT / ('cold-' + str(index)) / 'logs/motion-studio.log').read_text()
        assert cold_log.count(' upload_model_resource name=') == 282
        assert re.findall(r'compile_graph_pipeline operation=(\S+)', cold_log) == entries
    report['retained_setup_observations'] = dict(resource_upload_starts=282,
        distinct_pipeline_entries=entries, context_preparations=result['context_preparations'])
    frames = []
    for index, original in enumerate((0, 1, 0)):
        directory = path / f'input-{index:02}'
        frame = json.loads((directory / 'receipt.json').read_text())
        assert output(directory, frame) == cold[original]['digest']
        assert frame['pid'] == result['pid'] and frame['reused_context'] == (index > 0)
        frames.append(frame)
    report.update(cold=cold, retained=dict(whole_seconds=record['elapsed_seconds'], receipt=result, frames=frames),
        exact_aba_cold_equivalence=True)
    mutable_b = OUT / 'owned-mutable-b.f32'
    shutil.copyfile(OUT / tensors[1]['file'], mutable_b)
    def invalidate_second_input(child, deadline):
        receipt = OUT / 'reject-after-one/input-00/receipt.json'
        parse_failures = 0
        while time.monotonic() < deadline:
            if child.poll() is not None:
                raise AssertionError('Control child exited before the declared input-0 phase')
            if receipt.exists():
                try:
                    current = json.loads(receipt.read_text())
                except json.JSONDecodeError:
                    # Receipt writes may be observed in progress, for this
                    # directly owned child's fixed file only. Keep the count.
                    parse_failures += 1
                else:
                    if current.get('phase') in (
                        'upload_current_input_to_retained_pool',
                        'encode_separate_ordered_compute_passes',
                        'submit_complete_model_and_wait_final_readback',
                    ):
                        assert current['input_index'] == 0 and current['pid'] == child.pid
                        before = sha(mutable_b)
                        with mutable_b.open('r+b') as stream:
                            first = stream.read(1)
                            stream.seek(0)
                            stream.write(bytes([first[0] ^ 1]))
                        report['owned_input_mutation'] = dict(before_sha256=before,
                            after_sha256=sha(mutable_b), observed_phase=current['phase'],
                            child_pid=child.pid, partial_receipt_reads=parse_failures,
                            utc=datetime.now(timezone.utc).isoformat())
                        save()
                        return
            time.sleep(0.02)
        raise AssertionError('Original 60-second allowance elapsed before declared mutation phase')
    rejected, path, _ = native('reject-after-one', dict(common,
        inputs=[tensors[0], dict(tensors[1], file=mutable_b.name)]), True, 1, 1,
        invalidate_second_input)
    assert rejected['input_index'] == 1 and 'tensor length or SHA-256 mismatch' in rejected['failure']
    first = json.loads((path / 'input-00/receipt.json').read_text())
    assert output(path / 'input-00', first) == cold[0]['digest']
    assert not (path / 'input-01/relative_inverse_depth.f32').exists()
    report['failure_after_one_completed_input_preserves_first_output'] = True
    malformed, path, _ = native('reject-malformed-json', b'{', True, 1)
    pre_gpu_rejection(malformed, path)
    oversized, path, _ = native('reject-oversized-manifest', b' ' * (128 * 1024 + 1), True, 1)
    pre_gpu_rejection(oversized, path)
    for label, changes in (
        ('empty', {'inputs': []}),
        ('too-many', {'inputs': [tensors[0]] * 33}),
        ('wrong-version', {'version': 2}),
        ('wrong-program', {'program_sha256': '0' * 64}),
        ('implicit-backend', {'requested_backend': 'auto'}),
        ('wrong-shape', {'inputs': [dict(tensors[0], shape=[1, 3, 266, 266])]}),
        ('wrong-dtype', {'inputs': [dict(tensors[0], dtype='uint8')]}),
        ('unknown-field', {'ignore_failure': True}),
        ('wrong-digest', {'inputs': [dict(tensors[0], sha256='0' * 64)]}),
        ('path-escape', {'inputs': [dict(tensors[0], file='../tensor-0.f32')]}),
    ):
        rejected, path, _ = native('reject-' + label, dict(common, inputs=[tensors[0]]) | changes, True, 1)
        pre_gpu_rejection(rejected, path)
    report['status'] = 'finite_context_equivalence_and_declared_rejections_passed'
except BaseException:
    report.update(status='failed_original_outputs_retained', cause=traceback.format_exc())
finally:
    try:
        report['source_unchanged'] = source() == bindings
    except BaseException:
        report['source_unchanged'] = False
        report['source_verification_failure'] = traceback.format_exc()
    report.update(completed_utc=datetime.now(timezone.utc).isoformat(),
        elapsed_seconds=time.monotonic() - began)
    save()
print(json.dumps({key: report.get(key) for key in ('status', 'cause', 'exact_aba_cold_equivalence', 'source_unchanged')}))
raise SystemExit(0 if report['status'] == 'finite_context_equivalence_and_declared_rejections_passed' and report['source_unchanged'] else 1)
