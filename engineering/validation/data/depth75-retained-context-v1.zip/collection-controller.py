"""Consume and archive actual finite context evidence; no inference or test rerun."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

root = Path('E:/Dev/aem')
art = root / 'artifacts/pr-queue'
source = art / 'depth75-retained-context-v1'
work = root / '.worktrees/depth-retained-context75'
out = art / 'depth75-retained-context-public-v1'
receipt = json.loads((source / 'receipt.json').read_text())
assert receipt['status'] == 'finite_context_equivalence_and_declared_rejections_passed'
assert receipt['source_unchanged'] is True
assert receipt['exact_aba_cold_equivalence'] is True
assert receipt['cold_before_after_exact_equivalence'] is True
assert receipt['failure_after_one_completed_input_preserves_first_output'] is True
assert len(receipt['commands']) == 22
assert all(item['exit_code'] == item['expected_exit'] for item in receipt['commands'])
assert len([item for item in receipt['commands'] if item['expected_exit'] == 1]) == 13
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip() == receipt['source_head']
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for name, digest in receipt['changed_source_sha256'].items():
    assert sha(work / name) == digest
assert sha(source / 'controller.py') == receipt['controller_sha256']
assert sha(root / 'target/depth-wgsl-cache75-contract/debug/motion-depth-wgsl.exe') == receipt['binary_sha256']
tests = (source / 'admission-tests.stdout.log').read_text()
summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;', tests, re.M)
assert len(summaries) == 6
assert all(int(failed) == int(ignored) == int(filtered) == 0 for _, failed, ignored, filtered in summaries)
test_passes = sum(int(passed) for passed, _, _, _ in summaries)
marker = source / 'session-consumed.json'
assert not marker.exists()
consumed = dict(session=43396, consumed=True, exit_code=0,
    status=receipt['status'], source_unchanged=True,
    original_receipt_sha256=sha(source / 'receipt.json'),
    observed_utc=datetime.now(timezone.utc).isoformat())
marker.write_text(json.dumps(consumed, indent=2) + '\n')
out.mkdir(exist_ok=False)
shutil.copyfile(Path(__file__), out / 'collection-controller.py')
for name, digest in receipt['changed_source_sha256'].items():
    target = out / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(work / name, target)
    assert sha(target) == digest
excluded = []
for path in sorted(source.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(source)
    # Only authored controllers/manifests, operation receipts and raw logs.
    # No RGB, tensors, depth planes, executables, runtime or cache files.
    allowed = path.suffix in ('.json', '.log') or relative == Path('controller.py')
    if not allowed or 'appdata' in relative.parts:
        excluded.append(relative.as_posix())
        continue
    target = out / 'actual' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
collection = dict(status='finite_context_controls_verified_not_live_backend_qualification',
    source_head=receipt['source_head'], source_unchanged=True,
    binary_sha256=receipt['binary_sha256'], original_session=43396,
    controller_exit=0, completed_admission_test_targets=6, admission_tests_passed=test_passes,
    expected_failure_controls=13, exact_aba_cold_equivalence=True,
    cold_before_after_exact_equivalence=True,
    stop_after_first_preserves_original_output=True,
    excluded_nonpublic_files=excluded,
    limits=['Six real GPU outputs over two cold inputs, one A/B/A and one fail-after-first control',
        'Finite batch is explicitly selected research, not a persistent product service or qualified cache',
        'Only two source images and three retained inputs; no percentiles/realtime/domain/thermal certification',
        'Per-input process high-water readings are cumulative and not per-frame exclusive or final lifecycle memory',
        'Original full regression remains failed; no original failure was retried or assertion relaxed',
        'No third-party assets, models, arrays, executable/runtime bytes or environment workarounds distributed'])
(out / 'collection.json').write_text(json.dumps(collection, indent=2) + '\n')
members = {}
for path in sorted(out.rglob('*')):
    if path.is_file():
        members[path.relative_to(out).as_posix()] = dict(bytes=path.stat().st_size, sha256=sha(path))
archive = out / 'depth75-retained-context-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
    for name in members:
        target.write(out / name, name)
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(members)
    for name, expected in members.items():
        data = target.read(name)
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
manifest = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=members,
    readback='Every member CRC, byte length and SHA-256 verified')
(out / 'depth75-retained-context-v1.json').write_text(json.dumps(manifest, indent=2) + '\n')
checkpoint = art / 'depth75-resume-current.json'
state = json.loads(checkpoint.read_text(encoding='utf-8'))
current = state['versionedCache75']
current.update(activeController=None, ownHeavyWorkloads=[], retainedContextResult=dict(
    status=receipt['status'], originalSession=43396, consumed=True, exitCode=0,
    sourceHead=receipt['source_head'], receipt=str(source / 'receipt.json'),
    publicArchive=str(archive), archiveSha256=manifest['sha256'],
    sourceFreezeReleased=True, productBackendQualification=False))
state['updatedUtc'] = consumed['observed_utc']
checkpoint.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status=collection['status'], original_session=43396, consumed=True,
    admission_tests_passed=test_passes, failure_controls=13, bytes=manifest['bytes'],
    sha256=manifest['sha256'], members=len(members))))
