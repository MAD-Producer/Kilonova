from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-mcp-current-main'
out=root/'artifacts/pr-queue/tracking584-current-main-build-v1';wire=root/'artifacts/pr-queue/tracking584-current-main-wire-v1'
build=json.loads((out/'exit.json').read_text(encoding='utf-8'));protocol=json.loads((wire/'exit.json').read_text(encoding='utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
assert build['status']=='focused_controls_and_native_binary_build_passed' and protocol['status']=='native_stdio_workflow_default_logs_history_and_reopen_passed'
assert len(protocol['checks'])==10 and all(item['exitCode']==0 for item in build['results'])
assert build['source']==protocol['source'] and all(sha((work/p).read_bytes())==h for p,h in build['source'].items())
assert sha((root/'target/gltf-animation87-contract/debug/motion-studio.exe').read_bytes())==build['binarySha256']==protocol['binarySha256']
git=lambda *args:subprocess.check_output(['git',*args],cwd=work)
assert not git('status','--porcelain').strip()
assert git('rev-parse','HEAD').decode().strip()==build['head']=='f645ca3c36e44235ef146f8acfba52605abc7242'
assert not git('diff','--name-only','origin/main','--','desktop/app/src/panels').strip()
trees={}
for crate in ['motion-model','motion-core','motion-host','motion-media','motion-render']:
    name='crates/'+crate;a=git('rev-parse',build['integratedParent']+':'+name).decode().strip();b=git('rev-parse','HEAD:'+name).decode().strip()
    assert a==b,name
    trees[name]=a
entries={'publisher.py':Path(__file__).read_bytes()}
for folder in [out,wire]:
    for path in folder.rglob('*'):
        if path.is_file() and path.suffix in {'.py','.rs','.json','.jsonl','.log','.png'}:
            entries[folder.name+'/'+path.relative_to(folder).as_posix()]=path.read_bytes()
terminal=dict(buildSession=87354,wireSession=17299,bothTerminalConsumed=True,bothExitCode=0)
entries['terminal-review.json']=(json.dumps(terminal,indent=2)+'\n').encode('utf-8')
entries['manifest.json']=(json.dumps({n:dict(bytes=len(b),sha256=sha(b)) for n,b in entries.items()},indent=2)+'\n').encode('utf-8')
dest=work/'engineering/validation/data/tracking88-mcp-current-main-v1.zip'
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in entries.items():z.writestr(name,data)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    for name,data in entries.items():assert z.read(name)==data
receipt=dict(status='scoped_mcp_surface_stdio_passed_final_ci_pending',head=build['head'],main='77f61452',integratedParent=build['integratedParent'],unchangedCrateTrees=trees,
             terminal=terminal,binarySha256=build['binarySha256'],surface=build['surface'],surfaceChild=build['surfaceChild'],
             unitPassed=3,nativeSurfacePassed=1,wireChecks=protocol['checks'],editReplyCount=protocol['editReplyCount'],readonlyReplyCount=protocol['readonlyReplyCount'],
             archive=dict(path=dest.name,bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),members=len(entries)),
             limits=['Three actual MCP unit cases, one actual native Surface case and ten real stdio controls; not full workspace/desktop acceptance',
                     'Five full crate trees equal parent265f6668; parent tests retain their original source identity and are not counted again',
                     'Four native Surface images reviewed through before/after representative captures; not physical scanout or photographed tracker acceptance',
                     'Known earlier native crashes remain unresolved; current CI, issue85/86/88 and whole3D route incomplete; no Android acceptance'])
dest.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['surface','surfaceChild','wireChecks']}))
