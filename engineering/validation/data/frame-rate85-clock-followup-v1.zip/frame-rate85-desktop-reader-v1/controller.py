from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/frame-rate85-desktop-reader-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
paths = [p for folder in ['crates', 'desktop'] for p in (work / folder).rglob('*.rs')]
sources = {p.relative_to(work).as_posix(): sha(p) for p in paths}
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(),
    base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip(),
    sources=sources, results=[],
    scope='Actual desktop project_clock unit tests compiled against existing native dependencies, complete motion-media tests, and desktop FFmpeg compile; main desktop test binary, UI and full-route acceptance remain pending')
save = lambda: (out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
started = time.monotonic()
save()

def run(name, command):
    item = dict(name=name, command=command, status='running')
    report['results'].append(item)
    save()
    began = time.monotonic()
    with (out / f'{name}.stdout.log').open('wb') as stdout, (out / f'{name}.stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=work, env=os.environ.copy(), stdout=stdout, stderr=stderr)
        item['pid'] = child.pid
        save()
        item['exitCode'] = child.wait()
    item['elapsedSeconds'] = round(time.monotonic() - began, 3)
    item['summaries'] = re.findall(r'^test result: .+$', (out / f'{name}.stdout.log').read_text(encoding='utf-8', errors='replace'), re.M)
    item['status'] = 'passed' if item['exitCode'] == 0 else 'failed'
    save()
    print(json.dumps(item), flush=True)
    return item

try:
    deps = root / 'target/rational-rate85-contract/debug/deps'
    core = deps / 'libmotion_core-46cdf8497ca3e5b3.rlib'
    serde_json = deps / 'libserde_json-b39a2a8767a808ca.rlib'
    report['nativeDependencies'] = {str(p): sha(p) for p in [core, serde_json]}
    harness = out / 'project_clock_tests.rs'
    harness.write_text('#[path = "' + (work / 'desktop/app/src/project_clock.rs').as_posix() + '"]\nmod project_clock;\n', encoding='utf-8')
    binary = out / 'project_clock_tests.exe'
    compiled = run('reader-compile', ['rustc', '--edition=2021', '--test', str(harness),
        '-L', 'dependency=' + str(deps), '--extern', 'motion_core=' + str(core),
        '--extern', 'serde_json=' + str(serde_json), '-C', 'debuginfo=0', '-o', str(binary)])
    assert compiled['exitCode'] == 0, 'actual reader test compile failed; original logs retained'
    tested = run('reader-tests', [str(binary), '--test-threads=1'])
    assert tested['exitCode'] == 0 and tested['summaries'], 'actual reader tests failed'
    report['availableBytesBeforeMedia'] = shutil.disk_usage(root).free
    save()
    assert report['availableBytesBeforeMedia'] >= 3 * 1024**3, 'complete media source-size tests require sufficient storage; no assertion or preflight changes permitted'
    media = run('media', ['cargo', 'test', '-p', 'motion-media', '--no-default-features',
        '--locked', '--offline', '--no-fail-fast', '--', '--test-threads=1'])
    desktop = run('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg',
        '--no-default-features', '--locked', '--offline'])
    assert media['exitCode'] == 0 and media['summaries'] and desktop['exitCode'] == 0, 'media/desktop gate failed; original failures retained'
    report['status'] = 'reader_tests_media_package_and_desktop_compile_passed_full_desktop_acceptance_pending'
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report['sourceUnchanged'] = all(sha(work / path) == digest for path, digest in sources.items())
    if not report['sourceUnchanged']:
        report.update(status='failed', failure='frozen source changed during validation')
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - started, 3))
    save()
    print(json.dumps({key: report.get(key) for key in ['status', 'sourceUnchanged', 'elapsedSeconds', 'failure']}), flush=True)
    if not report['sourceUnchanged']:
        raise SystemExit(1)
