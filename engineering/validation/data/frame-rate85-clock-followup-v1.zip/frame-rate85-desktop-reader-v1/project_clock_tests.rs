#[path = "E:/Dev/aem/.worktrees/rational-frame-rates85/desktop/app/src/project_clock.rs"]
mod project_clock;
