from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/frame-rate85-render-test-adoption-v2'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = {p.relative_to(work).as_posix():sha(p) for name in ['motion-model','motion-core','motion-render','motion-effects','motion-scene'] for p in (work / 'crates' / name).rglob('*.rs')}
report = dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),sources=sources,results=[],
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),
    scope='Compile all motion-render test targets and execute the existing benchmark fixture contract after its explicit integer-rate expectation adaptation; not complete rendered-package or desktop acceptance')
save = lambda: (out / 'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
started = time.monotonic()
save()
try:
    commands = [
        ('all-render-tests-check',['cargo','check','-p','motion-render','--tests','--features','gpu-tests','--no-default-features','--locked','--offline','--keep-going']),
        ('benchmark-fixture-test',['cargo','test','-p','motion-render','--example','performance_baseline','--features','gpu-tests','--no-default-features','--locked','--offline','--','--test-threads=1']),
    ]
    for name,command in commands:
        item = dict(name=name,command=command,status='running')
        report['results'].append(item)
        save()
        began = time.monotonic()
        with (out / f'{name}.stdout.log').open('wb') as stdout,(out / f'{name}.stderr.log').open('wb') as stderr:
            child = subprocess.Popen(command,cwd=work,env=os.environ.copy(),stdout=stdout,stderr=stderr)
            item['pid'] = child.pid
            save()
            item['exitCode'] = child.wait()
        item['elapsedSeconds'] = round(time.monotonic()-began,3)
        item['summaries'] = re.findall(r'^test result: .+$',(out / f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
        item['status'] = 'passed' if item['exitCode'] == 0 else 'failed'
        save()
        print(json.dumps(item),flush=True)
    report['sourceUnchanged'] = all(sha(work / path) == digest for path,digest in sources.items())
    assert report['sourceUnchanged'] and all(item['exitCode'] == 0 for item in report['results']), 'render test adoption gate failed; original logs retained'
    assert len(report['results'][1]['summaries']) == 1 and all('0 failed; 0 ignored' in s for s in report['results'][1]['summaries'])
    report['status'] = 'all_render_tests_compile_and_benchmark_fixture_contract_passed_full_regression_pending'
except BaseException as cause:
    report.update(status='failed',failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-started,3))
    save()
    print(json.dumps({key:report.get(key) for key in ['status','sourceUnchanged','elapsedSeconds','failure']}),flush=True)
