from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/frame-rate85-gpu-cache-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sources = {p.relative_to(work).as_posix(): sha(p) for name in ['motion-model','motion-core','motion-render','motion-effects','motion-scene']
           for p in (work / 'crates' / name).rglob('*.rs')}
command = ['cargo','test','-p','motion-render','--test','rational_frame_clock','--features','gpu-tests',
           '--no-default-features','--locked','--offline','--','--test-threads=1','--nocapture']
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(),
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(), command=command,
    sources=sources, scope='Actual rational clock bundle/uniforms, preview plan cache and GPU pixel equivalence to fresh captures; not host retained-frame cache, desktop UI or full-route acceptance')
save = lambda: (out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
env = os.environ.copy()
env['MOTION_RATE_GPU_EVIDENCE_DIR'] = str(out / 'captures')
started = time.monotonic()
save()
try:
    with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    report['sourceUnchanged'] = all(sha(work / p) == digest for p,digest in sources.items())
    report['summaries'] = re.findall(r'^test result: .+$',(out / 'stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
    assert report['exitCode'] == 0 and report['sourceUnchanged'], 'actual rational GPU/cache gate failed; original logs retained'
    assert len(report['summaries']) == 1 and '4 passed; 0 failed; 0 ignored' in report['summaries'][0], report['summaries']
    captures = out / 'captures'
    records = json.loads((captures / 'captures.json').read_text(encoding='utf-8'))
    assert len(records) == 20 and len(list(captures.glob('*.png'))) == 20
    report['captures'] = {p.relative_to(out).as_posix():dict(sha256=sha(p),bytes=p.stat().st_size) for p in captures.iterdir()}
    report['status'] = 'actual_gpu_and_preview_plan_clock_cache_passed_remaining_acceptance_pending'
except BaseException as cause:
    report.update(status='failed',failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-started,3))
    save()
    print(json.dumps({key:report.get(key) for key in ['status','exitCode','sourceUnchanged','elapsedSeconds','failure']}),flush=True)
