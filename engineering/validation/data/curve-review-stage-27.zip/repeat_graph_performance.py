from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
from PIL import Image
root=Path('E:/Dev/aem');folder=root/'.tools/curve-view-ranges'/sys.argv[1];tag=sys.argv[2]
assert re.fullmatch('run-[b-z]',tag)
r=json.loads((folder/'receipt.json').read_text(encoding='utf8'))
assert r['build_exit_code']==0 and r['source_unchanged'] and r['run']['validated']
work=root/'.worktrees'/('curve-performance-baseline' if r['label']=='baseline' else 'curve-view-ranges')
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=work,text=True).splitlines()
paths=[p for p in paths if p.startswith(('crates/','desktop/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']]
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
assert freeze()==r['sources']
binary=Path(r['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==r['binary_sha256']
for item in r['runtime_dlls']:assert hashlib.sha256((folder/item['name']).read_bytes()).hexdigest()==item['sha256']
dest=folder/tag;dest.mkdir(exist_ok=False)
env=os.environ.copy();env.pop('MOTION_LOG',None);env['MOTION_GRAPH_PERFORMANCE_CHILD']=str(dest)
env['PATH']=str(folder)+os.pathsep+env.get('PATH','')
cmd=[str(binary),'--exact','panels::graph_native_performance_tests::actual_native_graph_costs_match_info_counters','--ignored','--nocapture','--test-threads=1']
start=time.monotonic();error=None
print('Independent '+r['label']+' '+tag+' measurement started from the checked compiled binary.',flush=True)
with (dest/'driver-stdout.log').open('w',encoding='utf8') as stdout,(dest/'driver-stderr.log').open('w',encoding='utf8') as stderr:
    try:result=subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr,timeout=1800)
    except subprocess.TimeoutExpired as cause:error='direct native test process exceeded1800s: '+str(cause)
summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',(dest/'driver-stdout.log').read_text(encoding='utf8'))
record=dict(label=r['label'],compiled_head=r['head'],binary_sha256=r['binary_sha256'],source_unchanged=freeze()==r['sources'],
    exit_code=result.returncode if error is None else None,error=error,summary=summary,seconds=round(time.monotonic()-start,2),scope='Independent repeated native process, same source and fixture; timing is observational, not a fixed throughput assertion.')
if error is None and result.returncode==0:
    assert summary==[('ok','1','0','0')]
    data=json.loads((dest/'result.json').read_text(encoding='utf8'));assert data['schema']==3 and len(data['cases'])==28 and data['projectUnchanged'] and data['revisionUnchanged']
    assert all(len(c['warmup'])==5 and len(c['frames'])==60 and c['renders']+c['reuses']>=60 for c in data['cases'])
    for c in data['cases']:
        advancing=c['phase']=='seek'
        assert (c['renders'],c['reuses'])==((60,0) if advancing else (0,60))
        assert all(row['sought']==advancing and row['effective_timeline_zoom']==c['timeline_zoom'] for row in c['frames'])
        assert all(isinstance(row['ui_thread_cpu_100ns'],int) and row['ui_thread_cpu_100ns']>=0 and row['ui_thread_cycles']>0 for row in c['frames'])
        if not advancing:assert all(row['seek_reply_us']==0 for row in c['frames'])
    pngs=[]
    for p in sorted(dest.glob('*.png')):
        with Image.open(p) as im:
            assert im.size==(1280,800) and any(a!=b for a,b in im.convert('RGB').getextrema())
        pngs.append(dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    assert len(pngs)==28
    project=hashlib.sha256((dest/'project/project.json').read_bytes()).hexdigest()
    package=hashlib.sha256((dest/'fixture.msfx').read_bytes()).hexdigest()
    assert project==r['run']['project_sha256'] and package==r['run']['fixture_sha256']
    record.update(validated=True,cases=28,warmup_frames=140,measured_frames=1680,pngs=pngs,project_sha256=project,fixture_sha256=package)
(dest/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in record.items() if k!='pngs'}),flush=True)
raise SystemExit(0 if record.get('validated') and record['source_unchanged'] else 1)
