from pathlib import Path
import hashlib,json,re,sys
out=Path('E:/Dev/aem/.tools/curve-view-ranges');work=Path('E:/Dev/aem/.worktrees/curve-view-ranges');folder=out/('app-stage-'+sys.argv[1]);r=json.loads((folder/'receipt.json').read_text(encoding='utf8'))
assert r['build_exit_code']==0 and r['source_unchanged'] and len(r['runs'])==9
assert all(x['exit_code']==0 and x['summary']==[['ok',x['summary'][0][1],'0',x['summary'][0][3]]] for x in r['runs'])
assert all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in r['sources'].items())
verified=set();evidence=[]
for family,expected in [('range-default-info',12),('mini-default-info',4),('readout-default-info',2),('mini-guard-default-info',1)]:
    for process in ['first-process','reset-process']:
        child=folder/family/process;result=json.loads((child/'result.json').read_text(encoding='utf8'));sites=result['sites'];assert len(sites)==expected
        stderr=(child/'stderr.log').read_text(encoding='utf8').splitlines();stdout=(child/'stdout.log').read_text(encoding='utf8');file=(child/'motion-studio.log').read_text(encoding='utf8')
        assert len(stderr)==expected and all('ERROR' in x for x in stderr)
        assert 'panel degradation' not in stdout and 'ERROR' not in stdout
        for site in sites:
            lines=[x for x in file.splitlines() if f'site={site} ' in x]
            assert len(lines)==2 and 'WARN' in lines[0] and 'count=1 ' in lines[0]
            assert 'ERROR' in lines[1] and 'count=60 ' in lines[1]
            assert all('generation=Some(1)' in x and 'revision=Some(' in x for x in lines)
            assert sum(f'site={site} ' in x for x in stderr)==1
        verified.update(sites)
        if family=='mini-guard-default-info':
            assert result['validEasingCases']==22 and result['finiteNormalizedSamples']==22550
            assert result['validActualHoverQuiet'] and result['malformedEasingRejectedBeforeHover']
            assert 'site=curve.mini.normalized_readout ' not in file
        evidence.append(dict(family=family,process=process,result=result))
assert len(verified)==19
inventory=json.loads((out/'graph-observation-inventory.json').read_text(encoding='utf8'));guarded={'curve.mini.normalized_readout'}
assert {x['site'] for x in inventory['sites'] if x['new_in_issue259']}==verified|guarded
for item in inventory['sites']:
    source=(work/item['path']).read_text(encoding='utf8');m=re.search(r'observe!\(\s*"'+re.escape(item['site'])+r'"',source);assert m
    item['line']=source[:m.start()].count('\n')+1
counts={x['name']:int(x['summary'][0][1]) for x in r['runs']};assert sum(counts.values())==136
record=dict(head=r['head'],binary_sha256=r['binary_sha256'],counts=counts,portable_passed=136,portable_ignored=1,
    actual_default_failure_sites=sorted(verified),finite_domain_guarded_sites=sorted(guarded),evidence=evidence,inventory=inventory['sites'],
    scope='Actual current-source default-level file/Error stderr/stdout isolation and process-lifetime threshold/suppression/recovery/reset verification. One guarded normalized-readout boundary is not an injected failure or a fixed defect. Native/performance/PR completion remains separate.')
(folder/'fault-channel-audit.json').write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps(dict(head=r['head'],portable_passed=136,ignored=1,actual_failure_sites=len(verified),guarded_sites=sorted(guarded))))
