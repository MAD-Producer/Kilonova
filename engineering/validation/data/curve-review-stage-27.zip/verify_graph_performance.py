from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time,types
from PIL import Image
root=Path('E:/Dev/aem');out=root/'.tools/curve-view-ranges';label,attempt=sys.argv[1:3]
assert label in ['baseline','current']
work=root/'.worktrees'/('curve-performance-baseline' if label=='baseline' else 'curve-view-ranges')
folder=out/('performance-'+label+'-'+attempt);folder.mkdir(exist_ok=False)
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=work,text=True).splitlines()
paths=[p for p in paths if p.startswith(('crates/','desktop/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']]
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
sources=freeze();shared={p:h for p,h in sources.items() if p.startswith(('crates/','desktop/ui/')) or p.endswith('Cargo.toml') or p=='Cargo.lock'}
reuse=None;roots=[p for p in paths if p.endswith('/src/lib.rs')]+['desktop/app/src/main.rs']
reuse_binary='--reuse-binary' in sys.argv[4:]
if len(sys.argv)>3:
    reference=out/sys.argv[3];proof=json.loads((reference/'receipt.json').read_text(encoding='utf8'))
    assert proof['source_unchanged']
    mismatches=[p for p in sorted(set(shared)|set(proof['shared_sources'])) if shared.get(p)!=proof['shared_sources'].get(p)]
    reuse=dict(reference=str(reference/'receipt.json'),mismatches=mismatches,compared_files=len(set(shared)|set(proof['shared_sources'])))
    if reuse_binary:
        assert proof['build_exit_code']==0 and sources==proof['sources']
        assert hashlib.sha256(Path(proof['binary']).read_bytes()).hexdigest()==proof['binary_sha256']
        roots=[];reuse['scope']='Exact source set and binary hash match; no compilation repeated'
    elif proof['build_exit_code']!=0:
        # Same checkout/target, only the new application test failed. Serial
        # Cargo reached the app after completing its dependencies; retain its
        # successful, byte-identical library build while fixing the app test.
        log=(reference/'build.log').read_text(encoding='utf8')
        assert proof['label']==label and not mismatches and '-j1' in proof['command']
        assert 'Compiling motion-desktop ' in log and 'error: could not compile `motion-desktop`' in log
        roots=['desktop/app/src/main.rs'];reuse['scope']='Same worktree serial app-only compile failure; shared source/asset set identical; no successful app or native run inferred'
    elif proof['label']==label and not mismatches:
        roots=['desktop/app/src/main.rs'];reuse['scope']='Same worktree and identical shared source/asset set; only the application test changed'
    elif set(mismatches)<= {'desktop/ui/styles/dark.json'}:
        roots=['desktop/ui/src/lib.rs','desktop/app/src/main.rs']
for p in roots:(work/p).touch()
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1','--no-run']
start=time.monotonic();print('Frozen '+label+' native graph performance '+('binary reuse' if reuse_binary else 'build')+' started.',flush=True)
if reuse_binary:build=types.SimpleNamespace(returncode=0)
else:
    with (folder/'build.log').open('w',encoding='utf8') as sink:build=subprocess.run(command,cwd=work,stdout=sink,stderr=subprocess.STDOUT)
run=None;digest=None;binary=None;error=None;runtime=[]
if build.returncode==0:
    original=Path(proof['binary']) if reuse_binary else Path(re.search(r'Executable unittests[^\n]*\(([^\n]+\.exe)\)',(folder/'build.log').read_text(encoding='utf8')).group(1))
    binary=folder/'motion-studio-tests.exe';shutil.copyfile(original,binary)
    digest=hashlib.sha256(original.read_bytes()).hexdigest();assert hashlib.sha256(binary.read_bytes()).hexdigest()==digest
    assert freeze()==sources,'Source changed during compilation'
    destination=folder/'run-a';destination.mkdir()
    env=os.environ.copy();env.pop('MOTION_LOG',None);env['MOTION_GRAPH_PERFORMANCE_CHILD']=str(destination)
    # The copied executable needs the same FFmpeg DLL adjacency as Cargo's
    # original deps executable. Snapshot only its five FFmpeg runtime imports;
    # keep these local runtime files out of any published evidence archive.
    for name in ['avcodec-62.dll','avformat-62.dll','avutil-60.dll','swscale-9.dll','swresample-6.dll']:
        source=Path(env['FFMPEG_DIR'])/'bin'/name;target=folder/name
        shutil.copyfile(source,target)
        h=hashlib.sha256(source.read_bytes()).hexdigest();assert hashlib.sha256(target.read_bytes()).hexdigest()==h
        runtime.append(dict(name=name,source=str(source),sha256=h,bytes=source.stat().st_size))
    env['PATH']=str(folder)+os.pathsep+env.get('PATH','')
    smoke=subprocess.run([str(binary),'--list'],cwd=work,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
    loader=dict(exit_code=smoke.returncode,benchmark_registered=b'actual_native_graph_costs_match_info_counters' in smoke.stdout,stderr=smoke.stderr.decode(errors='replace')[:1000])
    (folder/'loader-smoke.json').write_text(json.dumps(loader,indent=2),encoding='utf8')
    assert loader['exit_code']==0 and loader['benchmark_registered'],loader
    cmd=[str(binary),'--exact','panels::graph_native_performance_tests::actual_native_graph_costs_match_info_counters','--ignored','--nocapture','--test-threads=1']
    print('Frozen '+label+' native benchmark started; 28cases,5warmup+60measured per case.',flush=True)
    began=time.monotonic()
    with (destination/'driver-stdout.log').open('w',encoding='utf8') as stdout, (destination/'driver-stderr.log').open('w',encoding='utf8') as stderr:
        try:result=subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr,timeout=1800)
        except subprocess.TimeoutExpired as cause:error='direct native test process exceeded1800s: '+str(cause)
    summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',(destination/'driver-stdout.log').read_text(encoding='utf8'))
    run=dict(exit_code=result.returncode if error is None else None,seconds=round(time.monotonic()-began,2),summary=summary,error=error)
    if error is None and result.returncode==0:
        assert summary==[('ok','1','0','0')],summary
        data=json.loads((destination/'result.json').read_text(encoding='utf8'));assert data['schema']==3 and len(data['cases'])==28 and data['projectUnchanged'] and data['revisionUnchanged']
        assert all(len(c['warmup'])==5 and len(c['frames'])==60 and c['renders']+c['reuses']>=60 for c in data['cases'])
        for c in data['cases']:
            advancing=c['phase']=='seek'
            assert (c['renders'],c['reuses'])==((60,0) if advancing else (0,60))
            assert all(row['sought']==advancing and row['effective_timeline_zoom']==c['timeline_zoom'] for row in c['frames'])
            assert all(isinstance(row['ui_thread_cpu_100ns'],int) and row['ui_thread_cpu_100ns']>=0 and row['ui_thread_cycles']>0 for row in c['frames'])
            if not advancing:assert all(row['seek_reply_us']==0 for row in c['frames'])
        pngs=[]
        for p in sorted(destination.glob('*.png')):
            with Image.open(p) as im:
                assert im.size==(1280,800) and any(a!=b for a,b in im.convert('RGB').getextrema())
                pngs.append(dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
        assert len(pngs)==28
        run.update(validated=True,cases=28,warmup_frames=140,measured_frames=1680,pngs=pngs,
            project_sha256=hashlib.sha256((destination/'project/project.json').read_bytes()).hexdigest(),
            fixture_sha256=hashlib.sha256((destination/'fixture.msfx').read_bytes()).hexdigest())
receipt=dict(label=label,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),command=command,
    build_exit_code=build.returncode,binary=str(binary) if binary else None,binary_sha256=digest,sources=sources,shared_sources=shared,
    source_unchanged=freeze()==sources,forced_roots=roots,library_reuse=reuse,build_reused_from=str(reference/'receipt.json') if reuse_binary else None,
    runtime_dlls=runtime,run=run,seconds=round(time.monotonic()-start,2),
    scope='Actual hidden native Shell graph+Viewer+Info cost study; debug ffmpeg executable; compare paired branches/raw records before drawing performance conclusions. No issue259 completion claim.')
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['sources','shared_sources','forced_roots','command']}),flush=True)
raise SystemExit(0 if build.returncode==0 and run and run.get('validated') and receipt['source_unchanged'] else 1)
