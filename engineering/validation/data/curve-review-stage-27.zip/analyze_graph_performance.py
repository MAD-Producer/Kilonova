from pathlib import Path
import hashlib,json,math,statistics,sys
out=Path('E:/Dev/aem/.tools/curve-view-ranges');base_name,current_name=sys.argv[1:3]
partial='--partial' in sys.argv[3:]
def percentile(values,q):
    a=sorted(values);p=(len(a)-1)*q;i=math.floor(p);j=math.ceil(p)
    return a[i]+(a[j]-a[i])*(p-i)
def metrics(rows,key):
    values=[row['info']['lastPresentUs'] if key=='worker' else row[key] for row in rows]
    return dict(samples=len(values),p50_us=statistics.median(values),p95_us=percentile(values,.95),p99_us=percentile(values,.99))
runs={};builds={};projects=set();packages=set();dlls=[];harnesses=set();schemas=set()
for label,name in [('baseline',base_name),('current',current_name)]:
    folder=out/name;r=json.loads((folder/'receipt.json').read_text(encoding='utf8'))
    assert r['label']==label and r['source_unchanged'] and r['build_exit_code']==0 and r['run']['validated']
    builds[label]=dict(head=r['head'],binary_sha256=r['binary_sha256'],folder=name)
    harnesses.add(r['sources']['desktop/app/src/panels/graph_native_performance_tests.rs'])
    dlls.append({x['name']:x['sha256'] for x in r['runtime_dlls']})
    runs[label]=[]
    for tag in ['run-a'] if partial else ['run-a','run-b']:
        p=folder/tag;check=r['run'] if tag=='run-a' else json.loads((p/'receipt.json').read_text(encoding='utf8'))
        assert check['validated'] and check['exit_code']==0
        data=json.loads((p/'result.json').read_text(encoding='utf8'))
        assert data['schema'] in [2,3] and len(data['cases'])==28 and data['projectUnchanged'] and data['revisionUnchanged']
        schemas.add(data['schema'])
        assert not any('panel degradation' in f.read_text(encoding='utf8') for f in (p/'logs').glob('*.log'))
        projects.add(hashlib.sha256((p/'project/project.json').read_bytes()).hexdigest())
        packages.add(hashlib.sha256((p/'fixture.msfx').read_bytes()).hexdigest())
        for c in data['cases']:
            assert len(c['frames'])==60 and len(c['warmup'])==5
            advancing=c['phase']=='seek';expected=(1,0) if advancing else (0,1)
            assert (c['renders'],c['reuses'])==tuple(60*x for x in expected)
            previous=c['info_before']
            for row in c['frames']:
                assert row['sought']==advancing and row['effective_timeline_zoom']==c['timeline_zoom']
                if not advancing:assert row['seek_reply_us']==0
                if data['schema']==3:
                    assert row['ui_thread_cpu_100ns']>=0 and row['ui_thread_cycles']>0
                    assert isinstance(row['document_generation'],int) and row['document_generation']>=1 and row['revision']==0
                counters=row['info']
                delta=tuple(counters[k]-previous[k] for k in ['compositionRenders','compositionReuses'])
                assert delta==expected,(c['case'],delta)
                previous=counters
            assert all(previous[k]==c['info_after'][k] for k in ['compositionRenders','compositionReuses'])
        runs[label].append(dict(tag=tag,data=data))
assert len(projects)==1 and len(packages)==1 and len(harnesses)==1 and dlls[0]==dlls[1] and len(schemas)==1
names=[c['case'] for c in runs['baseline'][0]['data']['cases']];results=[]
for name in names:
    item=dict(case=name)
    for label in ['baseline','current']:
        cases=[next(c for c in run['data']['cases'] if c['case']==name) for run in runs[label]]
        rows=[row for c in cases for row in c['frames']]
        item[label]=dict(ui=metrics(rows,'ui_build_and_atlas_us'),worker=metrics(rows,'worker'),reply=metrics(rows,'present_reply_us'),
            ui_run_medians=[statistics.median(row['ui_build_and_atlas_us'] for row in c['frames']) for c in cases])
        if next(iter(schemas))==3:
            item[label].update(ui_thread_cpu_mean_us=sum(row['ui_thread_cpu_100ns'] for row in rows)/10/len(rows),
                ui_thread_cycle_mean=sum(row['ui_thread_cycles'] for row in rows)/len(rows),
                ui_thread_cpu_run_means_us=[sum(row['ui_thread_cpu_100ns'] for row in c['frames'])/600 for c in cases],
                ui_thread_cycle_run_means=[sum(row['ui_thread_cycles'] for row in c['frames'])/60 for c in cases])
    a=item['baseline']['ui']['p50_us'];b=item['current']['ui']['p50_us']
    item.update(ui_p50_delta_us=b-a,ui_p50_delta_percent=100*(b/a-1))
    if next(iter(schemas))==3:
        for field in ['ui_thread_cpu_mean_us','ui_thread_cycle_mean']:
            a=item['baseline'][field];b=item['current'][field]
            item[field+'_delta_percent']=100*(b/a-1) if a else None
    results.append(item)
record=dict(status='PARTIAL_ONE_RUN_EACH' if partial else 'PAIRED_REPEATED_MEASUREMENT_COMPLETE',schema=next(iter(schemas)),builds=builds,
    runs_per_variant=1 if partial else 2,measured_frames=(3360 if partial else 6720),warmup_frames=(280 if partial else 560),
    cases=results,project_sha256=next(iter(projects)),fixture_sha256=next(iter(packages)),harness_sha256=next(iter(harnesses)),
    all_static_measured_frames_reuse=True,all_distinct_seek_frames_render=True,no_new_curve_degradation=True,
    limits='Debug ffmpeg build; fixed1280x800 test layout with small composition viewport and single owned effect layer. Direct seeks, not application playback/input dispatch; Mini default scale only. State observation outside timed UI/Present. Development-machine load/thermals not controlled. Timing differences need interpretation; no shipping FPS or cross-device speedup claim. Final latest-main/native/all-targets/PR acceptance remains separate.')
path=out/('performance-comparison-partial.json' if partial else 'performance-comparison.json')
path.write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps(dict(status=record['status'],project=record['project_sha256'],cases=len(results),
    largest_ui_p50_deltas=sorted([dict(case=x['case'],base_us=x['baseline']['ui']['p50_us'],current_us=x['current']['ui']['p50_us'],delta_percent=round(x['ui_p50_delta_percent'],2)) for x in results],key=lambda x:x['delta_percent'],reverse=True)[:8]),ensure_ascii=False))
