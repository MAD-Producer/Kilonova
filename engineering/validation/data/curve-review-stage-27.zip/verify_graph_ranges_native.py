from pathlib import Path
import hashlib,json,math,os,re,subprocess,sys,time
from PIL import Image
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges';out=root/'.tools/curve-view-ranges';attempt=sys.argv[1]
stage=out/('app-stage-'+attempt);r=json.loads((stage/'receipt.json').read_text(encoding='utf8'))
assert r['build_exit_code']==0 and r['source_unchanged'] and len(r['runs'])==9 and all(run['exit_code']==0 for run in r['runs'])
def freeze():return {path:hashlib.sha256((work/path).read_bytes()).hexdigest() for path in r['sources']}
assert freeze()==r['sources']
binary=Path(re.search(r'Executable unittests[^\n]*\(([^\n]+\.exe)\)',(stage/'build.log').read_text(encoding='utf8')).group(1))
assert hashlib.sha256(binary.read_bytes()).hexdigest()==r['binary_sha256']
folder=out/('native-ranges-'+attempt);folder.mkdir(exist_ok=False)
name='panels::graph_ranges::native_tests::graph_ranges_native_all_surfaces_locales_dpi_locks_cancellation_and_saved_files'
env=dict(os.environ,MOTION_GRAPH_RANGES_NATIVE_ARTIFACTS=str(folder));env.pop('MOTION_LOG',None)
started=time.monotonic()
with (folder/'runner.stdout.log').open('w',encoding='utf8') as stdout,(folder/'runner.stderr.log').open('w',encoding='utf8') as stderr:
 result=subprocess.run([str(binary),'--exact',name,'--ignored','--nocapture','--test-threads=1'],cwd=work,env=env,stdout=stdout,stderr=stderr)
text=(folder/'runner.stdout.log').read_text(encoding='utf8');summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
record=dict(head=r['head'],binary_sha256=r['binary_sha256'],test=name,exit_code=result.returncode,summary=summary,seconds=round(time.monotonic()-started,2),source_unchanged=freeze()==r['sources'],validated=False)
(folder/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8')
assert result.returncode==0 and summary==[('ok','1','0','0')] and record['source_unchanged'],record
e=json.loads((folder/'result.json').read_text(encoding='utf8'))
assert len(e['cases'])==32 and len({case['case'] for case in e['cases']})==32
assert e['saved_files_byte_equal'] and e['reopened_project_equal'] and e['actual_worker_revision_cancel']
assert e['external_edit_undo_separate_from_view_invariant'] and not e['physical_os_input'] and not e['system_dpi_setting_changed']
pngs=[];maximum=0.
for case in e['cases']:
 assert case['pixel_ratio'] in [1.,1.5,2.] and len(case['pixel_measurements'])>=2
 if '-mini-' in case['case']:assert 0<case['high_zoom_x_span']<0.002
 assert all(case[key] for key in ['fit_selection','lock_x_y_playhead_wheel','pointer_and_keyboard','ime_repeat_gated','focus_and_foreign_cancel','history_revision_project_unchanged'])
 for m in case['pixel_measurements']:
  error=m['nearest_colored_curve_pixel_distance'];assert math.isfinite(error) and error<=case['pixel_ratio']*1.5+0.75;maximum=max(maximum,error)
 for suffix in ['curve','menu','fit-selection','locked-menu','readout']:
  p=folder/(case['case']+'-'+suffix+'.png');im=Image.open(p);im.verify();im=Image.open(p)
  assert list(im.size)==[round(v*case['pixel_ratio']) for v in case['logical_size']]
  pngs.append(dict(path=p.name,size=list(im.size),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
assert len(pngs)==160
snapshots=[]
for path in sorted((folder/'saved-before').rglob('*')):
 if not path.is_file():continue
 relative=path.relative_to(folder/'saved-before');after=folder/'saved-after'/relative
 assert after.is_file() and path.read_bytes()==after.read_bytes(),str(relative)
 snapshots.append(dict(path=str(relative).replace('\\','/'),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
assert snapshots and any(p['path']=='project.json' for p in snapshots)
assert {p.relative_to(folder/'saved-after') for p in (folder/'saved-after').rglob('*') if p.is_file()}=={p.relative_to(folder/'saved-before') for p in (folder/'saved-before').rglob('*') if p.is_file()}
record.update(validated=True,cases=e['cases'],native_cases=32,pngs=pngs,saved_files=snapshots,maximum_nearest_curve_pixel_distance_physical=maximum,
 physical_os_input=False,controlled_pixel_ratios=[1.,1.5,2.],actual_worker_revision_cancel=True,
 scope='Actual hidden main/floating native surfaces with production chrome Input injection, four graph surfaces and value/speed modes; actual saved project bytes before/after and Core reopen. Exact four window/locale/size/ratio combinations recorded per case. No physical OS input or system DPI-setting change.')
(folder/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in record.items() if k not in ['cases','pngs']},ensure_ascii=False),flush=True)
