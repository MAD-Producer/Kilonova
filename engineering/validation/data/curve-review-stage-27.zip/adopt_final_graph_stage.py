from pathlib import Path
import ctypes,datetime,hashlib,json,os,re,subprocess,sys,time
from ctypes import wintypes
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges';out=root/'.tools/curve-view-ranges';folder=out/'app-stage-27'
driver,test=43628,32160
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE
k.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)];k.QueryFullProcessImageNameW.restype=wintypes.BOOL
k.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];k.GetExitCodeProcess.restype=wintypes.BOOL
k.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];k.WaitForSingleObject.restype=wintypes.DWORD
k.TerminateProcess.argtypes=[wintypes.HANDLE,wintypes.UINT];k.TerminateProcess.restype=wintypes.BOOL
k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
query=f'Get-CimInstance Win32_Process -Filter "ProcessId={driver} OR ProcessId={test}" | Select-Object ProcessId,ParentProcessId,CommandLine,CreationDate | ConvertTo-Json -Compress'
actual=json.loads(subprocess.check_output(['powershell','-NoProfile','-Command',query],text=True,encoding='utf8'))
by_id={p['ProcessId']:p for p in actual}
assert by_id[test]['ParentProcessId']==driver
assert 'verify_final_from_performance.py 27 performance-current-02 --build' in by_id[driver]['CommandLine']
assert 'app-stage-27\\motion-studio-tests.exe panels::graph_ranges::' in by_id[test]['CommandLine']
def open_process(pid,rights):
    handle=k.OpenProcess(rights,False,pid);assert handle,ctypes.get_last_error();return handle
handle=open_process(test,0x100000|0x1000);supervisor=open_process(driver,0x100000|0x1000|1)
buffer=ctypes.create_unicode_buffer(32768);size=wintypes.DWORD(len(buffer))
assert k.QueryFullProcessImageNameW(handle,0,buffer,ctypes.byref(size))
binary=folder/'motion-studio-tests.exe';assert Path(buffer.value).resolve()==binary.resolve()
def freeze():
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=work,text=True).splitlines()
    paths=[p for p in paths if p.startswith(('crates/','desktop/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']]
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
sources=freeze();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip();digest=hashlib.sha256(binary.read_bytes()).hexdigest()
record=dict(reason='The supervisor600s cap is below the recorded historical605.45s normal range-suite duration. Adopt the already-running exact range process, preserve its output and actual exit code, do not retry tests or change production timeouts.',processes=actual,source_head=head,binary_sha256=digest,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(folder/'supervision-adjustment.json').write_text(json.dumps(record,indent=2),encoding='utf8')
assert k.TerminateProcess(supervisor,75),ctypes.get_last_error()
assert k.WaitForSingleObject(supervisor,5000)==0;k.CloseHandle(supervisor)
print('Adopted the running exact range test; only its Python supervisor was stopped. Original test and fault child continue without restart.',flush=True)
started=time.monotonic()
while True:
    status=k.WaitForSingleObject(handle,1000)
    if status==0:break
    assert status==258,ctypes.get_last_error()
    assert time.monotonic()-started<1800,'Adopted test remains running after1800s; leave process intact and report pending'
code=wintypes.DWORD();assert k.GetExitCodeProcess(handle,ctypes.byref(code));k.CloseHandle(handle)
record.update(actual_range_exit_code=code.value,adopted_wait_seconds=round(time.monotonic()-started,2),source_unchanged=freeze()==sources)
(folder/'supervision-adjustment.json').write_text(json.dumps(record,indent=2),encoding='utf8')
assert record['source_unchanged']
targets=[('adaptive','panels::graph_adaptive::'),('sampling','panels::graph_sampling::'),('timeline','panels::timeline_shortcuts_tests::'),('handles','panels::graph_handles::'),('ranges','panels::graph_ranges::'),('axes','panels::graph_view::'),('effects','panels::effect_timeline::'),('comparison','panels::curve_comparison::'),('mini','panels::animation_controls::')]
env=os.environ.copy();env.pop('MOTION_LOG',None)
for key,name in dict(MOTION_CURVE_MINI_FAULT_ARTIFACTS='mini-default-info',MOTION_CURVE_RANGE_FAULT_ARTIFACTS='range-default-info',MOTION_CURVE_READOUT_FAULT_ARTIFACTS='readout-default-info',MOTION_MINI_ADAPTIVE_GUARD_ARTIFACTS='mini-guard-default-info').items():env[key]=str(folder/name)
runs=[]
for index,(name,pattern) in enumerate(targets):
    seconds=None
    if index>4:
        began=time.monotonic()
        with (folder/(name+'.log')).open('w',encoding='utf8') as sink:result=subprocess.run([str(binary),pattern,'--nocapture','--test-threads=1'],cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT)
        exit_code=result.returncode;seconds=round(time.monotonic()-began,2)
    else:exit_code=code.value if index==4 else 0
    summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',(folder/(name+'.log')).read_text(encoding='utf8'))
    assert len(summaries)==1 and int(summaries[0][1])>0,(name,summaries)
    item=dict(name=name,filter=pattern,exit_code=exit_code,seconds=seconds,summary=summaries);runs.append(item);print(json.dumps(item),flush=True)
ref=json.loads((out/'performance-current-02/receipt.json').read_text(encoding='utf8'))
receipt=dict(head=head,build_exit_code=0,build_reused_from=None,build_command=ref['command'],shared_library_reference=str(out/'performance-current-02/receipt.json'),
    sources=sources,source_unchanged=freeze()==sources,binary_sha256=digest,runs=runs,supervision_adjustment=str(folder/'supervision-adjustment.json'),
    scope='Actual frozen final-source build and nine portable suites. Range process adopted without restart from an overly short Python600s supervisor; actual Windows process exit and original log retained. Initial four suite exit codes recorded before supervisor handoff; summaries rechecked from original files. Native/all-targets/PR remain separate.')
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
raise SystemExit(0 if all(x['exit_code']==0 for x in runs) and receipt['source_unchanged'] else 1)
