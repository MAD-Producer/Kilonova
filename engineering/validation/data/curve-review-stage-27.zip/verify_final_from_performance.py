from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges';out=root/'.tools/curve-view-ranges'
attempt,reference=sys.argv[1:3];built=out/reference;r=json.loads((built/'receipt.json').read_text(encoding='utf8'))
assert r['label']=='current' and r['source_unchanged'] and r['build_exit_code']==0 and r['run']['validated']
def freeze():
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=work,text=True).splitlines()
    paths=[p for p in paths if p.startswith(('crates/','desktop/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']]
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
folder=out/('app-stage-'+attempt);folder.mkdir(exist_ok=False)
fresh='--build' in sys.argv[3:];sources=freeze()
if fresh:
    shared=lambda m:{p:h for p,h in m.items() if p.startswith(('crates/','desktop/ui/')) or p.endswith('Cargo.toml') or p=='Cargo.lock'}
    assert shared(sources)==shared(r['sources']),'Shared target library source/asset mismatch'
    (work/'desktop/app/src/main.rs').touch()
    print('Frozen final graph acceptance build started; exact shared-library source/asset set retained from '+reference,flush=True)
    with (folder/'cargo-build.log').open('w',encoding='utf8') as sink:build=subprocess.run(r['command'],cwd=work,stdout=sink,stderr=subprocess.STDOUT)
    assert freeze()==sources,'Compiled source set changed'
    if build.returncode:
        (folder/'receipt.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),build_exit_code=build.returncode,sources=sources,source_unchanged=True,runs=[]),indent=2),encoding='utf8')
        raise SystemExit(build.returncode)
    original=Path(re.search(r'Executable unittests[^\n]*\(([^\n]+\.exe)\)',(folder/'cargo-build.log').read_text(encoding='utf8')).group(1))
    binary=folder/'motion-studio-tests.exe';shutil.copyfile(original,binary)
    runtime=[]
    for item in r['runtime_dlls']:
        source=built/item['name'];assert hashlib.sha256(source.read_bytes()).hexdigest()==item['sha256']
        shutil.copyfile(source,folder/item['name']);runtime.append(item)
    r=dict(r,sources=sources,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
else:
    assert sources==r['sources'],'Cannot reuse a binary after its source set changed'
    binary=Path(r['binary']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==r['binary_sha256']
# The existing native validator reads this format. Point it at the verified,
# immutable copied executable, never at a shared target another build can replace.
(folder/'build.log').write_text('Verified exact binary reuse from '+str(built/'receipt.json')+'\nExecutable unittests src/main.rs ('+str(binary)+')\n',encoding='utf8')
env=os.environ.copy();env.pop('MOTION_LOG',None)
for key,name in dict(MOTION_CURVE_MINI_FAULT_ARTIFACTS='mini-default-info',MOTION_CURVE_RANGE_FAULT_ARTIFACTS='range-default-info',MOTION_CURVE_READOUT_FAULT_ARTIFACTS='readout-default-info',MOTION_MINI_ADAPTIVE_GUARD_ARTIFACTS='mini-guard-default-info').items():env[key]=str(folder/name)
targets=[('adaptive','panels::graph_adaptive::'),('sampling','panels::graph_sampling::'),('timeline','panels::timeline_shortcuts_tests::'),('handles','panels::graph_handles::'),('ranges','panels::graph_ranges::'),('axes','panels::graph_view::'),('effects','panels::effect_timeline::'),('comparison','panels::curve_comparison::'),('mini','panels::animation_controls::')]
started=time.monotonic();runs=[]
for name,pattern in targets:
    began=time.monotonic()
    with (folder/(name+'.log')).open('w',encoding='utf8') as sink:result=subprocess.run([str(binary),pattern,'--nocapture','--test-threads=1'],cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT,timeout=1800)
    summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',(folder/(name+'.log')).read_text(encoding='utf8'))
    assert len(summaries)==1 and int(summaries[0][1])>0,(name,summaries)
    item=dict(name=name,filter=pattern,exit_code=result.returncode,seconds=round(time.monotonic()-began,2),summary=summaries);runs.append(item);print(json.dumps(item),flush=True)
receipt=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),build_exit_code=0,
    build_reused_from=None if fresh else str(built/'receipt.json'),shared_library_reference=str(built/'receipt.json'),build_command=r['command'],sources=r['sources'],source_unchanged=freeze()==r['sources'],
    binary_sha256=r['binary_sha256'],runs=runs,seconds=round(time.monotonic()-started,2),
    scope='Nine full portable graph suites at the recorded frozen source and copied binary. Default level actual fault evidence retained. Explicit native/all-targets/PR acceptance remains separate.')
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['sources','build_command']}),flush=True)
raise SystemExit(0 if len(runs)==9 and all(x['exit_code']==0 for x in runs) and receipt['source_unchanged'] else 1)
