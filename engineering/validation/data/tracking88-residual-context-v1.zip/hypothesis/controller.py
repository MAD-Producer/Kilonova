"""Compare already available hypotheses on the unchanged first failed fit."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/planar-tracker88'
OUT = ART / 'tracking88-mousepad-hypothesis-v1'
CP = ART / 'depth75-resume-current.json'
HEAD = '87e648ffbbaea79b6e7c30f2b6a9b9df99298045'
SOURCE = ART / 'tracking88-real-planar-acquisition-v1/mouse-pad.avi'
BASE = ART / 'tracking88-mousepad-full-core-v1'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def write(p, v):
    tmp = p.with_suffix(p.suffix + '.pending')
    tmp.write_text(json.dumps(v, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    tmp.replace(p)

state = read(CP)
v = state['versionedCache75']
assert v['activeController'] is None and not v['ownHeavyWorkloads']
assert read(BASE / 'session-consumed.json')['original_tool_result_consumed']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK, text=True).strip()
assert sha(SOURCE) == 'f7cfe7d11fb64111777b6074a21bc58de7fc500ebce15f26577ee0ba2c4f890f'
baseline = BASE / 'no-corrections/observations.jsonl'
assert sha(baseline) == read(BASE / 'receipt.json')['blind_output_seals'][0]['sha256']
names = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()
hashes = {n: sha(WORK / n) for n in names}
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
os.environ.update(TEMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'),
                  TMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'), PYTHONDONTWRITEBYTECODE='1')
report = dict(status='running', head=HEAD, started_utc=datetime.now(timezone.utc).isoformat(),
              source_sha256=hashes, source_video_sha256=sha(SOURCE), baseline_sha256=sha(baseline),
              selected_indices=list(range(15)), rows=[], in_flight=None,
              scope='Post-failure selected diagnostic; unchanged tracker and gates, no annotation reads')
v.update(activeController=str(Path(__file__)), ownHeavyWorkloads=[dict(
    kind='first-loss existing-hypothesis residual diagnostic', head=HEAD, sourceFrozen=True, output=str(OUT))])
write(CP, state)

import logging
logger = logging.getLogger('tracking88.hypothesis')
logger.setLevel(logging.INFO)
sink = logging.FileHandler(OUT / 'observation.log', encoding='utf-8')
sink.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
console = logging.StreamHandler()
console.setLevel(logging.ERROR)
logger.addHandler(sink)
logger.addHandler(console)

def start(op):
    report['in_flight'] = op
    write(OUT / 'receipt.json', report)
    logger.info('start operation=%s', op)
    sink.flush()

try:
    start('import_existing_runtime')
    sys.path.insert(0, str(WORK / 'tools/tracking'))
    import plate_flow as flow
    import numpy as np
    flow.cv2.setNumThreads(1)
    flow.cv2.setRNGSeed(88)
    start('decode_original_indices_0_to_14')
    ff = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
    p = subprocess.run([str(ff), '-v', 'error', '-nostdin', '-threads', '1', '-noautorotate',
        '-copyts', '-i', str(SOURCE), '-an', '-sn', '-dn', '-vf', r'select=lte(n\,14)',
        '-fps_mode', 'passthrough', '-threads', '1', '-f', 'rawvideo', '-pix_fmt', 'gray', 'pipe:1'], capture_output=True)
    (OUT / 'decode.stderr.log').write_bytes(p.stderr)
    assert p.returncode == 0 and not p.stderr and len(p.stdout) == 15 * 640 * 480
    images = np.frombuffer(p.stdout, np.uint8).reshape(15, 480, 640)
    expected = [json.loads(line) for line in baseline.read_text(encoding='utf-8').splitlines()[:15]]
    original = flow.cv2.findHomography
    calls = []
    def observed(*args, **kwargs):
        matrix, mask = original(*args, **kwargs)
        calls.append((None if matrix is None else matrix.copy(),
                      None if mask is None else mask.copy()))
        return matrix, mask
    flow.cv2.findHomography = observed
    previous = None
    prior_matrix = np.eye(3)
    for index, image in enumerate(images):
        start(f'unchanged_frame_{index}')
        gray = flow.prepare(image)
        calls = []
        if index == 0:
            tracker = flow.Tracker(dict(id='plane', kind='plane', roi=[200., 140., 340., 260.]), gray)
            observation, confidence = tracker.initial, 1.
        else:
            observation, confidence = tracker.observe(previous, gray)
        prior = next(t for t in expected[index]['tracks'] if t['id'] == 'plane')
        assert observation == prior['observation'] and confidence == prior['confidence'] and tracker.reason == prior['reason']
        row = dict(index=index, visible=observation is not None, reason=tracker.reason)
        if index == 14:
            assert tracker.reason == 'plane fit has too few inliers' and len(calls) == 2
            fit = ~tracker.holdout
            independent, _ = original(tracker.reference[tracker.holdout], tracker.points[tracker.holdout], 0)
            x, y, w, h = tracker.seed['roi']
            corners = [[x,y], [x+w,y], [x+w,y+h], [x,y+h]]
            candidates = {}
            for name, matrix in [('original_prediction', calls[0][0]), ('original_final', calls[1][0]),
                                 ('previous_visible', prior_matrix)]:
                error = np.linalg.norm(flow.transform(matrix, tracker.reference)-tracker.points, axis=1)
                support = error[fit] <= flow.LIMITS['planeFitPixels']
                held = error[tracker.holdout]
                disagreement = np.linalg.norm(flow.transform(matrix,corners)-flow.transform(independent,corners),axis=1)
                candidates[name] = dict(fitting_points=int(np.sum(fit)), fitting_inliers=int(np.sum(support)),
                    fitting_ratio=float(np.mean(support)), fitting_median=float(np.median(error[fit])),
                    fitting_maximum=float(error[fit].max()), heldout_points=len(held),
                    heldout_rms=float(np.sqrt(np.mean(held**2))), heldout_maximum=float(held.max()),
                    independent_extrapolation_maximum=float(disagreement.max()),
                    original_inlier_gate=bool(np.sum(support)>=flow.LIMITS['minimumFitInliers'] and np.mean(support)>=flow.LIMITS['minimumInlierRatio']),
                    original_holdout_gate=bool(np.sqrt(np.mean(held**2))<=flow.LIMITS['heldOutRmsPixels'] and held.max()<=flow.LIMITS['heldOutMaxPixels']),
                    original_extrapolation_gate=bool(disagreement.max()<=flow.LIMITS['planeConsensusMaxPixels']))
            row['candidates_on_identical_final_correspondences'] = candidates
        report['rows'].append(row)
        if observation is not None:
            prior_matrix = np.asarray(observation['matrix'])
        previous = gray.copy()
    flow.cv2.findHomography = original
    report.update(status='selected_hypotheses_observed_original_decisions_preserved', observation_equivalence=True)
except BaseException:
    import traceback
    report.update(status='failed_original_observation_retained', cause=traceback.format_exc())
    logger.error('operation=%s cause=%s', report['in_flight'], report['cause'][-8192:])
finally:
    report.update(in_flight=None, completed_utc=datetime.now(timezone.utc).isoformat(),
        source_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==HEAD
        and not subprocess.check_output(['git','status','--porcelain'],cwd=WORK,text=True).strip()
        and all(sha(WORK / name)==digest for name,digest in hashes.items()),
        input_unchanged=sha(SOURCE)==report['source_video_sha256'] and sha(baseline)==report['baseline_sha256'])
    write(OUT / 'receipt.json', report)
    sink.close()
    print(json.dumps({k:report.get(k) for k in ('status','observation_equivalence','source_unchanged','input_unchanged','cause')}))
raise SystemExit(0 if report['status']=='selected_hypotheses_observed_original_decisions_preserved' and report['source_unchanged'] and report['input_unchanged'] else 1)
