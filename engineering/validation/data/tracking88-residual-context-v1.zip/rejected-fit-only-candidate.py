"""Bounded fit-only polishing; no held-out or ground-truth inputs."""
def polish(flow, original_find, reference, points, roi, hypotheses):
    import numpy as np
    best = None
    trace = []
    threshold = flow.LIMITS['planeFitPixels']
    def evaluate(matrix):
        if matrix is None:
            return None
        try:
            matrix = flow.plane_matrix(matrix, roi)
            distance = np.linalg.norm(flow.transform(matrix, reference)-points, axis=1)
        except ValueError:
            return None
        mask = distance <= threshold
        score = (int(mask.sum()), -float(np.minimum(distance**2, threshold**2).sum()))
        return score, matrix.copy(), mask
    for name, matrix in hypotheses:
        current = evaluate(matrix)
        for step in range(9):
            if current is None:
                break
            score, matrix, mask = current
            trace.append(dict(hypothesis=name,step=step,inliers=score[0],clipped_squared_error=-score[1]))
            if best is None or score > best[0]:
                best = current
            if step == 8 or mask.sum() < flow.LIMITS['minimumFitInliers']:
                break
            refined, _ = original_find(reference[mask], points[mask], 0)
            candidate = evaluate(refined)
            if candidate is None or candidate[0] <= score:
                break
            current = candidate
    return best, trace
