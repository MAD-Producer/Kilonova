"""Verify new numeric causes against both complete sealed core observations."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import traceback

ART = Path('E:/Dev/aem/artifacts/pr-queue')
WORK = Path('E:/Dev/aem/.worktrees/planar-tracker88')
OUT = ART / 'tracking88-residual-context-v1'
BASE = ART / 'tracking88-mousepad-full-core-v1'
CP = ART / 'depth75-resume-current.json'
CV = 'E:/Dev/aem/.tools/ai-depth74/venv/Scripts/python.exe'
OLD = ART / 'tracking88-mousepad-full-core-v1-controller.py'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
state = read(CP)
v = state['versionedCache75']
assert v['activeController'] is None and not v['ownHeavyWorkloads']
assert read(ART/'tracking88-mousepad-polish-v1/session-consumed.json')['original_tool_result_consumed']
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert head == '87e648ffbbaea79b6e7c30f2b6a9b9df99298045'
status = subprocess.check_output(['git','status','--porcelain'],cwd=WORK,text=True)
names = subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
names += ['tools/tracking/test_plane_diagnostics.py']
hashes = {n:sha(WORK/n) for n in names}
inputs = [OLD, ART/'tracking88-real-planar-acquisition-v1/mouse-pad.avi']
for mode in ('no-corrections','periodic-manual-200'):
    inputs += [BASE/(mode+'.request.json'), BASE/mode/'observations.jsonl']
input_hashes = {str(p):sha(p) for p in inputs}
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
for name in ('plate_flow.py','test_plane_diagnostics.py'):
    (OUT/name).write_bytes((WORK/'tools/tracking'/name).read_bytes())
report = dict(status='running',head=head,dirty_source_status=status,source_sha256=hashes,
    input_sha256=input_hashes,started_utc=datetime.now(timezone.utc).isoformat(),
    in_flight=None,commands=[],comparisons=[])
env = dict(os.environ)
env.pop('MOTION_LOG',None)
env.update(TEMP='E:/Dev/aem/target/depth-wgsl-cache75-contract/tmp',
           TMP='E:/Dev/aem/target/depth-wgsl-cache75-contract/tmp',PYTHONDONTWRITEBYTECODE='1')
v.update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(
    kind='full original core equivalence and residual-context controls',head=head,
    sourceFrozen=True,dirtySourceHashes=hashes,output=str(OUT))])
write(CP,state)
def run(name,args):
    report['in_flight']=name
    write(OUT/'receipt.json',report)
    with (OUT/(name+'.stdout.log')).open('xb') as stdout, (OUT/(name+'.stderr.log')).open('xb') as stderr:
        p=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        row=dict(name=name,command=args,pid=p.pid,started_utc=datetime.now(timezone.utc).isoformat())
        report['commands'].append(row)
        write(OUT/'receipt.json',report)
        row['exit_code']=p.wait()
        row['completed_utc']=datetime.now(timezone.utc).isoformat()
    assert row['exit_code']==0, row
try:
    run('numeric-and-flow-controls',[CV,'-B','-m','unittest','discover','-s','tools/tracking','-p','test*.py','-v'])
    for pattern in ('test_ci_plate_tracking.py','test_ci_tracking_calibration.py'):
        run(pattern[:-3],[sys.executable,'-B','-m','unittest','discover','-s','tools','-p',pattern,'-v'])
    for mode in ('no-corrections','periodic-manual-200'):
        run(mode,[CV,'-B',str(OLD),'--core',str(BASE/(mode+'.request.json')),str(OUT/mode)])
        before=(BASE/mode/'observations.jsonl').read_text(encoding='utf-8').splitlines()
        after=(OUT/mode/'observations.jsonl').read_text(encoding='utf-8').splitlines()
        assert len(before)==len(after)==6946
        changed=0
        for a,b in zip(before,after):
            a,b=json.loads(a),json.loads(b)
            for prior,current in zip(a['tracks'],b['tracks']):
                if current['reason']!=prior['reason']:
                    assert current['reason'].startswith(prior['reason']+': ')
                    assert len(current['reason'])<=256
                    current['reason']=prior['reason']
                    changed+=1
            assert a==b
        log=(OUT/mode/'tracking.log').read_text(encoding='utf-8')
        stderr=(OUT/(mode+'.stderr.log')).read_text(encoding='utf-8')
        assert (OUT/(mode+'.stdout.log')).stat().st_size==0
        assert 'INFO start operation=mousepad_full_core' in log and ' DEBUG ' not in log
        errors=[line.split('ERROR ',1)[1] for line in log.splitlines() if 'ERROR ' in line]
        assert errors==[line.removeprefix('ERROR ') for line in stderr.splitlines()]
        if mode=='no-corrections':
            plane=[line for line in errors if 'track=plane ' in line]
            assert len(plane)==1 and 'source_index=73 occurrences=60' in plane[0]
            assert 'inliers=96 fit=146 ratio=0.657534 minimum_count=12 minimum_ratio=0.7' in plane[0]
        report['comparisons'].append(dict(mode=mode,frames=6946,geometry_confidence_visibility_manual_pts_exact=True,
            bounded_reason_extensions=changed,error_file_stderr_exact=True,stdout_bytes=0,error_records=len(errors)))
    report['status']='full_core_geometry_exact_numeric_causes_default_file_stderr_verified'
except BaseException:
    report.update(status='failed_original_outputs_retained',cause=traceback.format_exc())
finally:
    report.update(in_flight=None,completed_utc=datetime.now(timezone.utc).isoformat(),
        source_unchanged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head
        and subprocess.check_output(['git','status','--porcelain'],cwd=WORK,text=True)==status
        and all(sha(WORK/n)==h for n,h in hashes.items()),
        inputs_unchanged=all(sha(Path(n))==h for n,h in input_hashes.items()))
    write(OUT/'receipt.json',report)
    print(json.dumps({k:report.get(k) for k in ('status','source_unchanged','inputs_unchanged','comparisons','cause')}))
raise SystemExit(0 if report['status'].startswith('full_core_geometry_exact') and report['source_unchanged'] and report['inputs_unchanged'] else 1)
