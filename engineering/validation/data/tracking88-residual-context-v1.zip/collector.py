"""Publish authored code, aggregate diagnostics and original logs, never imagery."""
from pathlib import Path
import hashlib
import json
import zipfile

ART=Path('E:/Dev/aem/artifacts/pr-queue')
WORK=Path('E:/Dev/aem/.worktrees/planar-tracker88')
OUT=ART/'tracking88-residual-context-public-v1'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
OUT.mkdir(exist_ok=False)
files={}
for name in ('hypothesis','polish'):
    root=ART/('tracking88-mousepad-'+name+'-v1')
    r=read(root/'receipt.json')
    consumed=read(root/'session-consumed.json')
    assert consumed['original_tool_result_consumed'] and consumed['source_freeze_released']
    row=r['rows'][-1]
    summary={k:r[k] for k in ('status','head','source_video_sha256','baseline_sha256','scope',
        'observation_equivalence','source_unchanged','input_unchanged')}
    summary['selected_first_loss']=row
    summary['source_sha256']={k:v for k,v in r['source_sha256'].items() if k in (
        'tools/tracking/plate_flow.py','tools/tracking/plate_contract.py','tools/tracking/track_plate.py')}
    files[name+'/summary.json']=(json.dumps(summary,indent=2)+'\n').encode()
    for n in ('controller.py','observation.log','decode.stderr.log','session-consumed.json'):
        files[name+'/'+n]=(root/n).read_bytes()
root=ART/'tracking88-residual-context-v1'
r=read(root/'receipt.json')
consumed=read(root/'session-consumed.json')
assert consumed['original_tool_result_consumed'] and consumed['source_freeze_released']
for n,digest in consumed['files'].items():
    assert sha((root/n).read_bytes())==digest
summary={k:v for k,v in r.items() if k!='source_sha256'}
summary['source_sha256']={k:v for k,v in r['source_sha256'].items() if k.startswith('tools/tracking/')}
files['verification/summary.json']=(json.dumps(summary,indent=2)+'\n').encode()
for n in ('controller.py','session-consumed.json','plate_flow.py','test_plane_diagnostics.py'):
    files['verification/'+n]=(root/n).read_bytes()
for p in root.glob('*.log'):
    files['verification/'+p.name]=p.read_bytes()
for name in ('no-corrections','periodic-manual-200'):
    for n in ('tracking.log','report.json','decode.stderr.log'):
        path=root/name/n
        if path.exists():
            files['verification/'+name+'/'+n]=path.read_bytes()
files['rejected-fit-only-candidate.py']=(ART/'tracking88-plane-fit-candidate-v1.py').read_bytes()
files['collector.py']=Path(__file__).read_bytes()
assert len(files)==len(set(files))
for name in files:
    assert not name.endswith(('.avi','.png','.zip','.mstrack','.jsonl'))
archive=OUT/'tracking88-residual-context-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()):
        z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and sorted(z.namelist())==sorted(files)
    assert all(z.read(name)==data for name,data in files.items())
manifest=dict(bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members=len(files),
    scope='Authored diagnostics and unchanged-gate observation context; rejected local fit is not product code',
    excluded=['Original media','Annotations','Images','Requests','Full observations and PTS','Copied source pages'],
    files={n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())})
target=WORK/'engineering/validation/data'/archive.name
assert not target.exists()
target.write_bytes(archive.read_bytes())
assert sha(target.read_bytes())==manifest['sha256']
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    assert all(sha(z.read(n))==m['sha256'] and len(z.read(n))==m['bytes'] for n,m in manifest['files'].items())
target.with_suffix('.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:manifest[k] for k in ('bytes','sha256','members')}))
