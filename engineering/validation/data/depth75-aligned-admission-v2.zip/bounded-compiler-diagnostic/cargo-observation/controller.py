from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,re
root=Path("E:/Dev/aem")
w=root/".worktrees/depth-transition75"
out=root/"artifacts/pr-queue/depth75-rustc-observer-v1/cargo-observation"
assert shutil.disk_usage(root).free>=10<<30
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=w,text=True).strip()=="522bd1cae9f9b1e3dabf86142bdfee10894b1607"
files=subprocess.check_output(["git","ls-files"],cwd=w,text=True).splitlines()+["crates/motion-host/src/depth/transition/admission.rs","crates/motion-host/tests/depth_aligned_admission.rs"]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
snapshot=lambda:{n:sha(w/n) for n in sorted(set(files))}
before=snapshot()
targets=["depth_alignment","depth_transition","depth_transition_jobs","depth_routing","depth_aligned_admission"]
names=[]
for name in targets:
 names+=re.findall(r"#\[test\]\s*fn (\w+)",(w/f"crates/motion-host/tests/{name}.rs").read_text())
assert len(names)==len(set(names))==41
out.mkdir(exist_ok=False)
(out/"controller.py").write_bytes(Path(__file__).read_bytes())
assert json.loads((root/"artifacts/pr-queue/depth75-rustc-observer-v1/fault-control/receipt.json").read_text())["status"]=="owned_fault_wrapper_qualified"
assert json.loads((root/"artifacts/pr-queue/depth75-aligned-admission-native-v2/session-consumed.json").read_text())["exitCode"]==1
env=os.environ.copy()
env.update(RUSTC_WORKSPACE_WRAPPER=str(root/"artifacts/pr-queue/depth75-rustc-observer-v1/wrapper.exe"),MOTION_RUSTC_OBSERVATION=str(out),MOTION_RUSTC_OBSERVER_EXE=str(root/"artifacts/pr-queue/depth75-native-startup-observation-v1/observer.exe"))
env.update(CARGO_HOME=str(root/".tools/prerender-cargo-home"),CARGO_TARGET_DIR=str(root/"target/colmap88-isolated-check"),CARGO_INCREMENTAL="0",CARGO_BUILD_JOBS="1",CARGO_PROFILE_DEV_DEBUG="0",CARGO_PROFILE_TEST_DEBUG="0",TEMP=str(out/"tmp"),TMP=str(out/"tmp"),LOCALAPPDATA=str(out/"appdata"))
(out/"tmp").mkdir()
command=["cargo","test","--locked","-p","motion-host","--features","ai-depth"]
for target in targets: command += ["--test",target]
command += ["--","--test-threads=1"]
r=dict(status="running",base="522bd1cae9f9b1e3dabf86142bdfee10894b1607",source=before,command=command,expectedNames=names,startedUtc=datetime.now(timezone.utc).isoformat())
def save(): (out/"receipt.json").write_text(json.dumps(r,indent=2)+"\n")
save()
with (out/"stdout.log").open("wb") as stdout,(out/"stderr.log").open("wb") as stderr:
 child=subprocess.Popen(command,cwd=w,env=env,stdout=stdout,stderr=stderr)
 r["pid"]=child.pid;save();r["exitCode"]=child.wait()
text=(out/"stdout.log").read_text()
r["sourceUnchanged"]=snapshot()==before
r["namedPasses"]=[n for n in names if len(re.findall(r"(?m)^test "+re.escape(n)+r" \.\.\. ok$",text))==1]
events=out/"owned-rustc/events.log"
r["observerEventsPresent"]=events.exists()
r["diagnosticLimits"]=["Single bounded diagnostic of owned motion_host rustc launched by Cargo with original inherited build environment", "Workspace compiler wrapper/debug observer can alter metadata and timing; this is not ordinary final native acceptance", "No feature/assertion/timeout/GPU/backend changes or compiler retry loop; original ordinary failure remains authoritative"]
r["completedUtc"]=datetime.now(timezone.utc).isoformat()
r["status"]="diagnostic41_completed_original_compiler_crash_unresolved" if r["exitCode"]==0 and len(r["namedPasses"])==41 and r["sourceUnchanged"] and r["observerEventsPresent"] else "failed_original_outputs_retained"
save()
print(json.dumps({k:v for k,v in r.items() if k not in ("source","expectedNames","command")}))
raise SystemExit(0 if r["status"]=="diagnostic41_completed_original_compiler_crash_unresolved" else 1)
