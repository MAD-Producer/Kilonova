#include <windows.h>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <regex>
#include <io.h>
#include <fcntl.h>
static std::wstring quote(const wchar_t* text) {
    std::wstring out = L"\""; size_t slashes = 0;
    for (; *text; ++text) {
        if (*text == L'\\') { ++slashes; continue; }
        if (*text == L'\"') { out.append(slashes * 2 + 1, L'\\'); out += *text; }
        else { out.append(slashes, L'\\'); out += *text; }
        slashes = 0;
    }
    out.append(slashes * 2, L'\\'); out += L'\"'; return out;
}

static std::wstring env(const wchar_t* name) { wchar_t value[32768]={}; DWORD n=GetEnvironmentVariableW(name,value,32768); if(n>=32768) return L""; return value; }
static DWORD launch(const std::wstring& exe,std::wstring command,HANDLE output,HANDLE errors) {
 STARTUPINFOW si={};si.cb=sizeof si;si.dwFlags=STARTF_USESTDHANDLES;
 si.hStdOutput=output;si.hStdError=errors;si.hStdInput=GetStdHandle(STD_INPUT_HANDLE);
 PROCESS_INFORMATION pi={};if(!CreateProcessW(exe.c_str(),command.data(),nullptr,nullptr,TRUE,CREATE_NO_WINDOW,nullptr,nullptr,&si,&pi))return 109;
 WaitForSingleObject(pi.hProcess,INFINITE);DWORD code=111;GetExitCodeProcess(pi.hProcess,&code);CloseHandle(pi.hThread);CloseHandle(pi.hProcess);return code;
}
int wmain(int argc,wchar_t** argv) {
 if(argc<2 || std::filesystem::path(argv[1]).filename()!=L"rustc.exe")return 102;
 bool selected=false; for(int i=2;i+1<argc;++i) if(std::wstring(argv[i])==L"--crate-name" && std::wstring(argv[i+1])==L"motion_host")selected=true;
 std::wstring cmd=quote(argv[1]);for(int i=2;i<argc;++i)cmd+=L" "+quote(argv[i]);
 if(!selected)return launch(argv[1],cmd,GetStdHandle(STD_OUTPUT_HANDLE),GetStdHandle(STD_ERROR_HANDLE));
 auto root=std::filesystem::path(env(L"MOTION_RUSTC_OBSERVATION")); auto out=root/L"owned-rustc";
 if(!root.is_absolute() || !CreateDirectoryW(out.c_str(),nullptr))return 103;
 {std::ofstream args(out/L"command.utf16",std::ios::binary);args.write(reinterpret_cast<const char*>(cmd.data()),cmd.size()*sizeof(wchar_t));}
 {std::ofstream vars(out/L"environment.utf16",std::ios::binary); for(auto key:{L"CARGO_MANIFEST_DIR",L"OUT_DIR",L"CARGO_PKG_NAME",L"CARGO_PKG_VERSION"}) {std::wstring line=std::wstring(key)+L"="+env(key)+L"\n";vars.write(reinterpret_cast<const char*>(line.data()),line.size()*sizeof(wchar_t));}}
 SECURITY_ATTRIBUTES a={sizeof a,nullptr,TRUE};
 HANDLE output=CreateFileW((out/L"observer.stdout.log").c_str(),GENERIC_WRITE,FILE_SHARE_READ,&a,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);
 HANDLE errors=CreateFileW((out/L"observer.stderr.log").c_str(),GENERIC_WRITE,FILE_SHARE_READ,&a,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);
 auto observer=env(L"MOTION_RUSTC_OBSERVER_EXE");
 std::wstring observed=quote(observer.c_str())+L" "+quote(argv[1])+L" "+quote(out.c_str());
 for(int i=2;i<argc;++i)observed+=L" "+quote(argv[i]);
 DWORD observerCode=launch(observer,observed,output,errors);CloseHandle(output);CloseHandle(errors);
 _setmode(_fileno(stdout),_O_BINARY);_setmode(_fileno(stderr),_O_BINARY);
 {std::ifstream f(out/L"target.stdout.log",std::ios::binary);if(f.peek()!=EOF)std::cout<<f.rdbuf();}
 {std::ifstream f(out/L"target.stderr.log",std::ios::binary);if(f.peek()!=EOF)std::cerr<<f.rdbuf();}
 std::ifstream f(out/L"events.log");std::string events((std::istreambuf_iterator<char>(f)),{});std::smatch m;
 if(!std::regex_search(events,m,std::regex("target exit=0x([0-9a-f]+)")))return observerCode?observerCode:104;
 return static_cast<DWORD>(std::stoul(m[1].str(),nullptr,16));
}
