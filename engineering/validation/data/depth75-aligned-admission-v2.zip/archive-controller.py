from pathlib import Path
import hashlib, json, zipfile, shutil
root=Path('E:/Dev/aem');base=root/'artifacts/pr-queue';work=root/'.worktrees/depth-transition75'
native=base/'depth75-aligned-admission-native-v3';red=base/'depth75-aligned-file-v1';green=base/'depth75-aligned-file-v2'
read=lambda p:json.loads(p.read_text())
n=read(native/'receipt.json');g=read(green/'receipt.json');r=read(red/'receipt.json')
assert n['status']=='all41_controls_passed' and len(n['namedPasses'])==41 and n['sourceUnchanged']
assert read(native/'session-consumed.json')['session']==80770 and read(native/'session-consumed.json')['exitCode']==0
assert g['status']=='actual_blocked_start_and_error_channels_passed' and g['sourceUnchanged']
assert read(green/'session-consumed.json')['session']==9607 and read(green/'session-consumed.json')['exitCode']==0
assert r['status']=='failed_original_outputs_retained' and r['stages'][-1]['exitCode']==101
assert read(red/'session-consumed.json')['exitCode']==1
members={}
for directory,prefix,names in (
 (native,'native41',('controller.py','receipt.json','session-consumed.json','stdout.log','stderr.log')),
 (red,'file-before-flush',('controller.py','receipt.json','session-consumed.json','actual.stdout.log','actual.stderr.log','execution/logs/motion-studio.log')),
 (green,'file-after-flush',('controller.py','receipt.json','session-consumed.json','metadata.stdout.log','metadata.stderr.log','build.stdout.log','build.stderr.log','actual.stdout.log','actual.stderr.log','execution/logs/motion-studio.log'))):
 for name in names:members[prefix+'/'+name]=(directory/name).read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ('crates/motion-host/src/depth/transition.rs','crates/motion-host/src/depth/transition/admission.rs','crates/motion-host/tests/depth_aligned_admission.rs','desktop/app/src/logging/sink.rs'):
 raw=(work/name).read_bytes();assert sha(raw)==n['source'][name]==g['source'][name];members['source/'+name]=raw
fixture=base/'depth75-aligned-file-source'
for name in ('Cargo.toml','Cargo.lock','src/main.rs'):members['fixture/'+name]=(fixture/name).read_bytes()
previous=base/'depth75-aligned-admission-native-v2'
assert read(previous/'receipt.json')['exitCode']==101
for name in ('controller.py','receipt.json','session-consumed.json','stdout.log','stderr.log'):
 members['previous-native-compiler-failure/'+name]=(previous/name).read_bytes()
diag=base/'depth75-rustc-observer-v1'
for name in ('wrapper.cpp','first-wrapper-build.json','host-memory.json','fault-control/receipt.json','cargo-observation/controller.py','cargo-observation/receipt.json','cargo-observation/session-consumed.json','cargo-observation/stdout.log','cargo-observation/stderr.log','cargo-observation/owned-rustc/events.log','cargo-observation/owned-rustc/target.stdout.log','cargo-observation/owned-rustc/target.stderr.log','cargo-observation/owned-rustc/command.utf16','cargo-observation/owned-rustc/environment.utf16'):
 members['bounded-compiler-diagnostic/'+name]=(diag/name).read_bytes()
members['archive-controller.py']=Path(__file__).read_bytes()
m=dict(schema=1,base=n['base'],status='actual41_controls_and_default_blocked_file_error_channels_passed',
 namedPasses=41,sourceDelta={p:sha(raw) for p,raw in members.items() if p.startswith('source/')},
 limits=['Source delta over32d3c860; not a fresh full workspace pass or cross-platform qualification of this delta',
 'Actual Jobs provide authoritative prepared pixel fingerprints; synthetic values qualify mechanism, not scene quality',
 'Original pre-flush file failure is retained with actual101 exit; identical blocking fixture passes after flush',
 'One reference and candidate per Admission; no global cache quota, persistent identity or export policy',
 'Session installation, capability/tier selection, real video transitions and thermal/other hardware remain pending',
 'Original ordinary rustc access violation remains unexplained; diagnostic/debugger41 and later ordinary41 are separate records',
 'No panels/UI, Android, dependency, model distribution or source-media change'],
 members={p:dict(bytes=len(raw),sha256=sha(raw)) for p,raw in members.items()})
out=base/'depth75-aligned-public-v2';out.mkdir(exist_ok=False)
a=out/'depth75-aligned-admission-v2.zip'
with zipfile.ZipFile(a,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.writestr('manifest.json',json.dumps(m,indent=2))
 for p,raw in members.items():z.writestr(p,raw)
with zipfile.ZipFile(a) as z:
 assert set(z.namelist())=={'manifest.json',*members}
 for p,raw in members.items():assert z.read(p)==raw
m['archive']=dict(file=a.name,bytes=a.stat().st_size,sha256=sha(a.read_bytes()),verifiedMembers=len(members)+1)
j=out/'depth75-aligned-admission-v2.json';j.write_text(json.dumps(m,indent=2)+'\n')
for p in (a,j):shutil.copyfile(p,work/'engineering/validation/data'/p.name)
print(json.dumps(m['archive']))
