This is delivery/correctness validation, not a new performance measurement.
Measured native source: df046e09ae2ca51298bbfc4235f60f5a518bdaa7; delivery tested source: 1092420cb189ec0c0d7fae7103d50d83a6c56175
Full-backtrace diagnostic source: 98e84762fd4d15bed4dd19203a6674aacc5cfa91
The original non-unwinding abort remains unresolved; a later pass did not establish its cause or a fix.
Ignored explicit performance studies are recorded separately from default tests.
All original measured evidence remains in the separate immutable df046e09 archive.
