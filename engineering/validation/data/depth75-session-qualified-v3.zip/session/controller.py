"""Execute actual Session controls only after the current full native run is consumed."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,time,traceback
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/depth-session75';OUT=ROOT/'artifacts/pr-queue/depth75-session-native-v3'
prior=ROOT/'artifacts/pr-queue/depth75-aligned-workspace-v5'
r=json.loads((prior/'receipt.json').read_text(encoding='utf-8'))
c=json.loads((prior/'session-consumed.json').read_text(encoding='utf-8-sig'))
assert r['status']=='complete_maintained_workspace_passed' and r['sourceUnchanged'] and r['exitCode']==0
assert c['session']==63614 and c['exitCode']==0 and c['status']=='terminal_consumed'
assert shutil.disk_usage(ROOT).free>=10<<30
assert 'RUSTC_WRAPPER' not in os.environ and 'RUSTC_WORKSPACE_WRAPPER' not in os.environ
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert head=='1a939a3dd71d4d37b6635fcbf8b035d615bd67b2'
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
def identity():return {n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in paths}
source=identity();OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy()
for k in list(env):
 if k.startswith('MOTION_'):env.pop(k,None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/depth75-post-restart-validation'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'appdata'),TEMP=str(ROOT/'target/depth75-post-restart-validation/tmp'),TMP=str(ROOT/'target/depth75-post-restart-validation/tmp'))
Path(env['TEMP']).mkdir(parents=True,exist_ok=True)
command=['cargo','test','--locked','-p','motion-host','--features','ai-depth','--test','depth_session','--','--test-threads=1']
names=['session_transition_capacity_refusal_preserves_reference_and_explicit_recovery','session_transition_composes_saved_camera_z_and_inverse_calibration_without_changing_authoring_data','session_transition_decodes_managed_image_and_samples_affine_result_without_relabeling','session_transition_refuses_changed_file_pixels_and_recovers_only_after_explicit_raw_request','session_transition_preserves_backend_cause_without_retries_or_raw_fallback','session_transition_seek_revokes_a_candidate_blocked_inside_its_actual_backend','session_transition_rejects_missing_reference_invalid_limits_and_backward_clock']
report=dict(status='running',baseCommit=head,source=source,command=command,startedUtc=datetime.now(timezone.utc).isoformat(),expectedNewControls=names,limits=['All original tests in depth_session are selected, not only the seven new controls','Original numerical assertions, features, GPU/backend, ignores, timeout and10GiB admission unchanged','Complete host/workspace, complete renderer depth_surface and Session capture with gpu-tests and actual default-file probes remain separate obligations; no executed Scene/video/export quality claim'])
def save():
 q=OUT/'receipt.pending.json';q.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(q,OUT/'receipt.json')
save();began=time.monotonic()
try:
 with (OUT/'stdout.log').open('wb') as out,(OUT/'stderr.log').open('wb') as err:
  child=subprocess.Popen(command,cwd=WORK,env=env,stdout=out,stderr=err);report['pid']=child.pid;save();report['exitCode']=child.wait()
 stdout=(OUT/'stdout.log').read_text(encoding='utf-8',errors='replace')
 stderr=(OUT/'stderr.log').read_text(encoding='utf-8',errors='replace')
 summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
 report['summaries']=summaries
 report['namedPasses']=[n for n in names if len(re.findall(r'(?m)^test transitions::'+re.escape(n)+r' \.\.\. ok$',stdout))==1]
 report['failedTestNames']=re.findall(r'^test (.+?) \.\.\. FAILED$',stdout,re.M)
 report['abnormalNativeExits']=[n for n in stderr.splitlines() if "process didn't exit successfully:" in n]
 report['status']='all_session_tests_and_seven_new_controls_passed' if report['exitCode']==0 and len(summaries)==1 and summaries[0][0]=='ok' and summaries[0][2]=='0' and summaries[0][5]=='0' and len(report['namedPasses'])==7 and not report['abnormalNativeExits'] else 'failed_original_outputs_retained'
except BaseException as e:report.update(status='observer_failed_original_outputs_retained',cause=repr(e),traceback=traceback.format_exc())
finally:
 report.update(sourceUnchanged=identity()==source,elapsedSeconds=round(time.monotonic()-began,3),completedUtc=datetime.now(timezone.utc).isoformat())
 report['logs']={n:dict(bytes=(OUT/n).stat().st_size,sha256=hashlib.sha256((OUT/n).read_bytes()).hexdigest()) for n in ['stdout.log','stderr.log'] if (OUT/n).exists()};save()
print(json.dumps({k:v for k,v in report.items() if k!='source'}))
raise SystemExit(0 if report['status']=='all_session_tests_and_seven_new_controls_passed' and report['sourceUnchanged'] else 1)
