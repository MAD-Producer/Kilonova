"""Run both complete depth targets with actual GPU controls, after Session preflight."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, time, traceback
ROOT=Path('E:/Dev/aem'); WORK=ROOT/'.worktrees/depth-session75'
PRIOR=ROOT/'artifacts/pr-queue/depth75-session-native-v3'
OUT=ROOT/'artifacts/pr-queue/depth75-session-render-gpu-v1'
prior=json.loads((PRIOR/'receipt.json').read_text(encoding='utf-8'))
consumed=json.loads((PRIOR/'session-consumed.json').read_text(encoding='utf-8-sig'))
assert prior['status']=='all_session_tests_and_seven_new_controls_passed' and prior['sourceUnchanged']
assert consumed['status']=='terminal_consumed' and consumed['exitCode']==0
assert shutil.disk_usage(ROOT).free>=10<<30
assert 'RUSTC_WRAPPER' not in os.environ and 'RUSTC_WORKSPACE_WRAPPER' not in os.environ
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
def identity(): return {p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in paths}
source=identity(); assert source==prior['source'], 'Source changed after Session preflight'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
OUT.mkdir(exist_ok=False); (OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy()
for key in list(env):
    if key.startswith('MOTION_'): env.pop(key,None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT/'target/depth75-post-restart-validation'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT/'appdata'), TEMP=str(ROOT/'target/depth75-post-restart-validation/tmp'),
           TMP=str(ROOT/'target/depth75-post-restart-validation/tmp'))
stages=[('render', ['cargo','test','--locked','-p','motion-render','--features','gpu-tests','--test','depth_surface','--','--test-threads=1'],
          ['aligned::aligned_geometry_rechecks_original_saved_calibration_source_and_metric_observations',
           'aligned::aligned_candidate_preserves_actual_rendered_geometry_and_owned_image_after_source_replacement']),
        ('session', ['cargo','test','--locked','-p','motion-host','--features','ai-depth,gpu-tests','--test','depth_session','--','--test-threads=1'],
          ['transitions::'+n for n in prior['expectedNewControls']]+[
           'transitions::session_transition_capture_preserves_occlusion_and_owned_pixels_after_source_replacement'])]
report=dict(status='running', baseCommit=head,source=source,startedUtc=datetime.now(timezone.utc).isoformat(),stages=[],
            limits=['Exactly one own native workload; both full targets run serially with original assertions and actual GPU',
                    'No filtered or ignored test is accepted as a GPU result',
                    'No frozen export, model quality, video, thermal or complete workspace acceptance inferred'])
def save():
    pending=OUT/'receipt.pending.json';pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(pending,OUT/'receipt.json')
save(); began=time.monotonic()
try:
    for name, command, names in stages:
        assert shutil.disk_usage(ROOT).free>=10<<30, 'Original disk admission not met'
        stage=dict(name=name,command=command,expectedNewControls=names,status='running');report['stages'].append(stage);save()
        with (OUT/(name+'.stdout.log')).open('wb') as out,(OUT/(name+'.stderr.log')).open('wb') as err:
            child=subprocess.Popen(command,cwd=WORK,env=env,stdout=out,stderr=err);stage['pid']=child.pid;save();stage['exitCode']=child.wait()
        stdout=(OUT/(name+'.stdout.log')).read_text(encoding='utf-8',errors='replace')
        stderr=(OUT/(name+'.stderr.log')).read_text(encoding='utf-8',errors='replace')
        summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
        stage['summaries']=summaries
        stage['namedPasses']=[n for n in names if len(re.findall(r'(?m)^test '+re.escape(n)+r' \.\.\. ok$',stdout))==1]
        stage['failedTestNames']=re.findall(r'^test (.+?) \.\.\. FAILED$',stdout,re.M)
        stage['abnormalNativeExits']=[line for line in stderr.splitlines() if "process didn't exit successfully:" in line]
        stage['passed']=stage['exitCode']==0 and len(summaries)==1 and summaries[0][0]=='ok' and summaries[0][2]=='0' and summaries[0][3]=='0' and summaries[0][5]=='0' and len(stage['namedPasses'])==len(names) and not stage['abnormalNativeExits']
        stage['status']='passed' if stage['passed'] else 'failed_original_outputs_retained';save()
        if not stage['passed']: break
    report['status']='both_complete_targets_and_ten_new_controls_passed' if len(report['stages'])==2 and all(s['passed'] for s in report['stages']) else 'failed_original_outputs_retained'
except BaseException as error:
    report.update(status='observer_failed_original_outputs_retained',cause=repr(error),traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=identity()==source,elapsedSeconds=round(time.monotonic()-began,3),completedUtc=datetime.now(timezone.utc).isoformat())
    report['logs']={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in OUT.glob('*.log')};save()
print(json.dumps({k:v for k,v in report.items() if k!='source'}))
raise SystemExit(0 if report['status']=='both_complete_targets_and_ten_new_controls_passed' and report['sourceUnchanged'] else 1)
