$ErrorActionPreference='Stop'
Set-Location 'E:/Dev/aem/.worktrees/shared-menu-navigation'
. E:/Dev/aem/artifacts/multiple-camera-layers/env.ps1
$env:CARGO_TARGET_DIR='E:/Dev/aem/target/host-error-contract-verified'
$env:CARGO_BUILD_JOBS='1'
$env:MOTION_SHARED_MENU_EVIDENCE='E:/Dev/aem/artifacts/pr-ci-followups/shared-menu-final/native'
$outputRoot='E:/Dev/aem/artifacts/pr-ci-followups/shared-menu-final'
New-Item -ItemType Directory -Force -Path $outputRoot | Out-Null
$source=(& git rev-parse HEAD).Trim()
if(-not $source.StartsWith('4cfe6485')){throw "unexpected source $source"}
& git diff --quiet HEAD -- desktop
if($LASTEXITCODE -ne 0){throw 'dirty source'}
$results=[System.Collections.Generic.List[object]]::new()
function Run-Check([string]$name,[string[]]$arguments){
    Write-Output "start $name source=$source"
    $timer=[Diagnostics.Stopwatch]::StartNew()
    & cargo @arguments *> (Join-Path $outputRoot "$name.log")
    $status=$LASTEXITCODE
    $results.Add(@{name=$name;source=$source;arguments=$arguments;exit=$status;elapsed_ms=$timer.ElapsedMilliseconds})
    $results | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 (Join-Path $outputRoot 'results.json')
    Write-Output "done $name exit=$status elapsed=$($timer.Elapsed)"
    if($status -ne 0){throw "$name failed; preserve its log"}
}
Run-Check 'ui-menu' @('test','-p','motion-ui','--lib','--locked','--offline','widgets::menu')
$testArgs=@('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline')
Run-Check 'shared-navigation' ($testArgs+@('shared_menu','--','--test-threads=1'))
Run-Check 'layer-actions' ($testArgs+@('panels::layer_actions::tests','--','--test-threads=1'))
Run-Check 'effect-menu' ($testArgs+@('panels::effect_controls::removal_tests','--','--test-threads=1'))
Run-Check 'text-menu' ($testArgs+@('text_menu','--','--test-threads=1'))
Run-Check 'recent-effects' ($testArgs+@('recent_effect_menu_tests','--','--test-threads=1'))
Run-Check 'native-menu' ($testArgs+@('panels::layer_actions::tests::shared_native::shared_menu_native_root_child_shortcuts_checks_and_small_window_owners','--','--exact','--ignored','--nocapture','--test-threads=1'))
Run-Check 'build-ffmpeg' @('build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline')
Copy-Item -LiteralPath "$env:CARGO_TARGET_DIR/debug/motion-studio.exe" -Destination "$outputRoot/motion-studio.exe"
& "$outputRoot/motion-studio.exe" --help *> "$outputRoot/help.log"
if($LASTEXITCODE -ne 0){throw 'built executable --help failed'}
Get-FileHash -Algorithm SHA256 -LiteralPath "$outputRoot/motion-studio.exe" | ConvertTo-Json | Set-Content -Encoding utf8 "$outputRoot/binary.json"
& git diff --quiet HEAD -- desktop
if($LASTEXITCODE -ne 0){throw 'source changed during acceptance'}
Write-Output "all checks passed source=$source"
