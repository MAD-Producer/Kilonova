from pathlib import Path
import subprocess,json,hashlib,re,zipfile,shutil
from PIL import Image,ImageDraw

repo=Path('E:/Dev/aem/.worktrees/shared-menu-navigation')
run=Path('E:/Dev/aem/artifacts/pr-ci-followups/shared-menu-final-v4')
source='01c8fbf799d06b19cb835729fbdf82b61fc78340'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source
assert not subprocess.check_output(['git','diff','HEAD','--','desktop'],cwd=repo)
stages=json.loads((run/'results.json').read_text(encoding='utf-8-sig'))
assert isinstance(stages,list) and len(stages)==10
assert all(s['exit']==0 and s['source']==source for s in stages)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for s in stages:
    p=run/(s['name']+'.log')
    s['log_sha256']=digest(p)
    match=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',p.read_text(encoding='utf-8-sig'))
    if s['name']!='build-ffmpeg':
        assert match,s['name'];s['counts']=dict(zip(('passed','failed','ignored'),map(int,match.groups())))
ui_library=(run/'ui-library.log').read_text(encoding='utf-8-sig')
assert re.search(r'test result: ok\. 76 passed; 0 failed;',ui_library)
images=sorted((run/'native').glob('*.png'))
assert len(images)==30,len(images)
captures=[]
for p in images:
    image=Image.open(p).convert('RGB')
    probe=image.copy();probe.thumbnail((64,64))
    assert len(probe.getcolors(4096) or [])>3,p
    captures.append(dict(name=p.name,width=image.width,height=image.height,sha256=digest(p)))

assets=repo/'engineering/validation/shared-menu-navigation'
assets.mkdir(exist_ok=True)
for name in ['shared-menu-zh-floating-route-1x-root.png','shared-menu-zh-floating-route-1x-child.png','shared-menu-en-floating-route-1x-child.png','shared-menu-zh-main-1x-workspaces.png','shared-menu-en-main-1.5x-workspaces.png']:
    shutil.copyfile(run/'native'/name,assets/name)
# Derived previews contain only crops/resizing of our actual captures.
for language in ('zh','en'):
    p=run/'native'/f'shared-menu-{language}-main-1x-workspaces.png'
    im=Image.open(p)
    im.crop((0,0,1200,1000)).save(assets/f'shared-menu-{language}-workspaces-crop.png')
thumb_width,thumb_height=400,310
sheet=Image.new('RGB',(thumb_width*3,thumb_height*10),(28,28,30))
draw=ImageDraw.Draw(sheet)
for i,p in enumerate(images):
    im=Image.open(p).convert('RGB');im.thumbnail((thumb_width-12,thumb_height-38))
    x=(i%3)*thumb_width;y=(i//3)*thumb_height
    sheet.paste(im,(x+6,y+28));draw.text((x+6,y+6),p.stem.replace('shared-menu-',''),fill=(210,210,210))
sheet.save(assets/'contact-sheet.png')
changed=subprocess.check_output(['git','diff','--name-only','8c271bd361b0ecdd4d57e29d3bfe2d7ecaff5f4f',source],cwd=repo,text=True).splitlines()
source_files=[]
for name in changed:
    p=repo/name
    if p.is_file():source_files.append(dict(path=name,sha256=digest(p),git_blob=subprocess.check_output(['git','rev-parse',source+':'+name],cwd=repo,text=True).strip()))

archive=repo/'engineering/validation/data/shared-menu-navigation-evidence.zip'
archive.parent.mkdir(exist_ok=True)
entries={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    def put(p,name):z.write(p,name);entries[name]=digest(p)
    for p in run.rglob('*'):
        if p.is_file() and p.suffix not in ('.exe',):put(p,'final/'+p.relative_to(run).as_posix())
    for record in source_files:put(repo/record['path'],'source/'+record['path'])
    for p in Path('E:/Dev/aem/artifacts/pr-ci-followups/shared-menu-final').glob('*.log'):put(p,'earlier-frozen/'+p.name)
    for p in (run.parent/'shared-menu-final-v2').rglob('*'):
        if p.is_file() and p.suffix in ('.log','.json','.png'):put(p,'earlier-a1b9/'+p.relative_to(run.parent/'shared-menu-final-v2').as_posix())
    for p in (run.parent/'shared-menu-final-v3').rglob('*'):
        if p.is_file() and p.suffix in ('.log','.json','.png'):put(p,'superseded-b264/'+p.relative_to(run.parent/'shared-menu-final-v3').as_posix())
    for name in ('shared-menu-desktop-first.log','shared-menu-widget-first.log','shared-menu-widget-tests.log','shared-menu-regressions-first.log','verify-shared-menu.ps1','verify-shared-menu-v2.ps1','verify-shared-menu-v3.ps1','verify-shared-menu-v4.ps1','package-shared-menu.py'):
        p=run.parent/name;put(p,'reproduction/'+name)
    z.writestr('entries-sha256.json',json.dumps(entries,ensure_ascii=False,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,sha in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha,name
result=dict(schema_version=1,issue=276,source=source,base='8c271bd361b0ecdd4d57e29d3bfe2d7ecaff5f4f',stages=stages,ui_library=dict(passed=76,failed=0,sha256=digest(run/'ui-library.log'),source_equivalence=json.loads((run/'ui-library-source.json').read_text())),captures=captures,source_files=source_files,binary=json.loads((run/'binary.json').read_text(encoding='utf-8-sig')),evidence=dict(path='data/'+archive.name,sha256=digest(archive),bytes=archive.stat().st_size,entries=len(entries)+1),limits=['Controlled normalized input; not OS input injection into an independent floating window.','Rendering pixel ratios 1/1.5/2; no system DPI change.','Dedicated library/path/project popups retain their specialized layouts.','Counts overlap between filtered suites and must not be summed.'])
(repo/'engineering/validation/shared-menu-navigation-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(source=source,stages=[(s['name'],s.get('counts')) for s in stages],screens=len(images),evidence=result['evidence']),ensure_ascii=False,indent=2))
