"""Compile the portable control after quota acceptance; Linux ENOSPC stays pending."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/prerender-disk-cache'
OUT = ROOT / 'artifacts/pr-queue/prerender-full-volume-source-v4'
PROPOSAL = ROOT / 'artifacts/pr-queue/prerender-full-volume-proposal-v2'
PARENT = 7504
BASE = 'cd26ba2964569d765cafb34a89be079ac0506861'


def now():
    return datetime.now(timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode('utf-8').strip()


def sources():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: hashlib.sha256((WORK / name).read_bytes()).hexdigest()
            for name in sorted(set(names)) if name and (name.startswith(('crates/', 'desktop/'))
            or name.endswith(('.toml', '.rs', '.wgsl', '.json', '.py', '.yml', '.yaml', '.md'))
            or name == 'Cargo.lock') and not name.endswith(('.zip', '.pdf'))}


proposal = json.loads((PROPOSAL / 'receipt.json').read_text(encoding='utf-8'))
patch = PROPOSAL / 'full-volume.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest() == proposal['patchSha256']
assert git('rev-parse', 'HEAD') == BASE
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'controller.py')
report = dict(status='queued', startedUtc=now(), head=BASE, patchSha256=proposal['patchSha256'], steps=[],
    limits='Only portable test compilation, unchanged native component regression, actual Windows guard refusal and CI tool integration. Actual Linux bounded-volume ENOSPC MUST still execute in CI. No full-volume, P95, native crash fix or complete issue82 acceptance claim.')


def save():
    (OUT / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')


env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(PYTHONDONTWRITEBYTECODE='1',
           CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT / 'owned-profile'),
           TEMP=str(ROOT / 'target/ci-policy-validation-tmp'), TMP=str(ROOT / 'target/ci-policy-validation-tmp'))
expected = None


def step(name, command, counts=None, refusal=False):
    began = now()
    print(json.dumps(dict(start=name)), flush=True)
    with (OUT / f'{name}.stdout.log').open('wb') as stdout, (OUT / f'{name}.stderr.log').open('wb') as stderr:
        code = subprocess.run(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr).returncode
    output = (OUT / f'{name}.stdout.log').read_text(encoding='utf-8')
    errors = (OUT / f'{name}.stderr.log').read_text(encoding='utf-8')
    actual = re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', output)
    valid = (code == 1 and 'bounded-volume launcher is Linux-only' in errors) if refusal else code == 0
    if counts is not None:
        valid &= actual == [tuple(map(str, counts))]
    row = dict(name=name, command=command, startedUtc=began, completedUtc=now(), exitCode=code,
               counts=actual, sourceUnchanged=sources() == expected and git('rev-parse', 'HEAD') == BASE)
    row['passed'] = valid and row['sourceUnchanged']
    if not row['passed']:
        # Read only paths named by this exact Cargo invocation, not all cached
        # executables left by other historical worktrees.
        deps = (ROOT / 'target/gltf-animation87-contract/debug/deps').resolve()
        for raw in set(re.findall(r'([A-Za-z]:[^\n`"<>]*?\.exe)', errors)):
            exe = Path(raw.strip().strip('(')).resolve()
            if exe.parent != deps or not exe.name.startswith('motion_desktop_media-'):
                continue
            for original in (exe, exe.with_suffix('.pdb')):
                if not original.exists():
                    continue
                copy = OUT / 'failed-binaries' / name / original.name
                copy.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(original, copy)
                digest = hashlib.sha256(copy.read_bytes()).hexdigest()
                assert digest == hashlib.sha256(original.read_bytes()).hexdigest()
                row.setdefault('preservedFiles', []).append(dict(path=str(copy), sha256=digest))
    report['steps'].append(row)
    save()
    print(json.dumps(row), flush=True)
    assert row['passed'], f'{name}: original failure retained; no automatic retry'


kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
handle = None
save()
try:
    previous = json.loads((ROOT / 'artifacts/pr-queue/prerender-disk-quota-v4/exit.json').read_text(encoding='utf-8'))
    assert previous['status'] == 'running' and 'fixedSource' in previous
    stopped = json.loads((ROOT / 'artifacts/pr-queue/prerender-disk-quota-v4/controller-stopped-observation.json').read_text(encoding='utf-8'))
    assert stopped['toolExitCode'] == 1
    required = ['disk-inventory', 'disk-quota-original-negatives', 'disk-quota-fixed', 'disk-storage',
                'disk-worker', 'disk-native-foreground', 'disk-four-native-precisions', 'media-prerender-regression']
    assert [step['name'] for step in previous['steps']] == required
    assert all(step['passed'] and step['sourceUnchanged'] for step in previous['steps'])
    report['upstreamStopped'] = stopped
    report['upstream'] = {k: previous.get(k) for k in ['status', 'completedUtc', 'failure']}
    assert previous['steps'][1]['expectedNegative'] and previous['steps'][1]['exitCode'] == 101
    report['unresolvedRequiredGate'] = previous['unresolvedRequiredGate']
    assert sources() == previous['fixedSource']
    for name, digest in proposal['originalHashes'].items():
        assert hashlib.sha256((WORK / name).read_bytes()).hexdigest() == digest
    assert hashlib.sha256(patch.read_bytes()).hexdigest() == proposal['patchSha256']
    active = subprocess.check_output(['powershell', '-NoProfile', '-Command',
        "@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('rustc.exe','link.exe','cargo.exe') -and $_.CommandLine -match 'gltf-animation87-contract' }).Count"]).decode().strip()
    assert active == '0', f'serial target still active: {active}'
    subprocess.run(['git', 'apply', '--check', '--whitespace=error', str(patch)], cwd=WORK, check=True)
    subprocess.run(['git', 'apply', '--whitespace=error', str(patch)], cwd=WORK, check=True)
    expected = sources()
    changed = {n for n in expected if n not in previous['fixedSource'] or expected[n] != previous['fixedSource'][n]}
    assert changed == set(proposal['files'])
    report.update(status='running', releasedUtc=now(), source=expected)
    Path(env['LOCALAPPDATA']).mkdir()
    for name in ['crates/motion-render/src/lib.rs', 'crates/motion-desktop-media/src/lib.rs', 'desktop/app/src/main.rs']:
        os.utime(WORK / name, None)
    assert sources() == expected
    save()
    for optimized in [False, True]:
        label = 'optimized' if optimized else 'normal'
        destination = OUT / ('refused-' + label)
        command = [sys.executable, *(['-O'] if optimized else []), 'tools/validate_prerender_full_volume.py', '--artifacts', str(destination)]
        step('windows-refusal-' + label, command, refusal=True)
        assert not destination.exists()
    media = ['cargo', 'test', '-p', 'motion-desktop-media', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--lib']
    step('media-source-inventory', media + ['--', '--list'])
    listing = (OUT / 'media-source-inventory.stdout.log').read_text(encoding='utf-8')
    assert 'actual_full_volume_keeps_native_frames_project_bytes_and_recovery_intact: test' in listing
    step('disk-worker-regression', media + ['movie::prerender::worker::tests::disk_cache::', '--', '--test-threads=1'], counts=(4, 0, 2))
    step('media-prerender-regression', media + ['movie::prerender::', '--', '--test-threads=1'], counts=(63, 0, 3))
    desktop = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--bin', 'motion-studio']
    step('headless-disk-policy', desktop + ['mcp::prerender_tests::disk_cache::disk_policy_is_optional_bounded_read_only_guarded_and_does_no_headless_io', '--', '--exact', '--test-threads=1'], counts=(1, 0, 0))
    step('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline'])
    step('tool-inventory', [sys.executable, 'tools/validation_inventory.py'])
    step('existing-ci-tool-tests', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_ci_*.py'])
    step('provenance', [sys.executable, 'tools/validate_provenance.py'])
    step('whitespace', ['git', 'diff', '--check'])
    assert not any('/panels/' in n for n in git('diff', '--name-only').splitlines())
    report.update(status='accepted_portable_control_source_linux_and_native_sink_pending', completedUtc=now())
    save()
    (OUT / 'source-accepted.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
except BaseException as error:
    report.update(status='failed', completedUtc=now(), failure=repr(error))
    save()
    raise
finally:
    if handle:
        kernel.CloseHandle(handle)
