"""Source-frozen disk component gate, serialized behind exact combined owners."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/prerender-disk-cache'
OUT = ROOT / 'artifacts/pr-queue/prerender-disk-cache-v1'
BASE = 'cd26ba2964569d765cafb34a89be079ac0506861'
PARENTS = [26560, 37816]

def now():
    return datetime.now(timezone.utc).isoformat()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode('utf-8').strip()

def sources():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: hashlib.sha256((WORK / name).read_bytes()).hexdigest()
            for name in sorted(set(names)) if name and (name.startswith(('crates/', 'desktop/'))
            or name.endswith(('.toml', '.rs', '.wgsl', '.json', '.py', '.yml', '.yaml', '.md'))
            or name == 'Cargo.lock') and not name.endswith(('.zip', '.pdf'))}

assert git('rev-parse', 'HEAD') == BASE
assert git('branch', '--show-current') == 'feat/82-prerender-disk-cache'
assert not any('/panels/' in p for p in git('diff', '--name-only').splitlines())
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'controller.py')
source = sources()
report = dict(status='queued', head=BASE, source=source, startedUtc=now(), steps=[],
              limits='Disk component only, not whole issue82 acceptance. Physical disk-full, strict input P95, original native crash cause/disposition, final combined full regression and cross-platform CI remain open. No unchanged failed test rerun, assertion weakening or Android validation.')

def save():
    (OUT / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT / 'owned-profile'),
           MOTION_PRERENDER_DISK_LOG_ARTIFACTS=str(OUT / 'default-disk-logs'))

def retain_crash(name, stderr):
    if not re.search(r'0xc000[0-9a-f]+|STATUS_(?:ACCESS|ILLEGAL|STACK|HEAP)', stderr, re.I):
        return
    captured = []
    for raw in re.findall(r'([A-Za-z]:[^\n`"<>]*?\.exe)', stderr):
        path = Path(raw.strip().strip('('))
        try:
            path.resolve().relative_to((ROOT / 'target/gltf-animation87-contract').resolve())
        except ValueError:
            continue
        for original in [path, path.with_suffix('.pdb')]:
            if not original.is_file():
                continue
            destination = OUT / 'native-crash' / name / original.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, destination)
            digest = hashlib.sha256(original.read_bytes()).hexdigest()
            assert hashlib.sha256(destination.read_bytes()).hexdigest() == digest
            captured.append(dict(source=str(original), retained=str(destination), sha256=digest))
    report.setdefault('nativeFailures', []).append(dict(step=name, files=captured))

def step(name, args, counts=None, tests=False):
    print(json.dumps(dict(start=name)), flush=True)
    began = now()
    with (OUT / f'{name}.stdout.log').open('wb') as stdout, (OUT / f'{name}.stderr.log').open('wb') as stderr:
        code = subprocess.run(args, cwd=WORK, env=env, stdout=stdout, stderr=stderr).returncode
    output = (OUT / f'{name}.stdout.log').read_text(encoding='utf-8')
    errors = (OUT / f'{name}.stderr.log').read_text(encoding='utf-8')
    actual = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored', output)
    valid = not tests or bool(actual) and all(int(f) == 0 for _, f, _ in actual) and sum(int(p) for p, _, _ in actual) > 0
    if counts is not None:
        valid = actual == [tuple(map(str, counts))]
    row = dict(name=name, command=args, startedUtc=began, completedUtc=now(),
               exitCode=code, counts=actual, sourceUnchanged=sources() == source and git('rev-parse', 'HEAD') == BASE)
    row['passed'] = code == 0 and valid and row['sourceUnchanged']
    report['steps'].append(row)
    retain_crash(name, errors)
    save()
    print(json.dumps(row), flush=True)
    assert row['passed'], f'{name} failed; original output retained'

save()
handles = []
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
try:
    # Capture real handles now: PID reuse cannot release this dependency.
    for pid in PARENTS:
        handle = kernel.OpenProcess(0x00100000, False, pid)
        assert handle, f'expected exact live parent {pid}: {ctypes.get_last_error()}'
        handles.append((pid, handle))
    report['parents'] = [dict(pid=pid, handleCaptured=True,
                              live=kernel.WaitForSingleObject(handle, 0) == 258)
                         for pid, handle in handles]
    assert all(p['live'] for p in report['parents'])
    save()
    print(json.dumps(dict(queuedBehind=PARENTS, head=BASE)), flush=True)
    for pid, handle in handles:
        while True:
            result = kernel.WaitForSingleObject(handle, 1000)
            if result == 0:
                break
            assert result == 258, f'wait failed for {pid}: {result}'
    assert sources() == source, 'queued source changed'
    previous = json.loads((ROOT / 'artifacts/pr-queue/prerender-combined-v6/exit.json').read_text(encoding='utf-8'))
    assert previous.get('completedUtc'), 'parent ended without terminal evidence'
    report['priorCombined'] = {k: previous.get(k) for k in ['head', 'status', 'completedUtc']}
    active = subprocess.check_output(['powershell', '-NoProfile', '-Command',
        "@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('rustc.exe','link.exe','cargo.exe') -and $_.CommandLine -match 'gltf-animation87-contract' }).Count"]).decode().strip()
    assert active == '0', f'serial target still active: {active}'
    report['status'] = 'running'
    report['releasedUtc'] = now()
    Path(env['LOCALAPPDATA']).mkdir()
    touched = []
    for name in ['crates/motion-render/src/lib.rs', 'crates/motion-desktop-media/src/lib.rs', 'desktop/app/src/main.rs']:
        path = WORK / name
        before = path.stat().st_mtime_ns
        os.utime(path, None)
        touched.append(dict(path=name, before=before, after=path.stat().st_mtime_ns))
    report['timestampOnlyRefresh'] = touched
    assert sources() == source
    save()
    media = ['cargo', 'test', '-p', 'motion-desktop-media', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--lib']
    desktop = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--bin', 'motion-studio']
    step('media-source-inventory', media + ['--', '--list'])
    listing = (OUT / 'media-source-inventory.stdout.log').read_text(encoding='utf-8')
    for name in ['concurrent_cache_writer_skips_without_evicting_or_exceeding_payload_quota',
                 'disk_io_publishes_in_flight_before_entry_and_acknowledges_cancellation',
                 'disk_warm_worker_preserves_all_four_actual_native_precision_layouts',
                 'reopened_disk_hit_installs_current_native_pixels_without_foreground_disk_access']:
        assert name + ': test' in listing
    step('disk-storage', media + ['movie::prerender::disk::tests::', '--', '--test-threads=1'], counts=(9, 0, 0))
    step('disk-worker', media + ['movie::prerender::worker::tests::disk_cache::', '--', '--test-threads=1'], counts=(4, 0, 1))
    step('disk-native-foreground', media + ['movie::prerender::coordinator::tests::disk_cache::', '--', '--test-threads=1'], counts=(1, 0, 0))
    step('disk-four-native-precisions', media + ['movie::prerender::worker::tests::disk_cache::disk_warm_worker_preserves_all_four_actual_native_precision_layouts', '--', '--ignored', '--exact', '--test-threads=1'], counts=(1, 0, 0))
    step('media-prerender-regression', media + ['movie::prerender::', '--', '--test-threads=1'], counts=(60, 0, 2))
    step('desktop-source-inventory', desktop + ['--', '--list'])
    listing = (OUT / 'desktop-source-inventory.stdout.log').read_text(encoding='utf-8')
    for name in ['actual_disk_open_failure_escalates_once_at_default_file_and_stderr_without_stdout',
                 'disk_policy_is_optional_bounded_read_only_guarded_and_does_no_headless_io']:
        assert name + ': test' in listing
    step('default-disk-failure-sinks', desktop + ['engine::pending_video_tests::prerender_disk_logging::actual_disk_open_failure_escalates_once_at_default_file_and_stderr_without_stdout', '--', '--exact', '--test-threads=1'], counts=(1, 0, 0))
    step('headless-disk-policy', desktop + ['mcp::prerender_tests::disk_cache::disk_policy_is_optional_bounded_read_only_guarded_and_does_no_headless_io', '--', '--exact', '--test-threads=1'], counts=(1, 0, 0))
    step('existing-prerender-policy', desktop + ['mcp::prerender_tests::', '--', '--test-threads=1'], tests=True)
    step('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline'])
    step('provenance', [sys.executable, 'tools/validate_provenance.py'])
    step('tool-inventory', [sys.executable, 'tools/validation_inventory.py'])
    step('whitespace', ['git', 'diff', '--check'])
    report.update(status='accepted_component', completedUtc=now())
    save()
    (OUT / 'accepted.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
except BaseException as error:
    report.update(status='failed', completedUtc=now(), failure=repr(error))
    save()
    raise
finally:
    for _, handle in handles:
        kernel.CloseHandle(handle)
