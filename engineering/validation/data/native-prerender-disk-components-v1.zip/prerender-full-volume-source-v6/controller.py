from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, sys, shutil
ROOT = Path("E:/Dev/aem")
WORK = ROOT / ".worktrees/prerender-disk-cache"
PRIOR = ROOT / "artifacts/pr-queue/prerender-full-volume-source-v5"
OUT = ROOT / "artifacts/pr-queue/prerender-full-volume-source-v6"
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / "controller.py")
prior = json.loads((PRIOR / "exit.json").read_text(encoding="utf-8"))
assert prior["status"] == "failed" and prior.get("completedUtc")
assert prior["steps"][-1]["name"] == "test_ci_workflow.py"
assert all(row["passed"] for row in prior["steps"][:-1])
expected = prior["source"].copy()
workflow = ".github/workflows/ci.yml"
fixed_hash = hashlib.sha256((WORK/workflow).read_bytes()).hexdigest()
assert fixed_hash != expected[workflow]
expected[workflow] = fixed_hash
def verify():
    names = subprocess.check_output(["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"], cwd=WORK).decode().strip("\0").split("\0")
    actual = {n: hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in sorted(set(names)) if n and (n.startswith(("crates/", "desktop/")) or n.endswith((".toml", ".rs", ".wgsl", ".json", ".py", ".yml", ".yaml", ".md")) or n == "Cargo.lock") and not n.endswith((".zip", ".pdf"))}
    assert actual == expected
verify()
env=os.environ.copy()
env.update(PYTHONPATH=str(ROOT/".tools/build-validation-python"), PYTHONDONTWRITEBYTECODE="1", TEMP=str(ROOT/"target/ci-policy-validation-tmp"), TMP=str(ROOT/"target/ci-policy-validation-tmp"))
report=dict(status="running", startedUtc=datetime.now(timezone.utc).isoformat(), source=expected, steps=[], prior="prerender-full-volume-source-v5", limits="Existing pinned PyYAML6.0.3 environment plus non-PR-only evidence upload condition repair. After actual workflow-policy failure, only the two affected workflow modules are rechecked on the one-line CI condition repair. Rust/native controls are not rerun. Original assertions preserved. Native sink failure and actual Linux ENOSPC remain pending. Not complete issue82 acceptance.")
def save(): (OUT/"exit.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
def step(name,args):
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/(name+".stdout.log")).open("wb") as stdout,(OUT/(name+".stderr.log")).open("wb") as stderr:
        code=subprocess.run(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr).returncode
    verify()
    report["steps"].append(dict(name=name,command=args,exitCode=code,sourceUnchanged=True))
    save()
    assert code == 0, name
try:
    save()
    step("pinned-python-environment",[sys.executable,"-c","import yaml, importlib.metadata; assert yaml.__version__ == '6.0.3' and importlib.metadata.version('PyYAML') == '6.0.3'; print(yaml.__file__)"])
    for module in ["test_ci_desktop_release.py","test_ci_workflow.py"]:
        step(module,[sys.executable,"-m","unittest","discover","-s","tools","-p",module])
    step("provenance",[sys.executable,"tools/validate_provenance.py"])
    step("whitespace",["git","diff","--check"])
    report.update(status="accepted_portable_source_native_sink_and_linux_pending",completedUtc=datetime.now(timezone.utc).isoformat())
    save()
    (OUT/"source-accepted.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
except BaseException as error:
    report.update(status="failed",failure=repr(error),completedUtc=datetime.now(timezone.utc).isoformat())
    save()
    raise
print(json.dumps(dict(status=report["status"])),flush=True)
