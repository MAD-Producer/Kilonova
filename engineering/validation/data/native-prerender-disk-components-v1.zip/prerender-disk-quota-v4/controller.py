"""Prove quota defects before fixing them, behind the exact existing validators."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/prerender-disk-cache'
OUT = ROOT / 'artifacts/pr-queue/prerender-disk-quota-v4'
PROPOSAL = ROOT / 'artifacts/pr-queue/prerender-disk-quota-proposal-v2'
PARENT = 39564
BASE = 'cd26ba2964569d765cafb34a89be079ac0506861'
DISK = 'crates/motion-desktop-media/src/movie/prerender/disk.rs'
TESTS = 'crates/motion-desktop-media/src/movie/prerender/disk/tests.rs'
NEW = 'crates/motion-desktop-media/src/movie/prerender/disk/tests/quota_reopen.rs'


def now():
    return datetime.now(timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode('utf-8').strip()


def sources():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: hashlib.sha256((WORK / name).read_bytes()).hexdigest()
            for name in sorted(set(names)) if name and (name.startswith(('crates/', 'desktop/'))
            or name.endswith(('.toml', '.rs', '.wgsl', '.json', '.py', '.yml', '.yaml', '.md'))
            or name == 'Cargo.lock') and not name.endswith(('.zip', '.pdf'))}


original = json.loads((ROOT / 'artifacts/pr-queue/prerender-disk-cache-v4/exit.json').read_text(encoding='utf-8'))
proposal = json.loads((PROPOSAL / 'receipt.json').read_text(encoding='utf-8'))
assert sources() == original['source']
assert git('rev-parse', 'HEAD') == BASE
assert git('branch', '--show-current') == 'feat/82-prerender-disk-cache'
assert not (WORK / NEW).exists()
for name, digest in proposal['patches'].items():
    assert hashlib.sha256((PROPOSAL / name).read_bytes()).hexdigest() == digest
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'controller.py')
report = dict(status='queued', head=BASE, startedUtc=now(), steps=[],
              originalSource=original['source'], patches=proposal['patches'],
              limits='Quota component only. Only independent quota controls are qualified; completed native controls must pass, while the original desktop parser failure remains unresolved. Three new tests must fail for their original assertions, then pass unchanged after production-only fix. No old assertion edits, retry-to-green, physical full-volume claim, P95 claim, native crash fix claim or whole issue82 acceptance.')


def save():
    (OUT / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')


env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT / 'owned-profile'),
           TEMP=str(ROOT / 'target/ci-policy-validation-tmp'),
           TMP=str(ROOT / 'target/ci-policy-validation-tmp'),
           MOTION_PRERENDER_DISK_LOG_ARTIFACTS=str(OUT / 'default-disk-logs'))
expected_source = original['source']


def step(name, command, counts=None, negative=False):
    began = now()
    print(json.dumps(dict(start=name)), flush=True)
    with (OUT / f'{name}.stdout.log').open('wb') as stdout, (OUT / f'{name}.stderr.log').open('wb') as stderr:
        code = subprocess.run(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr).returncode
    output = (OUT / f'{name}.stdout.log').read_text(encoding='utf-8')
    errors = (OUT / f'{name}.stderr.log').read_text(encoding='utf-8')
    actual = re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', output)
    valid = actual == [tuple(map(str, counts))] if counts is not None else code == 0
    row = dict(name=name, command=command, startedUtc=began, completedUtc=now(), exitCode=code,
               counts=actual, expectedNegative=negative,
               sourceUnchanged=sources() == expected_source and git('rev-parse', 'HEAD') == BASE)
    row['passed'] = (code == 101 if negative else code == 0) and valid and row['sourceUnchanged']
    if negative:
        combined = output + errors
        for marker in ['reopening must enforce the new quota before a hit',
                       "one write exceeded the next scan's bound",
                       'a contending open must not skip initial quota admission']:
            row['passed'] &= marker in combined
        failed = re.findall(r'^test (.+?) \.\.\. FAILED\s*$', output, re.M)
        row['actualFailedTests'] = failed
        row['passed'] &= {n.rsplit('::', 1)[-1] for n in failed} == set(proposal['intendedNegatives'])
    report['steps'].append(row)
    # Retain the owned executable on any unexpected failure, including an
    # isolated child crash whose wrapper omits the numeric Windows exit code.
    if not row['passed']:
        retained = OUT / 'failed-binaries' / name
        retained.mkdir(parents=True)
        deps = (ROOT / 'target/gltf-animation87-contract/debug/deps').resolve()
        candidates = set(re.findall(r'([A-Za-z]:[^\n`"<>]*?\.exe)', errors))
        current = []
        for raw in candidates:
            exe = Path(raw.strip().strip('(')).resolve()
            if exe.parent == deps and exe.name.startswith(('motion_desktop_media-', 'motion_studio-')):
                current.append(exe)
        assert len(current) <= 2, 'unexpected executable inventory; preserve original logs'
        for exe in current:
            for original_file in (exe, exe.with_suffix('.pdb')):
                if not original_file.exists():
                    continue
                copy = retained / original_file.name
                shutil.copyfile(original_file, copy)
                digest = hashlib.sha256(copy.read_bytes()).hexdigest()
                assert digest == hashlib.sha256(original_file.read_bytes()).hexdigest()
                row.setdefault('preservedFiles', []).append(dict(path=str(copy), sha256=digest))
    save()
    print(json.dumps(row), flush=True)
    assert row['passed'], f'{name}: original output retained; no automatic retry'


kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
handle = None
save()
try:
    phase = json.loads((ROOT / 'artifacts/pr-queue/prerender-input-phases-v1/exit.json').read_text(encoding='utf-8'))
    disk = json.loads((ROOT / 'artifacts/pr-queue/prerender-disk-cache-v4/exit.json').read_text(encoding='utf-8'))
    assert phase.get('completedUtc') and disk.get('completedUtc'), 'parent evidence is not terminal'
    report['upstream'] = dict(disk={k: disk.get(k) for k in ['status', 'completedUtc']},
                              phases={k: phase.get(k) for k in ['status', 'completedUtc']})
    assert disk['status'] == 'failed' and disk.get('completedUtc')
    assert disk['failure'] == "AssertionError('default-disk-failure-sinks failed; original output retained')"
    for required in ['media-source-inventory', 'disk-storage', 'disk-worker', 'disk-native-foreground',
                     'disk-four-native-precisions', 'media-prerender-regression', 'desktop-source-inventory']:
        assert next(step for step in disk['steps'] if step['name'] == required)['passed']
    report['unresolvedRequiredGate'] = dict(gate='prerender-disk-cache-v4/default-disk-failure-sinks',
        disposition='Original native parser UB failure retained. Not retried unchanged or counted as passed.',
        remaining='Default desktop sink and original native crashes still require resolution before issue82 acceptance.')
    assert sources() == original['source']
    active = subprocess.check_output(['powershell', '-NoProfile', '-Command',
        "@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('rustc.exe','link.exe','cargo.exe') -and $_.CommandLine -match 'gltf-animation87-contract' }).Count"]).decode().strip()
    assert active == '0', f'serial target still active: {active}'
    for name, digest in proposal['patches'].items():
        assert hashlib.sha256((PROPOSAL / name).read_bytes()).hexdigest() == digest
        subprocess.run(['git', 'apply', '--check', '--whitespace=error', str(PROPOSAL / name)], cwd=WORK, check=True)
    subprocess.run(['git', 'apply', '--whitespace=error', str(PROPOSAL / 'tests.patch')], cwd=WORK, check=True)
    expected_source = sources()
    assert set(expected_source) - set(original['source']) == {NEW}
    assert {n for n in original['source'] if original['source'][n] != expected_source[n]} == {TESTS}
    test_hashes = {n: expected_source[n] for n in [TESTS, NEW]}
    report.update(status='running', releasedUtc=now(), negativeSource=expected_source, testHashes=test_hashes)
    Path(env['LOCALAPPDATA']).mkdir()
    for name in ['crates/motion-render/src/lib.rs', 'crates/motion-desktop-media/src/lib.rs', 'desktop/app/src/main.rs']:
        os.utime(WORK / name, None)
    assert sources() == expected_source
    save()
    media = ['cargo', 'test', '-p', 'motion-desktop-media', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--lib']
    desktop = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--bin', 'motion-studio']
    group = 'movie::prerender::disk::tests::quota_reopen::'
    step('disk-inventory', media + ['--', '--list'])
    listing = (OUT / 'disk-inventory.stdout.log').read_text(encoding='utf-8')
    assert all(group + n + ': test' in listing for n in proposal['intendedNegatives'])
    step('disk-quota-original-negatives', media + [group, '--', '--test-threads=1'], counts=(0, 3, 0), negative=True)
    subprocess.run(['git', 'apply', '--whitespace=error', str(PROPOSAL / 'production.patch')], cwd=WORK, check=True)
    fixed = sources()
    assert set(fixed) == set(expected_source)
    assert {n for n in fixed if fixed[n] != expected_source[n]} == {DISK}
    assert all(fixed[n] == digest for n, digest in test_hashes.items())
    expected_source = fixed
    report['fixedSource'] = fixed
    save()
    step('disk-quota-fixed', media + [group, '--', '--test-threads=1'], counts=(3, 0, 0))
    step('disk-storage', media + ['movie::prerender::disk::tests::', '--', '--test-threads=1'], counts=(12, 0, 0))
    step('disk-worker', media + ['movie::prerender::worker::tests::disk_cache::', '--', '--test-threads=1'], counts=(4, 0, 1))
    step('disk-native-foreground', media + ['movie::prerender::coordinator::tests::disk_cache::', '--', '--test-threads=1'], counts=(1, 0, 0))
    step('disk-four-native-precisions', media + ['movie::prerender::worker::tests::disk_cache::disk_warm_worker_preserves_all_four_actual_native_precision_layouts', '--', '--ignored', '--exact', '--test-threads=1'], counts=(1, 0, 0))
    step('media-prerender-regression', media + ['movie::prerender::', '--', '--test-threads=1'], counts=(63, 0, 2))
    step('headless-disk-policy', desktop + ['mcp::prerender_tests::disk_cache::disk_policy_is_optional_bounded_read_only_guarded_and_does_no_headless_io', '--', '--exact', '--test-threads=1'], counts=(1, 0, 0))
    step('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline'])
    step('provenance', [sys.executable, 'tools/validate_provenance.py'])
    step('whitespace', ['git', 'diff', '--check'])
    assert not any('/panels/' in n for n in git('diff', '--name-only').splitlines())
    report.update(status='accepted_quota_controls_native_sink_unresolved', completedUtc=now())
    save()
    (OUT / 'quota-controls.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
except BaseException as error:
    report.update(status='failed', completedUtc=now(), failure=repr(error))
    save()
    raise
finally:
    if handle:
        kernel.CloseHandle(handle)
