"""Retain the original failed cohort before correcting the caller identity check."""
from pathlib import Path
import hashlib, json, subprocess, zipfile
ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
OUT=BASE/'depth75-reference-onnx266-v1'
receipt=json.loads((OUT/'receipt.json').read_text())
assert receipt['status']=='failed_original_outputs_retained' and receipt['exit_code']==1 and receipt['source_unchanged']
assert receipt['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
def sha(raw):return hashlib.sha256(raw).hexdigest()
for name,digest in receipt['source_sha256'].items():assert sha((WORK/name).read_bytes())==digest,name
(OUT/'session-consumed.json').write_text(json.dumps(dict(session=22317,consumed=True,exit_code=1))+'\n')
partial=json.loads((OUT/'onnx266/measurements.json').read_text())
assert partial['samples']==[] and partial['status']=='failed'
assert not (OUT/'actual.stdout.log').read_bytes()
cause='reference worker changed source, extent or measurement identity'
assert cause==partial['cause'] and cause in (OUT/'actual.stderr.log').read_text()
logs=(OUT/'onnx266/logs/motion-studio.log').read_text()
assert 'start #1 depth_infer' in logs and 'phase=capability_metadata' in logs and cause in logs
members={name:(OUT/name).read_bytes() for name in ('controller.py','receipt.json','session-consumed.json',
 'actual.stdout.log','actual.stderr.log','onnx266/measurements.json','onnx266/logs/motion-studio.log')}
for name in ('crates/motion-host/examples/depth_reference.rs','crates/motion-host/src/depth.rs',
 'crates/motion-model/src/depth/prepared.rs'):
 members['source/'+name]=(WORK/name).read_bytes()
members['archive-controller.py']=Path(__file__).read_bytes()
data=WORK/'engineering/validation/data';archive=data/'depth75-reference-onnx266-failure-v1.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(members.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
 assert sorted(z.namelist())==sorted(members)
 for name,raw in members.items():assert z.read(name)==raw
manifest=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
 head=receipt['head'],source_unchanged=True,original_session=22317,consumed_exit_code=1,
 status='original_cohort_failed_in_caller_after_first_actual_inference',accepted_samples=0,
 cause='Caller compared raw RGB file SHA-256 against versioned format/dimensions/RGB fingerprint',
 limits=['No accepted prediction array or quality result; worker backend and metadata phases returned once',
 'Original failure remains failed; subsequent source correction requires new tests/build and a distinct cohort',
 'No model, sensor/RGB image, prediction array or executable redistributed'],
 members=[dict(path=name,bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(members.items())])
(data/'depth75-reference-onnx266-failure-v1.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
checkpoint=BASE/'depth75-resume-current.json';state=json.loads(checkpoint.read_text())
v=state['versionedCache75'];v['ownHeavyWorkloads']=[];v['activeController']=None
v['independentReference75']['firstActualCohort'].update(status='terminal_consumed_exit1',consumed=True,exit_code=1,
 archive=archive.name,sha256=manifest['sha256'],sourceFrozen=False)
checkpoint.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:manifest[k] for k in ('archive','bytes','sha256','status')}))
