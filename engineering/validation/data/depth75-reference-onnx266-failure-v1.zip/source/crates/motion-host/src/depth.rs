//! Optional, bounded desktop depth jobs. The inference engine lives behind a
//! backend; callers must provide the *current* source identity when taking output.
//!
//! One running job and one replaceable pending input are retained. Cancellation
//! is cooperative: backends must check it during work (subprocess backends can
//! terminate their own child). This worker never owns a render session or GPU.

use motion_model::depth::{
    DepthGeometry, DepthModel, DepthResource, DepthSource, PreparedDepthInput,
};
use sha2::{Digest, Sha256};
pub(crate) mod image;
pub mod cache;
pub mod capability;
pub mod alignment;
pub mod transition;
pub mod routing;
pub mod onnx;
pub mod wgsl;
pub(crate) mod storage;
pub(crate) mod video;
pub use video::VideoInput;
use std::{
    any::Any,
    panic::{catch_unwind, AssertUnwindSafe},
    sync::{
        atomic::{AtomicBool, Ordering},
        Arc, Condvar, Mutex,
    },
    thread::{self, JoinHandle},
    time::{Duration, Instant},
};

pub type Result<T> = std::result::Result<T, Error>;

#[derive(Debug, thiserror::Error)]
pub enum Error {
    #[error(transparent)]
    Resource(#[from] motion_model::Error),
    #[error("depth input rejected: {0}")]
    Invalid(&'static str),
    #[error("depth inference canceled")]
    Canceled,
    #[error("depth worker state is unavailable")]
    State,
    #[error("depth worker stopped")]
    Stopped,
    #[error("depth result request={request} asset={asset} phase=retain: capacity exceeded; bytes={required_bytes}/{byte_limit} samples={required_samples}/{sample_limit}")]
    RetentionCapacity {
        request: u64,
        asset: u64,
        required_bytes: usize,
        byte_limit: usize,
        required_samples: usize,
        sample_limit: usize,
    },
    #[error("depth storage request={request} object={object} phase=spill: capacity exceeded; bytes={required_bytes}/{byte_limit} sample_limit={sample_limit}")]
    StorageCapacity {
        request: u64,
        object: u64,
        required_bytes: u64,
        byte_limit: u64,
        sample_limit: usize,
    },
    #[error("depth backend panicked: {0}")]
    Panic(String),
    #[error("depth backend failed: {0}")]
    Backend(String),
    #[error("depth worker alignment failed: {0}")]
    Alignment(#[from] transition::admission::Error),
    #[error(transparent)]
    Io(#[from] std::io::Error),
    #[error(transparent)]
    Json(#[from] serde_json::Error),
    #[error(transparent)]
    Image(#[from] ::image::ImageError),
    #[error(transparent)]
    Media(#[from] motion_media::Error),
    #[error(transparent)]
    Render(#[from] motion_render::RenderError),
    #[error("{primary}; depth temporary cleanup also failed: {cleanup}")]
    Cleanup {
        #[source]
        primary: Box<Error>,
        cleanup: std::io::Error,
    },
}

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Key {
    pub source: DepthSource,
    pub geometry: DepthGeometry,
    pub model: DepthModel,
}

impl Key {
    pub fn same_sample(&self, other: &Self) -> bool {
        self.source.same_sample(&other.source)
            && self.geometry == other.geometry
            && self.model == other.model
    }

    fn validate(&self) -> Result<()> {
        self.source.pts.validate()?;
        self.geometry.validate()?;
        self.model.validate()?;
        Ok(())
    }
}

/// Opaque RGB8 in sRGB encoding, after the declared crop/rotation/mirroring.
/// Alpha compositing and conversion from a renderer's working space are the
/// caller's explicit responsibility. No implicit unpremultiplication is made.
#[derive(Clone, Debug)]
pub struct Input {
    key: Key,
    size: [u32; 2],
    rgb: Arc<[u8]>,
    image: Option<motion_render::DepthImage>,
    video_end_us: Option<u64>,
}

impl Input {
    pub fn new(key: Key, size: [u32; 2], rgb: Arc<[u8]>) -> Result<Self> {
        key.validate()?;
        let [_, _, w, h] = key.geometry.crop;
        let expected = if key.geometry.quarter_turns % 2 == 0 {
            [w, h]
        } else {
            [h, w]
        };
        if size != expected || size.contains(&0) || size.iter().any(|n| *n > 4096) {
            return Err(Error::Invalid(
                "dimensions must match the oriented crop, up to 4096",
            ));
        }
        if rgb.len() as u64 != u64::from(size[0]) * u64::from(size[1]) * 3 {
            return Err(Error::Invalid("RGB byte count differs from dimensions"));
        }
        Ok(Self {
            key,
            size,
            rgb,
            image: None,
            video_end_us: None,
        })
    }
    pub fn key(&self) -> &Key {
        &self.key
    }
    pub fn size(&self) -> [u32; 2] {
        self.size
    }
    pub fn rgb(&self) -> &[u8] {
        &self.rgb
    }
    pub(crate) fn into_image(self) -> Option<motion_render::DepthImage> {
        self.image
    }
    pub(crate) fn video_end_us(&self) -> Option<u64> {
        self.video_end_us
    }
    pub(crate) fn fingerprint(&self, cancellation: &Cancellation) -> Result<PreparedDepthInput> {
        let mut hash = Sha256::new();
        hash.update(b"MotionStudio/depth/rgb8-srgb-opaque/v1\0");
        for size in self.size {
            hash.update(size.to_le_bytes());
        }
        for chunk in self.rgb.chunks(64 << 10) {
            cancellation.check()?;
            hash.update(chunk);
        }
        cancellation.check()?;
        let input = PreparedDepthInput {
            rgb_size: self.size,
            rgb_sha256: hash.finalize().into(),
        };
        input.validate(&self.key.geometry)?;
        Ok(input)
    }
}

#[derive(Clone, Debug, Default)]
pub struct Costs {
    /// Worker-side managed source IO, decode and RGB preparation, before inference.
    pub source_prepare: Duration,
    pub source_rgb_bytes: u64,
    /// Full worker operation wall time, including managed-source preparation.
    /// Direct backend calls report their own wall time without source staging.
    pub total: Duration,
    /// Measured parent-side staging/serialization and output ownership checks.
    /// This is separate from the child's tensor copies and filesystem phases.
    pub host_transport: Duration,
    pub load: Duration,
    pub preprocess: Duration,
    pub input_copy: Duration,
    pub inference: Duration,
    pub output_copy: Duration,
    pub postprocess: Duration,
    /// Worker-side alignment against the exact prepared reference, if requested.
    pub alignment: Duration,
    pub input_bytes: u64,
    pub output_bytes: u64,
}

#[derive(Clone, Debug)]
pub struct Estimate {
    pub resource: DepthResource,
    /// Actual provider returned by the runtime, never just the requested one.
    pub provider: String,
    pub costs: Costs,
}

/// Only the worker constructs this pair, after all crop, orientation and color
/// conversion. The backend cannot supply the authoritative input fingerprint.
#[derive(Clone, Debug)]
pub struct PreparedEstimate {
    estimate: Estimate,
    input: PreparedDepthInput,
    image: Option<motion_render::DepthImage>,
    video_end_us: Option<u64>,
    measurement: Option<capability::Measurement>,
}
impl PreparedEstimate {
    pub fn estimate(&self) -> &Estimate {
        &self.estimate
    }
    pub fn input(&self) -> PreparedDepthInput {
        self.input
    }
    /// Present only for a successful, uncached `Jobs::start_measured` request.
    /// Ordinary inference and cached/restored results do not qualify a device.
    pub fn measurement(&self) -> Option<&capability::Measurement> {
        self.measurement.as_ref()
    }
    /// Exclusive source interval end, established by managed-index/decoder
    /// agreement. None for direct RGB or still-image requests. The descriptor's
    /// source PTS is its start; the requested timeline coordinate is not a PTS.
    pub fn video_end_us(&self) -> Option<u64> { self.video_end_us }
    pub(crate) fn into_owned_parts(
        self,
    ) -> (
        Estimate,
        PreparedDepthInput,
        Option<motion_render::DepthImage>,
        Option<u64>,
    ) {
        (self.estimate, self.input, self.image, self.video_end_us)
    }
    pub fn into_parts(self) -> (Estimate, PreparedDepthInput) {
        (self.estimate, self.input)
    }
}

impl Estimate {
    fn validate(&self, key: &Key) -> Result<()> {
        let d = self.resource.descriptor();
        if !key.source.same_sample(&d.source) || key.geometry != d.geometry || key.model != d.model
        {
            return Err(Error::Invalid(
                "backend result identity differs from request",
            ));
        }
        if self.provider.is_empty()
            || self.provider.len() > 128
            || self.provider.chars().any(char::is_control)
        {
            return Err(Error::Invalid(
                "missing or unbounded actual execution provider",
            ));
        }
        Ok(())
    }
}

#[derive(Clone, Default)]
pub struct Cancellation(Arc<AtomicBool>);
impl Cancellation {
    pub fn is_canceled(&self) -> bool {
        self.0.load(Ordering::Acquire)
    }
    pub fn check(&self) -> Result<()> {
        if self.is_canceled() {
            Err(Error::Canceled)
        } else {
            Ok(())
        }
    }
    fn cancel(&self) {
        self.0.store(true, Ordering::Release);
    }
}

/// Return promptly after cancellation. Errors retain their original causes; no
/// implicit retries, requested-provider reports or synthetic depth are allowed.
pub trait Backend: Send + 'static {
    fn infer(&mut self, input: &Input, cancellation: &Cancellation) -> Result<Estimate>;
    /// Metadata from the immediately preceding successful inference for this
    /// input. Implementations must not do IO or new work here. This is retained
    /// managed GPU buffer capacity, not driver/process/device peak memory.
    /// None means unobserved; zero must not stand in for an unknown value.
    fn retained_gpu_buffer_capacity(&self, _input: &Input) -> Option<u64> { None }
    /// Establish the actual execution environment before persistent lookup.
    /// None means this backend cannot currently attest it, not a cache miss.
    fn execution_identity(&mut self, _input: &Input, cancellation: &Cancellation)
        -> Result<Option<cache::Execution>> {
        cancellation.check()?;
        Ok(None)
    }
}

#[derive(Clone, Copy, Debug, Default)]
/// Saturating lifetime counts of this Jobs instance; never reset by a seek.
pub struct Counts {
    pub submitted: u64,
    pub superseded_pending: u64,
    pub completed: u64,
    pub canceled: u64,
    pub failed: u64,
    pub stale: u64,
    /// Completed jobs restored from verified scalar spill data, without inference.
    pub restored: u64,
    /// Verified persistent raw restores, separate from session video spill.
    pub cache_hits: u64,
    pub cache_misses: u64,
}

#[derive(Clone, Debug)]
pub struct InFlight {
    pub request: u64,
    pub asset: u64,
    pub revision: u64,
    /// Unknown until video decoding has established the exact source sample.
    pub source: Option<DepthSource>,
    pub target_time_us: Option<u64>,
    pub phase: &'static str,
    pub elapsed: Duration,
}

/// A requested video timeline coordinate, distinct from the decoded frame PTS.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct VideoKey {
    pub object: u64,
    pub asset: u64,
    pub revision: u64,
    pub target_us: u64,
    pub geometry: DepthGeometry,
    pub model: DepthModel,
}
impl VideoKey {
    fn validate(&self) -> Result<()> {
        self.geometry.validate()?;
        self.model.validate()?;
        if self.target_us > 3_600_000_000 {
            return Err(Error::Invalid(
                "video depth target exceeds source duration limit",
            ));
        }
        Ok(())
    }
}

#[derive(Clone)]
pub(crate) enum Identity {
    Sample(Key),
    Video(VideoKey),
}
impl Identity {
    pub(crate) fn same_request(&self, other: &Self) -> bool {
        match (self, other) {
            (Self::Sample(a), Self::Sample(b)) => a.same_sample(b),
            (Self::Video(a), Self::Video(b)) => a == b,
            _ => false,
        }
    }
    fn validate(&self) -> Result<()> {
        match self {
            Self::Sample(key) => key.validate(),
            Self::Video(key) => key.validate(),
        }
    }
    fn source(&self) -> Option<DepthSource> {
        match self {
            Self::Sample(key) => Some(key.source.clone()),
            Self::Video(_) => None,
        }
    }
    fn asset_revision(&self) -> (u64, u64) {
        match self {
            Self::Sample(key) => (key.source.asset, key.source.revision),
            Self::Video(key) => (key.asset, key.revision),
        }
    }
    fn target_time_us(&self) -> Option<u64> {
        match self {
            Self::Sample(_) => None,
            Self::Video(key) => Some(key.target_us),
        }
    }
    fn log_start(&self, request: u64) {
        if !log::log_enabled!(log::Level::Info) {
            return;
        }
        let model = match self {
            Self::Sample(key) => &key.model,
            Self::Video(key) => &key.model,
        };
        let digest: String = model
            .sha256
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect();
        match self {
            Self::Sample(key) => log::info!("start #{} depth_infer asset={} revision={} pts={}/{} model={} model_revision={} processing={} model_sha256={}",
                request,key.source.asset,key.source.revision,key.source.pts.ticks,key.source.pts.timescale,model.id,model.revision,model.processing,digest),
            Self::Video(key) => log::info!("start #{} depth_infer asset={} revision={} target_us={} phase=video_decode object={} model={} model_revision={} processing={} model_sha256={}",
                request,key.asset,key.revision,key.target_us,key.object,model.id,model.revision,model.processing,digest),
        }
        // The production sink buffers Info. Persist the request before source
        // preparation or a backend can block, rather than waiting for completion.
        log::logger().flush();
    }
}

/// Read-only session observation. Counts belong to this worker's lifetime;
/// invalidating a document/sample does not reset them.
#[derive(Clone, Debug)]
pub struct SessionStatus {
    pub request: Option<u64>,
    pub installed: bool,
    pub counts: Counts,
    pub in_flight: Option<InFlight>,
    pub queue_depth: usize,
    /// Results admitted for the current document/revision. Owned static image
    /// samples survive clock changes; video and pending tickets stay frame-bound.
    pub retained_samples: usize,
    /// Scalar/validity/confidence planes, preserving the existing observation.
    pub retained_bytes: usize,
    /// Owned original RGBA allocation capacity. Combined with retained_bytes,
    /// this is bounded by the session result-admission allowance.
    pub retained_image_bytes: usize,
    /// Lifetime host result-admission failures; separate from backend failures.
    pub retention_rejections: u64,
    /// Document-scoped scalar spill data, independent of the live RGBA cache.
    pub stored_samples: usize,
    pub stored_bytes: u64,
    /// Saturating capacity failures, reset when this document store is disposed.
    pub storage_rejections: u64,
}

struct Job {
    request: u64,
    input: Work,
    alignment: Option<transition::admission::Pending>,
    cancellation: Cancellation,
}

enum Work {
    Prepared(Input),
    Image(image::ImageInput),
    Video(video::VideoInput, Option<Arc<storage::Store>>),
}
impl Work {
    fn identity(&self) -> Identity {
        match self {
            Self::Prepared(input) => Identity::Sample(input.key().clone()),
            Self::Image(input) => Identity::Sample(input.key.clone()),
            Self::Video(input, _) => Identity::Video(input.key.clone()),
        }
    }
    fn prepare(self, cancellation: &Cancellation) -> Result<Input> {
        match self {
            Self::Prepared(input) => Ok(input),
            Self::Image(input) => input.decode(cancellation),
            Self::Video(input, _) => input.decode(cancellation),
        }
    }
    fn store(&self) -> Option<Arc<storage::Store>> {
        match self { Self::Video(_, store) => store.clone(), _ => None }
    }
    fn store_root(&self) -> Option<std::path::PathBuf> {
        match self { Self::Video(input, Some(_)) => Some(input.root.clone()), _ => None }
    }
}
struct Flight {
    request: u64,
    asset: u64,
    revision: u64,
    source: Option<DepthSource>,
    target_time_us: Option<u64>,
    phase: &'static str,
    started: Instant,
    cancellation: Cancellation,
}
struct Completion {
    request: u64,
    identity: Identity,
    result: Result<Ready>,
}
// An aligned completion cannot be taken through the raw result API and silently
// installed without its proof. There is still only one ready slot per worker.
enum Ready {
    Raw(PreparedEstimate),
    Aligned(transition::admission::Admission),
}
#[derive(Default)]
struct State {
    latest: u64,
    pending: Option<Job>,
    flight: Option<Flight>,
    ready: Option<Completion>,
    stopped: bool,
    counts: Counts,
}
type Shared = Arc<(Mutex<State>, Condvar)>;

pub struct Jobs {
    shared: Shared,
    bindings: Option<Arc<capability::policy::Bindings>>,
    worker: Option<JoinHandle<()>>,
}

impl Jobs {
    pub fn start(backend: impl Backend) -> Result<Self> {
        Self::start_configured(backend, None, false, None)
    }

    /// Explicit capability probe on the same bounded serial worker. Resolve the
    /// actual runtime before every inference, validate its returned provider,
    /// and retain worker-owned timing. Never restore or write reusable results.
    /// Source preparation is included; queueing and caller-side IO are not.
    /// This does not certify quality, peak memory, or sustained performance.
    pub fn start_measured(backend: impl Backend) -> Result<Self> {
        Self::start_configured(backend, None, true, None)
    }

    /// Explicit, strict persistent cache. Unsupported execution identities and
    /// corrupt entries are failures; neither silently launches inference.
    pub fn start_cached(backend: impl Backend, cache: cache::Config) -> Result<Self> {
        cache.validate()?;
        Self::start_configured(backend, Some(cache), false, None)
    }

    /// Execute only explicitly admitted configurations. Actual runtime identity
    /// is resolved before either cache/spill reuse or inference. An unknown or
    /// changed execution is an error, never a fallback to another binding.
    pub fn start_qualified(backend: impl Backend, bindings: capability::policy::Bindings,
        cache: Option<cache::Config>) -> Result<Self> {
        if let Some(cache) = &cache { cache.validate()?; }
        Self::start_configured(backend, cache, false, Some(bindings))
    }

    pub fn qualified_bindings(&self) -> Option<&capability::policy::Bindings> {
        self.bindings.as_deref()
    }

    fn start_configured(backend: impl Backend, cache: Option<cache::Config>, measured: bool,
        bindings: Option<capability::policy::Bindings>) -> Result<Self> {
        let shared = Arc::new((Mutex::new(State::default()), Condvar::new()));
        let worker_shared = shared.clone();
        let bindings = bindings.map(Arc::new);
        let worker_bindings = bindings.clone();
        let worker = thread::Builder::new()
            .name("motion-depth".into())
            .spawn(move || run(backend, worker_shared, cache, measured, worker_bindings))?;
        Ok(Self {
            shared,
            bindings,
            worker: Some(worker),
        })
    }

    /// Replace the one pending input and cancel the old in-flight sample. The
    /// monotonically increasing ticket prevents an older completion overwriting it.
    pub fn request(&mut self, input: Input) -> Result<u64> {
        self.submit(Work::Prepared(input))
    }

    pub(crate) fn request_image(&mut self, input: image::ImageInput) -> Result<u64> {
        self.submit(Work::Image(input))
    }

    pub(crate) fn request_video(&mut self, input: video::VideoInput,
        store: Option<Arc<storage::Store>>) -> Result<u64> {
        self.submit(Work::Video(input, store))
    }

    /// Prepare an already registered original video on this serial worker.
    /// Index validation, decoder creation/use/drop, transfer conversion and RGB
    /// fingerprinting all precede inference on the worker, with no Session/GPU
    /// handle crossing threads. No session spill is restored or written here.
    /// With start_measured, these preparation costs are part of the observation.
    pub fn request_video_sample(&mut self, input: VideoInput) -> Result<u64> {
        self.request_video(input, None)
    }

    fn submit(&mut self, input: Work) -> Result<u64> {
        self.submit_with_alignment(input, None)
    }

    fn submit_with_alignment(
        &mut self,
        input: Work,
        alignment: Option<transition::admission::Pending>,
    ) -> Result<u64> {
        input.identity().validate()?;
        let mut state = self.shared.0.lock().map_err(|_| Error::State)?;
        if state.stopped {
            return Err(Error::Stopped);
        }
        let request = state
            .latest
            .checked_add(1)
            .ok_or(Error::Invalid("request counter exhausted"))?;
        if let Some(flight) = &state.flight {
            flight.cancellation.cancel();
        }
        if let Some(pending) = state.pending.take() {
            pending.cancellation.cancel();
            state.counts.superseded_pending = state.counts.superseded_pending.saturating_add(1);
        }
        state.latest = request;
        state.ready = None;
        state.pending = Some(Job {
            request,
            input,
            alignment,
            cancellation: Cancellation::default(),
        });
        state.counts.submitted = state.counts.submitted.saturating_add(1);
        drop(state);
        self.shared.1.notify_one();
        Ok(request)
    }

    /// Call on seek/source/model changes even when no replacement is requested.
    pub fn cancel(&mut self) -> Result<()> {
        let mut state = self.shared.0.lock().map_err(|_| Error::State)?;
        if let Some(flight) = &state.flight {
            flight.cancellation.cancel();
        }
        if let Some(pending) = state.pending.take() {
            pending.cancellation.cancel();
        }
        state.ready = None;
        Ok(())
    }

    /// This is the installation boundary: independently supply the live key.
    /// A source/revision/PTS/crop/model mismatch is a normal discarded old result.
    pub fn take_ready(&mut self, current: &Key) -> Result<Option<Estimate>> {
        self.take_prepared_ready(current)
            .map(|ready| ready.map(|ready| ready.estimate))
    }

    /// Preserve the worker's actual prepared input identity for saved calibration.
    /// The independent live-key comparison is identical to `take_ready`.
    pub fn take_prepared_ready(&mut self, current: &Key) -> Result<Option<PreparedEstimate>> {
        self.take_raw(&Identity::Sample(current.clone()))
    }

    pub(crate) fn take_video_prepared_ready(
        &mut self,
        current: &VideoKey,
    ) -> Result<Option<PreparedEstimate>> {
        self.take_raw(&Identity::Video(current.clone()))
    }

    /// Independently provide the live original-video request. Object, source,
    /// revision, requested time, geometry and model must still match. The result
    /// retains the decoder's actual source PTS/interval and prepared RGB hash.
    pub fn take_video_sample(&mut self, current: &VideoKey) -> Result<Option<PreparedEstimate>> {
        self.take_video_prepared_ready(current)
    }

    fn take_raw(&mut self, current: &Identity) -> Result<Option<PreparedEstimate>> {
        match self.take_identity(current)? {
            None => Ok(None),
            Some(Ready::Raw(ready)) => Ok(Some(ready)),
            Some(Ready::Aligned(_)) => Err(Error::Invalid("aligned completion requires its admission API")),
        }
    }

    fn take_identity(&mut self, current: &Identity) -> Result<Option<Ready>> {
        current.validate()?;
        let mut state = self.shared.0.lock().map_err(|_| Error::State)?;
        let Some(done) = state.ready.take() else {
            return Ok(None);
        };
        if done.request != state.latest || !done.identity.same_request(current) {
            state.counts.stale = state.counts.stale.saturating_add(1);
            return Ok(None);
        }
        drop(state);
        done.result.map(Some)
    }

    pub fn counts(&self) -> Result<Counts> {
        Ok(self.shared.0.lock().map_err(|_| Error::State)?.counts)
    }
    pub fn in_flight(&self) -> Result<Option<InFlight>> {
        Ok(self
            .shared
            .0
            .lock()
            .map_err(|_| Error::State)?
            .flight
            .as_ref()
            .map(|f| InFlight {
                request: f.request,
                asset: f.asset,
                revision: f.revision,
                source: f.source.clone(),
                target_time_us: f.target_time_us,
                phase: f.phase,
                elapsed: f.started.elapsed(),
            }))
    }
    pub fn queue_depth(&self) -> Result<usize> {
        Ok(usize::from(
            self.shared
                .0
                .lock()
                .map_err(|_| Error::State)?
                .pending
                .is_some(),
        ))
    }
}

impl Drop for Jobs {
    fn drop(&mut self) {
        let unavailable = match self.shared.0.lock() {
            Ok(mut state) => {
                state.stopped = true;
                if let Some(flight) = &state.flight {
                    flight.cancellation.cancel();
                }
                state.pending = None;
                false
            }
            Err(poison) => {
                drop(poison);
                true
            }
        };
        if unavailable {
            log::error!("operation=depth_shutdown phase=state cause=poisoned_state");
        }
        self.shared.1.notify_one();
        if let Some(worker) = self.worker.take() {
            if let Err(payload) = worker.join() {
                log::error!(
                    "operation=depth_shutdown phase=join cause={}",
                    panic_cause(payload.as_ref())
                );
            }
        }
    }
}

fn panic_cause(payload: &(dyn Any + Send)) -> String {
    let message = payload
        .downcast_ref::<String>()
        .map(String::as_str)
        .or_else(|| payload.downcast_ref::<&str>().copied())
        .unwrap_or("non-string panic");
    message.chars().take(512).collect()
}

fn run(mut backend: impl Backend, shared: Shared, cache: Option<cache::Config>, measured: bool,
    bindings: Option<Arc<capability::policy::Bindings>>) {
    // Measurements retain this private identity, so a future profile consumer
    // can distinguish equal request numbers from different worker instances.
    let measurement_scope = Arc::new(());
    loop {
        let job = {
            let Ok(mut state) = lock_state(&shared) else {
                log::error!("operation=depth_worker phase=receive cause=poisoned_state");
                return;
            };
            while !state.stopped && state.pending.is_none() {
                state = match shared.1.wait(state) {
                    Ok(state) => state,
                    Err(poison) => {
                        drop(poison);
                        log::error!("operation=depth_worker phase=wait cause=poisoned_state");
                        return;
                    }
                };
            }
            if state.stopped {
                return;
            }
            let Some(job) = state.pending.take() else {
                continue;
            };
            let identity = job.input.identity();
            let (asset, revision) = identity.asset_revision();
            state.flight = Some(Flight {
                request: job.request,
                asset,
                revision,
                source: identity.source(),
                target_time_us: identity.target_time_us(),
                phase: "source_prepare",
                started: Instant::now(),
                cancellation: job.cancellation.clone(),
            });
            job
        };
        let began = Instant::now();
        let identity = job.input.identity();
        let (asset, revision) = identity.asset_revision();
        identity.log_start(job.request);
        let mut stage = "source_prepare";
        let mut source = identity.source();
        let store = job.input.store();
        let store_root = job.input.store_root();
        let mut restored = false;
        let mut cache_hit = false;
        let mut cache_miss = false;
        let result = catch_unwind(AssertUnwindSafe(|| {
            job.cancellation.check()?;
            let prepare_began = Instant::now();
            let input = job.input.prepare(&job.cancellation)?;
            let prepared_input = input.fingerprint(&job.cancellation)?;
            let source_prepare = prepare_began.elapsed();
            job.cancellation.check()?;
            source = Some(input.key().source.clone());
            stage = "backend";
            {
                let mut state = lock_state(&shared)?;
                let flight = state.flight.as_mut().ok_or(Error::State)?;
                flight.source = Some(input.key().source.clone());
                flight.phase = "backend";
            }
            if identity.target_time_us().is_some() {
                log::info!("request={} operation=depth_infer asset={} revision={} phase=source_ready pts={}/{} source_prepare_ms={}",
                    job.request,asset,revision,input.key().source.pts.ticks,input.key().source.pts.timescale,source_prepare.as_millis());
            }
            // Resolve before *either* reusable result path. Session-local spill
            // must not bypass a changed actual runtime/provider/plan identity.
            let resolve_began = Instant::now();
            let required = bindings.as_ref().map(|bindings| bindings.execution(input.key())).transpose()?;
            let execution = if cache.is_some() || measured || required.is_some() {
                stage = if required.is_some() { "qualified_resolve" }
                    else if measured { "capability_resolve" } else { "cache_resolve" };
                if required.is_some() { qualification_phase(&shared, job.request, asset, stage)?; }
                else if measured { capability_phase(&shared, job.request, asset, stage)?; }
                else { cache_phase(&shared, job.request, asset, stage)?; }
                let execution = backend.execution_identity(&input, &job.cancellation)?
                    .ok_or(Error::Invalid(if required.is_some() {
                        "qualified inference requires an attested execution identity"
                    } else if measured {
                        "capability measurement requires an attested execution identity"
                    } else { "persistent cache requires an attested execution identity" }))?;
                execution.validate()?;
                if let Some(required) = required {
                    validate_qualified_execution(required, &execution)?;
                }
                Some(execution)
            } else { None };
            let resolve_elapsed = resolve_began.elapsed();
            job.cancellation.check()?;
            let cached = match (&store, &identity) {
                (Some(store), Identity::Video(key)) if !measured => store.lookup(key)?
                    .filter(|sample| execution.is_none() || sample.execution == execution),
                _ => None,
            };
            let mut estimate = if let Some(sample) = cached {
                stage = "archive_read";
                set_phase(&shared, stage)?;
                log::info!("start #{} depth_restore object={} asset={} pts={:?} phase=archive_read source_request={}",
                    job.request, match &identity { Identity::Video(key) => key.object, _ => 0 },
                    asset, input.key().source.pts, sample.request);
                log::logger().flush();
                let mut estimate = sample.restore(&input, prepared_input, &job.cancellation)?;
                estimate.costs = Costs::default();
                restored = true;
                estimate
            } else if let Some(cache) = &cache {
                let execution = execution.as_ref().ok_or(Error::State)?;
                stage = "cache_read";
                cache_phase(&shared, job.request, asset, stage)?;
                if let Some(estimate) = cache.read(&input, prepared_input, &execution, &job.cancellation)? {
                    cache_hit = true;
                    estimate
                } else {
                    cache_miss = true;
                    stage = "backend";
                    cache_phase(&shared, job.request, asset, stage)?;
                    let estimate = backend.infer(&input, &job.cancellation)?;
                    job.cancellation.check()?;
                    estimate.validate(input.key())?;
                    execution.validate_result(&estimate)?;
                    stage = "cache_write";
                    cache_phase(&shared, job.request, asset, stage)?;
                    cache.write(&input, prepared_input, &execution, &estimate, &job.cancellation)?;
                    estimate
                }
            } else {
                if required.is_some() {
                    stage = "backend";
                    qualification_phase(&shared, job.request, asset, stage)?;
                } else if measured {
                    stage = "backend";
                    capability_phase(&shared, job.request, asset, stage)?;
                }
                backend.infer(&input, &job.cancellation)?
            };
            job.cancellation.check()?;
            estimate.validate(input.key())?;
            if measured || required.is_some() {
                execution.as_ref().ok_or(Error::State)?.validate_result(&estimate)?;
            }
            let retained_gpu_buffers = if measured {
                stage = "capability_metadata";
                capability_phase(&shared, job.request, asset, stage)?;
                let capacity = backend.retained_gpu_buffer_capacity(&input);
                if capacity.is_some_and(|bytes| bytes == 0 || bytes > (512 << 20)) {
                    return Err(Error::Invalid("measured GPU buffer capacity must be nonzero and at most 512 MiB"));
                }
                capacity
            } else { None };
            estimate.costs.source_prepare = source_prepare;
            estimate.costs.source_rgb_bytes = input.rgb().len() as u64;
            estimate.costs.total = began.elapsed();
            if !restored && !measured {
                if let (Some(store), Identity::Video(key)) = (&store, &identity) {
                    stage = "archive_write";
                    set_phase(&shared, stage)?;
                    log::info!("start #{} depth_spill object={} asset={} pts={:?} phase=archive_write",
                        job.request, key.object, asset, input.key().source.pts);
                    log::logger().flush();
                    // The root is captured with the job; no Session or GPU
                    // state is accessed on this worker.
                    let root = store_root.as_deref().ok_or(Error::State)?;
                    if let Some(execution) = execution.as_ref() {
                        store.append_qualified(root, job.request, key.object, &input, prepared_input,
                            &estimate, Some(execution), &job.cancellation)?;
                    } else {
                        store.append(root, job.request, key.object, &input, prepared_input,
                            &estimate, &job.cancellation)?;
                    }
                }
            }
            estimate.costs.total = began.elapsed();
            let measurement = if measured {
                Some(capability::Measurement::new(measurement_scope.clone(), job.request,
                    execution.ok_or(Error::State)?, resolve_elapsed, estimate.costs.total, retained_gpu_buffers))
            } else { None };
            let prepared = PreparedEstimate { estimate, input: prepared_input, image: input.image,
                video_end_us: input.video_end_us, measurement };
            if let Some(alignment) = job.alignment {
                stage = "alignment";
                set_phase(&shared, stage)?;
                // No observation lock is held across logging, cancellation
                // polling or the linear fit. Keep Flight until publication.
                log::info!("start #{} depth_align asset={} revision={} phase=alignment generation={}",
                    job.request, asset, revision, alignment.generation());
                log::logger().flush();
                let mut admitted = alignment.complete(prepared, || job.cancellation.is_canceled())
                    .map_err(|cause| match cause {
                        transition::admission::Error::Alignment(alignment::Rejection::Canceled) => Error::Canceled,
                        other => Error::Alignment(other),
                    })?;
                job.cancellation.check()?;
                admitted.finish_worker_costs(began.elapsed());
                Ok(Ready::Aligned(admitted))
            } else {
                Ok(Ready::Raw(prepared))
            }
        }))
        .unwrap_or_else(|p| Err(Error::Panic(panic_cause(p.as_ref()))))
        .map_err(|error| match error {
            Error::Backend(cause) => Error::Backend(cause.chars().take(2048).collect()),
            other => other,
        });
        if let Err(error) = &result {
            if !matches!(error, Error::Canceled) {
                log::error!("request={} operation=depth_infer asset={} revision={} phase=prepare_or_backend stage={} target_us={:?} pts={:?} elapsed_ms={} cause={}",
                    job.request, asset, revision, stage, identity.target_time_us(), source.as_ref().map(|s| &s.pts), began.elapsed().as_millis(),
                    error.to_string().chars().take(768).collect::<String>());
            }
        }
        log::debug!(
            "done #{} depth_infer {}ms",
            job.request,
            began.elapsed().as_millis()
        );
        let halted = matches!(result, Err(Error::Panic(_)));
        let Ok(mut state) = lock_state(&shared) else {
            log::error!(
                "request={} operation=depth_infer phase=publish cause=poisoned_state",
                job.request
            );
            return;
        };
        state.flight = None;
        if cache_hit { state.counts.cache_hits = state.counts.cache_hits.saturating_add(1); }
        if cache_miss { state.counts.cache_misses = state.counts.cache_misses.saturating_add(1); }
        match &result {
            Ok(_) => {
                state.counts.completed = state.counts.completed.saturating_add(1);
                if restored { state.counts.restored = state.counts.restored.saturating_add(1); }
            },
            Err(Error::Canceled) => state.counts.canceled = state.counts.canceled.saturating_add(1),
            Err(_) => state.counts.failed = state.counts.failed.saturating_add(1),
        }
        // Both checks matter: cancel() need not allocate another ticket.
        if state.latest == job.request && !job.cancellation.is_canceled() && !state.stopped {
            state.ready = Some(Completion {
                request: job.request,
                identity,
                result,
            });
        }
        if halted {
            state.stopped = true;
            if let Some(pending) = state.pending.take() {
                pending.cancellation.cancel();
            }
            return;
        }
    }
}

fn lock_state(shared: &Shared) -> Result<std::sync::MutexGuard<'_, State>> {
    shared.0.lock().map_err(|poison| {
        drop(poison);
        Error::State
    })
}

fn set_phase(shared: &Shared, phase: &'static str) -> Result<()> {
    lock_state(shared)?.flight.as_mut().ok_or(Error::State)?.phase = phase;
    Ok(())
}

fn cache_phase(shared: &Shared, request: u64, asset: u64, phase: &'static str) -> Result<()> {
    set_phase(shared, phase)?;
    log::info!("start #{} depth_cache asset={} phase={}", request, asset, phase);
    log::logger().flush();
    Ok(())
}

fn capability_phase(shared: &Shared, request: u64, asset: u64, phase: &'static str) -> Result<()> {
    set_phase(shared, phase)?;
    log::info!("start #{} depth_capability asset={} phase={}", request, asset, phase);
    log::logger().flush();
    Ok(())
}

fn qualification_phase(shared: &Shared, request: u64, asset: u64, phase: &'static str) -> Result<()> {
    set_phase(shared, phase)?;
    log::info!("start #{} depth_qualification asset={} phase={}", request, asset, phase);
    log::logger().flush();
    Ok(())
}

fn validate_qualified_execution(required: &cache::Execution, actual: &cache::Execution) -> Result<()> {
    // Report the first changed field rather than two complete identities. Both
    // sides then fit the worker's bounded Error cause, including both digests.
    for (field, expected, resolved) in [
        ("backend", &required.backend, &actual.backend),
        ("provider", &required.provider, &actual.provider),
        ("precision", &required.precision, &actual.precision),
    ] {
        if expected != resolved {
            return Err(Error::Backend(format!(
                "qualified execution differs field={field} required={expected:?} resolved={resolved:?}"
            )));
        }
    }
    for (field, expected, resolved) in [
        ("runtime_sha256", &required.runtime_sha256, &actual.runtime_sha256),
        ("plan_sha256", &required.plan_sha256, &actual.plan_sha256),
    ] {
        if expected != resolved {
            return Err(Error::Backend(format!(
                "qualified execution differs field={field} required={expected:?} resolved={resolved:?}"
            )));
        }
    }
    Ok(())
}
