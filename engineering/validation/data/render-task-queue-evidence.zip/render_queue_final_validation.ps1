$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'E:/Dev/aem/.worktrees/render-task-queue'
. E:/Dev/aem/artifacts/multiple-camera-layers/env.ps1
$env:CARGO_TARGET_DIR = 'E:/Dev/aem/target/host-error-contract-verified'
$env:CARGO_BUILD_JOBS = '1'
$evidenceRoot = 'E:/Dev/aem/artifacts/pr-ci-followups'
$previewRoot = 'E:/Dev/aem/artifacts/render-queue-preview'
rustfmt --edition 2021 --config skip_children=true desktop/app/src/render_queue/controller.rs desktop/app/src/render_queue/worker.rs desktop/app/src/panels/auxiliary/render_queue.rs desktop/app/src/panels/auxiliary/render_queue/tests.rs desktop/app/src/panels/auxiliary/render_queue/tests/native.rs
if ($LASTEXITCODE -ne 0) { throw 'rustfmt failed' }
function Invoke-QueueCheck([string]$checkName, [string[]]$cargoArguments) {
    $phase = @{ phase = $checkName; command = @('cargo') + $cargoArguments; started = [DateTime]::UtcNow.ToString('o') }
    $phase | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$evidenceRoot/render-queue-final-phase.json" -Encoding utf8
    Write-Output "Starting $checkName"
    & cargo @cargoArguments *> "$evidenceRoot/render-queue-final-$checkName.log"
    if ($LASTEXITCODE -ne 0) { throw "$checkName failed: $LASTEXITCODE" }
}
Invoke-QueueCheck 'noffmpeg' @('test','-p','motion-desktop','--bin','motion-studio','--no-default-features','render_queue','--','--test-threads=1')
Invoke-QueueCheck 'targeted-recovery' @('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','render_queue','--','--test-threads=1')
Invoke-QueueCheck 'auxiliary' @('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','panels::auxiliary','--','--test-threads=1')
Invoke-QueueCheck 'work-area' @('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','native_work_area_drag_save_undo_main_float_bilingual','--','--test-threads=1')
$env:MOTION_RENDER_QUEUE_NATIVE_ARTIFACTS = "$evidenceRoot/render-queue-native-final-recovery"
Invoke-QueueCheck 'native-recovery' @('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','render_queue_native_tasks_templates_and_actual_output','--','--ignored','--test-threads=1')
Remove-Item Env:MOTION_RENDER_QUEUE_NATIVE_ARTIFACTS
$queueTestExecutable = 'E:/Dev/aem/target/host-error-contract-verified/debug/deps/motion_studio-2d9fbaae843f8623.exe'
$env:MOTION_RENDER_QUEUE_ERROR_ROOT = "$evidenceRoot/render-queue-default-final-recovery"
New-Item -ItemType Directory -Path $env:MOTION_RENDER_QUEUE_ERROR_ROOT -Force | Out-Null
& $queueTestExecutable --exact render_queue::worker::tests::render_queue_default_error_sinks_and_inflight_are_visible_before_a_handler_returns --nocapture 1> "$env:MOTION_RENDER_QUEUE_ERROR_ROOT/stdout.log" 2> "$env:MOTION_RENDER_QUEUE_ERROR_ROOT/stderr.log"
if ($LASTEXITCODE -ne 0) { throw "default-error-output failed: $LASTEXITCODE" }
Remove-Item Env:MOTION_RENDER_QUEUE_ERROR_ROOT
Invoke-QueueCheck 'build' @('build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg')
Copy-Item -LiteralPath 'E:/Dev/aem/target/host-error-contract-verified/debug/motion-studio.exe' -Destination "$previewRoot/motion-studio.exe" -Force
Get-FileHash -Algorithm SHA256 -LiteralPath "$previewRoot/motion-studio.exe" | ConvertTo-Json | Set-Content -LiteralPath "$evidenceRoot/render-queue-final-executable.json" -Encoding utf8
git diff --name-only 2308323b761b5ce47c248891b49a3ec63f31c552 -- desktop crates Cargo.toml Cargo.lock | ForEach-Object { Get-FileHash -Algorithm SHA256 -LiteralPath $_ } | ConvertTo-Json | Set-Content -LiteralPath "$evidenceRoot/render-queue-final-source-before-full.json" -Encoding utf8
Invoke-QueueCheck 'desktop-full' @('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--','--test-threads=1')
