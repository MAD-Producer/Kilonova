"""Package actual render-queue evidence; no fabricated outputs or font payloads."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = Path('E:/Dev/aem/.worktrees/render-task-queue')
ART = Path('E:/Dev/aem/artifacts/pr-ci-followups')
PREVIEW = Path('E:/Dev/aem/artifacts/render-queue-preview')
NATIVE = ART / 'render-queue-native-final-recovery'
DEFAULT = ART / 'render-queue-default-final-recovery'
PARENT = '2308323b761b5ce47c248891b49a3ec63f31c552'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def suites(name):
    text = (ART / name).read_text(encoding='utf-8-sig')
    results = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    if not results or 'test result: FAILED' in text:
        raise RuntimeError(f'No complete successful test result: {name}')
    counts = [tuple(map(int, row)) for row in results]
    assert all(failed == 0 for _, failed, _ in counts)
    return {'passed': sum(row[0] for row in counts), 'failed': 0,
            'ignored': sum(row[2] for row in counts), 'suites': len(counts),
            'log': name, 'sha256': sha(ART / name)}


checks = {
    'durable': suites('render-queue-durable-ownership-final.log'),
    'publication': suites('render-queue-publication-initial.log'),
    'capture_identity': suites('render-queue-capture-identity.log'),
    'queue_final': suites('render-queue-final-targeted-recovery.log'),
    'auxiliary_final': suites('render-queue-final-auxiliary.log'),
    'native_final': suites('render-queue-final-native-recovery.log'),
    'media_full': suites('render-queue-main-media.log'),
    'without_ffmpeg': suites('render-queue-final-noffmpeg.log'),
    'original_work_area_recovery': suites('render-queue-final-work-area.log'),
}
checks['media_full']['phase'] = 'Main integration before final template receipt changes; media production source unchanged.'
baseline_path = ART / 'render-queue-desktop-full.log'
baseline = re.findall(r'test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored;', baseline_path.read_text(encoding='utf-8-sig'))[-1]
assert tuple(map(int, baseline)) == (1172, 1, 11)
checks['desktop_full_initial'] = {
    'phase': 'Original work-area native assertion exposed paint-triggered Open intent. Fixed by moving on-demand open to Shell lifecycle; original assertions retained and rerun.',
    'passed': 1172, 'failed': 1, 'ignored': 11,
    'log': baseline_path.name, 'sha256': sha(baseline_path),
    'failed_test': 'panels::work_area::tests::native::native_work_area_drag_save_undo_main_float_bilingual',
    'executable_sha256': 'f1a6def095653b46f44ef8abbbdd29b663b7ba9e12ce54f36dc749a5e6e86b0f',
}
interrupted = ART / 'render-queue-main-desktop-full.log'
checks['desktop_full_before_receipt'] = {
    'state': 'intentionally_stopped_for_template_receipt_fix',
    'log': interrupted.name, 'sha256': sha(interrupted),
    'reason': (ART / 'render-queue-main-desktop-full-stop-reason.txt').read_text(encoding='utf-8-sig').strip(),
}
full_path = ART / 'render-queue-final-desktop-full.log'
checks['desktop_full_final'] = {'state': 'pending_or_running_at_packaging', 'log': full_path.name}
if full_path.exists() and re.search(r'test result: ok\. \d+ passed; 0 failed;', full_path.read_text(encoding='utf-8-sig')):
    checks['desktop_full_final'] = suites(full_path.name)
build = ART / 'render-queue-final-build.log'
assert 'Finished `dev` profile' in build.read_text(encoding='utf-8-sig')
assert checks['queue_final']['passed'] == 22
assert checks['native_final']['passed'] == 1
assert checks['original_work_area_recovery']['passed'] == 1
assert checks['without_ffmpeg']['passed'] == 15
assert (DEFAULT / 'motion-studio.log').is_file()
for path in [DEFAULT / 'motion-studio.log', DEFAULT / 'stderr.log']:
    text = path.read_text(encoding='utf-8-sig')
    assert 'render queue worker panicked: controlled render queue handler panic' in text
assert 'controlled render queue handler panic' not in (DEFAULT / 'stdout.log').read_text(encoding='utf-8-sig')

assert (PREVIEW / 'motion-studio.exe').is_file(), 'Use the executable copied immediately after the main build.'
env = os.environ.copy()
system_root = env.get('SystemRoot') or env.get('SYSTEMROOT')
assert system_root, 'The verification process must retain the Windows system root.'
env['PATH'] = str(PREVIEW) + ';' + str(Path(system_root) / 'System32')
commands = subprocess.run([str(PREVIEW / 'motion-studio.exe'), '--command-list'],
                          env=env, capture_output=True, check=True)
json.loads(commands.stdout)
assert not commands.stderr
(ART / 'render-queue-preview-commands.json').write_bytes(commands.stdout)
(ART / 'render-queue-preview-commands.stderr').write_bytes(commands.stderr)
video = subprocess.run([str(PREVIEW / 'motion-studio.exe'), '--video-smoke', str(NATIVE / 'frozen-0.mp4')],
                       env=env, capture_output=True, check=True)
decoded = json.loads(video.stdout)
assert decoded['backend'] == 'libav' and decoded['decoded']
assert decoded['sourceFrames'] == 3
assert all(frame['width'] == 32 and frame['height'] == 24 for frame in decoded['frames'])
(ART / 'render-queue-preview-video.json').write_bytes(video.stdout)
(ART / 'render-queue-preview-video.stderr').write_bytes(video.stderr)

changed = subprocess.check_output(['git', 'diff', '--name-only', PARENT], cwd=ROOT, text=True).splitlines()
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
source_paths = sorted({name for name in changed + untracked
                       if name.startswith(('desktop/', 'crates/')) or name in ('Cargo.toml', 'Cargo.lock')})
sources = {name: sha(ROOT / name) for name in source_paths if (ROOT / name).is_file()}
build_info = {
    'parent': PARENT,
    'production_source_sha256': sources,
    'executable_sha256': sha(PREVIEW / 'motion-studio.exe'),
    'ffmpeg_runtime': [{'file': p.name, 'sha256': sha(p)} for p in sorted(PREVIEW.glob('*.dll'))],
    'minimal_path': env['PATH'],
    'command_list_json_stdout': True,
    'command_list_empty_stderr': True,
    'video_runtime': decoded,
}
assert len(build_info['ffmpeg_runtime']) == 7
write_json(PREVIEW / 'BUILD-INFO.json', build_info)

images = ROOT / 'engineering/validation/render-task-queue'
images.mkdir(parents=True, exist_ok=True)
for name in ['zh-queue.png', 'zh-template.png', 'zh-floating-dpi15.png', 'zh-floating-tooltip.png', 'zh-failed.png', 'en-template-created.png']:
    shutil.copy2(NATIVE / name, images / name)

payloads = {}
for pattern in ['render-queue*.log', 'render-queue-preview-*', 'render-queue-main-desktop-full-stop-reason.txt']:
    for path in ART.glob(pattern):
        if path.is_file():
            if path.name == 'render-queue-final-package.log':
                continue  # This script is currently writing that wrapper log.
            if path == full_path and checks['desktop_full_final'].get('state'):
                continue
            payloads[f'logs/{path.name}'] = path
for directory in [NATIVE, DEFAULT]:
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in {'.png', '.mp4', '.json', '.log'}:
            payloads[f'{directory.name}/{path.relative_to(directory).as_posix()}'] = path
payloads['preview/BUILD-INFO.json'] = PREVIEW / 'BUILD-INFO.json'
payloads['render_queue_evidence.py'] = Path(__file__)
payloads['render_queue_final_validation.ps1'] = ART / 'render_queue_final_validation.ps1'
for name in ['render-queue-final-executable.json', 'render-queue-final-source-before-full.json']:
    payloads[f'logs/{name}'] = ART / name
manifest = [{'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path)}
            for name, path in sorted(payloads.items())]
assert not any(Path(row['path']).suffix in {'.ttf', '.ttc', '.otf', '.dll', '.exe'} for row in manifest)
archive = ROOT / 'engineering/validation/data/render-task-queue-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
    for name, path in sorted(payloads.items()):
        bundle.write(path, name)
    bundle.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
result = {
    'issue': 240,
    'parent': PARENT,
    'source_sha256': sources,
    'checks': checks,
    'build': {'log': build.name, 'sha256': sha(build), 'passed': True},
    'preview': build_info,
    'artifact': {'path': str(archive.relative_to(ROOT)).replace('\\', '/'),
                 'entries': len(payloads) + 1, 'bytes': archive.stat().st_size, 'sha256': sha(archive)},
    'ci': 'Pending on final PR head; parent checks are not substituted.',
    'limits': ['Windows native captures use controlled production Input, not foreground OS IME injection.',
               'Crash/power-loss durability is not claimed; tooltips wrap within the current panel capacity.',
               'Controlled block exercises production observation decorator; handler panic exercises the actual serial worker.'],
}
write_json(ROOT / 'engineering/validation/render-task-queue-results.json', result)
print(json.dumps({'checks': checks, 'artifact': result['artifact'],
                  'preview_executable_sha256': build_info['executable_sha256']}, ensure_ascii=False))
