from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

root=Path('E:/Dev/aem'); work=root/'.worktrees/video-depth-geometry'
out=root/'artifacts/pr-queue/frozen-video-cancel-red-v1'; out.mkdir(exist_ok=False)
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=work).decode().split('\0')
source={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml')) or p=='Cargo.lock')}
shutil.copyfile(__file__,out/'controller.py')
for p in ['crates/motion-desktop-media/src/movie.rs','crates/motion-desktop-media/src/movie/video_depth_tests.rs']:
    target=out/'source'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/p,target)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true',MOTION_REAL_VIDEO_DEPTH_ARTIFACTS=str(out/'renders'));env.pop('MOTION_LOG',None)
command=['cargo','test','-p','motion-desktop-media','--lib','--features','ffmpeg,gpu-tests,ai-depth','--locked','--offline','--','--exact','movie::video_depth_tests::cancellation::cancellation_inside_real_frozen_video_decoder_preserves_protocol_reason_and_complete_output','--test-threads=1']
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
    code=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
unchanged=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in source.items())
counts=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',(out/'stdout.log').read_text(encoding='utf-8'))
report=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),source=source,command=command,exitCode=code,sourceUnchanged=unchanged,counts=counts,completedUtc=datetime.now(timezone.utc).isoformat(),scope='Actual libav H.264 source RGB + controlled scalar backend + native GPU depth, re-encoded and fully decoded output; not durable temporal export or trained-model acceptance')
(out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='source'}),flush=True)
assert code!=0 and unchanged and counts==[('0','1','0')]
assert 'the engine recognizes this exact protocol reason' in (out/'stdout.log').read_text(encoding='utf-8')
(out/'reproduced.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
