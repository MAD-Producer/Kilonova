from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

root = Path('E:/Dev/aem'); work = root/'.worktrees/video-depth-geometry'
out = root/'artifacts/pr-queue/frozen-temporal-depth-native-v5'; out.mkdir(exist_ok=False)
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true', MOTION_VIDEO_DEPTH_TIMELINE_ARTIFACTS=str(out/'timeline-renders'), MOTION_REAL_VIDEO_DEPTH_ARTIFACTS=str(out/'renders'), MOTION_FROZEN_DEPTH_ARTIFACTS=str(out/'static-renders'))
env['MOTION_KEY_TIMING_MOVIE_ARTIFACTS']=str(out/'manual-key-timing-renders')
env.pop('MOTION_LOG', None)
paths = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'], cwd=work).decode().split('\0')
source = {p: hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml')) or p == 'Cargo.lock')}
git = lambda *args: subprocess.check_output(['git',*args], cwd=work).decode().strip()
for path in set(git('diff','--name-only','HEAD').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()):
    if path in source:
        dest = out/'source'/path; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(work/path,dest)
prior=json.loads((root/'artifacts/pr-queue/frozen-temporal-depth-native-v4/exit.json').read_text(encoding='utf-8'))
assert prior['source']==source
assert len(prior['steps'])==1
assert prior['steps'][0]['exitCode']==0 and prior['steps'][0]['sourceUnchanged'] and prior['steps'][0]['counts']==[['58','0','1']]
assert 'manual GPU and FFmpeg output proof' in (root/'artifacts/pr-queue/frozen-temporal-depth-native-v4/media-library.stdout.log').read_text(encoding='utf-8')
prior['steps'][0]['ignoredTestExecutedBy']='manual-key-timing'
report = dict(base=git('rev-parse','HEAD'), source=source, steps=prior['steps'].copy(), scope='Bounded indexed-video calibration authoring, actual decoder admission, temporal FIFO retention with current samples pinned, automatic staging and native GPU playback; including real H.264 source and independent frozen temporal export; not trained model quality, complex depth, DOF or final workspace acceptance')
shutil.copyfile(__file__,out/'controller.py')
tests = lambda *args: ['cargo','test',*args,'--locked','--offline','--','--test-threads=1']
steps = [
    ('manual-key-timing', ['cargo','test','-p','motion-desktop-media','--lib','--features','ffmpeg,gpu-tests,ai-depth','--locked','--offline','--','--ignored','--exact','movie::keyframe_timing_tests::frozen_keyframe_timing_matches_reopened_pixels_and_differs_from_linear_and_removed_layer','--test-threads=1']),
    ('video', tests('-p','motion-host','--features','ai-depth','--test','depth_video')),
    ('host-library', tests('-p','motion-host','--features','ai-depth','--lib')),
    ('session', tests('-p','motion-host','--features','ai-depth','--test','depth_session')),
    ('model', tests('-p','motion-model','--test','depth_video_track')),
    ('core', tests('-p','motion-core','--test','video_depth_calibration','--test','depth_calibration','--test','layer_clipboard')),
    ('host-without-depth', ['cargo','check','-p','motion-host','--no-default-features','--locked','--offline']),
    ('desktop', ['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),
    ('style', ['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
    ('provenance',['python','tools/validate_provenance.py']),
]
minimum = {'manual-key-timing':1, 'video':19, 'host-library':113, 'session':17, 'model':4, 'core':16}
for name, command in steps:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
        code = subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
    unchanged = all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in source.items())
    row = dict(name=name,command=command,exitCode=code,sourceUnchanged=unchanged)
    if name in minimum:
        row['counts'] = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',(out/f'{name}.stdout.log').read_text(encoding='utf-8'))
    report['steps'].append(row); report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8'); print(json.dumps(row),flush=True)
    assert code==0 and unchanged,name
    if name in minimum:
        assert row['counts'] and sum(int(p) for p,_,_ in row['counts'])>=minimum[name] and all(int(f)==int(i)==0 for _,f,i in row['counts']),row
assert len(list((root/'artifacts/pr-queue/frozen-temporal-depth-native-v4/renders').rglob('*.mp4')))==12
assert len(list((root/'artifacts/pr-queue/frozen-temporal-depth-native-v4/renders').rglob('*.png')))==28
assert len(list((root/'artifacts/pr-queue/frozen-temporal-depth-native-v4/renders').rglob('comparison.json')))==8
assert len(list((root/'artifacts/pr-queue/frozen-temporal-depth-native-v4/renders').rglob('depth.snapshot')))==4
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')

