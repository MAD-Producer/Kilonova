"""Publish authored aggregates and receipts, excluding dataset-derived arrays."""
from pathlib import Path
import hashlib
import json
import zipfile

ART = Path('E:/Dev/aem/artifacts/pr-queue')
ROOT = ART / 'tracking88-mousepad-flow-phases-v1'
OUT = ART / 'tracking88-flow-phases-public-v1'
OUT.mkdir(exist_ok=False)
r = json.loads((ROOT / 'receipt.json').read_text())
consumed = json.loads((ROOT / 'session-consumed.json').read_text())
assert consumed['original_tool_result_consumed'] and consumed['source_freeze_released']
assert consumed['exit_code'] == 0 and r['source_unchanged'] and r['inputs_unchanged']
assert r['status'] == 'selected_phase_comparison_measured_not_quality_acceptance'
for name, digest in consumed['files'].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
files = {name: (ROOT / name).read_bytes() for name in (
    'controller.py', 'receipt.json', 'session-consumed.json', 'observation.log', 'decode.stderr.log')}
files['consumer.py'] = (ART / 'tracking88-mousepad-flow-phases-consume-v1.py').read_bytes()
files['collector.py'] = Path(__file__).read_bytes()
archive = OUT / 'tracking88-flow-phases-v1.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
    for name, raw in sorted(files.items()):
        target.writestr(name, raw)
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(files)
    assert all(target.read(name) == raw for name, raw in files.items())
manifest = dict(archive=archive.name, bytes=archive.stat().st_size,
                sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), members=len(files),
                head=r['head'], source_unchanged=True,
                scope='Selected phase measurement, not algorithm adoption or full quality acceptance',
                excluded=['Media', 'Corner annotations', 'Derived images', 'Correspondence arrays',
                          'Complete observations', 'Model/runtime/dependency payloads'],
                files={name: dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
                       for name, raw in sorted(files.items())})
(OUT / 'tracking88-flow-phases-v1.json').write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
print(json.dumps({k: manifest[k] for k in ('archive', 'bytes', 'sha256', 'members')}))
