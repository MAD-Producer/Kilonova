"""Selected first-loss phase comparison; labels enter only after output sealing."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import logging
import os
import subprocess
import sys
import traceback
import zipfile

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/planar-tracker88'
OUT = ART / 'tracking88-mousepad-flow-phases-v1'
CP = ART / 'depth75-resume-current.json'
HEAD = 'cd4456135a169018e343fd79c5e85f09fd04c3ca'
DATA = ART / 'tracking88-real-planar-acquisition-v1'
BASE = ART / 'tracking88-mousepad-full-core-v1'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, value):
    pending = path.with_suffix(path.suffix + '.pending')
    pending.write_bytes((json.dumps(value, indent=2, allow_nan=False) + '\n').encode())
    pending.replace(path)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK, text=True).strip()


state = read(CP)
v = state['versionedCache75']
assert v['activeController'] is None and not v['ownHeavyWorkloads']
assert git('rev-parse', 'HEAD') == HEAD and not git('status', '--porcelain')
assert read(BASE / 'session-consumed.json')['original_tool_result_consumed']
assert sha(DATA / 'mouse-pad.avi') == 'f7cfe7d11fb64111777b6074a21bc58de7fc500ebce15f26577ee0ba2c4f890f'
assert sha(DATA / 'mouse-pad-gt.zip') == '532e0091d649f26d2158261ce1b42e4775fc91bb73c3502d23ed9744b67dba7a'
baseline = BASE / 'no-corrections/observations.jsonl'
assert sha(baseline) == read(BASE / 'receipt.json')['blind_output_seals'][0]['sha256']
hashes = {name: sha(WORK / name) for name in git('ls-files').splitlines()}
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
os.environ.update(TEMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'),
                  TMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'), PYTHONDONTWRITEBYTECODE='1')
report = dict(status='running', head=HEAD, source_sha256=hashes,
              started_utc=datetime.now(timezone.utc).isoformat(), in_flight=None,
              input_sha256={p.name: sha(p) for p in [DATA / 'mouse-pad.avi', DATA / 'mouse-pad-gt.zip', baseline]},
              protocol=dict(selected_indices=list(range(15)), selected_after_original_failure=True,
                            unchanged_tracker=True, parameter_search=False, annotation_reads_after_sealing=True,
                            phase_comparison=['adjacent', 'anchored', 'prediction', 'final'],
                            labels='Original four source-plane corner annotations at0 and14; same row/column convention'),
              limits=['Selected diagnostic, not blind generalization or complete-video acceptance',
                      'Annotated homography is a four-corner reference with annotation/lens/planarity uncertainty',
                      'No labels used for feature selection, fitting, candidate selection or tracker decisions',
                      'No algorithm, gates, existing assertions or coverage qualification changes'])
log = logging.getLogger('tracking88.flow_phases')
log.setLevel(logging.INFO)
sink = logging.FileHandler(OUT / 'observation.log', encoding='utf-8')
sink.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
console = logging.StreamHandler(sys.stderr)
console.setLevel(logging.ERROR)
log.addHandler(sink)
log.addHandler(console)
v.update(activeController=str(Path(__file__)), ownHeavyWorkloads=[dict(
    kind='selected original first-loss phase diagnostic', head=HEAD, output=str(OUT), sourceFrozen=True)])
write(CP, state)


def start(operation):
    report['in_flight'] = dict(operation=operation, utc=datetime.now(timezone.utc).isoformat())
    write(OUT / 'receipt.json', report)
    log.info('start operation=%s', operation)
    sink.flush()


try:
    start('import_existing_cv_runtime')
    sys.path.insert(0, str(WORK / 'tools/tracking'))
    import plate_flow as flow
    import numpy as np
    flow.cv2.setNumThreads(1)
    flow.cv2.setRNGSeed(88)
    original_flow, original_find = flow.flow, flow.cv2.findHomography
    calls, phases = [], []

    def observed_flow(*args, **kwargs):
        result = original_flow(*args, **kwargs)
        phases.append(tuple(a.copy() for a in result))
        return result

    def observed_find(*args, **kwargs):
        result = original_find(*args, **kwargs)
        calls.append(tuple(None if a is None else a.copy() for a in result))
        return result

    start('decode_original_indices_0_to_14')
    ff = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
    decoded = subprocess.run([str(ff), '-v', 'error', '-nostdin', '-threads', '1', '-noautorotate',
        '-copyts', '-i', str(DATA / 'mouse-pad.avi'), '-an', '-sn', '-dn',
        '-vf', r'select=lte(n\,14)', '-fps_mode', 'passthrough', '-threads', '1',
        '-f', 'rawvideo', '-pix_fmt', 'gray', 'pipe:1'], capture_output=True)
    (OUT / 'decode.stderr.log').write_bytes(decoded.stderr)
    assert decoded.returncode == 0 and not decoded.stderr and len(decoded.stdout) == 15 * 640 * 480
    images = np.frombuffer(decoded.stdout, np.uint8).reshape(15, 480, 640)
    expected = [json.loads(line) for line in baseline.read_text().splitlines()[:15]]
    flow.flow, flow.cv2.findHomography = observed_flow, observed_find
    previous = None
    observations = []
    for index, image in enumerate(images):
        start(f'unchanged_frame_{index}')
        gray = flow.prepare(image)
        calls.clear()
        phases.clear()
        if index == 0:
            tracker = flow.Tracker(dict(id='plane', kind='plane', roi=[200., 140., 340., 260.]), gray)
            observation, confidence = tracker.initial, 1.
        else:
            before = tracker.reference.copy()
            observation, confidence = tracker.observe(previous, gray)
        prior = next(t for t in expected[index]['tracks'] if t['id'] == 'plane')
        assert observation == prior['observation'] and confidence == prior['confidence']
        assert (tracker.reason is None and prior['reason'] is None) or tracker.reason.startswith(prior['reason'] + ':')
        observations.append(dict(index=index, observation=observation, confidence=confidence, reason=tracker.reason))
        if index == 14:
            assert observation is None and len(calls) == 2 and len(phases) == 2
            lookup = {tuple(point): slot for slot, point in enumerate(before)}
            kept = [lookup[tuple(point)] for point in tracker.reference]
            assert len(set(kept)) == len(kept)
            arrays = dict(reference=tracker.reference.copy(), heldout=tracker.holdout.copy(),
                          adjacent=phases[0][0][kept], anchored=tracker.points.copy(),
                          prediction=calls[0][0], final=calls[1][0])
        previous = gray.copy()
    flow.flow, flow.cv2.findHomography = original_flow, original_find
    write(OUT / 'blind-observations.json', observations)
    np.savez(OUT / 'blind-correspondences.npz', **arrays)
    report['blind_seals'] = {name: sha(OUT / name) for name in ('blind-observations.json', 'blind-correspondences.npz')}
    report['original_observations_preserved'] = True
    report['original_rejection'] = tracker.reason
    write(OUT / 'receipt.json', report)

    start('read_two_original_corner_annotations_after_sealing')
    with zipfile.ZipFile(DATA / 'mouse-pad-gt.zip') as archive:
        quads = []
        for index in (0, 14):
            a = np.array([float(x) for x in archive.read(f'img_{index + 100:05d}.txt').decode('ascii').split()]).reshape(2, 4)
            quads.append(np.column_stack((a[1] - 1., a[0] - 1.)))
    reference_matrix, _ = original_find(quads[0], quads[1], 0)
    assert reference_matrix is not None
    target = flow.transform(reference_matrix, arrays['reference'])

    def stats(values):
        return dict(count=len(values), rms_px=float(np.sqrt(np.mean(values**2))),
                    median_px=float(np.median(values)), p95_px=float(np.quantile(values, .95)),
                    maximum_px=float(values.max()), above_1_5_px=int(np.sum(values > 1.5)),
                    above_3_px=int(np.sum(values > 3)))

    report['phase_comparison'] = {}
    for name in report['protocol']['phase_comparison']:
        points = arrays[name] if name in ('adjacent', 'anchored') else flow.transform(arrays[name], arrays['reference'])
        error = np.linalg.norm(points - target, axis=1)
        report['phase_comparison'][name] = {
            label: stats(error[mask]) for label, mask in [('fit', ~arrays['heldout']), ('heldout', arrays['heldout'])]
        }
    report['anchor_step_px'] = stats(np.linalg.norm(arrays['anchored'] - arrays['adjacent'], axis=1))
    report['corner_reference_disagreement_px'] = {
        name: stats(np.linalg.norm(flow.transform(arrays[name], quads[0]) - quads[1], axis=1))
        for name in ('prediction', 'final')
    }
    assert all(sha(OUT / name) == digest for name, digest in report['blind_seals'].items())
    report['status'] = 'selected_phase_comparison_measured_not_quality_acceptance'
except BaseException:
    report.update(status='failed_original_outputs_retained', cause=traceback.format_exc())
    log.error('operation=%s cause=%s', report['in_flight'], report['cause'][-8192:])
finally:
    report.update(in_flight=None, completed_utc=datetime.now(timezone.utc).isoformat(),
                  source_unchanged=git('rev-parse', 'HEAD') == HEAD and not git('status', '--porcelain')
                  and all(sha(WORK / name) == digest for name, digest in hashes.items()),
                  inputs_unchanged=all(sha(path) == report['input_sha256'][path.name]
                                       for path in [DATA / 'mouse-pad.avi', DATA / 'mouse-pad-gt.zip', baseline]))
    write(OUT / 'receipt.json', report)
    sink.close()
    print(json.dumps({k: report.get(k) for k in ('status', 'cause', 'phase_comparison', 'anchor_step_px', 'source_unchanged')}))
raise SystemExit(0 if report['status'].startswith('selected_phase_comparison_measured')
                 and report['source_unchanged'] and report['inputs_unchanged'] else 1)
