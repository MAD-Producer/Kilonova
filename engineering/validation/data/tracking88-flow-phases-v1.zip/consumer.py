from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

ART = Path('E:/Dev/aem/artifacts/pr-queue')
OUT = ART / 'tracking88-mousepad-flow-phases-v1'
WORK = Path('E:/Dev/aem/.worktrees/planar-tracker88')
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
r = read(OUT / 'receipt.json')
assert r['status'] == 'selected_phase_comparison_measured_not_quality_acceptance'
assert r['source_unchanged'] and r['inputs_unchanged'] and r['original_observations_preserved']
assert all(sha(WORK / name) == digest for name, digest in r['source_sha256'].items())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == r['head']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK, text=True).strip()
assert all(sha(OUT / name) == digest for name, digest in r['blind_seals'].items())
proof = dict(session=27677, original_chunk_id='836476', exit_code=0,
             original_tool_result_consumed=True, source_unchanged=True, source_freeze_released=True,
             consumed_utc=datetime.now(timezone.utc).isoformat(),
             status='selected_phase_evidence_complete_not_algorithm_or_quality_acceptance',
             files={p.name: sha(p) for p in OUT.iterdir() if p.is_file()})
(OUT / 'session-consumed.json').write_bytes((json.dumps(proof, indent=2) + '\n').encode())
cp = ART / 'depth75-resume-current.json'
s = read(cp)
v = s['versionedCache75']
assert v['activeController'] == str(ART / 'tracking88-mousepad-flow-phases-v1-controller.py')
v.update(activeController=None, ownHeavyWorkloads=[], currentTrackerPhaseDiagnostic=proof)
v['currentGoalTurnAudit'] = dict(
    classification='progress', goal_complete=False, issue75_complete=False, issue88_complete=False,
    new_evidence=['Exact-source three-platform CI archived and published as validation-only commit',
                  'Independent native metadata-check compiler failure retained with original full failures',
                  'Selected first-loss phase outputs sealed before reference annotation comparison'],
    previous_goal_turn='progress: actual source observations and whole-stream equivalence, main integration',
    no_subagents=True, no_panels_changes=True, no_asset_acquisition=True,
    remaining=['Tracker/depth actual quality qualification', 'Original local compiler/runtime failures',
               'Current tracker CI and validation-only depth commit CI'])
cp.write_bytes((json.dumps(s, indent=2) + '\n').encode())
print(json.dumps({k: proof[k] for k in ('session', 'exit_code', 'status')}))
