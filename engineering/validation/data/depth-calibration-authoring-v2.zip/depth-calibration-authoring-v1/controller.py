"""Freeze authoring sources and retain actual host/core failure-path evidence."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

root = Path('E:/Dev/aem')
work = root/'.worktrees/depth-authoring'
out = root/'artifacts/pr-queue/depth-calibration-authoring-v1'
out.mkdir(exist_ok=False)
git = lambda *args: subprocess.check_output(['git', *args], cwd=work).decode().strip()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert (root/'artifacts/pr-queue/camera-source-editing-native-v2/accepted.json').exists()
base = '8b1610282864e4738c7fe245f1ab9e9644c5f0f4'
assert git('rev-parse', 'HEAD') == base
paths = git('ls-files', '-co', '--exclude-standard', '-z').split('\0')
source = {p:sha(work/p) for p in sorted(set(paths)) if p and
          (p.endswith(('.rs','.py','.toml','.wgsl','.json')) or p=='Cargo.lock')}
changed = sorted(set(git('diff','--name-only',base).splitlines()+git('ls-files','--others','--exclude-standard').splitlines()))
for p in changed:
    dest = out/'source'/p
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(work/p, dest)
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary',base],cwd=work))
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1',
    CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG',None)
def tests(package, targets, features=None, lib=False):
    cmd=['cargo','test','-p',package]
    if features: cmd+=['--features',features]
    if lib: cmd+=['--lib']
    for target in targets: cmd+=['--test',target]
    return cmd+['--locked','--offline','--no-fail-fast','--','--test-threads=1']
steps=[('provenance',[sys.executable,'tools/validate_provenance.py']),
    ('panel-style',[sys.executable,'-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
    ('model',tests('motion-model',[])+[]),
    ('core',tests('motion-core',['depth_calibration','command_registry','prepared_commands','layer_clipboard',
        'media_assets','composition_candidate_graphs','composition_resources','compositions','scoped_command_transport',
        'imported_cameras','parenting','parent_modes','model_layers'])),
    ('host',tests('motion-host',['depth_jobs','depth_session','depth_video','failure_boundaries',
        'imported_cameras','resource_composition_details','image_candidate_contract','session_concurrency'], 'gpu-tests,ai-depth',True)),
    ('host-without-depth',['cargo','check','-p','motion-host','--no-default-features','--locked','--offline']),
    ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'])]
# No --test restriction selects the entire model package, including doc tests.
steps[2]=('model',['cargo','test','-p','motion-model','--locked','--offline','--no-fail-fast','--','--test-threads=1'])
receipt=dict(startedUtc=datetime.now(timezone.utc).isoformat(),base=base,source=source,changedSource=changed,
    scope='Prepared RGB identity, persisted validated calibration, commands/history/clipboard, actual session reopen and guarded current-result rebind; render/reprojection/DOF not claimed',steps=[])
for name,command in steps:
    assert all(sha(work/p)==h for p,h in source.items())
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        code=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
    row=dict(name=name,command=command,exitCode=code,sourceUnchanged=all(sha(work/p)==h for p,h in source.items()))
    output=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
    if name in ('model','core','host'):
        results=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',output)
        row.update(targets=len(results),totals=dict(zip(('passed','failed','ignored'),[sum(int(v[i]) for v in results) for i in range(3)])))
    receipt['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    assert code==0 and row['sourceUnchanged'],name
    if 'totals' in row:
        assert row['targets']>0 and row['totals']['failed']==0 and row['totals']['ignored']==0
    if name=='host':
        for test in ('actual_calibration_authoring_reopens_and_rebinds_without_reusing_live_revisions',
            'saved_calibration_refuses_changed_pixels_and_processing_with_explicit_reauthoring_recovery',
            'calibration_authoring_rejects_pending_canceled_and_changed_candidate_sources_atomically',
            'prepared_input_fingerprint_comes_from_actual_pixels_and_dimensions',
            'prepared_output_cannot_escape_live_key_or_cancellation_guards',
            'installed_input_identity_survives_reopen_and_detects_changed_pixels_at_same_asset_key',
            'video_prepared_fingerprint_is_computed_after_bt709_to_srgb_conversion'):
            assert 'test '+test+' ... ok' in output,test
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=True)
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True)),flush=True)
