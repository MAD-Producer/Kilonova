"""Serialize target use after the camera gate; retain real logs and source hashes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,re,shutil,subprocess,sys,time
root=Path('E:/Dev/aem')
work=root/'.worktrees/depth-authoring'
out=root/'artifacts/pr-queue/depth-prepared-input-v2'
out.mkdir(exist_ok=False)
git=lambda *args:subprocess.check_output(['git',*args],cwd=work).decode().strip()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
base='8b1610282864e4738c7fe245f1ab9e9644c5f0f4'
assert git('rev-parse','HEAD')==base
paths=git('ls-files','-co','--exclude-standard','-z').split('\0')
source={p:sha(work/p) for p in sorted(set(paths)) if p and (p.endswith(('.rs','.py','.toml','.wgsl','.json')) or p=='Cargo.lock')}
changed=sorted(set(git('diff','--name-only',base).splitlines()+git('ls-files','--others','--exclude-standard').splitlines()))
for p in changed:
    dest=out/'source'/p
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(work/p,dest)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
receipt=dict(startedUtc=datetime.now(timezone.utc).isoformat(),head=base,source=source,changedSource=changed,
    scope='Actual worker-prepared RGB fingerprint and current-session guarded installation; no saved calibration or depth-render bridge claimed',steps=[])
waiting=root/'artifacts/pr-queue/camera-source-editing-native-v2/accepted.json'
print(json.dumps(dict(waitingFor=str(waiting))),flush=True)
while not waiting.exists():
    time.sleep(2)
    if (root/'artifacts/pr-queue/camera-source-editing-native-v2/exit.json').exists():
        prior=json.loads((root/'artifacts/pr-queue/camera-source-editing-native-v2/exit.json').read_text())
        if any(step['exitCode'] for step in prior['steps']):
            raise RuntimeError('Earlier source gate failed; inspect before sharing its target')
env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG',None)
steps=[('provenance',[sys.executable,'tools/validate_provenance.py']),
    ('model',['cargo','test','-p','motion-model','--locked','--offline','--no-fail-fast','--','--test-threads=1']),
    ('host-depth',['cargo','test','-p','motion-host','--features','ai-depth','--test','depth_jobs','--test','depth_session','--test','depth_video','--locked','--offline','--no-fail-fast','--','--test-threads=1']),
    ('host-without-depth',['cargo','check','-p','motion-host','--no-default-features','--locked','--offline']),
    ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'])]
for name,command in steps:
    assert all(sha(work/p)==h for p,h in source.items())
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        code=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
    row=dict(name=name,command=command,exitCode=code,sourceUnchanged=all(sha(work/p)==h for p,h in source.items()))
    output=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
    if name in ('model','host-depth'):
        results=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',output)
        row.update(targets=len(results),totals=dict(zip(('passed','failed','ignored'),[sum(int(v[i]) for v in results) for i in range(3)])))
    receipt['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    assert code==0 and row['sourceUnchanged'],name
    if 'totals' in row:
        assert row['targets']>0 and row['totals']['failed']==0 and row['totals']['ignored']==0
    if name=='host-depth':
        for test in ('prepared_input_fingerprint_comes_from_actual_pixels_and_dimensions',
                     'prepared_output_cannot_escape_live_key_or_cancellation_guards',
                     'installed_input_identity_survives_reopen_and_detects_changed_pixels_at_same_asset_key',
                     'video_prepared_fingerprint_is_computed_after_bt709_to_srgb_conversion'):
            assert 'test '+test+' ... ok' in output
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=True)
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True)),flush=True)
