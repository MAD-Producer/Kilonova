"""Archive the exact authoring gate without claiming the native frame bridge."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

root=Path('E:/Dev/aem'); work=root/'.worktrees/depth-authoring'
gate=root/'artifacts/pr-queue/depth-calibration-authoring-v2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
r=json.loads((gate/'accepted.json').read_text(encoding='utf-8'))
assert git('rev-parse','HEAD')==r['base']
assert all(sha(work/p)==h for p,h in r['source'].items())
assert all(s['exitCode']==0 and s['sourceUnchanged'] for s in r['steps'])
counts={s['name']:s['totals'] for s in r['steps'] if 'totals' in s}
assert sum(v['passed'] for v in counts.values())==317
assert all(v['failed']==0 and v['ignored']==0 for v in counts.values())
out=root/'artifacts/pr-queue/depth-calibration-authoring-complete-v1';out.mkdir(exist_ok=False)
archive=work/'engineering/validation/data/depth-calibration-authoring-v2.zip'
payload={}
for name in ('depth-prepared-input-v1','depth-prepared-input-v2',
             'depth-calibration-authoring-v1','depth-calibration-authoring-v2'):
    directory=root/'artifacts/pr-queue'/name
    if not directory.exists():continue
    for p in directory.rglob('*'):
        if p.is_file():payload[name+'/'+p.relative_to(directory).as_posix()]=p.read_bytes()
payload['completion-controller.py']=Path(__file__).read_bytes()
manifest={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in payload.items()}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for k,v in payload.items():z.writestr(k,v)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(manifest)+1
    for k,v in manifest.items():
        data=z.read(k);assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
doc=work/'engineering/validation/depth-calibration-authoring-current.md'
text='''# Persisted depth authoring and current-result admission

## Implemented boundary

The worker fingerprints its actual RGB8 sRGB opaque inference input after source
decode, crop, orientation and video transfer conversion, before entering the
backend. SHA-256 covers a versioned domain, little-endian dimensions and prepared
pixels, with cancellation checks in bounded chunks. Preparation timing includes
hashing. The worker alone creates the immutable Estimate/input pair: a backend
cannot supply the authoritative input digest. Public direct Estimate/Backend
contracts remain intact. Reading an installed session fingerprint does not
perform file IO, hashing or inference.

SavedDepthCalibration stores validated bounded authoring data, not inferred
pixels or a live edit revision: exact source asset and rational PTS, actual input
digest and extent, output interpretation/geometry/model processing, two anchors,
curve/extrapolation and explicit positive scene pixels-per-metre. The model's
processing revision is retained. Rebinding requires matching current prepared
input and interpretation, then creates a new immutable runtime calibration using
the actual admitted resource revision. The original RelativeDepthCalibration
revision checks remain unchanged.

An optional per-layer calibration is meaningful absence, not a migration.
`depth_calibration` requires an explicit nullable calibration field, supports
clearing, locks, scoped transactions, ordinary undo/redo, save/reopen and clipboard
asset remapping. Image/video references and geometry are validated against the
project. Host authoring requires the actual installed current result, validates
the transaction's final candidate before commit and preserves rollback/history
and the original error. A command committing a calibration changes the edit
revision, invalidating the previous installed result: only an explicit fresh
request can establish a subsequent runtime binding. Loading, undo and copying
saved authoring data do not implicitly run inference.

## Verified scope

The source-bound local gate passes **317 tests, 0 failed, 0 ignored**: model 96
across 25 targets, selected core 68 across 13 targets, and host 153 across nine
targets including actual native GPU library tests. Host compilation with depth
disabled and desktop FFmpeg/AI-depth compilation also pass, as do provenance and
panel-style checks. These are affected suites, not full-workspace, cross-platform
or final issue acceptance. Existing assertions, thresholds, budgets, timeouts and
ignored-test annotations are unchanged. Twelve new tests are included in these
totals; repeated attempts and checkpoint counts must not be summed.

Tests independently verify fixed hash vectors, changed pixel/dimension identity,
BT.709-to-sRGB conversion before hashing, geometry and bounded digest validation,
live revision refusal, saved interpretation/PTS/model refusal, mandatory nullable
command schema, locked/invalid atomic rollback, clipboard ownership mapping,
actual managed PNG preparation, committing/undoing/redoing a calibration,
save/reopen into another live revision, pending/canceled/stale results and
explicit recovery. Changing only an image's green channel while the controlled
backend reads red leaves predicted values unchanged but still refuses the saved
calibration, proving predicted values or path metadata are insufficient identity.
External file changes are detected on fresh source preparation; this does not
introduce per-frame file polling or claim synchronous detection of disk mutation.

The gate uses source base `8b1610282864e4738c7fe245f1ab9e9644c5f0f4`,
whose tree was merged as main `724ea8c0151b92b95c125ddd60a4b8c655230ecc`.
Each step verifies the exact source hashes. The later completion commit adds
only the document/archive beyond those tested implementation bytes.

The first run passed all 317 tests, then its depth-disabled compile encountered
stale trait metadata from the previously built camera-editing worktree. The
cached trait required a method absent from the unchanged current source; Cargo
dep paths in the shared target were relative. Current workspace input mtimes
were refreshed without changing file bytes, product behavior or assertions, and
the entire gate was rerun. Both raw attempts and the diagnosis are preserved.
Earlier prepared-input gates did not execute tests: the first stopped because
its prerequisite camera gate failed, and the second was stopped to expand this
same batch into persisted authoring. Those receipts are not passed coverage.

## Remaining route

This stage does not feed depth to ordinary host preview/capture or shared model
passes. SceneDepthInput remains a standalone admitted renderer input; native
frame routing, a source-camera/plane reprojection contract, multiple calibrated
layers, common-unit validation across consumers, camera motion/aspect, immutable
GPU seeding with budget refusal/recovery and actual reprojection/DOF output remain
open. Camera ancestry editing is separately accepted in PR535 and is not part of
this source base. Frozen video export, complex effect/mask/matte/nested shared
depth, intersecting transparency and final desktop acceptance also remain open.
Neither #74 nor #87 closes. Android is retired and excluded.

No UI/panel/style changes, third-party assets or new dependency versions are
introduced. Host production hashing opts into the already locked sha2 0.10 under
the existing optional ai-depth feature; the default session still starts no
inference worker. No source-camera or model-scale assumptions are silently added.
'''
text+=f'''\n[Source-bound evidence](data/depth-calibration-authoring-v2.zip), SHA-256
`{sha(archive)}`, {archive.stat().st_size} bytes. Exact changed source,
commands, controllers, raw output, exit receipts and initial stopped/failed gates
are retained; every archive entry was read back and SHA-256 verified.\n'''
doc.write_text(text,encoding='utf-8',newline='\n')
message=out/'commit-message.txt'
message.write_text('feat(depth): 持久化校准并校验当前输入绑定\n\n- 绑定实际准备像素的摘要与深度结果\n- 保存有界标定参数并保留运行时版本检查\n- 接通命令历史和剪贴板资源映射\n- 验证实际会话重开及取消和失败恢复\n- 归档验收并明确渲染接线的剩余范围\n',encoding='utf-8')
subprocess.run(['git','diff','--check'],cwd=work,check=True)
subprocess.run(['git','add','--','crates/motion-model','crates/motion-core','crates/motion-host',str(doc.relative_to(work)),str(archive.relative_to(work))],cwd=work,check=True)
subprocess.run(['git','diff','--cached','--stat'],cwd=work,check=True)
subprocess.run(['git','commit','--file',str(message)],cwd=work,check=True)
subprocess.run(['git','show','--stat','--oneline','HEAD'],cwd=work,check=True)
assert not git('status','--porcelain') and all(sha(work/p)==h for p,h in r['source'].items())
result=dict(head=git('rev-parse','HEAD'),base=r['base'],completedUtc=datetime.now(timezone.utc).isoformat(),
    totals=counts,archiveSha256=sha(archive),published=False,renderBridgeComplete=False)
(out/'completed.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
