from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
root=Path('E:/Dev/aem');work=root/'.worktrees/shortcut-contract';out=root/'.tools/shortcut-contract';out.mkdir(exist_ok=True)
path=out/'receipt.json';assert not path.exists()
print('Waiting for the existing shared-target verification to finish',flush=True)
while True:
 prior=json.loads((root/'.tools/resume-integrations-33.json').read_text())
 if prior['status']=='completed':break
 if prior['status']=='failed':raise RuntimeError('Earlier shared-target verification failed; do not overlap builds')
 time.sleep(5)
env=os.environ.copy();env.pop('MOTION_UPDATE_SHORTCUT_DOCS',None)
source=work/'desktop/app/src/shortcuts.rs';original=source.read_bytes()
test=work/'desktop/app/src/shortcuts_documentation_tests.rs'
source_hash=hashlib.sha256(original).hexdigest();test_hash=hashlib.sha256(test.read_bytes()).hexdigest()
record=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),status='running',runs=[],original_source_sha256=source_hash,test_sha256=test_hash)
def save():path.write_text(json.dumps(record,indent=2),encoding='utf8')
base=['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1','shortcuts::','--','--nocapture','--test-threads=1']
# The prior build used a different worktree and a UI fix absent from this branch.
for folder in ['crates','desktop']:
 for library in (work/folder).glob('**/src/lib.rs'):library.touch()
(work/'desktop/app/src/main.rs').touch()
def run(name,expected_fail=False):
 record['active']=name;save();print('Started shortcut '+name,flush=True);began=time.monotonic()
 before=(hashlib.sha256(source.read_bytes()).hexdigest(),hashlib.sha256(test.read_bytes()).hexdigest())
 with (out/(name+'.log')).open('w',encoding='utf8') as sink:child=subprocess.run(base,cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT,timeout=3600)
 after=(hashlib.sha256(source.read_bytes()).hexdigest(),hashlib.sha256(test.read_bytes()).hexdigest());assert before==after
 text=(out/(name+'.log')).read_text(encoding='utf8');summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
 item=dict(name=name,command=base,exit_code=child.returncode,seconds=round(time.monotonic()-began,2),summary=summary,source_sha256=before[0],test_sha256=before[1],source_unchanged=before==after)
 record['runs'].append(item);save();print(json.dumps(item),flush=True)
 assert summary,'Compilation/collector failure is not an expected mutant rejection'
 old='shortcuts::documentation_tests::default_binding_reference_matches_live_resolver'
 new='shortcuts::documentation_tests::repeated_chords_keep_the_documented_command_and_unbound_chords_stay_unbound'
 assert re.search(r'test '+re.escape(old)+r' \.\.\. ok',text),'Existing full reference check must still pass'
 if expected_fail:
  assert child.returncode==101 and summary[-1][2]=='1'
  assert new+' ... ' in text and 'OS repeat changed the binding' in text
 else:assert child.returncode==0 and all(s[0]=='ok' and s[2]=='0' and s[3]=='0' for s in summary)
try:
 run('healthy-before')
 text=original.decode('utf8')
 assert text.count('.then_some(command)')==1
 mutation=text.replace('.then_some(command)','.then_some(if repeat && command == NextFrame { PreviousFrame } else { command })')
 source.write_bytes(mutation.encode('utf8'));(work/'desktop/app/src/main.rs').touch();run('repeat-wrong-command',True)
 source.write_bytes(original)
 marker='    let command = match (scope, key, m.control, m.shift, m.alt) {'
 assert text.count(marker)==1
 mutation=text.replace(marker,'    if repeat && scope == Nodes && key == Key::B && m == Modifiers::default() { return Some(Delete); }\n'+marker)
 source.write_bytes(mutation.encode('utf8'));(work/'desktop/app/src/main.rs').touch();run('repeat-only-unbound-command',True)
finally:
 source.write_bytes(original);(work/'desktop/app/src/main.rs').touch()
 record['production_source_restored']=hashlib.sha256(source.read_bytes()).hexdigest()==source_hash;save()
run('healthy-restored')
assert record['production_source_restored'] and hashlib.sha256(test.read_bytes()).hexdigest()==test_hash
assert subprocess.check_output(['git','diff','--','desktop/app/src/shortcuts.rs'],cwd=work,text=True)==''
record.update(status='completed',active=None);save();print('Shortcut mutation and recovery verification completed',flush=True)
