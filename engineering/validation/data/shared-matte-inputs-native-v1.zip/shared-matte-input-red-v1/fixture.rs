//! Shared consumers read an independent image without losing source depth.
use super::spatial_matte_materials::authored;
use super::*;
use motion_model::compositing::{MatteMode, TrackMatte};
fn scene_for(p: &Project) -> Scene {
    let near = DepthResource::new(field(1).descriptor().clone(), vec![1., 1.], None, None).unwrap();
    let mut s = sampled(p);
    s.attach_calibrated_depth(1, &near.descriptor().source, &near, input())
        .unwrap();
    s
}
fn ray(p: &[u8], x: usize) -> &[u8] {
    &p[(32 * 96 + x) * 4..][..4]
}
fn srgb(c: f32) -> u8 {
    let c = if c <= 0.0031308 {
        12.92 * c
    } else {
        1.055 * c.powf(1. / 2.4) - 0.055
    };
    (255. * c).round() as u8
}
fn receiver(mode: MatteMode) -> Layer {
    let mut l = Layer::solid(
        90,
        "Independent ordinary consumer",
        [96., 64.],
        [48., 32., 0.],
        [1.; 4],
    );
    l.track_matte = Some(TrackMatte {
        source: 91,
        mode,
        hide_source: false,
    });
    l
}
#[test]
#[cfg_attr(not(feature = "gpu-tests"), ignore = "requires an actual GPU")]
fn shared_matte_image_feeds_ordinary_and_calibrated_receivers_in_four_precisions() {
    use motion_effects::image_contract::ChannelPrecision::*;
    for precision in [Unorm8, Unorm16, Float16, Float32] {
        let root = tempfile::tempdir().unwrap();
        let mut p = authored(root.path());
        p.working_precision = precision;
        p.layers.push(receiver(MatteMode::Alpha));
        p.validate().unwrap();
        let mut renderer = pollster::block_on(Renderer::headless_with_working_precision(
            precision,
            motion_render::AllocationBudget::new(128 << 20).unwrap(),
        ))
        .unwrap();
        prepare(&mut renderer, &p, root.path());
        let target = renderer
            .sdr_capture_target(96, 64, motion_render::OutputTransform::SDR_CLIP)
            .unwrap();
        for mode in [
            MatteMode::Alpha,
            MatteMode::AlphaInverted,
            MatteMode::Luma,
            MatteMode::LumaInverted,
        ] {
            p.layers
                .iter_mut()
                .find(|l| l.id == 90)
                .unwrap()
                .track_matte
                .as_mut()
                .unwrap()
                .mode = mode;
            let pixels = renderer
                .capture_sdr(&scene_for(&p), &target)
                .unwrap()
                .0
                .pixels;
            let c = 0.5 * (0.2126 + 0.0722);
            let mut ordinary = if mode.luma() { c } else { 0.5 };
            if mode.inverted() {
                ordinary = 1. - ordinary;
            }
            let expected = [
                srgb(ordinary + c * (1. - ordinary)),
                srgb(ordinary),
                srgb(1. - c * (1. - ordinary)),
                255,
            ];
            assert!(
                ray(&pixels, 56)
                    .iter()
                    .zip(expected)
                    .all(|(a, b)| a.abs_diff(b) <= 1),
                "{precision:?} {mode:?} actual={:?} expected={expected:?}",
                ray(&pixels, 56)
            );
            assert_eq!(
                ray(&pixels, 40),
                if mode.inverted() {
                    [255; 4]
                } else {
                    [0, 0, 255, 255]
                }
            );
            // Reorder only physical layers; the ordinary 2D overlay remains on top.
            p.layers[..3].reverse();
            assert_eq!(
                renderer
                    .capture_sdr(&scene_for(&p), &target)
                    .unwrap()
                    .0
                    .pixels,
                pixels
            );
            p.layers[..3].reverse();
            retain_fixture(
                &format!("shared-matte-image-{precision:?}-{mode:?}.png"),
                &pixels,
            );
        }
    }
}
