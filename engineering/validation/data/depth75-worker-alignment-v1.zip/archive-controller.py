"""Publish only consumed, source-bound worker controls; keep original failures."""
from pathlib import Path
import hashlib, json, shutil, zipfile

root = Path('E:/Dev/aem')
base = root / 'artifacts/pr-queue'
work = root / '.worktrees/depth-transition75'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda b: hashlib.sha256(b).hexdigest()
native = base / 'depth75-worker-alignment-native-v2'
green = base / 'depth75-worker-file-v3'
red = base / 'depth75-worker-file-v2'
host = base / 'depth75-worker-alignment-host-v1'
n, g, r, h = [read(p / 'receipt.json') for p in (native, green, red, host)]
assert n['status'] == 'all48_controls_passed' and len(n['namedPasses']) == 48 and n['sourceUnchanged']
assert g['status'] == 'actual_worker_blocked_start_alignment_and_error_channels_passed' and g['sourceUnchanged']
assert r['status'] == 'failed_original_outputs_retained' and r['stages'][-1]['exitCode'] == 101
assert h['status'] == 'full_host_and48_named_controls_passed' and h['sourceUnchanged']
assert h['allIntegrationTargetsAccounted'] and h['totals']['failed'] == h['totals']['filtered'] == 0
for directory, session, code in ((native, 29009, 0), (green, 68985, 0)):
    consumed = read(directory / 'session-consumed.json')
    assert consumed['session'] == session and consumed['exitCode'] == code
consumed = read(host / 'session-consumed.json')
assert consumed['session'] == 43268 and consumed['exitCode'] == 0
assert read(red / 'session-consumed.json')['exitCode'] == 1

members = {}
for directory, prefix, names in (
    (native, 'native48', ('controller.py', 'receipt.json', 'session-consumed.json', 'stdout.log', 'stderr.log')),
    (host, 'full-host', ('controller.py', 'receipt.json', 'session-consumed.json', 'stdout.log', 'stderr.log')),
    (red, 'file-before-start-flush', ('controller.py', 'receipt.json', 'session-consumed.json', 'actual.stdout.log', 'actual.stderr.log', 'execution/logs/motion-studio.log')),
    (green, 'file-after-start-flush', ('controller.py', 'receipt.json', 'session-consumed.json', 'build.stdout.log', 'build.stderr.log', 'actual.stdout.log', 'actual.stderr.log', 'execution/logs/motion-studio.log')),
    (base / 'depth75-worker-file-v1', 'probe-setup-compile-failure', ('controller.py', 'receipt.json', 'session-consumed.json', 'build.stdout.log', 'build.stderr.log')),
):
    for name in names:
        members[prefix + '/' + name] = (directory / name).read_bytes()

code = ('crates/motion-host/src/depth.rs', 'crates/motion-host/src/depth/onnx.rs',
        'crates/motion-host/src/depth/transition.rs', 'crates/motion-host/src/depth/transition/admission.rs',
        'crates/motion-host/tests/depth_aligned_admission.rs', 'crates/motion-host/tests/depth_worker_alignment.rs',
        'desktop/app/src/logging/sink.rs')
for name in code:
    raw = (work / name).read_bytes()
    assert sha(raw) == n['source'][name] == g['source'][name] == h['source'][name]
    members['source/' + name] = raw
for directory, prefix in ((base / 'depth75-worker-file-source', 'original-compile-failed-fixture'),
                           (base / 'depth75-worker-file-source-v2', 'namespace-corrected-identical-blocking-fixture')):
    for name in ('Cargo.toml', 'Cargo.lock', 'src/main.rs'):
        members[prefix + '/' + name] = (directory / name).read_bytes()
members['archive-controller.py'] = Path(__file__).read_bytes()
manifest = dict(schema=1, base=n['base'], status='actual_worker48_full_host_and_default_blocked_file_channels_passed',
    namedControls=48, hostTotals=h['totals'], integrationTargets=len(h['observedIntegrationTargets']),
    sourceDelta={name: sha((work / name).read_bytes()) for name in code}, limits=[
        'The source delta is qualified by exact code bytes over522bd1ca; fresh complete workspace and cross-platform CI for this delta are separate',
        'Seven new actual worker controls do not establish scene quality; the analytical reference is not a shipped model',
        'The real blocked backend start failed before the production flush, then the same behavioral fixture passed',
        'The earlier new probe namespace compile failure is retained; no behavioral assertion ran in that attempt',
        'Explicit aligned submission uses prepared Input; Session managed image/video installation, quality choice, cache and export policy remain pending',
        'One running, one replaceable pending and one ready slot; references share immutable planes; no application-wide retention quota is inferred',
        'Original model/provider/fingerprint and fit limits are retained; ordinary raw APIs cannot silently strip the alignment proof',
        'Full host preserves default GPU, original ignores and all assertions; it is not an include-ignored execution',
        'No UI/panels, Android, dependencies, assets, product retry/restart/timeout or project format change',
    ], members={name: dict(bytes=len(raw), sha256=sha(raw)) for name, raw in members.items()})
out = base / 'depth75-worker-alignment-public-v1'
out.mkdir(exist_ok=False)
archive = out / 'depth75-worker-alignment-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
    for name, raw in members.items(): z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == {'manifest.json', *members}
    for name, raw in members.items(): assert z.read(name) == raw
manifest['archive'] = dict(file=archive.name, bytes=archive.stat().st_size,
                           sha256=sha(archive.read_bytes()), verifiedMembers=len(members) + 1)
sidecar = out / 'depth75-worker-alignment-v1.json'
sidecar.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
for source in (archive, sidecar): shutil.copyfile(source, work / 'engineering/validation/data' / source.name)
print(json.dumps(manifest['archive']))
