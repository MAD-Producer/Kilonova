

use motion_host::depth::{
    alignment::{Limits, Rejection},
    transition::{
        admission::{Admission, Error as AdmissionError},
        Activity, Choices, Controller, Error as TransitionError, Policy, Ticket,
    },
    Backend, Cancellation, Costs, Error, Estimate, Input, Jobs, Key, PreparedEstimate,
};
use motion_model::depth::{
    DepthDescriptor, DepthGeometry, DepthMeasure, DepthModel, DepthResource, DepthSource,
    DepthTime, NearDirection,
};
use std::{
    sync::{mpsc, Arc, Mutex},
    thread::{self, ThreadId},
    time::{Duration, Instant},
};

fn choices(asset: u64) -> Choices {
    let reference = Key {
        source: DepthSource {
            asset,
            revision: 1,
            pts: DepthTime {
                ticks: 0,
                timescale: 24,
            },
        },
        geometry: DepthGeometry {
            source_size: [20, 1],
            crop: [0, 0, 20, 1],
            quarter_turns: 0,
            mirror_x: false,
        },
        model: DepthModel {
            id: "worker-alignment-control".into(),
            revision: "r1".into(),
            sha256: [1; 32],
            processing: "reference".into(),
        },
    };
    let mut candidate = reference.clone();
    candidate.model.processing = "candidate".into();
    Choices {
        interactive: reference,
        settled: candidate,
    }
}
fn controller() -> Controller {
    Controller::new(Policy {
        idle_delay: Duration::from_millis(100),
        minimum_interactive_residence: Duration::from_millis(300),
    })
    .unwrap()
}
fn limits() -> Limits {
    Limits {
        minimum_fit_pairs: 3,
        minimum_validation_pairs: 3,
        minimum_pair_fraction: 1.,
        minimum_confidence: None,
        minimum_reference_stddev: 1e-8,
        scale_bounds: [0.1, 10.],
        maximum_normalized_rms: 1e-8,
        maximum_normalized_error: 1e-8,
    }
}
fn input(key: &Key, pixel: u8) -> Input {
    Input::new(key.clone(), [20, 1], Arc::from(vec![pixel; 60])).unwrap()
}
struct Analytic {
    calls: mpsc::Sender<ThreadId>,
    fail_candidate: bool,
}
impl Backend for Analytic {
    fn infer(&mut self, input: &Input, _: &Cancellation) -> motion_host::depth::Result<Estimate> {
        self.calls.send(thread::current().id()).unwrap();
        if self.fail_candidate && input.key().model.processing == "candidate" {
            return Err(Error::Backend(
                "original worker alignment inference failure".into(),
            ));
        }
        let key = input.key();
        Ok(Estimate {
            resource: DepthResource::new(
                DepthDescriptor {
                    size: [20, 1],
                    source: key.source.clone(),
                    geometry: key.geometry.clone(),
                    model: key.model.clone(),
                    measure: DepthMeasure::Relative {
                        near: NearDirection::Increasing,
                    },
                    scale: 1.,
                    offset: 0.,
                    valid_range: None,
                },
                (0..20)
                    .map(|i| {
                        let x = i as f32 * 0.25;
                        if key.model.processing == "reference" {
                            2. * x + 3.
                        } else {
                            x
                        }
                    })
                    .collect(),
                None,
                None,
            )?,
            provider: "actual-worker-alignment-provider".into(),
            costs: Costs {
                inference: Duration::from_millis(7),
                ..Costs::default()
            },
        })
    }
}
fn worker(fail_candidate: bool) -> (Jobs, mpsc::Receiver<ThreadId>) {
    let (calls, received) = mpsc::channel();
    (
        Jobs::start(Analytic {
            calls,
            fail_candidate,
        })
        .unwrap(),
        received,
    )
}
fn completed(jobs: &Jobs, count: u64) {
    let until = Instant::now() + Duration::from_secs(5);
    loop {
        let counts = jobs.counts().unwrap();
        if counts.completed + counts.canceled + counts.failed >= count {
            return;
        }
        assert!(
            Instant::now() < until,
            "worker alignment fixture did not complete"
        );
        thread::sleep(Duration::from_millis(1));
    }
}
fn reference(c: &mut Controller, jobs: &mut Jobs, asset: u64) -> (Ticket, PreparedEstimate) {
    let first = c
        .observe(choices(asset), Activity::Idle, Duration::ZERO)
        .unwrap()
        .unwrap();
    c.request(&first, jobs, input(first.key(), 1))
        .unwrap()
        .unwrap();
    completed(jobs, 1);
    let reference = c.take_ready(&first, jobs, first.key()).unwrap().unwrap();
    let next = c
        .observe(choices(asset), Activity::Idle, Duration::from_millis(300))
        .unwrap()
        .unwrap();
    (next, reference)
}
fn aligned(c: &Controller, ticket: &Ticket, jobs: &mut Jobs) -> Admission {
    completed(jobs, 2);
    c.take_aligned_ready(ticket, jobs, ticket.key())
        .unwrap()
        .unwrap()
}


#[path="E:/Dev/aem/.worktrees/depth-transition75/desktop/app/src/logging/sink.rs"]
mod logging;
mod engine { pub fn current_command() -> Option<(u64,&'static str,std::time::Duration)> { None } }
struct Controlled {
    backend: Analytic,
    gate: Option<(mpsc::Sender<()>,mpsc::Receiver<()>)>,
}
impl Backend for Controlled {
    fn infer(&mut self,input:&Input,cancel:&Cancellation)->motion_host::depth::Result<Estimate> {
        if input.key().model.processing=="candidate" {
            if let Some((entered,release))=self.gate.take() {
                entered.send(()).unwrap();release.recv_timeout(Duration::from_secs(5)).unwrap();
            }
        }
        self.backend.infer(input,cancel)
    }
}
struct Release(mpsc::Sender<()>);
impl Drop for Release { fn drop(&mut self){let _=self.0.send(());} }
fn main()->Result<(),Box<dyn std::error::Error>> {
    assert!(std::env::var_os("MOTION_LOG").is_none());
    let out=std::path::PathBuf::from(std::env::args_os().nth(1).ok_or("output missing")?);
    assert!(out.is_absolute());std::fs::create_dir(&out)?;
    let _logging=logging::init(out.join("logs"))?;
    let (calls,_received)=mpsc::channel();
    let (entered,seen)=mpsc::channel();let (release,wait)=mpsc::channel();
    let mut jobs=Jobs::start(Controlled {backend:Analytic {calls,fail_candidate:false},gate:Some((entered,wait))})?;
    let release=Release(release);
    let mut c=controller();let (ticket,reference)=reference(&mut c,&mut jobs,579);
    log::logger().flush();
    let request=c.request_aligned(&ticket,&mut jobs,input(ticket.key(),1),&reference,limits())?.ok_or("request rejected")?;
    seen.recv_timeout(Duration::from_secs(5))?;
    let flight=jobs.in_flight()?.ok_or("missing blocked flight")?;
    assert_eq!(flight.request,request);assert_eq!(flight.phase,"backend");assert_eq!(flight.asset,579);
    // No manual flush, release or completed-result polling before this read.
    let log=std::fs::read_to_string(out.join("logs/motion-studio.log"))?;
    assert!(log.lines().any(|line|line.contains(" INFO ") && line.contains("start #2 depth_infer asset=579")),"default start was buffered while the actual worker was blocked");
    drop(release);let admitted=aligned(&c,&ticket,&mut jobs);
    let view=admitted.view(&c,ticket.key())?.ok_or("aligned view rejected")?;
    assert_eq!(view.sample(19)?,Some(12.5));assert!(!view.costs().alignment.is_zero());
    c.request_aligned(&ticket,&mut jobs,input(ticket.key(),2),&reference,limits())?.ok_or("fault request rejected")?;
    completed(&jobs,3);
    assert!(matches!(c.take_aligned_ready(&ticket,&mut jobs,ticket.key()),Err(TransitionError::Job(Error::Alignment(AdmissionError::Pixels)))));
    assert_eq!(jobs.counts()?.failed,1);assert_eq!(jobs.counts()?.completed,2);
    let log=std::fs::read_to_string(out.join("logs/motion-studio.log"))?;
    assert!(log.lines().any(|line|line.contains(" INFO ") && line.contains("start #2 depth_align asset=579 revision=1 phase=alignment generation=2")));
    assert!(log.lines().any(|line|line.contains(" ERROR ") && line.contains("request=3 operation=depth_infer asset=579 revision=1") && line.contains("stage=alignment") && line.contains("prepared input pixels differ")));
    println!("{}",serde_json::json!({"status":"actual_worker_blocked_start_alignment_and_error_channels_verified"}));Ok(())
}
