from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/render-dag'
out = root / 'artifacts/pr-queue/issue78-numeric-logical-grouping-v1'
receipt = json.loads((out / 'accepted.json').read_text(encoding='utf-8'))
assert receipt['sourceUnchanged']
assert [s['name'] for s in receipt['steps']] == ['desktop-check', 'render-library', 'render-affected']
assert all(s['exitCode'] == 0 and s['sourceUnchanged'] for s in receipt['steps'])
assert receipt['steps'][1]['totals']['passed'] == 230
assert receipt['steps'][2]['totals']['passed'] == 14
assert all(s.get('totals', {}).get('ignored', 0) == 0 for s in receipt['steps'])
for name, sha in receipt['source'].items():
    assert hashlib.sha256((work / name).read_bytes()).hexdigest() == sha, name
changed = [
    'crates/motion-render/src/effect_plan/scratch.rs',
    'crates/motion-render/src/effect_plan/scratch_graph.rs',
    'crates/motion-render/src/effect_plan/pointwise.rs',
    'crates/motion-render/src/effect_plan/pointwise/cache_tests.rs',
]
command = ['rustfmt', '--edition', '2024', '--check', *changed]
format_result = subprocess.run(command, cwd=work, capture_output=True, text=True)
assert format_result.returncode == 0, format_result.stderr
(out / 'format.json').write_text(json.dumps(dict(command=command, exitCode=0), indent=2), encoding='utf-8')
assert not subprocess.check_output(['git', 'diff', '--name-only', '--', 'desktop/app/src/panels'], cwd=work).strip()
files = {f'acceptance/{p.relative_to(out).as_posix()}': p.read_bytes() for p in out.rglob('*') if p.is_file()}
controller = root / '.tools/issue-closure-review/validate-issue78-logical-grouping.py'
files['controller/validate-issue78-logical-grouping.py'] = controller.read_bytes()
files['controller/archive-issue78-logical-grouping.py'] = Path(__file__).read_bytes()
manifest = dict(
    createdUtc=datetime.now(timezone.utc).isoformat(),
    base=receipt['head'],
    scope='Local logical def/use admission for real opt-in grouping; not complete effect-level IR',
    source=receipt['source'],
    files={name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())},
)
archive = work / 'engineering/validation/data/typed-render-dag-logical-grouping-be0c4b38.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(files.items()):
        z.writestr(name, data)
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(files) | {'manifest.json'}
    for name, sha in manifest['files'].items():
        assert hashlib.sha256(z.read(name)).hexdigest() == sha, name
summary = dict(archive=str(archive), bytes=archive.stat().st_size, files=len(files),
               sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
               sourcesVerified=len(receipt['source']),
               testTotals={s['name']: s.get('totals') for s in receipt['steps']})
(out / 'archive-verification.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary))
