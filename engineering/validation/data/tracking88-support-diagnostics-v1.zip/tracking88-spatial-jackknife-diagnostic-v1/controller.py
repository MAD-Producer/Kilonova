"""Blind spatial-block deletion diagnostic; no tracker/output/gate modification."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys, zipfile
import cv2
import numpy as np

ROOT=Path('E:/Dev/aem')
OUT=ROOT/'artifacts/pr-queue/tracking88-spatial-jackknife-diagnostic-v1'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
base=OUT/'baseline';base.mkdir()
for name in ('plate_contract.py','plate_flow.py'):
    (base/name).write_bytes(subprocess.check_output(['git','show','72423ec2:tools/tracking/'+name],cwd=ROOT))
sys.path.insert(0,str(base))
import plate_flow as flow
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=ROOT/'artifacts/pr-queue/tracking88-real-planar-acquisition-v1/phone.avi'
assert sha(source)=='c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
request_path=ROOT/'artifacts/pr-queue/tracking88-stratified-seed-candidate-v1/real-baseline/periodic-manual-200.request.json'
request=json.loads(request_path.read_text())
seed=next(s for s in request['tracks'] if s['kind']=='plane')
corrections={e['source_index']:e for e in request['corrections'] if e['track']==seed['id']}
ffmpeg=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
command=[str(ffmpeg),'-v','error','-nostdin','-hwaccel','none','-threads','1','-noautorotate','-copyts','-i',str(source),'-map','0:0','-an','-sn','-dn','-fps_mode','passthrough','-threads','1','-f','rawvideo','-pix_fmt','gray','pipe:1']
cv2.setNumThreads(1)
cv2.setRNGSeed(88)
rows=[]
report=dict(status='running_blind_geometry',startedUtc=datetime.now(timezone.utc).isoformat(),
            sourceSha256=sha(source),requestSha256=sha(request_path),sourceCommit='72423ec2',
            limits=['Full original sequence/request/corrections; original tracker and gates unchanged',
                    'Spatial deletion fits use fitting points only; holdout points do not initialize them',
                    'Original three-pixel consensus is descriptive, not a new acceptance threshold',
                    'No tracker output is changed or accepted; diagnostic can fail to explain the retained quality error'])
def save():
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
try:
    with (OUT/'decode.stderr.log').open('wb') as stderr:
        process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=stderr)
        report['decodePid']=process.pid;save()
        previous=tracker=None
        index=0
        while True:
            data=process.stdout.read(640*480)
            if not data:break
            assert len(data)==640*480
            current=flow.prepare(np.frombuffer(data,np.uint8).reshape(480,640))
            if index==0:
                tracker=flow.Tracker(seed,current)
                observation=tracker.initial
            elif index in corrections:
                observation,_=tracker.correct(current,corrections[index])
            else:
                observation,_=tracker.observe(previous,current)
            previous=current
            row=dict(index=index,manual=index in corrections,visible=observation is not None,reason=tracker.reason)
            if index and not row['manual'] and observation is not None:
                matrix=np.asarray(observation['matrix'])
                fit=~tracker.holdout
                reference,measured=tracker.reference[fit],tracker.points[fit]
                errors=np.linalg.norm(flow.transform(matrix,reference)-measured,axis=1)
                inliers=errors<=flow.LIMITS['planeFitPixels']
                reference,measured=reference[inliers],measured[inliers]
                x,y,w,h=seed['roi']
                blocks=(reference[:,0]>=x+w/2).astype(int)+2*(reference[:,1]>=y+h/2).astype(int)
                probes=[[x,y],[x+w,y],[x+w,y+h],[x,y+h]]
                tests=[]
                for block in range(4):
                    keep=blocks!=block
                    entry=dict(deletedBlock=block,retained=int(keep.sum()),removed=int((~keep).sum()))
                    if keep.sum()>=flow.LIMITS['minimumFitInliers'] and entry['removed']:
                        alternate,_=cv2.findHomography(reference[keep],measured[keep],0)
                        if alternate is not None:
                            try:
                                flow.plane_matrix(alternate,seed['roi'])
                                entry['maxRoiDisagreement']=float(np.linalg.norm(flow.transform(alternate,probes)-flow.transform(matrix,probes),axis=1).max())
                            except ValueError as error:entry['invalid']=str(error)
                    tests.append(entry)
                row.update(matrix=matrix.tolist(),spatialDeletion=tests)
            rows.append(row);index+=1
        process.stdout.close()
        report['decodeExit']=process.wait()
    assert report['decodeExit']==0 and len(rows)==2300
    # Seal all image-derived measurements before opening benchmark labels.
    blind=OUT/'blind-geometry.json';blind.write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    report['blindGeometrySha256']=sha(blind)
    labels=ROOT/'artifacts/pr-queue/tracking88-real-planar-acquisition-v1/phone-gt.zip'
    assert sha(labels)=='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
    with zipfile.ZipFile(labels) as archive:
        def corners(i):
            a=np.asarray([float(v) for v in archive.read(f'img_{i+200:05d}.txt').decode().split()]).reshape(2,4)
            return np.column_stack((a[1]-1,a[0]-1))
        original=corners(0)
        for row in rows:
            if 'matrix' in row:
                row['originalCornerError']=float(np.linalg.norm(flow.transform(np.asarray(row['matrix']),original)-corners(row['index']),axis=1).max())
    visible=[r for r in rows if 'matrix' in r]
    failures=[r for r in visible if r['originalCornerError']>15.]
    for r in visible:
        values=[v['maxRoiDisagreement'] for v in r['spatialDeletion'] if 'maxRoiDisagreement' in v]
        r['allFourMeasured']=len(values)==4
        r['maxSpatialDisagreement']=max(values) if values else None
    report.update(status='diagnostic_complete_not_adopted',frames=len(rows),automaticVisible=len(visible),
                  originalOver15Frames=len(failures),
                  over15WithAllFourMeasured=sum(r['allFourMeasured'] for r in failures),
                  over15AboveExistingConsensus=sum(r['maxSpatialDisagreement'] is not None and r['maxSpatialDisagreement']>flow.LIMITS['planeConsensusMaxPixels'] for r in failures))
    (OUT/'label-comparison.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
except BaseException as error:
    report.update(status='failed_original_outputs_retained',error=repr(error));raise
finally:
    report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps(report))
