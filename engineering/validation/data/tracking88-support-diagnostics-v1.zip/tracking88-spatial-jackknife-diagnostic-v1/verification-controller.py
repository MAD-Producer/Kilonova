"""Check diagnostic replay identity without adopting a tracker or changing gates."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json

ROOT = Path('E:/Dev/aem')
OUT = ROOT / 'artifacts/pr-queue/tracking88-spatial-jackknife-diagnostic-v1'
BASE = ROOT / 'artifacts/pr-queue/tracking88-stratified-seed-candidate-v1/real-baseline/periodic-manual-200/tracks.mstrack'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text(encoding='utf-8'))
receipt = load(OUT / 'receipt.json')
assert receipt['status'] == 'diagnostic_complete_not_adopted'
assert receipt['decodeExit'] == 0
assert sha(OUT / 'blind-geometry.json') == receipt['blindGeometrySha256']
blind = load(OUT / 'blind-geometry.json')
labelled = load(OUT / 'label-comparison.json')
original = next(t for t in load(BASE)['tracks'] if t['kind'] == 'plane')['samples']
assert len(original) == len(blind) == len(labelled) == 2300
matrix_count = 0
for sample, geometry, comparison in zip(original, blind, labelled):
    assert sample['source_index'] == geometry['index'] == comparison['index']
    assert sample['manual_correction'] == geometry['manual']
    assert (sample['visibility'] == 'visible') == geometry['visible']
    assert all(comparison[key] == value for key, value in geometry.items())
    assert 'originalCornerError' not in geometry
    if 'matrix' in geometry:
        assert sample['observation']['matrix'] == geometry['matrix']
        matrix_count += 1
assert matrix_count == 915
failed = [r for r in labelled if r.get('originalCornerError', 0) > 15]
assert len(failed) == receipt['originalOver15Frames'] == 21
assert all(r['allFourMeasured'] for r in failed)
assert all(r['maxSpatialDisagreement'] < 3 for r in failed)
report = dict(
    status='baseline_identity_verified_diagnostic_not_adopted',
    observedUtc=datetime.now(timezone.utc).isoformat(),
    originalSamples=2300,
    exactAutomaticMatrices=matrix_count,
    exactVisibilityAndManualFlags=True,
    blindMeasurementsPreservedBeforeLabelComparison=True,
    over15Frames=len(failed),
    maxSpatialDisagreementOnFailedFrames=max(r['maxSpatialDisagreement'] for r in failed),
    minOriginalErrorOnFailedFrames=min(r['originalCornerError'] for r in failed),
    maxOriginalErrorOnFailedFrames=max(r['originalCornerError'] for r in failed),
    sourceSha256=receipt['sourceSha256'],
    files={str(p.relative_to(ROOT)): sha(p) for p in (
        BASE, OUT / 'controller.py', OUT / 'receipt.json', OUT / 'blind-geometry.json',
        OUT / 'label-comparison.json', OUT / 'baseline/plate_contract.py', OUT / 'baseline/plate_flow.py')},
    limits=[
        'No tracker implementation, outputs, source request or acceptance gate changed',
        'Spatial deletion does not detect these retained quality failures at the existing consensus threshold',
        'This negative diagnostic neither proves correspondence correctness nor invalidates original annotations',
        'Original full-sequence quality remains failed; no failed frame or outside-image corner is excluded',
    ],
)
(OUT / 'verification-controller.py').write_bytes(Path(__file__).read_bytes())
(OUT / 'verification.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
(OUT / 'README.md').write_text(
    '# Spatial block deletion diagnostic — not adopted\n\n'
    'The original 2,300-frame sequence, request, eleven corrections, tracker and gates remain unchanged. '
    'All visibility/manual flags and 915 automatically visible matrices exactly match the retained baseline. '
    'Image-derived measurements were saved and hashed before benchmark labels were opened.\n\n'
    'Removing each of four spatial fitting-point quadrants leaves less than the existing three-pixel '
    'consensus disagreement on all 21 frames that fail the original fifteen-pixel quality gate. '
    'This diagnostic therefore does not identify those failures and is not adopted as a new admission rule. '
    'The original quality gate still fails; no annotation, correction, ROI or frame is excluded.\n\n'
    'verification.json retains replay-identity checks and hashes; label-comparison.json contains the '
    'full measured sequence. This does not establish a cause or a repaired tracker.\n', encoding='utf-8')
print(json.dumps({k: v for k, v in report.items() if k != 'files'}))
