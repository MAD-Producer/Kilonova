"""Retain negative/controlled evidence; exclude external benchmark payloads."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile

ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/planar-tracker88'
DEST=WORK/'engineering/validation/data/tracking88-support-diagnostics-v1'
assert not DEST.with_suffix('.zip').exists()
names=['tracking88-increment-prior-v1','tracking88-controlled-extrapolation-v1',
       'tracking88-spatial-jackknife-diagnostic-v1','tracking88-support-uncertainty-probe-v1',
       'tracking88-retained-error-visuals-v1']
files={}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in names:
    base=ROOT/'artifacts/pr-queue'/name
    assert base.is_dir()
    for path in base.rglob('*'):
        if path.is_file() and path.suffix in ('.json','.py','.log') and '__pycache__' not in path.parts:
            files[name+'/'+path.relative_to(base).as_posix()]=path
files['archive-controller.py']=Path(__file__)
entries={name:dict(bytes=p.stat().st_size,sha256=sha(p)) for name,p in sorted(files.items())}
with zipfile.ZipFile(DEST.with_suffix('.zip'),'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in sorted(files.items()):archive.writestr(name,path.read_bytes())
with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
    assert set(archive.namelist())==set(entries)
    for name,row in entries.items():
        payload=archive.read(name)
        assert len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
report=dict(status='negative_and_controlled_evidence_archived_not_adopted',
            createdUtc=datetime.now(timezone.utc).isoformat(),
            baseline='72423ec2aaf877147d20daa6827a2929bf3649b3',
            sourceVideoSha256='c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9',
            annotationsSha256='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886',
            bytes=DEST.with_suffix('.zip').stat().st_size,sha256=sha(DEST.with_suffix('.zip')),
            entries=entries,limits=[
                'Original all2300 frames/ROI/corrections/15pixel quality gate remain unchanged',
                'Original video, annotated source/permission data and derived images remain external; no photographed payload included',
                'The ridge candidate retains21 failures; neither support tests nor known flat-image motion establishes a repair',
                'Known source-frame0/1800 planar image warps have analytic transforms, not photographed-motion ground truth',
                'No experimental algorithm is adopted in the production/prototype branch',
                'Original source and label identities plus controllers are retained; this archive is not a portable benchmark-input package'])
DEST.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='entries'}))
