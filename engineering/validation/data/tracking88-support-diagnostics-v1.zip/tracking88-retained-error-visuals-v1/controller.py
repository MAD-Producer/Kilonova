"""Visualize retained measurements; no new tracker run or acceptance changes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import zipfile
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path('E:/Dev/aem')
SOURCE = ROOT / 'artifacts/pr-queue/tracking88-real-planar-acquisition-v1'
MEASURED = ROOT / 'artifacts/pr-queue/tracking88-stratified-seed-candidate-v1'
OUT = ROOT / 'artifacts/pr-queue/tracking88-retained-error-visuals-v1'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(SOURCE / 'phone.avi') == 'c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
assert digest(SOURCE / 'phone-gt.zip') == 'd4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
tracks_path = MEASURED / 'real-baseline/periodic-manual-200/tracks.mstrack'
asset = json.loads(tracks_path.read_text(encoding='utf-8'))
track = next(t for t in asset['tracks'] if t['kind'] == 'plane')
indices = [1800, 1801, 1802, 1810, 1820, 1845]
command = [str(ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'),
           '-nostdin', '-v', 'warning', '-hwaccel', 'none', '-threads', '1',
           '-i', str(SOURCE / 'phone.avi'), '-map', '0:v:0', '-an', '-sn',
           '-vf', 'select=' + '+'.join(f'eq(n\\,{i})' for i in indices),
           '-fps_mode', 'passthrough', '-frames:v', str(len(indices)),
           '-filter_threads', '1', '-threads', '1', str(OUT / 'source-%02d.png')]
report = dict(startedUtc=datetime.now(timezone.utc).isoformat(), status='running',
              command=command, sourceSha256=digest(SOURCE / 'phone.avi'),
              annotationsSha256=digest(SOURCE / 'phone-gt.zip'),
              retainedTracksSha256=digest(tracks_path), rows=[],
              limits=['Retained failed baseline measurements, not a new tracking experiment or quality pass',
                      'CPU-only source decode and static overlays; no GPU/model/tracker execution',
                      'Original ROI, complete-sequence gate, correction schedule and annotations unchanged',
                      'Independent ground-truth green, retained prediction orange; manual frame is explicitly labeled'])
try:
    with (OUT / 'decode.stdout.log').open('wb') as stdout, (OUT / 'decode.stderr.log').open('wb') as stderr:
        result = subprocess.run(command, stdout=stdout, stderr=stderr)
    report['decodeExit'] = result.returncode
    assert result.returncode == 0
    assert len(list(OUT.glob('source-*.png'))) == len(indices)
    panels = []
    with zipfile.ZipFile(SOURCE / 'phone-gt.zip') as archive:
        def corners(i):
            values = np.array([float(v) for v in archive.read(f'img_{i+200:05d}.txt').decode('ascii').split()]).reshape(2, 4)
            return np.column_stack((values[1] - 1., values[0] - 1.))
        reference = np.column_stack((corners(0), np.ones(4)))
        for ordinal, index in enumerate(indices, 1):
            source_path = OUT / f'source-{ordinal:02d}.png'
            canvas = Image.open(source_path).convert('RGB')
            assert canvas.size == (640, 480)
            sample = track['samples'][index]
            assert sample['source_index'] == index and sample['visibility'] == 'visible'
            transformed = reference @ np.asarray(sample['observation']['matrix']).T
            predicted = transformed[:, :2] / transformed[:, 2:]
            actual = corners(index)
            error = np.linalg.norm(predicted - actual, axis=1)
            draw = ImageDraw.Draw(canvas)
            for points, color in ((actual, '#36f176'), (predicted, '#ff9c30')):
                points = [tuple(p) for p in points]
                draw.line(points + [points[0]], fill=color, width=2)
                for x, y in points:
                    draw.ellipse((x-3, y-3, x+3, y+3), outline=color, width=2)
            draw.rectangle((0, 0, 639, 27), fill='black')
            label = f"frame {index}, {'MANUAL' if sample['manual_correction'] else 'automatic'}, max error {error.max():.2f}px"
            draw.text((8, 7), label, fill='white')
            canvas.save(OUT / f'overlay-{index}.png')
            panels.append(canvas)
            report['rows'].append(dict(sourceIndex=index, manual=sample['manual_correction'],
                                       confidence=sample['confidence'], errorPixels=error.tolist(),
                                       sourcePngSha256=digest(source_path),
                                       overlayPngSha256=digest(OUT / f'overlay-{index}.png')))
    sheet = Image.new('RGB', (1280, 1440), 'black')
    for i, panel in enumerate(panels):
        sheet.paste(panel, ((i % 2) * 640, (i // 2) * 480))
    sheet.save(OUT / 'contact-sheet.png')
    report['status'] = 'retained_failure_visualized_no_acceptance_change'
except BaseException as error:
    report.update(status='failed_original_outputs_retained', failure=repr(error))
    raise
finally:
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report))
