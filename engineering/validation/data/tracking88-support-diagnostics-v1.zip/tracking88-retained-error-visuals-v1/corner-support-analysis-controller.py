"""Classify retained errors without removing any frame or changing a quality gate."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile
import numpy as np

ROOT = Path('E:/Dev/aem/artifacts/pr-queue')
EXPERIMENT = ROOT / 'tracking88-stratified-seed-candidate-v1'
ANNOTATIONS = ROOT / 'tracking88-real-planar-acquisition-v1/phone-gt.zip'
OUT = ROOT / 'tracking88-retained-error-visuals-v1/corner-support-analysis.json'
assert not OUT.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(ANNOTATIONS) == 'd4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
with zipfile.ZipFile(ANNOTATIONS) as archive:
    corners = []
    for i in range(2300):
        values = np.array([float(v) for v in archive.read(f'img_{i+200:05d}.txt').decode('ascii').split()]).reshape(2, 4)
        corners.append(np.column_stack((values[1] - 1., values[0] - 1.)))
corners = np.asarray(corners)
reference = np.column_stack((corners[0], np.ones(4)))
report = dict(observedUtc=datetime.now(timezone.utc).isoformat(),
              scope='Pure NumPy analysis of all original 2300 retained samples; no decoder, tracker, model or GPU execution',
              annotationsSha256=sha(ANNOTATIONS), runs=[],
              limits=['All four original corner errors and the original 15-pixel gate remain authoritative',
                      'Offscreen classification is diagnostic only, never a ground-truth exclusion or accepted quality result',
                      'Annotations outside the image cannot establish their own visual uncertainty from these frames',
                      'This does not establish incorrect annotations, a correspondence cause, or a repaired tracker'])
inside = lambda pts: ((pts[:, 0] >= 0.) & (pts[:, 0] < 640.) & (pts[:, 1] >= 0.) & (pts[:, 1] < 480.))
for variant in ('baseline', 'candidate'):
    for mode in ('no-corrections', 'periodic-manual-200'):
        path = EXPERIMENT / f'real-{variant}' / mode / 'tracks.mstrack'
        asset = json.loads(path.read_text(encoding='utf-8'))
        assert asset['source_extent'] == [640, 480]
        track = next(t for t in asset['tracks'] if t['kind'] == 'plane')
        assert len(track['samples']) == 2300
        rows, visible = [], 0
        for i, sample in enumerate(track['samples']):
            assert sample['source_index'] == i
            if i == 0 or sample['manual_correction'] or sample['visibility'] != 'visible':
                continue
            visible += 1
            transformed = reference @ np.asarray(sample['observation']['matrix']).T
            predicted = transformed[:, :2] / transformed[:, 2:]
            errors = np.linalg.norm(predicted - corners[i], axis=1)
            if float(errors.max()) > 15.:
                bad = errors > 15.
                truth_inside = inside(corners[i])
                predicted_inside = inside(predicted)
                rows.append(dict(index=i, maxPixels=float(errors.max()),
                                 errorPixels=errors.tolist(), failingCorners=np.flatnonzero(bad).tolist(),
                                 groundTruthInside=truth_inside.tolist(), predictedInside=predicted_inside.tolist(),
                                 everyFailingGroundTruthCornerOutside=bool(np.all(~truth_inside[bad]))))
        report['runs'].append(dict(variant=variant, mode=mode, tracksSha256=sha(path),
                                   automaticVisible=visible, originalOver15Frames=len(rows),
                                   allFailingGroundTruthCornersOutsideFrames=sum(r['everyFailingGroundTruthCornerOutside'] for r in rows),
                                   rows=rows))
OUT.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({**report, 'runs': [{k:v for k,v in r.items() if k!='rows'} for r in report['runs']]}))
