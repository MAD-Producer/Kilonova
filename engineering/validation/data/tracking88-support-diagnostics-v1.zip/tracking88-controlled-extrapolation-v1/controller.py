"""Known subpixel motion of retained real imagery; no annotation reads.

This diagnoses the frozen tracker on partial-image support. It neither changes
the 2300-frame benchmark nor establishes its annotations or tracker as correct.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import math
import time
import cv2
import numpy as np

ROOT=Path('E:/Dev/aem')
OUT=ROOT/'artifacts/pr-queue/tracking88-controlled-extrapolation-v1'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
BASE=OUT/'baseline'
BASE.mkdir()
for name in ('plate_contract.py','plate_flow.py'):
    (BASE/name).write_bytes(subprocess.check_output(['git','show','72423ec2:tools/tracking/'+name],cwd=ROOT))
sys.path.insert(0,str(BASE))
import plate_flow as flow
cv2.setNumThreads(1)
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
request_path=ROOT/'artifacts/pr-queue/tracking88-stratified-seed-candidate-v1/real-baseline/periodic-manual-200.request.json'
request=json.loads(request_path.read_text())
seed=next(s for s in request['tracks'] if s['kind']=='plane')
edit=next(e for e in request['corrections'] if e['track']=='plane' and e['source_index']==1800)
video=ROOT/'artifacts/pr-queue/tracking88-real-planar-acquisition-v1/phone.avi'
assert sha(video)=='c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
ffmpeg=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
command=[str(ffmpeg),'-v','error','-nostdin','-hwaccel','none','-threads','1','-noautorotate',
         '-i',str(video),'-map','0:0','-an','-sn','-dn','-vf',r'select=eq(n\,0)+eq(n\,1800)',
         '-fps_mode','passthrough','-threads','1','-f','rawvideo','-pix_fmt','gray','pipe:1']
decoded=subprocess.run(command,capture_output=True,check=False)
(OUT/'decode.stderr.log').write_bytes(decoded.stderr)
assert decoded.returncode==0 and len(decoded.stdout)==2*640*480
images=np.frombuffer(decoded.stdout,np.uint8).reshape(2,480,640)
report=dict(status='running_known_motion',startedUtc=datetime.now(timezone.utc).isoformat(),
            sourceSha256=sha(video),requestSha256=sha(request_path),
            controls=[],limits=[
                'Only original authorized corrections are read; no benchmark annotations are opened',
                'Every generated image is independently warped from the same original; no recursive resampling',
                'Known motion of a flat image does not prove photographed 3D rigidity or annotation accuracy',
                'Original real-sequence failures, all quality gates and production sources remain unchanged',
                'Original credited image payloads remain external; only numerical diagnostics are written'])
def save():
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
start=time.monotonic()
x,y,w,h=seed['roi']
probes=np.array([[x,y],[x+w,y],[x+w,y+h],[x,y+h]],np.float64)
outer=np.array([[0.,0.],[640.,0.],[640.,480.],[0.,480.]])
to_origin=np.array([[1.,0.,-320.],[0.,1.,-240.],[0.,0.,1.]])
try:
    for image_index,enrollment in [(0,np.eye(3)),(1,np.asarray(edit['observation']['matrix']))]:
        image=images[image_index]
        initial=flow.prepare(image)
        for mode in ('translation','rotation_scale','projective'):
            cv2.setRNGSeed(88)
            tracker=flow.Tracker(seed,initial)
            if image_index==1:
                tracker.correct(initial,edit)
            previous=initial
            rows=[]
            for tick in range(1,49):
                phase=2*math.pi*tick/12
                dx,dy=2*math.sin(phase),1.5*(math.cos(phase)-1)
                delta=np.array([[1.,0.,dx],[0.,1.,dy],[0.,0.,1.]])
                if mode!='translation':
                    angle=.01*math.sin(phase)
                    scale=1.+.01*(math.cos(phase)-1)
                    c,s=scale*math.cos(angle),scale*math.sin(angle)
                    middle=np.array([[c,-s,dx],[s,c,dy],[0.,0.,1.]])
                    if mode=='projective':
                        middle[2,:2]=[.00008*math.sin(phase),.00006*(math.cos(phase)-1)]
                    delta=np.linalg.inv(to_origin)@middle@to_origin
                # Repeated phase zero is an exact input return, without a
                # near-identity interpolation path that could perturb pixels.
                if tick%12==0:
                    delta=np.eye(3)
                    current=initial
                else:
                    raw=cv2.warpPerspective(image,delta,(640,480),flags=cv2.INTER_LINEAR,
                                            borderMode=cv2.BORDER_CONSTANT,borderValue=0)
                    current=flow.prepare(raw)
                observation,_=tracker.observe(previous,current)
                previous=current
                row=dict(tick=tick,visible=observation is not None,reason=tracker.reason)
                if observation is not None:
                    predicted=np.asarray(observation['matrix'])
                    known=delta@enrollment
                    row.update(roiCornerError=float(np.linalg.norm(flow.transform(predicted,probes)-flow.transform(known,probes),axis=1).max()),
                               outerSourceCornerError=float(np.linalg.norm(flow.transform(predicted,outer)-flow.transform(known,outer),axis=1).max()))
                rows.append(row)
            visible=[r for r in rows if r['visible']]
            report['controls'].append(dict(sourceFrame=0 if image_index==0 else 1800,mode=mode,
                frames=48,automaticVisible=len(visible),lost=48-len(visible),
                maxRoiCornerError=max((r['roiCornerError'] for r in visible),default=None),
                maxOuterSourceCornerError=max((r['outerSourceCornerError'] for r in visible),default=None),rows=rows))
            save()
    report['status']='controlled_diagnostic_complete_not_real_benchmark_acceptance'
except BaseException as cause:
    report.update(status='failed_original_outputs_retained',failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-start,3),
                  sources={p.name:sha(p) for p in BASE.glob('*.py')})
    save()
print(json.dumps({**report,'controls':[{k:v for k,v in c.items() if k!='rows'} for c in report['controls']]}))
