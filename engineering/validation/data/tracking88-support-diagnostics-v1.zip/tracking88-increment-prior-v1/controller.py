"""Execute all original flow controls and seal a full-video blind candidate.

This experiment never modifies a production worktree or an existing artifact.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import time
import zipfile

ROOT = Path('E:/Dev/aem')
OUT = ROOT/'artifacts/pr-queue/tracking88-increment-prior-v1'
SRC = OUT/'candidate'
prep = json.loads((OUT/'preparation.json').read_text())
assert not (OUT/'receipt.json').exists()
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
report = dict(status='running_original_controls', startedUtc=datetime.now(timezone.utc).isoformat(),
              preparationSha256=sha(OUT/'preparation.json'), limits=prep['limits'])
def save():
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
started = time.monotonic()
try:
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    with (OUT/'controls.stdout.log').open('wb') as stdout, (OUT/'controls.stderr.log').open('wb') as stderr:
        control = subprocess.run([sys.executable,str(SRC/'test_flow.py'),'-v'],cwd=SRC,env=env,
                                 stdout=stdout,stderr=stderr,check=False)
    report['controlExit'] = control.returncode
    save()
    assert control.returncode == 0, 'original flow control failed; no video adoption'
    import cv2
    import numpy as np
    sys.path.insert(0,str(SRC))
    import plate_flow as flow
    cv2.setNumThreads(1)
    cv2.setRNGSeed(88)
    video=ROOT/'artifacts/pr-queue/tracking88-real-planar-acquisition-v1/phone.avi'
    assert sha(video)=='c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
    request_path=ROOT/'artifacts/pr-queue/tracking88-stratified-seed-candidate-v1/real-baseline/periodic-manual-200.request.json'
    request=json.loads(request_path.read_text())
    seed=next(s for s in request['tracks'] if s['kind']=='plane')
    corrections={e['source_index']:e for e in request['corrections'] if e['track']==seed['id']}
    assert len(corrections)==11
    ffmpeg=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
    command=[str(ffmpeg),'-v','error','-nostdin','-hwaccel','none','-threads','1','-noautorotate',
             '-copyts','-i',str(video),'-map','0:0','-an','-sn','-dn','-fps_mode','passthrough',
             '-threads','1','-f','rawvideo','-pix_fmt','gray','pipe:1']
    report.update(status='running_full_blind_video',requestSha256=sha(request_path),
                  sourceSha256=sha(video),decodeCommand=command)
    save()
    rows=[]
    with (OUT/'decode.stderr.log').open('wb') as stderr:
        process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=stderr,env=env)
        report['decodePid']=process.pid
        save()
        previous=tracker=None
        index=0
        try:
            while True:
                data=process.stdout.read(640*480)
                if not data: break
                assert len(data)==640*480
                current=flow.prepare(np.frombuffer(data,np.uint8).reshape(480,640))
                if index==0:
                    tracker=flow.Tracker(seed,current)
                    observation=tracker.initial
                elif index in corrections:
                    observation,_=tracker.correct(current,corrections[index])
                else:
                    observation,_=tracker.observe(previous,current)
                rows.append(dict(index=index,manual=index in corrections,observation=observation,
                                 reason=tracker.reason))
                previous=current
                index+=1
        finally:
            process.stdout.close()
            report['decodeExit']=process.wait(timeout=30)
    assert report['decodeExit']==0 and len(rows)==2300
    blind=OUT/'blind-observations.json'
    blind.write_text(json.dumps(rows,separators=(',',':'))+'\n',encoding='utf-8')
    report.update(status='blind_sealed_before_label_comparison',blindSha256=sha(blind))
    save()
    labels=ROOT/'artifacts/pr-queue/tracking88-real-planar-acquisition-v1/phone-gt.zip'
    assert sha(labels)=='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
    with zipfile.ZipFile(labels) as archive:
        def corners(i):
            a=np.asarray([float(v) for v in archive.read(f'img_{i+200:05d}.txt').decode().split()]).reshape(2,4)
            return np.column_stack((a[1]-1,a[0]-1))
        original=corners(0)
        for row in rows:
            if row['index'] and not row['manual'] and row['observation'] is not None:
                row['originalCornerError']=float(np.linalg.norm(flow.transform(
                    np.asarray(row['observation']['matrix']),original)-corners(row['index']),axis=1).max())
    automatic=[r for r in rows if 'originalCornerError' in r]
    failed=[r for r in automatic if r['originalCornerError']>15.]
    report.update(status='experiment_complete_not_adopted',frames=len(rows),
                  automaticVisible=len(automatic),automaticLost=2300-12-len(automatic),
                  originalOver15Frames=len(failed),maxCornerError=max(r['originalCornerError'] for r in automatic),
                  failingIndices=[r['index'] for r in failed],
                  baseline=dict(automaticVisible=915,originalOver15Frames=21,maxCornerError=56.640030446))
    (OUT/'label-comparison.json').write_text(json.dumps(rows,separators=(',',':'))+'\n',encoding='utf-8')
except BaseException as cause:
    report.update(status='failed_original_failure_retained_not_adopted',failure=repr(cause))
    raise
finally:
    report['sourcesUnchanged']=all(sha(SRC/name)==digest for name,digest in prep['files'].items())
    report.update(elapsedSeconds=round(time.monotonic()-started,3),
                  completedUtc=datetime.now(timezone.utc).isoformat())
    save()
    print(json.dumps(report),flush=True)
assert report['sourcesUnchanged']
