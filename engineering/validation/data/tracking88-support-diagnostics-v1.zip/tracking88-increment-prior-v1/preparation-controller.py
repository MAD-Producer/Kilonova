"""Prepare an isolated incremental projective regularization experiment.

No labels, output filtering, new visibility rule, or production edit. The fixed
regularizer is an algorithm hypothesis, not a relaxed publication threshold.
"""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('E:/Dev/aem')
OUT = ROOT / 'artifacts/pr-queue/tracking88-increment-prior-v1'
SRC = OUT / 'candidate'
SRC.mkdir(parents=True, exist_ok=False)
BASE = '72423ec2aaf877147d20daa6827a2929bf3649b3'
names = ('plate_contract.py', 'plate_flow.py', 'test_flow.py')
for name in names:
    (SRC / name).write_bytes(subprocess.check_output(
        ['git', 'show', f'{BASE}:tools/tracking/{name}'], cwd=ROOT))

path = SRC / 'plate_flow.py'
before = path.read_text()
helper = '''def regularized_increment(previous, reference, measured, roi):
    # Only fit-partition RANSAC inliers enter this estimate. The previous
    # published/manual image transform defines the normalization and a weak
    # zero-perspective incremental prior. No annotation or holdout enters it.
    x, y, w, h = roi
    corners = transform(previous, [[x,y],[x+w,y],[x+w,y+h],[x,y+h]])
    centre = corners.mean(axis=0)
    scale = max(float(np.linalg.norm(corners-centre,axis=1).mean()), 1.)
    normal = np.array([[1/scale,0,-centre[0]/scale],
                       [0,1/scale,-centre[1]/scale],[0,0,1.]])
    source = transform(normal @ previous, reference)
    target = transform(normal, measured)
    rows, values = [], []
    for (u,v),(a,b) in zip(source,target):
        rows.extend([[u,v,1,0,0,0,-a*u,-a*v],
                     [0,0,0,u,v,1,-b*u,-b*v]])
        values.extend([a,b])
    weight = np.sqrt(len(reference)) * .02
    rows.extend([[0,0,0,0,0,0,weight,0],
                 [0,0,0,0,0,0,0,weight]])
    values.extend([0.,0.])
    solution, _, rank, _ = np.linalg.lstsq(np.asarray(rows), np.asarray(values), rcond=None)
    require(rank == 8 and np.isfinite(solution).all(), 'incremental projective fit failed')
    delta = np.append(solution,1.).reshape(3,3)
    return plane_matrix(np.linalg.inv(normal) @ delta @ normal @ previous, roi)


'''
assert before.count('class Tracker:') == 1
text = before.replace('class Tracker:', helper+'class Tracker:')
needle = '        self.reference_matrix = matrix.copy()'
assert text.count(needle) == 1
text = text.replace(needle, needle+'\n        self.last_matrix = matrix.copy()')
needle = "            matrix = plane_matrix(matrix, self.seed['roi'])\n            errors ="
assert text.count(needle) == 1
text = text.replace(needle, "            matrix = regularized_increment(self.last_matrix, self.reference[fit][inliers.ravel()!=0], self.points[fit][inliers.ravel()!=0], self.seed['roi'])\n            errors =")
needle = "        return dict(kind='plane', matrix=matrix.tolist()), ratio*math.exp(-rms)"
assert text.count(needle) == 1
text = text.replace(needle, '        self.last_matrix = matrix.copy()\n'+needle)
path.write_text(text, encoding='utf-8')
receipt = dict(status='prepared_unexecuted_not_adopted', base=BASE,
    algorithm='Fixed .02 normalized incremental projective ridge; no parameter search',
    files={name: hashlib.sha256((SRC/name).read_bytes()).hexdigest() for name in names},
    limits=['Full original video, ROI, manual schedule and publication/quality gates unchanged',
            'No label reads until blind image-derived observations are sealed',
            'A known failing sequence motivated this hypothesis; not an unseen benchmark',
            'No production/panel/dependency or original assertion changes'])
(OUT/'preparation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
(OUT/'preparation-controller.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(receipt))
