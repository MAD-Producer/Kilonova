"""Blind geometric support diagnostic; no tracker changes or accepted outputs."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys, zipfile
import cv2
import numpy as np

ROOT = Path('E:/Dev/aem')
OUT = ROOT / 'artifacts/pr-queue/tracking88-support-uncertainty-probe-v1'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
baseline = OUT / 'baseline'
baseline.mkdir()
for name in ['plate_contract.py', 'plate_flow.py']:
    (baseline / name).write_bytes(subprocess.check_output(['git', 'show', '72423ec2:tools/tracking/' + name], cwd=ROOT))
sys.path.insert(0, str(baseline))
import plate_flow as flow
cv2.setNumThreads(1)
cv2.setRNGSeed(88)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = ROOT / 'artifacts/pr-queue/tracking88-real-planar-acquisition-v1/phone.avi'
assert sha(source) == 'c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
request = json.loads((ROOT / 'artifacts/pr-queue/tracking88-photographed-prototype-v6/periodic-manual-200.request.json').read_text())
edit = next(e for e in request['corrections'] if e['track'] == 'plane' and e['source_index'] == 1800)
seed = next(s for s in request['tracks'] if s['id'] == 'plane')
ffmpeg = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
command = [str(ffmpeg), '-v', 'error', '-nostdin', '-threads', '1', '-noautorotate', '-copyts', '-i', str(source), '-map', '0:0', '-an', '-sn', '-dn', '-vf', r'select=between(n\,1800\,1830)', '-fps_mode', 'passthrough', '-threads', '1', '-f', 'rawvideo', '-pix_fmt', 'gray', 'pipe:1']
decoded = subprocess.run(command, capture_output=True, check=True)
(OUT / 'decode.stderr.log').write_bytes(decoded.stderr)
assert len(decoded.stdout) == 31 * 640 * 480
images = np.frombuffer(decoded.stdout, np.uint8).reshape(31, 480, 640)


def support(matrix, reference, measured, roi):
    # Source normalization is fixed by the requested ROI, not benchmark labels.
    # Destination normalization is fixed by decoded image extent. Propagate
    # independent one-pixel observation noise through the homography Jacobian.
    x, y, w, h = roi
    origin = np.array([[2 / w, 0, -2 * x / w - 1], [0, 2 / h, -2 * y / h - 1], [0, 0, 1.]])
    destination = np.array([[1 / 320., 0, -1], [0, 1 / 320., -.75], [0, 0, 1.]])
    normalized = destination @ matrix @ np.linalg.inv(origin)
    normalized /= normalized[2, 2]

    def jacobian(points):
        p = flow.transform(origin, points)
        output = flow.transform(normalized, p)
        denominator = np.column_stack((p, np.ones(len(p)))) @ normalized[2]
        a = np.zeros((len(p) * 2, 8))
        for i, ((px, py), (u, v), z) in enumerate(zip(p, output, denominator)):
            a[2 * i] = [px, py, 1, 0, 0, 0, -u * px, -u * py]
            a[2 * i + 1] = [0, 0, 0, px, py, 1, -v * px, -v * py]
            a[2 * i:2 * i + 2] *= 320. / z
        return a

    projection_error = np.linalg.norm(flow.transform(matrix, reference) - measured, axis=1)
    inliers = projection_error <= flow.LIMITS['planeFitPixels']
    a = jacobian(reference[inliers])
    left, singular, right = np.linalg.svd(a, full_matrices=False)
    if len(singular) != 8 or singular[-1] <= singular[0] * 1e-12:
        return dict(inliers=int(inliers.sum()), fullRank=False)
    inverse = (right.T / singular) @ left.T
    corners = np.array([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], float)
    amplification = jacobian(corners) @ inverse
    uncertainty = [float(np.linalg.svd(amplification[i:i + 2], compute_uv=False)[0]) for i in range(0, 8, 2)]
    return dict(inliers=int(inliers.sum()), fullRank=True, singularValues=singular.tolist(),
                onePixelNoiseCornerSigma=uncertainty, maximumSigma=max(uncertainty),
                withinExistingThreePixelConsensus=max(uncertainty) <= flow.LIMITS['planeConsensusMaxPixels'])


reference = flow.prepare(images[0])
tracker = flow.Tracker(seed, reference)
tracker.correct(reference, edit)
previous = reference
rows = []
for offset in range(1, 31):
    current = flow.prepare(images[offset])
    observation, score = tracker.observe(previous, current)
    previous = current
    row = dict(index=1800 + offset, baselineVisible=observation is not None, baselineReason=tracker.reason)
    if observation is not None:
        matrix = np.array(observation['matrix'])
        fit = ~tracker.holdout
        row.update(matrix=matrix.tolist(), support=support(matrix, tracker.reference[fit], tracker.points[fit], seed['roi']))
    rows.append(row)
# Seal blind geometry before opening independent corner annotations.
(OUT / 'blind-measurements.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
annotations = ROOT / 'artifacts/pr-queue/tracking88-real-planar-acquisition-v1/phone-gt.zip'
assert sha(annotations) == 'd4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
with zipfile.ZipFile(annotations) as bundle:
    def quad(index):
        a = np.array([float(v) for v in bundle.read(f'img_{index + 200:05d}.txt').decode().split()]).reshape(2, 4)
        return np.column_stack([a[1] - 1, a[0] - 1])
    original = quad(0)
    for row in rows:
        if 'matrix' in row:
            row['independentCornerMax'] = float(np.linalg.norm(flow.transform(np.array(row['matrix']), original) - quad(row['index']), axis=1).max())
visible = [r for r in rows if r['baselineVisible']]
retained = [r for r in visible if r['support'].get('withinExistingThreePixelConsensus', False)]
report = dict(status='blind_support_diagnostic_complete_not_adopted', source='72423ec2',
              controllerSha256=sha(OUT / 'controller.py'), sourceSha256=sha(source),
              annotationSha256=sha(annotations), rows=rows, command=command,
              completedUtc=datetime.now(timezone.utc).isoformat(),
              visible=len(visible), supported=len(retained),
              originalOver15=sum(r['independentCornerMax'] > 15 for r in visible),
              supportedOver15=sum(r['independentCornerMax'] > 15 for r in retained),
              limits=['Retrospective diagnostic on 30 frames, not whole-sequence acceptance or an adopted product gate',
                      'One-pixel observation sigma is a model assumption, not a guaranteed pixel error bound',
                      'ROI-only geometric uncertainty cannot prove correct feature identity or planar scene geometry',
                      'Original full-sequence quality failure remains until a real fix passes all original controls'])
(OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in report.items() if k not in ('rows', 'command', 'limits')}))
