//! Reapply the current mixer to retained real ONNX/video samples, not new inference.
use motion_model::{depth::{blend::*, *}, Camera};
use serde_json::{json, Value};
use std::{fs, path::PathBuf, time::Instant};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
fn main() -> Result<()> {
    let out = PathBuf::from(std::env::args().nth(1).ok_or("output required")?);
    let manifest: Value = serde_json::from_slice(&fs::read(out.join("inputs.json"))?)?;
    let anchors = [DepthAnchor { value:manifest["low"].as_f64().unwrap(), camera_z_meters:10. },
                   DepthAnchor { value:manifest["high"].as_f64().unwrap(), camera_z_meters:1. }];
    let [w,h] = [320,180];
    let camera = DepthProjection::new(Camera::new(w,h).pose(0.,w,h)?,100.)?;
    let rows = manifest["cases"].as_array().unwrap();
    let derived: DepthModel = serde_json::from_value(manifest["derived_model"].clone())?;
    let mut resources = Vec::new();
    for row in rows {
        let bytes = fs::read(row["depth_path"].as_str().unwrap())?;
        let values = bytes.chunks_exact(4).map(|v| f32::from_le_bytes(v.try_into().unwrap())).collect();
        resources.push(DepthResource::new(DepthDescriptor {
            size:[w,h], source:DepthSource { asset:76, revision:1,
                pts:DepthTime { ticks:row["ticks"].as_i64().unwrap(), timescale:15000 } },
            geometry:DepthGeometry { source_size:[w,h], crop:[0,0,w,h], quarter_turns:0, mirror_x:false },
            model:serde_json::from_value(manifest["input_model"].clone())?,
            measure:DepthMeasure::Relative { near:NearDirection::Increasing },
            scale:1.,offset:0.,valid_range:None,
        },values,None,None)?);
    }
    let reference_calibration = RelativeDepthCalibration::new(resources[0].descriptor().clone(),
        anchors,CalibrationCurve::CameraZ,CalibrationExtrapolation::Reject)?;
    let binding = reference_calibration.bind(&resources[0])?;
    let mut descriptor = resources[0].descriptor().clone();
    descriptor.measure = DepthMeasure::Metric { meters_per_unit:1., axis:DepthAxis::CameraZ };
    descriptor.model = derived.clone();
    let reference = DepthResource::new(descriptor,
        (0..w as usize*h as usize).map(|i| binding.camera_z_meters(i).unwrap().unwrap() as f32).collect(),
        None,None)?;
    let first_registration = DepthRegistration::same_sample(DepthImageFrame::from_depth(&resources[0]),
        DepthImageFrame::from_depth(&reference))?;
    let mut records = Vec::new();
    for (index, (row, ai)) in rows.iter().zip(&resources).enumerate() {
        let calibration = RelativeDepthCalibration::new(ai.descriptor().clone(),anchors,
            CalibrationCurve::CameraZ,CalibrationExtrapolation::Reject)?;
        let registration = DepthRegistration::new(DepthImageFrame::from_depth(ai),
            DepthImageFrame::from_depth(&reference),[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]])?;
        let mask = DepthWeightMask::new(ai.descriptor().source.clone(),[w,h],ai.descriptor().geometry.clone(),
            (0..w as usize*h as usize).map(|i| if i % (w as usize) < 80 { 0. }
                else if i % (w as usize) < 160 { 0.5 } else { 1. }).collect(),None)?;
        let mask_registration = DepthRegistration::same_sample(DepthImageFrame::from_depth(ai),mask.frame().clone())?;
        if index != 0 {
            let cause = blend_depth(DepthBlendInput::new(ai,Some(&calibration),&camera,None)?,
                DepthBlendInput::new(&reference,None,&camera,None)?,&first_registration,None,
                DepthBlendOptions { weight:0.5, output_model:derived.clone(), byte_budget:w as usize*h as usize*5 })
                .err().ok_or("stale registration accepted")?;
            assert!(cause.to_string().contains("does not match source"));
        }
        for (name,weight,masked) in [("reference",0.,false),("half",0.5,false),("ai",1.,false),("mask",1.,true)] {
            let began = Instant::now();
            let result = blend_depth(DepthBlendInput::new(ai,Some(&calibration),&camera,None)?,
                DepthBlendInput::new(&reference,None,&camera,None)?,&registration,
                masked.then_some((&mask,&mask_registration)),
                DepthBlendOptions { weight,output_model:derived.clone(),byte_budget:w as usize*h as usize*5 })?;
            let elapsed_us = began.elapsed().as_micros();
            let mut maximum = 0_f64;
            for (i,actual) in result.resource.values().iter().enumerate() {
                let a = 10. - 9. * ((f64::from(ai.values()[i])-anchors[0].value)/(anchors[1].value-anchors[0].value));
                let b = f64::from(reference.values()[i]);
                let factor = if masked { if i % (w as usize) < 80 { 0. }
                    else if i % (w as usize) < 160 { 0.5 } else { 1. } } else { weight };
                let expected = (1.-factor)*b+factor*a;
                maximum = maximum.max((f64::from(*actual)-expected).abs());
                assert!((f64::from(*actual)-expected).abs() <= 2e-6,"{index} {name} pixel={i}");
            }
            assert!(result.resource.validity().unwrap().iter().all(|v| *v==1));
            let count = u64::from(w)*u64::from(h);
            assert_eq!(result.metrics.ai_reads,if weight==0. {0} else if masked {count*3/4} else {count});
            assert_eq!(result.metrics.reference_reads,if weight==1. && !masked {0} else if masked {count/2} else {count});
            assert_eq!(result.metrics.mask_reads,if masked {count} else {0});
            fs::write(out.join(format!("{}-{name}.f32",row["name"].as_str().unwrap())),
                result.resource.values().iter().flat_map(|v| v.to_le_bytes()).collect::<Vec<_>>())?;
            records.push(json!({"name":row["name"],"mode":name,"source":ai.descriptor().source,
                "elapsed_cpu_us":elapsed_us,"maximum_m_error":maximum,"metrics":result.metrics,
                "registration":"explicit authored per-frame identity; no alignment accuracy claim"}));
        }
    }
    fs::write(out.join("result.json"),serde_json::to_vec_pretty(&json!({
        "status":"passed_current_mixer_on_retained_natural_inputs", "cases":records,
        "fresh_inference":false,"fresh_native_render":false,"fresh_current_mixer":true,
        "limits":"Authored common calibration and static identity registration; no metric ground truth, motion-compensation or flicker-reduction claim"
    }))?)?;
    Ok(())
}
