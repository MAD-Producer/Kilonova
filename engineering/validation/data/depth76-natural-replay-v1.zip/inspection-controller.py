"""Display and describe retained real inputs without treating temporal averaging as quality."""
from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image,ImageDraw
root=Path('E:/Dev/aem/artifacts/pr-queue/depth76-natural-replay-v1')
inputs=json.loads((root/'inputs.json').read_text())
result=json.loads((root/'result.json').read_text())
assert len(result['cases'])==48
sheet=Image.new('RGB',(1000,425),'#202020')
draw=ImageDraw.Draw(sheet)
draw.text((6,3),'NASA / ISS crew; retained ONNX depth, fresh current mixer; authored units; no metric ground truth',fill='white')
for col,label in enumerate(['Current video','Static reference','Current AI depth','Half blend','Linear mask mix']):
    draw.text((col*200+5,24),label,fill='white')
for row,index in enumerate([0,5,11]):
    case=inputs['cases'][index]
    originals=[Image.open(case['input_image_path']).convert('RGB')]
    for mode in ['reference','ai','half','mask']:
        values=np.fromfile(root/f"{case['name']}-{mode}.f32",dtype='<f4').reshape(180,320)
        image=np.rint(np.clip((10.-values)/9.,0,1)*255).astype(np.uint8)
        originals.append(Image.fromarray(image).convert('RGB'))
    for col,image in enumerate(originals):
        sheet.paste(image.resize((200,112)),(col*200,48+row*126))
    draw.text((5,163+row*126),f"Frame {450+index}; exact PTS {case['ticks']}/15000",fill='white')
sheet.save(root/'natural-replay-contact.png')
temporal=[]
for previous,current in zip(inputs['cases'],inputs['cases'][1:]):
    row={}
    for mode in ['reference','ai','half','mask']:
        a=np.fromfile(root/f"{previous['name']}-{mode}.f32",dtype='<f4').astype(np.float64)
        b=np.fromfile(root/f"{current['name']}-{mode}.f32",dtype='<f4').astype(np.float64)
        row[mode]=dict(mean_abs_delta_m=float(np.abs(a-b).mean()),maximum_abs_delta_m=float(np.abs(a-b).max()))
    row.update(previous=previous['name'],current=current['name'])
    temporal.append(row)
report=dict(status='observed_not_temporal_quality_acceptance',temporal=temporal,
    cases=48,pixels_per_case=57600,maximum_numeric_error_m=max(r['maximum_m_error'] for r in result['cases']),
    blend_cpu_us=dict(min=min(r['elapsed_cpu_us'] for r in result['cases']),max=max(r['elapsed_cpu_us'] for r in result['cases'])),
    retained_output_bytes_per_case=288000,
    limits=['Same-pixel temporal differences contain camera/subject motion, lighting, scale and occlusion',
            'A frozen reference necessarily has zero delta; a half blend scales change without proving reduced flicker',
            'Explicit identity registration on changing video does not establish alignment or remove ghosts',
            'No fresh inference, physical distance truth, native render or GPU-duration claim'],
    files=[dict(path=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
           for p in sorted(root.glob('*.f32'))])
(root/'diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['temporal','files']}))
