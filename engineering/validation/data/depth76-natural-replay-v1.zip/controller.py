"""Fresh current mixer on retained credited real ONNX/video fields, not fresh inference."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, subprocess, time
ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/reference-depth76'
PROBE = ROOT / '.tools/depth76-natural-probe'
OUT = ROOT / 'artifacts/pr-queue/depth76-natural-replay-v1'
OUT.mkdir(exist_ok=False)
HOME = ROOT / '.tools/ai-depth74'
ORIGINAL = ROOT / 'artifacts/pr-queue/issue74-natural-domain-v1'
env = os.environ.copy()
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT / 'target/reference-depth76-contract'), CARGO_BUILD_JOBS='1',
           CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',
           TEMP=str(ROOT / 'target/ci-policy-validation-tmp'),TMP=str(ROOT / 'target/ci-policy-validation-tmp'))
os.environ['TEMP'] = env['TEMP']
os.environ['TMP'] = env['TMP']
import numpy as np
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
fixtures = json.loads((HOME / 'natural-domain/cases.json').read_text())
original = json.loads((ORIGINAL / 'accepted.json').read_text())
cases = [v for v in fixtures['cases'] if v.get('consecutive')]
assert len(cases) == 12 and [v['frame'] for v in cases] == list(range(450,462))
low, high = float('inf'), float('-inf')
for row in cases:
    p = ORIGINAL / row['name'] / 'native/actual.f32'
    rgb = HOME / 'natural-domain' / fixtures['caseDirectory'] / row['file']
    assert sha(rgb) == row['sha256']
    values = np.fromfile(p,dtype='<f4')
    assert values.size == 320*180 and np.isfinite(values).all()
    reference = np.fromfile(ORIGINAL / row['name'] / 'official-reference.f32',dtype='<f4')
    assert reference.size == values.size
    assert np.max(np.abs(values.astype(np.float64)-reference))/max(float(np.abs(reference).max()),1e-6) <= 2e-4
    logged = next(v for v in original['rows'] if v['name'] == row['name'])
    assert logged['provider'] == 'CPUExecutionProvider' and logged['pts']['ticks'] == row['ticks']
    low, high = min(low,float(values.min())), max(high,float(values.max()))
    row.update(depth_path=str(p),depth_sha256=sha(p),original_accepted_sha256=sha(p.parent/'accepted.json'),
               input_image_path=str(rgb),fresh_inference=False)
# One explicitly authored common relative-to-metre mapping, fixed for all cases.
# Its range comes from these declared diagnostic inputs, not metric observations.
digest = bytes.fromhex('274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434')
inputs = dict(cases=cases,low=low,high=high,
    input_model=dict(id='depth-anything-v2-small',revision='a561b849ebae10a6f5ef49e26c83cbbcd36c71bf',
                     sha256=list(digest),processing='dav2-small-rgb8-letterbox518-align-corners-relative-v1'),
    derived_model=dict(id='authored-natural-replay-reference-mix',revision='1',
                       sha256=list(bytes.fromhex(sha(PROBE/'src/main.rs'))),processing='common-anchor-camera-z-static-reference-v1'),
    limits='Authored global anchors and explicit per-frame identity; no metric truth, motion compensation or fresh inference',
    sourceManifest=fixtures['sourceManifest'])
(OUT/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
(OUT/'probe.rs').write_bytes((PROBE/'src/main.rs').read_bytes())
(OUT/'probe.Cargo.toml').write_bytes((PROBE/'Cargo.toml').read_bytes())
source_paths = [p for p in (WORK/'crates/motion-model').rglob('*.rs') if 'target' not in p.parts]
source_paths += [WORK/'Cargo.lock',WORK/'crates/motion-model/Cargo.toml',PROBE/'src/main.rs',PROBE/'Cargo.toml']
sources = lambda: {str(p):sha(p) for p in source_paths}
report = dict(status='running',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),
              source=sources(),startedUtc=datetime.now(timezone.utc).isoformat(),phases=[])
save = lambda: (OUT/'exit.json').write_text(json.dumps(report,indent=2)+'\n')
save()
began = time.monotonic()
try:
    commands = [
        ['cargo','generate-lockfile','--offline','--manifest-path',str(PROBE/'Cargo.toml')],
        ['cargo','build','--locked','--offline','--manifest-path',str(PROBE/'Cargo.toml')],
        [str(ROOT/'target/reference-depth76-contract/debug/depth76-natural-probe.exe'),str(OUT)],
    ]
    for index, command in enumerate(commands):
        with (OUT/f'{index}-stdout.log').open('wb') as stdout,(OUT/f'{index}-stderr.log').open('wb') as stderr:
            process = subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
            phase = dict(command=command,pid=process.pid)
            report['phases'].append(phase);save()
            phase['exitCode'] = process.wait()
        assert phase['exitCode'] == 0, (index,command)
    result = json.loads((OUT/'result.json').read_text())
    assert len(result['cases']) == 48 and result['fresh_current_mixer'] and not result['fresh_inference']
    report['sourceUnchanged'] = sources() == report['source']
    assert report['sourceUnchanged']
    assert (OUT/'2-stdout.log').read_bytes() == b'' and (OUT/'2-stderr.log').read_bytes() == b''
    (OUT/'probe.Cargo.lock').write_bytes((PROBE/'Cargo.lock').read_bytes())
    report['status'] = 'passed_current_mixer_on_retained_real_inputs_not_temporal_quality_proof'
except BaseException as cause:
    report.update(status='failed_original_outputs_retained',error=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-began)
    save()
print(json.dumps({k:v for k,v in report.items() if k!='source'}))
