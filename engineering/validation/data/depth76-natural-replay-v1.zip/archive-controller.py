"""Archive replay evidence and source; external credited imagery/planes stay external."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/reference-depth76'
OUT=ROOT/'artifacts/pr-queue/depth76-natural-replay-v1'
DATA=WORK/'engineering/validation/data'
sha=lambda b:hashlib.sha256(b).hexdigest()
receipt=json.loads((OUT/'exit.json').read_text())
diagnostic=json.loads((OUT/'diagnostic.json').read_text())
assert receipt['status']=='passed_current_mixer_on_retained_real_inputs_not_temporal_quality_proof'
assert receipt['sourceUnchanged'] and diagnostic['cases']==48
entries={p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file() and p.suffix not in ['.f32','.png']}
entries['archive-controller.py']=Path(__file__).read_bytes()
entries['inspection-controller.py']=(ROOT/'.tools/issue-closure-review/inspect-depth76-natural-replay-v1.py').read_bytes()
for path,digest in receipt['source'].items():
    p=Path(path);data=p.read_bytes();assert sha(data)==digest,path
    key='source/'+str(p.relative_to(WORK)).replace('\\','/') if p.is_relative_to(WORK) else 'external-probe/'+p.name
    entries[key]=data
for path in (WORK/'crates/motion-effects/src').rglob('*.rs'):
    entries['source/'+str(path.relative_to(WORK)).replace('\\','/')]=path.read_bytes()
archive=DATA/'depth76-natural-replay-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as output:
    for path,data in sorted(entries.items()):output.writestr(path,data)
with zipfile.ZipFile(archive) as verify:
    assert set(verify.namelist())==set(entries)
    for path,data in entries.items():assert verify.read(path)==data
manifest=dict(status=receipt['status'],head=receipt['head'],sourceUnchanged=True,cases=48,
    frames=12,pixelsPerCase=57600,maximumNumericErrorM=diagnostic['maximum_numeric_error_m'],
    blendCpuUs=diagnostic['blend_cpu_us'],elapsedSeconds=receipt['elapsedSeconds'],
    archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
    members=[dict(path=p,bytes=len(d),sha256=sha(d)) for p,d in sorted(entries.items())],
    limits=diagnostic['limits']+['Credited NASA imagery and float planes remain external; hashes/paths are retained, not portable input payloads',
                               'Global anchors derive from the declared diagnostic cohort, not physical distance observations'])
(DATA/'depth76-natural-replay-v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
