"""Collect diagnostic phase traces; never relabel an old P95 failure as fixed."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
from ctypes import wintypes
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/prerender-input-priority'
OUT = ROOT / 'artifacts/pr-queue/prerender-input-phases-v1'
BASE = 'cd26ba2964569d765cafb34a89be079ac0506861'
PARENT = 34684

def now():
    return datetime.now(timezone.utc).isoformat()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode('utf-8').strip()

def sources():
    names = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {name: hashlib.sha256((WORK / name).read_bytes()).hexdigest()
            for name in names if name and name.endswith(('.rs', '.toml', '.wgsl', '.json', '.md', '.py', '.yml', '.lock'))}

assert git('rev-parse', 'HEAD') == BASE
assert git('branch', '--show-current') == 'codex/82-native-input-phases'
assert set(git('diff', '--name-only').splitlines()) == {
    'desktop/app/src/engine/prerender/tests/input_latency.rs',
    'desktop/app/src/engine/prerender/tests/input_latency/driver.rs'}
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'controller.py')
source = sources()
report = dict(status='queued', head=BASE, source=source, steps=[], startedUtc=now(),
    limits='Test-only instrumentation, not a production fix or whole issue82 acceptance. Original combined-v6 strict input P95 failure and native crash remain failed. No scenario/count/order/criterion/assertion change or unchanged retry-to-green.')

def save():
    (OUT / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
    CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0',
    CARGO_PROFILE_TEST_DEBUG='0', RUST_BACKTRACE='full',
    LOCALAPPDATA=str(OUT / 'owned-profile'),
    MOTION_PRERENDER_INPUT_ARTIFACTS=str(OUT / 'input'))

def step(name, args, required=True):
    began = now()
    print(json.dumps(dict(start=name)), flush=True)
    with (OUT / f'{name}.stdout.log').open('wb') as stdout, (OUT / f'{name}.stderr.log').open('wb') as stderr:
        code = subprocess.run(args, cwd=WORK, env=env, stdout=stdout, stderr=stderr).returncode
    row = dict(name=name, command=args, exitCode=code, startedUtc=began, completedUtc=now(),
        sourceUnchanged=sources() == source and git('rev-parse', 'HEAD') == BASE)
    row['passed'] = code == 0 and row['sourceUnchanged']
    report['steps'].append(row)
    save()
    print(json.dumps(row), flush=True)
    assert row['sourceUnchanged']
    if required:
        assert row['passed'], f'{name}: original output retained'

kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
handle = None
save()
try:
    handle = kernel.OpenProcess(0x00100000, False, PARENT)
    assert handle and kernel.WaitForSingleObject(handle, 0) == 258, 'expected exact live disk gate'
    report['parent'] = dict(pid=PARENT, handleCaptured=True, live=True)
    save()
    print(json.dumps(dict(queuedBehind=PARENT)), flush=True)
    while True:
        result = kernel.WaitForSingleObject(handle, 1000)
        if result == 0:
            break
        assert result == 258
    previous = json.loads((ROOT / 'artifacts/pr-queue/prerender-disk-cache-v1/exit.json').read_text(encoding='utf-8'))
    assert previous.get('completedUtc'), 'disk gate stopped without terminal evidence'
    assert sources() == source
    report['diskComponent'] = {k: previous.get(k) for k in ['status', 'completedUtc']}
    active = subprocess.check_output(['powershell', '-NoProfile', '-Command',
        "@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('rustc.exe','link.exe','cargo.exe') -and $_.CommandLine -match 'gltf-animation87-contract' }).Count"]).decode().strip()
    assert active == '0', f'serial target still active: {active}'
    for name in ['crates/motion-render/src/lib.rs', 'crates/motion-desktop-media/src/lib.rs', 'desktop/app/src/main.rs']:
        os.utime(WORK / name, None)
    assert sources() == source
    report.update(status='running', releasedUtc=now())
    Path(env['LOCALAPPDATA']).mkdir()
    save()
    desktop = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth',
        '--locked', '--offline', '--bin', 'motion-studio']
    name = 'engine::prerender::tests::input_latency::native_controls_record_edit_and_scrub_latency_with_real_optional_work'
    step('test-inventory', desktop + ['--', '--list'])
    assert name + ': test' in (OUT / 'test-inventory.stdout.log').read_text(encoding='utf-8')
    step('native-input', desktop + [name, '--', '--ignored', '--exact', '--test-threads=1'])
    output = (OUT / 'native-input.stdout.log').read_text(encoding='utf-8')
    assert '1 passed; 0 failed; 0 ignored' in output, 'exact native test did not execute'
    data_path = OUT / 'input/input-costs.json'
    data = json.loads(data_path.read_text(encoding='utf-8'))
    allowed = {'input.window_events', 'input.pump', 'actions.draw_commands', 'actions.apply',
        'actions.await_reply', 'actions.accept_state', 'present.draw_commands',
        'present.ui_frame', 'present.enqueue', 'present.await_reply'}
    assert len(data['runs']) == 8 and not data['partialSamples']
    summaries = []
    for run in data['runs']:
        assert len(run['samples']) == 60
        values = {phase: [] for phase in allowed}
        for sample in run['samples']:
            assert sample['verified'] and sample['phases']['dropped'] == 0
            records = sample['phases']['records']
            assert 0 < len(records) <= 64
            assert all(record['phase'] in allowed and isinstance(record['elapsed_us'], int)
                and record['elapsed_us'] >= 0 for record in records)
            for phase, count in [('input.window_events', 3), ('input.pump', 3),
                ('actions.draw_commands', 3), ('present.await_reply', sample['presentPolls'])]:
                assert sum(r['phase'] == phase for r in records) == count, (phase, sample)
            for phase in allowed:
                values[phase].append(sum(r['elapsed_us'] for r in records if r['phase'] == phase))
        summaries.append(dict(scenario=run['scenario'], episode=run['episode'], enabled=run['enabled'],
            p95Us={phase: sorted(v)[math.ceil(len(v) * .95) - 1] for phase, v in values.items()}))
    report['trace'] = dict(samples=480, allVerified=True, dropped=0,
        rawSha256=hashlib.sha256(data_path.read_bytes()).hexdigest(), summaries=summaries,
        limits='Native window event timing is nested in pump timing; do not sum them as independent costs.')
    save()
    step('original-strict-p95', [sys.executable, 'tools/analyze_prerender_input.py', str(data_path),
        '--output', str(OUT / 'input-assessment.json')], required=False)
    report['p95Assessment'] = json.loads((OUT / 'input-assessment.json').read_text(encoding='utf-8'))
    report.update(status='diagnostic_complete_not_a_fix', completedUtc=now())
    save()
except BaseException as error:
    report.update(status='failed', completedUtc=now(), failure=repr(error))
    save()
    raise
finally:
    if handle:
        kernel.CloseHandle(handle)
