from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,subprocess,time,shutil
root=Path('E:/Dev/aem'); work=root/'.worktrees/tracking-colmap88'
out=root/'artifacts/pr-queue/tracking88-main-e314cc92-check-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
assert head=='90a8d7b1f5ea9e8c1d09aad9db80856d68c425b0'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work)
assert shutil.disk_usage(root).free>3*1024**3
names=subprocess.check_output(['git','ls-files'],cwd=work,text=True).splitlines()
def identity():
 return {n:hashlib.sha256((work/n).read_bytes()).hexdigest() for n in names if (work/n).is_file() and (n.startswith(('crates/','desktop/')) or n in ('Cargo.toml','Cargo.lock'))}
source=identity()
env=os.environ.copy()
for key in list(env):
 if key.startswith('MOTION_'): env.pop(key,None)
env.update(CARGO_HOME=str(root/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(root/'target/colmap88-isolated-check'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
command=['cargo','check','--workspace','--exclude','motion-android','--all-targets','--features','motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth','--locked']
receipt=dict(status='running',head=head,main='e314cc92232dcd366b01e10454ae1100d4e24d63',source=source,command=command,startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Compilation only; no test execution or full regression claim','Own dedicated target; E cache and temp; no cleanup; Android excluded by user'])
(out/'exit.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
started=time.monotonic()
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 process=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr)
receipt.update(status='check_passed' if process.returncode==0 else 'check_failed',exitCode=process.returncode,elapsedSeconds=round(time.monotonic()-started,3),sourceUnchanged=identity()==source,completedUtc=datetime.now(timezone.utc).isoformat(),freeBytesAfter=shutil.disk_usage(root).free)
assert receipt['sourceUnchanged']
(out/'exit.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='source'}))
raise SystemExit(process.returncode)
