from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,time,traceback
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-colmap88';out=root/'artifacts/pr-queue/3d-professional-e8ff7a1a-native-v1'
out.mkdir(exist_ok=False);(out/'controller.py').write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
assert head=='e8ff7a1ac1f91b6ec80507a778d91aaef0aff827'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work)
assert shutil.disk_usage(root).free>=3*1024**3,'Insufficient headroom; no compilation started'
names=subprocess.check_output(['git','ls-files'],cwd=work,text=True).splitlines()
def identity():
 return {n:sha(work/n) for n in names if (work/n).is_file() and (n.startswith(('crates/','desktop/','sdk/')) or n in ('Cargo.toml','Cargo.lock','ATTRIBUTION.md','PROVENANCE.md','NOTICE'))}
source=identity();env=os.environ.copy()
for k in list(env):
 if k.startswith('MOTION_'):env.pop(k,None)
env.update(CARGO_HOME=str(root/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(root/'target/colmap88-isolated-check'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',TEMP=str(root/'target/ci-policy-validation-tmp'),TMP=str(root/'target/ci-policy-validation-tmp'),LOCALAPPDATA=str(out/'appdata'),RUST_BACKTRACE='full',MOTION_PROFESSIONAL_KEY_ARTIFACTS=str(out/'key-native'),MOTION_PHOTOGRAPHED_SCREEN_ARTIFACTS=str(out/'screen-native'))
command=['cargo','test','-p','motion-effects','-p','motion-desktop-media','--test','chroma_key_sample','--test','professional_key','--test','professional_screen_photo','--no-run','--message-format=json','--features','motion-desktop-media/ffmpeg,motion-desktop-media/ai-depth','--locked']
report=dict(status='linking',head=head,main='e314cc92232dcd366b01e10454ae1100d4e24d63',source=source,command=command,startedUtc=datetime.now(timezone.utc).isoformat(),executions=[],limits=['Three complete selected test targets, not full workspace or repair of historical native AVs','Original assertions, budgets, ignores, backend and stack; default Info, serial own GPU use','Dedicated current integration target; E cache/temp; no cleanup; new source invalidates historical current-head claims'])
def save():
 p=out/'exit.pending.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(p,out/'exit.json')
start=time.monotonic();save()
try:
 with (out/'link.stdout.jsonl').open('wb') as stdout,(out/'link.stderr.log').open('wb') as stderr:
  child=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);report['pid']=child.pid;save();code=child.wait()
 report['linkExitCode']=code;assert code==0,('link',code)
 messages=[json.loads(line) for line in (out/'link.stdout.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
 artifacts={m['target']['name']:dict(path=m['executable'],sha256=sha(Path(m['executable']))) for m in messages if m.get('reason')=='compiler-artifact' and m.get('executable') and m['target']['name'] in ['chroma_key_sample','professional_key','professional_screen_photo']}
 assert set(artifacts)=={'chroma_key_sample','professional_key','professional_screen_photo'},artifacts
 assert identity()==source
 report.update(status='executing',executables=artifacts);save()
 for name,count in [('chroma_key_sample',1),('professional_key',2),('professional_screen_photo',1)]:
  exe=Path(artifacts[name]['path']);assert sha(exe)==artifacts[name]['sha256']
  invocation=[str(exe),'--test-threads=1','--nocapture'];began=time.monotonic()
  with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
   child=subprocess.Popen(invocation,cwd=work,env=env,stdout=stdout,stderr=stderr);report['pid']=child.pid;save();code=child.wait()
  row=dict(target=name,command=invocation,exitCode=code,elapsedSeconds=time.monotonic()-began);report['executions'].append(row);save()
  assert code==0,(name,code)
  text=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
  assert re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text,re.M)==[('ok',str(count),'0','0','0','0')],name
  assert sha(exe)==artifacts[name]['sha256']
 report.update(status='selected_native_targets_passed_visual_review_pending',passed=4,failed=0,ignored=0,filtered=0,sourceUnchanged=identity()==source)
 assert report['sourceUnchanged']
except BaseException:
 report.update(status='failed_original_outputs_retained',traceback=traceback.format_exc());raise
finally:
 report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-start,freeBytesAfter=shutil.disk_usage(root).free);save()
print(json.dumps({k:v for k,v in report.items() if k!='source'}))
