"""Read-only spatial residual audit of frozen outputs, without video/CV work."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, math, statistics, zipfile

BASE=Path('E:/Dev/aem/artifacts/pr-queue')
OUT=BASE/'tracking88-extent-residual-audit-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def multiply(a,b):return [[sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
def project(h,p):
    q=[row[0]*p[0]+row[1]*p[1]+row[2] for row in h]
    assert all(map(math.isfinite,q)) and abs(q[2])>1e-10
    return [q[0]/q[2],q[1]/q[2]]
def normalize(points):
    center=[statistics.mean(p[k] for p in points) for k in range(2)]
    distance=statistics.mean(math.dist(p,center) for p in points);assert distance>1e-9
    s=math.sqrt(2)/distance
    transform=[[s,0,-s*center[0]],[0,s,-s*center[1]],[0,0,1]]
    inverse=[[1/s,0,center[0]],[0,1/s,center[1]],[0,0,1]]
    return [project(transform,p) for p in points],transform,inverse
def fit(source,dest):
    a,ts,_=normalize(source);b,_,itd=normalize(dest);rows=[]
    for (x,y),(u,v) in zip(a,b):
        rows += [[x,y,1,0,0,0,-u*x,-u*y,u],[0,0,0,x,y,1,-v*x,-v*y,v]]
    for col in range(8):
        pivot=max(range(col,8),key=lambda k:abs(rows[k][col]));assert abs(rows[pivot][col])>1e-10
        rows[col],rows[pivot]=rows[pivot],rows[col]
        s=rows[col][col];rows[col]=[v/s for v in rows[col]]
        for k in range(8):
            if k!=col:
                s=rows[k][col];rows[k]=[v-s*w for v,w in zip(rows[k],rows[col])]
    values=[row[8] for row in rows]+[1]
    h=multiply(multiply(itd,[values[k:k+3] for k in (0,3,6)]),ts)
    assert max(math.dist(project(h,p),q) for p,q in zip(source,dest))<1e-6
    return h
def stats(v):return dict(count=len(v),minimum=min(v),median=statistics.median(v),maximum=max(v),rms=math.sqrt(statistics.mean(x*x for x in v)))

# Independent authored projective controls, including probes not used in fitting.
source=[[20.,30.],[620.,20.],[610.,450.],[25.,460.]]
probes=[[0.,0.],[160.,180.],[500.,390.],[320.,240.],[700.,520.]]
for h in ([[1.,0.,31.],[0.,1.,-7.],[0.,0.,1.]],[[.8,.13,35.],[-.11,1.04,62.],[.00019,-.00027,1.]]):
    estimated=fit(source,[project(h,p) for p in source])
    assert max(math.dist(project(h,p),project(estimated,p)) for p in probes)<1e-7

previous=json.loads((BASE/'tracking88-common-failure-audit-v1/receipt.json').read_text(encoding='utf-8'))
truth=BASE/'tracking88-real-planar-acquisition-v1/phone-gt.zip';assert sha(truth)==previous['annotation_sha256']
with zipfile.ZipFile(truth) as z:
    names=sorted(p.filename for p in z.infolist() if not p.is_dir())
    assert names==[f'img_{k:05d}.txt' for k in range(200,2500)]
    quads=[]
    for name in names:
        assert z.getinfo(name).file_size<=1024
        values=list(map(float,z.read(name).decode('ascii').split()));assert len(values)==8 and all(map(math.isfinite,values))
        quads.append([[values[4+k]-1,values[k]-1] for k in range(4)])
variants=[('original','tracking88-photographed-prototype-v6'),('persistent-descriptors','tracking88-photographed-identity-v1'),('manual-photometric-support','tracking88-photographed-manual-support-v1')]
report=dict(status='retained_extent_residuals_recomputed_not_tracker_acceptance',observed_utc=datetime.now(timezone.utc).isoformat(),annotation_sha256=sha(truth),audit_source_sha256=sha(Path(__file__)),variants=[],limits=[
    'No video decoding, inference, CV import, tracking rerun, threshold tuning or production source edits',
    'ROI probe reference is interpolated from the four annotations, not independently measured interior ground truth',
    'Descriptive spatial residuals cannot establish feature correspondences, model uncertainty or root cause',
    'All original915/890/836 automatic visible observations and original15px corner gate retained',
    'No third-party annotations, per-frame outputs, video, original requests or photographs redistributed'])
for variant,folder in variants:
    root=BASE/folder;request=json.loads((root/'periodic-manual-200.request.json').read_text(encoding='utf-8'))
    x,y,w,h=next(t['roi'] for t in request['tracks'] if t['kind']=='plane')
    probes=[[x,y],[x+w,y],[x+w,y+h],[x,y+h],[x+w/2,y+h/2]]
    path=root/'periodic-manual-200/tracks.mstrack';pinned=next(v for v in previous['variants'] if v['name']==variant)
    assert sha(path)==pinned['raw_output_sha256']
    data=json.loads(path.read_text(encoding='utf-8'));samples=next(t for t in data['tracks'] if t['kind']=='plane')['samples']
    rows=[]
    for k,s in enumerate(samples):
        assert s['source_index']==k
        if k==0 or s['manual_correction'] or s['visibility']!='visible':continue
        gt=fit(quads[0],quads[k]);actual=s['observation']['matrix']
        edge=max(math.dist(project(actual,p),q) for p,q in zip(quads[0],quads[k]))
        roi=max(math.dist(project(actual,p),project(gt,p)) for p in probes)
        rows.append((k,edge,roi))
    bad=[r for r in rows if r[1]>15]
    assert len(rows)==pinned['automatic_visible'] and [r[0] for r in bad]==pinned['bad_source_indices']
    assert abs(max(r[1] for r in rows)-pinned['maximum_error'])<1e-9
    report['variants'].append(dict(name=variant,output_sha256=sha(path),roi=[x,y,w,h],automatic_visible=len(rows),corner_errors=stats([r[1] for r in rows]),roi_probe_errors=stats([r[2] for r in rows]),bad_corner_errors=stats([r[1] for r in bad]),bad_roi_probe_errors=stats([r[2] for r in bad]),bad_edges_with_roi_at_most_3=sum(r[2]<=3 for r in bad),bad_edges_with_roi_at_most_15=sum(r[2]<=15 for r in bad),bad_edges_with_roi_over_15=sum(r[2]>15 for r in bad),bad_edge_to_roi_ratios=stats([r[1]/max(r[2],1e-12) for r in bad])))
OUT.mkdir(exist_ok=False)
(OUT/'audit.py').write_bytes(Path(__file__).read_bytes())
(OUT/'receipt.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
