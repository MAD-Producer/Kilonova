from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-import88'
helper = root / '.tools/issue-closure-review'
previous_dir = root / 'artifacts/pr-queue/tracking88-lens-clock-current-v1'
out = root / 'artifacts/pr-queue/tracking88-lens-clock-current-v2'
report = json.loads((out / 'exit.json').read_text(encoding='utf-8'))
previous = json.loads((previous_dir / 'exit.json').read_text(encoding='utf-8'))
assert previous['status'] == 'failed' and previous['source'] == report['source']
assert previous['steps'][:2] == report['steps'][:2]
assert previous['steps'][-1]['name'] == 'surface' and not previous['steps'][-1]['summaries']
assert report['status'] == 'latest_main_lens_video_clocks_prefetch_and_native_surface_passed'
assert report['sourceUnchanged'] and all(step['exitCode'] == 0 for step in report['steps'])
sha = lambda content: hashlib.sha256(content).hexdigest()
assert all(sha((work / path).read_bytes()) == digest for path, digest in report['source'].items())
git = lambda *args: subprocess.check_output(['git', *args], cwd=work)
assert not git('diff', '--name-only', '--diff-filter=U')
assert not git('diff', '--name-only', report['maintainedMain'], '--', 'desktop/app/src/panels')
tree = git('write-tree').decode().strip()
unchanged = {}
for crate in ['motion-model', 'motion-core', 'motion-render']:
    path = f'crates/{crate}'
    expected = git('rev-parse', '18579d81:' + path).decode().strip()
    current = git('rev-parse', tree + ':' + path).decode().strip()
    assert current == expected, path
    unchanged[path] = current
counts = {}
for step in report['steps']:
    rows = step['summaries']
    assert rows and all(row[0] == 'ok' and int(row[2]) == 0 for row in rows)
    counts[step['name']] = dict(passed=sum(int(row[1]) for row in rows), failed=0,
        ignored=sum(int(row[3]) for row in rows), summaries=len(rows), filtered=sum(int(row[5]) for row in rows))
for directory in ['surface-camera', 'surface-bindings']:
    assert json.loads((out / directory / 'child-process.json').read_text(encoding='utf-8'))
    assert json.loads((out / directory / 'report.json').read_text(encoding='utf-8'))
prefetch = json.loads((out / 'prefetch.json').read_text(encoding='utf-8'))
log = (out / 'prefetch-log/motion-studio.log').read_text(encoding='utf-8')
stderr = (out / 'prefetch-log/stderr.log').read_text(encoding='utf-8')
stdout = (out / 'prefetch-log/stdout.log').read_text(encoding='utf-8')
assert sum('site=video_prefetch_plan ' in line and ' ERROR ' in line and 'count=60 ' in line for line in log.splitlines()) == 2
assert stderr.count('site=video_prefetch_plan ') == 2 and 'site=video_prefetch_plan ' not in stdout
source = {}
for path in (out / 'source').rglob('*.rs'):
    relative = path.relative_to(out / 'source').as_posix()
    current = (work / relative).read_bytes()
    staged = git('show', ':' + relative)
    assert current == path.read_bytes() and staged == current.replace(b'\r\n', b'\n'), relative
    source[relative] = dict(rawSha256=sha(current), gitLfSha256=sha(staged))
members = {'publisher.py': Path(__file__).read_bytes()}
for directory in [previous_dir, out]:
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in {'.py', '.rs', '.json', '.log', '.png'}:
            members[directory.name + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
archive = work / 'engineering/validation/data/tracking88-lens-clock-current-v1.zip'
assert not archive.exists() and not archive.with_suffix('.json').exists()
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, content in sorted(members.items()):
        zipped.writestr(name, content)
with zipfile.ZipFile(archive) as zipped:
    assert set(zipped.namelist()) == set(members)
    for name, content in members.items():
        assert zipped.read(name) == content, name
receipt = dict(status=report['status'], head=report['head'], integratedParents=report['integratedParents'],
    maintainedMain=report['maintainedMain'], counts=counts, source=source, unchangedCrateTreesFrom18579d81=unchanged,
    rayOracle=report['rayOracle'], prefetch=prefetch, recoveryElapsedSeconds=report['elapsedSeconds'], steps=report['steps'],
    originalAttempt=dict(status=previous['status'], failure=previous['failure'], steps=previous['steps'], elapsedSeconds=previous['elapsedSeconds']),
    compilerEvents=json.loads((previous_dir / 'compiler-events.json').read_text(encoding='utf-8-sig')),
    limits=['Selected complete renderer targets and complete host library, not full desktop/workspace regression',
        'Current Surface/footage/prefetch controls do not qualify every codec/lens/binding/clock combination',
        'Prior model/core full results are historical on identical crate trees, not newly rerun here',
        'Final-head cross-platform CI, photographed tracking quality and full #88/3D route remain incomplete',
        'Android is retired and excluded'],
    archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
        members={name: dict(bytes=len(content), sha256=sha(content)) for name, content in sorted(members.items())}))
archive.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
rows = '\n'.join(f"- {name}: {count['passed']} passed, {count['failed']} failed, {count['ignored']} ignored; {count['filtered']} filtered" for name, count in counts.items())
maximum = max(row['maximumError'] for row in report['rayOracle'])
total = sum(count['passed'] for count in counts.values())
document = f'''# #88 nonlinear video, layer clocks and current-main prefetch

PR #586 synchronizes parent #584 `{report['integratedParents'][0]}` and freshly
fetched main `{report['maintainedMain']}` in one conflict-free merge. This includes
main's newly merged mapped-video-prefetch fix. No new product implementation,
test assertion, UI, dependency or asset is authored by this synchronization.

The complete model, core and render crate trees exactly match the earlier
layer-time integration `18579d81`; their Git tree IDs are recorded. That earlier
model/core full result stays historical. The host now includes main's prefetch
changes and is actually revalidated below, alongside the combined desktop paths.

## Executed gates on frozen current source

{rows}

Seven complete renderer targets cover nonlinear tracking lenses, RGBA/YUV,
queued-video lifetimes/instances/allocation, model layers and mapped nested time.
All eight independently ray-checked queued-video outputs retain the original
stable-pixel/edge policy and two-byte threshold; the measured maximum is {maximum}.

The two real Windows Surface controls keep a native window/device attached while
checking camera/video and fixed-plate point/plane/nonlinear-lens replacement,
committed-front pixels, actual Present, invalidation/reuse, undo/redo and reopen.
The four-case original-video clock control separately compares stretch, reverse,
linear source remap and hold to native references through replacement/relink and
history. These are separate bounded controls, not every possible combination.

Both current-main prefetch controls execute through the real FFmpeg decoder.
They compare CFR/VFR pixels under authored clocks and check actual planning
failure admission, continued required-video progress, suppression and recovery.
With MOTION_LOG unset, the injected planning failure logs Error at count 60,
suppresses repeats, resets on recovery, and logs once at the next count 60. Both
Error records appear in file and stderr, with neither in child stdout. The
existing test assertions are retained; 60 events are not labeled a duration.

The [receipt](data/tracking88-lens-clock-current-v1.json) and
[read-back verified archive](data/tracking88-lens-clock-current-v1.zip) retain
all commands, source identities, relevant staged-LF snapshots, native images,
independent oracle reports, process exits and original logs. Source remained
unchanged throughout execution. No panel differs from maintained main.

## Retained compiler failure and scoped recovery

The first invocation completed the seven renderer targets and complete host
library, then rustc exited with 0xc0000005 while compiling motion-render for the
desktop feature set. No Surface test executed in that failed step. Windows
Application Event 1000 names rustc_driver-e41b336de1bfe42c.dll, offset 0x180bd40,
with the matching compiler failure. The original failure, source hashes and event
remain archived. This identifies the compiler phase, not the underlying cause.

The next invocation checks identical source hashes, retains the already-passed
renderer/host steps without repeating them, and reruns only the unexecuted
Surface, prefetch and footage-clock groups. No Rust source, flags, assertion or
physical/image threshold is changed. The aggregate above therefore spans the
two source-identical invocations; it is not a single all-green original run or
a claim that the compiler or earlier product access violations are repaired.

## Remaining acceptance

This result totals {total} passing tests in the specified commands. It is not a
fresh complete desktop package or maintained-workspace regression. The previous
full desktop result and old-head green CI remain historical. Final-head CI,
earlier unexplained native crashes, optional photographed tracker quality,
prerequisites #85/#86 and full #88/3D-route acceptance remain separate work.
The hidden Surface does not establish physical display scanout. Android remains
retired and excluded. No PR merge or issue closure is implied.
'''
(work / 'engineering/validation/tracking88-lens-clock-current.md').write_text(document, encoding='utf-8')
for relative, addition in [
    ('tracking88-native-video-lens-current.md', '\n\n## Current-main and layer-time synchronization\n\nThe [fresh combined-source record](tracking88-lens-clock-current.md) covers the\nlatest parent/main merge, mapped prefetch, actual Surface and independent lens\noracles. Earlier results above retain their original source and scope.\n'),
    ('tracking88-acceptance-map-current.md', '\n\n## Current-main prefetch and nonlinear-video synchronization\n\nThe [latest combined-source record](tracking88-lens-clock-current.md) adds freshly\nexecuted complete host-library and seven renderer-target gates, actual Surface,\noriginal-video clock and current-main prefetch controls. It explicitly includes\nmain e2347558. Historical full model/core results refer to identical crate trees;\nno new full desktop/workspace or final-head CI pass is claimed.\n')]:
    path = work / 'engineering/validation' / relative
    text = path.read_text(encoding='utf-8')
    assert addition.strip().splitlines()[0] not in text
    path.write_text(text + addition, encoding='utf-8')
body = f'''普通 3D 视频在启用径向或切向畸变的相机下会被 `shared_geometry` 拒绝。本 PR 补齐受支持的简单视频平面路径，并保留几何命令已经引用的视频纹理版本，避免后续上传覆盖尚未提交的输入。

采样校验实际纹理视图格式，同时保留分配租约及既有限制。效果、蒙版、时间采样、特殊混合等边界未扩大。

基于 #584；本轮同时同步父提交 `{report['integratedParents'][0][:8]}` 和最新 main `{report['maintainedMain'][:8]}`，纳入图层时钟及新合入的视频预取修复。

当前冻结整合源码验证：

- 七个完整渲染集成目标 {counts['render']['passed']} 项通过；RGBA/YUV、两种裁剪旋转及正负畸变的八张输出，与独立射线参考的最大通道误差为 {maximum}
- 完整 host 库 {counts['host']['passed']} 项通过，包含新基线的映射预取控制
- 实际 Windows Surface 2 项通过；固定原片与 PTS 替换点、平面、非线性相机绑定，检查重绘、缓存复用和撤销重开
- 实际 CFR/VFR 预取与规划故障 2 项通过；四种原片时钟组合 1 项通过
- 默认日志的阈值、抑制、恢复重置及 Error 文件/stderr/stdout 隔离通过，原始源码与画面归档已回读校验

首次验证在渲染与 host 通过后遇到 rustc 编译器原生访问冲突，窗口测试尚未执行；Windows 事件定位到 rustc_driver DLL。随后在完全相同源码和参数下只重跑未执行的原生组，保留全部失败记录，不宣称崩溃已修复。

以上共 {total} 项通过，不包含被过滤测试。模型、核心与渲染完整子树与已验证的 `18579d81` 相同；本轮未重跑模型/核心全部测试，也未完成 desktop/workspace 全量回归。最新提交跨平台 CI 待完成。

[最新整合验收](https://github.com/MAD-Producer/Kilonova/blob/fix/88-native-video-lens/engineering/validation/tracking88-lens-clock-current.md)、[功能及原始失败证据](https://github.com/MAD-Producer/Kilonova/blob/fix/88-native-video-lens/engineering/validation/tracking88-native-video-lens-current.md)。

未修改 panels、交互、样式或既有断言，未引入依赖与第三方资产。旧原生崩溃根因、实拍跟踪质量和完整 #88/3D 路线仍未完成；Android 停维，不在验收范围。

关联 #88
'''
(helper / 'tracking88-lens-clock-current-pr-body.md').write_text(body, encoding='utf-8')
(helper / 'tracking88-lens-clock-current-commit.txt').write_text('''test(tracking): 对齐最新预取基线并验证畸变视频与图层时钟

- 整合父分支事务协议与主分支映射预取修复
- 复核独立射线参考及实际窗口历史缓存
- 验证原片时钟和默认日志的预取失败恢复
- 归档冻结源码回归结果与剩余验收边界
''', encoding='utf-8')
print(json.dumps(dict(status=receipt['status'], counts=counts, totalPassed=total,
    archiveBytes=archive.stat().st_size, members=len(members)), indent=2), flush=True)
