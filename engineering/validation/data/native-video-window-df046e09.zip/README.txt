Measured native revision: df046e09ae2ca51298bbfc4235f60f5a518bdaa7
Validation revision: acf1c3b222a2b7908ae4c32361b76109244c6316
Native Release build/test actually exited0/0. Original collector failed a secondary JSON copy; its failure is preserved.
Strict independent validation uses original host report bytes; no frame/pixel/GPU equality was relaxed.
144 completed compositions,144 root GPU samples, independently decoded one/four-file center pixels.
The original failed full render/host suite is included. Later diagnostic/delivery suites are separate, not waived.
Video files,12 full decoded RGBA references, external FFmpeg runtime and retained native executables are not embedded; original hashes and command receipts remain.
Source bundle requires base cc3d9bdccf997691b899825321611091d241103b from repository history.
Archived absolute paths describe the original environment. Reproduction creates a fresh output and source-bound receipt on the chosen machine.
No physical VRAM, complete GPU/readback coverage, display scanout FPS or optimization gain is claimed. Android validation is explicitly outside the user-approved scope.
