$ErrorActionPreference = 'Stop'
Set-Location 'E:/Dev/aem/.worktrees/shared-menu-navigation'
. E:/Dev/aem/artifacts/multiple-camera-layers/env.ps1
$env:CARGO_TARGET_DIR = 'E:/Dev/aem/target/host-error-contract-verified'
$env:CARGO_BUILD_JOBS = '1'
$outputRoot = 'E:/Dev/aem/artifacts/pr-ci-followups/menu-cascade-correction'
$env:MOTION_SHARED_MENU_EVIDENCE = Join-Path $outputRoot 'native'
$source = (& git rev-parse HEAD).Trim()
if (-not $source.StartsWith('dbaea61c')) { throw "unexpected source $source" }
$results = [System.Collections.Generic.List[object]]::new()
function Assert-Source {
    if ((& git rev-parse HEAD).Trim() -ne $source) { throw 'source HEAD changed' }
    & git diff --quiet HEAD -- desktop
    if ($LASTEXITCODE -ne 0) { throw 'dirty desktop source' }
}
function Run-Check([string]$name, [string[]]$arguments) {
    Assert-Source
    Write-Output "start $name source=$source"
    $timer = [Diagnostics.Stopwatch]::StartNew()
    & cargo @arguments *> (Join-Path $outputRoot "$name.log")
    $status = $LASTEXITCODE
    Assert-Source
    $results.Add(@{ name=$name; source=$source; arguments=$arguments; exit=$status; elapsed_ms=$timer.ElapsedMilliseconds })
    $results | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 (Join-Path $outputRoot 'results.json')
    Write-Output "done $name exit=$status elapsed=$($timer.Elapsed)"
    if ($status -ne 0) { throw "$name failed; preserve its log" }
}
Run-Check 'ui-lib' @('test','-p','motion-ui','--lib','--locked','--offline')
$testArgs = @('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline')
Run-Check 'shared-menu' ($testArgs + @('shared_menu','--','--test-threads=1'))
Run-Check 'layer-actions' ($testArgs + @('panels::layer_actions::tests','--','--test-threads=1'))
Run-Check 'effect-menu' ($testArgs + @('panels::effect_controls::removal_tests','--','--test-threads=1'))
Run-Check 'recent-effects' ($testArgs + @('recent_effect_menu_tests','--','--test-threads=1'))
Run-Check 'native-menu' ($testArgs + @('panels::layer_actions::tests::shared_native::shared_menu_native_root_child_shortcuts_checks_and_small_window_owners','--','--exact','--ignored','--nocapture','--test-threads=1'))
Assert-Source
Write-Output "all checks passed source=$source"
