from pathlib import Path
from hashlib import sha256
import json
import subprocess
import zipfile
from PIL import Image

repo = Path('E:/Dev/aem/.worktrees/shared-menu-navigation')
run = Path('E:/Dev/aem/artifacts/pr-ci-followups/menu-cascade-correction')
destination = repo / 'engineering/validation/menu-cascade-placement'
destination.mkdir(parents=True, exist_ok=True)
source = 'dbaea61cef7d00410634a44f7e2c99a2207c7b7b'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == source
subprocess.run(['git', 'diff', '--quiet', 'HEAD', '--', 'desktop'], cwd=repo, check=True)
results = json.loads((run / 'results.json').read_text(encoding='utf-8-sig'))
assert len(results) == 6 and all(r['exit'] == 0 and r['source'] == source for r in results)
images = sorted((run / 'native').glob('*.png'))
assert len(images) == 38, len(images)
provenance = []
for original, name, crop in [
    ('shared-menu-zh-main-1x-hover-root.png', 'zh-before-hover.png', (10, 740, 500, 985)),
    ('shared-menu-zh-main-1x-hover-child.png', 'zh-hover-right.png', (10, 740, 500, 985)),
    ('shared-menu-zh-main-1x-child.png', 'zh-right-edge-left.png', (1120, 740, 1600, 985)),
    ('shared-menu-zh-floating-route-1x-child.png', 'zh-compact-float.png', None),
]:
    original_path = run / 'native' / original
    output = destination / name
    image = Image.open(original_path)
    (image.crop(crop) if crop else image).save(output)
    provenance.append({'source': original, 'source_sha256': sha256(original_path.read_bytes()).hexdigest(), 'crop': crop, 'result': name, 'sha256': sha256(output.read_bytes()).hexdigest()})
(destination / 'screenshots.json').write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

files = {}
for path in sorted(run.rglob('*')):
    if path.is_file() and path.suffix not in ('.zip', '.exe'):
        label = path.relative_to(run).as_posix()
        if label == 'ui-menu.log':
            label = 'superseded-iteration/ui-menu.log'
        files['run/' + label] = path.read_bytes()
for name in ['desktop/ui/src/widgets/menu.rs', 'desktop/ui/src/widgets/menu/tests.rs', 'desktop/app/src/panels/layer_actions.rs', 'desktop/app/src/panels/layer_actions/tests/shared_native.rs', 'desktop/app/src/panels/menus/navigation.rs', 'DESIGN.md']:
    files['source/' + name] = (repo / name).read_bytes()
files['source/identity.txt'] = (source + '\n').encode()
for path in destination.iterdir():
    if path.is_file():
        files['screenshots/' + path.name] = path.read_bytes()
manifest = {name: sha256(data).hexdigest() for name, data in sorted(files.items())}
files['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
archive = repo / 'engineering/validation/data/menu-cascade-placement-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for name, data in sorted(files.items()):
        output.writestr(name, data)
with zipfile.ZipFile(archive) as verify:
    assert verify.testzip() is None
    for name, digest in manifest.items():
        assert sha256(verify.read(name)).hexdigest() == digest, name
summary = {'source': source, 'checks': results, 'png_count': len(images), 'archive_entries': len(files), 'archive_bytes': archive.stat().st_size, 'archive_sha256': sha256(archive.read_bytes()).hexdigest(), 'screenshots': provenance}
(repo / 'engineering/validation/menu-cascade-placement-results.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('checks','screenshots')}, indent=2))
