"""Validate the staged timecode-only library, preserving the unfinished port."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/frame-rate85-timecode-publish-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda data: hashlib.sha256(data).hexdigest()
modified = subprocess.check_output(['git', 'diff', '--name-only'], cwd=work).decode().splitlines()
ports = [path for path in modified if path.startswith('crates/motion-model/src/')]
backups = {path:(work / path).read_bytes() for path in ports}
for path, data in backups.items():
    destination = out / 'unfinished-port' / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
command = ['cargo', 'test', '-p', 'motion-model', '--test', 'frame_rate', '--test', 'timecode',
           '--locked', '--offline', '--', '--test-threads=1']
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), command=command,
    base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip(),
    stagedTree=subprocess.check_output(['git', 'write-tree'], cwd=work).decode().strip(),
    preservedPort={path:sha(data) for path,data in backups.items()},
    scope='Actual staged timecode-only library, excluding the unfinished rational project port; not UI integration')
save = lambda: (out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
started = time.monotonic()
save()
try:
    for path in ports:
        (work / path).write_bytes(subprocess.check_output(['git', 'show', ':' + path], cwd=work))
    report['testedLibrary'] = {path.relative_to(work).as_posix():sha(path.read_bytes())
        for path in (work / 'crates/motion-model/src').rglob('*.rs')}
    save()
    with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=work, env=os.environ.copy(), stdout=stdout, stderr=stderr)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    assert report['exitCode'] == 0, 'independent staged timecode gate failed'
    log = (out / 'stdout.log').read_text(encoding='utf-8')
    assert '7 passed; 0 failed; 0 ignored' in log and '5 passed; 0 failed; 0 ignored' in log
    assert all(sha((work / path).read_bytes()) == digest for path,digest in report['testedLibrary'].items())
    report['status'] = 'independent_timecode_and_existing_exact_clock_tests_passed_unfinished_port_excluded'
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    for path, data in backups.items():
        (work / path).write_bytes(data)
    report['portRestoredByteExactly'] = all((work / path).read_bytes() == data for path,data in backups.items())
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic()-started, 3))
    save()
    print(json.dumps({key:report.get(key) for key in ['status','exitCode','elapsedSeconds','portRestoredByteExactly','failure']}), flush=True)
