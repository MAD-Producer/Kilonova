"""Source-bound native foreground consumer controls; one Cargo owner."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/native-prerender-runtime'
OUT = ROOT / 'artifacts/pr-queue/prerender-consumer-v2'
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'controller.py')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()

def sources():
    paths = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {p: hashlib.sha256((WORK / p).read_bytes()).hexdigest() for p in paths if p and
            (p.endswith(('.rs', '.toml', '.wgsl', '.py', '.json', '.yml', '.yaml')) or p == 'Cargo.lock')}

assert not git('status', '--porcelain')
source = sources()
report = dict(head=git('rev-parse', 'HEAD'), source=source, status='running', steps=[])
prior = json.loads((ROOT / 'artifacts/pr-queue/prerender-coordinator-v3/accepted.json').read_text())
assert prior['status'] == 'accepted' and prior['sourceUnchanged']
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0',
           CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
host = ['cargo','test','-p','motion-host','--features','ai-depth','--locked','--offline','--lib']
render = ['cargo','test','-p','motion-render','--locked','--offline','--lib']
consumer = 'session::cached_preview_tests::actual_surface_uses_cached_pixels_and_rejects_stale_context_frame_profile_and_owner'
native = 'renderer::composition_frames::native::tests::all_four_native_completion_uploads_preserve_encoded_storage_hdr_negative_and_alpha'
steps = [
    ('desktop-check', ['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'], 0),
    ('native-copy', [*render,'renderer::composition_frames::','--','--test-threads=1'], None),
    ('native-copy-four-precision', [*render,native,'--','--ignored','--exact','--test-threads=1'], 1),
    ('window-consumer-four-precision', [*host,consumer,'--','--ignored','--exact','--test-threads=1'], 1),
    ('host-regression', ['cargo','test','-p','motion-host','--features','ai-depth','--locked','--offline','--','--test-threads=1'], None),
    ('render-regression', ['cargo','test','-p','motion-render','--locked','--offline','--','--test-threads=1'], None),
    ('worker', ['cargo','test','-p','motion-desktop-media','--features','ffmpeg,ai-depth','--locked','--offline','--lib','movie::prerender::worker::','--','--test-threads=1'], 6),
    ('provenance', ['python','tools/validate_provenance.py'], 0),
]
for name, args, expected in steps:
    print(json.dumps(dict(start=name)), flush=True)
    with (OUT / (name + '.stdout.log')).open('wb') as so, (OUT / (name + '.stderr.log')).open('wb') as se:
        code = subprocess.run(args, cwd=WORK, env=env, stdout=so, stderr=se).returncode
    stdout = (OUT / (name + '.stdout.log')).read_text(encoding='utf-8')
    counts = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored', stdout)
    row = dict(name=name, command=args, exitCode=code, counts=counts, sourceUnchanged=sources() == source,
               ignoredTests=re.findall(r'^test (\S+) \.\.\. ignored(?:, (.*))?$', stdout, re.M))
    report['steps'].append(row)
    (OUT / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], row
    if expected != 0:
        assert counts and all(int(f) == 0 for _, f, _ in counts), row
        passed = sum(int(p) for p, _, _ in counts)
        assert passed > 0 and (expected is None or expected == passed), row
        if expected == 1: assert all(int(i) == 0 for _, _, i in counts), row
report.update(status='accepted', sourceUnchanged=sources() == source, completedUtc=datetime.now(timezone.utc).isoformat(),
              scope='Actual same-owner native copy and real-window Session consumption of all four precisions. Engine scheduling, exposure/Auto/observer/reduced profiles, foreground P95, default logger block proof and combined full desktop/cross-platform regression remain pending. Capability stays disabled.')
(OUT / 'accepted.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True)), flush=True)

