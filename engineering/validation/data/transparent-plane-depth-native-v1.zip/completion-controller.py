"""Commit source-bound alpha geometry acceptance and align the unchanged tree to main."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/transparent-plane-depth'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
gate = root / 'artifacts/pr-queue/transparent-plane-depth-native-v1'
accepted = json.loads((gate / 'accepted.json').read_text(encoding='utf-8'))
assert accepted['sourceUnchanged'] and all(sha(work / p) == h for p, h in accepted['source'].items())
assert all(s['exitCode'] == 0 and s['sourceUnchanged'] for s in accepted['steps'])
native = next(s for s in accepted['steps'] if s['name'] == 'native')
assert native['totals']['failed'] == 0 and native['totals']['ignored'] == 0 and native['targets'] == 13
old_base = 'aab06c709da17347e4c36d0bfe6dfba912240c62'
new_base = '5f0c7b1834a171c45f3127c9375f6eac4f6a8cec'
main = '21093ee76231b76bbeb53055689cae4858c51897'
git = lambda *args: subprocess.check_output(['git', *args], cwd=work).decode().strip()
assert git('rev-parse', 'HEAD') == old_base
assert git('rev-parse', old_base + '^{tree}') == git('rev-parse', new_base + '^{tree}')
assert git('rev-parse', 'origin/main') == main
out = root / 'artifacts/pr-queue/transparent-plane-depth-complete-v1'
out.mkdir(exist_ok=False)
archive = work / 'engineering/validation/data/transparent-plane-depth-native-v1.zip'
assert not archive.exists()
payload = {}
for name in ['transparent-plane-depth-red-v1', 'transparent-plane-depth-red-v2', 'transparent-plane-depth-control-v3', 'transparent-plane-depth-green-v1', 'transparent-plane-depth-green-v2', 'transparent-plane-depth-native-v1']:
    base = root / 'artifacts/pr-queue' / name
    for p in base.rglob('*'):
        if p.is_file():
            assert p.suffix not in ['.exe', '.dll', '.pyc']
            payload[name + '/' + p.relative_to(base).as_posix()] = p.read_bytes()
payload['completion-controller.py'] = Path(__file__).read_bytes()
payload['tracked-source.patch'] = subprocess.check_output(['git', 'diff', '--binary'], cwd=work)
payload['textured-plane-main-alignment-v1.json'] = (root / 'artifacts/pr-queue/textured-plane-main-alignment-v1.json').read_bytes()
manifest = {p: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for p, data in payload.items()}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p, data in payload.items(): z.writestr(p, data)
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(manifest) + 1 and z.testzip() is None
    for p, info in manifest.items():
        data = z.read(p)
        assert len(data) == info['bytes'] and hashlib.sha256(data).hexdigest() == info['sha256']
digest = sha(archive)
doc = work / 'engineering/validation/transparent-plane-depth-current.md'
assert not doc.exists()
passed = native['totals']['passed']
doc.write_text(f'''# Plane alpha coverage in native shared scene depth

## Implemented behavior

The accepted opaque-image checkpoint is extended with translucent solid/image
planes and layer opacity. Compatible meshes and planes use one camera and
fragment depth. Opaque geometry writes depth first; alpha geometry tests that
depth without writing it, and joins the existing global mesh primitive order.
Linear premultiplied color is blended once. A zero-alpha image texel preserves
visible rear geometry. Equal-depth opaque plane/mesh ties preserve the earlier
mesh winner. Pure-plane compositions retain their original BSP path.

The source revision ownership, admission and immutable vertex contracts from
the opaque-image increment apply to alpha images too. Solid vertices still cost
192 bytes per plane, images 240 bytes. The bounded pipeline cache now has at
most 32 keys: four formats, two sample counts, two source kinds and two alpha
modes. Shader variants are compiled only on cold keys and keep the existing
Info start/default diagnostics. No healthy per-frame file IO is introduced.

## Actual controls and acceptance

The first test draft fails compilation on an unspecified bytemuck output type;
an explicit f32-to-u8 type resolves it without changing expected behavior.
The unchanged parent then fails all three actual GPU regressions: solid alpha
and image alpha cover a nearer mesh, and alpha planes bypass mesh global order.
The first native implementation passes both occlusion tests. Its idealized
Float32 endpoint assertion fails because the actual GPU sRGB material sample
differs from one by an ULP. The independent reference is corrected to render
each isolated source and calculate linear source-over on CPU. Byte equality
remains exact, with no new or relaxed tolerance. The exact corrected tests run
again on the unchanged parent in an isolated control tree: all three still
fail for their intended causes. They then all pass on the new implementation.
All original test histories are retained.

Final source-bound native acceptance has **{passed} passed, 0 failed, 0 ignored**
across 13 targets, plus desktop FFmpeg/AI-depth compilation, provenance and
panel-style checks. Eight new tests exercise real saved/reopened assets with
removed source files, both authored orders, all six permutations of three
alpha sources, an independent CPU source-over oracle in Float32, solid/image
coverage in four precisions at 1x/4x, actual PNG holes with nearer/rear geometry,
layer opacity, reverse queued source revisions and abandonment, opaque coplanar
ties, exact one-byte-short admission, invalid opacity refusal, unchanged output
after failure and successful recovery. Existing renderer, model, scene, mask,
matte, effect, composition, exposure and nested tests remain unchanged.
Overlapping previous checkpoint counts are not added to this total.

## Remaining scope

Transparent primitives still use their camera-forward center for global order.
This is not exact intersecting translucent-fragment ordering or OIT. Mixed
intersecting alpha geometry and the preservation/extension of BSP semantics
remain explicit work, rather than a completed transparency claim. Effects,
masks, mattes, nested compositions, nonnormal blends and incompatible sampling
retain their existing receiver boundaries. Imported-camera project selection
and tracks, persisted current-frame calibration/reprojection and DOF remain
open with #74/#87. This is not full-workspace, GUI or cross-platform acceptance.
The older opaque checkpoint's alpha-fallback description is historical and is
superseded by this increment; its source-bound evidence remains unchanged.

No UI/panel/style edits, dependencies or third-party assets are added. Android
is retired and excluded. Pre-existing assertions, tolerances, budgets and
timeouts are unchanged. Neither #74 nor #87 is closed by this checkpoint.

## Source alignment and evidence

PR528 merged at `{main}` after required CI passed, with its actual Chinese
squash title verified. Its tree is identical to the original published head.
The opaque-image commit is reparented to that main without any tree change.
After this acceptance, the alpha increment is reparented onto that identical
opaque-image tree; source/test hashes and the complete final tree are checked.

[Source-bound failures, independent control and native acceptance](data/transparent-plane-depth-native-v1.zip):
SHA-256 `{digest}`, {archive.stat().st_size} bytes, {len(manifest) + 1} entries.
Every entry is read back and hash-verified. Only changed source is copied;
full source hashes identify the baseline. Executables and shared libraries are
excluded. Reparenting receipts retain old/new heads without claiming a rerun.
''', encoding='utf-8', newline='\n')
older = work / 'engineering/validation/textured-plane-depth-current.md'
old_doc = older.read_text(encoding='utf-8')
note = '\nThis is the historical opaque-only checkpoint. Its alpha-fallback boundary is\nsuperseded by [shared alpha depth](transparent-plane-depth-current.md); the\noriginal source-bound evidence below remains unchanged.\n'
assert 'historical opaque-only checkpoint' not in old_doc
older.write_text(old_doc.replace('\n', '\n' + note, 1), encoding='utf-8', newline='\n')
assert not any(p.startswith('desktop/app/src/panels/') for p in accepted['changedSource'])
subprocess.run(['git', 'diff', '--check'], cwd=work, check=True)
subprocess.run(['git', 'diff', '--stat'], cwd=work, check=True)
paths = accepted['changedSource'] + [doc.relative_to(work).as_posix(), archive.relative_to(work).as_posix(), older.relative_to(work).as_posix()]
subprocess.run(['git', 'add', '--', *paths], cwd=work, check=True)
message = out / 'commit-message.txt'
message.write_text('feat(render): 接入透明平面与模型的共享深度和混合排序\n\n- 统一透明实色与图片平面的深度测试和预乘混合\n- 保留待提交图片版本与不透明共面遮挡规则\n- 验证四种精度及透明孔洞和预算拒绝恢复\n- 归档独立失败对照与原生验收并记录相交透明的剩余范围\n\nRefs #87\n', encoding='utf-8', newline='\n')
subprocess.run(['git', 'commit', '-F', str(message)], cwd=work, check=True)
original_head = git('rev-parse', 'HEAD')
original_tree = git('rev-parse', 'HEAD^{tree}')
subprocess.run(['git', 'rebase', '--onto', new_base, old_base], cwd=work, check=True)
assert git('rev-parse', 'HEAD^{tree}') == original_tree
assert not git('status', '--porcelain')
assert all(sha(work / p) == h for p, h in accepted['source'].items())
subprocess.run(['git', 'show', '--stat', '--oneline', 'HEAD'], cwd=work, check=True)
result = dict(completedUtc=datetime.now(timezone.utc).isoformat(), branch='feat/87-transparent-plane-depth', originalHead=original_head,
    head=git('rev-parse', 'HEAD'), main=main, parent=new_base, exactEntireTreeUnchangedOnRebase=True,
    totals=native['totals'], archiveSha256=digest, archiveBytes=archive.stat().st_size, entries=len(manifest) + 1, clean=True, published=False)
(out / 'completed.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result), flush=True)
