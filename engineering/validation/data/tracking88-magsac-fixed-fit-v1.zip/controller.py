"""One declared fit-only estimator; no label input, method search or adoption."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import logging
import os
import subprocess
import sys
import traceback

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/planar-tracker88'
OUT = ART / 'tracking88-magsac-fixed-fit-v1'
BASE = ART / 'tracking88-mousepad-flow-phases-v1'
CP = ART / 'depth75-resume-current.json'
HEAD = 'a6b060ccbba1d5ee6a93910441127ceb48f95f6a'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))


def write(path, value):
    path.write_bytes((json.dumps(value, indent=2, allow_nan=False) + '\n').encode())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK, text=True).strip()


state = read(CP)
v = state['versionedCache75']
assert v['activeController'] is None and not v['ownHeavyWorkloads']
assert git('rev-parse', 'HEAD') == HEAD and not git('status', '--porcelain')
assert read(BASE / 'session-consumed.json')['original_tool_result_consumed']
INPUT = BASE / 'blind-correspondences.npz'
assert sha(INPUT) == '2f063ca72eb7b7de9fbff341619cd17dc7238dcb9614f4acb536e91073ef2819'
hashes = {name: sha(WORK / name) for name in git('ls-files').splitlines()}
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
os.environ.update(TEMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'),
                  TMP=str(ROOT / 'target/depth-wgsl-cache75-contract/tmp'), PYTHONDONTWRITEBYTECODE='1')
r = dict(status='running', head=HEAD, source_sha256=hashes,
         started_utc=datetime.now(timezone.utc).isoformat(), in_flight=None,
         input_sha256=sha(INPUT), candidate_adopted=False,
         protocol=dict(method='USAC_MAGSAC', fit_calls=1, max_iterations=2000, confidence=.995,
                       ransac_threshold_px=1.5, exact_fit_points=146, heldout_points=46,
                       heldouts_excluded_from_fit=True, annotation_reads=False, parameter_search=False,
                       original_rejection_gates_preserved=True),
         reference='https://docs.opencv.org/4.13.0/de/d3e/tutorial_usac.html',
         limits=['Post-failure selected correspondences, not blind generalization or full video',
                 'Uses existing OpenCV implementation; no source or dependency copied/acquired',
                 'A good selected fit cannot qualify either original full photographed sequence',
                 'Reject without trying further methods/parameters if any original gate fails'])
logger = logging.getLogger('tracking88.magsac_fixed_fit')
logger.setLevel(logging.INFO)
sink = logging.FileHandler(OUT / 'observation.log', encoding='utf-8')
sink.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
console = logging.StreamHandler(sys.stderr)
console.setLevel(logging.ERROR)
logger.addHandler(sink)
logger.addHandler(console)
v.update(activeController=str(Path(__file__)), ownHeavyWorkloads=[dict(
    kind='one fixed fit-only estimator measurement', head=HEAD, sourceFrozen=True, output=str(OUT))])
write(CP, state)


def start(operation):
    r['in_flight'] = dict(operation=operation, utc=datetime.now(timezone.utc).isoformat())
    write(OUT / 'receipt.json', r)
    logger.info('start operation=%s', operation)
    sink.flush()


try:
    start('import_existing_runtime_and_sealed_correspondences')
    sys.path.insert(0, str(WORK / 'tools/tracking'))
    import plate_flow as flow
    import numpy as np
    versions = {name: importlib.metadata.version(name) for name in ('opencv-python-headless', 'numpy')}
    assert versions == {'opencv-python-headless': '5.0.0.93', 'numpy': '2.4.6'}
    r['runtime'] = versions
    flow.cv2.setNumThreads(1)
    flow.cv2.setRNGSeed(88)
    data = np.load(INPUT, allow_pickle=False)
    reference, points, heldout = data['reference'], data['anchored'], data['heldout']
    assert int((~heldout).sum()) == 146 and int(heldout.sum()) == 46
    assert r['protocol']['ransac_threshold_px'] == flow.LIMITS['planeFitPixels']
    start('single_declared_fit_without_heldouts_or_annotations')
    matrix, supplied_mask = flow.cv2.findHomography(reference[~heldout], points[~heldout],
        flow.cv2.USAC_MAGSAC, flow.LIMITS['planeFitPixels'], maxIters=2000, confidence=.995)
    if matrix is None or supplied_mask is None:
        r.update(status='fixed_candidate_refused_not_adopted', refusal='candidate returned no homography/mask')
    else:
        start('independent_unchanged_gates_after_fit')
        residuals = np.linalg.norm(flow.transform(matrix, reference) - points, axis=1)
        inliers = (residuals[~heldout] <= flow.LIMITS['planeFitPixels']).reshape(-1, 1)
        errors = residuals[heldout]
        r['measurements'] = dict(fitting_points=146, actual_inliers=int(inliers.sum()),
            actual_ratio=float(inliers.mean()), supplied_mask_inliers=int(supplied_mask.sum()),
            supplied_mask_matches_actual=bool(np.array_equal(supplied_mask.astype(bool), inliers)),
            heldout_points=46, heldout_rms_px=float(np.sqrt(np.mean(errors**2))),
            heldout_maximum_px=float(errors.max()))
        try:
            matrix = flow.plane_matrix(matrix, [200., 140., 340., 260.])
            flow.check_plane_residuals(inliers, errors)
            flow.check_plane_extrapolation(matrix, reference[heldout], points[heldout], [200., 140., 340., 260.])
        except ValueError as cause:
            r.update(status='fixed_candidate_refused_not_adopted', refusal=str(cause))
        else:
            r.update(status='selected_candidate_passed_original_gates_not_adopted', selected_gates_passed=True)
except BaseException:
    r.update(status='failed_original_outputs_retained', cause=traceback.format_exc())
    logger.error('operation=%s cause=%s', r['in_flight'], r['cause'][-8192:])
finally:
    r.update(in_flight=None, completed_utc=datetime.now(timezone.utc).isoformat(),
             source_unchanged=git('rev-parse', 'HEAD') == HEAD and not git('status', '--porcelain')
             and all(sha(WORK / name) == digest for name, digest in hashes.items()),
             input_unchanged=sha(INPUT) == r['input_sha256'])
    write(OUT / 'receipt.json', r)
    sink.close()
    print(json.dumps({k: r.get(k) for k in ('status', 'refusal', 'measurements', 'cause', 'source_unchanged')}))
raise SystemExit(0 if r['status'] in ('fixed_candidate_refused_not_adopted', 'selected_candidate_passed_original_gates_not_adopted')
                 and r['source_unchanged'] and r['input_unchanged'] else 1)
