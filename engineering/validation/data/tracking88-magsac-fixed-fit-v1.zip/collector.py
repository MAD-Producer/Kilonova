from pathlib import Path
import hashlib
import json
import zipfile

ART = Path('E:/Dev/aem/artifacts/pr-queue')
ROOT = ART / 'tracking88-magsac-fixed-fit-v1'
OUT = ART / 'tracking88-magsac-public-v1'
OUT.mkdir(exist_ok=False)
r = json.loads((ROOT / 'receipt.json').read_text())
c = json.loads((ROOT / 'session-consumed.json').read_text())
assert c['original_tool_result_consumed'] and c['source_freeze_released'] and c['exit_code'] == 0
assert r['status'] == 'fixed_candidate_refused_not_adopted' and not r['candidate_adopted']
assert r['source_unchanged'] and r['input_unchanged']
for name, digest in c['files'].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
files = {name: (ROOT / name).read_bytes() for name in (
    'controller.py', 'receipt.json', 'session-consumed.json', 'observation.log')}
files['consumer.py'] = (ART / 'tracking88-magsac-fixed-fit-consume-v1.py').read_bytes()
files['collector.py'] = Path(__file__).read_bytes()
archive = OUT / 'tracking88-magsac-fixed-fit-v1.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
    for name, raw in sorted(files.items()):
        target.writestr(name, raw)
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(files)
    assert all(target.read(name) == raw for name, raw in files.items())
manifest = dict(archive=archive.name, bytes=archive.stat().st_size,
                sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), members=len(files),
                head=r['head'], status='candidate_rejected_original_heldout_limit',
                candidate_adopted=False, input_arrays_redistributed=False,
                files={name: dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
                       for name, raw in files.items()})
(OUT / 'tracking88-magsac-fixed-fit-v1.json').write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
print(json.dumps({k: manifest[k] for k in ('archive', 'bytes', 'sha256', 'members')}))
