from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

ART = Path('E:/Dev/aem/artifacts/pr-queue')
OUT = ART / 'tracking88-magsac-fixed-fit-v1'
WORK = Path('E:/Dev/aem/.worktrees/planar-tracker88')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
r = read(OUT / 'receipt.json')
assert r['status'] == 'fixed_candidate_refused_not_adopted'
assert not r['candidate_adopted'] and r['source_unchanged'] and r['input_unchanged']
assert all(sha(WORK / name) == digest for name, digest in r['source_sha256'].items())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == r['head']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK, text=True).strip()
proof = dict(session=3111, original_chunk_id='eee383', exit_code=0,
             original_tool_result_consumed=True, source_unchanged=True, source_freeze_released=True,
             consumed_utc=datetime.now(timezone.utc).isoformat(),
             status='single_declared_candidate_rejected_original_heldout_limit',
             files={p.name: sha(p) for p in OUT.iterdir() if p.is_file()})
(OUT / 'session-consumed.json').write_bytes((json.dumps(proof, indent=2) + '\n').encode())
cp = ART / 'depth75-resume-current.json'
s = read(cp)
v = s['versionedCache75']
assert v['activeController'] == str(ART / 'tracking88-magsac-fixed-fit-v1-controller.py')
v.update(activeController=None, ownHeavyWorkloads=[], currentTrackerFixedFitCandidate=proof)
v['currentGoalTurnAudit'] = dict(
    classification='progress', previous_goal_turn='progress: source-bound CI publication and sealed phase diagnosis',
    goal_complete=False, issue75_complete=False, issue88_complete=False,
    new_evidence='One declared MAGSAC fit rejected:119/146 fit support and1.17619 RMS but3.14934px heldout maximum exceeds original3px',
    no_parameter_search=True, no_gate_changes=True, no_candidate_adoption=True,
    remaining=['Original photographed quality/coverage failures', 'Depth thermal/domain/device-budget qualification',
               'Local compiler/runtime root cause and current exact-source CI'])
cp.write_bytes((json.dumps(s, indent=2) + '\n').encode())
print(json.dumps({k: proof[k] for k in ('session', 'exit_code', 'status')}))
