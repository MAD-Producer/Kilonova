from pathlib import Path
import hashlib,json,subprocess,zipfile

root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-colmap88';out=root/'artifacts/pr-queue/tracking88-document-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((out/'exit.json').read_text(encoding='utf-8'))
assert r['status']=='passed' and r['sourceUnchanged']
assert all(sha(work/n)==h for n,h in r['source'].items())
assert [s['name'] for s in r['steps']]==['model','host','check']
assert all(s['exitCode']==0 for s in r['steps'])
assert r['steps'][0]['summaries']==[['ok','10','0','0','0','0'],['ok','8','0','0','0','0']]
assert r['steps'][1]['summaries']==[['ok','54','0','0','0','126']]
audit=dict(status='model_conversion_document_host_tracking_and_desktop_ffmpeg_check_passed',sourceBase=r['head'],model=dict(passed=18,targets=2,failed=0,ignored=0,filtered=0),hostTracking=dict(passed=54,failed=0,ignored=0,filtered=126),elapsedSeconds=r['elapsedSeconds'],limits=r['limits'])
(out/'independent-summary.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
entries={f'run/{p.name}':p for p in out.iterdir() if p.is_file()}
entries['environment/run.ps1']=root/'.tools/issue-closure-review/run-tracking88-document-v1.ps1'
entries['environment/publish.py']=Path(__file__)
names=subprocess.check_output(['git','diff','--name-only','HEAD','--','crates'],cwd=work).decode().splitlines()
names+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','crates'],cwd=work).decode().splitlines()
for n in sorted(set(names)):
    assert sha(work/n)==r['source'][n]
    entries['source/'+n]=work/n
manifest=dict(audit=audit,entries={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in entries.items()})
archive=work/'engineering/validation/data/tracking88-colmap-managed-v1.zip'
archive.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
    for n,p in entries.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n,p in entries.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(p)
receipt=dict(audit=audit,archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members=len(entries)+1)
archive.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2),flush=True)
