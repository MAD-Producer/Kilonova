from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, time

root=Path('E:/Dev/aem')
work=root/'.worktrees/tracking-colmap88'
out=root/'artifacts/pr-queue/tracking88-document-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[n for n in git('ls-files','--cached','--others','--exclude-standard','crates','desktop','Cargo.toml','Cargo.lock').splitlines() if n.endswith(('.rs','.wgsl','Cargo.toml','Cargo.lock')) and (work/n).is_file()]
r=dict(status='running',head=git('rev-parse','HEAD'),source={n:sha(work/n) for n in paths},steps=[],startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Complete two selected model targets and host tracking namespace only, no full workspace or GPU acceptance','CPU-only while unchanged desktop/UI static binary runs; one own GPU workload','No assertion, deadline, ignore, production-profile or UI change'])
env=os.environ.copy();env.pop('MOTION_LOG',None)
commands=[
 ('model',['cargo','test','-p','motion-model','--test','tracking_colmap','--test','tracking_document','--no-fail-fast','--locked','--offline','--','--test-threads=1']),
 ('host',['cargo','test','-p','motion-host','--lib','--locked','--offline','tracking::','--','--test-threads=1']),
 ('check',['cargo','check','-p','motion-desktop','--features','ffmpeg','--locked','--offline'])
]
def save():(out/'exit.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
try:
 for name,command in commands:
    step=dict(name=name,command=command);r['steps'].append(step);save()
    with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
        p=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);step['pid']=p.pid;save();step['exitCode']=p.wait()
    step['summaries']=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',(out/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace'),re.M)
    r['sourceUnchanged']=all(sha(work/n)==h for n,h in r['source'].items());save()
    assert step['exitCode']==0 and r['sourceUnchanged'],name
    if name!='check':
        assert step['summaries'] and all(s[0]=='ok' and s[2]==s[3]=='0' for s in step['summaries']),name
        if name=='model':assert len(step['summaries'])==2 and all(s[5]=='0' for s in step['summaries'])
 r['status']='passed'
except BaseException as cause:
 r.update(status='failed_original_outputs_retained',failure=repr(cause));raise
finally:
 r.update(elapsedSeconds=round(time.monotonic()-began,3),completedUtc=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({k:v for k,v in r.items() if k not in ['source','steps']},indent=2),flush=True)
