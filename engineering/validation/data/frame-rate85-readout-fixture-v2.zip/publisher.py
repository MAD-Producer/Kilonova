from pathlib import Path
import hashlib,json,re,subprocess,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-import88'
before=root/'artifacts/pr-queue/frame-rate85-approved-readout-v1'
after=root/'artifacts/pr-queue/frame-rate85-approved-readout-v2'
report=json.loads((after/'exit.json').read_text(encoding='utf-8'));failed=json.loads((before/'exit.json').read_text(encoding='utf-8'))
assert report['status']=='approved_fixture_actual_hover_default_logs_and_original_assertions_passed' and report['exitCode']==0 and report['sourceUnchanged']
assert failed['exitCode']==101 and failed['status']=='failed_original_output_retained'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert all(sha((work/p).read_bytes())==h for p,h in report['sources'].items())
fixture='desktop/app/src/panels/graph_ranges/tests/faults.rs'
assert subprocess.check_output(['git','diff','--name-only'],cwd=work).decode().splitlines()==[fixture]
old=subprocess.check_output(['git','show','HEAD:'+fixture],cwd=work).decode('utf-8');new=(work/fixture).read_text(encoding='utf-8')
assertions=lambda text:re.findall(r'assert(?:_eq|_ne)?!\([\s\S]*?\);',text)
assert assertions(old)==assertions(new)
entries={'publisher.py':Path(__file__).read_bytes()}
for folder in [before,after]:
    for p in folder.rglob('*'):
        if p.is_file():entries[folder.name+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
review=dict(originalSession=6892,terminalConsumed=True,exitCode=0,unchangedAssertMacros=len(assertions(old)),
            originalFailedSession=61424,originalFailedTerminalConsumed=True,originalExitCode=1,
            baselineDisposition='DESIGN section0.7 rows retained: only this approved failure fixture changed; no layout/style/hit-area/product edits')
entries['review.json']=(json.dumps(review,indent=2)+'\n').encode('utf-8')
for label in ['v1','v2']:
    name='run-frame-rate85-approved-readout-'+label+'.ps1'
    entries['environment/'+name]=(root/'.tools/issue-closure-review'/name).read_bytes()
entries['manifest.json']=(json.dumps({n:dict(bytes=len(b),sha256=sha(b)) for n,b in entries.items()},indent=2)+'\n').encode('utf-8')
dest=work/'engineering/validation/data/frame-rate85-readout-fixture-v2.zip'
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in entries.items():z.writestr(name,data)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    for name,data in entries.items():assert z.read(name)==data
receipt=dict(status=report['status'],headBeforeFixtureCommit=report['head'],fixtureSha256=sha((work/fixture).read_bytes()),
             command=report['command'],passed=1,failed=0,ignored=0,elapsedSeconds=report['elapsedSeconds'],review=review,outputs=report['observedOutputs'],
             archive=dict(path=dest.name,bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),members=len(entries)),
             limits=['Two fresh real CPU render/hover processes, original first/59/60/120 checkpoints and recovery assertions unchanged',
                     'Finite large slope is shared by healthy cached data and fault snapshot; valid30/1 yields finite velocity and valid240/1 overflows f32',
                     'Provider snapshot deliberately shortens composition before authored keys; not a legal saved-project fixture',
                     'Original failed cached-track attempt retained, not a retry passing without a source correction',
                     'No production panel/layout/style/hit area or observation threshold changes; full regression and CI remain pending'])
dest.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(receipt))
