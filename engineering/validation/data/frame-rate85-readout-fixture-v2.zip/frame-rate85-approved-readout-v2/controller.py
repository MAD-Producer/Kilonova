from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,time
root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-import88'
out=root/'artifacts/pr-queue/frame-rate85-approved-readout-v2';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
name='desktop/app/src/panels/graph_ranges/tests/faults.rs'
original=subprocess.check_output(['git','show','HEAD:'+name],cwd=work).decode('utf-8')
current=(work/name).read_text(encoding='utf-8')
assert re.findall(r'assert(?:_eq|_ne)?!\([\s\S]*?\);',original)==re.findall(r'assert(?:_eq|_ne)?!\([\s\S]*?\);',current)
assert subprocess.check_output(['git','diff','--name-only'],cwd=work).decode().splitlines()==[name]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','-z','crates','desktop','tools','Cargo.toml','Cargo.lock'],cwd=work).decode().split('\0')
sources={n:sha(work/n) for n in names if n and (work/n).is_file()}
(out/'approved.patch').write_bytes(subprocess.check_output(['git','diff','--',name],cwd=work))
(out/'faults-before.rs').write_text(original,encoding='utf-8',newline='\n')
(out/'faults-after.rs').write_bytes((work/name).read_bytes())
os.environ.pop('MOTION_LOG',None)
os.environ['MOTION_CURVE_READOUT_FAULT_ARTIFACTS']=str(out/'captures')
os.environ['LOCALAPPDATA']=str(out/'appdata')
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--locked','--offline','panels::graph_ranges::tests::faults::effect_and_comparison_readout_overflow_reports_the_real_hover_without_poisoning_the_curve','--','--exact','--test-threads=1','--nocapture']
report=dict(status='running',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),sources=sources,command=command,startedUtc=datetime.now(timezone.utc).isoformat(),authorization='User call_31bdf0dc0d774a6581319f42185d7da0 approved this one fixture file; valid240 clock and shared finite-slope snapshots follow the approved same-file scope; all assertions unchanged; prior failed attempt retained separately')
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
try:
    with (out/'test.stdout.log').open('wb') as stdout,(out/'test.stderr.log').open('wb') as stderr:
        p=subprocess.Popen(command,cwd=work,stdout=stdout,stderr=stderr,env=os.environ.copy());report['pid']=p.pid;save();report['exitCode']=p.wait()
    assert report['exitCode']==0,report['exitCode']
    assert '1 passed; 0 failed; 0 ignored;' in (out/'test.stdout.log').read_text(encoding='utf-8')
    checks=[]
    for child in ['first-process','reset-process']:
        folder=out/'captures'/child
        lines=(folder/'motion-studio.log').read_text(encoding='utf-8').splitlines()
        stderr=(folder/'stderr.log').read_text(encoding='utf-8').splitlines()
        stdout=(folder/'stdout.log').read_text(encoding='utf-8')
        assert len(lines)==5 and len(stderr)==2 and 'ERROR' not in stdout and 'panel degradation' not in stdout
        for site in ['effect.graph_readout','curve.comparison.readout']:
            records=[s for s in lines if 'site='+site+' ' in s]
            assert len(records)==2 and 'WARN' in records[0] and 'count=1 ' in records[0] and 'ERROR' in records[1] and 'count=60 ' in records[1]
            assert all('not finite' in s and 'frame=30' in s and 'revision=Some(91)' in s for s in records)
            assert len([s for s in stderr if 'site='+site+' ' in s and 'ERROR' in s])==1
        checks.append(dict(child=child,defaultLevel=True,fileRecords=5,errorStderrRecords=2,stdoutIsolated=True))
    report['observedOutputs']=checks
    report['sourceUnchanged']=all(sha(work/n)==h for n,h in sources.items());assert report['sourceUnchanged']
    report['status']='approved_fixture_actual_hover_default_logs_and_original_assertions_passed'
except BaseException as cause:report.update(status='failed_original_output_retained',failure=repr(cause));raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3));save()
    print(json.dumps({k:v for k,v in report.items() if k!='sources'}),flush=True)
