from pathlib import Path
import subprocess,json,hashlib,time,os
root=Path('E:/Dev/aem');work=root/'.worktrees/node-labels-f9-integration';out=root/'.tools/node-labels-f9-integration'

def git(*args):return subprocess.check_output(['git',*args],cwd=work,text=True).strip()
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tree=git('show','-s','--format=%T','HEAD')
paths=['desktop/app/src/node_editor.rs','desktop/app/src/node_editor/view/canvas.rs','desktop/app/src/node_editor/view/mod.rs','desktop/app/src/node_editor/view/frame_cards_tests.rs','desktop/app/src/node_editor/view/wire_target_tests.rs','desktop/app/src/node_editor/view/wires/socket_index_tests.rs','desktop/app/src/shell/effect_timeline_acceptance.rs','desktop/app/src/shell/effect_timeline_acceptance/protocol_tests.rs','desktop/app/src/shell/effect_timeline_acceptance/tests.rs','desktop/app/src/panels/key_selection.rs','desktop/ui/src/paint.rs','Cargo.lock','tools/ci_desktop.py']
for p in paths[1:6]:assert git('rev-parse','HEAD:'+p)==git('rev-parse','a9947e8:'+p)
for p in paths[6:9]:assert git('rev-parse','HEAD:'+p)==git('rev-parse','d5d82b7e:'+p)
frozen={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
intent={'head':head,'tree':tree,'base':'4afb6cfc036393d3ec02062ae7a846a26403b1df','fix':'d5d82b7e04d7432bb830a3083906f363ea779c4c','labels':'a9947e8ce401dad99f15d9126639c9e0709b5d03','sources':frozen,'source_blobs':{p:git('rev-parse','HEAD:'+p) for p in paths}}
(out/'intent.json').write_text(json.dumps(intent,indent=2),encoding='utf8')
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1','node_editor::','--','--test-threads=1']
start=time.monotonic()
with (out/'node-regressions.log').open('w',encoding='utf8') as log:r=subprocess.run(command,cwd=work,stdout=log,stderr=subprocess.STDOUT)
record={'head':head,'tree':tree,'command':command,'exit_code':r.returncode,'seconds':round(time.monotonic()-start,2),'sources':frozen,'source_unchanged':all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in frozen.items())}
(out/'node-regressions-receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8');assert r.returncode==0 and record['source_unchanged']
assert '164 passed; 0 failed; 0 ignored' in (out/'node-regressions.log').read_text(encoding='utf8')
binary=root/'target/debug/deps/motion_studio-d5bd28a41c2d0117.exe';env=os.environ.copy();env['MOTION_EFFECT_CAPTURE_FAILURE_ARTIFACTS']=str(out/'failure-path');env.pop('MOTION_LOG',None)
command=[str(binary),'shell::effect_timeline_acceptance::','--test-threads=1','--nocapture'];start=time.monotonic()
with (out/'native-protocol-tests.log').open('w',encoding='utf8') as log:r=subprocess.run(command,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
record=dict(record,command=command,exit_code=r.returncode,seconds=round(time.monotonic()-start,2),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),source_unchanged=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in frozen.items()))
(out/'native-protocol-receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8');assert r.returncode==0 and record['source_unchanged']
assert '3 passed; 0 failed; 0 ignored' in (out/'native-protocol-tests.log').read_text(encoding='utf8')
print(json.dumps({'head':head,'tree':tree,'node_tests':164,'native_protocol_tests':3,'passed':True}),flush=True)
