from pathlib import Path
import hashlib,json,os,struct,subprocess,sys,time
out=Path(__file__).resolve().parent;work=Path('E:/Dev/aem/.worktrees/node-labels-f9-integration')
name=sys.argv[1];size,locale,mode=name.split('-');assert size in ['minimum','default'] and locale in ['en','zh'] and mode in ['workspace','properties']
build=json.loads((out/'native-build-receipt.json').read_text(encoding='utf-8'));binary=out/'native/motion-studio.exe'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256']
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in build['sources']}
assert freeze()==build['sources']
folder=out/'native-ui'/name;assert not folder.exists();folder.mkdir(parents=True)
report=folder/'report.json';command=[str(binary),'--property-smoke' if mode=='properties' else '--smoke',str(report),'--locale',locale,'--project',str(folder/'project')]
env=os.environ.copy();env.pop('MOTION_SMOKE_MINIMUM',None)
if size=='minimum':env['MOTION_SMOKE_MINIMUM']='1'
record=dict(name=name,command=command,binary_sha256=build['binary_sha256'],sources=build['sources'],requested_logical_size=[900,600] if size=='minimum' else [1600,1000],harness_limit_seconds=240)
start=time.monotonic();process=None
try:
    with (folder/'stdout.log').open('w',encoding='utf-8') as stdout,(folder/'stderr.log').open('w',encoding='utf-8') as stderr:
        process=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=env,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
        record['pid']=process.pid;(folder/'started.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
        while True:
            try:record['exit_code']=process.wait(timeout=15);break
            except subprocess.TimeoutExpired:
                pngs=list(folder.glob('*.png'));last=max(pngs,key=lambda p:p.stat().st_mtime) if pngs else None
                print(json.dumps(dict(name=name,elapsed_seconds=round(time.monotonic()-start),png_files=len(pngs),latest=last.name if last else None)),flush=True)
                if time.monotonic()-start>=240:
                    process.kill();process.wait(timeout=10);raise TimeoutError('Native case exceeded the 240-second test deadline')
    assert record['exit_code']==0,'native process failed'
    sys.path.insert(0,str(work/'tools'));from ci_desktop import verify_design_screens,verify_expanded_workspace_previews
    snapshot=json.loads(report.read_text(encoding='utf-8'));assert snapshot['locale']==locale
    verify_design_screens(snapshot,locale,property_followups=mode=='properties')
    verify_expanded_workspace_previews(snapshot,locale)
    presentations=snapshot['workspacePresentationProbe']['presentations']
    assert snapshot['workspacePresentationProbe']['projectUntouched'] is True and len(presentations)==6
    assert {r['preset'] for r in presentations}=={'default','nodes','drawing','all','animation'}
    if mode=='workspace':assert any(r['nodeOverlay'] is True for r in presentations)
    expanded=[r for r in presentations if r.get('expandedPreview') is not None]
    if mode=='workspace' and size=='minimum':assert expanded,'minimum workspace must exercise an actual expanded preview'
    if mode=='workspace' and size=='default':assert not expanded,'default layout must retain its existing normal preview path'
    stderr=(folder/'stderr.log').read_text(encoding='utf-8')
    assert not any('site=text.missing_glyph' in line and any(code in line for code in ['U+2194','U+2713']) for line in stderr.splitlines())
    png=Path(snapshot['screenshot']).read_bytes();assert png.startswith(b'\x89PNG\r\n\x1a\n')
    record.update(passed=True,design_screen_count=len(snapshot.get('designScreens',{})),primary_png_size=list(struct.unpack('>II',png[16:24])),presentations=presentations,expanded_preview_cases=len(expanded))
except Exception as error:
    record.update(passed=False,cause=str(error)[:600])
    if process is not None and process.poll() is None:
        try:process.kill();process.wait(timeout=10)
        except Exception as cleanup:record['cleanup_error']=str(cleanup)[:300]
    raise
finally:
    record.update(seconds=round(time.monotonic()-start,2),source_unchanged=freeze()==build['sources'])
    (folder/'receipt.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(record,ensure_ascii=False),flush=True)
