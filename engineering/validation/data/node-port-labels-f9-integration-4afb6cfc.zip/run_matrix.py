from pathlib import Path
import json,os,subprocess,time
out=Path(__file__).resolve().parent
cases=[f'{size}-{locale}-properties' for size in ['default','minimum'] for locale in ['en','zh']]
assert not (out/'matrix.json').exists()
state={'cases':cases,'completed':[],'status':'running','started_at':time.time(),'pid':os.getpid()}
def save():(out/'matrix.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
save()
for name in cases:
    state['current']=name;save()
    result=subprocess.run(['python',str(out/'run_native_case.py'),name],stdout=(out/(name+'.runner.log')).open('w',encoding='utf-8'),stderr=subprocess.STDOUT)
    receipt=json.loads((out/'native-ui'/name/'receipt.json').read_text(encoding='utf-8'))
    state['completed'].append({'name':name,'exit_code':result.returncode,'passed':receipt['passed'],'seconds':receipt['seconds']});save()
    print(json.dumps(state['completed'][-1]),flush=True)
    if result.returncode or not receipt['passed']:
        state['status']='failed';save();raise SystemExit(1)
state['status']='passed';state['elapsed_seconds']=round(time.time()-state['started_at'],2);state.pop('current');save()
print('All four integrated property cases passed',flush=True)
