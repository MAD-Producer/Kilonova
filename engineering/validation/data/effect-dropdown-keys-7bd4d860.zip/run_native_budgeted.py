from pathlib import Path
import hashlib,json,os,struct,subprocess,sys,time
out=Path(__file__).resolve().parent;work=Path('E:/Dev/aem/.worktrees/effect-dropdown-keys')
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
build=read(out/'native-build-receipt.json');binary=out/'native/motion-studio.exe'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==build['binary_sha256']
frozen=build['sources'];freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in frozen}
assert freeze()==frozen
first=read(out/'native-ui/default-en-workspace/receipt.json');assert not first['passed'] and 'timed out' in first['cause']
env=os.environ.copy();env.pop('MOTION_SMOKE_MINIMUM',None)
sys.path.insert(0,str(work/'tools'));from ci_desktop import verify_design_screens,verify_style_consumers
verify_style_consumers();records=[]
for size in ['default','minimum']:
    for locale in ['en','zh']:
        for mode,flag,properties in [('workspace','--smoke',False),('properties','--property-smoke',True)]:
            name=f'{size}-{locale}-{mode}';folder=out/'native-ui-budgeted'/name;assert not folder.exists();folder.mkdir(parents=True)
            report=folder/'report.json';command=[str(binary),flag,str(report),'--locale',locale,'--project',str(folder/'project')]
            case_env=env.copy()
            if size=='minimum':case_env['MOTION_SMOKE_MINIMUM']='1'
            record=dict(name=name,head=build['head'],binary_sha256=build['binary_sha256'],command=command,harness_limit_seconds=240,
                        reason='Original 90-second debug harness deadline expired while new screenshots were still being written; same product binary and original verification assertions retained',requested_logical_size=[900,600] if size=='minimum' else [1600,1000])
            start=time.monotonic();process=None
            try:
                with (folder/'stdout.log').open('w',encoding='utf-8') as stdout,(folder/'stderr.log').open('w',encoding='utf-8') as stderr:
                    process=subprocess.Popen(command,env=case_env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
                    record['pid']=process.pid;(folder/'started.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
                    while True:
                        try:record['exit_code']=process.wait(timeout=15);break
                        except subprocess.TimeoutExpired:
                            files=list(folder.glob('*.png'));latest=max(files,key=lambda p:p.stat().st_mtime) if files else None
                            print(json.dumps(dict(name=name,pid=process.pid,elapsed_seconds=round(time.monotonic()-start),png_files=len(files),latest=latest.name if latest else None)),flush=True)
                            if time.monotonic()-start>=240:
                                process.kill();process.wait(timeout=10)
                                raise TimeoutError('Native acceptance exceeded the explicit 240-second harness deadline')
                assert record['exit_code']==0,'native process failed'
                snapshot=read(report);assert snapshot['locale']==locale
                verify_design_screens(snapshot,locale,property_followups=properties)
                png=Path(snapshot['screenshot']).read_bytes();assert png.startswith(b'\x89PNG\r\n\x1a\n')
                record.update(passed=True,design_screens_verified=True,design_screen_count=len(snapshot.get('designScreens',{})),primary_png_size=list(struct.unpack('>II',png[16:24])))
            except Exception as error:
                record.update(passed=False,cause=str(error)[:600])
                if process is not None and process.poll() is None:
                    try:process.kill();process.wait(timeout=10)
                    except Exception as cleanup:record['cleanup_error']=str(cleanup)[:300]
                raise
            finally:
                record.update(seconds=round(time.monotonic()-start,2),source_unchanged=freeze()==frozen)
                (folder/'receipt.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
                print(json.dumps(record,ensure_ascii=False),flush=True)
            assert record['source_unchanged'];records.append(record)
(out/'native-ui-budgeted-receipt.json').write_text(json.dumps(dict(head=build['head'],sources=frozen,cases=records,all_eight_passed=True,original_90_second_timeout_preserved=True),ensure_ascii=False,indent=2),encoding='utf-8')
