from pathlib import Path
import hashlib,json,os,subprocess,time
out=Path(__file__).resolve().parent;work=Path.cwd()
assert work==Path('E:/Dev/aem/.worktrees/effect-dropdown-keys')
sources=['desktop/app/src/panels/effect_controls.rs','desktop/app/src/panels/effect_controls/dropdown_cache.rs']
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sources}
frozen=freeze();(out/'checks-source-freeze.json').write_text(json.dumps(frozen,indent=2),encoding='utf-8')
common=['cargo','test','-p','motion-desktop','--bin','motion-studio','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1']
env=os.environ.copy();env['CARGO_TERM_COLOR']='never'
for name,scope in [('controls-regressions','panels::effect_controls'),('property-regressions','panels::property_followup_tests'),('timeline-regressions','panels::effect_timeline')]:
    receipt=out/(name+'-receipt.json');assert not receipt.exists(),'Inspect previous attempt instead of restarting'
    command=common+[scope,'--','--test-threads=1'];start=time.monotonic();log=out/(name+'.log')
    with log.open('w',encoding='utf-8') as stream:result=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
    record=dict(command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),source_unchanged=freeze()==frozen,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    receipt.write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps(dict(name=name,**record)),flush=True)
    assert result.returncode==0 and record['source_unchanged'],record
