from pathlib import Path
import json,shutil
out=Path(__file__).resolve().parent;work=Path('E:/Dev/aem/.worktrees/effect-dropdown-keys')
receipt=json.loads((out/'before-receipt.json').read_text(encoding='utf-8'))
assert receipt['exit_code']==0 and receipt['source_unchanged']
path=work/'desktop/app/src/panels/effect_controls.rs';text=path.read_text(encoding='utf-8')
marker='\n#[cfg(test)]\nmod dropdown_key_probe;\n'
assert text==(out/'original-effect-controls.rs').read_text(encoding='utf-8')+marker
changes=[
('mod curve;\n','mod curve;\nmod dropdown_cache;\n'),
('    dropdowns: HashMap<(u64, String), motion_ui::widgets::Dropdown>,','    dropdowns: dropdown_cache::Cache,'),
('        for dropdown in self.dropdowns.values_mut() {\n            dropdown.open = false;\n        }','        self.dropdowns.close();'),
('                                    let key = (id, param.to_string());\n',''),
]
for a,b in changes:
    assert text.count(a)==1,a
    text=text.replace(a,b)
start=text.index('                                    let dropdown = self.dropdowns.entry(key.clone()).or_default();')
end=text.index('                                    result.map(|i| {',start)
old=text[start:end]
new='''                                    let is_modal_owner = modal_owner.as_ref()
                                        .is_some_and(|(owner, name)| *owner == id && name == param);
                                    let (result, open) = self.dropdowns.with(id, param, |dropdown| {
                                        let result = dropdown.draw(
                                            &mut overlays,
                                            atlas,
                                            rect,
                                            area,
                                            &items,
                                            (value[0] - parameter["min"].as_f64().unwrap_or(0.) as f32)
                                                .max(0.) as usize,
                                            if is_modal_owner { original_input } else { input },
                                            enabled,
                                            false,
                                        );
                                        (result, dropdown.open)
                                    });
                                    let is_owner = self.enum_owner.as_ref()
                                        .is_some_and(|(owner, name)| *owner == id && name == param);
                                    if open {
                                        if !is_owner {
                                            self.enum_owner = Some((id, param.into()));
                                        }
                                    } else if is_owner {
                                        self.enum_owner = None;
                                    }
'''
text=text[:start]+new+text[end:]
target=path.parent/'effect_controls/dropdown_cache.rs';assert not target.exists()
path.write_text(text,encoding='utf-8');shutil.copyfile(out/'dropdown_cache.rs',target)
print('Applied owned dropdown key cache change; original drawing arguments retained')
