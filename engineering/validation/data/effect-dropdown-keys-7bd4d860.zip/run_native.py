from pathlib import Path
import hashlib,json,os,shutil,struct,subprocess,sys,time

out=Path(__file__).resolve().parent;work=Path.cwd()
assert work==Path('E:/Dev/aem/.worktrees/effect-dropdown-keys')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='6fa4dcf5be7eaa459f65de87d911a06cfce11a96'
sources=['desktop/app/src/panels/effect_controls.rs','desktop/app/src/panels/effect_controls/dropdown_cache.rs']
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sources}
frozen=freeze();env=os.environ.copy();env['CARGO_TERM_COLOR']='never';env.pop('MOTION_SMOKE_MINIMUM',None)
receipt=out/'native-build-receipt.json';assert not receipt.exists(),'Inspect saved build instead of restarting'
cmd=['cargo','build','-p','motion-desktop','--bin','motion-studio','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1']
log=out/'native-build.log';start=time.monotonic()
with log.open('w',encoding='utf-8') as stream:result=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
r=dict(head=head,command=cmd,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),sources=frozen,source_unchanged=freeze()==frozen,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
receipt.write_text(json.dumps(r,indent=2),encoding='utf-8');assert result.returncode==0 and r['source_unchanged'],r
binary=out/'native/motion-studio.exe';binary.parent.mkdir(exist_ok=True);assert not binary.exists()
shutil.copyfile(Path(env['CARGO_TARGET_DIR'])/'debug/motion-studio.exe',binary)
r['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest();receipt.write_text(json.dumps(r,indent=2),encoding='utf-8')
print(json.dumps(dict(name='native-build',**r)),flush=True)
sys.path.insert(0,str(work/'tools'))
from ci_desktop import verify_design_screens,verify_style_consumers
verify_style_consumers()
records=[]
for size in ['default','minimum']:
    for locale in ['en','zh']:
        for mode,flag,property_followups in [('workspace','--smoke',False),('properties','--property-smoke',True)]:
            name=f'{size}-{locale}-{mode}';folder=out/'native-ui'/name;assert not folder.exists();folder.mkdir(parents=True)
            case_env=env.copy()
            if size=='minimum':case_env['MOTION_SMOKE_MINIMUM']='1'
            report=folder/'report.json';command=[str(binary),flag,str(report),'--locale',locale,'--project',str(folder/'project')]
            record=dict(name=name,head=head,command=command,requested_logical_size=[900,600] if size=='minimum' else [1600,1000],binary_sha256=r['binary_sha256'])
            start=time.monotonic()
            try:
                with (folder/'stdout.log').open('w',encoding='utf-8') as stdout,(folder/'stderr.log').open('w',encoding='utf-8') as stderr:
                    result=subprocess.run(command,env=case_env,stdout=stdout,stderr=stderr,timeout=90,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
                record['exit_code']=result.returncode;assert result.returncode==0,'native process failed'
                snapshot=json.loads(report.read_text(encoding='utf-8'));assert snapshot['locale']==locale
                verify_design_screens(snapshot,locale,property_followups=property_followups)
                record['design_screens_verified']=True
                record['design_screen_count']=len(snapshot.get('designScreens',{}))
                png=Path(snapshot['screenshot']).read_bytes();assert png.startswith(b'\x89PNG\r\n\x1a\n')
                record['primary_png_size']=list(struct.unpack('>II',png[16:24]))
                record['passed']=True
            except Exception as error:
                record['passed']=False;record['cause']=str(error)[:600]
                raise
            finally:
                record.update(seconds=round(time.monotonic()-start,2),source_unchanged=freeze()==frozen)
                (folder/'receipt.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
                print(json.dumps(record,ensure_ascii=False),flush=True)
            assert record['source_unchanged'];records.append(record)
(out/'native-ui-receipt.json').write_text(json.dumps(dict(head=head,sources=frozen,cases=records,all_eight_passed=True),ensure_ascii=False,indent=2),encoding='utf-8')
