from pathlib import Path
import hashlib,json,re,zipfile
out=Path(__file__).resolve().parent;work=Path('E:/Dev/aem/.worktrees/effect-dropdown-keys');dest=work/'engineering/validation'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
comparison=read(out/'comparison.json');assert comparison['all_paint_streams_identical'] and len(comparison['cases'])==12
marker='\n#[cfg(test)]\nmod dropdown_key_probe;\n'
assert (out/'after-effect-controls-with-probe.rs').read_text(encoding='utf-8').removesuffix(marker)==(work/'desktop/app/src/panels/effect_controls.rs').read_text(encoding='utf-8')
assert (out/'after-dropdown-cache.rs').read_text(encoding='utf-8').split('#[cfg(test)]')[0]==(work/'desktop/app/src/panels/effect_controls/dropdown_cache.rs').read_text(encoding='utf-8').split('#[cfg(test)]')[0]
tests=[]
for name in ['controls-regressions','property-regressions','timeline-regressions']:
    receipt=read(out/(name+'-receipt.json'));assert receipt['exit_code']==0 and receipt['source_unchanged']
    log=out/(name+'.log');assert digest(log)==receipt['log_sha256']
    rows=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(encoding='utf-8'),re.M)
    assert len(rows)==1 and rows[0][1:]==('0','0')
    tests.append(dict(name=name,passed=int(rows[0][0]),failed=0,ignored=0,receipt=receipt))
assert sum(r['passed'] for r in tests)==59
first=read(out/'native-ui/default-en-workspace/receipt.json');assert not first['passed']
budgeted=out/'native-ui-budgeted/default-en-workspace';success=read(budgeted/'receipt.json');assert success['passed'] and success['source_unchanged']
build=read(out/'native-build-receipt.json');assert build['source_unchanged'] and build['exit_code']==0
items=[(out/name,name) for name in ['probe.rs','run_phase.py','apply_change.py','dropdown_cache.rs','run_checks.py','run_native.py','run_native_budgeted.py','collect_comparison.py','package_progress.py','original-effect-controls.rs','after-effect-controls-with-probe.rs','after-dropdown-cache.rs','after-source-freeze.json','checks-source-freeze.json','comparison.json','before.log','before-receipt.json','after.log','after-receipt.json','native-build.log','native-build-receipt.json']]
for name in ['controls-regressions','property-regressions','timeline-regressions']:
    items.extend([(out/(name+suffix),name+suffix) for suffix in ['.log','-receipt.json']])
for phase in ['before','after']:
    items.extend((p,p.relative_to(out).as_posix()) for p in sorted((out/phase).iterdir()) if p.is_file())
for phase in ['native-ui','native-ui-budgeted']:
    folder=out/phase/'default-en-workspace'
    items.extend((folder/name,f'{phase}/default-en-workspace/{name}') for name in ['receipt.json','stdout.log','stderr.log'] if (folder/name).is_file())
    if (folder/'report.json').exists():items.append((folder/'report.json',f'{phase}/default-en-workspace/report.json'))
    for name in ['report.effect-controls.png','report.effect-controls-narrow.png']:
        p=folder/name
        if p.is_file():items.append((p,f'{phase}/default-en-workspace/{name}'))
archive=dest/'data/effect-dropdown-keys-7bd4d860.zip';archive.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,name in items:
        assert path.suffix not in ['.exe','.dll'];z.write(path,name)
record=dict(issue=134,comparison=comparison,tests=tests,integration_product_head=build['head'],integration_base='7b2aff0cbe04fde81569d6399373b308947dcc3c',native_build=build,native_first_attempt=first,native_first_completed_case=success,
            native_status='frozen at completion of the first extended-budget case; keep PR draft until the full eight-case matrix completes; final results will be appended to PR body without changing tested product code',
            archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=digest(archive),files=len(items)))
(dest/'effect-dropdown-keys-results.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rows='\n'.join(f"| {r['effects']} | {r['locale']} | {int(r['width'])} | {r['before_allocations']} → {r['after_allocations']} | {r['before_bytes']} → {r['after_bytes']} |" for r in comparison['cases'])
doc=f'''# 效果枚举控件缓存键复用进度

2026-10-25 的冻结验收记录，关联 #134。只处理效果面板已有枚举状态缓存的重复建键，不关闭合集。原生窗口进度冻结在首个扩大测试预算的场景完成时；后续完整结果与最终 CI 状态在对应 PR 正文更新。

## 实现与排重

原枚举行每帧 `param.to_string()` 再克隆一次键，即使缓存命中也分配两个 String。本次用按效果 ID 分组的私有缓存，在命中时借用参数名；首次出现才保存自有名称。原下拉菜单调用的选项、数值、矩形、样式、输入所有者和返回值保留。弹出菜单所有者只在切换时保存新键；取消仍关闭全部已缓存菜单。

开始前检查 416 个引用、121 个工作树、26 个相关文件版本；三个脏工作树均未改变缓存键区域。开放的 #494 处理动画菜单，不改本批文件。既有 TrackCache 已有借用查询，属于已有改进，本次不重复实现或认领其验收。

缓存保留的效果/参数键集合与生命周期保持原语义；分组后首次访问每个效果会建立一个小 HashMap，布局可能增加常驻开销。本次未测 RSS/峰值内存，不把请求字节差当成常驻内存节省，也没有认领缓存淘汰或生命周期修复。现有每行选项 Vec 和弹出菜单期间的面板所有者快照仍保留。

## 冻结基线的真实面板对照

基线 `7bd4d86003b21dd02483e73cbccac730df7036a7`。同一临时测量模块注入两侧测试构建，实际调用 `Controls::render`，每组预热 3 帧再测 20 帧；引擎状态获取、绘制数据格式化、断言和文件 IO 在计数区间外。仅统计当前线程的 Rust alloc/alloc_zeroed/realloc 请求。两侧都包含未改的 `cfg(test)` 命中区观察，不能当作发布版整帧分配或帧率。

| 效果/枚举数 | 语言 | 宽度 | 20 帧分配请求：前 → 后 | 请求字节：前 → 后 |
| --- | --- | --- | --- | --- |
{rows}

12 组共 240 帧，减少 4000 次请求、16000 个请求字节；每个已预热枚举行每帧少两个参数名 String。整体绘制分配仍随内容增长。全部 12 份完整绘制流（顶点/形状、颜色、字形 UV/位置与命令顺序），共 13,606,715 字节逐字节一致。只读绘制没有产生编辑动作，工程未改变。

## 交互、集成与原生窗口状态

- 冻结产品改动的 59 项相关回归通过、0 失败、0 忽略：效果控件 36 项、属性跟进 10 项、效果时间轴 13 项。新增一项名称所有权、效果/参数隔离及全部关闭的状态测试；其余是已有覆盖复验，原断言不变。包含离散选择、撤销、锁定/只读、主窗/浮窗输入所有者和取消。既有行测试在 220/360 宽度、1/1.5/2 倍像素比及 22/32 行高组合验证内联控件，组合仍只计一项测试。
- 随后移植到已合入 #492/#493 的主线 `7b2aff0c`，产品提交 `{build['head']}`；产品源文保持一致，原生应用已在该集成提交构建成功。旧基线的性能对照与新集成运行分开记录。
- Windows 首轮默认英文原生验收被测试脚本的 90 秒上限截断，当时仍连续生成截图。原因未被证明，首轮不计通过；原始日志、限时记录和已完成的效果面板截图保留。
- 同一程序 SHA-256 `{build['binary_sha256']}`，保持原设计截图检查，另一次受控运行将测试预算设为 240 秒，默认英文场景在 {success['seconds']} 秒完成，46 张设计截图校验通过。效果面板宽/窄截图已目检：保持原内联行、下拉选择器和裁剪。该预算只属于外部验收脚本，没有改产品超时、线程、重试或业务返回值。
- 其余 7 个原生场景仍在运行，覆盖中英文、默认 1600×1000 与最小 900×600、基本工作区及属性主窗/浮窗。PR 保持草稿，完整结束后在正文追加结果；本阶段不声明完整 `ci_desktop.py`、所有原生窗口或所有 OS/DPI 已通过。事件为既有归一化验收输入，不冒充物理键盘或系统 IME 服务。

## DESIGN §0.7 逐项处置

| 位置 | 原基线 | 本次之后与证据 | 状态 |
| --- | --- | --- | --- |
| path_controls:860,884,953,1002,1070,1149 | 六处固定行步进 | 不涉及该文件；未由缓存改动整改 | retained with reason |
| path_controls:893 | 固定两列公式 | 不涉及该文件 | retained with reason |
| path_controls:894–953,1038 | 按钮高度混用 | 不涉及该文件或命中区 | retained with reason |
| path_controls:1124,1130 | 数值背景与颜色 | 不涉及该文件或 token | retained with reason |
| path_controls:1151–1170 | 布尔整行按钮 | 不涉及该文件 | retained with reason |
| effect_controls:958,1043,1050 | 属性行步进 | 绘制调用及全部 12 组绘制流一致 | retained with reason |
| effect_controls:998–1013 | 布尔表示 | 既有 Checkbox 分支不变；未认领本次视觉修复 | retained with reason |
| effect_controls:1053–1064 | 枚举表示 | 既有 Dropdown 与原有命中矩形保留；59 项交互及宽/窄截图 | retained with reason |
| effect_controls:974 | hover 背景 | 样式/颜色调用不变，绘制流一致 | retained with reason |
| effect_controls 全文件 | 缩进层级 | 不改层级或展开区，绘制流一致 | retained with reason |
| timeline:541–547/标签列 | 固定列坐标 | 不涉及该文件；保留兼容基线 | retained with reason |
| timeline:1432–1436 | 吸附颜色 | 不涉及该文件或 token | retained with reason |

§12 中与本轮有关的控件行为和绘制不变有上述证据；其余面板、完整状态矩阵、原生窗口/DPI 全覆盖及全局呈现性能不由本阶段证明。没有新控件、尺寸、颜色 token、工程格式或历史系统。

## 错误与审计分类

| ID | 分类与证据 |
| --- | --- |
| EDK-01 | 新增局部优化：命中时借用参数名；12 组真实绘制请求计数与完整绘制流对照。 |
| EDK-02 | 总计 59 项回归：58 项既有交互/错误观察覆盖复验及 1 项新增缓存状态测试；已有 TrackCache 与样式能力不认领为新修复。 |
| EDK-03 | 正常分支：缓存未命中与主动关闭不记故障；新增缓存无 IO/锁/日志，原业务错误与返回语义保持。 |
| EDK-04 | 失败保留：首次原生测试限时与 GPU loader 的环境诊断原样保留；未吞错、修改已有断言或声称修复这些现象。 |
| EDK-05 | 待验证：剩余原生场景、最终五项 CI、合集其他事项、全局零分配与所有平台。完整原生结果后续在 PR 正文更新。 |

数据和阶段原始材料见 [结果清单](effect-dropdown-keys-results.json) 与 [归档](data/{archive.name})，SHA-256 `{digest(archive)}`。仅含独立夹具、自产绘制数据/本产品截图、源码和日志，不含可执行文件、DLL、第三方新增资产或 Adobe 资源。
'''
(dest/'effect-dropdown-keys-progress.md').write_text(doc,encoding='utf-8')
body='''效果面板的枚举状态按效果分组，缓存命中时借用参数名，首次访问才保存自有名称；菜单所有者只在切换时保存新键。保持原下拉选择、输入所有者、关闭和撤销行为。

已完成：12 组真实面板对照共 240 帧，减少 4000 次 String 分配请求；约 13.6 MB 完整绘制数据一致。59 项相关交互回归通过，原断言不变。增加的分组小表可能增加首次使用/常驻开销，不推断 RSS 或帧率。

草稿验收状态：Windows 首轮测试达到脚本 90 秒上限时仍在生成截图，原始失败保留。同一程序、原检查下扩大外部测试预算后，默认英文场景完成且 46 张设计截图通过；其余 7 场景正在运行。完整原生结果补齐后再转就绪，合并前仍要求五项 CI 成功。

工程记录：engineering/validation/effect-dropdown-keys-progress.md。只改既有缓存存储，不改样式、行高、命中区、工程格式或依赖；未关闭整个合集，仍有其他逐帧分配。

Refs #134
'''
(out/'pr-body.md').write_text(body,encoding='utf-8')
print(json.dumps(dict(tests=59,comparison_cases=12,archive=record['archive'],native_status='draft pending remaining seven cases'),ensure_ascii=False))
