use super::*;
use crate::engine::Engine;
use std::{alloc::{GlobalAlloc, Layout, System}, cell::Cell};
thread_local! { static COUNT: Cell<Option<(u64,u64)>> = const { Cell::new(None) }; }
struct Allocator;
fn note(bytes:usize) {
    let _=COUNT.try_with(|c|if let Some((n,b))=c.get(){c.set(Some((n.saturating_add(1),b.saturating_add(bytes as u64))));});
}
unsafe impl GlobalAlloc for Allocator {
    unsafe fn alloc(&self,l:Layout)->*mut u8 {let p=unsafe{System.alloc(l)};if !p.is_null(){note(l.size());}p}
    unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8 {let p=unsafe{System.alloc_zeroed(l)};if !p.is_null(){note(l.size());}p}
    unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {let p=unsafe{System.realloc(p,l,n)};if !p.is_null(){note(n);}p}
    unsafe fn dealloc(&self,p:*mut u8,l:Layout){unsafe{System.dealloc(p,l)}}
}
#[global_allocator]static ALLOCATOR:Allocator=Allocator;

#[test]
fn actual_closed_enum_frames() {
    let out=std::path::PathBuf::from(std::env::var_os("MOTION_DROPDOWN_PROBE_OUT").expect("output directory"));
    std::fs::create_dir_all(&out).unwrap();
    let mut reports=Vec::new();
    for count in [1,8,16] {
        let folder=tempfile::tempdir().unwrap();
        let engine=Engine::start(folder.path().join("project"),motion_desktop_media::platform(),8<<30).unwrap();
        engine.edit(serde_json::to_string(&Command::Add{layer:motion_core::Layer::solid(7,"Enum allocation fixture",[100.;2],[960.,540.,0.],[1.;4])}).unwrap()).unwrap();
        let catalogue=engine.plugin("{\"op\":\"catalogue\"}".into()).unwrap();
        let package=catalogue["packages"].as_array().unwrap().iter().find(|p|p["manifest"]["effects"].as_array().unwrap().iter().any(|e|e["id"]=="drop_shadow")).unwrap();
        for _ in 0..count {
            engine.plugin(serde_json::json!({"op":"add","object":7,"plugin":package["manifest"]["id"],"version":package["manifest"]["version"],"hash":package["hash"],"effect":"drop_shadow"}).to_string()).unwrap();
        }
        let state=engine.state().unwrap();
        assert_eq!(state["project"]["layers"][0]["effects"].as_array().unwrap().len(),count);
        for (locale,label) in [(Locale::En,"en"),(Locale::Zh,"zh")] {
            for width in [220.,360.] {
                let mut controls=Controls{catalogue:catalogue.clone().into(),..Default::default()};
                let mut atlas=TextAtlas::from_system(12.).unwrap();
                let area=Rect::new(0.,0.,width,100000.);
                let input=Input::default();
                let mut expected=None;
                let mut allocations=0;let mut bytes=0;
                for frame in 0..23 {
                    let mut list=PaintList::default();let mut y=0.;let mut actions=Vec::new();
                    if frame>=3 {COUNT.with(|c|c.set(Some((0,0))));}
                    controls.render(&mut list,&mut atlas,area,&mut y,&state["project"]["layers"][0],&state,&input,locale,&mut actions);
                    if frame>=3 {
                        let (n,b)=COUNT.with(|c|c.replace(None).unwrap());allocations+=n;bytes+=b;
                    }
                    assert!(actions.is_empty());assert!(controls.enum_owner.is_none());
                    assert_eq!(controls.test_rects.keys().filter(|(_,_,param,axis)|param=="mode"&&*axis == -4).count(),count);
                    let snapshot=format!("{:?}\n{:?}\n{:?}\n{:?}",list.shapes,list.colors,list.glyphs,list.order);
                    if frame>=3 {
                        if let Some(previous)=&expected {assert_eq!(&snapshot,previous);} else {expected=Some(snapshot);}
                    }
                }
                let name=format!("{count}-{label}-{}",width as u32);
                let snapshot=expected.unwrap();
                std::fs::write(out.join(format!("{name}.paint.txt")),snapshot.as_bytes()).unwrap();
                reports.push(serde_json::json!({"effects":count,"locale":label,"width":width,"frames":20,"allocations":allocations,"allocated_bytes":bytes,"paint_bytes":snapshot.len(),"visible_enum_controls":count}));
            }
        }
        assert_eq!(engine.state().unwrap()["project"],state["project"]);
    }
    std::fs::write(out.join("report.json"),serde_json::to_vec_pretty(&reports).unwrap()).unwrap();
}
