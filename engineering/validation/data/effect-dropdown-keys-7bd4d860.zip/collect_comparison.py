from pathlib import Path
import hashlib,json
out=Path(__file__).resolve().parent;work=Path('E:/Dev/aem/.worktrees/effect-dropdown-keys')
read=lambda name:json.loads((out/name).read_text(encoding='utf-8'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=read('before-receipt.json');after=read('after-receipt.json')
assert before['exit_code']==after['exit_code']==0 and before['source_unchanged'] and after['source_unchanged']
assert before['command']==after['command'] and before['head']==after['head']
parent=work/'desktop/app/src/panels/effect_controls.rs';cache=parent.parent/'effect_controls/dropdown_cache.rs';probe=parent.parent/'effect_controls/dropdown_key_probe.rs'
assert digest(parent)==after['source_sha256']
assert probe.read_bytes()==(out/'probe.rs').read_bytes()
assert cache.read_bytes()==(out/'dropdown_cache.rs').read_bytes()
assert not (out/'comparison.json').exists(),'Existing comparison must be inspected instead of overwritten'
rows=[];paints=[]
for a,b in zip(read('before/report.json'),read('after/report.json'),strict=True):
    for key in ['effects','locale','width','frames','paint_bytes','visible_enum_controls']:
        assert a[key]==b[key],(key,a,b)
    name=f"{a['effects']}-{a['locale']}-{int(a['width'])}.paint.txt"
    old=out/'before'/name;new=out/'after'/name
    assert old.read_bytes()==new.read_bytes(),name
    difference=a['allocations']-b['allocations']
    expected=2*a['effects']*a['frames']
    assert difference==expected,(a,b,expected)
    assert a['allocated_bytes']-b['allocated_bytes']==4*expected
    rows.append(dict(effects=a['effects'],locale=a['locale'],width=a['width'],frames=a['frames'],
                     before_allocations=a['allocations'],after_allocations=b['allocations'],
                     before_bytes=a['allocated_bytes'],after_bytes=b['allocated_bytes']))
    paints.append(dict(file=name,bytes=old.stat().st_size,sha256=digest(old)))
assert len(rows)==12
record=dict(base=before['head'],cases=rows,paints=paints,all_paint_streams_identical=True,
            removed_requests=sum(r['before_allocations']-r['after_allocations'] for r in rows),
            removed_request_bytes=sum(r['before_bytes']-r['after_bytes'] for r in rows),
            counting='current-thread Rust allocation requests during actual Controls::render; test build includes unchanged test_rects observations, not a production FPS or whole-frame constant-allocation claim',
            before_receipt=before,after_receipt=after)
(out/'comparison.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
for source,name in [(parent,'after-effect-controls-with-probe.rs'),(cache,'after-dropdown-cache.rs')]:
    target=out/name;assert not target.exists();target.write_bytes(source.read_bytes())
(out/'after-source-freeze.json').write_text(json.dumps({p.relative_to(work).as_posix():digest(p) for p in [parent,cache,probe]},indent=2),encoding='utf-8')
print(json.dumps(dict(cases=len(rows),removed_requests=record['removed_requests'],removed_request_bytes=record['removed_request_bytes'],paint_bytes=sum(p['bytes'] for p in paints),all_identical=True)))
