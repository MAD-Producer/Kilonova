from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
out=Path(__file__).resolve().parent;work=Path.cwd();phase=sys.argv[1]
assert work==Path('E:/Dev/aem/.worktrees/effect-dropdown-keys') and phase in ['before','after']
assert not (out/(phase+'-receipt.json')).exists(),'Inspect existing attempt; do not restart it'
source=work/'desktop/app/src/panels/effect_controls.rs'
marker='\n#[cfg(test)]\nmod dropdown_key_probe;\n'
if phase=='before':
    assert subprocess.check_output(['git','status','--porcelain'],text=True).strip()==''
    (out/'original-effect-controls.rs').write_bytes(source.read_bytes())
    source.write_text(source.read_text(encoding='utf-8')+marker,encoding='utf-8')
    target=source.parent/'effect_controls/dropdown_key_probe.rs'
    assert not target.exists();shutil.copyfile(out/'probe.rs',target)
assert source.read_text(encoding='utf-8').endswith(marker)
source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
cmd=['cargo','test','-p','motion-desktop','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1','--','--exact','panels::effect_controls::dropdown_key_probe::actual_closed_enum_frames','--test-threads=1','--nocapture']
env=os.environ.copy();env['CARGO_TERM_COLOR']='never';env['MOTION_DROPDOWN_PROBE_OUT']=str(out/phase)
start=time.monotonic();log=out/(phase+'.log')
with log.open('w',encoding='utf-8') as stream:result=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
record=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),command=cmd,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),source_sha256=source_hash,source_unchanged=hashlib.sha256(source.read_bytes()).hexdigest()==source_hash,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(out/(phase+'-receipt.json')).write_text(json.dumps(record,indent=2),encoding='utf-8')
assert result.returncode==0 and record['source_unchanged'],record
print(json.dumps(record),flush=True)
