from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/render-dag';out=root/'artifacts/pr-queue'
sha=lambda b:hashlib.sha256(b).hexdigest()
run=out/'issue78-shader-owners-v1'
receipt=json.loads((run/'accepted.json').read_text(encoding='utf-8'))
assert all(s['sourceUnchanged'] and s['exitCode']==0 for s in receipt['steps'])
assert sum(s['passed'] for s in receipt['steps'])==25
for name,digest in receipt['source'].items():assert sha((work/name).read_bytes())==digest,name
payload={}
for file in run.iterdir():
    if file.is_file():payload['run/'+file.name]=file.read_bytes()
files=[
 'crates/motion-render/src/effect_plan/effect_execution/admission.rs',
 'crates/motion-render/src/effect_plan/effect_execution/tests.rs',
 'crates/motion-render/src/effect_plan/execution.rs',
 'crates/motion-render/tests/scratch_planning.rs',
 'crates/motion-render/tests/typed_snapshot_execution.rs',
 'crates/motion-effects/src/execution_plan.rs',
 'crates/motion-effects/src/execution_plan/validation.rs',
 'crates/motion-effects/src/execution_plan/tests.rs',
 'crates/motion-effects/src/shader/identity.rs']
for name in files:payload['source/'+name]=(work/name).read_bytes()
for name in ['issue78-shader-budget-red.log','issue78-exposure-original-isolated.log','issue78-pr508-ci-180bce53-failed.log']:
    payload['rejected-or-isolated/'+name]=(out/name).read_bytes()
payload['controller/archive.py']=Path(__file__).read_bytes()
manifest=dict(baseHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
 scope='25 source-frozen scoped tests, no whole-workspace or final remote acceptance; original failed CI and isolated Exposure are separate evidence',
 payload={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(payload.items())})
payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=work/'engineering/validation/data/typed-render-dag-shader-owners.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(payload.items()):archive.writestr(name,data)
with zipfile.ZipFile(dest) as archive:
    assert set(archive.namelist())==set(payload)
    for name,data in payload.items():assert sha(archive.read(name))==sha(data)
result=dict(file=dest.name,bytes=dest.stat().st_size,files=len(payload),sha256=sha(dest.read_bytes()))
(out/'issue78-shader-owners-archive.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
