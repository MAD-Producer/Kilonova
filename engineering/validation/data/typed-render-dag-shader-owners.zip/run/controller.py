from pathlib import Path
import hashlib, json, os, re, subprocess, sys
root = Path('E:/Dev/aem'); work = root / '.worktrees/render-dag'
out = root / 'artifacts/pr-queue/issue78-shader-owners-v1'; out.mkdir(exist_ok=False)
def source():
    names = set()
    for args in [('ls-files','-z'),('ls-files','--others','--exclude-standard','-z')]:
        names.update(p.decode() for p in subprocess.check_output(['git',*args],cwd=work).split(b'\0') if p)
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(names)
            if (work/p).is_file() and (p.endswith(('.rs','.wgsl','.glsl','.toml','.json')) or p=='Cargo.lock')}
before=source(); env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/original-source-memory-b273180a'),CARGO_BUILD_JOBS='1',
           CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true',
           WGPU_BACKEND='vulkan',VK_DRIVER_FILES=str(root/'.tools/android-sdk/emulator/lib64/vulkan/lvp_icd.json'),
           MESA_SHADER_CACHE_DIR=str(root/'target/software-vulkan-cache'))
env['PATH']=str(root/'.tools/android-sdk/emulator/lib64/vulkan')+os.pathsep+env['PATH']
commands=[
    ('effect-ir',['cargo','test','-p','motion-render','--lib','effect_plan::effect_execution::tests::']),
    ('native-integration',['cargo','test','-p','motion-render','--test','scratch_planning','--test','typed_snapshot_execution']),
    ('generic-limits',['cargo','test','-p','motion-effects','--lib','execution_plan::tests::'])]
receipt=dict(source=before,controllerPid=os.getpid(),steps=[])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
for name,command in commands:
    command += ['--locked','--offline','--','--test-threads=1']
    step=dict(name=name,command=command);receipt['steps'].append(step)
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);step['pid']=child.pid
        (out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');step['exitCode']=child.wait()
    step['sourceUnchanged']=before==source()
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    assert step['sourceUnchanged']
    if step['exitCode']:sys.exit(step['exitCode'])
    results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (out/(name+'.stdout.log')).read_text(encoding='utf-8'))
    assert results and sum(int(r[0]) for r in results)>0 and all(int(r[1])==0 and int(r[2])==0 for r in results)
    step['passed']=sum(int(r[0]) for r in results)
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(passed=sum(s['passed'] for s in receipt['steps']),failed=0,ignored=0)),flush=True)
