"""Fresh complete maintained-workspace run after main-adf rebase."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, os, re, shutil, subprocess, time, traceback, ctypes
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/depth-transition75';OUT=ROOT/'artifacts/pr-queue/depth75-aligned-workspace-v5'
assert shutil.disk_usage(ROOT).free>=10<<30, 'Original10GiB admission; no test started'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
observed_origin_main=subprocess.check_output(['git','rev-parse','origin/main'],cwd=WORK,text=True).strip()
main='adf529314647e559fad57a7da2107a1a3c4ffc92' # Explicit source baseline, not a mutable shared remote-tracking ref
assert head=='1a939a3dd71d4d37b6635fcbf8b035d615bd67b2' and main=='adf529314647e559fad57a7da2107a1a3c4ffc92'
subprocess.run(['git','merge-base','--is-ancestor',main,head],cwd=WORK,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
second=ROOT/'artifacts/pr-queue/depth75-aligned-workspace-v4'
second_failure=json.loads((second/'receipt.json').read_text(encoding='utf-8'))
second_terminal=json.loads((second/'session-consumed.json').read_text(encoding='utf-8'))
assert second_failure['exitCode']==101 and second_failure['sourceUnchanged'] and second_terminal['session']==20005 and second_terminal['exitCode']==1
assert 'LNK1207' in (second/'stderr.log').read_text(encoding='utf-8') and (second/'stdout.log').stat().st_size==0
assert all(not x['headerHasMsfMagic'] for x in json.loads((second/'pdb-header-observation.json').read_text(encoding='utf-8'))['files'])
assert not (ROOT/'target/depth75-post-restart-validation').exists(), 'Fresh isolated target required; no old target is deleted'

failed=ROOT/'artifacts/pr-queue/depth75-aligned-workspace-v2'
failure=json.loads((failed/'receipt.json').read_text(encoding='utf-8'))
terminal=json.loads((failed/'session-consumed.json').read_text(encoding='utf-8-sig'))
recovery=json.loads((failed/'pdb-recovery.json').read_text(encoding='utf-8-sig'))
assert failure['exitCode']==101 and failure['sourceUnchanged'] and terminal['session']==99431 and terminal['exitCode']==1
assert (failed/'stdout.log').stat().st_size==0 and 'LNK1207' in (failed/'stderr.log').read_text(encoding='utf-8')
assert recovery['deletedFiles']==0 and recovery['recursiveOperation']==False
assert hashlib.sha256(Path(recovery['preserved']).read_bytes()).hexdigest().lower()==recovery['sha256'].lower()
# The first original path may now contain a regenerated valid PDB; preserved failed bytes remain authoritative.

interrupted=ROOT/'artifacts/pr-queue/depth75-aligned-workspace-v1'
interruption=json.loads((interrupted/'session-interrupted.json').read_text(encoding='utf-8'))
assert interruption['status']=='interrupted_no_terminal_exit_or_test_qualification' and interruption['exitCode'] is None
assert interruption['originalCargoPidAbsent'] and interruption['sourceUnchanged'] and interruption['stdoutBytes']==0
# Original run is retained, never relabeled. This fresh full invocation follows
# a documented host reboot, not an observation timeout or unexplained test retry.

previous=ROOT/'artifacts/pr-queue/depth75-worker-alignment-host-v2'
qualified=json.loads((previous/'receipt.json').read_text(encoding='utf-8'))
assert qualified['status']=='full_host_and48_named_controls_passed' and qualified['sourceUnchanged']
consumed=json.loads((previous/'session-consumed.json').read_text(encoding='utf-8'));assert consumed['session']==62805 and consumed['exitCode']==0
assert 'RUSTC_WORKSPACE_WRAPPER' not in os.environ and 'RUSTC_WRAPPER' not in os.environ
names=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def identity():return {n:sha(WORK/n) for n in names}
source=identity()
for name in ('crates/motion-host/src/depth.rs','crates/motion-host/src/depth/onnx.rs','crates/motion-host/src/depth/transition.rs','crates/motion-host/src/depth/transition/admission.rs','crates/motion-host/tests/depth_aligned_admission.rs','crates/motion-host/tests/depth_worker_alignment.rs','desktop/app/src/logging/sink.rs'):
 assert source[name]==qualified['source'][name]
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'): env.pop(name, None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),
    CARGO_TARGET_DIR=str(ROOT/'target/depth75-post-restart-validation'),
    CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT/'appdata'),
    TEMP=str(ROOT/'target/depth75-post-restart-validation/tmp'), TMP=str(ROOT/'target/depth75-post-restart-validation/tmp'))
Path(env['TEMP']).mkdir(parents=True, exist_ok=True)


preflight=dict(status='running',sourceCommit=head,startedUtc=datetime.now(timezone.utc).isoformat())
def preflight_save():(OUT/'cache-preflight.json').write_text(json.dumps(preflight,indent=2)+'\n',encoding='utf-8')
preflight_save()
try:
 with (OUT/'offline-metadata.json').open('wb') as out,(OUT/'offline-metadata.stderr.log').open('wb') as err:
  child=subprocess.Popen(['cargo','metadata','--format-version','1','--locked','--offline'],cwd=WORK,env=env,stdout=out,stderr=err);preflight['pid']=child.pid;preflight_save();preflight['exitCode']=child.wait()
 assert preflight['exitCode']==0
 preflight['status']='complete_locked_offline_metadata_passed'
except BaseException as e:preflight.update(status='failed_original_outputs_retained',cause=repr(e));raise
finally:preflight['sourceUnchanged']=identity()==source;preflight_save()
assert preflight['sourceUnchanged']
metadata = json.loads(subprocess.check_output(['cargo','metadata','--no-deps','--format-version','1','--locked'],cwd=WORK,env=env))
(OUT/'cargo-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
command = ['cargo','test','--workspace','--exclude','motion-android','--features',
    'motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth',
    '--no-fail-fast','--locked','--','--test-threads=1']
report=dict(status='running',baseCommit=head,main=main,observedOriginMain=observed_origin_main,source=source,command=command,
 startedUtc=datetime.now(timezone.utc).isoformat(),freeBytesBefore=shutil.disk_usage(ROOT).free,
 targetDirectory=env['CARGO_TARGET_DIR'],temporaryDirectory=env['TEMP'],expectedNamedControls=qualified['namedPasses'],
 limits=['Complete maintained workspace, exact committed1a939a3d source rebased to main-adf; Android excluded by user',
 'Original command, features, default GPU/backend, assertions, ignores, stack, timeout and10GiB admission preserved',
 'One own serial native workload; no foreign process stopped or cache deleted; controlled IO on E',
 'All metadata-selected test targets and doctests must be accounted for; abnormal native exits are failures',
 'Historical5002 and host443 remain qualified only for their recorded source; this fresh command covers main changes and the new worker',
 'Original native/compiler access violations remain unexplained and retained; no diagnostic wrapper, debugger or retry loop',
 'Previous complete invocation interrupted by verified host restart with no exit/test results; original evidence retained',
 'Two original invocations failed with actual LNK1207 on different zero-header PDBs; original failures retained, fresh isolated E target avoids all suspect old build outputs, no cache deleted',
 'Full regression does not establish scene/video alignment quality, automatic Session policy/cache/export or thermal stability'])
def save():
    pending=OUT/'receipt.pending.json'
    pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    os.replace(pending,OUT/'receipt.json')
save(); began=time.monotonic()

class HostMemory(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(name,ctypes.c_ulonglong) for name in
        ('totalPhysical','availablePhysical','totalPageFile','availablePageFile','totalVirtual','availableVirtual','availableExtendedVirtual')]
get_memory=ctypes.WinDLL('kernel32',use_last_error=True).GlobalMemoryStatusEx
get_memory.argtypes=[ctypes.POINTER(HostMemory)];get_memory.restype=ctypes.c_int
def observe_host_memory():
    memory=HostMemory();memory.length=ctypes.sizeof(memory)
    row=dict(utc=datetime.now(timezone.utc).isoformat(),stderrBytes=(OUT/'stderr.log').stat().st_size)
    if get_memory(ctypes.byref(memory)):
        row.update(loadPercent=memory.load,totalPhysical=memory.totalPhysical,availablePhysical=memory.availablePhysical,
            totalPageFile=memory.totalPageFile,availablePageFile=memory.availablePageFile)
    else:row['error']=ctypes.get_last_error()
    with (OUT/'host-memory.jsonl').open('a',encoding='utf-8') as file:file.write(json.dumps(row)+'\n')

try:
    with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        report['pid']=child.pid;save();observe_host_memory()
        while True:
            try:
                code=child.wait(timeout=30)
                break
            except subprocess.TimeoutExpired:
                observe_host_memory()
        observe_host_memory()
    report['exitCode']=code
    stdout=(OUT/'stdout.log').read_text(encoding='utf-8',errors='replace')
    stderr=(OUT/'stderr.log').read_text(encoding='utf-8',errors='replace')
    summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
    executables=re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)',stderr,re.M)
    docs=re.findall(r'^\s*Doc-tests (\S+)\s*$',stderr,re.M)
    expected=[];by_name={};doc_owners={}
    for package in metadata['packages']:
        if package['id'] not in metadata['workspace_members'] or package['name']=='motion-android':continue
        for target in package['targets']:
            if not target['test']:continue
            relative=Path(target['src_path']).relative_to(WORK).as_posix()
            key=package['name']+'::'+target['kind'][0]+'::'+relative
            expected.append(key);by_name.setdefault(target['name'].replace('-','_'),[]).append((relative,key))
        if any(t['doctest'] for t in package['targets']):
            key='doc::'+package['name'];expected.append(key);doc_owners[package['name'].replace('-','_')]=key
    observed=[];bound=[]
    for executable in executables:
        path=Path(executable);dependency=path.with_suffix('.d');raw=dependency.read_bytes()
        line=raw.decode('utf-8').splitlines()[0].split(': ',1)[1].replace('\\','/')
        name=re.sub(r'-[a-f0-9]+$','',path.stem)
        owners=[key for relative,key in by_name[name] if re.search(r'(?<!\S)'+re.escape(relative)+r'(?!\S)',line)]
        assert len(owners)==1,(executable,owners)
        observed.extend(owners)
        bound.append(dict(executable=executable,target=owners[0],depInfoSha256=hashlib.sha256(raw).hexdigest()))
    observed.extend(doc_owners[name] for name in docs)
    report.update(totals=dict(passed=sum(int(s[1]) for s in summaries),failed=sum(int(s[2]) for s in summaries),
        originalIgnored=sum(int(s[3]) for s in summaries),filtered=sum(int(s[5]) for s in summaries),
        summaryCount=len(summaries),observedInvocations=len(observed),expectedInvocations=len(expected)),
        sourceBoundInvocations=bound,missingSourceTargets=dict(Counter(expected)-Counter(observed)),
        unexpectedSourceTargets=dict(Counter(observed)-Counter(expected)),
        fullTargetCoverageAccounted=Counter(expected)==Counter(observed) and len(summaries)==len(observed),
        allSourceInvocationsStarted=Counter(expected)==Counter(observed),
        abnormalTargetExits=[line for line in stderr.splitlines() if "process didn't exit successfully:" in line],
        failedTestNames=re.findall(r'^test ([^\r\n]+?) \.\.\. FAILED\s*$',stdout,re.M))
    report['status']='complete_maintained_workspace_passed' if code==0 and report['fullTargetCoverageAccounted'] and not report['totals']['failed'] and not report['totals']['filtered'] else 'failed_original_outputs_retained'
    report['namedPasses']=[name for name in report['expectedNamedControls'] if len(re.findall(r'(?m)^test '+re.escape(name)+r' \.\.\. ok$',stdout))==1]
    if len(report['namedPasses'])!=48:report['status']='failed_original_outputs_retained'
except BaseException as error:
    report.update(status='observer_failed_original_outputs_retained',failure=repr(error),traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=identity()==source and subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,
        completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3),freeBytesAfter=shutil.disk_usage(ROOT).free)
    report['logs']={n:dict(bytes=(OUT/n).stat().st_size,sha256=sha(OUT/n)) for n in ('stdout.log','stderr.log','cargo-metadata.json') if (OUT/n).exists()}
    save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','sourceBoundInvocations')}))
raise SystemExit(0 if report['status']=='complete_maintained_workspace_passed' and report['sourceUnchanged'] else 1)
