//! Processed visible planar matte sources retain their own physical depth.
use super::*;
use motion_model::compositing::{MatteMode, TrackMatte};
fn ray(pixels: &[u8], x: usize) -> &[u8] {
    &pixels[(32 * 96 + x) * 4..][..4]
}
fn srgb(c: f32) -> u8 {
    let c = if c <= 0.0031308 {
        12.92 * c
    } else {
        1.055 * c.powf(1. / 2.4) - 0.055
    };
    (255. * c).round() as u8
}
#[test]
#[cfg_attr(not(feature = "gpu-tests"), ignore = "requires an actual GPU")]
fn spatial_matte_material_stays_behind_physical_backdrop_and_projects_independent_luma() {
    use motion_effects::image_contract::ChannelPrecision::*;
    for precision in [Unorm8, Unorm16, Float16, Float32] {
        let root = tempfile::tempdir().unwrap();
        let mut p = project(root.path());
        p.working_precision = precision;
        image::save_buffer(
            root.path().join("assets/green.png"),
            &[0, 255, 0, 255, 0, 255, 0, 255],
            2,
            1,
            image::ColorType::Rgba8,
        )
        .unwrap();
        p.assets.push(Asset {
            id: 8,
            path: "assets/green.png".into(),
            width: 2,
            height: 1,
        });
        let mut source = Layer::solid(
            91,
            "Far processed spatial matte",
            [64., 40.],
            [48., 32., 20.],
            [1.; 4],
        );
        source.content = Content::Image { asset: 8 };
        source.three_d = true;
        source.transform.opacity.value = 0.5;
        source.masks.push(calibrated_masks::right_source_half());
        let package = motion_effects::builtin::package().unwrap();
        let definition = package
            .manifest
            .effects
            .iter()
            .find(|e| e.id == "invert")
            .unwrap();
        let mut effect = motion_core::EffectInstance::new(
            1,
            &package.manifest.id,
            &package.manifest.version,
            &package.hash,
            definition,
            [64., 40.],
        );
        effect.params.get_mut("channel").unwrap().track.value = [1., 0., 0., 0.];
        source.effects.push(effect);
        p.layers.push(source);
        p.layers[0].track_matte = Some(TrackMatte {
            source: 91,
            mode: MatteMode::Luma,
            hide_source: false,
        });
        p.rebuild_plugin_dependencies();
        p.validate().unwrap();
        let near =
            DepthResource::new(field(1).descriptor().clone(), vec![1., 1.], None, None).unwrap();
        let sample = |p: &Project| {
            let mut s = sampled(p);
            s.attach_calibrated_depth(1, &near.descriptor().source, &near, input())
                .unwrap();
            s
        };
        let mut renderer = pollster::block_on(Renderer::headless_with_working_precision(
            precision,
            motion_render::AllocationBudget::new(128 << 20).unwrap(),
        ))
        .unwrap();
        prepare(&mut renderer, &p, root.path());
        let target = renderer
            .sdr_capture_target(96, 64, motion_render::OutputTransform::SDR_CLIP)
            .unwrap();
        let actual = renderer.capture_sdr(&sample(&p), &target).unwrap().0.pixels;
        assert_eq!(ray(&actual, 40), [0, 0, 255, 255]);
        // Independent magenta source luminance after its half opacity. The
        // visible source is behind opaque blue, so it cannot overpaint it.
        let c = 0.5 * (0.2126 + 0.0722);
        let expected = [srgb(c), 0, srgb(1. - c), 255];
        assert!(
            ray(&actual, 56)
                .iter()
                .zip(expected)
                .all(|(a, b)| a.abs_diff(b) <= 1),
            "{precision:?} actual={:?} expected={expected:?}",
            ray(&actual, 56)
        );
        p.layers.reverse();
        assert_eq!(
            renderer.capture_sdr(&sample(&p), &target).unwrap().0.pixels,
            actual,
            "physical source depth must not depend on authored order"
        );
        retain_fixture(
            &format!("spatial-matte-material-{precision:?}.png"),
            &actual,
        );
    }
}
