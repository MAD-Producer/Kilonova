"""Test the independently publishable clock against HEAD's integer project API.

Keep the unfinished project port byte-for-byte in a recoverable external
snapshot; restore it even if the selected Cargo gate fails. No source is lost.
"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/frame-rate85-fractional-publish-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda data: hashlib.sha256(data).hexdigest()
modified = subprocess.check_output(['git', 'diff', '--name-only'], cwd=work).decode('utf-8').splitlines()
ports = [p for p in modified if p.startswith('crates/motion-model/src/') and not p.endswith('/frame_rate.rs')]
backups = {p: (work / p).read_bytes() for p in ports}
for path, data in backups.items():
    dest = out / 'unfinished-port' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
publish_paths = ['crates/motion-model/src/frame_rate.rs', 'crates/motion-model/tests/frame_rate.rs',
                 'crates/motion-model/tests/fixtures/frame-rate/fractional-clock.json']
env = os.environ.copy()
env.update(CARGO_HOME=str(root / '.tools/prerender-cargo-home'),
    CARGO_TARGET_DIR=str(root / 'target/rational-rate85-contract'), CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1',
    TEMP=str(root / 'target/ci-policy-validation-tmp'), TMP=str(root / 'target/ci-policy-validation-tmp'))
command = ['cargo', 'test', '-p', 'motion-model', '--test', 'frame_rate', '--locked', '--offline', '--', '--test-threads=1']
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(), command=command,
    base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip(),
    preservedPort={p: sha(v) for p, v in backups.items()},
    publishedSource={p: sha((work / p).read_bytes()) for p in publish_paths})
save = lambda: (out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
save()
started = time.monotonic()
try:
    for path in ports:
        (work / path).write_bytes(subprocess.check_output(['git', 'show', f'HEAD:{path}'], cwd=work))
    report['testedLibrary'] = {str(p.relative_to(work)).replace('\\', '/'): sha(p.read_bytes())
                              for p in (work / 'crates/motion-model/src').rglob('*.rs')}
    save()
    with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    assert report['exitCode'] == 0, 'independent fractional clock gate failed'
    assert '7 passed; 0 failed; 0 ignored' in (out / 'stdout.log').read_text(encoding='utf-8')
    assert all(sha((work / p).read_bytes()) == digest for p, digest in report['testedLibrary'].items())
    assert all(sha((work / p).read_bytes()) == digest for p, digest in report['publishedSource'].items())
    report['status'] = 'independent_fractional_clock_passed_project_port_excluded'
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    for path, data in backups.items():
        (work / path).write_bytes(data)
    report['portRestoredByteExactly'] = all((work / p).read_bytes() == v for p, v in backups.items())
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic()-started, 3))
    save()
    print(json.dumps({k: report.get(k) for k in ['status', 'exitCode', 'elapsedSeconds', 'portRestoredByteExactly', 'failure']}), flush=True)
