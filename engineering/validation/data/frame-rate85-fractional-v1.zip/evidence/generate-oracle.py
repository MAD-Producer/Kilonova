"""Freeze an independent integer/Fraction oracle for binary-f64 media clocks."""
from fractions import Fraction
from pathlib import Path
import json
import math
import struct

root = Path('E:/Dev/aem/.worktrees/rational-frame-rates85')
rates = [(1, 1), (24, 1), (24000, 1001), (30000, 1001),
         (60000, 1001), (1000000, 1), (1, 1000000)]
frames = [0.0, -0.0, math.ulp(0.0), -math.ulp(0.0), 2.0**-1022,
          -2.0**-1022, 2.0**-100, -2.0**-100, -100000.25, -1.5,
          -0.5, 0.5, 1.5, 100000.25, 2.0**63, -(2.0**63),
          float.fromhex('0x1.fffffffffffffp+1023')]
rows = []
for numerator, denominator in rates:
    for ticks in [1, 48000, 1000000, 1000000000]:
        # Also cover the representable neighbors of positive/negative half ticks.
        half = numerator / (2 * ticks * denominator)
        values = frames + [half, math.nextafter(half, 0.0), math.nextafter(half, math.inf),
                           -half, math.nextafter(-half, 0.0), math.nextafter(-half, -math.inf)]
        for frame in values:
            exact = Fraction.from_float(frame) * ticks * denominator / numerator
            floor = exact.numerator // exact.denominator
            ceil = -((-exact.numerator) // exact.denominator)
            magnitude = abs(exact)
            nearest = (2 * magnitude.numerator + magnitude.denominator) // (2 * magnitude.denominator)
            if exact < 0:
                nearest = -nearest
            expected = [v if -(2**63) <= v < 2**63 else None for v in (floor, ceil, nearest)]
            rows.append(dict(rate=[numerator, denominator], ticks=ticks,
                             bits=f'{struct.unpack(">Q", struct.pack(">d", frame))[0]:016x}',
                             expected=expected))
out = root / 'crates/motion-model/tests/fixtures/frame-rate/fractional-clock.json'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(dict(oracle='Python Fraction.from_float; exact integer rounding', cases=rows),
                          indent=2) + '\n', encoding='utf-8')
print(f'{len(rows)} exact clock cases written')
