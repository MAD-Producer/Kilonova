from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,shutil
root=Path('E:/Dev/aem');work=root/'.worktrees/native-camera-dof';out=root/'artifacts/pr-queue/native-camera-dof-regression-v1';out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='1',MOTION_DEPTH_ACCEPTANCE_DIR=str(out/'native-renders'),MOTION_FROZEN_DEPTH_ARTIFACTS=str(out/'native-outputs'));env.pop('MOTION_LOG',None)
def git(*a):return subprocess.check_output(['git',*a],cwd=work).decode().strip()
def sources():
 paths=git('ls-files','--cached','--others','--exclude-standard','-z').split('\0')
 return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml')) or p=='Cargo.lock')}
assert git('merge-base','HEAD','origin/main')==git('rev-parse','origin/main')=='3865b0feca1acc65b8a5d0f96a0ca9684ee26beb'
changed=set(git('diff','--name-only','-z').split('\0'))|set(git('ls-files','--others','--exclude-standard','-z').split('\0'))
assert not any(p.startswith('desktop/app/src/panels/') for p in changed)
for p in changed:
 if p and p.endswith(('.rs','.wgsl','.toml')):
  dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/p,dest)
source=sources();report=dict(head=git('rev-parse','HEAD'),main=git('rev-parse','origin/main'),source=source,steps=[])
render=['cargo','test','-p','motion-render']
for target in ['depth_surface','model_layers','layer_compositing','layer_masks','layer_rasters','effects','motion_effects','spatial_effects','image_allowed_sets','scene_gpu']:render+=['--test',target]
render+=['--locked','--offline','--','--test-threads=1']
steps=[('model-core',['cargo','test','-p','motion-model','-p','motion-core','--lib','--tests','--locked','--offline','--','--test-threads=1']),('render-regression',render),('render-lib',['cargo','test','-p','motion-render','--lib','--locked','--offline','--','--test-threads=1']),('scheduler',['cargo','test','-p','motion-host','--no-default-features','--lib','prerender::tests','--locked','--offline','--','--test-threads=1']),('frozen',['cargo','test','-p','motion-desktop-media','--features','ffmpeg,ai-depth','movie::depth_of_field_tests::','--locked','--offline','--','--test-threads=1']),('current-main-capture',['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','capture_context_tests','--locked','--offline','--','--test-threads=1']),('desktop',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),('style',['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),('provenance',['python','tools/validate_provenance.py'])]
for name,command in steps:
 print(json.dumps(dict(start=name)),flush=True)
 with (out/(name+'.stdout.log')).open('wb') as so,(out/(name+'.stderr.log')).open('wb') as se:code=subprocess.run(command,cwd=work,env=env,stdout=so,stderr=se).returncode
 counts=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',(out/(name+'.stdout.log')).read_text(encoding='utf-8'))
 row=dict(name=name,command=command,exitCode=code,counts=counts,sourceUnchanged=sources()==source);report['steps'].append(row)
 (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(row),flush=True)
 assert code==0 and row['sourceUnchanged'],name
 if name not in ['desktop','style','provenance']:assert counts and all(int(f)==int(i)==0 for _,f,i in counts),row
report.update(distinctPassed=sum(int(p) for step in report['steps'] for p,_,_ in step['counts']),sourceUnchanged=sources()==source,completedUtc=datetime.now(timezone.utc).isoformat())
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(dict(acceptedDistinct=report['distinctPassed'])),flush=True)
