from pathlib import Path
import json,os,subprocess,re,hashlib
root=Path('E:/Dev/aem');work=root/'.worktrees/native-camera-dof';out=root/'artifacts/pr-queue/native-camera-dof-focus-v4';out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='1');env.pop('MOTION_LOG',None)
def sources():
 paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=work).decode().split('\0')
 return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p.endswith(('.rs','.toml','.wgsl')) or p=='Cargo.lock'}
report=dict(source=sources(),steps=[])
steps=[('model',['cargo','test','-p','motion-model','--test','depth_of_field','--locked','--offline']),('native',['cargo','test','-p','motion-render','--test','scene_gpu','depth_of_field::','--locked','--offline','--','--test-threads=1'])]
steps += [('composition',['cargo','test','-p','motion-render','--test','depth_surface','--test','model_layers','depth_of_field::','--locked','--offline','--','--test-threads=1'])]
for name,command in steps:
 print(json.dumps(dict(start=name)),flush=True)
 with (out/(name+'.stdout.log')).open('wb') as so,(out/(name+'.stderr.log')).open('wb') as se:
  code=subprocess.run(command,cwd=work,env=env,stdout=so,stderr=se).returncode
 row=dict(name=name,exitCode=code,sourceUnchanged=sources()==report['source'],counts=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',(out/(name+'.stdout.log')).read_text(encoding='utf-8')))
 report['steps'].append(row);(out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(row),flush=True)
 if code or not row['sourceUnchanged']:raise SystemExit(1)
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
