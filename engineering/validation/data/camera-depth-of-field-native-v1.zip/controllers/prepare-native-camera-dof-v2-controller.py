from pathlib import Path

directory=Path('E:/Dev/aem/.tools/issue-closure-review')
text=(directory/'validate-native-camera-dof-regression-v1.py').read_text(encoding='utf-8')
text=text.replace("native-camera-dof-regression-v1'", "native-camera-dof-regression-v2'")
text=text.replace('3865b0feca1acc65b8a5d0f96a0ca9684ee26beb', 'e4d6e1425f5440009ad8234230efc9c051b36544')
text=text.replace("'test','-p','motion-desktop','--features'", "'test','-p','motion-desktop','--bin','motion-studio','--features'")
text=text.replace("'test','-p','motion-desktop-media','--features'", "'test','-p','motion-desktop-media','--lib','--features'")
needle='for name,command in steps:\n'
replacement="""steps.insert(1, ('manual-history', ['cargo','test','-p','motion-core','--lib','editor::history_accounting_tests::history_accounting_large_document_measurement','--locked','--offline','--','--ignored','--exact','--test-threads=1']))
steps.insert(5, ('host-aperture', ['cargo','test','-p','motion-host','--test','imported_cameras','--locked','--offline','--','--test-threads=1']))
for name,command in steps:
"""
assert text.count(needle)==1
text=text.replace(needle,replacement)
needle=" if name not in ['desktop','style','provenance']:assert counts and all(int(f)==int(i)==0 for _,f,i in counts),row"
replacement=""" if name not in ['desktop','style','provenance']:
  assert counts and all(int(f)==0 for _,f,_ in counts),row
  if name=='model-core':
   assert sum(int(i) for _,_,i in counts)==1
   assert re.findall(r'^test (\\S+) \\.\\.\\. ignored,.*$', (out/(name+'.stdout.log')).read_text(encoding='utf-8'),re.M)==['editor::history_accounting_tests::history_accounting_large_document_measurement']
  else:assert all(int(i)==0 for _,_,i in counts),row
  assert sum(int(p) for p,_,_ in counts)>0,row
  if name in ['manual-history','frozen','current-main-capture']:assert sum(int(p) for p,_,_ in counts)==1,row"""
assert text.count(needle)==1
text=text.replace(needle,replacement)
needle="report.update(distinctPassed="
replacement="report.update(defaultIgnored=1,unexecutedIgnored=0,explicitlyExecutedIgnored=['editor::history_accounting_tests::history_accounting_large_document_measurement'],distinctPassed="
assert text.count(needle)==1
text=text.replace(needle,replacement)
target=directory/'validate-native-camera-dof-regression-v2.py'
compile(text,str(target),'exec')
target.write_text(text,encoding='utf-8')
print(target)
