from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess

root = Path('E:/Dev/aem')
work = root / '.worktrees/native-camera-dof'
out = root / 'artifacts/pr-queue/native-camera-dof-regression-v1'
controller = root / '.tools/issue-closure-review/validate-native-camera-dof-regression-v1.py'
namespace = {}
# Reuse the original immutable command definitions without executing its loop.
prefix = controller.read_text(encoding='utf-8').split('for name,command in steps:')[0]
prefix = prefix.replace('out.mkdir(exist_ok=False)', 'assert out.is_dir()')
exec(compile(prefix, str(controller), 'exec'), namespace)
report = json.loads((out / 'exit.json').read_text(encoding='utf-8'))
source = report['source']
assert namespace['sources']() == source
assert len(report['steps']) == 1
first = report['steps'][0]
assert first['name'] == 'model-core' and first['exitCode'] == 0 and first['sourceUnchanged']
assert all(int(f) == 0 for _, f, _ in first['counts'])
assert sum(int(i) for _, _, i in first['counts']) == 1
ignored = 'editor::history_accounting_tests::history_accounting_large_document_measurement'
log = (out / 'model-core.stdout.log').read_text(encoding='utf-8')
assert re.findall(r'^test (\S+) \.\.\. ignored,.*$', log, re.M) == [ignored]
steps = [('manual-history', ['cargo', 'test', '-p', 'motion-core', '--lib', ignored,
          '--locked', '--offline', '--', '--ignored', '--exact', '--test-threads=1'])]
steps += namespace['steps'][1:]
for name, command in steps:
    print(json.dumps(dict(start=name)), flush=True)
    with (out / (name + '.stdout.log')).open('wb') as so, (out / (name + '.stderr.log')).open('wb') as se:
        code = subprocess.run(command, cwd=work, env=namespace['env'], stdout=so, stderr=se).returncode
    counts = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored', (out / (name + '.stdout.log')).read_text(encoding='utf-8'))
    row = dict(name=name, command=command, exitCode=code, counts=counts,
               sourceUnchanged=namespace['sources']() == source)
    report['steps'].append(row)
    (out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], name
    if name not in ['desktop', 'style', 'provenance']:
        assert counts and all(int(f) == int(i) == 0 for _, f, i in counts), row
    if name == 'manual-history':
        assert sum(int(p) for p, _, _ in counts) == 1
report.update(distinctPassed=sum(int(p) for step in report['steps'] for p, _, _ in step['counts']),
              sourceUnchanged=namespace['sources']() == source,
              completedUtc=datetime.now(timezone.utc).isoformat(),
              defaultIgnored=1, explicitlyExecutedIgnored=[ignored], unexecutedIgnored=0)
(out / 'accepted.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(dict(acceptedDistinct=report['distinctPassed'], unexecutedIgnored=0)), flush=True)
