"""Retain original integration failures and the bounded successful controls."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path('E:/Dev/aem'); BASE=ROOT/'artifacts/pr-queue'; WORK=ROOT/'.worktrees/prerender-input-priority'
DEST=WORK/'engineering/validation/data';files={}
for name in [*[f'prerender82-main-ac65-check-v{i}' for i in range(1,5)],
        'prerender82-main-ac65-tools-v1','prerender82-main-ac65-native-v1']:
    folder=BASE/name;receipt=json.loads((folder/'receipt.json').read_text(encoding='utf-8'))
    assert receipt['status']!='running' and receipt['source_unchanged']
    for path in folder.iterdir():
        if path.is_file() and path.suffix in {'.json','.log','.py','.diff'}:files[name+'/'+path.name]=path
    controller=BASE/(name+'-controller.py')
    if controller.exists():files[name+'/original-controller.py']=controller
native=json.loads((BASE/'prerender82-main-ac65-native-v1/receipt.json').read_text())
assert native['status']=='selected_controls_passed_not_final_acceptance'
assert sum(s.get('passed',0) for s in native['stages'])==10
for suffix in ['stdout.log','stderr.log']:files['locked-fetch/'+suffix]=BASE/('prerender82-main-ac65-fetch-v1.'+suffix)
for name in ['crates/motion-render/src/renderer.rs','desktop/app/src/engine.rs',
        'desktop/app/src/engine/frame_completion.rs','desktop/app/src/engine/frame_completion/tests/native.rs',
        'desktop/app/src/engine/prerender/tests.rs','desktop/app/src/engine/prerender/signals.rs',
        'desktop/app/src/engine/prerender/tests/input_poll_generation.rs']:
    path=WORK/name
    assert hashlib.sha256(path.read_bytes()).hexdigest()==native['source']['files'][name]
    files['source/'+name]=path
files[Path(__file__).name]=Path(__file__)
archive=DEST/'native-prerender-main-ac65-integration-v1.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for name,path in files.items():z.writestr(name,path.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(files)
    for name,path in files.items():assert z.read(name)==path.read_bytes()
manifest=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    source_head=native['source']['head'],source_diff_sha256=native['source']['diff_sha256'],
    members={n:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for n,p in files.items()},
    limits=['Selected ten controls and complete136-tool discovery; not full workspace or P95 acceptance',
        'Deferred-frame test can return on unsupported driver cache; its optional report was not retained, so blocked-restore activation is not qualified',
        'Original dependency and two compiler failures retained; no runtime or binary redistributed'])
archive.with_suffix('.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:manifest[k] for k in ['archive','bytes','sha256','source_head','source_diff_sha256']}))
