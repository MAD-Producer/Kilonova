"""Check the rebased integration once, retaining the original result."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/prerender-input-priority'
OUT = ROOT / 'artifacts/pr-queue/prerender82-main-ac65-check-v1'
TARGET = ROOT / 'target/depth-wgsl-cache75-contract'
CP = ROOT / 'artifacts/pr-queue/depth75-resume-current.json'
assert shutil.disk_usage(ROOT).free >= 10 << 30
state = json.loads(CP.read_text(encoding='utf-8-sig'))
assert state['versionedCache75']['activeController'] is None
assert not state['versionedCache75']['ownHeavyWorkloads']
assert not {'RUST_MIN_STACK', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'} & os.environ.keys()
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK)
def source():
    paths = set(git('ls-files').decode().splitlines())
    paths.update(git('ls-files', '--others', '--exclude-standard').decode().splitlines())
    return {'head':git('rev-parse','HEAD').decode().strip(),
        'diff_sha256':hashlib.sha256(git('diff','--binary','HEAD')).hexdigest(),
        'files':{p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in sorted(paths)}}
initial = source()
(OUT/'source.diff').write_bytes(git('diff','--binary','HEAD'))
env = {k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
prefix = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(TARGET),
    CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    FFMPEG_DIR=str(prefix), FFMPEG_INCLUDE_DIR=str(prefix/'include'), FFMPEG_LIB_DIR=str(prefix/'lib'),
    LIBCLANG_PATH=str(ROOT/'.tools/python-libclang/clang/native'),
    TEMP=str(TARGET/'tmp'), TMP=str(TARGET/'tmp'), LOCALAPPDATA=str(OUT/'appdata'), RUST_BACKTRACE='full')
env['PATH'] = str(prefix/'bin') + os.pathsep + env['PATH']
command = ['cargo','check','-p','motion-desktop','--tests','--features',
    'ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth','--locked','--offline']
receipt = {'status':'running','pid':os.getpid(),'started_utc':datetime.now(timezone.utc).isoformat(),
    'source':initial,'command':command,'environment':{k:env[k] for k in [
        'CARGO_HOME','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG',
        'CARGO_PROFILE_TEST_DEBUG','FFMPEG_DIR','FFMPEG_INCLUDE_DIR','FFMPEG_LIB_DIR','LIBCLANG_PATH',
        'TEMP','TMP','LOCALAPPDATA','RUST_BACKTRACE']},
    'limits':['Check includes all desktop test compilation; it does not execute native tests',
        'Original native failures remain unresolved; no compiler, stack or backend workaround',
        'Reuses existing owned E target; no cache cleanup or new packages']}
def save():
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
state['versionedCache75']['activeController'] = str(OUT/'controller.py')
state['versionedCache75']['ownHeavyWorkloads'] = [{'controller':os.getpid(),'worktree':str(WORK),'command':command}]
CP.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
save()
try:
    print('start rebased desktop check --tests',flush=True)
    with (OUT/'stdout.log').open('wb') as out, (OUT/'stderr.log').open('wb') as err:
        child = subprocess.Popen(command,cwd=WORK,env=env,stdout=out,stderr=err)
        receipt['child_pid']=child.pid
        save()
        receipt['exit_code']=child.wait()
    receipt['source_unchanged'] = source() == initial
    receipt['status'] = 'passed_check_not_acceptance' if receipt['exit_code']==0 and receipt['source_unchanged'] else 'failed'
except BaseException:
    receipt['status']='controller_failed'
    receipt['traceback']=traceback.format_exc()
    raise
finally:
    receipt['ended_utc']=datetime.now(timezone.utc).isoformat()
    save()
    state=json.loads(CP.read_text(encoding='utf-8-sig'))
    state['versionedCache75']['activeController']=None
    state['versionedCache75']['ownHeavyWorkloads']=[]
    state['prerender82CurrentCheck']={'receipt':str(OUT/'receipt.json'),'status':receipt['status'],'source_head':initial['head']}
    CP.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:receipt.get(k) for k in ['status','exit_code','source_unchanged']}),flush=True)
