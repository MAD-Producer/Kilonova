"""One build and serial actual controls for the changed rebased integration."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, traceback
ROOT=Path('E:/Dev/aem'); WORK=ROOT/'.worktrees/prerender-input-priority'
OUT=ROOT/'artifacts/pr-queue/prerender82-main-ac65-native-v1'
TARGET=ROOT/'target/depth-wgsl-cache75-contract'
CP=ROOT/'artifacts/pr-queue/depth75-resume-current.json'
previous=json.loads((ROOT/'artifacts/pr-queue/prerender82-main-ac65-check-v4/receipt.json').read_text())
assert previous['status']=='passed_check_not_acceptance' and previous['source_unchanged']
assert shutil.disk_usage(ROOT).free>=10<<30
state=json.loads(CP.read_text(encoding='utf-8-sig'))
assert state['versionedCache75']['activeController'] is None and not state['versionedCache75']['ownHeavyWorkloads']
assert not {'RUST_MIN_STACK','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'} & os.environ.keys()
OUT.mkdir(exist_ok=False); (OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def git(*args): return subprocess.check_output(['git',*args],cwd=WORK)
def source():
    names=set(git('ls-files').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines())
    return dict(head=git('rev-parse','HEAD').decode().strip(),diff_sha256=hashlib.sha256(git('diff','--binary','HEAD')).hexdigest(),
        files={n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in sorted(names)})
initial=source(); assert initial==previous['source']
(OUT/'source.diff').write_bytes(git('diff','--binary','HEAD'))
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}; env.update(previous['environment'])
env['LOCALAPPDATA']=str(OUT/'appdata')
env['PATH']=str(Path(env['FFMPEG_DIR'])/'bin')+os.pathsep+env['PATH']
receipt=dict(status='running',pid=os.getpid(),started_utc=datetime.now(timezone.utc).isoformat(),source=initial,stages=[],
    limits=['Actual selected controls, not complete workspace or strict P95 acceptance',
        'Original compiler errors and native failures retained; no stack/backend/compiler workaround',
        'All existing assertions and deadlines retained; no native test skipped by controller'])
def save(): (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
state['versionedCache75']['activeController']=str(OUT/'controller.py')
state['versionedCache75']['ownHeavyWorkloads']=[dict(controller=os.getpid(),worktree=str(WORK))]
CP.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8');save()
def run(name,cmd,expected=None):
    assert source()==initial, 'source changed during verification'
    assert shutil.disk_usage(ROOT).free>=10<<30
    row=dict(name=name,command=[str(v) for v in cmd]);receipt['stages'].append(row);save()
    print('start '+name,flush=True)
    with (OUT/(name+'.stdout.log')).open('wb') as out,(OUT/(name+'.stderr.log')).open('wb') as err:
        child=subprocess.Popen(row['command'],cwd=WORK,env=env,stdout=out,stderr=err)
        row['pid']=child.pid;save();row['exit_code']=child.wait()
    save();print('done '+name+' exit='+str(row['exit_code']),flush=True)
    assert row['exit_code']==0, name+' failed; original outputs retained'
    if expected is not None:
        raw=(OUT/(name+'.stdout.log')).read_text(encoding='utf-8',errors='replace')
        summaries=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw,re.M)
        assert summaries and tuple(map(int,summaries[-1]))==(expected,0,0), 'coverage mismatch: '+str(summaries)
        row['passed']=expected;save()
try:
    run('build',['cargo','test','-p','motion-desktop','--bin','motion-studio','--features',
        'ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth','--locked','--offline','--no-run','--message-format=json'])
    messages=[json.loads(line) for line in (OUT/'build.stdout.log').read_text(encoding='utf-8').splitlines() if line.startswith('{')]
    binaries=[Path(m['executable']) for m in messages if m.get('reason')=='compiler-artifact' and m.get('executable')
        and m['target']['name']=='motion-studio' and m['profile']['test']]
    assert len(binaries)==1
    binary=binaries[0];receipt['binary']=dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest());save()
    cases=[('polling-protocol','engine::prerender::polling_tests::',4,False,False),
        ('controlled-block','diagnostics::tests::in_flight_and_queue_depth_track_a_blocked_worker',1,True,False),
        ('frame-shutdown','engine::frame_completion::tests::shutdown_cancels_pending_replies_but_failure_keeps_the_original_error_identity',1,True,False),
        ('polling-generation','engine::prerender::tests::input_poll_generation::native_polling_present_preserves_input_generations_and_frozen_hold',1,True,True),
        ('input-parking','engine::prerender::tests::input_poll_parking::native_input_parks_optional_timer_after_acknowledgment_and_present_rearms_it',1,True,True),
        ('multiview','engine::prerender::tests::multiview_admission::native_multiview_retires_single_view_warmup_and_recovers_after_single_present',1,True,True),
        ('deferred-input-generation','engine::frame_completion::tests::native::native_pending_frames_complete_without_resampling_or_starving_edits_and_cancel_stale_work',1,True,False)]
    for name,case,count,exact,ignored in cases:
        run(name,[binary,case,'--nocapture','--test-threads=1']+(['--exact'] if exact else [])+(['--ignored'] if ignored else []),count)
    receipt['status']='selected_controls_passed_not_final_acceptance'
except BaseException:
    receipt['status']='failed';receipt['traceback']=traceback.format_exc();raise
finally:
    receipt['source_unchanged']=source()==initial;receipt['ended_utc']=datetime.now(timezone.utc).isoformat();save()
    state=json.loads(CP.read_text(encoding='utf-8-sig'));state['versionedCache75']['activeController']=None;state['versionedCache75']['ownHeavyWorkloads']=[]
    state['prerender82NativeCurrent']={'receipt':str(OUT/'receipt.json'),'status':receipt['status'],'source_head':initial['head']}
    CP.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:receipt.get(k) for k in ['status','source_unchanged']}),flush=True)
