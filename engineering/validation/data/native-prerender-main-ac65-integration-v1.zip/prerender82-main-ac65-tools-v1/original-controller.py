from pathlib import Path
import subprocess,json,os,sys,hashlib,datetime
R=Path('E:/Dev/aem');S=R/'.worktrees/prerender-input-priority';O=R/'artifacts/pr-queue/prerender82-main-ac65-tools-v1';O.mkdir(exist_ok=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();assert head.startswith('ae5c1e18')
files=subprocess.check_output(['git','ls-files','tools'],cwd=S,text=True).splitlines();hashes={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in files};env=os.environ.copy();env.update(TEMP=str(O),TMP=str(O),PYTHONDONTWRITEBYTECODE='1');cmd=[sys.executable,'-B','-m','unittest','discover','-s','tools','-p','test_ci_*.py','-v']
j=dict(status='running',head=head,scope='Complete unchanged CI Python discovery on rebased integration; native gates remain separate',command=cmd,source_hashes=hashes)
def save():(O/'receipt.json').write_text(json.dumps(j,indent=2),encoding='utf-8')
save()
with (O/'stdout.log').open('xb') as a,(O/'stderr.log').open('xb') as b:
 c=subprocess.Popen(cmd,cwd=S,env=env,stdout=a,stderr=b);j['pid']=c.pid;save();j['exit_code']=c.wait()
j.update(status='passed' if j['exit_code']==0 else 'failed',source_unchanged=all(hashlib.sha256((S/n).read_bytes()).hexdigest()==v for n,v in hashes.items()),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(json.dumps({k:j.get(k) for k in ['status','exit_code','source_unchanged']}));print((O/'stderr.log').read_text(encoding='utf-8',errors='replace')[-2200:])
