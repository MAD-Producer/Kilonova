"""One owner: native cancellation/resumption controls, then media regression."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/native-prerender-runtime'
OUT = ROOT / 'artifacts/pr-queue/prerender-cache-resume-v1'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()

def sources():
    paths = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {p: hashlib.sha256((WORK / p).read_bytes()).hexdigest() for p in paths if p and
            (p.endswith(('.rs', '.toml', '.wgsl', '.py', '.json', '.yml', '.yaml')) or p == 'Cargo.lock')}

assert not git('status', '--porcelain')
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'controller.py')
source = sources()
report = dict(head=git('rev-parse', 'HEAD'), source=source, status='running', steps=[])
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0',
           CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
test = ['cargo','test','-p','motion-desktop-media','--features','ffmpeg,ai-depth','--locked','--offline']
steps = [
    ('coordinator', [*test,'--lib','movie::prerender::coordinator::','--','--test-threads=1'], 5),
    ('media-regression', [*test,'--','--test-threads=1'], None),
    ('desktop-check', ['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'], 0),
    ('provenance', ['python','tools/validate_provenance.py'], 0),
]
for name, args, expected in steps:
    print(json.dumps(dict(start=name)), flush=True)
    with (OUT / (name + '.stdout.log')).open('wb') as so, (OUT / (name + '.stderr.log')).open('wb') as se:
        code = subprocess.run(args, cwd=WORK, env=env, stdout=so, stderr=se).returncode
    stdout = (OUT / (name + '.stdout.log')).read_text(encoding='utf-8')
    counts = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored', stdout)
    row = dict(name=name, command=args, exitCode=code, counts=counts, sourceUnchanged=sources() == source,
               ignoredTests=re.findall(r'^test (\S+) \.\.\. ignored(?:, (.*))?$', stdout, re.M))
    report['steps'].append(row)
    (OUT / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], row
    if expected != 0:
        assert counts and all(int(f) == 0 for _, f, _ in counts), row
        passed = sum(int(p) for p, _, _ in counts)
        assert passed > 0 and (expected is None or passed == expected), row
        if expected: assert all(int(i) == 0 for _, _, i in counts), row
report.update(status='accepted', sourceUnchanged=sources() == source, completedUtc=datetime.now(timezone.utc).isoformat(),
              scope='Native coordinator cancellation after publication, retained exact pixels after matching frozen-source acknowledgment, and changed content rejection. Engine runtime and P95 remain pending; capability false. Focused counts overlap full media regression.')
(OUT / 'accepted.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True)), flush=True)
