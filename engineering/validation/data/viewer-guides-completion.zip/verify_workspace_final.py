from pathlib import Path
import subprocess,json,hashlib,time,importlib.util,sys,re
root=Path('E:/Dev/aem');work=root/'.worktrees/viewer-guides';out=root/'.tools/viewer-guides'
stage_name=sys.argv[1];prior=out/stage_name
r=json.loads((prior/'receipt.json').read_text(encoding='utf8'));n=json.loads((prior/'native-verified.json').read_text(encoding='utf8'))
assert r['build_exit_code']==0 and r['source_unchanged'] and all(run['exit_code']==0 for run in r['runs']) and n['png_count']==22
folder=out/('workspace-final-'+stage_name);folder.mkdir(exist_ok=False)
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in r['sources']}
assert freeze()==r['sources']
spec=importlib.util.spec_from_file_location('ci_desktop_guide_gate',work/'tools/ci_desktop.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.verify_style_consumers(work/'desktop/app/src/panels')
features='motion-host/diagnostics,motion-host/gpu-tests,motion-ui/gpu-tests,motion-desktop/gpu-tests,motion-desktop/ffmpeg,motion-desktop-media/gpu-tests,motion-graph/gpu-tests,motion-render/gpu-tests'
commands=[('all-targets',['cargo','check','--workspace','--exclude','motion-android','--all-targets','--features',features,
 '--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1']),
 ('guide-model',['cargo','test','-p','motion-core','--test','viewer_guides','--locked','--offline','-j1','--','--test-threads=1']),
 ('history',['cargo','test','-p','motion-core','--lib','history_accounting_tests::','--locked','--offline','-j1','--','--test-threads=1'])]
records=[]
for name,command in commands:
 start=time.monotonic();print(name+' started',flush=True)
 with (folder/(name+'.log')).open('w',encoding='utf8') as sink: result=subprocess.run(command,cwd=work,stdout=sink,stderr=subprocess.STDOUT)
 text=(folder/(name+'.log')).read_text(encoding='utf8');summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
 record=dict(name=name,command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),summary=summary);records.append(record);print(json.dumps(record),flush=True)
 if result.returncode:break
record=dict(stage=stage_name,head=r['head'],base_main=r['base_main'],style_consumers_passed=True,runs=records,
 source_unchanged=freeze()==r['sources'],binary_sha256=n['binary_sha256'],
 scope='Current full-workspace all-target compilation and actual guide/history model regressions. Desktop behavior uses the separately recorded native and targeted runs.')
(folder/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8')
assert len(records)==3 and all(record['exit_code']==0 for record in records) and record['source_unchanged']
