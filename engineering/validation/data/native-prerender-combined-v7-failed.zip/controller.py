"""One frozen current-main source: static hints, native ownership, P95 and full gate."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import ctypes
from ctypes import wintypes

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/native-prerender-runtime'
OUT = ROOT / 'artifacts/pr-queue/prerender-combined-v7'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()

def sources():
    return {p: hashlib.sha256((WORK / p).read_bytes()).hexdigest()
            for p in git('ls-files', '-z').split('\0')
            if p and (p.endswith(('.rs', '.toml', '.wgsl', '.py', '.json', '.yml', '.yaml', '.md')) or p == 'Cargo.lock')}

# Prior exact-source failures remain failures; this source combines actual
# source invalidation/input fixes and rebases every commit onto latest main.
assert git('rev-parse','HEAD') == '8bb44d4a81f67f693a20e7bc3c067a987d37cb31'
assert git('rev-parse','origin/main') == '49890ce0da7d7701eaec5e521d749b562d3ffd47'
previous=json.loads((ROOT/'artifacts/pr-queue/prerender-combined-v6/exit.json').read_text(encoding='utf-8'))
assert previous['status']=='failed' and previous.get('completedUtc')
assert git('rev-parse','HEAD')!=previous['head']
active=subprocess.check_output(['powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('rustc.exe','link.exe') -and $_.CommandLine -match 'gltf-animation87-contract' }).Count"]).decode().strip()
assert active=='0',f'owned serial target still active: {active}'
assert not git('status', '--porcelain')
assert git('merge-base', 'HEAD', 'origin/main') == git('rev-parse', 'origin/main')
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'controller.py')
source = sources()
report = dict(head=git('rev-parse', 'HEAD'), base=git('rev-parse', 'origin/main'),
              source=source, status='running', steps=[],
              limits='Current optional disk cache, quota/reopen repair, input phase instrumentation and integrated fault-order/procedural watcher/queued upload/quiet foreground source on main49890ce0. All earlier native and strict performance failures remain failed; a later pass cannot establish their cause or fix. Real bounded Linux ENOSPC is a separate CI gate; physical low-memory and final cross-platform qualification remain outside this local gate; this is not whole issue82 completion. Android retired; no existing assertion or performance criterion weakened.')
report['controllerPid']=os.getpid()
report['priorCombinedFailure']={k:previous.get(k) for k in ('head','status','completedUtc')}
report['startedUtc']=datetime.now(timezone.utc).isoformat()
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(PYTHONPATH=str(ROOT/'.tools/build-validation-python'), MOTION_PRERENDER_DISK_LOG_ARTIFACTS=str(OUT/'default-disk-logs'), CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0',
           CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT / 'owned-profile'),
           MOTION_PRERENDER_STATIC_ARTIFACTS=str(OUT / 'native-static'),
           MOTION_PRERENDER_ENGINE_ARTIFACTS=str(OUT / 'native-idle'),
           MOTION_PRERENDER_PLAYBACK_ARTIFACTS=str(OUT / 'native-gap'),
           MOTION_PRERENDER_BLOCKED_ARTIFACTS=str(OUT / 'native-blocked'),
           MOTION_PRERENDER_LIFECYCLE_ARTIFACTS=str(OUT / 'native-pressure'),
           MOTION_PRERENDER_PACED_ARTIFACTS=str(OUT / 'paced'),
           MOTION_PRERENDER_REFRESH_ARTIFACTS=str(OUT / 'native-refresh'),
           MOTION_PRERENDER_PRIORITY_ARTIFACTS=str(OUT/'native-priority'),
           MOTION_PRERENDER_SOURCE_ARTIFACTS=str(OUT/'native-source'),
           MOTION_PRERENDER_INPUT_ARTIFACTS=str(OUT/'input'),
           MOTION_SOURCE_WATCH_LOG_ARTIFACTS=str(OUT/'default-source-logs'),
           MOTION_CURVE_RANGE_FAULT_ARTIFACTS=str(OUT / 'workspace-graph-faults'))
Path(env['LOCALAPPDATA']).mkdir()


def save():
    temporary = OUT / 'exit.next.json'
    temporary.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(temporary, OUT / 'exit.json')

def retain_native(name, text):
    # Inspect both channels. Rust's UB precondition and child stack-overflow
    # reports may be in stdout even when Cargo itself returns ordinary 101.
    triggers = re.findall(r'(?im)^.*(?:0xc000[0-9a-f]+|unsafe precondition|non-unwinding panic|stack overflow|STATUS_(?:ACCESS|ILLEGAL|STACK|HEAP)).*$', text)
    if not triggers:
        return
    deps = (ROOT/'target/gltf-animation87-contract/debug/deps').resolve()
    paths = set()
    for raw in re.findall(r'([A-Za-z]:[^\r\n`"<>]*?\.exe)', text):
        path = Path(raw.strip().lstrip('(')).resolve()
        if path.parent == deps and path.is_file():
            paths.add(path)
    preferred = sorted(paths, key=lambda p: (not p.name.startswith(('motion_studio-', 'motion_render-')), p.name))[:8]
    record = dict(step=name, observedUtc=datetime.now(timezone.utc).isoformat(),
                  signals=triggers[:32], candidateCount=len(paths), files=[],
                  limits='At most eight current step-owned EXE/PDB candidates; presence in logs does not establish the faulting test or thread. Copies are made before any later build.')
    for path in preferred:
        for original in (path, path.with_suffix('.pdb'), path.with_suffix('.d')):
            if not original.is_file():
                continue
            destination=OUT/'native-failures'/name/original.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            before=hashlib.sha256(original.read_bytes()).hexdigest()
            shutil.copyfile(original,destination)
            after=hashlib.sha256(destination.read_bytes()).hexdigest()
            assert before==after
            record['files'].append(dict(original=str(original),preserved=str(destination),sha256=after,bytes=destination.stat().st_size))
    report.setdefault('nativeFailureEvidence', []).append(record)
    save()

def step(name, args, expected=None, tests=False, required=True):
    began = datetime.now(timezone.utc)
    active = dict(name=name, command=args, startedUtc=began.isoformat(), phase='starting')
    report['activeStep'] = active
    save()
    print(json.dumps(dict(start=name, head=report['head'])), flush=True)
    with (OUT/(name+'.stdout.log')).open('wb') as stdout, (OUT/(name+'.stderr.log')).open('wb') as stderr:
        child = subprocess.Popen(args, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        active.update(pid=child.pid,phase='running')
        save()
        code=child.wait()
    # Persist the actual process result BEFORE parsing, hashing or copying.
    active.update(phase='exited',exitCode=code,completedUtc=datetime.now(timezone.utc).isoformat())
    save()
    text=(OUT/(name+'.stdout.log')).read_text(encoding='utf-8')
    errors=(OUT/(name+'.stderr.log')).read_text(encoding='utf-8')
    counts=re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', text)
    good_counts = not tests or bool(counts) and all(int(f)==0 for p,f,i in counts) and sum(int(p) for p,f,i in counts)>0
    if expected is not None:
        target=(expected,0,0) if isinstance(expected,int) else expected
        good_counts=counts==[tuple(map(str,target))]
    row=dict(name=name,command=args,exitCode=code,counts=counts,
             startedUtc=began.isoformat(),completedUtc=active['completedUtc'],
             sourceUnchanged=sources()==source and git('rev-parse','HEAD')==report['head'],
             ignoredTests=re.findall(r'^test (\S+) \.\.\. ignored(?:, (.*))?$',text,re.M))
    row['passed']=code==0 and good_counts and row['sourceUnchanged']
    report['steps'].append(row)
    if not row['passed']:
        report['status']='failed'
    save()
    retain_native(name,text+'\n'+errors)
    report.pop('activeStep',None)
    save()
    print(json.dumps({k:v for k,v in row.items() if k!='ignoredTests'}),flush=True)
    assert row['sourceUnchanged'],'source changed during validation'
    if required:
        assert row['passed'],name

save()
try:
    # Refresh only roots of changed packages when switching shared-target trees.
    touched=[]
    for relative in ['crates/motion-render/src/lib.rs','crates/motion-desktop-media/src/lib.rs','desktop/app/src/main.rs']:
        path=WORK/relative; old=path.stat().st_mtime_ns;os.utime(path,None)
        touched.append(dict(path=relative,beforeMtimeNs=old,afterMtimeNs=path.stat().st_mtime_ns))
    assert sources()==source
    report['timestampOnlyBuildRefresh']=touched;save()
    render=['cargo','test','-p','motion-render','--locked','--offline','--lib']
    media=['cargo','test','-p','motion-desktop-media','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--lib']
    step('render-source-inventory',render+['--','--list'])
    listing=(OUT/'render-source-inventory.stdout.log').read_text(encoding='utf-8')
    for name in ['queued_native_upload_and_foreground_copy_share_one_submission_in_all_four_precisions','unsubmitted_native_upload_retains_budget_after_eviction_until_a_real_flush','queued_native_upload_rejects_bad_contract_and_foreign_owner_before_queue_io']:
        assert name+': test' in listing
    step('media-source-inventory',media+['--','--list'])
    listing=(OUT/'media-source-inventory.stdout.log').read_text(encoding='utf-8')
    for name in ['a_normal_change_cannot_hide_a_later_watcher_fault_before_retirement','procedural_sources_do_not_require_an_os_watcher_and_keep_real_job_lifetimes','native_install_keeps_default_foreground_quiet_and_preserves_worker_start']:
        assert name+': test' in listing
    report['integratedTestInventoriesConfirmed']=True;save()
    # These run once normally on changed combined source; not an unchanged retry.
    # Independent later gates are still collected if this target fails.
    step('integrated-native-cache',render+['renderer::composition_frames::','--','--test-threads=1'],tests=True,required=False)
    step('integrated-queued-four-precision',render+['renderer::composition_frames::native::tests::deferred::queued_native_upload_and_foreground_copy_share_one_submission_in_all_four_precisions','--','--ignored','--exact','--test-threads=1'],expected=1,required=False)
    step('host-scheduling', ['cargo', 'test', '-p', 'motion-host', '--features', 'ai-depth', '--locked', '--offline', '--lib', 'prerender::', '--', '--test-threads=1'], expected=19)
    step('media-prerender', ['cargo', 'test', '-p', 'motion-desktop-media', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--lib', 'movie::prerender::', '--', '--test-threads=1'], expected=(63,0,3), required=False)

    step('disk-storage', media+['movie::prerender::disk::tests::','--','--test-threads=1'],expected=(12,0,0),required=False)
    step('disk-worker', media+['movie::prerender::worker::tests::disk_cache::','--','--test-threads=1'],expected=(4,0,2),required=False)
    step('disk-native-foreground', media+['movie::prerender::coordinator::tests::disk_cache::','--','--test-threads=1'],expected=1,required=False)
    step('disk-four-native-precisions', media+['movie::prerender::worker::tests::disk_cache::disk_warm_worker_preserves_all_four_actual_native_precision_layouts','--','--ignored','--exact','--test-threads=1'],expected=1,required=False)
    step('native-four-precision-producer', ['cargo', 'test', '-p', 'motion-desktop-media', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--lib', 'movie::prerender::tests::all_four_precisions_keep_native_storage_and_existing_exposure_policies', '--', '--ignored', '--exact', '--test-threads=1'], expected=1)
    step('paced-parser', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_ci_prerender_paced.py'])

    desktop = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--bin', 'motion-studio']
    step('default-disk-failure-sinks',desktop+['engine::pending_video_tests::prerender_disk_logging::actual_disk_open_failure_escalates_once_at_default_file_and_stderr_without_stdout','--','--exact','--test-threads=1'],expected=1,required=False)
    step('headless-disk-policy',desktop+['mcp::prerender_tests::disk_cache::disk_policy_is_optional_bounded_read_only_guarded_and_does_no_headless_io','--','--exact','--test-threads=1'],expected=1,required=False)
    for label, name in [
        ('native-priority','engine::prerender::tests::input_priority::native_input_preempts_before_action_generation_and_waits_for_its_present'),
        ('native-source','engine::prerender::tests::source_freshness::native_source_change_bypasses_blocked_engine_and_replaces_cached_pixels_without_edit'),
        ('native-refresh', 'engine::prerender::tests::foreground_refresh::native_edit_waits_for_foreground_refresh_before_warming_its_revision'),
        ('native-static', 'engine::prerender::tests::static_window::native_static_window_reduces_work_and_warms_the_changed_frame_at_a_clip_cut'),
        ('native-gap', 'engine::prerender::tests::playback::native_playback_ignores_idle_delay_and_presents_a_warm_exact_frame'),
        ('native-pressure', 'engine::prerender::tests::pressure_lifecycle::native_pressure_holds_admission_and_project_reopen_preserves_pixel_ownership'),
        ('native-blocked', 'engine::pending_video_tests::prerender_runtime::blocked_prerender_is_observable_and_canceled_before_a_foreground_handler_runs'),
        ('native-idle', 'engine::prerender::tests::native_idle_owner_presents_a_warm_frame_and_rejects_an_edited_source'),
    ]:
        step(label, [*desktop, name, '--', '--ignored', '--exact', '--test-threads=1'], expected=1)
    step('native-precision', ['cargo', 'test', '-p', 'motion-render', '--locked', '--offline', '--lib',
         'renderer::composition_frames::native::tests::all_four_native_completion_uploads_preserve_encoded_storage_hdr_negative_and_alpha',
         '--', '--ignored', '--exact', '--test-threads=1'], expected=1)
    step('input-parser-controls',[sys.executable,'-m','unittest','discover','-s','tools','-p','test_ci_prerender_input.py'])
    step('native-input',[*desktop,'engine::prerender::tests::input_latency::native_controls_record_edit_and_scrub_latency_with_real_optional_work','--','--ignored','--exact','--test-threads=1'],expected=1,required=False)
    step('input-assessment',[sys.executable,'tools/analyze_prerender_input.py',str(OUT/'input/input-costs.json'),'--output',str(OUT/'input-assessment.json')],required=False)
    step('paced', [*desktop, 'engine::prerender::tests::performance::paced_model_playback_records_paired_foreground_costs_and_real_cache_hits',
         '--', '--ignored', '--exact', '--test-threads=1'], expected=1, required=False)
    spec = importlib.util.spec_from_file_location('paced_evidence', WORK / 'tools/analyze_prerender_paced.py')
    analyzer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analyzer)
    try:
        assessment = analyzer.assess(json.loads((OUT / 'paced/paced-costs.json').read_text(encoding='utf-8')))
    except (ValueError, OSError, KeyError, TypeError) as error:
        assessment = dict(noRegression=False, invalidEvidence=str(error))
    (OUT / 'paced-assessment.json').write_text(json.dumps(assessment, indent=2), encoding='utf-8')
    report['pacedAssessment'] = assessment
    if not assessment['noRegression']:
        report['status'] = 'p95_regression'
    save()
    # Always collect the independent full gate. A failed paired criterion still
    # prevents acceptance; it must not starve workspace/startup diagnostics.
    step('workspace-regression', ['cargo', 'test', '--workspace', '--exclude', 'motion-android',
         '--features', 'motion-desktop/ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--no-fail-fast', '--', '--test-threads=1'], tests=True, required=False)
    step('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline'], required=False)
    step('desktop-build', ['cargo', 'build', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--bin', 'motion-studio'])
    (OUT / 'shared-mcp').mkdir()
    step('shared-mcp', [sys.executable, '-c', "import sys; from pathlib import Path; sys.path.insert(0,'tools'); import ci_desktop; ci_desktop.verify_mcp(Path(sys.argv[1]),Path(sys.argv[2]))",
         str(ROOT / 'target/gltf-animation87-contract/debug/motion-studio.exe'), str(OUT / 'shared-mcp')], required=False)
    step('provenance', [sys.executable, 'tools/validate_provenance.py'], required=False)
    step('tool-inventory', [sys.executable, 'tools/validation_inventory.py'], required=False)
    report.update(status='accepted' if assessment['noRegression'] and all(s['passed'] for s in report['steps']) else 'failed', completedUtc=datetime.now(timezone.utc).isoformat())
    save()
    if report['status'] == 'accepted':
        (OUT / 'accepted.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(dict(status=report['status'])), flush=True)
    raise SystemExit(0 if report['status'] == 'accepted' else 1)
except BaseException:
    if report['status']!='accepted':
        report.update(status='failed',completedUtc=datetime.now(timezone.utc).isoformat());save()
    raise
