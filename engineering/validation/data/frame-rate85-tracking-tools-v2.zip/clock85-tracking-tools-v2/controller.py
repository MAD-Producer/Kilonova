from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,time

root=Path('E:/Dev/aem');work=root/'.worktrees/rational-frame-rates85';out=root/'artifacts/pr-queue/clock85-tracking-tools-v2';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
assert git('rev-parse','HEAD')=='6f845f1829b773d1dc3b17d65111dc68140a3ddd' and not git('status','--porcelain')
sha=lambda b:hashlib.sha256(b).hexdigest()
source={n:sha((work/n).read_bytes()) for n in git('ls-files','crates','desktop','Cargo.toml','Cargo.lock').splitlines() if (work/n).is_file() and n.endswith(('.rs','.wgsl','Cargo.toml','Cargo.lock'))}
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(LOCALAPPDATA=str(out/'appdata'),MOTION_TRACKED_RPC_DIR=str(out),MOTION_TRACKED_SURFACE_ARTIFACTS=str(out/'surface'))
common=['--locked','--offline'];native=['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg']+common
commands=[('check',['cargo','check','-p','motion-host','-p','motion-desktop','--features','motion-desktop/ffmpeg','--all-targets']+common),
('tests',native+['mcp::tracked_video::tests::','--','--test-threads=1','--nocapture']),
('surface',native+['engine::tracking_video_replacement_tests::paired::surface::tracked_plate_replacement_invalidates_actual_surface_front_and_history_retains_reuse','--','--exact','--test-threads=1','--nocapture']),
('build',['cargo','build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg']+common)]
prior=json.loads((root/'artifacts/pr-queue/clock85-tracking-tools-v1/exit.json').read_text())
assert prior['steps'][0]['exitCode']==0 and prior['steps'][1]['exitCode']==101 and not prior['steps'][1]['summaries']
commands=commands[1:]
for phase,command in commands:
    if phase!='build':command.extend(['--config','profile.test.package.motion-desktop.codegen-units=4']) if '--' not in command else command.__setitem__(slice(command.index('--'),command.index('--')),['--config','profile.test.package.motion-desktop.codegen-units=4'])
report=dict(priorCheck=prior['steps'][0],codegenUnits=4,status='running',head=git('rev-parse','HEAD'),main=git('rev-parse','origin/main'),source=source,steps=[],startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Combined rational clock, parameter API and merged tracking MCP/Surface sources; scoped acceptance, not full desktop/workspace','Default Info; one local diagnostic build changes only desktop test codegen units to4 to limit LLVM parallel work. No source/assertion/threshold/ignore/timeout change; prior default compiler AV remains uncorrected; not proof of its cause. Existing E app-local runtime; one own GPU workload'])
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
try:
 for phase,command in commands:
    row=dict(phase=phase,command=command);report['steps'].append(row);save()
    with (out/f'{phase}.stdout.log').open('wb') as stdout,(out/f'{phase}.stderr.log').open('wb') as stderr:
        p=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait()
    row['summaries']=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',(out/f'{phase}.stdout.log').read_text(encoding='utf-8',errors='replace'));save()
    assert row['exitCode']==0,(phase,row)
    if phase in ['tests','surface']:
        assert row['summaries'] and all(s[0]=='ok' and s[2]=='0' and s[3]=='0' for s in row['summaries'])
        assert sum(int(s[1]) for s in row['summaries'])==dict(tests=3,surface=1)[phase]
    print(json.dumps(row),flush=True)
 assert all(sha((work/n).read_bytes())==h for n,h in source.items())
 binary=root/'target/rational-rate85-contract/debug/motion-studio.exe'
 runtime=root/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
 report['appLocalRuntime']=[]
 for name in ['avutil-60.dll','swresample-6.dll','swscale-9.dll','avcodec-62.dll','avformat-62.dll']:
    src=runtime/name;dest=binary.parent/name
    if dest.exists():assert sha(dest.read_bytes())==sha(src.read_bytes()),dest
    else:shutil.copy2(src,dest)
    report['appLocalRuntime'].append(dict(file=name,sha256=sha(dest.read_bytes())))
 report.update(status='focused_controls_and_native_binary_build_passed',sourceUnchanged=True,binarySha256=sha(binary.read_bytes()))
except BaseException as cause:report.update(status='failed_original_outputs_retained',failure=repr(cause));raise
finally:report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3));save()
