"""Actual textured plane/mesh depth regression, with frozen source and retained failures."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys

root = Path('E:/Dev/aem')
work = root / '.worktrees/shared-model-catalog'
out = root / 'artifacts/pr-queue/instance-camera-world-native-v2'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
out.mkdir(exist_ok=False)
paths = subprocess.check_output(['git', 'ls-files', '-co', '--exclude-standard', '-z'], cwd=work).decode().split('\0')
source = {p: sha(work / p) for p in sorted(set(paths)) if p and (p.endswith(('.rs', '.py', '.toml', '.wgsl', '.json')) or p == 'Cargo.lock')}
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=work).decode().splitlines()
changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=work).decode().splitlines()
for p in changed:
    dest = out / 'source' / p
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(work / p, dest)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_NET_OFFLINE='true')
env.pop('MOTION_LOG', None)
receipt = dict(startedUtc=datetime.now(timezone.utc).isoformat(), source=source, changedSource=changed,
               existingAssertionsUnchanged=True, steps=[], scope='Imported camera composition-world prefix, original animation/units/aspect, invalid-transform refusal and actual native covariance in four precisions at 1x/4x')
targets = ['scene_gpu', 'model_layers', 'multiple_camera_compositions', 'spatial_effects', 'exposure_frame']
native = ['cargo','test','-p','motion-render','--features','gpu-tests']
for target in targets: native.extend(['--test',target])
native.extend(['--locked','--offline','--no-fail-fast','--','--test-threads=1'])
steps = [('provenance',[sys.executable,'tools/validate_provenance.py']),
 ('scene',['cargo','test','-p','motion-scene','--locked','--offline','--','--test-threads=1']),
 ('native',native),
 ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'])]
for name, cmd in steps:
    print(json.dumps(dict(start=name)), flush=True)
    with (out / (name + '.stdout.log')).open('wb') as so, (out / (name + '.stderr.log')).open('wb') as se:
        code = subprocess.run(cmd, cwd=work, env=env, stdout=so, stderr=se).returncode
    row = dict(name=name, command=cmd, exitCode=code, sourceUnchanged=all(sha(work / p) == h for p, h in source.items()))
    text = (out / (name + '.stdout.log')).read_text(encoding='utf-8')
    if name in ['native','scene']:
        results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
        row.update(targets=len(results), totals=dict(zip(('passed', 'failed', 'ignored'), [sum(int(v[i]) for v in results) for i in range(3)])))
    receipt['steps'].append(row)
    (out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], name
    if name == 'native':
        assert row['targets'] == len(targets) and row['totals']['failed'] == 0 and row['totals']['ignored'] == 0
        assert 'test cameras::imported_camera_and_model_instance_move_together_without_changing_pixels_or_depth ... ok' in text
    if name == 'scene':
        assert row['totals']['failed'] == 0 and row['totals']['ignored'] == 0
        for test in ['instance_camera_prefix_preserves_projection_clipping_and_authored_aspect','instance_camera_prefix_composes_after_units_and_independent_animation','invalid_instance_camera_prefix_refuses_without_changing_owned_source']:
            assert 'test ' + test + ' ... ok' in text
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=True)
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True, totals=next(s['totals'] for s in receipt['steps'] if s['name'] == 'native'))), flush=True)

