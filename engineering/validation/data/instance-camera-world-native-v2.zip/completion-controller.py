from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile
root=Path("E:/Dev/aem")
work=root/".worktrees/shared-model-catalog"
gate=root/"artifacts/pr-queue/instance-camera-world-native-v2"
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((gate/"accepted.json").read_text(encoding="utf-8"))
assert r["sourceUnchanged"] and all(sha(work/p)==h for p,h in r["source"].items())
assert all(s["exitCode"]==0 and s["sourceUnchanged"] for s in r["steps"])
native=next(s for s in r["steps"] if s["name"]=="native")
assert native["targets"]==5 and native["totals"]["failed"]==0 and native["totals"]["ignored"]==0
out=root/"artifacts/pr-queue/instance-camera-world-complete-v1"
out.mkdir(exist_ok=False)
archive=work/"engineering/validation/data/instance-camera-world-native-v2.zip"
payload={p.relative_to(gate).as_posix():p.read_bytes() for p in gate.rglob("*") if p.is_file()}
old=root/"artifacts/pr-queue/instance-camera-world-native-v1"
for p in old.rglob("*"):
 if p.is_file(): payload["previous-attempt/"+p.relative_to(old).as_posix()]=p.read_bytes()
payload["completion-controller.py"]=Path(__file__).read_bytes()
payload["source.patch"]=subprocess.check_output(["git","diff","--binary"],cwd=work)
manifest={k:{"bytes":len(v),"sha256":hashlib.sha256(v).hexdigest()} for k,v in payload.items()}
with zipfile.ZipFile(archive,"x",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for k,v in payload.items(): z.writestr(k,v)
 z.writestr("manifest.json",json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(manifest)+1
 for k,v in manifest.items():
  data=z.read(k)
  assert len(data)==v["bytes"] and hashlib.sha256(data).hexdigest()==v["sha256"]
scene=next(s for s in r["steps"] if s["name"]=="scene")
assert scene["totals"]["failed"]==0 and scene["totals"]["ignored"]==0
doc=work/"engineering/validation/instance-camera-world-current.md"
doc.write_text(f"""# Imported camera instance-world sampling

## Implemented

`camera_view_in_world` samples the explicitly selected source node and original
animation in pixels, then composes the same affine world prefix that the model
instance uses. The prefix includes the caller's model-layer hierarchy and pivot;
it does not bake camera animation into Euler tracks. `CameraView.world` exposes
the resulting orthonormal camera transform for semantic hierarchy integration.
The earlier `camera_view` API delegates with identity, preserving source units,
projection, clipping and authored aspect/viewport. Per glTF, camera scale is
ignored; collapsed, sheared, reflected, nonfinite or projective camera frames
are explicitly refused. Shared native depth attachments also expose TEXTURE_BINDING for original depth
samples at 1x/4x, after explicit usage capability validation, without a depth
resolve or additional texture allocation. Existing byte admission is unchanged.
No camera is automatically selected and no healthy
frame-time logs or file reads are introduced.

## Source-bound acceptance

The complete motion-scene suite has **{scene['totals']['passed']} passed, 0 failed,
0 ignored** across {scene['targets']} targets including doc tests. Affected native
renderer acceptance has **{native['totals']['passed']} passed, 0 failed, 0 ignored**
across five targets: model layers, scene GPU, multiple-camera compositions,
spatial effects and exposure frames. Desktop FFmpeg/AI-depth compilation and
provenance verification also pass. These are distinct scope counts, not a
full-workspace or cross-platform result. Earlier checkpoint totals overlap and
must not be summed as new coverage.

The first native attempt has 105 passed and one failed new test: its helper
incorrectly tries to copy multisampled depth through the single-sample-only
reader. That raw failure is retained. The helper now reads all four actual depth
samples through a compute shader; every sample remains compared without a
relaxed threshold or omitted MSAA case. No existing test helper/assertion changes.

Three new CPU tests cover perspective/orthographic coordinate covariance,
unchanged clipping and aspect, independent animation time, units and pivot
ordering, invalid-prefix refusal and recovery with the same owned source.
The new native GPU test moves an actual model and camera together through a
90-degree basis rotation and translation. Color bytes match the independently
rendered original in four working precisions at 1x/4x MSAA, and actual depth is
compared at the existing depth-test tolerance of 1e-6. Original assertions,
timeouts and budgets are unchanged; no old test is skipped or relaxed.

## Remaining integration

This is the imported-camera world transform boundary, not saved project camera
activation. The shared CPU catalog, saved selection, semantic hierarchy and
camera viewport must still be wired through initial/no-GPU host sampling,
replacement/undo, composition-local nested/exposure clocks, preview, and actual
capture/export. Fixed imported aspect must preserve clipping/letterboxing for
all scene consumers rather than only the mesh pass. Persisted current-frame
depth calibration, reprojection/DOF and intersecting transparency also remain.
Neither #74 nor #87 is closed. No UI/panels/styles, dependencies or third-party
assets change; Android is retired and excluded.

[Source-bound acceptance](data/instance-camera-world-native-v2.zip), SHA-256
`{sha(archive)}`, {archive.stat().st_size} bytes. Entries are read back and
hash-verified, with the exact source snapshot and native logs retained.
""",encoding="utf-8",newline="\n")
subprocess.run(["git","diff","--check"],cwd=work,check=True)
subprocess.run(["git","diff","--stat"],cwd=work,check=True)
paths=r["changedSource"]+[doc.relative_to(work).as_posix(),archive.relative_to(work).as_posix()]
assert not any(p.startswith("desktop/app/src/panels/") for p in paths)
subprocess.run(["git","add","--",*paths],cwd=work,check=True)
message=out/"commit-message.txt"
message.write_text("feat(scene): 支持导入摄影机跟随模型世界变换\n\n- 在单位和原始动画采样后组合摄影机实例变换\n- 暴露正交世界基并拒绝不明确的剪切和反射\n- 验证四种精度下模型与摄影机共同移动的颜色和深度\n- 归档受影响回归并保留工程选择和语义接线待办\n\nRefs #87\n",encoding="utf-8",newline="\n")
subprocess.run(["git","commit","-F",str(message)],cwd=work,check=True)
subprocess.run(["git","show","--stat","--oneline","HEAD"],cwd=work,check=True)
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=work).decode().strip()
assert not subprocess.check_output(["git","status","--porcelain"],cwd=work).strip()
assert all(sha(work/p)==h for p,h in r["source"].items())
result=dict(head=head,completedUtc=datetime.now(timezone.utc).isoformat(),totals=native["totals"],sceneTotals=scene["totals"],archiveSha256=sha(archive),published=False)
(out/"completed.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
print(json.dumps(result),flush=True)
