"""One bounded official dataset acquisition; no extraction or model inference."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import tarfile
import time
import traceback
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-wgsl-cache75'
OUT = BASE / 'depth75-reference-acquisition-v1'
URL = 'https://cvg.cit.tum.de/rgbd/dataset/freiburg1/rgbd_dataset_freiburg1_desk.tgz'
PREFIX = 'rgbd_dataset_freiburg1_desk/'
assert not OUT.exists()
for name, session, code in [('depth75-qualified-runtime-binding-v1', 33029, 1),
                            ('depth75-qualified-file-output-v1', 90072, 0)]:
    assert json.loads((BASE/name/'session-consumed.json').read_text()) == dict(
        session=session, consumed=True, exit_code=code)
assert not json.loads((BASE/'depth75-resume-current.json').read_text())['versionedCache75']['ownHeavyWorkloads']
assert shutil.disk_usage(ROOT).free >= 10 << 30
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
paths = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def hashes():
    return {name: digest(WORK/name) for name in paths}


OUT.mkdir()
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='running', phase='download', url=URL,
              head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip(),
              source_sha256=hashes(), started_utc=datetime.now(timezone.utc).isoformat(),
              limits=['One acquisition attempt, no retry or cleanup',
                      'No archive extraction, image decoding, CV, model predictions or quality claim',
                      'Official source/format/license independently reviewed and registered before acquisition',
                      'Any sequence-specific notice must be reviewed before selecting or inferring images',
                      'External archive and upstream text remain local, outside version control'])


def save():
    temporary = OUT/'receipt.pending.json'
    temporary.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    os.replace(temporary, OUT/'receipt.json')


save()
try:
    began = time.monotonic()
    partial = OUT/'dataset.tgz.partial'
    count = 0
    sha = hashlib.sha256()
    request = Request(URL, headers={'User-Agent': 'MotionStudio-local-reference-validation/1'})
    with urlopen(request, timeout=60) as response, partial.open('xb') as output:
        final = urlsplit(response.url)
        assert final.scheme == 'https' and final.hostname in ('cvg.cit.tum.de', 'webshare.cvg.cit.tum.de')
        expected = response.headers.get('Content-Length')
        expected = int(expected) if expected is not None else None
        assert expected is None or 0 < expected <= 1 << 30
        report.update(final_url=response.url, expected_bytes=expected,
                      content_type=response.headers.get('Content-Type'), downloaded_bytes=0)
        save()
        last_save = began
        while True:
            chunk = response.read(1 << 20)
            if not chunk:
                break
            count += len(chunk)
            assert count <= 1 << 30 and time.monotonic() - began <= 600
            output.write(chunk)
            sha.update(chunk)
            if time.monotonic() - last_save >= 10:
                report['downloaded_bytes'] = count
                save()
                last_save = time.monotonic()
        output.flush()
    assert count > 0 and (expected is None or count == expected)
    archive = OUT/'dataset.tgz'
    partial.rename(archive)
    report.update(phase='metadata', downloaded_bytes=count, sha256=sha.hexdigest(),
                  download_elapsed_seconds=time.monotonic()-began)
    save()
    assert digest(archive) == report['sha256']
    notices = []
    lists = {}
    members = 0
    declared_bytes = 0
    with tarfile.open(archive, 'r|gz') as tar:
        for member in tar:
            members += 1
            assert members <= 20000
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts
            assert member.name == PREFIX.rstrip('/') or member.name.startswith(PREFIX)
            assert member.isdir() or member.isfile(), 'No links, devices or other special entries'
            assert 0 <= member.size <= 16 << 20
            declared_bytes += member.size
            assert declared_bytes <= 2 << 30
            if not member.isfile():
                continue
            lower = path.name.lower()
            metadata = member.name in (PREFIX+'rgb.txt', PREFIX+'depth.txt')
            notice = any(word in lower for word in ('readme', 'license', 'licence', 'copyright', 'copying', 'notice'))
            if not metadata and not notice:
                continue
            assert member.size <= 256 << 10
            stream = tar.extractfile(member)
            assert stream is not None
            raw = stream.read(member.size+1)
            assert len(raw) == member.size
            text = raw.decode('utf-8')
            if metadata:
                destination = OUT/path.name
                destination.write_bytes(raw)
                lists[path.name] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
            if notice:
                assert len(notices) < 64
                destination = f'upstream-notice-{len(notices):02}.txt'
                (OUT/destination).write_bytes(raw)
                notices.append(dict(member=member.name, local=destination, bytes=len(raw),
                                    sha256=hashlib.sha256(raw).hexdigest()))
    assert set(lists) == {'rgb.txt', 'depth.txt'}
    report.update(status='acquired_metadata_retained_notice_review_required_no_inference',
                  phase='completed', archive_members=members, declared_uncompressed_bytes=declared_bytes,
                  timestamp_lists=lists, sequence_notice_files=notices)
    save()
except BaseException:
    report['status'] = 'failed_original_attempt_retained'
    report['cause'] = traceback.format_exc()
    save()
    raise
finally:
    report['source_unchanged'] = hashes() == report['source_sha256']
    report['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    assert report['source_unchanged'], 'Source changed during original acquisition'
