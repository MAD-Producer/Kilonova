"""Publish acquisition identity and authored protocol, never the dataset."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('E:/Dev/aem')
WORK = ROOT/'.worktrees/depth-wgsl-cache75'
OUT = ROOT/'artifacts/pr-queue/depth75-reference-acquisition-v1'
r = json.loads((OUT/'receipt.json').read_text(encoding='utf-8'))
assert json.loads((OUT/'session-consumed.json').read_text()) == dict(session=65494, consumed=True, exit_code=0)
assert r['status'] == 'acquired_metadata_retained_notice_review_required_no_inference' and r['source_unchanged']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == r['head']


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


for name, digest in r['source_sha256'].items():
    assert sha((WORK/name).read_bytes()) == digest, name
assert not r['sequence_notice_files']
assert r['downloaded_bytes'] == r['expected_bytes'] == (OUT/'dataset.tgz').stat().st_size == 344011403
members = {'native/'+name: (OUT/name).read_bytes()
           for name in ('controller.py', 'receipt.json', 'session-consumed.json')}
for name in ('engineering/validation/depth75-independent-reference-protocol.md',
             'tools/depth_reference_metrics.py', 'tools/test_depth_reference_metrics.py'):
    members['source/'+name] = (WORK/name).read_bytes()
members['archive-controller.py'] = Path(__file__).read_bytes()
data = WORK/'engineering/validation/data'
archive = data/'depth75-reference-acquisition-v1.zip'
manifest = data/'depth75-reference-acquisition-v1.json'
assert not archive.exists() and not manifest.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, raw in sorted(members.items()):
        zipped.writestr(name, raw)
with zipfile.ZipFile(archive) as zipped:
    assert sorted(zipped.namelist()) == sorted(members)
    for name, raw in members.items():
        assert zipped.read(name) == raw
value = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
             members=[dict(path=name, bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(members.items())],
             head=r['head'], source_unchanged=True,
             acquisition={name: r[name] for name in ('url', 'final_url', 'downloaded_bytes', 'sha256',
                          'archive_members', 'declared_uncompressed_bytes', 'timestamp_lists', 'sequence_notice_files')},
             review='No sequence-specific notice entries in the structurally checked archive; official benchmark CC BY4.0 default applies',
             license_source='https://cvg.cit.tum.de/data/datasets/rgbd-dataset#license',
             limits=['One successful acquisition; no image decode, predictions or quality result',
                     'No archive data, upstream timestamp lists, notices, source code, model or binary redistributed',
                     'Authored protocol and analytic controls remain distinct from actual independent-model measurements'])
manifest.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')
print(json.dumps({k: value[k] for k in ('archive', 'bytes', 'sha256')}))
