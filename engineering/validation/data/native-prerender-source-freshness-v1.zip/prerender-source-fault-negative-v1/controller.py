"""Serial source-bound native source-watch qualification; never whole #82."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
from ctypes import wintypes
import hashlib,json,os,re,subprocess,tomllib
ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/native-prerender-runtime'
OUT=ROOT/'artifacts/pr-queue/prerender-source-fault-negative-v1'
def git(*args):
    return subprocess.check_output(['git',*args],cwd=WORK).decode().strip()
def sources():
    names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=WORK).decode().split('\0')
    return {p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in names if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml','.md')) or p in ('Cargo.lock','NOTICE'))}

head=git('rev-parse','HEAD');original=sources();OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env=os.environ.copy();env.pop('MOTION_LOG',None);env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
args=['cargo','test','-p','motion-desktop-media','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--lib','movie::prerender::coordinator::tests::source_freshness::watcher_fault_drains_real_ack_and_preserves_simultaneous_worker_failure','--','--exact','--test-threads=1']
report=dict(head=head,status='running_negative',source=original,command=args)
(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
with (OUT/'stdout.log').open('wb') as out,(OUT/'stderr.log').open('wb') as err: code=subprocess.run(args,cwd=WORK,env=env,stdout=out,stderr=err).returncode
text=(OUT/'stdout.log').read_text(encoding='utf-8');counts=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',text)
report.update(exitCode=code,counts=counts,sourceUnchanged=sources()==original,intendedFailure='watcher fault must not prevent draining the real worker acknowledgment' in text,completedUtc=datetime.now(timezone.utc).isoformat())
report['status']='expected_negative_confirmed' if code==101 and counts==[('0','1','0')] and report['sourceUnchanged'] and report['intendedFailure'] else 'unexpected_negative_result'
(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if k!='source'}));assert report['status']=='expected_negative_confirmed'
