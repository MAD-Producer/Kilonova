"""Serial source-bound native source-watch qualification; never whole #82."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
from ctypes import wintypes
import hashlib,json,os,re,subprocess,tomllib
ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/native-prerender-runtime'
OUT=ROOT/'artifacts/pr-queue/prerender-source-freshness-v7'
def git(*args):
    return subprocess.check_output(['git',*args],cwd=WORK).decode().strip()
def sources():
    names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=WORK).decode().split('\0')
    return {p:hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in names if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml','.md')) or p in ('Cargo.lock','NOTICE'))}
head=git('rev-parse','HEAD'); original=sources(); lock_before=(WORK/'Cargo.lock').read_bytes()
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.WaitForSingleObject.restype=wintypes.DWORD
kernel.CloseHandle.argtypes=[wintypes.HANDLE]
owner=kernel.OpenProcess(0x100000,False,73480)
print(json.dumps(dict(waitingForOwner=73480,head=head,sourceFiles=len(original))),flush=True)
if owner:
    try:
        while True:
            result=kernel.WaitForSingleObject(owner,10000)
            if result==0: break
            assert result==258, f'process wait failed: {result}'
    finally: kernel.CloseHandle(owner)
previous=json.loads((ROOT/'artifacts/pr-queue/prerender-input-v4/exit.json').read_text(encoding='utf-8'))
assert previous.get('completedUtc') and previous['status']!='running', 'input validation has not finished'
failed_fetch=json.loads((ROOT/'artifacts/pr-queue/prerender-source-freshness-v1/exit.json').read_text(encoding='utf-8'))
assert failed_fetch['status']=='failed_not_accepted' and len(failed_fetch['steps'])==1 and failed_fetch['steps'][0]['name']=='fetch' and failed_fetch['steps'][0]['exitCode']==101
negative=json.loads((ROOT/'artifacts/pr-queue/prerender-source-fault-negative-v1/exit.json').read_text(encoding='utf-8'))
assert negative['status']=='expected_negative_confirmed' and negative['sourceUnchanged']
assert all(original.get(p)==h for p,h in negative['source'].items() if p!='crates/motion-desktop-media/src/movie/prerender/coordinator.rs'), 'unexpected change beyond native acknowledgment fix'

assert sources()==original and git('rev-parse','HEAD')==head, 'queued source changed'
active=subprocess.check_output(['powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('cargo.exe','rustc.exe','link.exe') -and $_.CommandLine -match 'gltf-animation87-contract' }).Count"]).decode().strip()
assert active=='0', f'owned target tools still live: {active}'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes());(OUT/'Cargo.lock.before').write_bytes(lock_before)
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',LOCALAPPDATA=str(OUT/'owned-profile'),MOTION_SOURCE_WATCH_LOG_ARTIFACTS=str(OUT/'default-logs'))
report=dict(head=head,sourceBefore=original,status='running',steps=[],startedUtc=datetime.now(timezone.utc).isoformat(),limits='Local native filesystems and actual media Coordinator GPU controls only. Engine-native presentation, unchanged P95, full current-source gate and cross-platform CI remain pending. Original failures retained.')
report['inputV4Disposition']={k:previous.get(k) for k in ('head','status','completedUtc')}
report['faultCorrection']='An additional actual blocked native control failed before the fix: watcher fault prevented draining its completed acknowledgment. v7 defers reporting until completion bookkeeping, keeps source faults closed, releases only on actual ack and preserves a simultaneous primary worker panic; no assertion changed. Original negative and v6 component receipts retained.'
report['snapshotCorrection']='v5 actual existing regression found live invalidation wrongly changed the standalone frozen-snapshot contract. v6 opts into live watches only through Worker observed preparation, keeping standalone prepare independent of original files. Existing deletion-after-freeze assertions unchanged; all 39 media tests required.'
report['fixtureCorrection']='v4 executed 8 tests: 7 passed, atomic replacement fixture failed before event assertions. Independent owned Windows API controls confirmed MoveFileEx fails for an open destination while ReplaceFileW succeeds. v5 changes only cfg(test) publication helper; old reader, equal size/mtime and cancellation assertions retained and old-reader contents additionally verified.'
report['compileCorrection']='v3 failed E0624 before any tests: worker source_observation private to sibling module. Changed only its visibility to pub(super); assertions and behavior unchanged. Original receipt retained.'
report['previousVerifierFailure']='v2 fetched successfully on E but its no-existing-edge-change check rejected the expected mio/log feature edge. No compile or tests ran. v3 explicitly verifies that sole added edge plus all original versions/checksums/dependencies; original failed receipt retained.'
report['dependencySetupRecovery']='Initial fetch failed before any tests: existing C registry denied writes. v2 uses an E cargo home; original system registry sources are reused through read-only junctions. No ACL changed, source deleted or failed test hidden.'
fixed=original
def save(): (OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def step(name,args,expected=None,allow_lock_update=False):
    print(json.dumps(dict(start=name)),flush=True)
    began=datetime.now(timezone.utc).isoformat()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        code=subprocess.run(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr).returncode
    text=(OUT/(name+'.stdout.log')).read_text(encoding='utf-8',errors='strict')
    counts=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',text)
    actual=sources()
    unchanged=all(actual.get(p)==h for p,h in fixed.items() if not allow_lock_update or p!='Cargo.lock') and actual.keys()==fixed.keys()
    passed=code==0 and unchanged and (expected is None or counts==[(str(expected),'0','0')])
    row=dict(name=name,command=args,exitCode=code,counts=counts,sourceUnchanged=unchanged,passed=passed,startedUtc=began,completedUtc=datetime.now(timezone.utc).isoformat())
    report['steps'].append(row);save();print(json.dumps(row),flush=True)
    assert passed,name
save()
try:
    # Resolve only the added dependency closure while preserving existing pins.
    step('fetch',['cargo','fetch','--locked','--offline','--target','x86_64-pc-windows-msvc'])
    before=tomllib.loads((ROOT/'artifacts/pr-queue/prerender-source-freshness-v1/Cargo.lock.before').read_text(encoding='utf-8'))['package'];after=tomllib.loads((WORK/'Cargo.lock').read_text(encoding='utf-8'))['package']
    package_key=lambda p:(p['name'],p['version'],p.get('source'))
    old={package_key(p):p for p in before};new={package_key(p):p for p in after}
    removed=[k for k in old if k not in new]
    def normalized(package, universe):
        result={k:v for k,v in package.items() if k!='dependencies'}
        dependencies=[]
        for dependency in package.get('dependencies',[]):
            fields=dependency.split()
            candidates=[key for key in universe if key[0]==fields[0] and (len(fields)==1 or key[1]==fields[1])]
            assert len(candidates)==1, f'ambiguous lock dependency: {dependency}'
            dependencies.append(candidates[0])
        result['dependencies']=sorted(dependencies,key=str)
        return result
    mutated=[k for k in old if k in new and normalized(old[k],old)!=normalized(new[k],new) and k[0]!='motion-desktop-media']
    old_media=next(p for p in old.values() if p['name']=='motion-desktop-media')
    new_media=next(p for p in new.values() if p['name']=='motion-desktop-media')
    before_deps=normalized(old_media,old)['dependencies'];after_deps=normalized(new_media,new)['dependencies']
    assert set(before_deps).issubset(after_deps)
    assert [d for d in after_deps if d not in before_deps]==[('notify','8.2.0','registry+https://github.com/rust-lang/crates.io-index')]

    report['dependencyDelta']=dict(removed=removed,mutatedExisting=mutated,added=[p for k,p in new.items() if k not in old]);save()
    assert not removed
    expected_mio=('mio','1.2.4','registry+https://github.com/rust-lang/crates.io-index')
    assert mutated==[expected_mio], 'unexpected dependency mutation'
    old_mio=normalized(old[expected_mio],old);new_mio=normalized(new[expected_mio],new)
    old_mio_deps=old_mio.pop('dependencies');new_mio_deps=new_mio.pop('dependencies')
    assert old_mio==new_mio and set(old_mio_deps).issubset(new_mio_deps)
    assert [d for d in new_mio_deps if d not in old_mio_deps]==[('log','0.4.34','registry+https://github.com/rust-lang/crates.io-index')]
    report['dependencyDelta']['expectedFeatureAddition']='notify enables mio os-ext and its log dependency; mio version/checksum and every previously resolved edge remain unchanged'
    save()

    assert any(p['name']=='notify' and p['version']=='8.2.0' and p.get('checksum')=='4d3d07927151ff8575b7087f245456e549fea62edf0ec4e565a5ee50c8402bc3' for p in new.values())
    fixed=sources();report['source']=fixed;save()
    media=['cargo','test','-p','motion-desktop-media','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--lib']
    step('source-watch',media+['movie::prerender::source_watch::tests::','--','--test-threads=1'],expected=8)
    step('native-source-freshness',media+['movie::prerender::coordinator::tests::source_freshness::','--','--test-threads=1'],expected=3)
    # Existing producer/worker/coordinator assertions must still pass unchanged.
    step('media-prerender',media+['movie::prerender::','--','--test-threads=1'])
    last=report['steps'][-1];assert last['counts'] and all(f=='0' for p,f,i in last['counts']) and sum(int(p) for p,f,i in last['counts'])>=40
    desktop=['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--bin','motion-studio']
    step('default-logs',desktop+['engine::pending_video_tests::prerender_logging::source_watch_records_default_info_and_setup_error_without_stdout_pollution','--','--exact','--test-threads=1'],expected=1)
    step('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'])
    step('provenance',[os.sys.executable,'tools/validate_provenance.py'])
    step('inventory',[os.sys.executable,'tools/validation_inventory.py'])
    report['status']='accepted_media_source_component_only'
except BaseException:
    report['status']='failed_not_accepted';report['completedUtc']=datetime.now(timezone.utc).isoformat();save();raise
report['completedUtc']=datetime.now(timezone.utc).isoformat();save();print(json.dumps(dict(status=report['status'])),flush=True)
