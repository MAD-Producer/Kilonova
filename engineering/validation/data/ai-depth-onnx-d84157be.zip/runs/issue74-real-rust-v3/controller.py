from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/ai-depth';probe=root/'.tools/ai-depth74/rust-probe'
out=root/'artifacts/pr-queue'/('issue74-real-rust-'+sys.argv[1]);out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def source():
 names=set()
 for args in [('ls-files','-z'),('ls-files','--others','--exclude-standard','-z')]:
  names.update(p.decode() for p in subprocess.check_output(['git',*args],cwd=work).split(b'\0') if p)
 return {p:sha(work/p) for p in sorted(names) if (work/p).is_file() and p.endswith(('.rs','.toml','.py'))} | {'external-probe/main.rs':sha(probe/'src/main.rs'),'external-probe/Cargo.toml':sha(probe/'Cargo.toml')}
inputs=source();env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_TARGET_DIR=str(root/'target/ai-depth74-contract'),CARGO_INCREMENTAL='1',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='2',CARGO_NET_OFFLINE='true')
cmd=['cargo','build','--manifest-path',str(probe/'Cargo.toml'),'--locked','--offline']
receipt=dict(source=inputs,command=cmd,steps=[])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
(out/'probe.rs').write_bytes((probe/'src/main.rs').read_bytes())
for name in ['crates/motion-host/src/depth.rs','crates/motion-host/src/depth/onnx.rs','tools/ai_depth_onnx.py','tools/export_ai_depth.py']:
 target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((work/name).read_bytes())
with (out/'build.stdout.log').open('wb') as stdout,(out/'build.stderr.log').open('wb') as stderr:
 result=subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr)
if result.returncode:sys.exit(result.returncode)
binary=root/'target/ai-depth74-contract/debug/motion-depth74-native-probe.exe'
receipt['binarySha256']=sha(binary)
for mode,width,height in [('success',96,64),('fallback',64,96),('hash',96,64),('missing',96,64)]:
 folder=out/mode;folder.mkdir()
 with (folder/'stdout.log').open('wb') as stdout,(folder/'stderr.log').open('wb') as stderr:
  child=subprocess.run([str(binary),str(folder),mode,str(width),str(height)],cwd=work,env=env,stdout=stdout,stderr=stderr,timeout=180)
 assert child.returncode==0,f'{mode}: child failed; inspect stdout/stderr'
 assert (folder/'stdout.log').read_bytes()==b'',f'{mode}: stdout polluted'
 log=(folder/'logs/motion-studio.log').read_text(encoding='utf-8')
 console=(folder/'stderr.log').read_text(encoding='utf-8')
 assert 'logging initialized level=INFO' in log and 'start #' in log and 'depth_infer' in log
 row=json.loads((folder/'accepted.json').read_text(encoding='utf-8'))
 if mode in ['hash','missing']:
  for sink in [log,console]:
   assert 'ERROR' in sink and 'operation=depth_infer' in sink and 'request=1' in sink and 'asset=74' in sink and 'phase=model_hash' in sink
   assert ('SHA-256' if mode=='hash' else 'FileNotFoundError') in sink
 else:assert not console and 'ERROR' not in log
 if mode!='missing':assert row['positive']['sawInFlight'] and 'actual_provider=CPUExecutionProvider' in log
 if mode=='fallback':assert 'requested_provider=CUDAExecutionProvider cpu_fallback=true' in log
 assert source()==inputs,'source changed during actual model acceptance'
 receipt['steps'].append(row);(out/'progress.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
 print(json.dumps(dict(completed=mode,positive=row['positive'])),flush=True)
receipt['sourceUnchanged']=source()==inputs
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,cases=len(receipt['steps']))),flush=True)
