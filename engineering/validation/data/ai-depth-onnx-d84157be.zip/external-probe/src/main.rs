//! External acceptance harness: actual Jobs + Onnx + desktop file logger.
//! There is no GUI engine in this process; panic command context is absent.
#[path = "E:/Dev/aem/.worktrees/ai-depth/desktop/app/src/logging.rs"]
mod logging;
mod engine {
    pub fn current_command() -> Option<(u64, &'static str, std::time::Duration)> {
        None
    }
}
use motion_host::depth::{onnx::{Config, Onnx, Provider, PROCESSING}, Estimate, Input, Jobs, Key};
use motion_model::depth::{DepthGeometry, DepthMeasure, DepthModel, DepthSource, DepthTime, NearDirection};
use std::{fs, path::{Path, PathBuf}, sync::Arc, thread, time::{Duration, Instant}};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;

fn wait(jobs: &mut Jobs, key: &Key, ticket: u64, require_flight: bool) -> Result<(motion_host::depth::Result<Estimate>, bool)> {
    let start = Instant::now();
    let mut saw_flight = false;
    loop {
        if let Some(flight) = jobs.in_flight()? {
            assert_eq!(flight.request, ticket);
            assert!(flight.source.same_sample(&key.source));
            saw_flight = true;
        }
        match jobs.take_ready(key) {
            Ok(Some(value)) => {
                assert!(!require_flight || saw_flight);
                return Ok((Ok(value), saw_flight));
            }
            Err(error) => return Ok((Err(error), saw_flight)),
            Ok(None) => {}
        }
        if start.elapsed() > Duration::from_secs(120) {
            jobs.cancel()?;
            return Err("real ONNX depth job exceeded harness deadline".into());
        }
        thread::sleep(Duration::from_millis(2));
    }
}

fn verify(value: &Estimate, key: &Key, size: [u32; 2], reference: &Path, out: &Path) -> Result<serde_json::Value> {
    let resource = &value.resource;
    assert_eq!(resource.descriptor().size, size);
    assert_eq!(resource.descriptor().model, key.model);
    assert!(resource.descriptor().source.same_sample(&key.source));
    assert_eq!(resource.descriptor().measure, DepthMeasure::Relative { near: NearDirection::Increasing });
    assert!(resource.confidence().is_none() && resource.validity().is_none());
    assert_eq!(value.provider, "CPUExecutionProvider");
    assert!(value.costs.inference > Duration::ZERO);
    assert!(value.costs.total >= value.costs.inference);
    assert!(value.costs.host_transport > Duration::ZERO && value.costs.host_transport <= value.costs.total);
    assert_eq!(value.costs.input_bytes, 1 * 3 * 518 * 518 * 4);
    assert_eq!(value.costs.output_bytes, 518 * 518 * 4);
    let bytes = fs::read(reference)?;
    assert_eq!(bytes.len(), resource.values().len() * 4);
    let expected: Vec<f32> = bytes.chunks_exact(4).map(|b| f32::from_le_bytes(b.try_into().unwrap())).collect();
    let amplitude = expected.iter().map(|v| v.abs() as f64).fold(1e-6, f64::max);
    let errors: Vec<f64> = resource.values().iter().zip(expected).map(|(a,b)| (f64::from(*a) - f64::from(b)).abs()).collect();
    let max = errors.iter().copied().fold(0., f64::max) / amplitude;
    let mean = errors.iter().sum::<f64>() / errors.len() as f64 / amplitude;
    assert!(max <= 2e-4 && mean <= 2e-5, "reference error max={max}, mean={mean}");
    fs::write(out.join("actual.f32"), resource.values().iter().flat_map(|v| v.to_le_bytes()).collect::<Vec<_>>())?;
    Ok(serde_json::json!({"maxNormalized":max,"meanNormalized":mean,"size":size,"provider":value.provider,
        "loadNs":value.costs.load.as_nanos(),"inferenceNs":value.costs.inference.as_nanos(),
        "totalNs":value.costs.total.as_nanos(),"hostTransportNs":value.costs.host_transport.as_nanos(),
        "inputCopyNs":value.costs.input_copy.as_nanos(),"outputCopyNs":value.costs.output_copy.as_nanos(),
        "inputHostCopyBytes":value.costs.input_bytes,"outputHostCopyBytes":value.costs.output_bytes}))
}

fn main() -> Result<()> {
    let args: Vec<String> = std::env::args().collect();
    let out = PathBuf::from(&args[1]);
    let mode = &args[2];
    let width: u32 = args[3].parse()?;
    let height: u32 = args[4].parse()?;
    fs::create_dir_all(&out)?;
    let _logger = logging::init(out.join("logs"))?;
    let home = PathBuf::from("E:/Dev/aem/.tools/ai-depth74");
    let fixture = args.get(5).map(PathBuf::from).unwrap_or_else(|| PathBuf::from("E:/Dev/aem/artifacts/pr-queue/issue74-letterbox-worker-v2").join(format!("{width}x{height}")));
    let ticks = args.get(6).map(|s| s.parse()).transpose()?.unwrap_or(7);
    let digest = "274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434";
    let sha256: Vec<u8> = (0..64).step_by(2).map(|n| u8::from_str_radix(&digest[n..n+2],16).unwrap()).collect();
    let key = Key {
        source: DepthSource { asset:74, revision:3, pts:DepthTime { ticks,timescale:24 } },
        geometry: DepthGeometry { source_size:[width,height],crop:[0,0,width,height],quarter_turns:0,mirror_x:false },
        model: DepthModel { id:"depth-anything-v2-small".into(), revision:"a561b849ebae10a6f5ef49e26c83cbbcd36c71bf".into(),sha256:sha256.try_into().unwrap(),processing:PROCESSING.into() },
    };
    let provider = if mode == "fallback" { Provider::Cuda } else { Provider::Cpu };
    let config = Config {
        python:home.join("venv/Scripts/python.exe"),
        model:if mode == "missing" { out.join("missing-model.onnx") } else { home.join("models/depth_anything_v2_vits_518.onnx") },
        scratch:out.join("scratch"),provider,
    };
    let rgb: Arc<[u8]> = fs::read(fixture.join("input.rgb"))?.into();
    let mut jobs = Jobs::start(Onnx::new(config)?)?;
    let mut negative = None;
    if mode == "hash" || mode == "missing" {
        let mut wrong = key.clone();
        if mode == "hash" { wrong.model.sha256 = [0;32]; }
        let ticket = jobs.request(Input::new(wrong.clone(), [width,height], rgb.clone())?)?;
        let (result, saw_flight) = wait(&mut jobs, &wrong, ticket, false)?;
        let error = result.expect_err("actual invalid model must fail").to_string();
        assert!(error.contains("model_hash"), "original failure phase missing: {error}");
        if mode == "hash" { assert!(error.contains("SHA-256")); }
        else { assert!(error.contains("FileNotFoundError")); }
        assert_eq!(jobs.counts()?.failed,1);
        negative = Some(serde_json::json!({"cause":error,"sawInFlight":saw_flight,"request":ticket}));
    }
    let positive = if mode != "missing" {
        let ticket = jobs.request(Input::new(key.clone(),[width,height],rgb)?)?;
        let (result, saw_flight) = wait(&mut jobs,&key,ticket,true)?;
        let mut report = verify(&result?, &key, [width,height], &fixture.join("official-reference.f32"), &out)?;
        report["sawInFlight"] = saw_flight.into();
        report["request"] = ticket.into();
        Some(report)
    } else { None };
    assert_eq!(jobs.queue_depth()?,0);
    assert!(jobs.in_flight()?.is_none());
    assert_eq!(jobs.counts()?.completed, u64::from(mode != "missing"));
    drop(jobs);
    assert_eq!(fs::read_dir(out.join("scratch"))?.count(),0);
    fs::write(out.join("accepted.json"), serde_json::to_vec_pretty(&serde_json::json!({"mode":mode,"negative":negative,"positive":positive,"guiEngine":false}))?)?;
    logging::flush();
    Ok(())
}
