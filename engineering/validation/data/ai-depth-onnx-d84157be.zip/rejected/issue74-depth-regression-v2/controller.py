"""Reuse this task's cache only after the other worktree's run has exited."""
from pathlib import Path
import json,os,runpy,subprocess,time
root=Path('E:/Dev/aem');helpers=root/'.tools/issue-closure-review'
terminal=root/'artifacts/pr-queue/issue78-full-software-v3/exit.json'
ready=[root/'artifacts/pr-queue/issue74-real-rust-v3/accepted.json',root/'artifacts/pr-queue/issue74-domain-matrix-v2/accepted.json']
began=time.monotonic()
while not (terminal.is_file() and all(p.is_file() for p in ready)):
 if time.monotonic()-began>1200:raise RuntimeError('exclusive validation prerequisites did not finish; no cache cleared')
 time.sleep(2)
target=(root/'target/ai-depth74-contract').resolve()
assert target.is_relative_to((root/'target').resolve()) and target.name=='ai-depth74-contract'
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(target)
log=root/'artifacts/pr-queue/issue74-model-artifact-invalidation.log'
# The previous optional-host compile reused a no-depth model artifact from the
# other worktree. Invalidate workspace packages, retaining third-party caches.
# No cargo process using this target is still building at this point.
with log.open('wb') as output:
 packages=['motion-model','motion-core','motion-effects','motion-graph','motion-render','motion-media','motion-host']
 command=['cargo','clean',*[arg for name in packages for arg in ['-p',name]],'--target-dir',str(target)]
 subprocess.run(command,cwd=root/'.worktrees/ai-depth',env=env,stdout=output,stderr=subprocess.STDOUT,check=True)
source=(helpers/'validate-issue74-depth-regression.py').read_text(encoding='utf-8').replace('issue74-depth-regression-v1','issue74-depth-regression-v2')
copy=root/'artifacts/pr-queue/issue74-depth-regression-body-v2.py'
copy.write_text(source,encoding='utf-8')
exec(compile(source,__file__,'exec'))
