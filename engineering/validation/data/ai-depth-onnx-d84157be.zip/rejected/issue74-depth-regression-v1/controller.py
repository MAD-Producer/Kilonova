from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/ai-depth';out=root/'artifacts/pr-queue/issue74-depth-regression-v1';out.mkdir(exist_ok=False)
def source():
 names=set()
 for args in [('ls-files','-z'),('ls-files','--others','--exclude-standard','-z')]:
  names.update(p.decode() for p in subprocess.check_output(['git',*args],cwd=work).split(b'\0') if p)
 return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(names) if (work/p).is_file() and (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
inputs=source();env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/ai-depth74-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
env.pop('MOTION_LOG',None)
command=['cargo','test','-p','motion-host','--lib','--features','ai-depth','depth::','--locked','--offline','--','--test-threads=1']
receipt=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),source=inputs,command=command,controllerPid=os.getpid())
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 process=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);receipt['pid']=process.pid;(out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');code=process.wait()
receipt.update(exitCode=code,sourceUnchanged=inputs==source());(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
assert receipt['sourceUnchanged']
if code:sys.exit(code)
text=(out/'stdout.log').read_text(encoding='utf-8');assert '10 passed; 0 failed; 0 ignored;' in text
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(dict(passed=10,failed=0,ignored=0)),flush=True)
