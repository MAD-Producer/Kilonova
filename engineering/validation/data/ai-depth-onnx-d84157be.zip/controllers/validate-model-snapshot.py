from pathlib import Path
import hashlib,importlib.util,json,os,shutil,sys,tempfile
root=Path('E:/Dev/aem');home=root/'.tools/ai-depth74';work=root/'.worktrees/ai-depth'
out=root/'artifacts/pr-queue/issue74-model-snapshot-v1';out.mkdir(exist_ok=False)
import numpy as np,onnxruntime as ort
original=home/'models/depth_anything_v2_vits_518.onnx'
digest='274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
assert hashlib.sha256(original.read_bytes()).hexdigest()==digest
scratch=home/'temp';scratch.mkdir(exist_ok=True)
factory=ort.InferenceSession;rows=[]
old=root/'artifacts/pr-queue/issue74-real-rust-v2/source/tools/ai_depth_onnx.py'
new=work/'tools/ai_depth_onnx.py'
for label,source in [('path-red',old),('snapshot-green',new)]:
 spec=importlib.util.spec_from_file_location(label,source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 (out/(label+'-source.py')).write_bytes(source.read_bytes())
 with tempfile.TemporaryDirectory(prefix='depth-snapshot-',dir=scratch) as temporary:
  directory=Path(temporary);model=directory/'model.onnx';shutil.copyfile(original,model)
  shutil.copyfile(root/'artifacts/pr-queue/issue74-letterbox-worker-v2/96x64/input.rgb',directory/'input.rgb')
  request=dict(schema=1,model=str(model),sha256=digest,processing=module.PROCESSING,width=96,height=64,provider='CPUExecutionProvider')
  (directory/'request.json').write_text(json.dumps(request),encoding='utf-8')
  entered=[]
  def replace_after_hash(model_input,*args,**kwargs):
   # A controlled replacement precisely between verified hashing and loading.
   model.write_bytes(b'concurrently replaced model')
   entered.append(type(model_input).__name__)
   return factory(model_input,*args,**kwargs)
  ort.InferenceSession=replace_after_hash
  try:
   result=module.infer(directory)
  except RuntimeError as error:
   assert label=='path-red' and entered==['str'] and 'phase=session' in str(error)
   rows.append(dict(label=label,expectedFailure=True,cause=str(error)[:2048],argumentType=entered[0]))
  else:
   assert label=='snapshot-green' and entered==['bytes']
   actual=np.fromfile(directory/'output.f32',dtype='<f4')
   expected=np.fromfile(root/'artifacts/pr-queue/issue74-letterbox-worker-v2/96x64/official-reference.f32',dtype='<f4')
   amplitude=max(float(np.abs(expected).max()),1e-6);maximum=float(np.max(np.abs(actual-expected)))/amplitude
   assert actual.shape==expected.shape and np.isfinite(actual).all() and maximum<=2e-4
   assert result['providers']==['CPUExecutionProvider']
   rows.append(dict(label=label,maxNormalized=maximum,argumentType=entered[0],actualProvider=result['providers']))
  finally:ort.InferenceSession=factory
assert len(rows)==2 and hashlib.sha256(original.read_bytes()).hexdigest()==digest
(out/'controller.py').write_bytes(Path(__file__).read_bytes());(out/'accepted.json').write_text(json.dumps(dict(rows=rows,originalModelUnchanged=True),indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,rows=rows)),flush=True)
