from pathlib import Path
import hashlib, json, subprocess, zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/ai-depth';runs=root/'artifacts/pr-queue'
sha=lambda b:hashlib.sha256(b).hexdigest()
labels=['issue74-real-rust-v3','issue74-domain-matrix-v2','issue74-model-snapshot-v1','issue74-depth-regression-v3']
receipts={n:json.loads((runs/n/'accepted.json').read_text(encoding='utf-8')) for n in labels}
for label in ['issue74-real-rust-v3','issue74-domain-matrix-v2','issue74-depth-regression-v3']:
    for name,digest in receipts[label]['source'].items():
        actual=(root/'.tools/ai-depth74/rust-probe/src/main.rs' if name=='external-probe/main.rs' else
                root/'.tools/ai-depth74/rust-probe/Cargo.toml' if name=='external-probe/Cargo.toml' else work/name)
        assert actual.is_file() and sha(actual.read_bytes())==digest,(label,name)
assert receipts['issue74-real-rust-v3']['sourceUnchanged']
assert len(receipts['issue74-real-rust-v3']['steps'])==4
assert len(receipts['issue74-domain-matrix-v2']['rows'])==15
assert receipts['issue74-model-snapshot-v1']['originalModelUnchanged']
assert all(s['sourceUnchanged'] and s['exitCode']==0 for s in receipts['issue74-depth-regression-v3']['steps'])
payload={}
def add(name,path):
    assert name not in payload,name
    assert path.is_file() and path.stat().st_size<(16<<20),path
    assert path.suffix not in {'.onnx','.pth','.exe','.dll','.pyc'},path
    payload[name]=path.read_bytes()
for label in labels:
    for path in sorted((runs/label).rglob('*')):
        if path.is_file():add('runs/'+label+'/'+path.relative_to(runs/label).as_posix(),path)
for label in ['issue74-depth-regression-v1','issue74-depth-regression-v2']:
    for filename in ['controller.py','started.json','exit.json','stdout.log','stderr.log']:
        path=runs/label/filename
        if path.is_file():add('rejected/'+label+'/'+filename,path)
owned=['Cargo.toml','Cargo.lock','ATTRIBUTION.md','PROVENANCE.md','NOTICE',
       'crates/motion-host/Cargo.toml','crates/motion-host/src/depth.rs',
       'crates/motion-host/tests/depth_jobs.rs','crates/motion-model/src/depth.rs',
       'crates/motion-model/tests/depth.rs','tools/ai_depth_onnx.py','tools/export_ai_depth.py',
       'engineering/host-api/optional-depth-inference.md']
owned += [p.relative_to(work).as_posix() for p in sorted((work/'crates/motion-host/src/depth').rglob('*.rs'))]
for name in owned:add('source/'+name,work/name)
for filename in ['Cargo.toml','Cargo.lock','src/main.rs']:
    add('external-probe/'+filename,root/'.tools/ai-depth74/rust-probe'/filename)
for filename in ['model.json','LICENSE-Depth-Anything-V2.txt']:
    add('export/'+filename,root/'.tools/ai-depth74/export-tool-v1'/filename)
for filename in ['issue74-export-tool-v1.stdout.log','issue74-export-tool-v1.stderr.log',
                 'issue74-owned-format-check.log','issue74-model-artifact-invalidation.log']:
    add('logs/'+filename,runs/filename)
for filename in ['validate-domain-matrix.py','validate-model-snapshot.py']:
    add('controllers/'+filename,root/'.tools/ai-depth74'/filename)
add('controllers/archive.py',Path(__file__))
manifest=dict(baseHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
    scope='Optional host prototype on Windows CPU; four real-model cases, fifteen domain comparisons, ten native tests; no GUI, accelerated-provider or Android acceptance',
    limits='Synthetic interior/video; no natural interior/live-action or metric/temporal-quality guarantee. Models, weights, upstream source and runtime binaries excluded.',
    payload={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(payload.items())})
payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
name='ai-depth-onnx-'+sha(payload['source/tools/ai_depth_onnx.py'])[:8]+'.zip'
destination=work/'engineering/validation/data'/name
assert not destination.exists()
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for entry,data in sorted(payload.items()):archive.writestr(entry,data)
assert destination.stat().st_size<(64<<20)
with zipfile.ZipFile(destination) as archive:
    assert set(archive.namelist())==set(payload)
    for entry,data in payload.items():assert sha(archive.read(entry))==sha(data),entry
result=dict(file=name,sha256=sha(destination.read_bytes()),bytes=destination.stat().st_size,files=len(payload))
(runs/'issue74-runtime-archive.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
