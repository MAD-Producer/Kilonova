"""Actual Rust/ONNX vs independently prepared official-reference domain probes.

Only the NASA portrait is external. Illustration, room and short camera-motion
sequence are authored here; the room is a synthetic interior, not a photo.
"""
from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path('E:/Dev/aem');home=root/'.tools/ai-depth74';work=root/'.worktrees/ai-depth'
out=root/'artifacts/pr-queue'/('issue74-domain-matrix-'+sys.argv[1]);out.mkdir(exist_ok=False)
for name in ['TEMP','TMP','TORCH_HOME','HF_HOME','TORCHINDUCTOR_CACHE_DIR']:
 directory=home/'domain-temp'/name.lower();directory.mkdir(parents=True,exist_ok=True);os.environ[name]=str(directory)
os.environ.pop('MOTION_LOG',None);os.environ['CUDA_VISIBLE_DEVICES']=''
os.environ.update(CARGO_TARGET_DIR=str(root/'target/ai-depth74-contract'),CARGO_PROFILE_DEV_DEBUG='2',CARGO_INCREMENTAL='1',CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true')
probe=home/'rust-probe'
with (out/'build.stdout.log').open('wb') as stdout,(out/'build.stderr.log').open('wb') as stderr:
 result=subprocess.run(['cargo','build','--manifest-path',str(probe/'Cargo.toml'),'--locked','--offline'],cwd=work,env=os.environ,stdout=stdout,stderr=stderr)
if result.returncode:sys.exit(result.returncode)
import cv2,numpy as np,torch
from PIL import Image,ImageDraw
sys.path.insert(0,str(home/'official-reference'))
from depth_anything_v2.dpt import DepthAnythingV2
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=home/'official-reference',text=True).strip()=='a561b849ebae10a6f5ef49e26c83cbbcd36c71bf'
weights=home/'models/depth_anything_v2_vits.pth'
assert hashlib.sha256(weights.read_bytes()).hexdigest()=='715fade13be8f229f8a70cc02066f656f2423a59effd0579197bbf57860e1378'
torch.set_num_threads(1);torch.set_num_interop_threads(1)
model=DepthAnythingV2(encoder='vits',features=64,out_channels=[48,96,192,384]).cpu().eval()
model.load_state_dict(torch.load(weights,map_location='cpu',weights_only=True),strict=True)

def room(pan=0.):
 w,h=256,192;y,x=np.mgrid[:h,:w]
 rays=np.stack([(x+.5-w/2)/180,-(y+.5-h/2)/180,np.ones((h,w))],axis=-1)
 camera=np.array([pan,1.4,-3.]);depth=np.full((h,w),np.inf);colour=np.zeros((h,w,3))
 light=np.array([-.3,.8,-.5]);light/=np.linalg.norm(light)
 def install(t,n,base):
  nonlocal depth,colour
  valid=(t>0)&(t<depth)&np.isfinite(t);illum=.35+.65*np.maximum(0,np.sum(n*light,axis=-1))
  shaded=np.broadcast_to(base,(h,w,3))*illum[...,None]
  colour=np.where(valid[...,None],shaded,colour);depth=np.where(valid,t,depth)
 for axis,position,normal,base in [(0,-3.,[1,0,0],[.6,.65,.8]),(0,3.,[-1,0,0],[.8,.65,.6]),(1,0.,[0,1,0],[.7,.67,.55]),(1,3.,[0,-1,0],[.88,.88,.85]),(2,8.,[0,0,-1],[.74,.78,.76])]:
  with np.errstate(divide='ignore',invalid='ignore'):t=(position-camera[axis])/rays[...,axis]
  points=camera+rays*t[...,None];albedo=np.broadcast_to(base,(h,w,3)).copy()
  if axis==1 and position==0:
   checks=((np.floor(points[...,0]*1.4)+np.floor(points[...,2]*1.4))%2)==0
   albedo*=np.where(checks,.8,1)[...,None]
  install(t,np.broadcast_to(normal,(h,w,3)),albedo)
 for center,radius,base in [([-.9,.7,2.4],.7,[.7,.22,.12]),([.9,.5,4.4],.5,[.12,.5,.68]),([.3,1.,6.1],1.,[.55,.62,.2])]:
  center=np.array(center);oc=camera-center;a=np.sum(rays*rays,axis=-1);b=2*np.sum(rays*oc,axis=-1);c=np.dot(oc,oc)-radius*radius
  disc=b*b-4*a*c;t=np.where(disc>=0,(-b-np.sqrt(np.maximum(disc,0)))/(2*a),np.inf)
  points=camera+rays*np.where(np.isfinite(t),t,0)[...,None];normals=(points-center)/radius
  install(t,normals,base)
 assert np.isfinite(depth).all()
 return np.rint(np.clip(colour,0,1)*255).astype(np.uint8),depth.astype('<f4')

portrait=home/'domain-fixtures-v1/portrait.original'
payload=portrait.read_bytes();assert hashlib.sha1(b'blob '+str(len(payload)).encode()+b'\0'+payload).hexdigest()=='834cda0012478c5edc8d43bade96d315dedeaab4'
image=Image.open(portrait).convert('RGB').resize((256,256),Image.Resampling.LANCZOS)
illustration=Image.new('RGB',(256,192),(28,40,67));draw=ImageDraw.Draw(illustration)
draw.polygon([(0,142),(65,44),(136,148)],fill=(59,95,109));draw.polygon([(85,144),(196,26),(256,144)],fill=(83,117,121))
draw.ellipse((179,15,219,55),fill=(230,201,111));draw.rectangle((0,144,256,192),fill=(42,74,87))
draw.ellipse((71,63,161,153),fill=(225,169,135));draw.pieslice((64,53,170,161),175,355,fill=(46,31,40))
draw.ellipse((88,105,95,112),fill=(33,31,43));draw.ellipse((136,105,143,112),fill=(33,31,43))
draw.arc((103,115,127,135),15,165,fill=(149,78,72),width=2);draw.polygon([(77,145),(155,145),(186,192),(47,192)],fill=(185,73,72))
indoor,truth=room();cases=[('portrait',np.array(image),None,7),('illustration',np.array(illustration),None,7),('synthetic-interior',indoor,truth,7)]
for frame in range(12):
 rgb,z=room((frame-5.5)*.035);cases.append((f'video-{frame:02}',rgb,z,frame))

binary=root/'target/ai-depth74-contract/debug/motion-depth74-native-probe.exe'
code_names=['crates/motion-host/src/depth.rs','crates/motion-host/src/depth/onnx.rs','tools/ai_depth_onnx.py']
frozen={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in code_names}
rows=[];thumbs=[];sequence=[]
(out/'controller.py').write_bytes(Path(__file__).read_bytes());(out/'probe.rs').write_bytes((probe/'src/main.rs').read_bytes())
for name,rgb,truth,ticks in cases:
 folder=out/name;folder.mkdir();h,w=rgb.shape[:2];rgb.tofile(folder/'input.rgb');Image.fromarray(rgb).save(folder/'input.png')
 # Derive geometry independently using integer arithmetic, not the production
 # worker's preprocess/resize functions, then use official normalization.
 if w>=h:rw=518;rh=max(1,(h*518+w//2)//w)
 else:rh=518;rw=max(1,(w*518+h//2)//h)
 bx,by=(518-rw)//2,(518-rh)//2;boxed=np.zeros((518,518,3),dtype=np.uint8)
 boxed[by:by+rh,bx:bx+rw]=cv2.resize(rgb,(rw,rh),interpolation=cv2.INTER_CUBIC)
 tensor,_=model.image2tensor(boxed[:,:,::-1].copy(),input_size=518)
 with torch.no_grad():prediction=model(tensor).unsqueeze(1);reference=torch.nn.functional.interpolate(prediction[:,:,by:by+rh,bx:bx+rw],size=(h,w),mode='bilinear',align_corners=True)[0,0].numpy()
 reference.astype('<f4').tofile(folder/'official-reference.f32')
 native=folder/'native';native.mkdir()
 with (native/'stdout.log').open('wb') as stdout,(native/'stderr.log').open('wb') as stderr:
  process=subprocess.run([str(binary),str(native),'success',str(w),str(h),str(folder),str(ticks)],cwd=work,env=os.environ,stdout=stdout,stderr=stderr,timeout=180)
 assert process.returncode==0,f'{name}: real Rust/ONNX comparison failed'
 assert (native/'stdout.log').read_bytes()==b'' and (native/'stderr.log').read_bytes()==b''
 result=json.loads((native/'accepted.json').read_text(encoding='utf-8'))['positive'];row=dict(name=name,pts=dict(ticks=ticks,timescale=24),**result)
 actual=np.fromfile(native/'actual.f32',dtype='<f4').reshape(h,w)
 for suffix,values in [('actual',actual),('reference',reference)]:
  lo,hi=np.percentile(values,[1,99]);gray=np.rint(np.clip((values-lo)/max(hi-lo,1e-6),0,1)*255).astype(np.uint8)
  Image.fromarray(gray).save(folder/(suffix+'.png'))
 if truth is not None:
  truth.tofile(folder/'camera-z-oracle.f32');inverse=1/truth
  row['syntheticInverseZPearson']=float(np.corrcoef(actual.ravel(),inverse.ravel())[0,1])
 if name.startswith('video-'):sequence.append(actual)
 rows.append(row)
 canvas=Image.new('RGB',(384,150),'white');canvas.paste(Image.fromarray(rgb).resize((128,128)),(0,20))
 canvas.paste(Image.open(folder/'reference.png').convert('RGB').resize((128,128)),(128,20));canvas.paste(Image.open(folder/'actual.png').convert('RGB').resize((128,128)),(256,20))
 ImageDraw.Draw(canvas).text((3,2),name+' | input / official / Rust ONNX',fill='black');thumbs.append(canvas)
 assert frozen=={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in code_names}
 print(json.dumps(dict(completed=name,maxNormalized=row['maxNormalized'],qualityOracle=row.get('syntheticInverseZPearson'))),flush=True)
sheet=Image.new('RGB',(384*3,150*5),'white')
for i,thumb in enumerate(thumbs):sheet.paste(thumb,((i%3)*384,(i//3)*150))
sheet.save(out/'comparison.png')
differences=[float(np.mean(np.abs(b-a))/max(float(np.ptp(a)),1e-6)) for a,b in zip(sequence,sequence[1:])]
receipt=dict(source=frozen,binarySha256=hashlib.sha256(binary.read_bytes()).hexdigest(),portrait=dict(author='NASA',source='scikit-image v0.25.2 skimage/data/astronaut.png',sha256=hashlib.sha256(payload).hexdigest(),license='Public domain per upstream dataset'),rows=rows,sequenceFrameDifferences=differences,
 limits='Synthetic interior and short synthetic camera sequence; no natural interior or live-action temporal quality acceptance. Unaligned per-frame differences include real parallax and are not a pure flicker metric. Relative predictions are not calibrated camera Z. No GPU provider or Session/GUI claim.')
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(dict(accepted=True,cases=len(rows))),flush=True)
