from pathlib import Path
from PIL import Image, ImageDraw

folder=Path('E:/Dev/aem/artifacts/pr-queue/professional-api86-relink-v3/relink-shot')
path=folder/'comparison.png'
assert not path.exists()
canvas=Image.new('RGB',(620,370),'#1e2228')
draw=ImageDraw.Draw(canvas)
for col,label in enumerate(['Native decoded PNGs','Independent CPU golden','Frozen after source deletion']):
    draw.text((10+205*col,10),label,fill='white')
for row,(title,names) in enumerate([
    ('Original sources',['initial.png','golden-initial.png','frozen-0.png']),
    ('Relinked sources',['relinked.png','golden-relinked.png','frozen-1.png']),
]):
    top=32+row*165
    draw.text((10,top),title,fill='white')
    for col,name in enumerate(names):
        im=Image.open(folder/name).convert('RGBA').resize((192,144),Image.Resampling.NEAREST)
        bg=Image.new('RGBA',im.size,'#c9c9c9')
        checks=ImageDraw.Draw(bg)
        for y in range(0,144,12):
            for x in range(0,192,12):
                if (x//12+y//12)%2: checks.rectangle((x,y,x+11,y+11),fill='#ececec')
        canvas.paste(Image.alpha_composite(bg,im).convert('RGB'),(10+205*col,top+16))
canvas.save(path)
print(path)
