"""Collect terminal exact-head CI before publishing the next owned source."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
from datetime import datetime,timezone
ART=Path('E:/Dev/aem/artifacts/pr-queue');OUT=ART/'depth75-ci-53c3280d-terminal-v1'
REPO='MAD-Producer/Kilonova';RUN=42573859294;HEAD='53c3280dd83f6d373bd00897e651f0d05b7da50c'
def api(p):return subprocess.check_output(['gh','api',p])
def write(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
run=json.loads(api(f'repos/{REPO}/actions/runs/{RUN}'))
jobs=json.loads(api(f'repos/{REPO}/actions/runs/{RUN}/jobs?per_page=100'))['jobs']
assert run['head_sha']==HEAD and run['status']=='completed' and run['conclusion']=='success'
assert len(jobs)==10 and sum(j['conclusion']=='success' for j in jobs)==8
assert all(j['status']=='completed' and j['conclusion'] in {'success','skipped'} and j['head_sha']==HEAD for j in jobs)
OUT.mkdir(exist_ok=False);write(OUT/'run.json',run);write(OUT/'jobs.json',jobs)
records=[]
for j in jobs:
    if j['conclusion']=='skipped':continue
    path=OUT/f'{j["id"]}.log'
    old=ART/'depth75-ci-53c3280d-completed-tests-v1'/path.name
    if old.is_file():path.write_bytes(old.read_bytes())
    else:
        with path.open('wb') as stdout,(OUT/f'{j["id"]}.download.stderr.log').open('wb') as stderr:
            p=subprocess.run(['gh','api',f'repos/{REPO}/actions/jobs/{j["id"]}/logs'],stdout=stdout,stderr=stderr)
        assert p.returncode==0
    data=path.read_bytes();assert len(data)>0
    records.append(dict(id=j['id'],name=j['name'],bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
write(OUT/'collection.json',dict(status='terminal_exact_head_eight_applicable_jobs_passed',run=RUN,head=HEAD,
    observed_utc=datetime.now(timezone.utc).isoformat(),jobs=records,
    limits=['Exact published Session source only; later retained cohort/Rust-remap integration commits require their own CI',
        'Remote success does not erase original failed local workspace/host/native runs']))
members={p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file()}
members['collector.py']=Path(__file__).read_bytes()
archive=OUT/'depth75-ci-53c3280d-v1.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
manifest=dict(schema=1,archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    source_head=HEAD,run=RUN,members={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in sorted(members.items())})
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for name,data in members.items():assert z.read(name)==data
write(OUT/'depth75-ci-53c3280d-v1.json',manifest)
print(json.dumps(dict(bytes=manifest['bytes'],sha256=manifest['sha256'],members=len(members),run=RUN,head=HEAD)))
