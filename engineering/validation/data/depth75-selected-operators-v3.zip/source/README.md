# External operator research (not qualified)

These independently authored FP32 WGSL entry points prepare the same-weight
operator comparison for #75. They are not an installed product backend.
No shader compilation, numerical equivalence or timing is established by source
preparation. Run only after the live #88 complete native regression terminates.

The first four operations are tiled batched MatMul (including explicit shared
weight broadcasting), last-axis stable Softmax, last-axis LayerNormalization,
and NCHW linear Resize with align_corners. All input dimensions, strides, finite
values, model identity, storage lengths and device limits need host admission.
Workgroup/barrier participation includes partial matrix tiles.

Qualification fixtures retain actual model weights and actual intermediate
activations from the pinned Small ONNX model, outside the repository. A complete
same-weight model evaluation, all remaining operator families, real video,
generation/frozen-output scheduling and cross-platform execution remain required.
Synthetic scalar cases can expose implementation errors but cannot replace the
same-weight model evidence or establish an inference backend.

The completed third attempt covers all13distinct audited layouts in the four
families (117actual nodes), plus21 authored edge controls. The13 representatives
include all six MatMul shape/broadcast combinations. They do not establish
numerical equivalence for all117weights/activations or a composed model result.

Actual Vulkan execution on the RTX4070Laptop passed all34 independent numerical
comparisons with the original2e-4 maximum/2e-5 mean normalized bounds. All15host
admission tests passed. Five actual negative requests retained Error output in
file and stderr, with defaultInfo starts visible and stdout empty. The first
attempt failed to compile; the second exposed constant width7 LayerNorm error.
The third uses translation-invariant centering before reduction, keeping a
constant row exactly zero. Original failed source/logs and reference bytes stay
retained. These controls do not establish full inference or installed integration.

`convolution.wgsl` and `erf.wgsl` prepare the next operator families. They are
deliberately not linked into the four-operator probe. Convolution admission,
reference fixtures and actual shader/device comparisons are still required.
The transpose kernel only covers the audited nonoverlapping2/stride2 and4/stride4
forms. The Erf candidate independently evaluates published mathematical
coefficients from Abramowitz & Stegun, AMS55 p299 Eq7.1.26 and a small-argument
power series from NIST DLMF7.6.1. Mathematical approximation error is distinct
from actual Float32 GPU error. Before publication, add these mathematical
references to provenance/attribution; do not publish source/imagery from the book.
Those references are prepared in the75documentation worktree's attribution and
provenance files and must be committed with the actual evidence before publishing.

The executed host suite has10 first-family admission tests and5 convolution
admission tests. The latter check OIHW/IOHW channels, optional bias, the37x37
patch-embedding grid, restricted transpose forms and logical allocation bounds.
These host tests do not establish GPU convolution pixels.

The separately retained scalar Erf experiment sampled20025 Float32 arguments
against Python `math.erf`, observing maximum absolute2.980232238769531e-7 below
its predeclared1e-6 bound. That standard-library scalar experiment is not WGSL,
ONNX, model, latency or hardware evidence; GPU arithmetic still needs checking.
