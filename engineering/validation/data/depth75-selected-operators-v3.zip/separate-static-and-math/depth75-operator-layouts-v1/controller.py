"""Static enumeration of every planned operator layout; no learned evaluation."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os

os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
import onnx

ROOT=Path('E:/Dev/aem')
MODEL=ROOT/'.tools/ai-depth74/models/depth_anything_v2_vits_518.onnx'
INVENTORY=ROOT/'artifacts/pr-queue/depth75-static-model-audit-v3/tensor-inventory.json'
OUT=ROOT/'artifacts/pr-queue/depth75-operator-layouts-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(MODEL)=='274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='running_static_layout_enumeration',startedUtc=datetime.now(timezone.utc).isoformat(),
            modelSha256=sha(MODEL),inventorySha256=sha(INVENTORY),inferenceExecuted=False,
            bufferBudgetBytes=256*1024**2,maximumBindingBytes=128*1024**2,maximumWorkgroupsPerDimension=65535,
            nodes=[],limits=['Static layout/admission analysis only; not Rust execution or WGSL validation',
                'Explicit materialized contiguous inputs are assumed for each operator; no fused/view stride claim',
                'Comparison baseline limits are not queried device capabilities',
                'No image, learned operator, native app, GPU, CV or model-inference workload executed',
                'Remaining19operator kinds and whole-model execution/scheduling remain unimplemented'])
def save(): (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
model=onnx.load(str(MODEL),load_external_data=False)
inventory=json.loads(INVENTORY.read_text(encoding='utf-8'))
assert len(inventory)==len(model.graph.node)==598
shapes={t.name:list(t.dims) for t in model.graph.initializer}
shapes.update({v.name:[d.dim_value for d in v.type.tensor_type.shape.dim] for v in model.graph.input})
shapes.update({o['name']:o['shape'] for n in inventory for o in n['outputs']})
representatives={}
for index,node in enumerate(model.graph.node):
    kind=node.op_type
    if kind not in ('MatMul','Softmax','LayerNormalization','Resize'): continue
    count={'MatMul':2,'Softmax':1,'LayerNormalization':3,'Resize':1}[kind]
    inputs=[shapes[n] for n in list(node.input)[:count]]
    output=shapes[node.output[0]]
    assert len(node.output)==1
    assert all(1<=len(s)<=4 and all(isinstance(n,int) and n>0 for n in s) for s in inputs+[output])
    attrs={a.name:onnx.helper.get_attribute_value(a) for a in node.attribute}
    p={}
    if kind=='MatMul':
        a,b=inputs; assert len(a)>=2 and len(b)>=2 and a[-1]==b[-2]
        prefix=[]
        rank=max(len(a)-2,len(b)-2)
        for offset in range(rank):
            x=a[-3-offset] if len(a)>=3+offset else 1
            y=b[-3-offset] if len(b)>=3+offset else 1
            assert x==y or x==1 or y==1
            prefix.insert(0,max(x,y))
        batches=math.prod(prefix)
        assert math.prod(a[:-2]) in (1,batches) and math.prod(b[:-2]) in (1,batches),'Unsupported partial batch broadcast'
        assert output==prefix+[a[-2],b[-1]]
        dispatch=[math.ceil(b[-1]/8),math.ceil(a[-2]/8),batches]
        p=dict(m=a[-2],n=b[-1],k=a[-1],batches=batches,
               aBatchStride=0 if math.prod(a[:-2])==1 else a[-2]*a[-1],
               bBatchStride=0 if math.prod(b[:-2])==1 else b[-2]*b[-1])
    elif kind in ('Softmax','LayerNormalization'):
        assert attrs.get('axis',-1)==-1 and inputs[0]==output
        if kind=='LayerNormalization':
            assert inputs[1]==inputs[2]==[inputs[0][-1]] and attrs['epsilon']>0
        rows=math.prod(output[:-1]); x=min(rows,65535); dispatch=[x,math.ceil(rows/x),1]
        p=dict(width=output[-1],rows=rows)
    else:
        assert len(inputs[0])==len(output)==4 and inputs[0][:2]==output[:2]
        assert attrs['mode']==b'linear' and attrs['coordinate_transformation_mode']==b'align_corners'
        groups=math.ceil(math.prod(output)/64); x=min(groups,65535); dispatch=[x,math.ceil(groups/x),1]
        p=dict(inputHeight=inputs[0][2],inputWidth=inputs[0][3],outputHeight=output[2],outputWidth=output[3])
    sizes=[math.prod(s)*4 for s in inputs+[output]]
    logical=sum(sizes[:-1])+2*sizes[-1]+64+(3-count)*4
    assert max(sizes)<=report['maximumBindingBytes'] and logical<=report['bufferBudgetBytes']
    assert all(0<n<=65535 for n in dispatch)
    entry=dict(index=index,name=node.name,operation=kind,inputs=inputs,output=output,dispatch=dispatch,
               logicalBufferBytes=logical,parameters=p)
    report['nodes'].append(entry)
    signature=json.dumps([kind,inputs,output,p],sort_keys=True)
    # Resize uses every distinct size even when a later operator shares it.
    representatives.setdefault(signature,entry)
report.update(status='all_four_operator_family_static_layouts_admitted',completedUtc=datetime.now(timezone.utc).isoformat(),
              modelUnchanged=sha(MODEL)==report['modelSha256'],counts=dict(Counter(n['operation'] for n in report['nodes'])),
              largestLogicalOperatorBytes=max(n['logicalBufferBytes'] for n in report['nodes']),
              representativeNodes=list(representatives.values()))
assert report['counts']=={'MatMul':72,'LayerNormalization':28,'Softmax':12,'Resize':5}
assert report['modelUnchanged']
save()
print(json.dumps({k:v for k,v in report.items() if k not in ('nodes','representativeNodes')}))
print(json.dumps({'representatives':[dict(index=n['index'],operation=n['operation'],inputs=n['inputs'],output=n['output']) for n in representatives.values()]}))
