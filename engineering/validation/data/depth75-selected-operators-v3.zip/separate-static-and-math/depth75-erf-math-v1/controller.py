"""Tiny scalar mathematics check, not a model, native app or GPU workload."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
import struct

ROOT=Path('E:/Dev/aem')
OUT=ROOT/'artifacts/pr-queue/depth75-erf-math-v1'
SOURCE=ROOT/'.tools/ai-depth75/operator-probe/src/erf.wgsl'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
f=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
add=lambda a,b:f(f(a)+f(b))
mul=lambda a,b:f(f(a)*f(b))
div=lambda a,b:f(f(a)/f(b))

def candidate(x):
    if x==0.:return x
    a=abs(x)
    if a>=6.:return math.copysign(1.,x)
    if a<.5:
        term=total=x
        for n in range(1,13):
            term=mul(term,div(mul(-x,x),float(n)))
            total=add(total,div(term,float(2*n+1)))
        return mul(1.1283791670955126,total)
    t=div(1.,add(1.,mul(.3275911,a)))
    polynomial=mul(add(mul(add(mul(add(mul(add(mul(1.061405429,t),-1.453152027),t),1.421413741),t),-.284496736),t),.254829592),t)
    return mul(math.copysign(1.,x),add(1.,-mul(polynomial,f(math.exp(-mul(a,a))))))

points=[f(-6.+12.*i/20000) for i in range(20001)]
points.extend(f(x) for x in (0.,-0.,1e-45,-1e-45,1e-30,-1e-30,1e-12,-1e-12,1e-7,-1e-7,
                              .4999999701976776,.5,.5000000596046448,-.4999999701976776,-.5,-.5000000596046448,
                              5.999999523162842,6.,6.000000476837158,-6.,1e20,-1e20,3e38,-3e38))
rows=[dict(input=x,reference=f(math.erf(x)),roundedCandidate=candidate(x)) for x in points]
assert all(math.isfinite(r['roundedCandidate']) for r in rows)
errors=[abs(r['roundedCandidate']-r['reference']) for r in rows]
worst=max(range(len(rows)),key=errors.__getitem__)
zero=next(r for r in rows if r['input']==0.)
report=dict(status='scalar_math_check_passed_gpu_unqualified',completedUtc=datetime.now(timezone.utc).isoformat(),
            shaderSha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),samples=len(rows),
            maximumAbsolute=errors[worst],meanAbsolute=sum(errors)/len(errors),worst=rows[worst],
            predeclaredMaximumAbsolute=1e-6,zeroExact=zero['roundedCandidate']==0.,
            inferenceExecuted=False,gpuExecuted=False,
            mathematicalReferences=['https://digital.library.unt.edu/ark:/67531/metadc40302/m1/315/ocr/',
                                    'https://dlmf.nist.gov/7.6.E1'],
            limits=['Python standard-library scalar evaluation with Float32 rounding after each arithmetic operation',
                    'math.erf is the independent comparison, not an ONNX or learned output',
                    'Does not model GPU FMA, reassociation, exp implementation, denormal policy or actual WGSL execution',
                    'The retained bound only qualifies these sampled CPU expressions, not every real argument',
                    'All same-model GPU numerical and end-to-end inference gates remain required'])
if errors[worst]>1e-6 or not report['zeroExact']:report['status']='scalar_math_check_failed_original_bound_retained'
(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
assert report['status']=='scalar_math_check_passed_gpu_unqualified'
