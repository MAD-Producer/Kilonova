"""Static next-family shape/admission inventory; no learned operator evaluation."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os

os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
import onnx

ROOT=Path('E:/Dev/aem')
MODEL=ROOT/'.tools/ai-depth74/models/depth_anything_v2_vits_518.onnx'
INVENTORY=ROOT/'artifacts/pr-queue/depth75-static-model-audit-v3/tensor-inventory.json'
OUT=ROOT/'artifacts/pr-queue/depth75-convolution-layouts-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(MODEL)=='274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='running_static_next_family_inventory',startedUtc=datetime.now(timezone.utc).isoformat(),
            modelSha256=sha(MODEL),inventorySha256=sha(INVENTORY),inferenceExecuted=False,nodes=[],
            limits=['Static ONNX shape/attribute analysis only, no GPU or learned evaluation',
                    'The convolution/Erf shader files remain unlinked and unqualified',
                    '256MiB logical operator budget and128MiB binding are baseline admission comparisons, not measured device memory',
                    'No complete graph execution, accuracy, latency, power or thermal claim'])
def save():(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
model=onnx.load(str(MODEL),load_external_data=False)
inventory=json.loads(INVENTORY.read_text(encoding='utf-8'))
shapes={t.name:list(t.dims) for t in model.graph.initializer}
shapes.update({o['name']:o['shape'] for n in inventory for o in n['outputs']})
shapes.update({v.name:[d.dim_value for d in v.type.tensor_type.shape.dim] for v in model.graph.input})
for index,node in enumerate(model.graph.node):
    if node.op_type not in ('Conv','ConvTranspose','Erf'):continue
    inputs=[shapes[n] for n in node.input]
    output=shapes[node.output[0]]
    assert len(node.output)==1 and all(all(isinstance(d,int) and d>0 for d in s) for s in inputs+[output])
    attrs={a.name:onnx.helper.get_attribute_value(a) for a in node.attribute}
    if node.op_type=='Erf':
        assert len(inputs)==1 and inputs[0]==output and not attrs
    else:
        assert len(inputs) in (2,3) and len(inputs[0])==len(inputs[1])==len(output)==4
        assert set(attrs)<= {'kernel_shape','dilations','group','pads','strides','output_padding'}
        assert attrs['group']==1 and attrs['dilations']==[1,1]
        n,ci,ih,iw=inputs[0]; w=inputs[1]
        kh,kw=attrs['kernel_shape']; sh,sw=attrs['strides']; pt,pl,pb,pr=attrs['pads']
        assert [kh,kw]==w[2:] and min(sh,sw)>0 and attrs.get('output_padding',[0,0])==[0,0]
        if node.op_type=='Conv':
            co=w[0]; assert w[1]==ci
            assert ih+pt+pb>=kh and iw+pl+pr>=kw
            expected=[n,co,(ih+pt+pb-kh)//sh+1,(iw+pl+pr-kw)//sw+1]
        else:
            co=w[1]; assert w[0]==ci
            assert (kh,kw) in ((2,2),(4,4)) and [sh,sw]==[kh,kw] and [pt,pl,pb,pr]==[0,0,0,0]
            expected=[n,co,ih*kh,iw*kw]
        assert output==expected
        if len(inputs)==3:assert inputs[2]==[co]
    sizes=[math.prod(s)*4 for s in inputs+[output]]
    logical=sum(sizes[:-1])+2*sizes[-1]+64+(3-len(inputs))*4
    assert max(sizes)<=128*1024**2 and logical<=256*1024**2
    groups=math.ceil(math.prod(output)/64); x=min(groups,65535); y=math.ceil(groups/x)
    assert 0<y<=65535
    report['nodes'].append(dict(index=index,name=node.name,operation=node.op_type,inputs=inputs,output=output,
                                attributes=attrs,hasBias=node.op_type!='Erf' and len(inputs)==3,
                                logicalBufferBytes=logical,dispatch=[x,y,1]))
report.update(status='static_convolution_erf_layouts_recorded_gpu_unqualified',completedUtc=datetime.now(timezone.utc).isoformat(),
              counts=dict(Counter(n['operation'] for n in report['nodes'])),
              convolutionWithoutBias=sum(n['operation']=='Conv' and not n['hasBias'] for n in report['nodes']),
              maximumLogicalOperatorBytes=max(n['logicalBufferBytes'] for n in report['nodes']),
              modelUnchanged=sha(MODEL)==report['modelSha256'])
assert report['counts']=={'Conv':31,'ConvTranspose':2,'Erf':12}
assert report['convolutionWithoutBias']==4 and report['modelUnchanged']
save()
print(json.dumps({k:v for k,v in report.items() if k!='nodes'}))
