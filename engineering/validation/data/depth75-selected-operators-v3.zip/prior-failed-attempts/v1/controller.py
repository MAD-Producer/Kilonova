"""Deferred selected-operator qualification; preserves every failed attempt."""
from pathlib import Path
from datetime import datetime, timezone
import copy
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import traceback

ROOT = Path('E:/Dev/aem')
SCRIPTS = ROOT / '.tools/issue-closure-review'
WORK = ROOT / '.tools/ai-depth75/operator-probe'
OUT = ROOT / 'artifacts/pr-queue/depth75-operators-v1'
FIXTURES = ROOT / 'artifacts/pr-queue/depth75-operator-fixtures-v1'
PYTHON = ROOT / '.tools/ai-depth74/venv/Scripts/python.exe'
FULL = ROOT / 'artifacts/pr-queue/tracking88-prototype-workspace-integration-v3/exit.json'
native = json.loads(FULL.read_text(encoding='utf-8'))
assert native['status'] != 'running' and 'completedUtc' in native and native['sourceUnchanged'], 'Keep original full native regression undisturbed'
window = ROOT / 'artifacts/pr-queue/tracking88-window-support-candidate-v1/experiment.json'
assert not window.exists() or 'completedUtc' in json.loads(window.read_text()), 'Do not compete with the real tracking experiment'
assert shutil.disk_usage(ROOT).free >= 10*1024**3, 'Original 10 GiB build-space admission; no cleanup performed'
assert not OUT.exists(), 'Preserve all prior attempts; do not overwrite'
OUT.mkdir()
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
for name in list(env):
    if name.startswith('MOTION_'): env.pop(name)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/depth75-operators'),
           CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
           TEMP=str(ROOT/'target/depth75-operators/tmp'),TMP=str(ROOT/'target/depth75-operators/tmp'),
           PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',
           LOCALAPPDATA=str(OUT/'appdata'),RUST_BACKTRACE='full')
Path(env['TEMP']).mkdir(parents=True,exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
report = dict(status='running',pid=os.getpid(),startedUtc=datetime.now(timezone.utc).isoformat(),stages=[],
              originalNativeStatus=native['status'],environment={k:env[k] for k in env if k.startswith(('CARGO_','RUST_')) or k in ('TEMP','TMP')},
              limits=['Selected operators only; no installed WGSL backend or complete model output',
                      'Original full native outcome is retained; these filtered research controls cannot replace it',
                      'One own workload at a time; explicit Vulkan hardware adapter without precision/backend fallback',
                      'Same existing optional Small model/runtime; no model assets or weights added to repository',
                      'Cold per-operator submit/map wall observations do not establish full inference latency or thermal qualification'])

def save():
    pending=OUT/'receipt.pending.json'
    pending.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    os.replace(pending,OUT/'receipt.json')

def run(name,command,cwd=WORK,expected=0):
    row=dict(name=name,command=[str(x) for x in command],status='running',startedUtc=datetime.now(timezone.utc).isoformat())
    report['stages'].append(row); save()
    start=time.monotonic()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(row['command'],cwd=cwd,env=env,stdout=stdout,stderr=stderr)
        row['pid']=child.pid; save(); code=child.wait()
    row.update(exitCode=code,elapsedSeconds=round(time.monotonic()-start,3),
               completedUtc=datetime.now(timezone.utc).isoformat(),status='expected_result' if code==expected else 'unexpected_result')
    save()
    assert code==expected,(name,code,expected)

def sources():
    files=list((WORK/'src').glob('*'))+list((WORK/'tests').glob('*'))+[WORK/'Cargo.toml',WORK/'Cargo.lock']
    return {p.relative_to(WORK).as_posix():sha(p) for p in files if p.is_file()}

began=time.monotonic(); save()
try:
    if not FIXTURES.exists():
        run('reference-fixtures',[PYTHON,SCRIPTS/'prepare-depth75-operator-fixtures-v1.py'],ROOT)
    fixture_report=json.loads((FIXTURES/'receipt.json').read_text())
    assert fixture_report['status']=='same_weight_reference_fixtures_generated_wgsl_comparison_pending'
    report['fixturesReceiptSha256']=sha(FIXTURES/'receipt.json'); save()
    run('offline-lock',['cargo','generate-lockfile','--offline','--manifest-path',WORK/'Cargo.toml'])
    before=sources(); report['source']=before; save()
    for name,expected in before.items():
        snapshot=OUT/'frozen-source'/name
        snapshot.parent.mkdir(parents=True,exist_ok=True)
        snapshot.write_bytes((WORK/name).read_bytes())
        assert sha(snapshot)==expected
    run('host-admission-tests',['cargo','test','--offline','--locked','--tests','--','--test-threads=1'])
    run('build',['cargo','build','--offline','--locked','--bin','motion-depth-operator-probe'])
    binary=Path(env['CARGO_TARGET_DIR'])/'debug/motion-depth-operator-probe.exe'
    assert binary.is_file()
    report['binarySha256']=sha(binary)
    retained=OUT/'retained-binary'; retained.mkdir()
    shutil.copyfile(binary,retained/binary.name)
    binary=retained/binary.name
    assert sha(binary)==report['binarySha256']
    report['executedRetainedBinary']=str(binary); save()
    run('actual-gpu',[binary,FIXTURES/'request.json',OUT/'gpu'])
    assert not (OUT/'actual-gpu.stdout.log').read_bytes(),'Protocol stdout must remain empty'
    info=(OUT/'gpu/logs/motion-studio.log').read_text(encoding='utf-8')
    assert 'start #1' in info,'Default Info must retain a pre-operator start'
    run('independent-comparison',[PYTHON,SCRIPTS/'compare-depth75-operator-outputs-v1.py',FIXTURES,OUT/'gpu',OUT/'comparison'],ROOT)

    original=json.loads((FIXTURES/'request.json').read_text())
    # A new root per fault uses canonical references to the original hashed
    # tensors. Copy only the small selected case inputs rather than aliases,
    # so path escape admission is not weakened for fault injection.
    base=next(c for c in original['cases'] if c['id']=='control-softmax-width-7')
    faults=['model-identity','axis','budget','tensor-hash','nonfinite']
    report['failureObservations']=[]
    for fault in faults:
        directory=OUT/('fault-'+fault); directory.mkdir(); (directory/'tensors').mkdir()
        request=copy.deepcopy(original); request['cases']=[copy.deepcopy(base)]
        case=request['cases'][0]
        for tensor in case['inputs']+[case['expected']]:
            destination=directory/tensor['file']; destination.parent.mkdir(parents=True,exist_ok=True)
            if not destination.exists(): shutil.copyfile(FIXTURES/tensor['file'],destination)
        if fault=='model-identity': request['model_sha256']='0'*64
        elif fault=='axis': case['operation']['axis']=0
        elif fault=='budget': request['buffer_budget_bytes']=1
        elif fault=='tensor-hash': case['inputs'][0]['sha256']='0'*64
        elif fault=='nonfinite':
            tensor=case['inputs'][0]; path=directory/tensor['file']; raw=bytearray(path.read_bytes())
            raw[:4]=bytes.fromhex('0000c07f'); path.write_bytes(raw); tensor['sha256']=sha(path)
        request_path=directory/'request.json'; request_path.write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8')
        run('fault-'+fault,[binary,request_path,directory/'observed'],expected=1)
        assert not (OUT/('fault-'+fault+'.stdout.log')).read_bytes()
        file_log=(directory/'observed/logs/motion-studio.log').read_text(encoding='utf-8')
        stderr=(OUT/('fault-'+fault+'.stderr.log')).read_text(encoding='utf-8',errors='replace')
        result=json.loads((directory/'observed/receipt.json').read_text())
        assert result['status']=='failed_original_cause_retained' and result['failure']
        assert result['failure'] in file_log and result['failure'] in stderr
        report['failureObservations'].append(dict(fault=fault,cause=result['failure'],fileError=True,stderrError=True,stdoutEmpty=True))
        save()
    assert sources()==before,'Prepared operator sources changed during execution'
    report.update(status='selected_operator_tests_and_numerics_passed',sourceUnchanged=True,defaultInfoStartVisible=True,stdoutEmpty=True,
                  numericalReceiptSha256=sha(OUT/'comparison/receipt.json'))
except BaseException as cause:
    report.update(status='failed_original_outputs_retained',failure=repr(cause),traceback=traceback.format_exc())
    if 'before' in locals(): report['sourceUnchanged']=sources()==before
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3))
    save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','stages')}))
