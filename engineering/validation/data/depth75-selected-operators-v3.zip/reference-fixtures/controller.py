"""Post-native same-weight intermediate fixtures; never run beside the full gate."""
from pathlib import Path
from datetime import datetime, timezone
import copy
import hashlib
import json
import logging
import os
import sys
import time
import traceback

ROOT = Path('E:/Dev/aem')
FULL = ROOT / 'artifacts/pr-queue/tracking88-prototype-workspace-integration-v3/exit.json'
MODEL = ROOT / '.tools/ai-depth74/models/depth_anything_v2_vits_518.onnx'
OUT = ROOT / 'artifacts/pr-queue/depth75-operator-fixtures-v1'
EXPECTED = '274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
native = json.loads(FULL.read_text(encoding='utf-8'))
assert native['status'] != 'running' and 'completedUtc' in native and native['sourceUnchanged'], 'Original native gate still live; no fixture process started'
assert sha(MODEL) == EXPECTED
OUT.mkdir(exist_ok=False)
(OUT / 'tensors').mkdir()
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
logger = logging.getLogger('depth75-fixtures')
logger.setLevel(getattr(logging, os.environ.get('MOTION_LOG', 'INFO').upper(), logging.INFO))
file_log = logging.FileHandler(OUT / 'research.log', encoding='utf-8')
file_log.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
logger.addHandler(file_log)
errors = logging.StreamHandler(sys.stderr); errors.setLevel(logging.ERROR); errors.setFormatter(file_log.formatter)
logger.addHandler(errors)
report = dict(status='running_reference_fixture_generation', pid=os.getpid(),
              startedUtc=datetime.now(timezone.utc).isoformat(), modelSha256=EXPECTED,
              originalNativeGateStatus=native['status'], phases=[],
              limits=['Same-weight selected-operator reference fixtures, not WGSL or complete model-backend qualification',
                      'Input RGB is independently authored synthetic data, not photographed/video quality evidence',
                      'Model weights, intermediate tensor payloads and CPU runtime remain external',
                      'Disabled ORT graph optimization exposes original named operators; runtime options are recorded',
                      'No Android work, default distribution, backend fallback or temporal quality claim'])

def phase(name):
    report['phase'] = name
    report['phases'].append(dict(name=name, utc=datetime.now(timezone.utc).isoformat()))
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    logger.info('start request=75 operation=%s', name)
    file_log.flush()

began = time.monotonic()
try:
    phase('load_optional_cpu_reference')
    os.environ.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='')
    import numpy as np
    import onnx
    import onnxruntime as ort
    model = onnx.load(str(MODEL), load_external_data=False)
    initializers = {t.name: t for t in model.graph.initializer}
    report['versions'] = dict(numpy=np.__version__, onnx=onnx.__version__, onnxruntime=ort.__version__)
    layout_path = ROOT / 'artifacts/pr-queue/depth75-operator-layouts-v1/receipt.json'
    layouts = json.loads(layout_path.read_text(encoding='utf-8'))
    assert layouts['status'] == 'all_four_operator_family_static_layouts_admitted' and layouts['modelSha256'] == EXPECTED
    # Select every distinct real input/output layout, not only the first two
    # MatMuls: attention-times-value and the long1536 contraction also matter.
    selected = [(entry['index'],model.graph.node[entry['index']]) for entry in layouts['representativeNodes']]
    assert len(selected) == 13 and len({i for i,n in selected}) == 13
    assert all(node.op_type == entry['operation'] and node.name == entry['name']
               for (index,node),entry in zip(selected,layouts['representativeNodes']))
    report['staticLayoutReceiptSha256'] = sha(layout_path)
    known = json.loads((ROOT / 'artifacts/pr-queue/depth75-static-model-audit-v3/tensor-inventory.json').read_text())
    assert len(known) == len(model.graph.node) == 598
    metadata = {row['name']: row for entry in known for row in entry['outputs']}
    model_inputs = {value.name for value in model.graph.input}
    needed = set()
    for index, node in selected:
        count = {'MatMul':2,'LayerNormalization':3,'Softmax':1,'Resize':1}[node.op_type]
        needed.update(node.output)
        needed.update(n for n in list(node.input)[:count] if n not in initializers and n not in model_inputs)
    existing_outputs = {o.name for o in model.graph.output}
    augmented = copy.deepcopy(model)
    for name in sorted(needed - existing_outputs):
        description = metadata[name]
        assert description['dtype'] == 'FLOAT' and all(isinstance(d,int) and d > 0 for d in description['shape'])
        augmented.graph.output.append(onnx.helper.make_tensor_value_info(name, onnx.TensorProto.FLOAT, description['shape']))
    onnx.checker.check_model(augmented)
    phase('author_normalized_input')
    rng = np.random.default_rng(75)
    y,x = np.indices((518,518), dtype=np.float32)
    rgb = np.stack((x/517.,y/517.,(x+y)/1034.), axis=-1)
    rgb = np.clip(rgb + rng.uniform(-.03,.03,rgb.shape).astype(np.float32), 0., 1.)
    inputs = ((rgb-np.array([.485,.456,.406],np.float32))/np.array([.229,.224,.225],np.float32)).transpose(2,0,1)[None].copy()
    assert inputs.shape == (1,3,518,518) and np.isfinite(inputs).all()
    report['authoredInputSha256'] = hashlib.sha256(inputs.astype('<f4').tobytes()).hexdigest()
    phase('create_cpu_reference_session')
    options = ort.SessionOptions()
    options.intra_op_num_threads=1; options.inter_op_num_threads=1; options.log_severity_level=3
    options.graph_optimization_level=ort.GraphOptimizationLevel.ORT_DISABLE_ALL
    session = ort.InferenceSession(augmented.SerializeToString(), sess_options=options, providers=['CPUExecutionProvider'])
    report['providers'] = session.get_providers()
    assert report['providers'] == ['CPUExecutionProvider']
    names = sorted(needed | existing_outputs)
    phase('run_actual_same_weight_cpu_model')
    returned = session.run(names, {'rgb':inputs})
    values = dict(zip(names,returned))
    values.update({'rgb':inputs})
    assert all(np.isfinite(v).all() and v.dtype == np.float32 for v in returned)
    report['finalDepthSha256'] = hashlib.sha256(values['relative_inverse_depth'].astype('<f4').tobytes()).hexdigest()
    phase('retain_actual_inputs_weights_and_reference_outputs')
    def write_tensor(name, array):
        assert array.dtype == np.float32 and array.ndim <= 4 and np.isfinite(array).all()
        raw = np.ascontiguousarray(array,dtype='<f4').tobytes()
        identity = hashlib.sha256(raw).hexdigest()
        path = OUT / 'tensors' / (identity+'.f32')
        if not path.exists(): path.write_bytes(raw)
        assert sha(path) == identity and path.stat().st_size == len(raw)
        return dict(name=name,dtype='float32',shape=list(array.shape),file=path.relative_to(OUT).as_posix(),sha256=identity)
    def tensor(name):
        array = onnx.numpy_helper.to_array(initializers[name]) if name in initializers else values[name]
        return write_tensor(name, array)
    cases = []
    for index,node in selected:
        attrs = {a.name:onnx.helper.get_attribute_value(a) for a in node.attribute}
        operation = dict(kind=node.op_type)
        count = {'MatMul':2,'LayerNormalization':3,'Softmax':1,'Resize':1}[node.op_type]
        if node.op_type in ('LayerNormalization','Softmax'):
            operation['axis'] = attrs.get('axis', -1)
            assert operation['axis'] == -1
        if node.op_type == 'LayerNormalization': operation['epsilon'] = attrs['epsilon']
        if node.op_type == 'Resize':
            operation.update(mode=attrs['mode'].decode(),coordinate_transformation_mode=attrs['coordinate_transformation_mode'].decode())
            assert operation['mode'] == 'linear' and operation['coordinate_transformation_mode'] == 'align_corners'
        cases.append(dict(id=f'model-{index}-{node.op_type.lower()}',origin='same_model_intermediate',source_node=node.name,
                          operation=operation, inputs=[tensor(n) for n in list(node.input)[:count]],expected=tensor(node.output[0])))
    phase('author_independent_operator_edge_controls')
    def control(identity, operation, arrays, reference):
        cases.append(dict(id=identity,origin='authored_control',source_node=None,operation=operation,
                     inputs=[write_tensor(f'{identity}-input-{i}', np.asarray(a,dtype=np.float32)) for i,a in enumerate(arrays)],
                     expected=write_tensor(identity+'-reference',np.asarray(reference,dtype=np.float32))))
    # Float64 mathematical references are rounded once into explicit Float32.
    # No WGSL output, measured error or result-dependent threshold is involved.
    for identity,a_shape,b_shape in [('odd',(3,17),(17,5)),('batched',(2,3,9),(2,9,11)),
                                   ('shared-right',(2,3,9),(9,7)),('shared-left',(3,9),(2,9,7))]:
        a=rng.uniform(-2,2,a_shape).astype(np.float32); b=rng.uniform(-2,2,b_shape).astype(np.float32)
        control('control-matmul-'+identity,dict(kind='MatMul'),[a,b],a.astype(np.float64)@b.astype(np.float64))
    for width in (1,7,63,64,65,1370):
        a=rng.uniform(-15,15,(3,width)).astype(np.float32)
        a[0]=1000.; a[1]+=1000.; a[2]-=1000.
        stable=a.astype(np.float64)-a.max(axis=-1,keepdims=True).astype(np.float64)
        probabilities=np.exp(stable); probabilities/=probabilities.sum(axis=-1,keepdims=True)
        control(f'control-softmax-width-{width}',dict(kind='Softmax',axis=-1),[a],probabilities)
    for width in (1,7,65,384):
        a=rng.uniform(-2,2,(4,width)).astype(np.float32); a[0]=3.; a[1]=0.
        scale=rng.uniform(-2,2,width).astype(np.float32); bias=rng.uniform(-1,1,width).astype(np.float32)
        centered=a.astype(np.float64)-a.astype(np.float64).mean(axis=-1,keepdims=True)
        epsilon=float(np.float32(1e-6))
        reference=centered/np.sqrt((centered*centered).mean(axis=-1,keepdims=True)+epsilon)*scale+bias
        control(f'control-layernorm-width-{width}',dict(kind='LayerNormalization',axis=-1,epsilon=epsilon),[a,scale,bias],reference)
    for ih,iw,oh,ow in [(3,5,7,9),(7,9,3,5),(1,5,7,9),(3,1,7,9),(3,5,1,9),(3,5,7,1),(3,5,1,1)]:
        a=rng.uniform(-2,2,(2,3,ih,iw)).astype(np.float32)
        reference=np.empty((2,3,oh,ow),dtype=np.float64)
        for oy in range(oh):
            sy=oy*(ih-1)/(oh-1) if oh>1 else 0.; y0=int(sy); y1=min(y0+1,ih-1); wy=sy-y0
            for ox in range(ow):
                sx=ox*(iw-1)/(ow-1) if ow>1 else 0.; x0=int(sx); x1=min(x0+1,iw-1); wx=sx-x0
                upper=a[:,:,y0,x0].astype(np.float64)*(1-wx)+a[:,:,y0,x1].astype(np.float64)*wx
                lower=a[:,:,y1,x0].astype(np.float64)*(1-wx)+a[:,:,y1,x1].astype(np.float64)*wx
                reference[:,:,oy,ox]=upper*(1-wy)+lower*wy
        control(f'control-resize-{ih}-{iw}-to-{oh}-{ow}',dict(kind='Resize',mode='linear',coordinate_transformation_mode='align_corners'),[a],reference)
    request = dict(version=1,model_sha256=EXPECTED,
                   original_weights_sha256='715fade13be8f229f8a70cc02066f656f2423a59effd0579197bbf57860e1378',
                   requested_backend='vulkan',buffer_budget_bytes=256*1024**2,cases=cases)
    (OUT / 'request.json').write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8')
    report.update(status='same_weight_reference_fixtures_generated_wgsl_comparison_pending',requestSha256=sha(OUT / 'request.json'),
                  selectedNodes=[dict(index=i,name=n.name,operation=n.op_type) for i,n in selected],
                  outputCounts=dict(cases=len(cases),sameModelCases=len(selected),authoredControls=len(cases)-len(selected),
                                    rawFiles=len(list((OUT/'tensors').glob('*.f32')))),
                  declaredComparisonBounds=dict(maxNormalized=0.0002,meanNormalized=0.00002,
                    provenance='Unchanged historical Small ONNX/reference end-to-end numerical bounds; not tuned to these GPU results'),
                  modelUnchanged=sha(MODEL)==EXPECTED,elapsedSeconds=round(time.monotonic()-began,3),
                  completedUtc=datetime.now(timezone.utc).isoformat())
    assert report['modelUnchanged']
    phase('completed')
except BaseException as cause:
    report.update(status='reference_fixture_generation_failed_original_cause_retained',failure=repr(cause),
                  traceback=traceback.format_exc(),completedUtc=datetime.now(timezone.utc).isoformat())
    (OUT / 'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    logger.error('reference fixture generation failed phase=%s cause=%s',report.get('phase'),repr(cause)[:4096])
    raise
