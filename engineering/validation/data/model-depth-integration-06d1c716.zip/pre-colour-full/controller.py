from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

root = Path('E:/Dev/aem')
work = root / '.worktrees/3d-model-depth'
out = root / 'artifacts/pr-queue/issue3d-combined-main-full-v1'
out.mkdir(exist_ok=False)
head = '653dc2056a2f12d0cdc6fbb6907d2a2a44b60376'
base = '7bb54085242f2ca6d5eefe823a01b7ac7044239c'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip() == head
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=work)
subprocess.run(['git', 'merge-base', '--is-ancestor', base, head], cwd=work, check=True)

def now():
    return datetime.now(timezone.utc).isoformat()

def source():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=work).decode().split('\0')
    return {p: hashlib.sha256((work / p).read_bytes()).hexdigest() for p in sorted(paths)
            if p and (work / p).is_file() and (p.endswith(('.rs', '.py', '.toml')) or p == 'Cargo.lock')}

before = source()
env = os.environ.copy()
target = root / 'target/gltf-scene87-contract'
env.update(CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
           CARGO_NET_OFFLINE='true', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           LOCALAPPDATA=str(out / 'appdata'), RUST_BACKTRACE='1',
           MOTION_MODEL_UI_ARTIFACTS=str(out / 'model-editor-fixture'))
env.pop('MOTION_MODEL_UI_PROJECT', None)
env.pop('MOTION_LOG', None)
env.pop('VK_DRIVER_FILES', None)
env.pop('VK_ICD_FILENAMES', None)
features = 'motion-host/diagnostics,motion-host/ai-depth,motion-host/gpu-tests,motion-ui/gpu-tests,motion-desktop/gpu-tests,motion-desktop/ffmpeg,motion-desktop-media/gpu-tests,motion-graph/gpu-tests'
steps = [
    ('panel-style-consumers', [sys.executable, '-c', "import runpy; runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
    ('provenance', [sys.executable, 'tools/validate_provenance.py']),
    ('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline']),
    ('workspace-tests', ['cargo', 'test', '--workspace', '--exclude', 'motion-android', '--locked', '--offline',
                         '--features', features, '--no-fail-fast', '--', '--test-threads=1']),
    ('desktop-binary', ['cargo', 'build', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline']),
    ('command-list', [str(target / 'debug/motion-studio.exe'), '--command-list']),
]
receipt = {'head': head, 'base': base, 'source': before, 'startedUtc': now(),
           'controllerPid': os.getpid(), 'steps': [], 'previousTurn': 'progress',
           'scope': 'current maintained main plus model and image/video depth integration; all native GPU/FFmpeg/ai-depth features; Android excluded by user instruction',
           'expectedExistingIgnores': 14, 'environment': {k: env.get(k) for k in (
               'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CARGO_NET_OFFLINE',
               'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'TEMP', 'TMP', 'LOCALAPPDATA',
               'LIBCLANG_PATH', 'FFMPEG_DIR', 'MOTION_LOG')}}
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
for name, command in steps:
    step = {'name': name, 'command': command, 'startedUtc': now()}
    print(json.dumps({'start': name, 'head': head}), flush=True)
    stdout_path, stderr_path = out / (name + '.stdout.log'), out / (name + '.stderr.log')
    with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
        process = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
        step['pid'] = process.pid
        receipt['steps'].append(step)
        (out / 'started.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        step['exitCode'] = process.wait()
    step['completedUtc'] = now()
    step['sourceUnchanged'] = before == source()
    step['worktreeClean'] = not subprocess.check_output(['git', 'status', '--porcelain'], cwd=work)
    step['stdoutSha256'] = hashlib.sha256(stdout_path.read_bytes()).hexdigest()
    step['stderrSha256'] = hashlib.sha256(stderr_path.read_bytes()).hexdigest()
    if name == 'workspace-tests':
        text = stdout_path.read_text(encoding='utf-8', errors='strict')
        results = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
        step['totals'] = dict(zip(('passed', 'failed', 'ignored'), (sum(int(r[i]) for r in results) for i in range(3))))
        step['totals']['targets'] = len(results)
        step['ignoredObserved'] = [line for line in text.splitlines() if re.match(r'test .* \.\.\. ignored', line)]
    (out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    assert step['sourceUnchanged'] and step['worktreeClean']
    print(json.dumps({'done': name, 'exit': step['exitCode'], 'totals': step.get('totals')}), flush=True)
    if step['exitCode']:
        sys.exit(step['exitCode'])
    if name == 'workspace-tests':
        assert step['totals']['passed'] >= 3192 and step['totals']['failed'] == 0
        assert step['totals']['ignored'] == receipt['expectedExistingIgnores']
        expected_ignores = json.loads((root / 'artifacts/pr-queue/issue87-model-main-full-v1/exit.json').read_text(encoding='utf-8'))['steps'][-1]['ignoredObserved']
        assert set(step['ignoredObserved']) == set(expected_ignores), 'ignored test identities changed'
        for test in ('model_catalog_bounds_new_and_cached_retained_payloads_together',
                     'model_materials_obey_shared_source_budget_and_mesh_draws_are_reported',
                     'saved_model_keyframes_render_inside_the_editor',
                     'scene_native_access_rejects_a_foreign_thread_before_allocation_and_recovers',
                     'backend_flight_has_actual_pts_and_same_sample_seek_cannot_install_late_success',
                     'decoder_open_is_observable_before_blocking_and_seek_discards_old_request',
                     'installed_video_result_checks_live_frame_and_registered_relink_without_sample',
                     'mismatched_frame_pts_end_dimensions_and_yuv_color_fail_before_backend',
                     'missing_or_wrong_index_retains_native_cause_and_new_request_can_recover',
                     'packet_cancellation_releases_non_send_decoder_without_entering_inference',
                     'payload_budget_is_checked_before_decoder_open_and_outside_time_is_a_normal_miss',
                     'replacing_same_path_video_document_rejects_old_backend_success',
                     'rotated_sdr_yuv_is_converted_before_inference_using_display_pixel_coordinates',
                     'variable_rate_sample_uses_actual_decoder_pts_and_explicit_crop_orientation',
                     'actual_managed_png_is_cropped_rotated_mirrored_off_owner_thread',
                     'actual_decode_errors_are_typed_observed_and_do_not_enter_backend_or_retry',
                     'blocked_depth_publishes_flight_before_backend_and_retains_only_latest_pending_sample',
                     'actual_child_keeps_protocol_and_diagnostics_in_separate_pipes'):
            assert re.search(r'test [^\n]*' + test + r' \.\.\. ok', text), test
    elif name == 'command-list':
        catalogue = json.loads(stdout_path.read_text(encoding='utf-8'))
        serialized = json.dumps(catalogue)
        assert 'register_model_asset' in serialized and not stderr_path.read_bytes()
        step['binarySha256'] = hashlib.sha256((target / 'debug/motion-studio.exe').read_bytes()).hexdigest()
receipt['completedUtc'] = now()
receipt['sourceUnchanged'] = before == source()
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps({'accepted': True, 'head': head}), flush=True)
