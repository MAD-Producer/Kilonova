"""Audit the maintained-main ignore inventory; preserve the original failed controller."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess

root=Path('E:/Dev/aem'); work=root/'.worktrees/3d-model-depth'
gate=root/'artifacts/pr-queue/issue3d-combined-main-full-v1'
out=gate/'inventory-continuation'; out.mkdir(exist_ok=False)
head='653dc2056a2f12d0cdc6fbb6907d2a2a44b60376'
base='7bb54085242f2ca6d5eefe823a01b7ac7044239c'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=work).decode().strip()
def source():
    return {p:sha(work/p) for p in git('ls-files','-z').split('\0') if p and
        (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
original=json.loads((gate/'exit.json').read_text(encoding='utf-8'))
assert original['head']==head and original['base']==base
assert len(original['steps'])==4 and original['expectedExistingIgnores']==14
before=source(); assert original['source']==before
for step in original['steps']:
    assert step['exitCode']==0 and step['sourceUnchanged'] and step['worktreeClean']
    for stream in ('stdout','stderr'):
        assert sha(gate/(step['name']+'.'+stream+'.log'))==step[stream+'Sha256']
tests=original['steps'][-1]; assert tests['name']=='workspace-tests'
totals=tests['totals']; assert totals['passed']>=3192 and totals['failed']==0 and totals['ignored']==15
text=(gate/'workspace-tests.stdout.log').read_text(encoding='utf-8')
observed=[line for line in text.splitlines() if re.match(r'test .* \.\.\. ignored',line)]
assert observed==tests['ignoredObserved'] and len(observed)==15 and len(set(observed))==15
old=json.loads((root/'artifacts/pr-queue/issue87-model-main-full-v1/exit.json').read_text(encoding='utf-8'))['steps'][-1]['ignoredObserved']
added=set(observed)-set(old)
assert added=={'test panels::auxiliary::text_style::tests::native::text_style_native_controls_pixels_transactions_and_floating_input ... ignored, manual native GPU character/paragraph captures and window routing'}
assert not set(old)-set(observed)
audit=[]
for line in observed:
    name=line.split(' ... ',1)[0][5:].rsplit('::',1)[-1]
    files=git('grep','-l','-F','fn '+name+'(',head,'--','*.rs').splitlines()
    assert files
    for entry in files:
        path=entry.split(':',1)[1]
        actual=git('rev-parse',head+':'+path); baseline=git('rev-parse',base+':'+path)
        assert actual==baseline,(name,path)
        audit.append(dict(test=line,path=path,headBlob=actual,mainBaseBlob=baseline))
# The original controller checks these after its inventory assertion; retain all
# named execution requirements in this independent continuation too.
controller=(gate/'controller.py').read_text(encoding='utf-8')
names=re.findall(r"'([a-z][a-z0-9_]+)'",controller[controller.index("for test in ("):controller.index("elif name == 'command-list':")])
assert len(names)>=18
for name in names: assert re.search(r'test [^\n]*'+name+r' \.\.\. ok',text),name
receipt=json.loads(json.dumps(original))
receipt.update(expectedExistingIgnores=15,originalExpectedExistingIgnores=14,
    originalController='Stopped after successful tests at stale ignore inventory assertion; raw controller and exit.json unchanged',
    ignoreInventoryAudit=audit,inventoryContinuation=True)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
(out/'original-exit.json').write_bytes((gate/'exit.json').read_bytes())
(out/'inventory-audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
env=os.environ.copy();env.update(original['environment']);env={k:v for k,v in env.items() if v is not None}
env['CARGO_NET_OFFLINE']='true';env.pop('MOTION_LOG',None)
binary=root/'target/gltf-scene87-contract/debug/motion-studio.exe'
commands=[('desktop-binary',['cargo','build','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),
          ('command-list',[str(binary),'--command-list'])]
for name,command in commands:
    row=dict(name=name,command=command)
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        process=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr)
        row['pid']=process.pid; row['exitCode']=process.wait()
    row.update(sourceUnchanged=source()==before,worktreeClean=not git('status','--porcelain'))
    for stream in ('stdout','stderr'): row[stream+'Sha256']=sha(out/(name+'.'+stream+'.log'))
    receipt['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    assert row['exitCode']==0 and row['sourceUnchanged'] and row['worktreeClean']
    if name=='command-list':
        catalogue=json.loads((out/(name+'.stdout.log')).read_text(encoding='utf-8'))
        assert 'register_model_asset' in json.dumps(catalogue) and not (out/(name+'.stderr.log')).read_bytes()
        row['binarySha256']=sha(binary)
receipt.update(sourceUnchanged=source()==before,completedUtc=datetime.now(timezone.utc).isoformat())
assert receipt['sourceUnchanged']
(gate/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,totals=totals,inventoryContinuation=True)))
