"""Real decoder/Session colour staging and unknown-metadata rejection; no inference."""
from pathlib import Path
import hashlib,json,math,os,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/model-depth-integration';probe=root/'.tools/ai-depth74/integration-probe'
attempt='v3'
out=root/'artifacts/pr-queue/issue3d-final-color-staging-v1';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def source():
    names=subprocess.check_output(['git','ls-files','-z'],cwd=work).decode().split('\0')
    r={p:sha(work/p) for p in names if p and (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
    for p in ('Cargo.toml','Cargo.lock','src/main.rs'):r['external-probe/'+p]=sha(probe/p)
    return r
before=source();build=json.loads((root/'artifacts/pr-queue/issue3d-final-integration-v1/accepted.json').read_text(encoding='utf-8'))
binary=root/'target/ai-depth74-contract/debug/motion-depth74-integration-probe.exe'
assert before==build['source'] and sha(binary)==build['nativeProbeBinarySha256']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work)
receipt=dict(head=build['head'],source=before,binarySha256=sha(binary),actualInference=False,commands=[])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
ffbin=root/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
env=os.environ.copy();env.pop('MOTION_LOG',None);env['PATH']=str(ffbin)+os.pathsep+env['PATH']
for dll in ffbin.glob('*.dll'):assert sha(binary.parent/dll.name)==sha(dll)
def run(name,cmd):
    assert source()==before
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        p=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr)
        row=dict(name=name,command=cmd,pid=p.pid);receipt['commands'].append(row)
        row['exitCode']=p.wait(timeout=60)
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    assert row['exitCode']==0,name
    return (out/(name+'.stdout.log')).read_bytes()
original=root/'artifacts/pr-queue/issue74-video-native-v3/project/assets/source.mp4'
good=out/'known';unknown=out/'unknown'
for d in (good,unknown):(d/'project/assets').mkdir(parents=True)
known=good/'project/assets/source.mp4'
# OpenH264 did not write the requested primary/transfer declarations. Stamp the
# independently authored fixture's intended BT.709 values into the bitstream,
# preserving encoded samples and timestamps; verify actual metadata before use.
run('declare-owned-bt709',[str(ffbin/'ffmpeg.exe'),'-nostdin','-v','error','-copyts','-i',str(original),'-map','0:v:0','-c:v','copy','-bsf:v','h264_metadata=colour_primaries=1:transfer_characteristics=1','-color_primaries','bt709','-color_trc','bt709','-video_track_timescale','1000000',str(known)])
known_meta=json.loads(run('ffprobe-known',[str(ffbin/'ffprobe.exe'),'-v','error','-select_streams','v:0','-show_entries','stream=color_primaries,color_transfer,color_space','-of','json',str(known)]))['streams'][0]
assert known_meta==dict(color_space='bt709',color_transfer='bt709',color_primaries='bt709')
run('remove-colour-declarations',[str(ffbin/'ffmpeg.exe'),'-nostdin','-v','error','-copyts','-i',str(known),'-map','0:v:0','-c:v','copy','-bsf:v','h264_metadata=colour_primaries=2:transfer_characteristics=2','-color_primaries','unknown','-color_trc','unknown','-video_track_timescale','1000000',str(unknown/'project/assets/source.mp4')])
meta=json.loads(run('ffprobe-unknown',[str(ffbin/'ffprobe.exe'),'-v','error','-select_streams','v:0','-show_entries','stream=color_primaries,color_transfer,color_space','-of','json',str(unknown/'project/assets/source.mp4')]))['streams'][0]
assert meta.get('color_primaries','unknown')=='unknown' and meta.get('color_transfer','unknown')=='unknown'
run('inspect',[str(binary),str(good),'inspect-color'])
run('reject',[str(binary),str(unknown),'reject-color'])
for name,d,stage in [('inspect',good,'backend'),('reject',unknown,'source_prepare')]:
    assert not (out/(name+'.stdout.log')).read_bytes()
    log=(d/'logs/motion-studio.log').read_text(encoding='utf-8')
    stderr=(out/(name+'.stderr.log')).read_text(encoding='utf-8')
    assert log.index('start #1 depth_infer asset=74')<log.index('ERROR')
    for stream in (log,stderr):assert 'request=1 operation=depth_infer asset=74' in stream and 'stage='+stage in stream
    assert 'start #1' not in stderr
    r=json.loads((d/'result.json').read_text(encoding='utf-8'));assert r['actualInference'] is False and r['actualSession'] and r['actualNativeFfmpeg']
    if name=='reject':assert 'primaries=Unspecified transfer=Unspecified' in stderr
    assert not (d/'scratch').exists()
run('raw-reference',[str(ffbin/'ffmpeg.exe'),'-nostdin','-v','error','-i',str(known),'-vf','select=eq(n\\,1),scale=in_color_matrix=bt709:in_range=tv:out_range=pc','-frames:v','1','-pix_fmt','rgb24','-f','rawvideo',str(out/'independent-bt709.rgb')])
# Evaluate the declared scene transfer with FFmpeg's independent expression
# evaluator. zscale's display-referred BT.709 uses BT.1886, and its different
# chroma reconstruction is not an oracle for this declared inverse-OETF policy.
linear='if(lt(val/255,0.081),(val/255)/4.5,pow(((val/255)+0.099)/1.099,1/0.45))'
encoded=f'if(lte({linear},0.0031308),12.92*({linear}),1.055*pow({linear},1/2.4)-0.055)'
expr=f'floor(255*({encoded})+0.5)'
transfer="lutrgb="+":".join(c+"='"+expr+"'" for c in ('r','g','b'))
run('srgb-reference',[str(ffbin/'ffmpeg.exe'),'-nostdin','-v','error','-i',str(known),'-vf','select=eq(n\\,1),scale=in_color_matrix=bt709:in_range=tv:out_range=pc,format=rgb24,'+transfer,'-frames:v','1','-pix_fmt','rgb24','-f','rawvideo',str(out/'independent-srgb.rgb')])
import numpy as np
from PIL import Image
native=np.fromfile(good/'original-decoded.rgb',np.uint8).reshape(64,96,3)
raw=np.fromfile(out/'independent-bt709.rgb',np.uint8).reshape(64,96,3)
raw_error=int(np.abs(native.astype(np.int16)-raw.astype(np.int16)).max());assert raw_error<=4
def orient(v):return np.rot90(v[5:57,7:87],k=-1)[:,::-1].copy()
lut=[]
for i in range(256):
    v=i/255;linear=v/4.5 if v<0.081 else ((v+0.099)/1.099)**(1/0.45)
    encoded=12.92*linear if linear<=0.0031308 else 1.055*linear**(1/2.4)-0.055
    lut.append(min(255,max(0,math.floor(encoded*255+0.5))))
lut=np.array(lut,np.uint8);actual=np.fromfile(good/'input.rgb',np.uint8).reshape(80,52,3)
assert np.array_equal(actual,lut[orient(native)])
independent=orient(np.fromfile(out/'independent-srgb.rgb',np.uint8).reshape(64,96,3))
srgb_error=int(np.abs(actual.astype(np.int16)-independent.astype(np.int16)).max())
# Preserve the original raw matrix bound (four) above. The additional nonlinear
# comparison derives its bound from the maximum step of the standard byte LUT;
# it does not replace or relax the raw matrix/registration assertion.
step=int(np.diff(lut.astype(np.int16)).max());assert srgb_error<=4*step+1,(srgb_error,step)
assert not np.array_equal(actual,orient(native)), 'BT.709 must not be mislabeled sRGB'
Image.fromarray(actual).save(good/'prepared-srgb.png')
assert before==source() and not subprocess.check_output(['git','status','--porcelain'],cwd=work)
receipt.update(transferPolicy='BT.709 inverse OETF then IEC sRGB encoding; no display viewing OOTF',reference='pinned FFmpeg swscale plus independent libavutil expression evaluator',rejectedReference='v2 zscale: different display transfer and chroma reconstruction; failure retained',sourceUnchanged=True,rawMatrixMax=raw_error,rawMatrixBound=4,srgbReferenceMax=srgb_error,
               srgbReferenceBound=4*step+1,standardByteLutBitExact=True,unknownRejectedBeforeBackend=True,
               defaultInfoStart=True,errorFileAndStderr=True,stdoutEmpty=True)
receipt['artifacts']={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()}
(out/'verified.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source','artifacts','commands')}),flush=True)
