"""Freeze current maintained source and run all optional depth CPU contracts."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/model-depth-integration';probe=root/'.tools/ai-depth74/integration-probe'
# CPU contracts and compilation use a separate target and source tree. They may
# run alongside the frozen suite; heavy actual inference has a separate guard.
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root/'.worktrees/3d-model-depth',text=True).strip()=='653dc2056a2f12d0cdc6fbb6907d2a2a44b60376'
out=root/'artifacts/pr-queue/issue3d-final-integration-v1';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
assert head=='06d1c71675de2e29a93d88bae520bdb341977169' and not subprocess.check_output(['git','status','--porcelain'],cwd=work)
def source():
    names=subprocess.check_output(['git','ls-files','-z'],cwd=work).decode().split('\0')
    r={p:sha(work/p) for p in names if p and (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
    for p in ('Cargo.toml','Cargo.lock','src/main.rs'):r['external-probe/'+p]=sha(probe/p)
    return r
before=source();env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/ai-depth74-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
env.pop('MOTION_LOG',None)
steps=[
 ('av-colour-metadata',['cargo','test','-p','motion-desktop-media','--no-default-features','--features','ffmpeg','--lib','av::rgb_encoding_tests','--locked','--offline','--','--test-threads=1'],1),
 ('video-session-jobs',['cargo','test','-p','motion-host','--no-default-features','--features','ai-depth','--test','depth_video','--test','depth_session','--test','depth_jobs','--locked','--offline','--','--test-threads=1'],26),
 ('onnx-unit',['cargo','test','-p','motion-host','--no-default-features','--features','ai-depth','--lib','depth::onnx::tests::','--locked','--offline','--','--test-threads=1'],4),
 ('default-host',['cargo','check','-p','motion-host','--no-default-features','--locked','--offline'],None),
 ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline'],None),
 ('native-probe-build',['cargo','build','--manifest-path',str(probe/'Cargo.toml'),'--locked','--offline'],None),
]
dll_source=root/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
for dll in dll_source.glob('*.dll'):
    dest=root/'target/ai-depth74-contract/debug/deps'/dll.name
    assert dest.exists() and sha(dest)==sha(dll)
r=dict(head=head,source=before,controllerPid=os.getpid(),steps=[],scope='Final integration source: 31 CPU colour/depth contracts, no-default host and FFmpeg/AI desktop checks, native final-source probe build; full maintained-main gate is separately frozen at pre-colour 653dc205')
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
for name,cmd,expected in steps:
    assert source()==before
    print(json.dumps(dict(start=name)),flush=True)
    step=dict(name=name,command=cmd)
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        p=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr)
        step['pid']=p.pid;r['steps'].append(step)
        (out/'started.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
        step['exitCode']=p.wait()
    step['sourceUnchanged']=source()==before
    step['worktreeClean']=not subprocess.check_output(['git','status','--porcelain'],cwd=work)
    for stream in ('stdout','stderr'):step[stream+'Sha256']=sha(out/(name+'.'+stream+'.log'))
    if expected is not None:
        rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (out/(name+'.stdout.log')).read_text(encoding='utf-8'))
        step['totals']=dict(zip(('passed','failed','ignored'),(sum(int(row[i]) for row in rows) for i in range(3))))
    (out/'exit.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
    assert step['sourceUnchanged'] and step['worktreeClean']
    assert step['exitCode']==0,name
    if expected is not None:assert step['totals']==dict(passed=expected,failed=0,ignored=0),step['totals']
r['nativeProbeBinarySha256']=sha(root/'target/ai-depth74-contract/debug/motion-depth74-integration-probe.exe')
(out/'accepted.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,head=head,passed=31,failed=0,ignored=0)),flush=True)
