"""Real product Session/FFmpeg/ONNX, independent FFmpeg pixels and official PyTorch reference."""
from pathlib import Path
import hashlib, json, math, os, subprocess, sys
root=Path('E:/Dev/aem');work=root/'.worktrees/model-depth-integration';home=root/'.tools/ai-depth74'
probe=home/'integration-probe'
assert (root/'artifacts/pr-queue/issue3d-combined-main-full-v1/accepted.json').is_file(), 'do not run heavy reference inference alongside frozen GPU/performance gate'
out=root/'artifacts/pr-queue/issue3d-final-native-depth-v1'
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def source():
    names=subprocess.check_output(['git','ls-files','-z'],cwd=work).decode().split('\0')
    r={p:sha(work/p) for p in names if p and (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
    for p in ('Cargo.toml','Cargo.lock','src/main.rs'):r['external-probe/'+p]=sha(probe/p)
    return r
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
assert head=='06d1c71675de2e29a93d88bae520bdb341977169' and not subprocess.check_output(['git','status','--porcelain'],cwd=work)
before=source();binary=root/'target/ai-depth74-contract/debug/motion-depth74-integration-probe.exe'
build=json.loads((root/'artifacts/pr-queue/issue3d-final-integration-v1/accepted.json').read_text(encoding='utf-8'))
assert build['source']==before and build['nativeProbeBinarySha256']==sha(binary)
receipt=dict(head=head,source=before,binarySha256=sha(binary),commands=[],motionLog=None)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
for p in ('Cargo.toml','Cargo.lock','src/main.rs'):
    (out/('probe-'+Path(p).name)).write_bytes((probe/p).read_bytes())
env=os.environ.copy();env.pop('MOTION_LOG',None)
for key,folder in [('TEMP','temp'),('TMP','temp'),('TORCH_HOME','torch-cache'),('HF_HOME','hf-cache'),('TORCHINDUCTOR_CACHE_DIR','inductor-cache'),('PYTHONPYCACHEPREFIX','pycache')]:
    p=home/folder;p.mkdir(exist_ok=True);env[key]=str(p);os.environ[key]=str(p)
env['CUDA_VISIBLE_DEVICES']='';os.environ['CUDA_VISIBLE_DEVICES']=''
ffbin=root/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
env['PATH']=str(ffbin)+os.pathsep+env['PATH']
# Mirror the application's explicit pinned-runtime staging. Do not depend on
# DLL search state inherited from numerical Python packages used by this driver.
receipt['pinnedRuntimeDlls']={}
for dll in ffbin.glob('*.dll'):
    staged=binary.parent/dll.name
    if not staged.exists():staged.write_bytes(dll.read_bytes())
    assert sha(staged)==sha(dll)
    receipt['pinnedRuntimeDlls'][dll.name]=sha(dll)
def run(name,cmd,timeout=180):
    assert before==source()
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        p=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr)
        row=dict(name=name,command=cmd,pid=p.pid);receipt['commands'].append(row)
        (out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
        row['exitCode']=p.wait(timeout=timeout)
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    assert row['exitCode']==0,name
    return (out/(name+'.stdout.log')).read_bytes()
import numpy as np
from PIL import Image
accepted_color=root/'artifacts/pr-queue/issue3d-final-color-staging-v1'
color_receipt=json.loads((accepted_color/'verified.json').read_text(encoding='utf-8'))
assert color_receipt['source']==before
assert color_receipt['rawMatrixMax']<=4 and color_receipt['srgbReferenceMax']<=13
for rel in ('crates/motion-desktop-media/src/av.rs','crates/motion-host/src/depth/video.rs','crates/motion-host/src/platform.rs','crates/motion-host/src/video_frame.rs','crates/motion-host/tests/depth_video.rs'):
    old=subprocess.check_output(['git','rev-parse','a0641ff8:'+rel],cwd=work).strip()
    assert old==subprocess.check_output(['git','rev-parse',head+':'+rel],cwd=work).strip()
assets=out/'project/assets';assets.mkdir(parents=True)
fixture=accepted_color/'known/project/assets/source.mp4'
assert sha(fixture)==color_receipt['artifacts']['known/project/assets/source.mp4']
(assets/'source.mp4').write_bytes(fixture.read_bytes())
meta=json.loads(run('ffprobe-colour',[str(ffbin/'ffprobe.exe'),'-v','error','-select_streams','v:0','-show_entries','stream=color_primaries,color_transfer,color_space','-of','json',str(assets/'source.mp4')]))['streams'][0]
assert meta==dict(color_space='bt709',color_transfer='bt709',color_primaries='bt709')
frames=json.loads(run('ffprobe-source',[str(ffbin/'ffprobe.exe'),'-v','error','-select_streams','v:0','-show_entries','frame=best_effort_timestamp_time','-of','json',str(assets/'source.mp4')]))['frames']
independent_pts=[round(float(f['best_effort_timestamp_time'])*1_000_000) for f in frames]
run('native-session',[str(binary),str(out)])
assert not (out/'native-session.stdout.log').read_bytes()
result=json.loads((out/'result.json').read_text(encoding='utf-8'));native=json.loads((out/'native-probe.json').read_text(encoding='utf-8'))
assert native['timestamps']==independent_pts
assert result['actualPtsUs']!=result['targetUs'] and result['actualNativeFfmpeg'] and result['actualInference']
index=independent_pts.index(result['actualPtsUs'])
actual_rgb=np.fromfile(out/'input.rgb',np.uint8).reshape(80,52,3)
assert np.array_equal(actual_rgb,np.fromfile(accepted_color/'known/input.rgb',np.uint8).reshape(80,52,3)), 'actual inference must consume accepted sRGB source preparation'
Image.fromarray(actual_rgb).save(out/'prepared-source.png')
assert sha(home/'models/depth_anything_v2_vits_518.onnx')=='274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
reference=home/'official-reference'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=reference,text=True).strip()=='a561b849ebae10a6f5ef49e26c83cbbcd36c71bf'
weights=home/'models/depth_anything_v2_vits.pth'
assert sha(weights)=='715fade13be8f229f8a70cc02066f656f2423a59effd0579197bbf57860e1378'
sys.path.insert(0,str(reference))
import cv2,torch
from depth_anything_v2.dpt import DepthAnythingV2
torch.set_num_threads(1);torch.set_num_interop_threads(1)
model=DepthAnythingV2(encoder='vits',features=64,out_channels=[48,96,192,384]).cpu().eval()
model.load_state_dict(torch.load(weights,map_location='cpu',weights_only=True),strict=True)
# Independent letterbox geometry, then official normalization/layout and PyTorch
# execution. Reference unletterboxing uses PyTorch's align_corners interpolation.
width,height=52,80;rw=math.floor(width*518/max(width,height)+0.5);rh=518
x,y=(518-rw)//2,0;boxed=np.zeros((518,518,3),np.uint8)
boxed[y:y+rh,x:x+rw]=cv2.resize(actual_rgb,(rw,rh),interpolation=cv2.INTER_CUBIC)
tensor,_=model.image2tensor(boxed[:,:,::-1].copy(),input_size=518)
with torch.no_grad():
    depth=model(tensor).unsqueeze(1)
    expected=torch.nn.functional.interpolate(depth[:,:,y:y+rh,x:x+rw],size=(height,width),mode='bilinear',align_corners=True)[0,0].numpy()
expected.astype('<f4').tofile(out/'official-reference.f32')
actual=np.fromfile(out/'output.f32','<f4').reshape(height,width)
error=np.abs(actual.astype(np.float64)-expected.astype(np.float64));amp=max(float(np.abs(expected).max()),1e-6)
maximum=float(error.max())/amp;mean=float(error.mean())/amp
assert maximum<=2e-4 and mean<=2e-5,(maximum,mean)
Image.fromarray(np.rint((actual-actual.min())/max(float(np.ptp(actual)),1e-6)*255).astype(np.uint8)).save(out/'relative-depth-visualization.png')
log=(out/'logs/motion-studio.log').read_text(encoding='utf-8');stderr=(out/'native-session.stderr.log').read_text(encoding='utf-8')
assert 'logging initialized level=INFO' in log and 'start #1 depth_infer asset=74' in log
assert log.index('start #1')<log.index('ERROR')
for stream in (log,stderr):
    assert 'ERROR' in stream and 'request=1 operation=depth_infer asset=74' in stream
    assert 'stage=source_prepare' in stream and 'video cache missing' in stream
assert f'phase=source_ready pts={result["actualPtsUs"]}/1000000' in log
assert 'start #1' not in stderr and 'logging initialized' not in stderr
assert before==source() and not subprocess.check_output(['git','status','--porcelain'],cwd=work)
receipt.update(result=result,maxNormalized=maximum,meanNormalized=mean,acceptedSrgbInputBitExact=True,rawMatrixMax=color_receipt['rawMatrixMax'],srgbReferenceMax=color_receipt['srgbReferenceMax'],colorReceiptSha256=sha(accepted_color/'verified.json'),
               independentFfprobePts=independent_pts,sourceUnchanged=True,errorFileAndStderr=True,stdoutEmpty=True,
               weightSha256=sha(weights),onnxSha256=sha(home/'models/depth_anything_v2_vits_518.onnx'))
receipt['artifacts']={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()}
(out/'verified.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source','artifacts','commands')}),flush=True)
