//! External acceptance: actual Session + FFmpeg original source + actual Onnx.
#[path = "E:/Dev/aem/.worktrees/model-depth-integration/desktop/app/src/logging.rs"]
mod logging;
mod engine {
    pub fn current_command() -> Option<(u64, &'static str, std::time::Duration)> { None }
}
use motion_host::{depth::{self, Backend, Cancellation, Estimate, Input, onnx::{Config, Onnx, Provider, PROCESSING}}, Platform, Session};
use motion_model::depth::{DepthGeometry, DepthModel};
use std::{fs, path::PathBuf, sync::Arc, thread, time::{Duration, Instant}};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;

struct Recorded { onnx: Onnx, out: PathBuf, owner: thread::ThreadId, inspect:bool }
impl Backend for Recorded {
    fn infer(&mut self, input:&Input, cancel:&Cancellation)->depth::Result<Estimate> {
        assert_ne!(self.owner,thread::current().id());
        fs::write(self.out.join("input.rgb"),input.rgb())?;
        fs::write(self.out.join("prepared.json"),serde_json::to_vec_pretty(&serde_json::json!({
            "source":input.key().source,"geometry":input.key().geometry,"model":input.key().model,
            "size":input.size(),"workerDifferentFromOwner":true
        }))?)?;
        if self.inspect {return Err(depth::Error::Backend("controlled RGB inspection stop".into()));}
        self.onnx.infer(input,cancel)
    }
}
fn wait(session:&mut Session)->Result<Arc<Estimate>> {
    let until=Instant::now()+Duration::from_secs(120);
    loop {
        if let Some(result)=session.poll_depth()? {return Ok(result);}
        assert!(Instant::now()<until,"real video inference did not finish");
        thread::sleep(Duration::from_millis(2));
    }
}
fn main()->Result<()> {
    let out=PathBuf::from(std::env::args().nth(1).ok_or("missing output path")?);
    let mode=std::env::args().nth(2).unwrap_or_else(||"inference".into());
    assert!(matches!(mode.as_str(),"inference"|"inspect-color"|"reject-color"));
    let _logger=logging::init(out.join("logs"))?;
    let root=out.join("project");let source=root.join("assets/source.mp4");
    let platform=motion_desktop_media::platform();assert_eq!(platform.name(),"libav");
    let mut probe=platform.probe_video(&source,None,None,&||Ok(()))?;
    probe.asset.id=74;probe.asset.path="assets/source.mp4".into();
    let asset=probe.asset;let pts=probe.timestamps;
    assert!(asset.variable_frame_rate && pts.len()>=3);
    assert!(pts.windows(3).any(|p|p[1]-p[0]!=p[2]-p[1]));
    assert!(asset.video_start_us>0);
    fs::write(out.join("native-probe.json"),serde_json::to_vec_pretty(&serde_json::json!({"asset":asset,"timestamps":pts}))?)?;
    let index=motion_media::video_cache_path(&root,&asset)?;
    fs::create_dir_all(index.parent().ok_or("no index parent")?)?;
    motion_media::save_index(&index,&asset,&pts)?;
    let good_index=fs::read(&index)?;
    let mut project=motion_core::Project::new(96,64,30,12)?;
    let mut layer=motion_core::Layer::solid(1,"Owned original video",[96.,64.],[0.;3],[1.;4]);
    layer.content=motion_core::Content::Video {video:motion_core::VideoClip {source_offset_us:asset.video_start_us,..motion_core::VideoClip::new(74)}};
    layer.set_interval(12,motion_core::ClipRange {in_frame:0.,out_frame:4.})?;
    project.video_assets.push(asset.clone());project.layers.push(layer);
    let before=project.clone();
    if mode=="inspect-color" {
        let target=asset.video_start_us+66_667;
        let mut decoder=platform.open_decoder(&source,asset.clone(),pts.clone())?;
        let decoded=decoder.frame(target,&||Ok(()))?;
        assert_eq!(decoder.rgb_encoding()?,motion_host::video_frame::RgbEncoding::Bt709);
        let rgba=decoded.rgba()?;
        let raw:Vec<u8>=rgba.chunks_exact(4).flat_map(|p|p[..3].iter().copied()).collect();
        fs::write(out.join("original-decoded.rgb"),raw)?;
    }
    let mut session=Session::new(project,root,platform)?;
    let home=PathBuf::from("E:/Dev/aem/.tools/ai-depth74");
    session.configure_depth(Recorded {onnx:Onnx::new(Config {
        python:home.join("venv/Scripts/python.exe"),model:home.join("models/depth_anything_v2_vits_518.onnx"),
        scratch:out.join("scratch"),provider:Provider::Cpu,
    })?,out:out.clone(),owner:thread::current().id(),inspect:mode=="inspect-color"})?;
    session.frame=2.;session.sample()?;
    let target=asset.video_start_us+66_667;
    let expected=pts[pts.partition_point(|p|*p<=target)-1];assert_ne!(target,expected);
    let geometry=DepthGeometry {source_size:[96,64],crop:[7,5,80,52],quarter_turns:1,mirror_x:true};
    let digest="274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434";
    let sha256:Vec<u8>=(0..64).step_by(2).map(|i|u8::from_str_radix(&digest[i..i+2],16).unwrap()).collect();
    let model=DepthModel {id:"depth-anything-v2-small".into(),revision:"a561b849ebae10a6f5ef49e26c83cbbcd36c71bf".into(),sha256:sha256.try_into().unwrap(),processing:PROCESSING.into()};
    if mode!="inference" {
        session.request_video_depth(1,geometry,model)?.ok_or("unexpected time miss")?;
        let error=wait(&mut session).expect_err("inspection/rejection must not run inference").to_string();
        if mode=="inspect-color" {
            assert!(error.contains("controlled RGB inspection stop"));
            assert!(out.join("input.rgb").exists());
        } else {
            assert!(error.contains("primaries=Unspecified transfer=Unspecified"),"{error}");
            assert!(!out.join("input.rgb").exists());
        }
        let status=session.depth_status()?.unwrap();
        assert_eq!(status.counts.submitted,1);assert_eq!(status.counts.failed,1);
        assert!(!status.installed && status.in_flight.is_none() && status.queue_depth==0);
        assert!(!out.join("scratch").exists());
        fs::write(out.join("result.json"),serde_json::to_vec_pretty(&serde_json::json!({
            "mode":mode,"actualInference":false,"actualNativeFfmpeg":true,"actualSession":true,
            "targetUs":target,"expectedPtsUs":expected,"cause":error,"guiEngine":false,"renderDepthBound":false
        }))?)?;
        logging::flush();return Ok(());
    }
    // Native missing-index failure must precede both decoder and inference.
    fs::remove_file(&index)?;
    session.request_video_depth(1,geometry.clone(),model.clone())?.ok_or("unexpected time miss")?;
    let negative=wait(&mut session).expect_err("missing real index must fail").to_string();
    assert!(negative.contains("video cache missing"));
    assert!(!out.join("input.rgb").exists() && !out.join("scratch").exists());
    fs::write(&index,good_index)?;
    let request=session.request_video_depth(1,geometry.clone(),model.clone())?.ok_or("unexpected miss")?;
    let result=wait(&mut session)?;
    let d=result.resource.descriptor();assert_eq!(d.source.pts.ticks,expected as i64);
    assert_eq!(d.source.pts.timescale,1_000_000);assert_eq!(d.geometry,geometry);assert_eq!(d.model,model);
    assert_eq!(d.size,[52,80]);assert_eq!(result.provider,"CPUExecutionProvider");
    assert!(result.costs.inference>Duration::ZERO && result.costs.source_prepare>Duration::ZERO);
    assert_eq!(result.costs.source_rgb_bytes,52*80*3);
    let mut raw=Vec::new();for v in result.resource.values(){raw.extend_from_slice(&v.to_le_bytes());}
    fs::write(out.join("output.f32"),raw)?;
    let status=session.depth_status()?.unwrap();
    assert_eq!(status.counts.submitted,2);assert_eq!(status.counts.failed,1);assert_eq!(status.counts.completed,1);
    assert!(status.installed && status.in_flight.is_none() && status.queue_depth==0);
    session.frame=0.;assert!(session.poll_depth()?.is_none());assert_eq!(session.engine.snapshot(),before);
    drop(result);drop(session);
    assert_eq!(fs::read_dir(out.join("scratch"))?.count(),0);
    fs::write(out.join("result.json"),serde_json::to_vec_pretty(&serde_json::json!({
        "request":request,"targetUs":target,"actualPtsUs":expected,"provider":"CPUExecutionProvider",
        "negative":negative,"actualInference":true,"actualNativeFfmpeg":true,"actualSession":true,
        "seekInvalidated":true,"guiEngine":false,"renderDepthBound":false
    }))?)?;
    logging::flush();Ok(())
}
