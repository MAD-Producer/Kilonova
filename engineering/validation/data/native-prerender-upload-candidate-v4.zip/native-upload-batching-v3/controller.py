"""Queued GPU/upload lifecycle controls and a changed-source paced study."""
from pathlib import Path
from datetime import datetime, timezone
from ctypes import wintypes as w
import ctypes
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/prerender-paced-study'
OUT = ROOT / 'artifacts/pr-queue/native-upload-batching-v3'
PATCH = ROOT / '.tools/issue-closure-review/native-upload-batching-fix.patch'
PRIOR = ROOT / 'artifacts/pr-queue/procedural-source-watch-v3/exit.json'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode('utf-8').strip()

def sources():
    return {p: hashlib.sha256((WORK / p).read_bytes()).hexdigest()
            for p in git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
            if p and (p.endswith(('.rs', '.toml', '.wgsl', '.py', '.json', '.yml', '.yaml', '.md'))
                      or p in ('Cargo.lock', 'NOTICE'))}

head = git('rev-parse', 'HEAD')
assert head == '510484160fde38d18b177ba8c69baf19af1730dc'
assert git('branch', '--show-current') == 'perf/82-native-upload-batching'
original = sources()
tests = {p: h for p, h in original.items() if '/tests/' in p or p.endswith('/tests.rs')}
patch = PATCH.read_bytes()
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'controller.py')
(OUT / 'fix.patch').write_bytes(patch)
report = dict(status='queued', priorController='v2 rejected zero tests; v3 preserves source/test/patch bytes and strict counts, refreshes package timestamps, proves both actual test inventories', head=head, source=original, steps=[], waitingForOwner=80204,
              startedUtc=datetime.now(timezone.utc).isoformat(),
              limits='Native queued-upload component only. Immediate API behavior is retained. Actual queued pixels, admission/eviction/shutdown and foreground consumption are required. No full-workspace, input-P95 or cross-platform acceptance; original native causes remain unconfirmed. A new exact-source paced result is recorded separately without relaxing any criterion.')

def save():
    (OUT / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

save()
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
kernel.OpenProcess.restype = w.HANDLE
kernel.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]
kernel.WaitForSingleObject.restype = w.DWORD
kernel.CloseHandle.argtypes = [w.HANDLE]
kernel.CloseHandle.restype = w.BOOL
owner = kernel.OpenProcess(0x100000, False, 80204)
print(json.dumps(dict(waitingForOwner=80204, sourceFiles=len(original))), flush=True)
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0', RUST_BACKTRACE='full',
           LOCALAPPDATA=str(OUT / 'owned-profile'),
           MOTION_PRERENDER_ENGINE_ARTIFACTS=str(OUT / 'native-engine'),
           MOTION_PRERENDER_PACED_ARTIFACTS=str(OUT / 'paced'))
fixed = original

def step(name, args, counts=None, negative=None, any_tests=False):
    print(json.dumps(dict(start=name)), flush=True)
    began = datetime.now(timezone.utc).isoformat()
    with (OUT / (name + '.stdout.log')).open('wb') as out, (OUT / (name + '.stderr.log')).open('wb') as err:
        code = subprocess.run(args, cwd=WORK, env=env, stdout=out, stderr=err).returncode
    stdout = (OUT / (name + '.stdout.log')).read_text(encoding='utf-8')
    stderr = (OUT / (name + '.stderr.log')).read_text(encoding='utf-8')
    actual = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored', stdout)
    unchanged = sources() == fixed and git('rev-parse', 'HEAD') == head
    if negative:
        expected_counts = [('0', '1', '0')] * (2 if name == 'negative-foreground-io' else 1)
        passed = code == 101 and actual == expected_counts and negative in stdout + stderr and unchanged
    else:
        passed = code == 0 and unchanged and (counts is None or actual == counts)
        if any_tests:
            passed = passed and bool(actual) and all(f == '0' for p, f, i in actual) and sum(int(p) for p, f, i in actual) > 0
    row = dict(name=name, command=args, exitCode=code, counts=actual, passed=passed,
               sourceUnchanged=unchanged, expectedNegative=negative, startedUtc=began,
               completedUtc=datetime.now(timezone.utc).isoformat())
    report['steps'].append(row)
    save()
    print(json.dumps(row), flush=True)
    assert passed, name

try:
    if owner:
        try:
            while True:
                result = kernel.WaitForSingleObject(owner, 10000)
                if result == 0:
                    break
                assert result == 258, f'owner wait failed: {result}'
        finally:
            kernel.CloseHandle(owner)
    prior = json.loads(PRIOR.read_text(encoding='utf-8'))
    assert prior.get('completedUtc') and prior['status'] not in ('running', 'queued')
    assert sources() == original and PATCH.read_bytes() == patch
    report.update(status='running', priorProceduralStatus=prior['status'])
    save()
    render = ['cargo', 'test', '-p', 'motion-render', '--locked', '--offline', '--lib']
    media = ['cargo', 'test', '-p', 'motion-desktop-media', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--lib']
    desktop = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline', '--bin', 'motion-studio']
    base = 'renderer::composition_frames::native::tests::deferred::'
    pixels = base + 'queued_native_upload_and_foreground_copy_share_one_submission_in_all_four_precisions'
    memory = base + 'unsubmitted_native_upload_retains_budget_after_eviction_until_a_real_flush'
    bad = base + 'queued_native_upload_rejects_bad_contract_and_foreign_owner_before_queue_io'
    foreground = 'movie::prerender::coordinator::tests::foreground_logging::native_install_keeps_default_foreground_quiet_and_preserves_worker_start'
    # Force the current worktree package roots into shared-target freshness.
    # Metadata timestamps change only; every source/test/patch byte is retained.
    touched = []
    for relative in ['crates/motion-render/src/lib.rs', 'crates/motion-desktop-media/src/lib.rs', 'desktop/app/src/main.rs']:
        path = WORK / relative
        old_time = path.stat().st_mtime_ns
        os.utime(path, None)
        touched.append(dict(path=relative, beforeMtimeNs=old_time, afterMtimeNs=path.stat().st_mtime_ns))
    assert sources() == original
    report['timestampOnlyBuildRefresh'] = touched
    save()
    step('media-test-inventory', [*media, '--', '--list'])
    inventory = (OUT / 'media-test-inventory.stdout.log').read_text(encoding='utf-8')
    assert foreground + ': test' in inventory
    assert 'a_normal_change_cannot_hide_a_later_watcher_fault_before_retirement: test' not in inventory
    assert 'procedural_sources_do_not_require_an_os_watcher_and_keep_real_job_lifetimes: test' not in inventory
    step('render-test-inventory', [*render, '--', '--list'])
    inventory = (OUT / 'render-test-inventory.stdout.log').read_text(encoding='utf-8')
    assert all(test + ': test' in inventory for test in [pixels, memory, bad])
    report['exactSourceTestInventoriesConfirmed'] = True
    save()
    step('negative-foreground-io', [*media, foreground, '--', '--exact', '--test-threads=1'], negative='healthy foreground cache installation must not flush the log sink')
    step('negative-separate-submit', [*render, pixels, '--', '--ignored', '--exact', '--test-threads=1'],
         negative='installation must not submit a separate empty command')
    step('negative-unsubmitted-lifetime', [*render, memory, '--', '--exact', '--test-threads=1'],
         negative='unsubmitted native destination must stay admitted after eviction')
    step('invalid-before', [*render, bad, '--', '--exact', '--test-threads=1'], counts=[('1', '0', '0')])
    report['negativeControlsConfirmed'] = True
    for p in ('crates/motion-render/src/renderer/composition_frames/native.rs', 'crates/motion-desktop-media/src/movie/prerender/coordinator.rs'):
        (OUT / (Path(p).stem + '.before.rs')).write_bytes((WORK / p).read_bytes())
    subprocess.run(['git', 'apply', '--check', str(PATCH)], cwd=WORK, check=True)
    subprocess.run(['git', 'apply', str(PATCH)], cwd=WORK, check=True)
    fixed = sources()
    assert all(fixed[p] == h for p, h in tests.items()), 'a test changed between controls'
    assert {p for p in fixed if fixed[p] != original[p]} == {'crates/motion-render/src/renderer/composition_frames/native.rs', 'crates/motion-desktop-media/src/movie/prerender/coordinator.rs'}
    report['fixedSource'] = fixed
    save()
    step('fixed-foreground-io', [*media, foreground, '--', '--exact', '--test-threads=1'], counts=[('1', '0', '0')])
    step('fixed-pixels', [*render, pixels, '--', '--ignored', '--exact', '--test-threads=1'], counts=[('1', '0', '0')])
    step('fixed-lifetime', [*render, memory, '--', '--exact', '--test-threads=1'], counts=[('1', '0', '0')])
    step('fixed-invalid', [*render, bad, '--', '--exact', '--test-threads=1'], counts=[('1', '0', '0')])
    step('all-cache-native', [*render, 'renderer::composition_frames::', '--', '--test-threads=1'], any_tests=True)
    step('immediate-four-precisions', [*render, 'renderer::composition_frames::native::tests::all_four_native_completion_uploads_preserve_encoded_storage_hdr_negative_and_alpha', '--', '--ignored', '--exact', '--test-threads=1'], counts=[('1', '0', '0')])
    step('media-prerender-regression', [*media, 'movie::prerender::', '--', '--test-threads=1'], counts=[('41', '0', '1')])
    step('default-worker-start', [*desktop, 'engine::pending_video_tests::prerender_logging::prerender_worker_start_is_on_disk_before_blocked_decode_and_error_uses_default_sinks', '--', '--exact', '--test-threads=1'], counts=[('1', '0', '0')])
    step('native-engine', [*desktop, 'engine::prerender::tests::native_idle_owner_presents_a_warm_frame_and_rejects_an_edited_source', '--', '--ignored', '--exact', '--test-threads=1'], counts=[('1', '0', '0')])
    step('paced', [*desktop, 'engine::prerender::tests::performance::paced_model_playback_records_paired_foreground_costs_and_real_cache_hits', '--', '--ignored', '--exact', '--test-threads=1'], counts=[('1', '0', '0')])
    spec = importlib.util.spec_from_file_location('paced_evidence', WORK / 'tools/analyze_prerender_paced.py')
    analyzer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analyzer)
    assessment = analyzer.assess(json.loads((OUT / 'paced/paced-costs.json').read_text(encoding='utf-8')))
    (OUT / 'paced-assessment.json').write_text(json.dumps(assessment, indent=2), encoding='utf-8')
    report['pacedAssessment'] = assessment
    report['noPacedRegression'] = assessment['noRegression']
    save()
    step('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline'])
    step('provenance', [sys.executable, 'tools/validate_provenance.py'])
    step('tool-inventory', [sys.executable, 'tools/validation_inventory.py'])
    report.update(status='accepted_native_upload_component_only', completedUtc=datetime.now(timezone.utc).isoformat())
    save()
    print(json.dumps(dict(status=report['status'], noPacedRegression=assessment['noRegression'])), flush=True)
except BaseException:
    report.update(status='failed_not_accepted', completedUtc=datetime.now(timezone.utc).isoformat())
    save()
    raise
