from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, re, subprocess, sys

root=Path('E:/Dev/aem');work=root/'.worktrees/gltf-main-validation'
out=root/'artifacts/pr-queue/issue87-maintained-main-full-v1';out.mkdir(exist_ok=False)
base='bcaeb8d0970b54714b2adb5b8eb15de2986014ce'
def git(*args,raw=False):
    data=subprocess.check_output(['git',*args],cwd=work)
    return data if raw else data.decode().strip()
head=git('rev-parse','HEAD')
assert not git('status','--porcelain')
subprocess.run(['git','merge-base','--is-ancestor',base,head],cwd=work,check=True)
assert not git('diff','--name-only',base,head,'--','desktop/app/src/panels')
def source():
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(git('ls-files','-z').split('\0'))
        if p and (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
def now():return datetime.now(timezone.utc).isoformat()

# Audit the maintained baseline's manual annotations before running. Additional
# manual tests introduced on main are not silently counted as our new ignores.
ignored_paths=git('grep','-l','-F','#[ignore',base,'--','*.rs').splitlines()
inventory=[]
for entry in ignored_paths:
    path=entry.split(':',1)[1]
    main_blob=git('rev-parse',base+':'+path); own_blob=git('rev-parse',head+':'+path)
    assert main_blob==own_blob,(path,'manual-test source changed')
    text=git('show',base+':'+path)
    for marker in re.finditer(r'#\[ignore(?:\s*=\s*"[^"]*")?\]',text):
        match=re.search(r'\bfn\s+(\w+)\s*\(',text[marker.end():marker.end()+1500])
        assert match,path
        inventory.append(dict(path=path,test=match[1],mainBlob=main_blob,headBlob=own_blob,
            annotation=marker[0]))
assert len(inventory)==18 and len({i['test'] for i in inventory})==len(inventory)
(out/'maintained-manual-inventory.json').write_text(json.dumps(dict(base=base,head=head,items=inventory),indent=2),encoding='utf-8')

before=source();env=os.environ.copy();target=root/'target/gltf-scene87-contract'
env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',
    CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',LOCALAPPDATA=str(out/'appdata'),RUST_BACKTRACE='1',
    MOTION_MODEL_UI_ARTIFACTS=str(out/'model-editor-fixture'))
for key in ('MOTION_MODEL_UI_PROJECT','MOTION_LOG','VK_DRIVER_FILES','VK_ICD_FILENAMES'):env.pop(key,None)
features='motion-host/diagnostics,motion-host/ai-depth,motion-host/gpu-tests,motion-ui/gpu-tests,motion-desktop/gpu-tests,motion-desktop/ffmpeg,motion-desktop-media/gpu-tests,motion-graph/gpu-tests'
steps=[
    ('panel-style-consumers',[sys.executable,'-c',"import runpy; runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
    ('provenance',[sys.executable,'tools/validate_provenance.py']),
    ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),
    ('workspace-tests',['cargo','test','--workspace','--exclude','motion-android','--locked','--offline','--features',features,'--no-fail-fast','--','--test-threads=1']),
    ('desktop-binary',['cargo','build','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),
    ('command-list',[str(target/'debug/motion-studio.exe'),'--command-list']),
]
receipt=dict(head=head,base=base,source=before,startedUtc=now(),controllerPid=os.getpid(),steps=[],
    scope='Rebased maintained main plus model/image-video depth, imported transform clips, shared native depth and camera consumers; full native GPU/FFmpeg/AI-depth; Android excluded',
    manualInventory=inventory,environment={k:env.get(k) for k in ('CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','TEMP','TMP','LOCALAPPDATA','MOTION_LOG')})
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
for name,command in steps:
    step=dict(name=name,command=command,startedUtc=now());print(json.dumps(dict(start=name,head=head)),flush=True)
    stdout_path=out/(name+'.stdout.log');stderr_path=out/(name+'.stderr.log')
    with stdout_path.open('wb') as stdout,stderr_path.open('wb') as stderr:
        process=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr)
        step['pid']=process.pid;receipt['steps'].append(step)
        (out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
        step['exitCode']=process.wait()
    step.update(completedUtc=now(),sourceUnchanged=source()==before,worktreeClean=not git('status','--porcelain'),
        stdoutSha256=hashlib.sha256(stdout_path.read_bytes()).hexdigest(),stderrSha256=hashlib.sha256(stderr_path.read_bytes()).hexdigest())
    if name=='workspace-tests':
        text=stdout_path.read_text(encoding='utf-8')
        results=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
        step['totals']=dict(zip(('passed','failed','ignored'),(sum(int(r[i]) for r in results) for i in range(3))))
        step['totals']['targets']=len(results)
        step['ignoredObserved']=[line for line in text.splitlines() if re.match(r'test .* \.\.\. ignored',line)]
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    assert step['sourceUnchanged'] and step['worktreeClean']
    print(json.dumps(dict(done=name,exit=step['exitCode'],totals=step.get('totals'))),flush=True)
    if step['exitCode']:sys.exit(step['exitCode'])
    if name=='workspace-tests':
        assert step['totals']['passed']>=3213 and step['totals']['failed']==0 and step['totals']['targets']>=318
        matches=[]
        for line in step['ignoredObserved']:
            identity=re.match(r'test (.*?) \.\.\. ignored',line)[1]
            candidates=[i for i in inventory if identity==i['test'] or identity.endswith('::'+i['test'])]
            assert len(candidates)==1,(identity,'ignore absent from maintained baseline')
            matches.append(dict(identity=identity,**candidates[0]))
        assert len(matches)==step['totals']['ignored'] and len({m['identity'] for m in matches})==len(matches)
        step['ignoredAudit']=matches
        step['uncompiledManualTests']=[i for i in inventory if not any(m['test']==i['test'] for m in matches)]
        required=('saved_model_keyframes_render_inside_the_editor',
            'backend_flight_has_actual_pts_and_same_sample_seek_cannot_install_late_success',
            'actual_child_keeps_protocol_and_diagnostics_in_separate_pipes',
            'shared_depth_interleaves_separate_sources_independently_of_submission_order',
            'shared_blend_queue_is_global_and_masked_fragments_do_not_write_depth',
            'shared_attachment_budget_failure_rolls_back_and_recovers_without_losing_prior_depth',
            'shared_failure_observation_is_bounded_retains_context_and_resets_after_recovery',
            'shared_draw_allowance_counts_primitives_across_all_instances',
            'imported_orthographic_camera_letterboxes_single_and_shared_native_draws',
            'imported_finite_and_infinite_perspective_cameras_drive_real_hardware_depth',
            'imported_gltf_clips_render_from_saved_owned_data_and_reject_missing_selection',
            'imported_clip_time_uses_layer_local_frames_without_rewriting_euler_keys')
        for test in required:assert re.search(r'test [^\n]*'+test+r' \.\.\. ok',text),test
    if name=='command-list':
        catalogue=json.loads(stdout_path.read_text(encoding='utf-8'))
        assert 'register_model_asset' in json.dumps(catalogue) and not stderr_path.read_bytes()
        step['binarySha256']=hashlib.sha256((target/'debug/motion-studio.exe').read_bytes()).hexdigest()
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
receipt.update(completedUtc=now(),sourceUnchanged=source()==before)
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,head=head)),flush=True)
