from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-import88'
art = root / 'artifacts/pr-queue'
helper = root / '.tools/issue-closure-review'
version = int(sys.argv[1])
out = art / f'tracking88-video-clock-v{version}'
report = json.loads((out / 'exit.json').read_text(encoding='utf-8'))
assert report['status'] == 'mapped_original_video_publication_and_regression_passed'
assert report['sourceUnchanged']
sha = lambda content: hashlib.sha256(content).hexdigest()
for relative, digest in report['source'].items():
    assert sha((work / relative).read_bytes()) == digest, relative
native = json.loads((out / 'mapped/report.json').read_text(encoding='utf-8'))
assert {case['case'] for case in native['cases']} == {'stretch', 'reverse', 'source-remap', 'source-hold'}
counts = {}
for step in report['steps']:
    assert step['exitCode'] == 0
    log = (out / f'{step["name"]}.stdout.log').read_text(encoding='utf-8', errors='replace')
    rows = [(int(p), int(f), int(i)) for p, f, i in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', log)]
    assert rows and 'test result: FAILED' not in log and not any(row[1] for row in rows)
    counts[step['name']] = dict(passed=sum(row[0] for row in rows), failed=0, ignored=sum(row[2] for row in rows), targets=len(rows))
assert counts['mapped-native']['passed'] == counts['existing-native']['passed'] == 1
native_elapsed = float(re.search(r'finished in ([0-9.]+)s',
    (out / 'mapped-native.stdout.log').read_text(encoding='utf-8')).group(1))
for path in ['crates/motion-model', 'crates/motion-core', 'crates/motion-render', 'desktop/app/src/panels']:
    assert not subprocess.check_output(['git', 'diff', '--name-only', 'codex/88-track-import-contract', '--', path], cwd=work), path
previous = json.loads(subprocess.check_output(['gh', 'pr', 'view', '581', '--repo', 'MAD-Producer/Kilonova', '--json', 'body'], cwd=work, encoding='utf-8'))['body'].replace('\r', '')
assert '### 图层时钟整合验收' not in previous
members = {}
for index in range(1, version + 1):
    directory = art / f'tracking88-video-clock-v{index}'
    assert directory.is_dir()
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in {'.json', '.log', '.rs', '.py', '.png'}:
            members[directory.name + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
members['publisher.py'] = Path(__file__).read_bytes()
source = {}
for path in (out / 'source').rglob('*.rs'):
    relative = path.relative_to(out / 'source').as_posix()
    content = (work / relative).read_bytes()
    assert content == path.read_bytes()
    staged = subprocess.check_output(['git', 'show', ':' + relative], cwd=work)
    assert staged == content.replace(b'\r\n', b'\n'), relative
    source[relative] = dict(rawSha256=sha(content), gitLfSha256=sha(staged))
archive = work / 'engineering/validation/data/tracking88-video-clock-v1.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, content in sorted(members.items()):
        zipped.writestr(name, content)
with zipfile.ZipFile(archive) as zipped:
    assert set(zipped.namelist()) == set(members)
    for name, content in members.items():
        assert zipped.read(name) == content, name
receipt = dict(status=report['status'], head=report['head'], integratedParent=report['integratedParent'], source=source,
    steps=report['steps'], counts=counts, native=native, elapsedSeconds=report['elapsedSeconds'],
    limits=['No new complete desktop/workspace regression or final-head cross-platform CI claim',
        'Offscreen actual decoder/GPU capture, not a retained native Surface',
        'Constant imported camera pose isolates footage time; independently bound objects do not implicitly follow footage remaps',
        'Original VFR/B-frame fixture and four bounded clock combinations, not every codec or nesting arrangement',
        'Photographed tracker quality and the full 3D route remain incomplete'],
    archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
        members={name: dict(bytes=len(content), sha256=sha(content)) for name, content in sorted(members.items())}))
archive.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
host = counts['host-lib']['passed']
media = counts['media-video']['passed']
integration = counts['host-integration']['passed']
document = f'''# #88 original-video publication under mapped layer time

PR #581 is synchronized with parent `{report['integratedParent']}`. The parent
already integrates maintained main `9d085c0f`; the merge is conflict-free and
retains its current-only schema 36. No new product behavior or UI is authored.

## Actual native combination controls

One new test executes four bounded combinations against the existing original
VFR/B-frame CTTS fixture: 3/2 stretch, reverse, linear source remap, and source
hold. Each uses the actual FFmpeg decoder, worker, host and GPU. An independently
addressed unretimed project supplies the expected image at an explicitly
tabulated source-frame instant. The reference must differ from frame zero and
contain more than 100 visible pixels, excluding empty/static-image false passes.
Every mapped image must match that native reference exactly; no image threshold
or original-source PTS is weakened or rewritten.

For each combination, a valid container with changed bytes is refused without
project/revision/pixel mutation. Identical original bytes remain admissible via
direct replacement and batched relink. Both transactions keep the authored layer
clock, original tracking PTS and camera binding through separate undo/redo
steps. Save and a fresh Engine reopen retain the complete project and image.

The imported camera observations are deliberately constant to isolate the
footage clock. The test does not imply that a camera/null on its own property
clock automatically follows a different footage layer's source remap. This
continues the explicitly documented binding semantics.

## Verification and evidence boundaries

- New four-case native test: one passed
- Existing native tracked-video replacement/relink control: one passed
- Complete host library: {host} passed
- Complete tracking_relink and asset_registration targets: {integration} passed
- Existing media video group: {media} passed
- Source hashes remained unchanged throughout every command

The two native tests run in separate processes because the existing file logger
is initialized only once per process. With MOTION_LOG unset, their actual file
logs contain pre-verification Info starts; original-cause Error records reach
both file and stderr and never contaminate stdout. The original native control
and its assertions remain unchanged apart from the new module declaration.
Both inherit the existing ffmpeg feature gate; the recorded native commands
explicitly enable it. A default desktop test invocation without ffmpeg does not
execute these video tests. The new four-case native test took {native_elapsed:.2f} seconds in
the successful invocation, separate from rebuilding and other regression steps.

The model, core and renderer source trees are unchanged from the integrated
parent; its broader package/renderer results remain historical evidence of that
parent, not a newly executed full regression on this commit. No panel differs
from maintained main. No dependency, third-party fixture or product retry was
added. The new source snapshots, native images, failed attempts and raw logs are
in the [receipt](data/tracking88-video-clock-v1.json) and
[verified archive](data/tracking88-video-clock-v1.zip).

The first invocation failed to compile the newly added test because it named
the camera binding under motion_host's tracking reexports rather than the
motion_core model API. Only that type path was corrected; no assertion changed.
The following source also adds explicit batched-relink coverage. Its first
runtime invocation correctly refused camera interpolation: the new fixture had
changed its PTS clock from 48,000 Hz to 1,000,000 Hz while retaining a gap budget
expressed in the old ticks. The fixture now converts 4000/48000 seconds to the
new units with integer flooring and explicitly asserts that the physical bound
does not increase. No original timestamp, image reference, assertion or physical
tolerance was relaxed. The next invocation also caught the new fixture reusing
a pre-undo revision for starting relink; the protocol correctly cancelled that
stale request. The fixture now captures the current revision after undo/redo
before staging relink. Cancellation and request lookup behavior are unchanged.
All earlier failures and source snapshots remain archived rather than counted
as passes.

This is actual offscreen GPU capture, not retained-window Surface acceptance.
It covers the existing CTTS source and four explicit clocks, not all codecs,
nesting or source mutations. Full desktop/workspace regression, final-head
cross-platform CI, photographed tracker quality and the full 3D route remain
separate work. Android remains outside the maintained scope.
'''
(work / 'engineering/validation/tracking88-video-clock-current.md').write_text(document, encoding='utf-8')
body = previous.rstrip() + f'''

### 图层时钟整合验收

同步父 PR #580 的主分支整合提交 `{report['integratedParent'][:8]}`，保留工程版本 36；没有新增产品或 panels 改动。

- 新增四组原生视频验收：3/2 伸缩、倒放、源时间重映射、定格
- 使用实际 FFmpeg 解码和 GPU 图像，与独立寻址的未变速原片逐像素比较
- 验证错误原片拒绝、同字节替换及批量重连、独立撤销重做、保存重开；保留图层时钟、原始 PTS 和绑定
- 新旧原生测试各 1 项通过；完整 host 库 {host} 项、两组集成 {integration} 项、media 视频 {media} 项通过
- 验证默认 Info 文件日志、Error 文件与 stderr、stdout 隔离，保留类型路径编译失败和新夹具漏换间隙单位的运行失败；向下取整换算保持原物理上限，未修改原断言

记录：`engineering/validation/tracking88-video-clock-current.md`。这是离屏原生图像验收，未宣称完整 desktop/workspace、保留窗口 Surface、实拍 tracker 或 #88/3D 路线完成；最终提交跨平台 CI 待完成。
'''
(helper / 'tracking88-video-clock-pr-body.md').write_text(body, encoding='utf-8')
(helper / 'tracking88-video-clock-commit.txt').write_text('''test(tracking): 整合基线并验证变速视频替换与重连

- 保留主分支图层时钟和原始解算身份校验
- 比较伸缩倒放重映射及定格的实际原生视频图像
- 验证错误原片拒绝和替换重连的撤销重开
- 归档源文件身份原始失败与主机回归结果
''', encoding='utf-8')
print(json.dumps(dict(status=receipt['status'], counts=counts, archiveBytes=archive.stat().st_size, members=len(members)), indent=2))
