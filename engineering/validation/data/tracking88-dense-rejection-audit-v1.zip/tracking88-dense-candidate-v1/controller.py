from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88';OUT=ROOT/'artifacts/pr-queue/tracking88-dense-candidate-v1'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
CAND=OUT/'candidate';SRC=CAND/'tools/tracking';SRC.mkdir(parents=True)
for name in ['plate_contract.py','plate_flow.py','track_plate.py','test_flow.py']:(SRC/name).write_bytes((WORK/'tools/tracking'/name).read_bytes())
p=SRC/'plate_flow.py';s=p.read_text();needle="            errors = np.linalg.norm(transform(matrix, self.reference[self.holdout])-self.points[self.holdout], axis=1)"
assert s.count(needle)==1
addition='''            # Experimental area alignment; all independent held-out gates below
            # remain unchanged. No oracle or benchmark coordinates enter here.
            warp = matrix @ np.linalg.inv(self.reference_matrix)
            extent=(self.reference_gray.shape[1],self.reference_gray.shape[0])
            aligned=cv2.warpPerspective(current,warp,extent,flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP)
            support=cv2.warpPerspective(np.full(current.shape,255,np.uint8),warp,extent,flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP)
            x,y,w,h=self.seed['roi']
            quad=transform(self.reference_matrix,[[x,y],[x+w,y],[x+w,y+h],[x,y+h]])
            mask=np.zeros(self.reference_gray.shape,np.uint8)
            cv2.fillConvexPoly(mask,np.rint(quad).astype(np.int32),255)
            mask[(support!=255)]=0
            mask=cv2.erode(mask,np.ones((5,5),np.uint8),borderType=cv2.BORDER_CONSTANT,borderValue=0)
            yy,xx=np.nonzero(mask)
            require(len(xx)>=256,'plane dense support too small')
            left,top,right,bottom=int(xx.min()),int(yy.min()),int(xx.max())+1,int(yy.max())+1
            local=np.eye(3,dtype=np.float32)
            try:
                correlation,local=cv2.findTransformECC(
                    self.reference_gray[top:bottom,left:right],aligned[top:bottom,left:right],local,
                    cv2.MOTION_HOMOGRAPHY,(cv2.TERM_CRITERIA_COUNT | cv2.TERM_CRITERIA_EPS,30,1e-5),
                    mask[top:bottom,left:right],5)
            except cv2.error as cause:
                raise ValueError('plane dense alignment did not converge') from cause
            require(np.isfinite(correlation),'plane dense correlation nonfinite')
            shift=np.array([[1.,0.,left],[0.,1.,top],[0.,0.,1.]])
            matrix=plane_matrix(warp @ shift @ local @ np.linalg.inv(shift) @ self.reference_matrix,self.seed['roi'])
'''
s=s.replace(needle,addition+needle);p.write_text(s)
real=(ROOT/'.tools/issue-closure-review/measure-tracking88-photographed-v5.py').read_text()
real=real.replace("WORK=ROOT/'.worktrees/tracking-import88'",'WORK=Path('+repr(CAND.as_posix())+')').replace('photographed-prototype-v5','photographed-dense-candidate-v1')
(OUT/'real-controller.py').write_text(real)
paths=['plate_contract.py','plate_flow.py','track_plate.py','test_flow.py'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),candidateSources={n:sha(SRC/n) for n in paths},publishedSources={n:sha(WORK/'tools/tracking'/n) for n in paths},steps=[])
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2))
save()
try:
 for phase,command in [('controls',[sys.executable,str(SRC/'test_flow.py'),'-v']),('full-real',[sys.executable,str(OUT/'real-controller.py')])]:
  with (OUT/(phase+'.stdout.log')).open('wb') as stdout,(OUT/(phase+'.stderr.log')).open('wb') as stderr:
   child=subprocess.Popen(command,cwd=WORK,stdout=stdout,stderr=stderr);row=dict(phase=phase,pid=child.pid,command=command);report['steps'].append(row);save();row['exitCode']=child.wait();save()
  assert all(sha(SRC/n)==h for n,h in report['candidateSources'].items())
  assert all(sha(WORK/'tools/tracking'/n)==h for n,h in report['publishedSources'].items())
 report['status']='candidate_measured_not_adopted'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps(dict(status=report['status'],steps=report['steps']),indent=2))
