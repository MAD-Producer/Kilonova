"""Blind dense measurement on a known failing segment; never adopts outputs."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,zipfile
import cv2,numpy as np
root=Path('E:/Dev/aem');out=root/'artifacts/pr-queue/tracking88-dense-fit-probe-v1';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
src=out/'baseline';src.mkdir()
for name in ['plate_contract.py','plate_flow.py']:
    (src/name).write_bytes(subprocess.check_output(['git','show','72423ec2:tools/tracking/'+name],cwd=root))
sys.path.insert(0,str(src));import plate_flow as flow
cv2.setNumThreads(1);cv2.setRNGSeed(88)
source=root/'artifacts/pr-queue/tracking88-real-planar-acquisition-v1/phone.avi'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
request=json.loads((root/'artifacts/pr-queue/tracking88-photographed-prototype-v6/periodic-manual-200.request.json').read_text())
edit=next(e for e in request['corrections'] if e['track']=='plane' and e['source_index']==1800)
seed=next(s for s in request['tracks'] if s['id']=='plane');manual=np.array(edit['observation']['matrix'])
ffmpeg=root/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
command=[str(ffmpeg),'-v','error','-nostdin','-threads','1','-noautorotate','-copyts','-i',str(source),'-map','0:0','-an','-sn','-dn','-vf','select=between(n\\,1800\\,1830)'.replace('\\\\','\\'),'-fps_mode','passthrough','-threads','1','-f','rawvideo','-pix_fmt','gray','pipe:1']
raw=subprocess.run(command,capture_output=True,check=True).stdout
assert len(raw)==31*640*480
images=np.frombuffer(raw,np.uint8).reshape(31,480,640)
reference=flow.prepare(images[0]);tracker=flow.Tracker(seed,reference);tracker.correct(reference,edit)
rows=[];previous=reference
for offset in range(1,31):
    current=flow.prepare(images[offset]);observation,score=tracker.observe(previous,current);previous=current
    row=dict(index=1800+offset,baselineVisible=observation is not None,baselineReason=tracker.reason)
    if observation is not None:
        matrix=np.array(observation['matrix']);warp=matrix@np.linalg.inv(manual)
        x,y,w,h=seed['roi'];quad=flow.transform(matrix,[[x,y],[x+w,y],[x+w,y+h],[x,y+h]])
        mask=np.zeros(current.shape,np.uint8);cv2.fillConvexPoly(mask,np.rint(quad).astype(np.int32),255)
        for point in flow.transform(matrix,tracker.reference[tracker.holdout]):
            cv2.circle(mask,tuple(np.rint(point).astype(int)),23,0,-1)
        mask=cv2.erode(mask,np.ones((5,5),np.uint8))
        try:
            coefficient,refined=cv2.findTransformECC(reference,current,warp.astype(np.float32),cv2.MOTION_HOMOGRAPHY,(cv2.TERM_CRITERIA_COUNT|cv2.TERM_CRITERIA_EPS,50,1e-6),mask,5)
            refined=flow.plane_matrix(refined.astype(float)@manual,seed['roi'])
            errors=np.linalg.norm(flow.transform(refined,tracker.reference[tracker.holdout])-tracker.points[tracker.holdout],axis=1)
            rms=float(np.sqrt(np.mean(errors**2)));maximum=float(errors.max())
            row.update(refinedMatrix=refined.tolist(),correlation=float(coefficient),heldOutRms=rms,heldOutMax=maximum,unchangedHeldOutGate=rms<=flow.LIMITS['heldOutRmsPixels'] and maximum<=flow.LIMITS['heldOutMaxPixels'])
            try:flow.check_plane_extrapolation(refined,tracker.reference[tracker.holdout],tracker.points[tracker.holdout],seed['roi']);row['unchangedConsensusGate']=True
            except ValueError as cause:row.update(unchangedConsensusGate=False,consensusCause=str(cause))
        except (cv2.error,ValueError) as cause:row['refinementFailure']=str(cause)[:2048]
        row['baselineMatrix']=matrix.tolist()
    rows.append(row)
# Ground truth is opened only after all blind measurements have completed.
gt=root/'artifacts/pr-queue/tracking88-real-planar-acquisition-v1/phone-gt.zip'
assert hashlib.sha256(gt.read_bytes()).hexdigest()=='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
with zipfile.ZipFile(gt) as z:
 def quad(index):
    a=np.array([float(v) for v in z.read(f'img_{index+200:05d}.txt').decode().split()]).reshape(2,4);return np.column_stack([a[1]-1,a[0]-1])
 initial=quad(0)
 for row in rows:
    actual=quad(row['index'])
    for key,label in [('baselineMatrix','baselineCornerMax'),('refinedMatrix','refinedCornerMax')]:
        if key in row:row[label]=float(np.linalg.norm(flow.transform(np.array(row[key]),initial)-actual,axis=1).max())
report=dict(status='blind_segment_measurement_complete_not_adopted',startedSource='72423ec2',rows=rows,completedUtc=datetime.now(timezone.utc).isoformat(),command=command,
    limits=['Same original video decode, ROI, authored correction and baseline thresholds; no published tracker output changed','Retrospective selected failing segment is diagnostic only, never full2300frame acceptance','Dense mask excludes heldout patch neighborhoods; full independent-support proof, synthetic negatives and whole-sequence quality still required'])
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(measured=len(rows),baselineVisible=sum(r['baselineVisible'] for r in rows),refined=sum('refinedMatrix' in r for r in rows),baselineWorst=max(r.get('baselineCornerMax',0) for r in rows),refinedWorst=max(r.get('refinedCornerMax',0) for r in rows),bothGates=sum(r.get('unchangedHeldOutGate',False) and r.get('unchangedConsensusGate',False) for r in rows))),flush=True)
