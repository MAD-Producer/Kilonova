"""Independently recompute existing rejected ECC results; no CV or decode."""
from pathlib import Path
import hashlib
import json
import math
import statistics
import zipfile

BASE = Path('E:/Dev/aem/artifacts/pr-queue')
OUT = BASE / 'tracking88-dense-rejection-audit-v1'
truth = BASE / 'tracking88-real-planar-acquisition-v1/phone-gt.zip'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert digest(truth) == 'd4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
with zipfile.ZipFile(truth) as bundle:
    names = sorted(i.filename for i in bundle.infolist() if not i.is_dir())
    assert names == [f'img_{i:05d}.txt' for i in range(200, 2500)]
    quads = []
    for name in names:
        assert bundle.getinfo(name).file_size <= 1024
        values = list(map(float, bundle.read(name).decode('ascii').split()))
        assert len(values) == 8 and all(map(math.isfinite, values))
        quads.append([(values[4+i]-1, values[i]-1) for i in range(4)])

def project(matrix, point):
    x, y = point
    values = [row[0]*x + row[1]*y + row[2] for row in matrix]
    assert all(map(math.isfinite, values)) and abs(values[2]) > 1e-10
    return values[0]/values[2], values[1]/values[2]

experiment = BASE / 'tracking88-dense-candidate-v1'
decision = json.loads((experiment / 'decision.json').read_text())
execution = json.loads((experiment / 'exit.json').read_text())
assert decision['status'] == 'rejected_do_not_adopt'
assert execution['status'] == 'candidate_measured_not_adopted'
assert all(row['exitCode'] == 0 for row in execution['steps'])
for name, expected in decision['candidateSources'].items():
    assert digest(experiment / 'candidate/tools/tracking' / name) == expected

report = dict(status='rejected_dense_candidate_independently_recomputed',
    method=decision['method'], annotation_sha256=digest(truth), variants=[],
    historical_execution_sha256=digest(experiment/'exit.json'),
    historical_decision_sha256=digest(experiment/'decision.json'), limits=[
    'Standard-library-only read of original retained outputs; no CV import, decode, tracking or inference',
    'Same2300frame original timeline, ROI, correction request, source identity and unchanged15pixel gate',
    'Historical candidate remains rejected and is not current product code or native acceptance',
    'No annotations, media, request payloads or complete per-frame outputs redistributed',
    'No confidence threshold, output filtering, coverage gate or existing assertion changed'])
request = None
bad_sets = []
for label, folder, expected_visible in (
    ('original', 'tracking88-photographed-prototype-v6', 915),
    ('dense-ecc', 'tracking88-photographed-dense-candidate-v1', 938)):
    root = BASE / folder
    config = json.loads((root/'periodic-manual-200.request.json').read_text())
    if request is None:
        request = config
    else:
        assert config == request
    path = root/'periodic-manual-200/tracks.mstrack'
    asset = json.loads(path.read_text())
    assert asset['source_sha256'] == 'c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
    assert asset['ticks_per_second'] == 100 and asset['source_pts'] == list(range(2300))
    track = next(t for t in asset['tracks'] if t['kind'] == 'plane')
    assert len(track['samples']) == 2300
    errors, bad = [], []
    manual = lost = 0
    for index, sample in enumerate(track['samples']):
        assert sample['source_index'] == index
        if sample['manual_correction']:
            manual += 1
            continue
        if index == 0:
            continue
        if sample['visibility'] != 'visible':
            lost += 1
            continue
        actual = [project(sample['observation']['matrix'], p) for p in quads[0]]
        error = max(math.dist(p, q) for p, q in zip(actual, quads[index]))
        errors.append(error)
        if error > 15:
            bad.append(index)
    assert len(errors) == expected_visible and manual == 11 and len(bad) == 21
    bad_sets.append(set(bad))
    report['variants'].append(dict(name=label, raw_output_sha256=digest(path),
        automatic_visible=len(errors), automatic_lost=lost, manual_samples=manual,
        maximum_error=max(errors), rms_error=math.sqrt(statistics.mean(x*x for x in errors)),
        over_5_pixels=sum(x > 5 for x in errors), over_15_pixels=len(bad), bad_source_indices=bad))
assert report['variants'][1]['automatic_visible'] == decision['candidate']['automaticVisible']
assert abs(report['variants'][1]['maximum_error']-decision['candidate']['maxPixels']) < 1e-9
report.update(same_bad_indices=bad_sets[0] == bad_sets[1],
    common_bad_count=len(set.intersection(*bad_sets)),
    disposition='Do not repeat post-LK ECC as an untried remedy; full quality still fails')
OUT.mkdir(exist_ok=False)
(OUT/'audit.py').write_bytes(Path(__file__).read_bytes())
(OUT/'receipt.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
print(json.dumps(report, indent=2))
