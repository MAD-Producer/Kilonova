from pathlib import Path
import hashlib,json,re,zipfile,subprocess
root=Path('E:/Dev/aem');work=root/'.worktrees/rational-frame-rates85';out=root/'artifacts/pr-queue/clock85-full-desktop-v3'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((out/'exit.json').read_text(encoding='utf-8'))
assert r['exitCode']==0 and r['sourceUnchanged'] and r['completedUtc']
assert all(sha(work/n)==h for n,h in r['source'].items())
metadata=json.loads((out/'cargo-metadata.json').read_text(encoding='utf-8-sig'))
packages=[p for p in metadata['packages'] if p['name'] in ['motion-desktop','motion-ui']]
expected=[]
for p in packages:
 for t in p['targets']:
  if t['test']:expected.append((t['name'],t['kind'][0]))
 if any(t['doctest'] for t in p['targets']):expected.append((p['name'].replace('-','_'),'doc'))
stderr=(out/'tests.stderr.log').read_text(encoding='utf-8',errors='replace')
invocations=re.findall(r'^\s*(?:Running|Doc-tests) .+$',stderr,re.M)
assert len(invocations)==len(expected)==len(r['summaries'])==31,(len(invocations),expected)
for name,kind in expected:
 assert any((f'Doc-tests {name}' if kind=='doc' else f'{name.replace("-","_")}-') in line for line in invocations),(name,kind)
totals=[sum(int(s[i]) for s in r['summaries']) for i in [1,2,3,5]]
assert totals[1:]==[0,72,0],totals
assert r['summaries'][0][1:]==['1730','0','72','0','0']
audit=dict(status='complete_selected_desktop_ui_passed',head=r['head'],main=r['main'],passed=totals[0],failed=0,originalIgnored=72,filtered=0,targets=31,elapsedSeconds=r['elapsedSeconds'],command=r['command'],expectedTargets=expected,invocations=invocations,limits=['Selected desktop/UI packages, not whole workspace or later source','Desktop test codegen-units4 only, default compiler AV unresolved; old native stack/heap failures not established fixed','Original exec handle71502 unavailable after continuation; persisted terminal receipt exit0 plus complete Cargo outputs and absent original process establish completion. No invented controller exit or rerun','New parent expression budget observation2ca4 not included in this frozen2a5 source'])
(out/'independent-target-audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
entries={f'run/{p.name}':p for p in out.iterdir() if p.is_file()}
entries['environment/run.ps1']=root/'.tools/issue-closure-review/run-clock85-full-desktop-v3.ps1'
entries['environment/publish.py']=Path(__file__)
manifest=dict(audit=audit,entries={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in entries.items()})
archive=work/'engineering/validation/data/frame-rate85-complete-desktop-ui-v3.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
 for n,p in entries.items():z.write(p,n)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,p in entries.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(p)
receipt=dict(audit=audit,archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members=len(entries)+1)
archive.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
(work/'engineering/validation/frame-rate85-complete-desktop-ui-current.md').write_text(f'''# Complete desktop/UI runtime regression on the aligned clock branch

Status: all 31 selected Cargo targets passed on frozen source `{r['head']}`,
including main `{r['main']}`. This is not full issue 85/86/88 completion.

The desktop binary completed **1730 passed, zero failed, 72 original ignored**.
Across desktop integration targets, complete UI unit/integration targets and UI
documentation tests, the command completed **{totals[0]} passed, zero failed,
72 original ignored, zero filtered** in {r['elapsedSeconds']} seconds. Actual
Cargo invocations and result summaries were matched against Cargo metadata.
No test-name filters, assertion changes, budget increases or ignore edits were
introduced. The approved graph-readout fixture and native project-precision
menu tests both passed in this full run.

The command enabled FFmpeg and retained default GPU selection. Only the desktop
test code generation partition count was overridden to four, as documented in
the earlier compiler diagnostic. This does not establish that the original
default compiler access violation or historical native stack/heap failures are
fixed. New parent expression interruption observations are outside this frozen
source and require separate integration validation. Android is excluded.

The controller persisted terminal exit code zero and unchanged source hashes.
After the continuation, its original exec handle was unavailable; its original
process was absent and complete raw Cargo outputs independently established
completion. No controller return code was invented and no tests were restarted.

The [archive](data/frame-rate85-complete-desktop-ui-v3.zip) retains original
controller, environment, output, complete source hashes, Cargo metadata and
target audit. Every archive member was read back and hash-verified; its
[receipt](data/frame-rate85-complete-desktop-ui-v3.json) records scope and limits.
''',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='audit'}));print(json.dumps(dict(passed=totals[0],targets=len(expected))))
