from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,time

root=Path('E:/Dev/aem');work=root/'.worktrees/rational-frame-rates85';out=root/'artifacts/pr-queue/clock85-full-desktop-v3';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
git=lambda *a:subprocess.check_output(['git',*a],cwd=work).decode().strip()
assert git('rev-parse','HEAD')=='2a5cec9f7b7127d3bc73ab72f66255d6f926711f' and not git('status','--porcelain')
assert git('rev-parse','origin/main')=='b4133761df4bed5341d104740ebbe9820ad14554'
sha=lambda b:hashlib.sha256(b).hexdigest()
source={n:sha((work/n).read_bytes()) for n in git('ls-files','crates','desktop','Cargo.toml','Cargo.lock').splitlines() if (work/n).is_file() and n.endswith(('.rs','.wgsl','Cargo.toml','Cargo.lock'))}
env=os.environ.copy();env.pop('MOTION_LOG',None)
for name in ['MOTION_TRACKED_RPC_DIR','MOTION_TRACKED_SURFACE_ARTIFACTS','MOTION_TRACKED_PAIR_NATIVE_DIR','MOTION_TRACKED_PAIR_AUDIO_DIR','MOTION_TRACKING_VIDEO_CLOCK_DIR','MOTION_TRACKING_VIDEO_NATIVE_DIR']:env.pop(name,None)
env['LOCALAPPDATA']=str(out/'appdata')
command=['cargo','test','-p','motion-desktop','-p','motion-ui','--features','motion-desktop/ffmpeg','--no-fail-fast','--locked','--offline','--config','profile.test.package.motion-desktop.codegen-units=4','--','--test-threads=1']
report=dict(status='running',head=git('rev-parse','HEAD'),main=git('rev-parse','origin/main'),command=command,source=source,startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Complete selected desktop/UI packages including FFmpeg, no test-name filter; original ignore markers retained','Only desktop test codegen-units4 build override; unchanged assertions, runtime budgets, stack and production profile. Earlier default compiler AV and native product faults remain separate unresolved records','One own GPU workload, default adapter and default Info; all controlled caches/temp/output on E; no Android'])
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
try:
 with (out/'tests.stdout.log').open('wb') as stdout,(out/'tests.stderr.log').open('wb') as stderr:
    p=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);report['cargoPid']=p.pid;save();report['exitCode']=p.wait()
 report['summaries']=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',(out/'tests.stdout.log').read_text(encoding='utf-8',errors='replace'))
 report['sourceUnchanged']=all(sha((work/n).read_bytes())==h for n,h in source.items());save()
 assert report['exitCode']==0 and report['summaries'] and report['sourceUnchanged']
 assert all(s[0]=='ok' and s[2]=='0' and s[5]=='0' for s in report['summaries'])
 assert any(int(s[1])>=1700 for s in report['summaries']),'Missing complete desktop binary summary'
 report['status']='complete_selected_desktop_ui_runtime_passed_with_documented_codegen_override'
except BaseException as cause:report.update(status='failed_original_outputs_retained',failure=repr(cause));raise
finally:report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3));save()
print(json.dumps({k:v for k,v in report.items() if k!='source'}),flush=True)
