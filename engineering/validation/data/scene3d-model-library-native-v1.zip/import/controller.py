from pathlib import Path
from datetime import datetime,timezone
from ctypes import wintypes
import ctypes,hashlib,json,os,re,shutil,subprocess

root=Path('E:/Dev/aem');work=root/'.worktrees/model-import-native'
out=root/'artifacts/pr-queue/model-import-regression-v5';out.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=work).decode().strip()
def sources():
    paths=git('ls-files','--cached','--others','--exclude-standard','-z').split('\0')
    return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml')) or p=='Cargo.lock')}
source=sources();changed=git('diff','--name-only','HEAD').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
assert not any(p.startswith('desktop/app/src/panels/') for p in changed)
report=dict(baseHead=git('rev-parse','HEAD'),source=source,steps=[],status='waiting for the confirmed active previous controller')
for p in changed:
    if p in source:
        dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/p,dest)
shutil.copyfile(__file__,out/'controller.py')
previous=57008
command=subprocess.check_output(['powershell','-NoProfile','-Command',f'(Get-CimInstance Win32_Process -Filter "ProcessId = {previous}").CommandLine'],text=True).strip()
assert 'continue-scene87-workspace-v3.py' in command,command
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.WaitForSingleObject.restype=wintypes.DWORD
kernel.CloseHandle.argtypes=[wintypes.HANDLE]
handle=kernel.OpenProcess(0x00100000,False,previous)
assert handle,ctypes.get_last_error()
report.update(previousController=dict(pid=previous,command=command,boundUtc=datetime.now(timezone.utc).isoformat()))
(out/'waiting.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(waitingForController=previous)),flush=True)
while True:
    status=kernel.WaitForSingleObject(handle,1000)
    if status==0:break
    assert status==258,status
kernel.CloseHandle(handle)
previous_receipt=root/'artifacts/pr-queue/scene87-full-workspace-continuation-v3/accepted.json'
assert previous_receipt.is_file(),'Previous full workspace did not finish acceptance; inspect its retained failure before continuing'
previous_data=json.loads(previous_receipt.read_text(encoding='utf-8'))
assert previous_data['failed']==0 and previous_data['sourceUnchanged']
assert sources()==source,'Model import source changed while queued'
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',
           CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
           MOTION_MODEL_IMPORT_UI_ARTIFACTS=str(out/'native-ui'))
common=['--features','ffmpeg,motion-host/ai-depth','--locked','--offline']
test=['cargo','test','-p','motion-desktop',*common]
steps=[('focused-import',[*test,'engine::model_import_tests::','--','--test-threads=1']),
       ('mcp',[*test,'mcp::tests::','--','--test-threads=1']),
       ('native-ui',[*test,'shell::model_import_tests::dropped_obj_publishes_an_editable_model_and_native_editor_pixels','--','--exact','--test-threads=1']),
       ('desktop-regression',[*test,'--','--test-threads=1']),
       ('host-library',['cargo','test','-p','motion-host','--features','ai-depth','--lib','--locked','--offline','--','--test-threads=1']),
       ('desktop-check',['cargo','check','-p','motion-desktop',*common]),
       ('style',['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
       ('provenance',['python','tools/validate_provenance.py'])]
report.update(status='running',inheritedFullWorkspaceHead=previous_data['head'])
for name,command in steps:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as so,(out/(name+'.stderr.log')).open('wb') as se:
        code=subprocess.run(command,cwd=work,env=env,stdout=so,stderr=se).returncode
    stdout=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
    row=dict(name=name,command=command,exitCode=code,sourceUnchanged=sources()==source,
             counts=re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',stdout),
             ignoredTests=re.findall(r'^test (\S+) \.\.\. ignored(?:, (.*))?$',stdout,re.M))
    report['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    assert code==0 and row['sourceUnchanged'],row
    if name not in ['desktop-check','style','provenance']:
        assert row['counts'] and all(int(f)==0 for _,f,_ in row['counts']),row
        assert sum(int(p) for p,_,_ in row['counts'])>0,row
        if name=='focused-import':assert sum(int(p) for p,_,_ in row['counts'])==6,row
        if name=='native-ui':assert sum(int(p) for p,_,_ in row['counts'])==1,row
log=(out/'native-ui/logs/motion-studio.log').read_text(encoding='utf-8')
stderr=(out/'native-ui/child.stderr.txt').read_text(encoding='utf-8')
assert 'model_import' in log and 'missing.obj' in log and 'missing.obj' in stderr
assert 'start #' in log and ' import_model' in log
report.update(status='accepted',completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=sources()==source,
              nativeUi=json.loads((out/'native-ui/accepted.json').read_text(encoding='utf-8')),
              note='Focused controls overlap the full desktop regression and are not added into a distinct total; ignored legacy manual UI/performance fixtures remain enumerated')
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True)),flush=True)
