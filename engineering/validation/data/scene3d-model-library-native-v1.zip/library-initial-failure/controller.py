from pathlib import Path
from datetime import datetime, timezone
from ctypes import wintypes
import ctypes, hashlib, json, os, re, shutil, subprocess

root = Path('E:/Dev/aem')
work = root / '.worktrees/model-library-native'
out = root / 'artifacts/pr-queue/model-library-regression-v1'
out.mkdir(exist_ok=False)
shutil.copyfile(__file__, out / 'controller.py')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=work).decode().strip()

def sources():
    paths = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {p: hashlib.sha256((work / p).read_bytes()).hexdigest() for p in paths if p and
            (p.endswith(('.rs', '.toml', '.wgsl', '.py', '.json', '.yml', '.yaml')) or p == 'Cargo.lock')}

source = sources()
assert not git('status', '--porcelain'), 'Freeze the own source before queueing validation'
report = dict(head=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'),
              source=source, steps=[], status='queued')
previous = 65072
command = subprocess.check_output(['powershell', '-NoProfile', '-Command',
    f'(Get-CimInstance Win32_Process -Filter "ProcessId = {previous}").CommandLine'], text=True).strip()
assert 'validate-model-import-stdio-v4.py' in command, command
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
handle = kernel.OpenProcess(0x00100000, False, previous)
assert handle, ctypes.get_last_error()
report['previousController'] = dict(pid=previous, command=command, boundUtc=datetime.now(timezone.utc).isoformat())
(out / 'waiting.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(dict(waitingForController=previous)), flush=True)
while True:
    status = kernel.WaitForSingleObject(handle, 1000)
    if status == 0:
        break
    assert status == 258, status
kernel.CloseHandle(handle)
prior = json.loads((root / 'artifacts/pr-queue/model-import-stdio-v4/accepted.json').read_text(encoding='utf-8'))
assert prior.get('sourceUnchanged'), 'Prior source-bound MCP acceptance did not pass'
assert sources() == source, 'Library source changed while queued'

env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0',
           CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           MOTION_MODEL_LIBRARY_UI_ARTIFACTS=str(out / 'native-ui'),
           MOTION_MODEL_IMPORT_UI_ARTIFACTS=str(out / 'import-native-ui'))
common = ['--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline']
test = ['cargo', 'test', '-p', 'motion-desktop', *common]
native = 'panels::project::tests::native::models::model_library_native_menu_and_placement_reuse_owned_sources_in_both_languages'
steps = [
    ('library', [*test, 'engine::model_library_tests::', '--', '--test-threads=1'], 2),
    ('import-regression', [*test, 'engine::model_import_tests::', '--', '--test-threads=1'], 6),
    ('project-import', [*test, 'shell::project_import::tests::', '--', '--test-threads=1'], None),
    ('drag', [*test, 'panels::project_drag::tests::', '--', '--test-threads=1'], 4),
    ('native-ui', [*test, native, '--', '--ignored', '--exact', '--test-threads=1'], 1),
    ('desktop-regression', [*test, '--', '--test-threads=1'], None),
    ('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', *common], 0),
    ('style', ['python', '-c', "import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"], 0),
    ('provenance', ['python', 'tools/validate_provenance.py'], 0),
]
report.update(status='running')
for name, args, expected in steps:
    print(json.dumps(dict(start=name)), flush=True)
    with (out / (name + '.stdout.log')).open('wb') as so, (out / (name + '.stderr.log')).open('wb') as se:
        code = subprocess.run(args, cwd=work, env=env, stdout=so, stderr=se).returncode
    stdout = (out / (name + '.stdout.log')).read_text(encoding='utf-8')
    counts = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored', stdout)
    row = dict(name=name, command=args, exitCode=code, counts=counts, sourceUnchanged=sources() == source,
               ignoredTests=re.findall(r'^test (\S+) \.\.\. ignored(?:, (.*))?$', stdout, re.M))
    report['steps'].append(row)
    (out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], row
    if expected != 0:
        assert counts and all(int(f) == 0 for _, f, _ in counts), row
        passed = sum(int(p) for p, _, _ in counts)
        assert passed > 0 and (expected is None or passed == expected), row
        if name == 'native-ui':
            receipt = json.loads((out / 'native-ui/accepted.json').read_text(encoding='utf-8'))
            assert len(receipt['cases']) == 4
            for case in receipt['cases']:
                assert case['redCompositionPixels'] > 200 and case['separatePlacementUndoRedo']
                assert case['originalSourcesRemoved'] and case['sharedAsset']
                assert len(case['screenshots']) == 4 and all(Path(p).is_file() for p in case['screenshots'])
                directory = Path(case['screenshots'][0]).parent
                log = (directory / 'logs/motion-studio.log').read_text(encoding='utf-8')
                stderr = (directory / 'child.stderr.txt').read_text(encoding='utf-8')
                assert 'missing-library.obj' in log and 'missing-library.obj' in stderr
                assert 'INFO' in log and 'start #' in log and 'project_register_model' in log
            report['nativeUi'] = receipt
report.update(status='accepted', completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=sources() == source,
              note='Focused controls overlap full desktop regression. Manual native screenshots executed explicitly; other existing manual fixtures enumerated, not counted as passes. Android excluded.')
(out / 'accepted.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True)), flush=True)
