from pathlib import Path
from datetime import datetime, timezone
from ctypes import wintypes
import ctypes, hashlib, json, os, queue, shutil, subprocess, threading
from PIL import Image

root = Path('E:/Dev/aem')
work = root / '.worktrees/model-import-native'
out = root / 'artifacts/pr-queue/model-import-stdio-v4'
out.mkdir(exist_ok=False)
shutil.copyfile(__file__, out / 'controller.py')
previous = 56808
command = subprocess.check_output(['powershell', '-NoProfile', '-Command',
    f'(Get-CimInstance Win32_Process -Filter "ProcessId = {previous}").CommandLine'], text=True).strip()
assert 'validate-model-import-regression-v5.py' in command, command
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
handle = kernel.OpenProcess(0x00100000, False, previous)
assert handle, ctypes.get_last_error()
(out / 'waiting.json').write_text(json.dumps(dict(pid=previous, command=command,
    boundUtc=datetime.now(timezone.utc).isoformat()), indent=2), encoding='utf-8')
print(json.dumps(dict(waitingForController=previous)), flush=True)
while True:
    status = kernel.WaitForSingleObject(handle, 1000)
    if status == 0:
        break
    assert status == 258, status
kernel.CloseHandle(handle)
prior = json.loads((root / 'artifacts/pr-queue/model-import-regression-v5/accepted.json').read_text(encoding='utf-8'))
assert prior['status'] == 'accepted' and prior['sourceUnchanged']

def sources():
    paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=work).decode().split('\0')
    return {p: hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and
        (p.endswith(('.rs', '.toml', '.wgsl', '.py', '.json', '.yml', '.yaml')) or p == 'Cargo.lock')}

assert sources() == prior['source'], 'Product changed after accepted regression'
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0',
    CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    LOCALAPPDATA=str(out/'config'))
build = ['cargo', 'build', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline']
with (out/'build.stdout.log').open('wb') as so, (out/'build.stderr.log').open('wb') as se:
    code = subprocess.run(build, cwd=work, env=env, stdout=so, stderr=se).returncode
(out/'build.json').write_text(json.dumps(dict(command=build, exitCode=code), indent=2), encoding='utf-8')
assert code == 0 and sources() == prior['source']
runtime = out/'runtime'
runtime.mkdir()
target = root/'target/gltf-animation87-contract/debug'
for path in [target/'motion-studio.exe', *target.glob('*.dll')]:
    shutil.copyfile(path, runtime/path.name)
(out/'runtime.json').write_text(json.dumps({p.name: hashlib.sha256(p.read_bytes()).hexdigest()
    for p in runtime.iterdir()}, indent=2), encoding='utf-8')
original = out/'originals'
original.mkdir()
obj = original/'editable.obj'
obj.write_text('mtllib paint.mtl\nv -1 -1 0\nv 1 -1 0\nv 0 1 0\nusemtl Red\nf 1 2 3\n', encoding='utf-8')
(original/'paint.mtl').write_text('newmtl Red\nKd 1 0 0\nillum 0\n', encoding='utf-8')
project = out/'project'

class Client:
    def __init__(self, name):
        self.name = name
        self.number = 0
        self.responses = queue.Queue()
        self.raw = []
        self.requests = []
        self.err = (out/(name+'.stderr.log')).open('wb')
        self.process = subprocess.Popen([str(runtime/'motion-studio.exe'), '--mcp', '--project', str(project)],
            cwd=runtime, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.err,
            creationflags=subprocess.CREATE_NO_WINDOW)
        def read():
            for line in self.process.stdout:
                self.raw.append(line)
                self.responses.put(line)
            self.responses.put(None)
        self.reader = threading.Thread(target=read, daemon=True)
        self.reader.start()

    def send(self, method, params, notify=False):
        message = dict(jsonrpc='2.0', method=method, params=params)
        if not notify:
            self.number += 1
            message['id'] = self.number
        self.requests.append(message)
        self.process.stdin.write((json.dumps(message)+'\n').encode())
        self.process.stdin.flush()
        if notify:
            return
        line = self.responses.get(timeout=120)
        assert line is not None, f'{method}: unexpected EOF'
        response = json.loads(line)
        assert response.get('jsonrpc') == '2.0' and response.get('id') == self.number, response
        assert 'error' not in response, response
        return response['result']

    def start(self):
        self.send('initialize', dict(protocolVersion='2025-11-25', capabilities={},
            clientInfo=dict(name='owned-model-acceptance', version='1')))
        self.send('notifications/initialized', {}, notify=True)

    def tool(self, name, args=None, failed=False):
        result = self.send('tools/call', dict(name=name, arguments=args or {}))
        assert result['isError'] == failed, result
        return result if failed else result['structuredContent']

    def close(self):
        self.process.stdin.close()
        try:
            code = self.process.wait(timeout=30)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait()
            raise
        finally:
            self.reader.join(timeout=5)
            self.err.close()
            (out/(self.name+'.stdout.log')).write_bytes(b''.join(self.raw))
            (out/(self.name+'.requests.json')).write_text(json.dumps(self.requests, indent=2), encoding='utf-8')
        assert code == 0, code
        assert len(self.raw) == sum('id' in request for request in self.requests)
        for line in self.raw:
            assert json.loads(line)['jsonrpc'] == '2.0', 'Non-protocol stdout'

def pixels(value):
    return Image.open(value['path']).convert('RGBA')

client = Client('first')
try:
    client.start()
    tools = client.send('tools/list', {})['tools']
    declaration = next(tool for tool in tools if tool['name'] == 'import_model')
    assert set(declaration['inputSchema']['required']) == {'path', 'expectedRevision'}
    before = client.tool('motion_state')
    missing = str(original/'missing.obj')
    refusal = client.tool('import_model', dict(path=missing, expectedRevision=before['revision']), failed=True)
    assert 'model_import' in str(refusal) and 'missing.obj' in str(refusal)
    assert client.tool('motion_state')['project'] == before['project']
    after = client.tool('import_model', dict(path=str(obj), expectedRevision=before['revision']))
    assert after['modelImport']['owned'] and len(after['project']['model_assets']) == 1
    obj.unlink()
    (original/'paint.mtl').unlink()
    first = pixels(client.tool('render_preview', dict(frame=0)))
    red = sum(r > g+20 and r > b+20 for r,g,b,a in first.getdata())
    assert red > 500, red
    first.save(out/'owned-model-first.png')
    assert client.tool('motion_history', dict(operation='undo'))['project'] == before['project']
    assert client.tool('motion_history', dict(operation='redo'))['project'] == after['project']
    client.tool('motion_save')
finally:
    client.close()
reopened = Client('reopened')
try:
    reopened.start()
    assert reopened.tool('motion_state')['project'] == after['project']
    second = pixels(reopened.tool('render_preview', dict(frame=0)))
    assert second.tobytes() == first.tobytes()
    second.save(out/'owned-model-reopened.png')
finally:
    reopened.close()
logs = list((out/'config').rglob('motion-studio.log*'))
log = '\n'.join(p.read_text(encoding='utf-8') for p in logs)
stderr = (out/'first.stderr.log').read_text(encoding='utf-8')
assert 'start #' in log and ' import_model' in log
assert 'missing.obj' in log and 'missing.obj' in stderr
assert sources() == prior['source']
receipt = dict(completedUtc=datetime.now(timezone.utc).isoformat(), sourceUnchanged=True,
    defaultLogLevel=True, fileError=True, stderrError=True, stdoutAllJsonRpc=True,
    redPixels=red, reopenedPixelsExact=True, originalSourcesRemoved=True,
    oneStepUndoRedo=True, project=after['project'], inheritedRegression='model-import-regression-v5',
    binarySha256=hashlib.sha256((runtime/'motion-studio.exe').read_bytes()).hexdigest())
(out/'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True, redPixels=red)), flush=True)
