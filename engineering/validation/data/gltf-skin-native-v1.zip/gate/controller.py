from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,re,subprocess
root=Path('E:/Dev/aem'); work=root/'.worktrees/gltf-skin'
out=root/'artifacts/pr-queue/issue87-skin-native-v1'; out.mkdir(exist_ok=False)
def git(*args): return subprocess.check_output(['git',*args],cwd=work).decode().strip()
def source():
 paths=set(git('ls-files','-co','--exclude-standard','-z').split('\0'))
 return {p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in sorted(paths) if p and (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
assert git('rev-parse','HEAD').startswith('dafd66b5')
assert not git('diff','--name-only','HEAD','--','desktop/app/src/panels')
before=source(); env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-scene87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',LOCALAPPDATA=str(out/'appdata'),MOTION_MODEL_UI_ARTIFACTS=str(out/'model-editor-fixture'))
for key in ('MOTION_LOG','MOTION_MODEL_UI_PROJECT','VK_DRIVER_FILES','VK_ICD_FILENAMES'):env.pop(key,None)
receipt=dict(base=git('rev-parse','HEAD'),main='7ba96e6e0abd496c42b36501b74c417377569f21',source=before,controllerPid=os.getpid(),startedUtc=datetime.now(timezone.utc).isoformat(),steps=[],scope='Owned CPU/native linear blend skin, morph-before-skin, sampled joint palettes, actual saved-project consumer; singular/reflected effective skin matrices explicitly refused; Android excluded; whole workspace/cross-platform gates separate')
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
commands=[('provenance',['python','tools/validate_provenance.py']),
 ('style-consumers',['python','-c','from tools.ci_desktop import verify_style_consumers; verify_style_consumers()']),
 ('scene-cpu',['cargo','test','-p','motion-scene','--locked','--offline','--','--test-threads=1']),
 ('scene-clippy',['cargo','clippy','-p','motion-scene','--all-targets','--locked','--offline','--','-D','warnings']),
 ('core-model',['cargo','test','-p','motion-core','--test','model_layers','--locked','--offline','--','--test-threads=1']),
 ('native-model',['cargo','test','-p','motion-render','--features','gpu-tests','--test','model_layers','--test','scene_gpu','--locked','--offline','--','--test-threads=1']),
 ('native-error-boundary',['cargo','test','-p','motion-render','--lib','--features','gpu-tests','--locked','--offline','wrapped_native_','--','--test-threads=1']),
 ('desktop-check',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),
 ('desktop-model',['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','model_layer_tests','--','--test-threads=1'])]
expected={'scene-cpu':82,'core-model':5,'native-model':46,'native-error-boundary':2,'desktop-model':1}
for name,cmd in commands:
 print(json.dumps(dict(start=name)),flush=True)
 with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
  process=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr);code=process.wait()
 row=dict(name=name,command=cmd,exitCode=code,sourceUnchanged=before==source())
 for stream in ('stdout','stderr'):row[stream+'Sha256']=hashlib.sha256((out/(name+'.'+stream+'.log')).read_bytes()).hexdigest()
 text=(out/(name+'.stdout.log')).read_text(encoding='utf-8')
 totals=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 if totals:row['totals']=dict(zip(('passed','failed','ignored'),(sum(int(v[i]) for v in totals) for i in range(3))))
 receipt['steps'].append(row);(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(dict(done=name,exitCode=code,totals=row.get('totals'))),flush=True)
 assert code==0 and row['sourceUnchanged']
 if name in expected:assert row['totals']==dict(passed=expected[name],failed=0,ignored=0)
 if name=='native-model':
  for name in ('two_joint_morph_pixels_match_independent_geometry_in_four_precisions_and_pending_frames','shared_skin_depth_and_transparency_use_the_deformed_world_centre','skin_budget_refusal_preserves_pixels_and_abandoned_buffers_release_capacity','shared_mesh_different_skins_and_unskinned_primitive_keep_independent_transforms','skinned_normal_maps_match_independent_nonuniform_basis_and_unsupported_poses_keep_pixels'):
   assert re.search(r'test skins::'+name+r' \.\.\. ok',text),name
  assert 'imported_joint_animation_renders_from_saved_owned_project_and_seeks_without_source_files ... ok' in text
 if name=='native-error-boundary':assert 'wrapped_native_skin_keeps_original_typed_resource_refusal ... ok' in text
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=source()==before)
assert receipt['sourceUnchanged']; (out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(json.dumps(dict(accepted=True,totalPassed=sum(s.get('totals',{}).get('passed',0) for s in receipt['steps']))))
