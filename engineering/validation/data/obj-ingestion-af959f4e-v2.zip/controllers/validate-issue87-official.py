from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys

root=Path('E:/Dev/aem');work=root/'.worktrees/gltf-scene'
fixture=root/'.tools/gltf-scene87-fixtures'
label=sys.argv[1] if len(sys.argv)>1 else 'v1'
assert label in ['v1','v2','v3','v4']
out=root/('artifacts/pr-queue/issue87-official-'+label);out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def sources():
    names=list((work/'crates/motion-scene').rglob('*.rs'))+[work/'Cargo.toml',work/'Cargo.lock',work/'crates/motion-scene/Cargo.toml',
        work/'desktop/app/src/logging.rs',root/'.tools/gltf-scene87-probe/src/main.rs',root/'.tools/gltf-scene87-probe/Cargo.toml',root/'.tools/gltf-scene87-probe/Cargo.lock']
    return {str(p.relative_to(root)):sha(p.read_bytes()) for p in names}
before=sources();manifest=json.loads((fixture/'manifest.json').read_text(encoding='utf-8'))
for item in manifest['files']:
    assert sha((fixture/item['path']).read_bytes())==item['sha256'],item['path']
binary=root/'target/gltf-scene87-contract/debug/motion-scene87-probe.exe'
binary_sha=sha(binary.read_bytes());env=os.environ.copy();env.pop('MOTION_LOG',None)
receipt=dict(startedUtc=datetime.now(timezone.utc).isoformat(),base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
    sources=before,binarySha256=binary_sha,fixture=manifest,cases=[])
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
reports={}
for model in ['Avocado','BoxVertexColors']:
    reports[model]=[]
    for kind,extension in [('glTF','gltf'),('glTF-Binary','glb')]:
        source=fixture/'Models'/model/kind/(model+'.'+extension)
        case=out/(model+'-'+kind);case.mkdir();command=[str(binary),str(source),str(case)]
        with (case/'stdout.log').open('wb') as stdout,(case/'stderr.log').open('wb') as stderr:
            process=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr,timeout=120)
        row=dict(model=model,kind=kind,command=command,exitCode=process.returncode)
        receipt['cases'].append(row);(out/'running.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
        assert process.returncode==0,row
        assert not (case/'stdout.log').read_bytes() and not (case/'stderr.log').read_bytes()
        logs=(case/'logs/motion-studio.log').read_text(encoding='utf-8')
        assert 'INFO' in logs and 'start #8701 gltf_import source=87' in logs
        assert 'start #8702 gltf_unfreeze source=87' in logs
        assert 'ERROR' not in logs and 'DEBUG' not in logs
        report=json.loads((case/'report.json').read_text(encoding='utf-8'))
        assert report['frozenRoundtripEqual'] and report['meshes'] and report['instances']
        reports[model].append(report)
        row.update(reportSha256=sha((case/'report.json').read_bytes()),bundleSha256=sha((case/'scene.mscn').read_bytes()),
            vertices=sum(len(p['positions']) for m in report['meshes'] for p in m),
            triangles=sum(len(p['indices'])//3 for m in report['meshes'] for p in m),images=len(report['images']))
        assert sources()==before and sha(binary.read_bytes())==binary_sha
    for field in ['meshes','materials','textures','samplers','images','instances']:
        assert reports[model][0][field]==reports[model][1][field],(model,field)

negative=out/'negative-traversal';negative.mkdir()
doc=json.loads((fixture/'Models/Avocado/glTF/Avocado.gltf').read_text(encoding='utf-8'))
doc['buffers'][0]['uri']='../blocked.bin'
source=negative/'input.gltf';source.write_text(json.dumps(doc),encoding='utf-8')
command=[str(binary),str(source),str(negative)]
with (negative/'stdout.log').open('wb') as stdout,(negative/'stderr.log').open('wb') as stderr:
    result=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr,timeout=30)
assert result.returncode==2 and not (negative/'stdout.log').read_bytes()
file=(negative/'logs/motion-studio.log').read_text(encoding='utf-8');console=(negative/'stderr.log').read_text(encoding='utf-8')
for text in [file,console]:
    assert 'ERROR' in text and 'gltf_import #8701 source=87 elapsed_ms=' in text
    assert 'phase=resource' in text and 'relative path' in text
assert 'INFO' not in console and 'start #8701 gltf_import source=87' in file
receipt['negative']=dict(command=command,exitCode=result.returncode,stdoutEmpty=True,errorFileAndStderr=True,infoOnlyInFile=True)
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=sources()==before)
assert receipt['sourceUnchanged']
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,models=2,variants=4,negativeDefaultSink=True,cases=receipt['cases'])),flush=True)
