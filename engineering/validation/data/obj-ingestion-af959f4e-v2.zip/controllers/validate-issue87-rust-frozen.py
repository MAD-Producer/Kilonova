from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys
root=Path('E:/Dev/aem');work=root/'.worktrees/gltf-scene'
label=sys.argv[1] if len(sys.argv)>1 else 'v2'
assert label in ['v2','v3','obj-v1','obj-v2']
out=root/('artifacts/pr-queue/issue87-rust-'+label);out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def source():
    paths=list((work/'crates/motion-scene').rglob('*.rs'))+[work/'Cargo.toml',work/'Cargo.lock',work/'crates/motion-scene/Cargo.toml']
    return {p.relative_to(work).as_posix():sha(p.read_bytes()) for p in paths}
inputs=source();env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-scene87-contract'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true')
steps=[['cargo','fmt','-p','motion-scene','--','--check'],
    ['cargo','test','-p','motion-scene','--locked','--offline','--','--test-threads=1'],
    ['cargo','clippy','-p','motion-scene','--all-targets','--locked','--offline','--','-D','warnings']]
receipt=dict(startedUtc=datetime.now(timezone.utc).isoformat(),base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),source=inputs,steps=[])
for i,command in enumerate(steps):
    stdout=out/(str(i)+'-stdout.log');stderr=out/(str(i)+'-stderr.log')
    with stdout.open('wb') as o,stderr.open('wb') as e: result=subprocess.run(command,cwd=work,env=env,stdout=o,stderr=e)
    row=dict(command=command,exitCode=result.returncode,sourceUnchanged=source()==inputs,stdoutSha256=sha(stdout.read_bytes()),stderrSha256=sha(stderr.read_bytes()))
    receipt['steps'].append(row);(out/'running.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    assert result.returncode==0 and row['sourceUnchanged'],row
    if i==1:
        totals=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout.read_text(encoding='utf-8'))
        expected=45 if label.startswith('obj-') else 25
        assert sum(int(v[0]) for v in totals)==expected and all(v[1:]==('0','0') for v in totals)
        receipt['tests']=dict(passed=expected,failed=0,ignored=0)
receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=source()==inputs)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,tests=receipt['tests'],sourceUnchanged=receipt['sourceUnchanged'])),flush=True)
