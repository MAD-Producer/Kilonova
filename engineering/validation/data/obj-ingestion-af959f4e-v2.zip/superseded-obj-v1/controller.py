from pathlib import Path
from datetime import datetime,timezone
import base64,hashlib,json,os,struct,subprocess,zlib

root=Path('E:/Dev/aem');work=root/'.worktrees/gltf-scene'
out=root/'artifacts/pr-queue/issue87-obj-files-v1';out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
binary=root/'target/gltf-scene87-contract/debug/motion-scene87-probe.exe'
def sources():
    files=list((work/'crates/motion-scene').rglob('*.rs'))+[work/'Cargo.toml',work/'Cargo.lock',work/'crates/motion-scene/Cargo.toml',work/'desktop/app/src/logging.rs',root/'.tools/gltf-scene87-probe/src/main.rs',root/'.tools/gltf-scene87-probe/Cargo.toml',root/'.tools/gltf-scene87-probe/Cargo.lock']
    return {str(p.relative_to(root)):sha(p.read_bytes()) for p in files}
before=sources();binary_sha=sha(binary.read_bytes());env=os.environ.copy();env.pop('MOTION_LOG',None)
receipt=dict(startedUtc=datetime.now(timezone.utc).isoformat(),base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),sources=before,binarySha256=binary_sha,cases=[],fixtureAuthor='Motion Studio contributors',fixtureOrigin='independently generated numerical OBJ/MTL/glTF and PNG; no upstream asset')
(out/'controller.py').write_bytes(Path(__file__).read_bytes())

def check_source():
    assert sources()==before and sha(binary.read_bytes())==binary_sha
def run(name,source,operation,expected=0,cause=None):
    case=out/name;case.mkdir();command=[str(binary),str(source),str(case)]
    with (case/'stdout.log').open('wb') as stdout,(case/'stderr.log').open('wb') as stderr:
        process=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr,timeout=60)
    row=dict(name=name,command=command,exitCode=process.returncode)
    receipt['cases'].append(row);(out/'running.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    assert process.returncode==expected,row
    assert not (case/'stdout.log').read_bytes()
    file=(case/'logs/motion-studio.log').read_text(encoding='utf-8');console=(case/'stderr.log').read_text(encoding='utf-8')
    assert f'start #8701 {operation} source=87' in file and 'DEBUG' not in file
    if expected==0:
        assert not console and 'ERROR' not in file
        report=json.loads((case/'report.json').read_text(encoding='utf-8'));assert report['frozenRoundtripEqual']
        row.update(reportSha256=sha((case/'report.json').read_bytes()),bundleSha256=sha((case/'scene.mscn').read_bytes()),stdoutEmpty=True,stderrEmpty=True)
    else:
        for text in [file,console]:
            assert 'ERROR' in text and f'{operation} #8701 source=87 elapsed_ms=' in text and cause in text
        assert 'INFO' not in console
        row.update(stdoutEmpty=True,errorFileAndStderr=True,infoOnlyInFile=True,cause=cause);report=None
    check_source();return report,case

inputs=out/'inputs';(inputs/'mats').mkdir(parents=True);(inputs/'textures').mkdir()
obj=b'o Triangle\ng Front Detail\nmtllib mats/scene.mtl\nv 0 0 0\nv 1 0 0\nv 0 1 0\nvt 0 0\nvt 1 0\nvt 0 1\nvn 0 0 2\nusemtl Paint\nf -3/-3/-1 -2/-2/-1 -1/-1/-1\n'
mtl=b'newmtl Paint\nKa .1 .1 .1\nKd .2 .4 .8\nKs .5 .5 .5\nNs 64\nNi 1.5\nd .8\nillum 2\nmap_Kd -s 2 2 -clamp on ../textures/check%20er.png\nbump -bm .2 ../textures/check%20er.png\n'
def chunk(name,data):return struct.pack('>I',len(data))+name+data+struct.pack('>I',zlib.crc32(name+data))
png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',2,2,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(bytes([0,255,255,255,255,128,128,128,255,0,128,128,128,255,255,255,255,255])))+chunk(b'IEND',b'')
positions=[0.,0.,0.,1.,0.,0.,0.,1.,0.];normals=[0.,0.,1.]*3;uv=[0.,1.,1.,1.,0.,0.]
data=struct.pack('<24f',*(positions+normals+uv))
gltf=dict(asset={'version':'2.0'},buffers=[dict(byteLength=len(data),uri='mesh.bin')],bufferViews=[dict(buffer=0,byteOffset=0,byteLength=36),dict(buffer=0,byteOffset=36,byteLength=36),dict(buffer=0,byteOffset=72,byteLength=24)],
    accessors=[dict(bufferView=0,componentType=5126,count=3,type='VEC3',min=[0,0,0],max=[1,1,0]),dict(bufferView=1,componentType=5126,count=3,type='VEC3'),dict(bufferView=2,componentType=5126,count=3,type='VEC2')],
    meshes=[dict(primitives=[dict(attributes={'POSITION':0,'NORMAL':1,'TEXCOORD_0':2},material=0)])],materials=[dict(pbrMetallicRoughness=dict(baseColorFactor=[.2,.4,.8,.8],baseColorTexture=dict(index=0)))],images=[dict(uri='textures/check%2520er.png')],textures=[dict(source=0)],nodes=[dict(mesh=0)],scenes=[dict(nodes=[0])],scene=0)
files={'triangle.obj':obj,'mats/scene.mtl':mtl,'textures/check%20er.png':png,'mesh.bin':data,'triangle.gltf':json.dumps(gltf).encode()}
copies=out/'fixture-copies';copies.mkdir()
receipt['fixtures']=[]
for name,content in files.items():
    (inputs/name).write_bytes(content);path=copies/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(content)
    receipt['fixtures'].append(dict(path=name,sha256=sha(content),bytes=len(content)))
obj_report,obj_case=run('obj-triangle',inputs/'triangle.obj','obj_import')
gltf_report,_=run('gltf-equivalent',inputs/'triangle.gltf','gltf_import')
for field in ['meshes','instances','images']:assert obj_report[field]==gltf_report[field],field
assert obj_report['sourceFormat']=='Obj' and obj_report['objMetadata']['primitives'][0]['groups']==['Front','Detail']
assert len(obj_report['extraResources'])==1 and len(obj_report['images'])==1 and len(obj_report['textures'])==2
classic=obj_report['materials'][0]['model']['Wavefront'];assert classic['specular_exponent']==64 and classic['optical_density']==1.5
assert classic['maps']['Bump']['bump_multiplier']==0.2 and classic['maps']['Diffuse']['clamp']
assert obj_report['materials'][0]['base_color_texture'] is None
receipt['equivalentGeometryAndImages']=True

# Remove only the known generated input files, then restore in another process.
assert inputs.resolve().parent==out.resolve()
for name in files:(inputs/name).unlink()
assert all(not (inputs/name).exists() for name in files)
report,_=run('restore-without-originals',obj_case/'scene.mscn','obj_unfreeze')
assert report==obj_report;receipt['originalFilesRemovedBeforeRestore']=True

negative=out/'negative-inputs';negative.mkdir()
for name,content,cause in [
    ('traversal',b'mtllib ../escape.mtl','phase=obj_path'),
    ('missing-mtl',b'mtllib missing.mtl','phase=resource'),
    ('bad-index',b'v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 99','corner index'),
    ('unsupported',b'call arbitrary.obj','unsupported capability')]:
    path=negative/(name+'.obj');path.write_bytes(content);run('error-'+name,path,'obj_import',2,cause)
bad=negative/'corrupt.mscn';damaged=bytearray((obj_case/'scene.mscn').read_bytes());damaged[44]^=1;bad.write_bytes(damaged);run('error-frozen-options',bad,'obj_unfreeze',2,'option digest mismatch')
check_source();receipt.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=True)
(out/'accepted.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,cases=len(receipt['cases']),sourceUnchanged=True,originalFilesRemovedBeforeRestore=True,equivalentGeometryAndImages=True)),flush=True)
