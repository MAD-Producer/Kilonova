"""One serial source-bound real-calibration and native GPU acceptance run."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,subprocess
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-relink-native-v2'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def now():return datetime.now(timezone.utc).isoformat()
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
sources={n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (WORK/n).is_file() and (n.startswith(('crates/','desktop/','tools/tracking/')) and n.endswith(('.rs','.wgsl','.toml','.py','.json')) or n in ('Cargo.toml','Cargo.lock','ATTRIBUTION.md'))}
report=dict(status='running',controllerPid=os.getpid(),startedUtc=now(),baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),source=sources,steps=[],scope='Actual desktop worker and native capture before/after tracked image relink, wrong source refusal, undo/redo/reopen. Default Info starts and Error file/stderr; no stdout logs. Offscreen capture, not retained interactive presenter or video replacement.')
def save():
 p=OUT/'pending.json';p.write_text(json.dumps(report,indent=2),encoding='utf-8');p.replace(OUT/'exit.json')
def identity():
 for n,h in sources.items():assert hashlib.sha256((WORK/n).read_bytes()).hexdigest()==h,n
env=os.environ.copy();env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',PYTHONUTF8='1',MOTION_LENS_ARTIFACTS=str(OUT/'images'))
env.pop('MOTION_LOG',None)
env['MOTION_TRACKING_RELINK_NATIVE_DIR']=str(OUT)
steps=[('desktop-relink',['cargo','test','-p','motion-desktop','--features','ffmpeg','--bin','motion-studio','--locked','--offline',
 'engine::tracking_relink_tests::tracked_image_relink_keeps_native_output_and_records_wrong_source','--','--exact','--test-threads=1','--nocapture'])]
save()
try:
 for name,args in steps:
  identity();row=dict(name=name,command=args,startedUtc=now());report['steps'].append(row);save()
  with (OUT/(name+'.stdout.log')).open('wb') as output,(OUT/(name+'.stderr.log')).open('wb') as stderr:
   p=subprocess.Popen(args,cwd=WORK,env=env,stdout=output,stderr=stderr);row['pid']=p.pid;save();row['exitCode']=p.wait()
  row['completedUtc']=now();save();assert row['exitCode']==0,row
 log=(OUT/'logs/motion-studio.log').read_text(encoding='utf-8')
 stderr=(OUT/'desktop-relink.stderr.log').read_text(encoding='utf-8',errors='replace')
 stdout=(OUT/'desktop-relink.stdout.log').read_text(encoding='utf-8',errors='replace')
 assert '1 passed; 0 failed' in stdout
 assert 'asset relink tracking start request=desktop-relink-wrong' in log
 for sink in [log,stderr]:
  assert 'asset relink tracking failed request=desktop-relink-wrong' in sink
  assert 'tracking source content differs' in sink
 assert 'asset relink tracking failed' not in stdout
 identity();report['status']='accepted_native_tracking_relink_increment_full_issue_pending'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=now();save()
