from pathlib import Path
import hashlib,json,re,subprocess,zipfile
from datetime import datetime,timezone
import numpy as np
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88';BASE=ROOT/'artifacts/pr-queue';DATA=WORK/'engineering/validation/data'
def read(folder):return json.loads((BASE/folder/'exit.json').read_text(encoding='utf-8'))
host=read('tracking88-relink-acceptance-v1');native=read('tracking88-relink-native-v3');ci=read('tracking88-ci-inventory-v1')
assert host['status']=='accepted_tracking_relink_increment_full_issue_pending'
assert native['status']=='accepted_native_tracking_relink_increment_full_issue_pending'
assert all(s['exitCode']==0 and s.get('completedUtc') for r in [host,native] for s in r['steps'])
assert ci['status']=='failed' and ci['failure']=="AssertionError('normal')"
assert ci['steps'][0]['exitCode']==0
for name,digest in host['source'].items():
 if name.startswith('crates/motion-host/'):
  assert hashlib.sha256((WORK/name).read_bytes()).hexdigest()==digest,name
for name,digest in native['source'].items():
 if name.startswith(('crates/','desktop/')) or name in ('Cargo.toml','Cargo.lock'):
  assert hashlib.sha256((WORK/name).read_bytes()).hexdigest()==digest,name
for name,digest in ci['source'].items():
 if name.startswith('tools/'):
  assert hashlib.sha256((WORK/name).read_bytes()).hexdigest()==digest,name
counts={}
for name in ['host-relink','host-tracking','host-media','host-registration']:
 text=(BASE/'tracking88-relink-acceptance-v1'/(name+'.log')).read_text(encoding='utf-8',errors='replace')
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
 assert rows,name
 counts[name]=[sum(int(row[i]) for row in rows) for i in range(3)]
assert counts=={'host-relink':[7,0,0],'host-tracking':[50,0,0],'host-media':[14,0,0],'host-registration':[8,0,0]},counts
names=set(subprocess.check_output(['git','diff','--name-only'],cwd=WORK,text=True).splitlines())
names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=WORK,text=True).splitlines())
names.update(['tools/tracking/calibrate_photographs.py','tools/validation_inventory.json','tools/test_ci_tracking_calibration.py'])
assert not any(n.startswith('desktop/app/src/panels/') for n in names)
members={}
for name in names:
 path=WORK/name
 if path.is_file() and path.suffix not in ['.zip','.pyc']:members['source/'+name]=path.read_bytes()
folders=['tracking88-relink-acceptance-v1','tracking88-relink-native-v2','tracking88-relink-native-v3','tracking88-ci-inventory-v1']
for folder in folders:
 for path in sorted((BASE/folder).rglob('*')):
  if path.is_file():members['evidence/'+folder+'/'+path.relative_to(BASE/folder).as_posix()]=path.read_bytes()
for name in ['tracking88-relink-baseline-v1.log','tracking88-relink-focused-v1.log','tracking88-pr580-python-regression-v1.log','tracking88-pr580-checks-job-7d2e0f33.log','tracking88-relink-style-v1.log','tracking88-relink-provenance-v1.log']:
 members['evidence/'+name]=(BASE/name).read_bytes()
controllers=['accept-tracking88-relink-v1.py','accept-tracking88-relink-native-v1.py','accept-tracking88-relink-native-v2.py','accept-tracking88-relink-native-v3.py','accept-tracking88-ci-inventory-v1.py','finalize-tracking88-relink-v1.py']
for name in controllers:members['controllers/'+name]=(ROOT/'.tools/issue-closure-review'/name).read_bytes()
frozen=json.loads((WORK/'crates/motion-model/tests/fixtures/tracking-photographs.json').read_text(encoding='utf-8'))
normal=json.loads((BASE/'tracking88-ci-inventory-v1/normal/calibration.json').read_text(encoding='utf-8'))
optimized=json.loads((BASE/'tracking88-ci-inventory-v1/optimized/calibration.json').read_text(encoding='utf-8'))
drift=dict(status='failed_exact_frozen_json_equality_not_repaired',normalEqualsOptimized=normal==optimized,
 maxKDifference=float(np.abs(np.array(normal['K'])-np.array(frozen['K'])).max()),
 maxDistortionDifference=float(np.abs(np.array(normal['distortion'])-np.array(frozen['distortion'])).max()),
 maxInversePixelDifference=max(float(np.abs(np.array(a['ideal'])-np.array(b['ideal'])).max()) for a,b in zip(normal['inverseOracle'],frozen['inverseOracle'])),
 poseResiduals=[dict(name=a['name'],frozenRms=a['heldOutRms'],normalRms=b['heldOutRms'],optimizedRms=c['heldOutRms'])for a,b,c in zip(frozen['views'],normal['views'],optimized['views'])])
archive=DATA/'tracking88-relink-v1.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,content in sorted(members.items()):z.writestr(name,content)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,content in members.items():assert z.read(name)==content,name
report=dict(status='accepted_tracked_image_relink_increment_full_issue_pending',createdUtc=datetime.now(timezone.utc).isoformat(),
 archive=dict(path=archive.name,bytes=archive.stat().st_size,members=len(members),sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),
 publicationAtArchive=dict(pr='https://github.com/MAD-Producer/Kilonova/pull/580',ciRepairCommit='93e09306',feature='awaiting commit and push'),
 counts=counts,desktopNative=[1,0,0],pythonCi=dict(testsRun=110,skipped=1,step=ci['steps'][0],wholeExperimentStatus=ci['status']),
 sourceBoundInputs=dict(hostPrefix='crates/motion-host/',nativePrefixes=['crates/','desktop/','Cargo.toml','Cargo.lock'],ciPrefix='tools/',verified=True),
 host=host,native=native,ciExperiment=ci,unresolvedExactCalibrationEquality=drift,panelsChanged=False,
 retainedFailures=['Pre-guard changed-image source was accepted; log retained, full original test source not captured',
 'External native controller v1 syntax error before any child or output directory',
 'Native-v2 compile failed on missing test json macro import; fixed in native-v3',
 'First Python suite interpreter lacked required PyYAML; rerun with CI-matching existing environment',
 'Extra normal/optimized calibration runs are not bit-exact frozen JSON repeats; assertion remains failed'],
 remaining=['Actual video relink and separate media replacement route','New plate/solve and lens asset replacement transaction',
 'Retained interactive GPU cache identity and out-of-band plate changes at reopen',
 '2D/planar tracker prototype','Full maintained desktop/workspace and exact-head cross-platform CI',
 'Bit-exact external calibration reproducibility','Earlier native/compiler faults and #82 strict performance/GPU coverage'])
(DATA/'tracking88-relink-closeout.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(ROOT/'.tools/issue-closure-review/tracking88-relink-current.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=report['status'],counts=counts,archive=report['archive']),indent=2))
