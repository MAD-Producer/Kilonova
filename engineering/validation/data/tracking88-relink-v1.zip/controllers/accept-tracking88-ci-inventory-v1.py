"""One serial source-bound real-calibration and native GPU acceptance run."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,subprocess
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-ci-inventory-v1'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def now():return datetime.now(timezone.utc).isoformat()
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
sources={n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (WORK/n).is_file() and (n.startswith(('crates/','desktop/','tools/')) and n.endswith(('.rs','.wgsl','.toml','.py','.json')) or n in ('Cargo.toml','Cargo.lock','ATTRIBUTION.md'))}
report=dict(status='running',controllerPid=os.getpid(),startedUtc=now(),baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),source=sources,steps=[],scope='Actual host image relink protocol with calibrated camera, wrong source, readiness recheck, cancellation, undo/reopen and warm CPU decode. Not GPU cache or video replacement qualification.')
def save():
 p=OUT/'pending.json';p.write_text(json.dumps(report,indent=2),encoding='utf-8');p.replace(OUT/'exit.json')
def identity():
 for n,h in sources.items():assert hashlib.sha256((WORK/n).read_bytes()).hexdigest()==h,n
env=os.environ.copy();env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',PYTHONUTF8='1',MOTION_LENS_ARTIFACTS=str(OUT/'images'))
cv=str(ROOT/'.tools/ai-depth74/venv/Scripts/python.exe')
ci=str(ROOT/'.tools/ui-pr-validation-env/Scripts/python.exe')
source=str(ROOT/'artifacts/pr-queue/tracking88-photographs-probe-v3')
steps=[('ci-python',[ci,'-m','unittest','discover','-s','tools','-p','test_ci_*.py']),
 ('calibration-normal',[cv,'tools/tracking/calibrate_photographs.py','--source',source,'--output',str(OUT/'normal')]),
 ('calibration-optimized',[cv,'-O','tools/tracking/calibrate_photographs.py','--source',source,'--output',str(OUT/'optimized')])]
save()
try:
 for name,args in steps:
  identity();row=dict(name=name,command=args,startedUtc=now());report['steps'].append(row);save()
  with (OUT/(name+'.log')).open('wb') as output:
   p=subprocess.Popen(args,cwd=WORK,env=env,stdout=output,stderr=subprocess.STDOUT);row['pid']=p.pid;save();row['exitCode']=p.wait()
  row['completedUtc']=now();save();assert row['exitCode']==0,row
 expected=json.loads((WORK/'crates/motion-model/tests/fixtures/tracking-photographs.json').read_text(encoding='utf-8'))
 for variant in ['normal','optimized']:
  actual=json.loads((OUT/variant/'calibration.json').read_text(encoding='utf-8'))
  assert actual==expected,variant
 identity();report['status']='accepted_calibration_ci_inventory_and_optimization_increment'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=now();save()
