from pathlib import Path
import json,hashlib,re,sys,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/curve-view-ranges';out=root/'.tools/curve-view-ranges';attempt=sys.argv[1]
stage=out/('app-stage-'+attempt);r=json.loads((stage/'receipt.json').read_text(encoding='utf8'))
assert r['build_exit_code']==0 and r['source_unchanged'] and len(r['runs'])==8 and all(run['exit_code']==0 for run in r['runs'])
assert all(hashlib.sha256((work/path).read_bytes()).hexdigest()==digest for path,digest in r['sources'].items())
names=[];counts={}
for run in r['runs']:
 text=(stage/(run['name']+'.log')).read_text(encoding='utf8')
 found=re.findall(r'^test ([a-zA-Z0-9_:]+) \.\.\. ',text,re.M)
 assert run['summary'][-1]==['ok',str(len(found)),'0','0'],(run['name'],run['summary'],found)
 counts[run['name']]=len(found);names.extend(found)
assert len(names)==len(set(names))
files=[out/'verify_app_stage.py',out/'record_comparison_stage.py']
for folder in sorted(out.glob('app-stage-*')):
 if 7<=int(folder.name.rsplit('-',1)[1])<=int(attempt):files.extend(path for path in folder.rglob('*') if path.is_file())
manifest={str(path.relative_to(out)).replace('\\','/'):hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
archive=work/('engineering/validation/data/curve-comparison-ranges-stage-'+attempt+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for path in files:z.write(path,str(path.relative_to(out)).replace('\\','/'))
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
record=dict(head=r['head'],binary_sha256=r['binary_sha256'],source_unchanged=True,stage=stage.name,counts=counts,unique_cases=len(names),cases=names,
 status='PROPERTY_EFFECT_COMPARISON_RANGE_STAGE_PASSED; ISSUE259_INCOMPLETE; no259 PR or closure',
 remaining=['Mini ranges and actual interval readouts','New default-level file/Error stderr/stdout site audit','Native EN/ZH main/float/DPI/visual/high-zoom and actual saved-file byte invariance','Full main integration and DESIGN12 acceptance before259 PR'],
 archive=dict(path='data/'+archive.name,bytes=archive.stat().st_size,entries=len(files)+1,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
(work/'engineering/validation/curve-comparison-ranges-progress-results.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
doc=f'''# 对比曲线分组范围与缓存阶段验证（#259，未完成）

本阶段接续[效果阶段](curve-effect-ranges-progress.md)，把范围控制、读数和误差驱动绘制接入对比图。Mini、默认新增故障站点信道、真实原生视觉/高倍率验收和实际保存文件字节验证尚未完成，不据本阶段关闭#259或提交完成PR。

源码提交 `{r['head']}`，二进制SHA-256 `{r['binary_sha256']}`，完整Rust/WGSL/Cargo/样式来源前后哈希一致。已接续主分支预设与共享深度、本人参考线分支。开始前核对其他PR，未重复其功能；本项无新增依赖、第三方资产或Adobe二进制参考。

## 实现与实际证据

同单位曲线共用Y范围，不同单位分别保存Y锁，X与时间轴共用合成时间。每组既有标题区显示单位并提供范围菜单；单组模式补同样的标题区，未缩小关键帧/手柄命中容差。适配选区只采用本单位组选中键的合成时间，不重复图层偏移；空/失效选区不退回旧键。菜单捕获有界的通道/可见性/单位上下文，其他组重绘不会关闭它，模式/集合/可见单位变化则取消。

范围与新读数使用既有Data实际模型采样，保留参数限幅、离散保持、偏移和物理单位。绘制采用同一有界细分器；离散边界包含左极限。原257点是自动范围与兼容基础，不是最终绘制分辨率。基准样本继续按原时间/模式缓存，最终折线另按时间、fps、模式、ppf、绘图区宽高、Y上下界和误差令牌缓存；仅改变ppf而end仍被末帧截住，也会更新最终折线。Y缩放不重建其他单位组的缓存。失败折线不返回部分成功，缓存不可用状态并显示日志提示；只有视图/来源改变才重新计算。

范围状态总量仍限128。缓存优先淘汰未锁且非当前菜单视图，保留已锁X/Y状态，避免浏览更多单位后回来失去锁轴。若所有槽均被锁定，旧范围保留，新视图菜单只读并显示需先解锁其他视图；解除一项锁后恢复新视图范围操作。这是明确的临时视图资源边界，不是工程或文件格式限制。

当前真实桌面程序 {len(names)} 个不同用例通过：细分{counts['adaptive']}、模型/物理速度{counts['sampling']}、既有时间轴{counts['timeline']}、手柄{counts['handles']}、范围菜单{counts['ranges']}、轴原语{counts['axes']}、效果{counts['effects']}、对比{counts['comparison']}。场景组合及重复独立原语不累加。新增验证包括：中英文主窗/浮窗chrome受控输入、分组适配与锁轴、模式/集合取消、旧纵向状态独立、ppf截断边界缓存、真实模型每段128密点的0.36逻辑像素界限、合法33000关键帧模型触发预算失败及视图缩放后恢复、容量边界保护锁轴和只读菜单。它们不是本项真实原生窗口或截图，也不将工程序列化内容不变冒称实际文件字节验收。

## 原始失败与修正

stage07编译成功、110通过/3失败，三个失败均为实际主窗/浮窗入口不能保留新范围菜单：旧时间轴背景右键又打开了图层菜单。为已取得输入的范围菜单补背景右键守卫，没有改点击方式或放宽断言。stage08原113项全部通过。随后源代码审查发现容量淘汰会移除已锁范围，改为保留锁项、容量满时只读，并补两项边界验证；此项来源为代码审查，不虚构早期失败运行。所有阶段原日志与源码冻结保留。

比较样本预算测试在编译前按模型MAX_FRAMES=36000调整为合法36000帧/33000键、InOut交替值；没有放宽模型上限或预算。新增拟合对不可用通道保留原始原因。原Data加载/采样与错误检查继续运行，既有断言保持。

## 观察与责任边界

新增curve.comparison.view_bounds/adaptive/readout/fit_all/fit_selection复用固定站点进程寿命Counter（首Warn、累计第60次Error、之后抑制，进程结束清零；不是连续次数或秒）。实际预算失败及负缓存功能已覆盖，但这些新增站点的默认文件/Error stderr/stdout审计仍待完成；原加载故障测试只证明原站点。缺失/不支持通道、取消、容量已满与正常缓存命中分别保留正常分支，不增加线程、重试或重启。没有FPS或内存降低声明；最多128条曲线、每条65536点，保留内存是显式有界的，仍需完整性能和原生验收。

## DESIGN §0.7逐项处置

| 基线 | 处置与原因 |
|---|---|
| Path六处纵向步进 | retained with reason：未修改Path行，本轮不重新验收该处。 |
| Path两列分割 | retained with reason：未改Path列宽。 |
| Path按钮高度 | retained with reason：未改Path按钮和原命中范围。 |
| Path自绘字段背景 | retained with reason：未改数值字段。 |
| Path布尔宽按钮 | retained with reason：未改Path布尔，新锁轴使用原生Checkbox。 |
| Effect Controls行高/步进 | retained with reason：未改效果属性行。 |
| Effect Controls fx布尔 | retained with reason：未改效果开关，不冒认主分支整改。 |
| Effect Controls枚举 | retained with reason：未改枚举语义或控件。 |
| Effect Controls手工hover | retained with reason：未改该处，没有新增颜色。 |
| Effect Controls层级 | retained with reason：未改属性树层级。 |
| Timeline标签栏列坐标 | retained with reason：未改标签栏坐标，继承主分支独立开关列。 |
| Timeline吸附线颜色 | retained with reason：未改吸附反馈或既有颜色。 |

保留处置不是缺陷已修复声明。标题/读数/菜单读取已有语义尺寸与颜色，完整§12验收仍待完成。[原始证据包]({record['archive']['path']})：{record['archive']['entries']}项/{record['archive']['bytes']}字节，SHA-256 `{record['archive']['sha256']}`；[结构化结果](curve-comparison-ranges-progress-results.json)。
'''
(work/'engineering/validation/curve-comparison-ranges-progress.md').write_text(doc,encoding='utf8')
prior=work/'engineering/validation/curve-effect-ranges-progress.md';text=prior.read_text(encoding='utf8')
marker='后续对比图分组范围、缓存和锁项容量边界见[对比阶段记录](curve-comparison-ranges-progress.md)，完整#259仍未完成。'
if marker not in text:prior.write_text(text.replace('\n\n','\n\n'+marker+'\n\n',1),encoding='utf8')
print(json.dumps({key:value for key,value in record.items() if key!='cases'},ensure_ascii=False))
