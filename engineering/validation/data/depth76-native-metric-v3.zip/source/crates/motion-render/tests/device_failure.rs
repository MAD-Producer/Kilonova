use motion_core::Project;
use motion_render::Scene;
use motion_render::Renderer;
#[test]
#[cfg_attr(not(feature = "gpu-tests"), ignore = "requires an actual GPU")]
fn an_actual_device_destruction_is_reported_and_a_new_device_can_render() {
    let mut renderer = pollster::block_on(Renderer::headless()).unwrap();
    let p = Project::demo().unwrap();
    let mut scene = Scene::new(&p).unwrap();
    scene.sample(&p, 72.0, None, &motion_core::ExpressionEvaluator).unwrap();
    let target = renderer.capture_target(64, 64).unwrap();
    renderer.draw(&scene, &target.view, 64, 64).unwrap();
    renderer.device.destroy();
    renderer.device.poll(wgpu::PollType::wait_indefinitely()).expect("GPU poll failed");
    assert!(renderer.gpu_error().is_some());
    assert!(renderer.draw(&scene, &target.view, 64, 64).is_err());
    drop(target);
    drop(renderer);
    let mut recreated = pollster::block_on(Renderer::headless()).unwrap();
    let target = recreated.capture_target(64, 64).unwrap();
    assert!(recreated
        .capture(&scene, &target)
        .unwrap()
        .0
        .iter()
        .any(|v| *v != 0));
    assert!(recreated.gpu_error().is_none());
}
