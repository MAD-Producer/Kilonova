use crate::{ensure, Result};
use serde::{Deserialize, Serialize};

pub const MAX_VIDEO_DIMENSION: u32 = 4096;
pub const MAX_VIDEO_PIXELS: u64 = 4096 * 2160;
pub const MAX_VIDEO_FPS: f64 = 240.0;
pub const MAX_VIDEO_FRAMES: u32 = 1_000_000;

/// All timestamps are on the source presentation timeline, including leading edits.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct VideoAsset {
    pub id: u64,
    pub path: String,
    pub bytes: u64,
    pub mime: String,
    pub track: u32,
    pub width: u32,
    pub height: u32,
    pub rotation: u32,
    pub display_width: u32,
    pub display_height: u32,
    pub video_start_us: u64,
    pub video_end_us: u64,
    pub duration_us: u64,
    pub frame_count: u32,
    pub variable_frame_rate: bool,
    pub nominal_frame_rate: f64,
    pub color_standard: u32,
    pub color_range: u32,
    /// A separate asset ID referencing the same owned source; never a second copy.
    pub audio_asset: Option<u64>,
}
impl VideoAsset {
    pub fn validate(&self) -> Result<()> {
        crate::storage::validate_relative_path(&self.path)?;
        ensure(
            self.bytes > 0 && self.bytes <= crate::storage::MAX_MEDIA_ASSET,
            "invalid video source size",
        )?;
        ensure(
            matches!(
                self.mime.as_str(),
                "video/avc" | "video/hevc" | "video/x-vnd.on2.vp8" | "video/x-vnd.on2.vp9"
            ),
            "unsupported video codec",
        )?;
        ensure(
            self.width > 0
                && self.height > 0
                && self.width <= MAX_VIDEO_DIMENSION
                && self.height <= MAX_VIDEO_DIMENSION
                && u64::from(self.width) * u64::from(self.height) <= MAX_VIDEO_PIXELS,
            "video exceeds 4K source pixel budget",
        )?;
        ensure(
            matches!(self.rotation, 0 | 90 | 180 | 270),
            "unsupported video rotation",
        )?;
        let expected = if self.rotation % 180 == 0 {
            (self.width, self.height)
        } else {
            (self.height, self.width)
        };
        ensure(
            (self.display_width, self.display_height) == expected,
            "video display size mismatch",
        )?;
        ensure(
            self.video_start_us < self.video_end_us
                && self.video_end_us <= self.duration_us
                && self.duration_us <= 3_600_000_000
                && self.frame_count > 0
                && self.frame_count <= MAX_VIDEO_FRAMES,
            "invalid video presentation interval",
        )?;
        ensure(
            self.nominal_frame_rate.is_finite()
                && self.nominal_frame_rate > 0.0
                && self.nominal_frame_rate <= MAX_VIDEO_FPS,
            "video exceeds 240 fps source limit",
        )?;
        ensure(
            matches!(self.color_standard, 1 | 2 | 4) && matches!(self.color_range, 1 | 2),
            "unsupported SDR color space",
        )
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct VideoClip {
    pub asset: u64,
    pub source_offset_us: u64,
    /// Show the first picture before its presentation time while retaining the
    /// original audio clock. Older clips default to their existing blank head.
    #[serde(default, skip_serializing_if = "is_false")]
    pub hold_first_frame: bool,
    pub volume: f32,
    pub muted: bool,
}
impl VideoClip {
    pub fn new(asset: u64) -> Self {
        Self {
            asset,
            source_offset_us: 0,
            hold_first_frame: false,
            volume: 1.0,
            muted: false,
        }
    }
    /// Initialize a newly placed source without changing legacy clips.
    pub fn for_source(asset: &VideoAsset, has_audio: bool) -> Self {
        let mut clip = Self::new(asset.id);
        if has_audio && asset.video_start_us > 0 {
            clip.hold_first_frame = true;
        } else {
            clip.source_offset_us = asset.video_start_us;
        }
        clip
    }
    pub fn source_time_us(&self, local_frame: f64, fps: crate::FrameRate) -> Result<i64> {
        let offset = i64::try_from(self.source_offset_us).map_err(|_| crate::RateError::NumericRange)?;
        let relative = fps.ticks_at_fractional_frame(local_frame, 1_000_000,
            crate::ClockRounding::NearestTiesAwayFromZero)?;
        Ok(offset.checked_add(relative).ok_or(crate::RateError::NumericRange)?)
    }
    /// Decoder time for the picture; audio continues to use source_time_us.
    pub fn picture_time_us(&self, local_frame: f64, fps: crate::FrameRate, asset: &VideoAsset) -> Result<i64> {
        let time = self.source_time_us(local_frame, fps)?;
        Ok(if self.hold_first_frame && time >= 0 && time < asset.video_start_us as i64 {
            asset.video_start_us as i64
        } else {
            time
        })
    }
    pub fn validate(&self) -> Result<()> {
        ensure(
            self.source_offset_us <= 3_600_000_000
                && self.volume.is_finite()
                && (0.0..=2.0).contains(&self.volume),
            "invalid video source offset or volume",
        )
    }
}

fn is_false(value: &bool) -> bool { !*value }

#[derive(Clone, Debug)]
pub struct VideoSample {
    pub asset: u64,
    pub source_time_us: u64,
}
