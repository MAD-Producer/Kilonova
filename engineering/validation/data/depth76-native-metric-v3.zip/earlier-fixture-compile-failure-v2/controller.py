"""Validate the shared scalar kernel, registered depth core and real GPU preset."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/reference-depth76'
OUT = ROOT / 'artifacts/pr-queue/depth76-native-metric-v2'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
paths = ['Cargo.toml', 'Cargo.lock']
for crate in ['motion-effects', 'motion-graph', 'motion-model', 'motion-render']:
    paths.append(f'crates/{crate}/Cargo.toml')
    paths.extend(str(p.relative_to(WORK)).replace('\\', '/')
                 for base in ['src', 'tests']
                 for p in (WORK / 'crates' / crate / base).rglob('*.rs'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = lambda: {p: sha(WORK / p) for p in sorted(paths)}
commands = [
    ['cargo', 'test', '-p', 'motion-model', '--test', 'depth', '--test', 'depth_prepared',
     '--test', 'depth_blend_coordinates', '--test', 'depth_blend', '--test', 'depth_calibration',
     '--test', 'depth_surface', '--test', 'depth_metric_geometry',
     '--locked', '--offline', '--', '--test-threads=1'],
    ['cargo', 'test', '-p', 'motion-render', '--test', 'scene_gpu',
     '--locked', '--offline', '--', '--test-threads=1'],
]
environment = os.environ.copy()
environment.update(CARGO_TARGET_DIR=str(ROOT / 'target/reference-depth76-contract'),
                   CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_BUILD_JOBS='1',
                   CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0',
                   TEMP=str(ROOT / 'target/ci-policy-validation-tmp'), TMP=str(ROOT / 'target/ci-policy-validation-tmp'),
                   MOTION_DEPTH_BLEND_ARTIFACTS=str(OUT / 'native'))
report = dict(status='running', commands=commands, source=sources(), phases=[],
              baseCommit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip(),
              startedUtc=datetime.now(timezone.utc).isoformat(),
              scope='Complete selected model targets and complete native scene_gpu target; authored movement, not real footage or Session persistence')
receipt = OUT / 'exit.json'
save = lambda: receipt.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
save()
began = time.monotonic()
try:
    for index, command in enumerate(commands):
        phase = dict(command=command, startedUtc=datetime.now(timezone.utc).isoformat())
        report['phases'].append(phase)
        with (OUT / f'{index}-stdout.log').open('wb') as stdout, (OUT / f'{index}-stderr.log').open('wb') as stderr:
            process = subprocess.Popen(command, cwd=WORK, env=environment, stdout=stdout, stderr=stderr)
            phase['pid'] = process.pid
            save()
            phase['exitCode'] = process.wait()
        phase['completedUtc'] = datetime.now(timezone.utc).isoformat()
        save()
        if phase['exitCode']:
            break
    report['sourceUnchanged'] = sources() == report['source']
    report['status'] = ('passed_selected_complete_targets'
                        if len(report['phases']) == len(commands)
                        and all(p['exitCode'] == 0 for p in report['phases'])
                        and report['sourceUnchanged'] else 'failed_original_outputs_retained')
except BaseException as error:
    report.update(status='failed_original_outputs_retained', error=repr(error))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=time.monotonic() - began)
    save()
print(json.dumps({k: v for k, v in report.items() if k != 'source'}))
raise SystemExit(0 if report['status'] == 'passed_selected_complete_targets' else 1)
