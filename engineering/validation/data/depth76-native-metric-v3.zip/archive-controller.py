"""Retain the complete native scene target and earlier fixture compile failures."""
from pathlib import Path
import hashlib, json, re, zipfile
ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/reference-depth76'
OUT = ROOT / 'artifacts/pr-queue/depth76-native-metric-v3'
DATA = WORK / 'engineering/validation/data'
report = json.loads((OUT / 'exit.json').read_text())
assert report['status'] == 'passed_selected_complete_targets' and report['sourceUnchanged']
assert len(report['phases']) == 2 and all(p['exitCode'] == 0 for p in report['phases'])
sha = lambda data: hashlib.sha256(data).hexdigest()
summaries = []
for path in sorted(OUT.glob('*-stdout.log')):
    summaries.extend(re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', path.read_text()))
assert len(summaries) == 8 and sum(int(s[0]) for s in summaries) == 89, summaries
assert all(s[1:] == ('0', '0', '0', '0') for s in summaries)
entries = {str(p.relative_to(OUT)).replace('\\', '/'): p.read_bytes() for p in OUT.rglob('*') if p.is_file()}
entries['archive-controller.py'] = Path(__file__).read_bytes()
for path, expected in report['source'].items():
    data = (WORK / path).read_bytes()
    assert sha(data) == expected, path
    entries['source/' + path] = data
for version in [1, 2]:
    failed = ROOT / f'artifacts/pr-queue/depth76-native-metric-v{version}'
    receipt = json.loads((failed / 'exit.json').read_text())
    assert receipt['status'] == 'failed_original_outputs_retained'
    for path in failed.glob('*'):
        if path.is_file(): entries[f'earlier-fixture-compile-failure-v{version}/' + path.name] = path.read_bytes()
archive = DATA / 'depth76-native-metric-v3.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for name, content in sorted(entries.items()): output.writestr(name, content)
with zipfile.ZipFile(archive) as output:
    assert set(output.namelist()) == set(entries)
    for name, content in entries.items(): assert output.read(name) == content
costs = json.loads((OUT / 'native/native-depth-costs.json').read_text())
assert len(costs) == 12 and {v['precision'] for v in costs} == {'Unorm8','Unorm16','Float16','Float32'}
manifest = dict(status='verified_registered_native_depth_and_model_not_full_workspace',
    baseCommit=report['baseCommit'], sourceUnchanged=True, commands=report['commands'],
    tests=dict(passed=89, failed=0, ignored=0, filtered=0, targets=8),
    elapsedSeconds=report['elapsedSeconds'], archive=archive.name,
    bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
    members=[dict(path=n, bytes=len(d), sha256=sha(d)) for n,d in sorted(entries.items())],
    nativeCases=12,
    timings_us={key:dict(min=min(c[key] for c in costs), max=max(c[key] for c in costs))
                for key in ['blend_us','projection_us','submission_cpu_us']},
    limits=['Moving depth is a controlled authored sequence, not real footage or automatic registration',
            'CPU submission timings are not GPU durations or a representative performance baseline',
            'No UI, host persistence or full-workspace acceptance is claimed',
            'Earlier compile failures were new fixture field names and byte-index types; assertions unchanged'])
(DATA / 'depth76-native-metric-v3.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({k:v for k,v in manifest.items() if k != 'members'}))
