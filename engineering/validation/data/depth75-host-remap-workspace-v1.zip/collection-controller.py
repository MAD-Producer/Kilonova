"""Archive the consumed, source-bound full run without launching native work."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess
import zipfile

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
SOURCE = ART / 'depth75-host-remap-workspace-v1'
OUT = ART / 'depth75-host-remap-workspace-public-v1'
WORK = ROOT / '.worktrees/depth-retained-context75'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    report = read(SOURCE / 'receipt.json')
    consumed = read(SOURCE / 'session-consumed.json')
    assert consumed['original_tool_result_consumed'] and consumed['session'] == 82855
    assert consumed['source_unchanged'] and report['source_unchanged']
    assert consumed['source_head'] == report['head']
    assert consumed['status'] == report['status']
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == report['head']
    OUT.mkdir(exist_ok=False)
    shutil.copyfile(__file__, OUT / 'collection-controller.py')
    for name in ('controller.py', 'receipt.json', 'session-consumed.json',
                 'cargo-metadata.json', 'workspace.stdout.log', 'workspace.stderr.log'):
        origin = SOURCE / name
        if name in report['logs']:
            expected = report['logs'][name]
            assert digest(origin) == expected['sha256'] and origin.stat().st_size == expected['bytes']
        shutil.copyfile(origin, OUT / name)
    interim = SOURCE / 'desktop-failure-interim.json'
    if interim.is_file():
        shutil.copyfile(interim, OUT / interim.name)
    shutil.copyfile(ART / 'depth75-host-remap-workspace-v1-consume.py', OUT / 'consume-controller.py')
    selected = (
        'desktop/app/src/engine/sampling_playback_tests.rs',
        'crates/motion-graph/tests/editable_data.rs',
        'crates/motion-render/tests/layer_rasters.rs',
        'crates/motion-render/tests/magnified_effect_density.rs',
        'crates/motion-host/src/depth/wgsl/rust_remap.rs',
        'crates/motion-host/tests/depth_wgsl_retained.rs',
        'crates/motion-host/tests/depth_wgsl_retained/session.rs',
    )
    bindings = {}
    for name in selected:
        origin = WORK / name
        assert digest(origin) == report['source_sha256'][name]
        destination = OUT / 'source' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(origin, destination)
        bindings[name] = digest(destination)
    collection = dict(
        status=report['status'], source_head=report['head'], baseline_main=report['main'],
        original_session=82855, original_controller_exit=consumed['exit_code'],
        original_cargo_exit=consumed['cargo_exit_code'], totals=report.get('totals'),
        full_target_coverage=report.get('full_target_coverage'),
        missing_targets=report.get('missing_targets'), unexpected_targets=report.get('unexpected_targets'),
        failed_tests=report.get('failed_test_names'), abnormal_targets=report.get('abnormal_target_exits'),
        source_unchanged=True, selected_source_sha256=bindings,
        observed_utc=datetime.now(timezone.utc).isoformat(), qualified=False,
        limits=[
            'Completed target summaries and abnormal exits retain distinct accounting',
            'The raw legacy total key original_ignored counts all ignored tests, including new opt-in host-remap tests',
            'No narrower success or remote CI substitutes for this exact full command',
            'Original assertions, waits, backends, feature selection and no-fail-fast retained',
            'No additional native work, retries, downloads, foreign process changes or Android tests',
            'Optional sampling child artifacts were not requested by the original command',
            'Selected source snapshots and all tracked hashes are not a complete repository archive',
            'No learned arrays, private RGB, models, weights, runtime or executable redistribution',
        ],
    )
    (OUT / 'collection.json').write_text(json.dumps(collection, indent=2) + '\n', encoding='utf-8')
    members = {p.relative_to(OUT).as_posix(): dict(bytes=p.stat().st_size, sha256=digest(p))
               for p in sorted(OUT.rglob('*')) if p.is_file()}
    archive = OUT / 'depth75-host-remap-workspace-v1.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
        for name in members:
            target.write(OUT / name, name)
    with zipfile.ZipFile(archive) as target:
        assert target.testzip() is None and set(target.namelist()) == set(members)
        for name, expected in members.items():
            raw = target.read(name)
            assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256']
    manifest = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=digest(archive),
                    members=members, source_head=report['head'], original_status=report['status'],
                    readback='Every member CRC, byte length and SHA-256 verified', qualified=False)
    (OUT / 'depth75-host-remap-workspace-v1.json').write_text(
        json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: manifest[k] for k in ('archive', 'bytes', 'sha256', 'original_status')}))


if __name__ == '__main__':
    main()
