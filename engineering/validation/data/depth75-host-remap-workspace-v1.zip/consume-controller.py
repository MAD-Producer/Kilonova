"""Record the original terminal tool result; never rerun the acceptance command."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import subprocess

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-retained-context75'
OUT = ART / 'depth75-host-remap-workspace-v1'
CP = ART / 'depth75-resume-current.json'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write_new(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--original-exit-code', type=int, required=True)
    parser.add_argument('--original-chunk-id', required=True)
    args = parser.parse_args()
    assert args.original_chunk_id and len(args.original_chunk_id) <= 64
    report = read(OUT / 'receipt.json')
    assert report['status'] in (
        'failed_original_outputs_retained',
        'complete_maintained_workspace_desktop_gpu_ffmpeg_passed',
    )
    assert report['completed_utc'] and report['source_unchanged']
    expected_exit = int(report['status'] != 'complete_maintained_workspace_desktop_gpu_ffmpeg_passed')
    assert args.original_exit_code == expected_exit
    assert len(report['stages']) == 1
    assert isinstance(report['stages'][0]['exit_code'], int)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
    assert head == report['head']
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
    for relative, expected in report['source_sha256'].items():
        assert hashlib.sha256((WORK / relative).read_bytes()).hexdigest() == expected, relative
    for relative, expected in report['logs'].items():
        raw = (OUT / relative).read_bytes()
        assert len(raw) == expected['bytes']
        assert hashlib.sha256(raw).hexdigest() == expected['sha256']
    state = read(CP)
    current = state['versionedCache75']
    assert Path(current['activeController']) == ART / 'depth75-host-remap-workspace-v1-controller.py'
    assert len(current['ownHeavyWorkloads']) == 1
    receipt = dict(
        session=82855,
        original_tool_result_consumed=True,
        original_chunk_id=args.original_chunk_id,
        exit_code=args.original_exit_code,
        cargo_exit_code=report['stages'][0]['exit_code'],
        status=report['status'],
        source_head=head,
        source_unchanged=True,
        source_freeze_released=True,
        observed_utc=datetime.now(timezone.utc).isoformat(),
        totals=report.get('totals'),
        failed_test_names=report.get('failed_test_names'),
        abnormal_target_exits=report.get('abnormal_target_exits'),
        prior_failures_retained=True,
        qualified=False,
    )
    write_new(OUT / 'session-consumed.json', receipt)
    current.update(activeController=None, ownHeavyWorkloads=[], currentFullWorkspace={
        **receipt, 'path': str(OUT), 'consumed': True,
    })
    pending = CP.with_suffix('.pending.json')
    pending.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
    pending.replace(CP)
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
