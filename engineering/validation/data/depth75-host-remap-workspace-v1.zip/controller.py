"""One full maintained-workspace run of the changed explicit host-remap source.
Previous native/broad failures remain failed; this is not an assertion or retry repair.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib,json,os,re,shutil,subprocess,time,traceback
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/depth-retained-context75';BASE=ROOT/'artifacts/pr-queue'
OUT=BASE/'depth75-host-remap-workspace-v1';TARGET=ROOT/'target/depth-wgsl-cache75-contract'
CP=BASE/'depth75-resume-current.json'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
state=read(CP);v=state['versionedCache75'];assert v['activeController'] is None and not v['ownHeavyWorkloads']
assert read(BASE/'depth75-host-remap-integration-v1/session-consumed.json')['original_tool_result_consumed']
assert read(BASE/'depth75-rust-remap-v1/session-consumed.json')['original_tool_result_consumed']
assert shutil.disk_usage(ROOT).free>=10<<30
assert not {'RUST_MIN_STACK','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'} & os.environ.keys()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert head.startswith('dc17b007')
main=subprocess.check_output(['git','rev-parse','origin/main'],cwd=WORK,text=True).strip()
assert main=='ac65d279c57626d7aa7e28061a1a7fdf7889c68a'
subprocess.run(['git','merge-base','--is-ancestor',main,head],cwd=WORK,check=True)
paths=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def hashes():return {p:sha(WORK/p) for p in paths}
OUT.mkdir(exist_ok=False);shutil.copyfile(__file__,OUT/'controller.py')
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
ff=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),LOCALAPPDATA=str(OUT/'appdata'),RUST_BACKTRACE='full',PYTHONDONTWRITEBYTECODE='1',LIBCLANG_PATH=str(ROOT/'.tools/python-libclang/clang/native'),FFMPEG_DIR=str(ff),FFMPEG_INCLUDE_DIR=str(ff/'include'),FFMPEG_LIB_DIR=str(ff/'lib'))
runtime=ff/'bin';env['PATH']=str(runtime)+';'+env['PATH']
env['MOTION_FROZEN_DEPTH_ARTIFACTS']=str(OUT/'outputs')
report=dict(status='running',head=head,main=main,source_sha256=hashes(),stages=[],started_utc=datetime.now(timezone.utc).isoformat(),
 limits=['Complete maintained workspace, original GPU/FFmpeg/AI-depth feature selection and no-fail-fast command; Android retired',
 'New explicit host-remap implementation and real controls are included; old Python/native and workspace failures remain unresolved',
 'No modified assertions, filters, ignores, stack, backend or deadlines; no retry-to-green',
 'One owned heavy controller, source/HEAD frozen until original terminal tool result consumed; no foreign processes changed'])
v.update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(kind='full maintained workspace after explicit Rust-remap integration',sourceFrozen=True,head=head,output=str(OUT))],currentLocalSourceHead=head,localUnpublishedHead=head)
write(CP,state)
def save():
    temporary=OUT/'receipt.pending.json';temporary.write_text(json.dumps(report,indent=2),encoding='utf-8');os.replace(temporary,OUT/'receipt.json')
def run(name,args):
    assert shutil.disk_usage(ROOT).free>=10<<30
    row=dict(name=name,command=args);report['stages'].append(row);save()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();row['exit_code']=child.wait()
    save();return row
save()
try:
    report['validation_runtime']=[]
    previous=json.loads((BASE/'depth75-cache-regression-v3/receipt.json').read_text())
    expected={Path(p['source']).name:p['sha256'] for p in previous['validationRuntime']}
    for name in ('avutil-60.dll','swresample-6.dll','avcodec-62.dll','avformat-62.dll','swscale-9.dll','avfilter-11.dll','avdevice-62.dll'):
        origin=runtime/name;digest=sha(origin);assert digest==expected[name]
        for folder in ('debug','debug/deps'):
            destination=TARGET/folder/name;destination.parent.mkdir(parents=True,exist_ok=True)
            if destination.exists():assert sha(destination)==digest,'Refusing to overwrite different local runtime'
            else:shutil.copy2(origin,destination)
            assert sha(destination)==digest
            report['validation_runtime'].append(dict(source=str(origin),destination=str(destination),sha256=digest,bytes=origin.stat().st_size))
    save()
    metadata=subprocess.check_output(['cargo','metadata','--locked','--offline','--no-deps','--format-version','1'],cwd=WORK,env=env)
    (OUT/'cargo-metadata.json').write_bytes(metadata);metadata=json.loads(metadata)
    row=run('workspace',['cargo','test','--workspace','--exclude','motion-android','--locked','--offline','--features','motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth,motion-host/gpu-tests,motion-render/gpu-tests,motion-ui/gpu-tests,motion-desktop/gpu-tests,motion-desktop-media/gpu-tests,motion-graph/gpu-tests','--no-fail-fast','--','--test-threads=1'])
    stdout=(OUT/'workspace.stdout.log').read_text(encoding='utf-8',errors='replace');stderr=(OUT/'workspace.stderr.log').read_text(encoding='utf-8',errors='replace')
    summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
    expected_targets=[];by_name={};doc_owners={}
    for package in metadata['packages']:
        if package['id'] not in metadata['workspace_members'] or package['name']=='motion-android':continue
        for target in package['targets']:
            if not target['test']:continue
            relative=Path(target['src_path']).relative_to(WORK).as_posix();key=package['name']+'::'+target['kind'][0]+'::'+relative
            expected_targets.append(key);by_name.setdefault(target['name'].replace('-','_'),[]).append((relative,key))
        if any(t['doctest'] for t in package['targets']):
            key='doc::'+package['name'];expected_targets.append(key);doc_owners[package['name'].replace('-','_')]=key
    observed=[];bound=[]
    for executable in re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)',stderr,re.M):
        path=Path(executable);raw=path.with_suffix('.d').read_bytes()
        line=raw.decode('utf-8').splitlines()[0].split(': ',1)[1].replace('\\','/')
        name=re.sub(r'-[a-f0-9]+$','',path.stem)
        owners=[key for relative,key in by_name[name] if re.search(r'(?<!\S)'+re.escape(relative)+r'(?!\S)',line)]
        assert len(owners)==1,(executable,owners)
        observed.extend(owners);bound.append(dict(executable=executable,target=owners[0],dep_info_sha256=hashlib.sha256(raw).hexdigest()))
    observed.extend(doc_owners[n] for n in re.findall(r'^\s*Doc-tests (\S+)\s*$',stderr,re.M))
    prior_regression=json.loads((BASE/'depth75-cache-regression-v3/receipt.json').read_text())
    names=prior_regression['expectedNamedControls']
    identities=['combined_identity_tracks_native_transform_and_actual_worker_independently','combined_identity_refuses_wrong_backend_precision_and_embedded_procedure','input_free_native_resolution_refuses_partial_work_other_hardware_and_stale_requests','transform_resolution_is_source_bound_and_contains_no_learned_operations','actual_transform_receipt_requires_the_identity_when_attestation_was_requested','actual_native_receipt_requires_verified_weights_and_the_same_execution','canceled_resolution_forgets_an_old_attestation_before_creating_scratch','actual_worker_file_change_is_refused_and_cancellation_precedes_file_io']
    names+=['depth::wgsl::identity::tests::'+name for name in identities]
    report.update(totals=dict(passed=sum(int(s[1]) for s in summaries),failed=sum(int(s[2]) for s in summaries),original_ignored=sum(int(s[3]) for s in summaries),filtered=sum(int(s[5]) for s in summaries),summary_count=len(summaries),observed_invocations=len(observed),expected_invocations=len(expected_targets)),source_bound_invocations=bound,missing_targets=dict(Counter(expected_targets)-Counter(observed)),unexpected_targets=dict(Counter(observed)-Counter(expected_targets)),full_target_coverage=Counter(expected_targets)==Counter(observed) and len(summaries)==len(observed),abnormal_target_exits=[s for s in stderr.splitlines() if "process didn't exit successfully:" in s],failed_test_names=re.findall(r'^test ([^\r\n]+?) \.\.\. FAILED\s*$',stdout,re.M),expected_named_controls=names)
    report['named_passes']=[name for name in names if len(re.findall(r'(?m)^test '+re.escape(name)+r' \.\.\. ok$',stdout))==1]
    assert row['exit_code']==0 and report['full_target_coverage'] and not report['totals']['failed'] and not report['totals']['filtered'] and not report['abnormal_target_exits'] and len(report['named_passes'])==len(names),'Full original maintained-workspace qualification failed'
    report['status']='complete_maintained_workspace_desktop_gpu_ffmpeg_passed'
except BaseException as cause:
    report.update(status='failed_original_outputs_retained',cause=repr(cause),traceback=traceback.format_exc())
finally:
    report.update(source_unchanged=hashes()==report['source_sha256'],completed_utc=datetime.now(timezone.utc).isoformat())
    report['logs']={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in OUT.glob('*.log')};save()
print(json.dumps({k:report.get(k) for k in ('status','head','totals','failed_test_names','abnormal_target_exits','source_unchanged')}))
raise SystemExit(0 if report['status']=='complete_maintained_workspace_desktop_gpu_ffmpeg_passed' and report['source_unchanged'] else 1)
