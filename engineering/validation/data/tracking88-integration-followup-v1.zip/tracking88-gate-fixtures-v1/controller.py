"""Verify the two unchanged test contracts after exposing causes and fixing types."""
from pathlib import Path
from datetime import datetime, timezone
import subprocess, json, hashlib, os, time, re, traceback
root=Path('E:/Dev/aem'); work=root/'.worktrees/tracking-colmap88'
out=root/'artifacts/pr-queue/tracking88-gate-fixtures-v1'; out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
def source():
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=work,text=True).splitlines()
    return {n:hashlib.sha256((work/n).read_bytes()).hexdigest() for n in paths if (work/n).is_file() and (n.startswith(('crates/','desktop/','tools/')) or n in ('Cargo.toml','Cargo.lock'))}
before=source()
env=os.environ.copy()
for key in list(env):
    if key.startswith('MOTION_'):env.pop(key,None)
env.update(CARGO_HOME=str(root/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(root/'target/rational-rate85-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',LOCALAPPDATA=str(out/'appdata'),TEMP=str(root/'target/ci-policy-validation-tmp'),TMP=str(root/'target/ci-policy-validation-tmp'))
tail=['--no-fail-fast','--locked','--offline','--','--test-threads=1']
steps=[('video-transactions',['cargo','test','-p','motion-media','--test','video_transactions']+tail),('host-media',['cargo','test','-p','motion-host','-p','motion-desktop-media','--features','motion-desktop-media/ffmpeg']+tail)]
report=dict(status='running',controllerPid=os.getpid(),baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),source=before,steps=[],startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Original assert predicates/state/history retained; FrameRate remains exactly30/1','Complete host/media plus video transaction integration target; not complete desktop/UI or workspace','Prior failed099 regression retained separately; no cause inferred for linker or hidden CI error'])
def save():(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
try:
    for label,cmd in steps:
        assert source()==before
        row=dict(label=label,command=cmd,status='running'); report['steps'].append(row);save();start=time.monotonic()
        with (out/(label+'.stdout.log')).open('wb') as stdout,(out/(label+'.stderr.log')).open('wb') as stderr:
            p=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();code=p.wait()
        assert source()==before
        summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',(out/(label+'.stdout.log')).read_text(encoding='utf-8',errors='replace'),re.M)
        row.update(status='passed' if code==0 else 'failed',exitCode=code,elapsedSeconds=round(time.monotonic()-start,3),summaries=summaries)
        if code==0:
            assert summaries and all(s[0]=='ok' and s[2]==s[5]=='0' for s in summaries)
            row['totals']=dict(passed=sum(int(s[1]) for s in summaries),originalIgnored=sum(int(s[3]) for s in summaries),targets=len(summaries))
        save()
    report.update(status='gate_fixtures_and_complete_host_media_passed' if all(s['exitCode']==0 for s in report['steps']) else 'failed_original_outputs_retained',sourceUnchanged=True)
except BaseException:
    report.update(status='observer_failed',traceback=traceback.format_exc());raise
finally:
    report.update(elapsedSeconds=round(time.monotonic()-began,3),completedUtc=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({k:v for k,v in report.items() if k!='source'}))
raise SystemExit(0 if report['status']=='gate_fixtures_and_complete_host_media_passed' else 1)
