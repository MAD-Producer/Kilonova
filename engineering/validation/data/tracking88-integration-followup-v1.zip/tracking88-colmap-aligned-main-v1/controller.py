"""Serial affected-package regression after the actual main merge; no borrowed passes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, time, traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-colmap88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-colmap-aligned-main-v1'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert head == '09915c81d46d6ddf9b7791eafb7ae7e55da8cf6a'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK).strip()
paths = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()
source = {n: sha(WORK / n) for n in paths if (WORK / n).is_file() and (
    n in ('Cargo.toml', 'Cargo.lock', 'ATTRIBUTION.md', 'PROVENANCE.md', 'NOTICE') or
    n.startswith(('crates/', 'desktop/', 'tools/')) and Path(n).suffix in ('.rs', '.wgsl', '.toml', '.json', '.py'))}

def identity():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == head
    for n, digest in source.items():
        assert sha(WORK / n) == digest, n

env = os.environ.copy()
for key in list(env):
    if key.startswith('MOTION_'):
        env.pop(key, None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
    CARGO_TARGET_DIR=str(ROOT / 'target/rational-rate85-contract'), CARGO_INCREMENTAL='0',
    CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
    RUST_BACKTRACE='full', PYTHONUTF8='1', LOCALAPPDATA=str(OUT / 'appdata'),
    TEMP=str(ROOT / 'target/ci-policy-validation-tmp'), TMP=str(ROOT / 'target/ci-policy-validation-tmp'),
    MOTION_LENS_ARTIFACTS=str(OUT / 'lens-artifacts'))
metadata = json.loads(subprocess.check_output(['cargo', 'metadata', '--no-deps', '--format-version', '1', '--locked', '--offline'], cwd=WORK, env=env))
(OUT / 'cargo-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
tail = ['--no-fail-fast', '--locked', '--offline', '--', '--test-threads=1']
render_targets = ['tracking_lens', 'working_precision', 'viewer_views', 'viewer_frame_views',
    'multiple_camera_compositions', 'scene_gpu', 'model_layers', 'image_capture',
    'exposure_scenes', 'nested_exposure', 'color_output']
render = ['cargo', 'test', '-p', 'motion-render', '--lib']
for name in render_targets:
    render += ['--test', name]
steps = [
    ('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg', '--locked', '--offline'], None),
    ('model-core', ['cargo', 'test', '-p', 'motion-model', '-p', 'motion-core'] + tail, ['motion-model', 'motion-core']),
    ('render-lens-color-lib', render + tail, None),
    ('host-media', ['cargo', 'test', '-p', 'motion-host', '-p', 'motion-desktop-media', '--features', 'motion-desktop-media/ffmpeg'] + tail, ['motion-host', 'motion-desktop-media']),
    ('normal-dev-build', ['cargo', 'build', '-p', 'motion-desktop', '--bin', 'motion-studio', '--features', 'ffmpeg', '--locked', '--offline'], None),
    ('desktop-ui', ['cargo', 'test', '-p', 'motion-desktop', '-p', 'motion-ui', '--features', 'motion-desktop/ffmpeg',
        '--config', 'profile.test.package.motion-desktop.codegen-units=4',
        '--config', 'profile.test.package.motion-ui.codegen-units=4'] + tail, ['motion-desktop', 'motion-ui'])]
report = dict(status='running', controllerPid=os.getpid(), baseCommit=head, integratedMain='eeada782742cae29935f59b9d89ee5145b92712a',
    source=source, startedUtc=datetime.now(timezone.utc).isoformat(), steps=[], limits=[
        'Affected full model/core/host/media/desktop/UI packages; selected eleven render integration targets plus render library, not complete workspace',
        'Android excluded; no assertion, budget, original ignore, stack, backend or production profile change',
        'Previously documented desktop/UI test-only codegen-units4; default Info and adapter; one own GPU workload; controlled caches/temp on E',
        'The earlier full desktop/UI failure and passing direct child remain separate; this gate cannot establish their cause'])

def save():
    tmp = OUT / 'exit.pending.json'
    tmp.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    os.replace(tmp, OUT / 'exit.json')

def expected_invocations(packages):
    result = []
    for p in metadata['packages']:
        if p['name'] not in packages:
            continue
        result.extend((t['name'], t['kind'][0]) for t in p['targets'] if t['test'])
        if any(t['doctest'] for t in p['targets']):
            result.append((p['name'].replace('-', '_'), 'doc'))
    return result

start = time.monotonic()
save()
try:
    for label, command, packages in steps:
        identity()
        row = dict(label=label, command=command, status='running', startedUtc=datetime.now(timezone.utc).isoformat())
        report['steps'].append(row)
        save()
        began = time.monotonic()
        with (OUT / (label + '.stdout.log')).open('wb') as stdout, (OUT / (label + '.stderr.log')).open('wb') as stderr:
            p = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
            row['pid'] = p.pid
            save()
            row['exitCode'] = p.wait()
        identity()
        row.update(status='passed' if row['exitCode'] == 0 else 'failed', elapsedSeconds=round(time.monotonic()-began, 3))
        if 'test' in command:
            summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',
                (OUT / (label + '.stdout.log')).read_text(encoding='utf-8', errors='replace'), re.M)
            invocations = re.findall(r'^\s*(?:Running|Doc-tests) .+$', (OUT / (label + '.stderr.log')).read_text(encoding='utf-8', errors='replace'), re.M)
            row.update(summaries=summaries, invocations=invocations)
            if row['exitCode'] == 0:
                assert summaries and len(summaries) == len(invocations)
                assert all(s[0] == 'ok' and s[2] == s[5] == '0' for s in summaries)
                if packages:
                    expected = expected_invocations(packages)
                    assert len(expected) == len(invocations), label
                    for name, kind in expected:
                        assert any((f'Doc-tests {name}' if kind == 'doc' else name.replace('-', '_') + '-') in v for v in invocations), name
                else:
                    assert len(invocations) == len(render_targets) + 1
                    for name in render_targets + ['motion_render']:
                        assert any(name + '-' in v for v in invocations), name
                row['totals'] = dict(passed=sum(int(s[1]) for s in summaries), failed=0,
                    originalIgnored=sum(int(s[3]) for s in summaries), filtered=0, targets=len(summaries))
        save()
    identity()
    report.update(sourceUnchanged=True, status='aligned_main_affected_packages_passed' if all(r['exitCode'] == 0 for r in report['steps']) else 'aligned_main_has_failed_gates_original_outputs_retained')
    if report['steps'][4]['exitCode'] == 0:
        binary = ROOT / 'target/rational-rate85-contract/debug/motion-studio.exe'
        report.update(binary=str(binary), binarySha256=sha(binary))
except BaseException as cause:
    report.update(status='observer_failed_original_outputs_retained', failure=repr(cause), traceback=traceback.format_exc())
    raise
finally:
    report.update(elapsedSeconds=round(time.monotonic()-start, 3), completedUtc=datetime.now(timezone.utc).isoformat())
    save()
print(json.dumps(dict(status=report['status'], seconds=report['elapsedSeconds'], steps=[(r['label'], r['exitCode']) for r in report['steps']])), flush=True)
if report['status'] != 'aligned_main_affected_packages_passed':
    raise SystemExit(1)
