"""One serial native qualification after the Session regression is consumed."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, time, traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/depth-export75'
BASE = ROOT / 'artifacts/pr-queue'
OUT = BASE / 'depth75-frozen-output-v1'
PRIOR = BASE / 'depth75-session-regression-v2'
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
prior,consumed=read(BASE/'depth75-frozen-target-v2/receipt.json'),read(BASE/'depth75-frozen-target-v2/session-consumed.json')
assert prior['status']=='complete_frozen_eight_controls_and_feature_off_passed' and prior['sourceUnchanged']
assert consumed['status']=='terminal_consumed' and consumed['session']==60024 and consumed['exitCode']==0
assert shutil.disk_usage(ROOT).free >= 10 << 30
assert 'RUSTC_WRAPPER' not in os.environ and 'RUSTC_WORKSPACE_WRAPPER' not in os.environ
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()
def identity(): return {p: sha(WORK / p) for p in paths}
source = identity()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert head == 'b190db953ef966d6b12d7ae98005c94ae615afa2'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = {k: v for k, v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT / 'target/depth75-post-restart-validation'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0', RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT / 'appdata'),
           TEMP=str(ROOT / 'target/depth75-post-restart-validation/tmp'), TMP=str(ROOT / 'target/depth75-post-restart-validation/tmp'))
names=['movie::depth_tests::aligned::aligned_transition_png_and_durable_mp4_keep_raw_metric_occlusion_without_live_owners_or_inference',
       'movie::depth_tests::actual_png_keeps_calibrated_geometry_after_seek_close_and_original_source_removal',
       'movie::depth_tests::durable_mp4_restores_scalar_depth_after_all_owners_exit_and_decodes_every_frame']
env['MOTION_FROZEN_DEPTH_ARTIFACTS']=str(OUT/'outputs')
report = dict(status='running', baseCommit=head, source=source, startedUtc=datetime.now(timezone.utc).isoformat(),
              expectedNewControls=names, stages=[], limits=[
                  'Scoped actual PNG/MP4 consumer controls after main rebase; deliberately filters unrelated media unit tests',
                  'Original assertions, ignores, deadlines, backend and 10 GiB gate retained',
                  'One own native workload; no Android or real-model quality qualification inferred',
                  'Current source differs from Session PR642; its earlier passes are not this increment acceptance'])
def save():
    path = OUT / 'receipt.pending.json'
    path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8'); os.replace(path, OUT / 'receipt.json')
def run(name, command):
    assert shutil.disk_usage(ROOT).free >= 10 << 30
    row = dict(name=name, command=command); report['stages'].append(row); save()
    with (OUT / (name + '.stdout.log')).open('wb') as out, (OUT / (name + '.stderr.log')).open('wb') as err:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=out, stderr=err)
        row['pid'] = child.pid; save(); row['exitCode'] = child.wait()
    save(); return row
save(); began = time.monotonic()
try:
    row = run('native', ['cargo','test','--locked','-p','motion-desktop-media','--features','ffmpeg,ai-depth,gpu-tests','--lib','movie::depth_tests','--','--test-threads=1'])
    stdout = (OUT / 'native.stdout.log').read_text(encoding='utf-8', errors='replace')
    stderr = (OUT / 'native.stderr.log').read_text(encoding='utf-8', errors='replace')
    summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', stdout, re.M)
    report.update(totals=dict(passed=sum(int(s[1]) for s in summaries), failed=sum(int(s[2]) for s in summaries),
        originalIgnored=sum(int(s[3]) for s in summaries), filtered=sum(int(s[5]) for s in summaries), summaries=len(summaries)),
        namedPasses=[n for n in names if len(re.findall(r'(?m)^test ' + re.escape(n) + r' \.\.\. ok$', stdout)) == 1],
        abnormalTargetExits=[line for line in stderr.splitlines() if "process didn't exit successfully:" in line],
        failedTests=re.findall(r'^test ([^\r\n]+?) \.\.\. FAILED\s*$', stdout, re.M))
    row['passed'] = row['exitCode'] == 0 and len(summaries) == 1 and not report['totals']['failed'] and not report['abnormalTargetExits'] and len(report['namedPasses']) == len(names)
    save()
    report['status']='complete_three_actual_output_controls_passed' if row['passed'] and report['totals']['passed']==3 else 'failed_original_outputs_retained'
except BaseException as cause:
    report.update(status='observer_failed_original_outputs_retained', cause=repr(cause), traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=identity() == source, completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - began, 3))
    report['logs'] = {p.name: dict(bytes=p.stat().st_size, sha256=sha(p)) for p in OUT.glob('*.log')}; save()
print(json.dumps({k: v for k, v in report.items() if k != 'source'}))
raise SystemExit(0 if report['status'] == 'complete_three_actual_output_controls_passed' and report['sourceUnchanged'] else 1)
