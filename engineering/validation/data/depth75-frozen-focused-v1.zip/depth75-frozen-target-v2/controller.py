"""One serial native qualification after the Session regression is consumed."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, time, traceback

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/depth-export75'
BASE = ROOT / 'artifacts/pr-queue'
OUT = BASE / 'depth75-frozen-target-v2'
PRIOR = BASE / 'depth75-session-regression-v2'
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
prior, consumed = read(PRIOR / 'receipt.json'), read(PRIOR / 'session-consumed.json')
assert prior['status'] == 'complete_changed_crates58_controls_and_desktop_check_passed'
assert prior['sourceUnchanged'] and consumed['status'] == 'terminal_consumed' and consumed['session'] == 71613 and consumed['exitCode'] == 0
failed=read(BASE/'depth75-frozen-target-v1/receipt.json')
failed_consumed=read(BASE/'depth75-frozen-target-v1/session-consumed.json')
manifest=read(BASE/'depth75-frozen-target-v1/failed-source-manifest.json')
assert failed['status']=='failed_original_outputs_retained' and failed['sourceUnchanged']
assert failed_consumed['session']==84215 and failed_consumed['exitCode']==1 and failed_consumed['status']=='terminal_consumed'
assert len(failed['failedTests'])==2 and failed['totals']['passed']==284
assert manifest['status']=='all_failed_executed_source_members_verified' and len(manifest['members'])==13
import zipfile
with zipfile.ZipFile(BASE/'depth75-frozen-target-v1/failed-executed-source.zip') as archive:
    for name,row in manifest['members'].items():
        assert hashlib.sha256(archive.read(name)).hexdigest()==row['sha256']
assert shutil.disk_usage(ROOT).free >= 10 << 30
assert 'RUSTC_WRAPPER' not in os.environ and 'RUSTC_WORKSPACE_WRAPPER' not in os.environ
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()
def identity(): return {p: sha(WORK / p) for p in paths}
source = identity()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert head == '7d6e9cf9be9670e4ad3a4a210117f81fa9f07437'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
env = {k: v for k, v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
           CARGO_TARGET_DIR=str(ROOT / 'target/depth75-post-restart-validation'),
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0', RUST_BACKTRACE='full', LOCALAPPDATA=str(OUT / 'appdata'),
           TEMP=str(ROOT / 'target/depth75-post-restart-validation/tmp'), TMP=str(ROOT / 'target/depth75-post-restart-validation/tmp'))
names = [
    'depth_snapshot::wire::tests::aligned::aligned_wire_requalifies_actual_instances_and_preserves_original_calibration_and_sharing',
    'depth_snapshot::wire::tests::aligned::aligned_wire_refuses_policy_metadata_and_plane_corruption_before_admission',
    'depth_snapshot::wire::tests::aligned::aligned_wire_counts_reference_and_candidate_memory_before_reading_planes',
    'depth_snapshot::wire::tests::aligned::aligned_restore_preserves_cancellation_inside_fit_and_checks_reference_identity',
    'transitions::frozen::frozen_transition_selects_current_phase_and_refuses_pending_seek_and_revoked_generations',
    'transitions::frozen::frozen_transition_fit_start_is_visible_at_default_info_before_cancellation',
    'transitions::frozen::failed_transition_cannot_freeze_an_older_raw_reference_or_retry_backend',
    'transitions::frozen::frozen_transition_roundtrip_matches_raw_metric_occlusion_after_session_close_and_copied_source_removal',
]
report = dict(status='running', baseCommit=head, source=source, startedUtc=datetime.now(timezone.utc).isoformat(),
              expectedNewControls=names, stages=[], limits=[
                  'Complete host unit and depth_session targets; actual GPU via existing gpu-tests feature',
                  'Original assertions, ignores, deadlines, backend and 10 GiB gate retained',
                  'One own native workload; no Android or real-model quality qualification inferred',
                  'Current source differs from Session PR642; its earlier passes are not this increment acceptance'])
def save():
    path = OUT / 'receipt.pending.json'
    path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8'); os.replace(path, OUT / 'receipt.json')
def run(name, command):
    assert shutil.disk_usage(ROOT).free >= 10 << 30
    row = dict(name=name, command=command); report['stages'].append(row); save()
    with (OUT / (name + '.stdout.log')).open('wb') as out, (OUT / (name + '.stderr.log')).open('wb') as err:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=out, stderr=err)
        row['pid'] = child.pid; save(); row['exitCode'] = child.wait()
    save(); return row
save(); began = time.monotonic()
try:
    row = run('native', ['cargo', 'test', '--locked', '-p', 'motion-host', '--features', 'ai-depth,gpu-tests',
        '--lib', '--test', 'depth_session', '--no-fail-fast', '--', '--test-threads=1'])
    stdout = (OUT / 'native.stdout.log').read_text(encoding='utf-8', errors='replace')
    stderr = (OUT / 'native.stderr.log').read_text(encoding='utf-8', errors='replace')
    summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', stdout, re.M)
    report.update(totals=dict(passed=sum(int(s[1]) for s in summaries), failed=sum(int(s[2]) for s in summaries),
        originalIgnored=sum(int(s[3]) for s in summaries), filtered=sum(int(s[5]) for s in summaries), summaries=len(summaries)),
        namedPasses=[n for n in names if len(re.findall(r'(?m)^test ' + re.escape(n) + r' \.\.\. ok$', stdout)) == 1],
        abnormalTargetExits=[line for line in stderr.splitlines() if "process didn't exit successfully:" in line],
        failedTests=re.findall(r'^test ([^\r\n]+?) \.\.\. FAILED\s*$', stdout, re.M))
    row['passed'] = row['exitCode'] == 0 and len(summaries) == 2 and not report['totals']['failed'] and not report['totals']['filtered'] and not report['abnormalTargetExits'] and len(report['namedPasses']) == len(names)
    save()
    if row['passed']:
        check = run('feature-off', ['cargo', 'check', '--locked', '-p', 'motion-host', '--no-default-features'])
        check['passed'] = check['exitCode'] == 0
    report['status'] = 'complete_frozen_eight_controls_and_feature_off_passed' if len(report['stages']) == 2 and all(s['passed'] for s in report['stages']) else 'failed_original_outputs_retained'
except BaseException as cause:
    report.update(status='observer_failed_original_outputs_retained', cause=repr(cause), traceback=traceback.format_exc())
finally:
    report.update(sourceUnchanged=identity() == source, completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - began, 3))
    report['logs'] = {p.name: dict(bytes=p.stat().st_size, sha256=sha(p)) for p in OUT.glob('*.log')}; save()
print(json.dumps({k: v for k, v in report.items() if k != 'source'}))
raise SystemExit(0 if report['status'] == 'complete_frozen_eight_controls_and_feature_off_passed' and report['sourceUnchanged'] else 1)
