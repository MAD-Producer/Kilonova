import pathlib,json,hashlib,zipfile,subprocess
r=pathlib.Path('E:/Dev/aem/artifacts/menu-caption-borrow')
repo=pathlib.Path('E:/Dev/aem/.worktrees/shortcut-feedback')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt={'tested_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
 'keyboard':{'passed':27,'failed':0,'ignored':1},'native':{'passed':1,'failed':0,'ignored':0},
 'native_png_comparisons':json.loads((r/'combined-native/comparison.json').read_text(encoding='utf-8')),
 'test_exe_sha256':sha(r/'combined-runtime/acceptance.exe'),'product_sha256':sha(r/'combined-product-runtime/motion-studio.exe'),
 'menu_source_sha256':sha(repo/'desktop/ui/src/widgets/menu.rs')}
(r/'combined-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
out=repo/'engineering/validation/data/menu-caption-integration.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in r.glob('combined-*.log'):z.write(p,'logs/'+p.name)
 for p in (r/'combined-native').glob('*'):
  if p.is_file():z.write(p,'native/'+p.name)
 for name in ['combined-receipt.json','combined-package.py']:z.write(r/name,name)
 z.write(repo/'desktop/ui/src/widgets/menu.rs','source/menu.rs')
print(json.dumps({'bytes':out.stat().st_size,'sha256':sha(out),'product_sha256':receipt['product_sha256']}))
