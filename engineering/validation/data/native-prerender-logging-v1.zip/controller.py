"""Actual blocked-handler and default desktop sink controls; no broad repeat."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/native-prerender-runtime'
OUT = ROOT / 'artifacts/pr-queue/prerender-logging-v1'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()

def sources():
    paths = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {p: hashlib.sha256((WORK / p).read_bytes()).hexdigest() for p in paths if p and
            (p.endswith(('.rs', '.toml', '.wgsl', '.py', '.json', '.yml', '.yaml')) or p == 'Cargo.lock')}

prior = json.loads((ROOT / 'artifacts/pr-queue/prerender-consumer-v2/accepted.json').read_text())
assert prior['status'] == 'accepted' and prior['sourceUnchanged']
assert not git('status', '--porcelain')
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'controller.py')
source = sources()
report = dict(head=git('rev-parse', 'HEAD'), source=source, status='running', steps=[])
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0',
           CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
           MOTION_PRERENDER_BUFFERED_ARTIFACTS=str(OUT / 'buffered'), MOTION_PRERENDER_LOG_ARTIFACTS=str(OUT / 'desktop'))
test = ['cargo','test','-p','motion-desktop-media','--features','ffmpeg,ai-depth','--locked','--offline','--lib']
guard = 'movie::prerender::worker::tests::logging::worker_start_flushes_before_entering_the_controlled_handler'
desktop = 'engine::pending_video_tests::prerender_logging::prerender_worker_start_is_on_disk_before_blocked_decode_and_error_uses_default_sinks'
steps = [
    ('blocked-handler-buffered-start', [*test,guard,'--','--exact','--test-threads=1'], 1),
    ('worker', [*test,'movie::prerender::worker::','--','--test-threads=1'], 7),
    ('default-desktop-sinks', ['cargo','test','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline','--bin','motion-studio',desktop,'--','--exact','--test-threads=1'], 1),
]
for name, args, expected in steps:
    print(json.dumps(dict(start=name)), flush=True)
    with (OUT / (name + '.stdout.log')).open('wb') as so, (OUT / (name + '.stderr.log')).open('wb') as se:
        code = subprocess.run(args, cwd=WORK, env=env, stdout=so, stderr=se).returncode
    stdout = (OUT / (name + '.stdout.log')).read_text(encoding='utf-8')
    counts = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored', stdout)
    row = dict(name=name, command=args, exitCode=code, counts=counts, sourceUnchanged=sources() == source)
    report['steps'].append(row)
    (OUT / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], row
    assert counts and sum(int(p) for p, _, _ in counts) == expected, row
    assert all(int(f) == 0 and int(i) == 0 for _, f, i in counts), row
cause = 'controlled first video frame failure'
file_log = (OUT / 'desktop/default-file.log').read_text(encoding='utf-8')
stderr = (OUT / 'desktop/default-stderr.log').read_text(encoding='utf-8')
stdout = (OUT / 'desktop/default-stdout.log').read_text(encoding='utf-8')
blocked = (OUT / 'desktop/blocked-start.log').read_text(encoding='utf-8')
assert cause in file_log and cause in stderr and cause not in stdout
assert 'prerender_worker operation=render' in blocked and cause not in blocked
buffered = (OUT / 'buffered/before-handler.log').read_text(encoding='utf-8')
assert 'prerender_worker operation=prepare' in buffered and 'prerender_prepare' not in buffered
report.update(status='accepted', sourceUnchanged=sources() == source, completedUtc=datetime.now(timezone.utc).isoformat(),
              scope='Buffered start regression guard blocks before handler; separate actual default desktop logger control blocks decode and proves file/Error-stderr/stdout isolation. Engine runtime and performance remain pending. Focused guard count overlaps worker suite; full host/render acceptance is source-bound in consumer-v2 and was not repeated for test-only additions.')
report['artifacts'] = {str(p.relative_to(OUT)): hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in OUT.rglob('*') if p.is_file() and p.name not in ['exit.json','accepted.json']}
(OUT / 'accepted.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True)), flush=True)
