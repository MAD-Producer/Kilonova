from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, time

root=Path('E:/Dev/aem');work=root/'.worktrees/tracking-import88'
out=root/'artifacts/pr-queue/frame-rate85-event-loop-isolation-v1';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
relative='desktop/app/src/shell/rational_clock_native_tests.rs'
before=subprocess.check_output(['git','show','HEAD:'+relative],cwd=work)
after=(work/relative).read_bytes()
insertion=after[len(before[:before.index(b'    let temporary')]):after.index(b'    let temporary')]
assert after.replace(insertion,b'',1)==before, 'Only child-process wrapper may change'
(out/'before.rs').write_bytes(before);(out/'after.rs').write_bytes(after)
names=subprocess.check_output(['git','ls-files','-z','crates','desktop','Cargo.toml','Cargo.lock'],cwd=work).decode().split('\0')
sha=lambda data:hashlib.sha256(data).hexdigest()
sources={name:sha((work/name).read_bytes()) for name in names if name and (work/name).is_file()}
test='shell::rational_clock_native_tests::fractional_project_clocks_render_native_readouts_in_both_locales'
first='engine::failure::tests::attached_hidden_surface_and_factory_release_after_worker_panic'
env=os.environ.copy();env.pop('MOTION_LOG',None);env.pop('MOTION_RATIONAL_CLOCK_UI_CHILD',None)
env['LOCALAPPDATA']=str(out/'appdata');env['MOTION_RATIONAL_CLOCK_UI_ARTIFACTS']=str(out/'captures')
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--locked','--offline','--','--exact',first,test,'--test-threads=1','--nocapture']
report=dict(status='running',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),
    sources=sources,command=command,startedUtc=datetime.now(timezone.utc).isoformat(),sourceChange='Only process-isolation prefix; original body and assertions byte-identical',
    limits=['Two actual ordered controls, not complete desktop/UI acceptance',
            'Earlier full CI failures retained: 1698 passed, one RecreationAttempt, 69 original ignores in each Windows run',
            'No retry, changed assertions/budgets/ignores, product changes or Android'])
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save();began=time.monotonic()
try:
    with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
        p=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr);report['pid']=p.pid;save();report['exitCode']=p.wait()
    text=(out/'stdout.log').read_text(encoding='utf-8',errors='replace')
    report['summaries']=re.findall(r'^test result: .+$',text,re.M)
    assert report['exitCode']==0
    assert any('2 passed; 0 failed; 0 ignored;' in row for row in report['summaries']),report['summaries']
    assert text.index('test '+first) < text.index('test '+test), 'The parent event loop must run first'
    cases=json.loads((out/'captures/report.json').read_text(encoding='utf-8'))
    assert len(cases)==4 and all(row['documentUnchanged'] and row['uniqueColors']>16 for row in cases)
    report['sourceUnchanged']=all(sha((work/name).read_bytes())==h for name,h in sources.items());assert report['sourceUnchanged']
    report.update(status='ordered_parent_event_loop_and_isolated_four_native_readbacks_passed_visual_review_pending',cases=cases)
except BaseException as cause:
    report.update(status='failed_original_outputs_retained',failure=repr(cause));raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3));save()
print(json.dumps({k:v for k,v in report.items() if k not in ['sources','cases']}),flush=True)
