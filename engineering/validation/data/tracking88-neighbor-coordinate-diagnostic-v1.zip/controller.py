"""Test an annotation-phase hypothesis on frozen numbers, without decoding."""
from pathlib import Path
import hashlib
import json
import math
import statistics
import zipfile

BASE = Path('E:/Dev/aem/artifacts/pr-queue')
OUT = BASE / 'tracking88-neighbor-coordinate-diagnostic-v1'
TRUTH = BASE / 'tracking88-real-planar-acquisition-v1/phone-gt.zip'
TRACK = BASE / 'tracking88-photographed-prototype-v6/periodic-manual-200/tracks.mstrack'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert sha(TRUTH) == 'd4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
assert sha(TRACK) == '5dd567b7f1ec994a4120700fe529abdf97fdc27ffd7c10f327751ab91bc68dfa'
with zipfile.ZipFile(TRUTH) as archive:
    names = sorted(i.filename for i in archive.infolist() if not i.is_dir())
    assert names == [f'img_{i:05d}.txt' for i in range(200, 2500)]
    quads = []
    for name in names:
        assert archive.getinfo(name).file_size <= 1024
        row = list(map(float, archive.read(name).decode('ascii').split()))
        assert len(row) == 8 and all(map(math.isfinite, row))
        quads.append([(row[4+i]-1, row[i]-1) for i in range(4)])
asset = json.loads(TRACK.read_text(encoding='utf-8'))
assert asset['source_pts'] == list(range(2300)) and asset['ticks_per_second'] == 100
track = next(t for t in asset['tracks'] if t['kind'] == 'plane')
assert len(track['samples']) == 2300


def project(matrix, p):
    v = [r[0]*p[0]+r[1]*p[1]+r[2] for r in matrix]
    assert all(map(math.isfinite, v)) and abs(v[2]) > 1e-10
    return v[0]/v[2], v[1]/v[2]


predictions = {}
manual = lost = 0
for index, sample in enumerate(track['samples']):
    assert index == sample['source_index']
    if sample['manual_correction']:
        manual += 1
    elif index == 0:
        continue
    elif sample['visibility'] != 'visible':
        lost += 1
    else:
        predictions[index] = [project(sample['observation']['matrix'], p) for p in quads[0]]
assert len(predictions) == 915 and manual == 11 and lost == 1373
original_errors = {i: max(math.dist(a, b) for a, b in zip(p, quads[i])) for i, p in predictions.items()}
bad = {i for i, error in original_errors.items() if error > 15}
assert bad == set(range(1801, 1811)) | set(range(1812, 1823))
assert abs(max(original_errors.values()) - 56.6400304460409) < 1e-9

rows = []
for offset in (-2, -1, 0, 1, 2):
    missing = [i for i in predictions if not 0 <= i+offset < len(quads)]
    errors = {i: max(math.dist(a, b) for a, b in zip(p, quads[i+offset]))
              for i, p in predictions.items() if i not in missing}
    assert bad <= errors.keys()
    rows.append(dict(annotation_offset=offset, original_automatic_visible=len(predictions),
        compared_observations=len(errors), missing_annotation_pairs=len(missing),
        maximum_error=max(errors.values()), rms_error=math.sqrt(statistics.mean(e*e for e in errors.values())),
        over_15_pixels=sum(e > 15 for e in errors.values()),
        original_21_bad_still_above_15=sum(errors[i] > 15 for i in bad),
        original_21_bad_maximum=max(errors[i] for i in bad),
        original_21_bad_rms=math.sqrt(statistics.mean(errors[i]**2 for i in bad))))
result = dict(status='neighbor_annotation_coordinate_hypothesis_measured_not_acceptance',
    original_annotation_sha256=sha(TRUTH), original_output_sha256=sha(TRACK),
    original_source_frames=2300, original_automatic_visible=915, manual_corrections=manual,
    original_automatic_lost=lost, offsets=rows,
    limits=[
        'Standard library only; no CV import, source decoding, tracking, GPU or inference',
        'All original automatic observations retained; missing neighboring annotations reported explicitly',
        'No offset is selected or applied to source PTS, requests, annotations, outputs or the original15pixel gate',
        'This numeric diagnostic does not independently verify video/annotation phase or establish a root cause',
        'No third-party media, annotations, full requests or per-frame observation arrays redistributed'])
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
(OUT/'receipt.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result, indent=2))
