"""Archive exact published head CI; retain local acceptance failures separately."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path('E:/Dev/aem')
OUT = ROOT/'artifacts/pr-queue/prerender-head-ci-652-final-v2'
REPO = 'MAD-Producer/Kilonova'
RUN = '41177231677'
HEAD = '652fbe6525f5813a85620fe0d5d2ad4eef5f9bfb'
OUT.mkdir(exist_ok=False)

def gh(*args):
    result = subprocess.run(['gh',*args],capture_output=True)
    assert result.returncode == 0, result.stderr.decode(errors='replace')
    return result.stdout

raw = gh('run','view',RUN,'--repo',REPO,'--json','headSha,status,conclusion,jobs,event,url')
(OUT/'run.json').write_bytes(raw)
run = json.loads(raw)
assert run['headSha']==HEAD and run['status']=='completed' and run['conclusion']=='success'
required = [j for j in run['jobs'] if j['name'] not in ('Desktop libav backend','Publish desktop release')]
assert len(required)==5 and all(j['status']=='completed' and j['conclusion']=='success' for j in required)
assert all(j['status']=='completed' and j['conclusion']=='skipped' for j in run['jobs'] if j not in required)
assert any('ubuntu-24.04' in j['name'] for j in required)
assert any('windows-2022' in j['name'] for j in required)
assert any('macos-15-intel' in j['name'] for j in required)

def collect(job):
    name = f"job-{job['databaseId']}.log"
    data = gh('api',f"repos/{REPO}/actions/jobs/{job['databaseId']}/logs")
    (OUT/name).write_bytes(data)
    text = data.decode('utf-8',errors='replace')
    counts = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
    relevant = [line for line in text.splitlines() if
        ('scheduling::' in line and ' ... ok' in line)
        or ('effect_search_native_pixels_and_default_failure_sinks' in line and ' ... ' in line)]
    return dict(name=job['name'],id=job['databaseId'],conclusion=job['conclusion'],log=name,
        sha256=hashlib.sha256(data).hexdigest(),
        executionTotals=[sum(int(c[i]) for c in counts) for i in range(3)],
        actualRelevantTestLines=relevant,
        steps=[{k:s.get(k) for k in ['name','conclusion','status']} for s in job['steps']])

with ThreadPoolExecutor(max_workers=2) as pool:
    jobs = list(pool.map(collect,required))
report = dict(status='accepted_five_required_exact_head_pr_checks_not_local_issue_acceptance',
    head=HEAD,run=RUN,url=run['url'],collectedUtc=datetime.now(timezone.utc).isoformat(),jobs=jobs,
    skippedJobs=[j['name'] for j in run['jobs'] if j['name'] in ('Desktop libav backend','Publish desktop release')],
    limits='Exact published head only. Execution totals overlap across jobs and are not unique tests. PR excludes arm64/release FFmpeg packaging. Uncommitted idle-upload/input and late-input proposals are not covered. Local strict input P95 and native UI access violation remain failed and unexplained; green CI on another machine/features does not diagnose or erase those failures. Final changed source needs its own full regression, original P95, actual MCP and exact-head CI.')
(OUT/'accepted-exact-head-ci.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(OUT/'collector.py').write_bytes(Path(__file__).read_bytes())
entries = {p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file()}
archive = OUT/'native-prerender-ci-652-five-checks.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(entries)
    assert all(z.read(name)==data for name,data in entries.items())
receipt = dict(members=len(entries),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),head=HEAD)
(OUT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(dict(status=report['status'],archive=receipt,jobs=jobs)))
