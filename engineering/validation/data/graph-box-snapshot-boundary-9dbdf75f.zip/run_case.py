from pathlib import Path
import subprocess,hashlib,json,os,time,sys,re
root=Path('E:/Dev/aem');out=root/'.tools/graph-box-snapshot-boundary';work=root/'.worktrees/graph-box-snapshot-boundary'
phase=sys.argv[1];assert phase in ['before','after']
target=out/phase;target.mkdir(exist_ok=False)
paths=['desktop/app/src/panels/graph_box.rs','desktop/app/src/panels/timeline_shortcuts_tests.rs',
       'desktop/app/src/panels/timeline_shortcuts_tests/graph_box_snapshot_tests.rs']
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
sources=freeze();(work/'desktop/app/src/main.rs').touch()
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--config','profile.dev.package.motion-desktop.debug=0',
         '--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1',
         'graph_box_snapshot_tests','--','--test-threads=1']
env=os.environ.copy();env.pop('MOTION_LOG',None);env['MOTION_GRAPH_BOX_SNAPSHOT_ARTIFACTS']=str(target/'default-info')
start=time.monotonic();print(phase+' started',flush=True)
with (target/'cargo.log').open('w',encoding='utf8') as sink:
    result=subprocess.run(command,cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT)
text=(target/'cargo.log').read_text(encoding='utf8')
receipt=dict(phase=phase,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,encoding='utf8').strip(),
    command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),sources=sources,source_unchanged=freeze()==sources,
    binary_sha256=hashlib.sha256((root/'target/debug/deps/motion_studio-d5bd28a41c2d0117.exe').read_bytes()).hexdigest(),
    actual_desktop_compile=any('Compiling motion-desktop ' in l and str(work).replace('\\','/').casefold() in l.replace('\\','/').casefold() for l in text.splitlines()))
(target/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
assert receipt['source_unchanged'] and receipt['actual_desktop_compile']
if phase=='before':
    assert result.returncode!=0 and '0 passed; 2 failed;' in text and 'graph_box.rs:234:' in text
    assert 'called `Option::unwrap()` on a `None` value' in text
else:
    assert result.returncode==0 and '2 passed; 0 failed;' in text
print(json.dumps(receipt),flush=True)
