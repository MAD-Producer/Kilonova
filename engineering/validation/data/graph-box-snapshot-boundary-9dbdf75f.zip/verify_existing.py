from pathlib import Path
import subprocess,json,hashlib,time,os,re
root=Path('E:/Dev/aem');parent=root/'.tools/graph-box-snapshot-boundary';work=root/'.worktrees/graph-box-snapshot-boundary'
after=json.loads((parent/'after/receipt.json').read_text(encoding='utf8'));assert after['exit_code']==0
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in after['sources']}
assert freeze()==after['sources'];out=parent/'existing-regressions';out.mkdir(exist_ok=False);records=[]
common=after['command'][:after['command'].index('graph_box_snapshot_tests')]
for label,pattern,expected in [('curve-box','curve_selection_box',3),('box-geometry','panels::graph_box::tests::',2),
                               ('property-owner','old_graph_box_cannot_delete_keys_after_another_property_takes_ownership',1)]:
    command=common+[pattern,'--','--test-threads=1'];start=time.monotonic();env=os.environ.copy();env.pop('MOTION_LOG',None)
    with (out/(label+'.log')).open('w',encoding='utf8') as sink:
        result=subprocess.run(command,cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT)
    text=(out/(label+'.log')).read_text(encoding='utf8');summary=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    item=dict(label=label,command=command,seconds=round(time.monotonic()-start,2),exit_code=result.returncode,
              source_unchanged=freeze()==after['sources'],binary_sha256=hashlib.sha256((root/'target/debug/deps/motion_studio-d5bd28a41c2d0117.exe').read_bytes()).hexdigest())
    records.append(item);(out/'receipt.json').write_text(json.dumps(records,indent=2),encoding='utf8')
    assert result.returncode==0 and summary and item['source_unchanged'] and item['binary_sha256']==after['binary_sha256']
    item['passed'],item['failed'],item['ignored']=map(int,summary.groups());assert (item['passed'],item['failed'],item['ignored'])==(expected,0,0)
    (out/'receipt.json').write_text(json.dumps(records,indent=2),encoding='utf8');print(json.dumps(item),flush=True)
