//! External acceptance: real Session + managed PNG + Onnx + product logger.
#[path = "E:/Dev/aem/.worktrees/ai-depth/desktop/app/src/logging.rs"]
mod logging;
mod engine {
    pub fn current_command() -> Option<(u64, &'static str, std::time::Duration)> { None }
}
use motion_host::{depth::onnx::{Config, Onnx, Provider, PROCESSING}, Platform, Session};
use motion_model::depth::{DepthGeometry, DepthModel};
use std::{fs, path::{Path, PathBuf}, sync::Arc, thread, time::{Duration, Instant}};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
struct NoMedia;
impl Platform for NoMedia {
    fn name(&self) -> &'static str { "actual-depth-session-acceptance" }
    fn probe_video(&self, _: &Path, _: Option<u32>, _: Option<u32>, _: &dyn Fn() -> motion_media::Result<()>) -> motion_media::Result<motion_media::VideoProbe> { unreachable!() }
    fn open_decoder(&self, _: &Path, _: motion_core::VideoAsset, _: Vec<u64>) -> motion_media::Result<Box<dyn motion_host::VideoDecoder>> { unreachable!() }
    fn decode_audio(&self, _: &Path, _: &Path, _: Option<u32>, _: u64, _: &mut dyn FnMut(Option<f64>) -> motion_media::Result<()>) -> motion_media::Result<motion_core::AudioAsset> { unreachable!() }
    fn media_capabilities(&self, _: Option<&motion_host::VideoQuery>) -> motion_media::Result<serde_json::Value> { Ok(serde_json::json!({})) }
    fn attach_surface(&self, _: Arc<dyn wgpu::DisplayAndWindowHandle + Send + Sync>, _: u32, _: u32, _: motion_render::AllocationBudget) -> motion_host::Result<motion_host::SurfaceTarget> { unreachable!() }
}
fn wait(session: &mut Session) -> Result<Arc<motion_host::depth::Estimate>> {
    let began = Instant::now();
    loop {
        if let Some(result) = session.poll_depth()? { return Ok(result); }
        assert!(began.elapsed() < Duration::from_secs(120), "real Session inference did not finish");
        thread::sleep(Duration::from_millis(2));
    }
}
fn main() -> Result<()> {
    let args: Vec<String> = std::env::args().collect();
    let out = PathBuf::from(&args[1]);
    let mode = &args[2];
    fs::create_dir_all(out.join("project/assets"))?;
    let _logger = logging::init(out.join("logs"))?;
    let home = PathBuf::from("E:/Dev/aem/.tools/ai-depth74");
    let fixture = PathBuf::from("E:/Dev/aem/artifacts/pr-queue/issue74-letterbox-worker-v2/96x64");
    let rgb = fs::read(fixture.join("input.rgb"))?;
    image::RgbImage::from_raw(96,64,rgb).ok_or("bad reference dimensions")?.save(out.join("project/assets/source.png"))?;
    let mut project = motion_core::Project::new(96,64,30,60)?;
    project.assets.push(motion_core::Asset { id:74, path:"assets/source.png".into(),width:96,height:64 });
    let before = project.clone();
    let mut session = Session::new(project, out.join("project"), Arc::new(NoMedia))?;
    session.configure_depth(Onnx::new(Config {
        python:home.join("venv/Scripts/python.exe"), model:home.join("models/depth_anything_v2_vits_518.onnx"),
        scratch:out.join("scratch"), provider:Provider::Cpu,
    })?)?;
    let digest = "274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434";
    let sha256: Vec<u8> = (0..64).step_by(2).map(|n| u8::from_str_radix(&digest[n..n+2],16).unwrap()).collect();
    let model = DepthModel { id:"depth-anything-v2-small".into(),revision:"a561b849ebae10a6f5ef49e26c83cbbcd36c71bf".into(),
        sha256:sha256.try_into().unwrap(),processing:PROCESSING.into() };
    let geometry = DepthGeometry { source_size:[96,64],crop:[0,0,96,64],quarter_turns:0,mirror_x:false };
    let mut negative = None;
    if mode == "decode" || mode == "hash" || mode == "decode-only" {
        let mut wrong = model.clone();
        if mode.starts_with("decode") { fs::write(out.join("project/assets/source.png"), b"invalid PNG")?; }
        else { wrong.sha256 = [0;32]; }
        session.request_image_depth(74, geometry.clone(), wrong)?;
        let error = wait(&mut session).expect_err("actual invalid source/model must fail").to_string();
        if mode == "hash" { assert!(error.contains("SHA-256")); }
        else { assert!(error.contains("format")); }
        assert_eq!(session.depth_status()?.unwrap().counts.failed, 1);
        negative = Some(error);
        if mode == "decode-only" {
            assert!(session.poll_depth()?.is_none());
            let status = session.depth_status()?.unwrap();
            assert_eq!(status.counts.submitted, 1);
            assert_eq!(status.counts.failed, 1);
            assert!(!status.installed && status.in_flight.is_none() && status.queue_depth == 0);
            drop(session);
            assert!(!out.join("scratch").exists(), "decoder failure must precede ONNX staging");
            fs::write(out.join("accepted.json"), serde_json::to_vec_pretty(&serde_json::json!({
                "mode":mode,"request":1,"negative":negative,"actualSession":true,"actualManagedPng":true,
                "inferenceEntered":false,"renderDepthBound":false,"guiEngine":false
            }))?)?;
            logging::flush();
            return Ok(());
        }
        if mode == "decode" {
            let rgb = fs::read(fixture.join("input.rgb"))?;
            image::RgbImage::from_raw(96,64,rgb).unwrap().save(out.join("project/assets/source.png"))?;
        }
    }
    let ticket = session.request_image_depth(74, geometry.clone(), model.clone())?;
    let result = wait(&mut session)?;
    assert_eq!(result.provider, "CPUExecutionProvider");
    assert!(result.costs.inference > Duration::ZERO);
    let descriptor = result.resource.descriptor();
    assert_eq!(descriptor.geometry, geometry);
    assert_eq!(descriptor.model, model);
    assert_eq!(descriptor.source.revision, session.engine.revision());
    assert_eq!((descriptor.source.pts.ticks,descriptor.source.pts.timescale), (0,1));
    let expected = fs::read(fixture.join("official-reference.f32"))?;
    let reference: Vec<f32> = expected.chunks_exact(4).map(|b|f32::from_le_bytes(b.try_into().unwrap())).collect();
    assert_eq!(result.resource.values().len(), reference.len());
    let amplitude = reference.iter().map(|v| f64::from(v.abs())).fold(1e-6, f64::max);
    let errors: Vec<f64> = result.resource.values().iter().zip(&reference).map(|(a,b)| (f64::from(*a)-f64::from(*b)).abs()/amplitude).collect();
    let maximum = errors.iter().copied().fold(0.,f64::max);
    let mean = errors.iter().sum::<f64>() / errors.len() as f64;
    assert!(maximum <= 2e-4 && mean <= 2e-5, "official reference bounds max={maximum} mean={mean}");
    assert_eq!(session.engine.snapshot(), before);
    let status = session.depth_status()?.unwrap();
    assert_eq!(status.request, Some(ticket));
    assert_eq!(status.counts.completed, 1);
    assert!(status.installed && status.in_flight.is_none() && status.queue_depth == 0);
    session.frame = 1.;
    session.sample()?;
    assert!(session.poll_depth()?.is_none());
    assert!(!session.depth_status()?.unwrap().installed);
    drop(result);
    drop(session);
    assert_eq!(fs::read_dir(out.join("scratch"))?.count(), 0);
    fs::write(out.join("accepted.json"), serde_json::to_vec_pretty(&serde_json::json!({
        "mode":mode,"request":ticket,"negative":negative,"maxNormalized":maximum,"meanNormalized":mean,
        "provider":"CPUExecutionProvider","actualSession":true,"actualManagedPng":true,"seekInvalidated":true,
        "renderDepthBound":false,"guiEngine":false
    }))?)?;
    logging::flush();
    Ok(())
}
