"""Real product Session/FFmpeg/ONNX, independent FFmpeg pixels and official PyTorch reference."""
from pathlib import Path
import hashlib, json, math, os, subprocess, sys
root=Path('E:/Dev/aem');work=root/'.worktrees/video-depth';home=root/'.tools/ai-depth74'
probe=home/'video-probe';attempt=sys.argv[1] if len(sys.argv)>1 else 'v1'
assert attempt in ('v1','v2','v3')
out=root/'artifacts/pr-queue'/('issue74-video-native-'+attempt)
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def source():
    names=subprocess.check_output(['git','ls-files','-z'],cwd=work).decode().split('\0')
    r={p:sha(work/p) for p in names if p and (p.endswith(('.rs','.py','.toml')) or p=='Cargo.lock')}
    for p in ('Cargo.toml','Cargo.lock','src/main.rs'):r['external-probe/'+p]=sha(probe/p)
    return r
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
assert head.startswith('8af6ebfc') and not subprocess.check_output(['git','status','--porcelain'],cwd=work)
before=source();binary=root/'target/ai-depth74-contract/debug/motion-depth74-video-probe.exe'
build=json.loads((root/'artifacts/pr-queue/issue74-video-contract-v1/accepted.json').read_text(encoding='utf-8'))
assert build['source']==before and build['nativeProbeBinarySha256']==sha(binary)
receipt=dict(head=head,source=before,binarySha256=sha(binary),commands=[],motionLog=None)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
for p in ('Cargo.toml','Cargo.lock','src/main.rs'):
    (out/('probe-'+Path(p).name)).write_bytes((probe/p).read_bytes())
env=os.environ.copy();env.pop('MOTION_LOG',None)
for key,folder in [('TEMP','temp'),('TMP','temp'),('TORCH_HOME','torch-cache'),('HF_HOME','hf-cache'),('TORCHINDUCTOR_CACHE_DIR','inductor-cache'),('PYTHONPYCACHEPREFIX','pycache')]:
    p=home/folder;p.mkdir(exist_ok=True);env[key]=str(p);os.environ[key]=str(p)
env['CUDA_VISIBLE_DEVICES']='';os.environ['CUDA_VISIBLE_DEVICES']=''
ffbin=root/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
env['PATH']=str(ffbin)+os.pathsep+env['PATH']
def run(name,cmd,timeout=180):
    assert before==source()
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        p=subprocess.Popen(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr)
        row=dict(name=name,command=cmd,pid=p.pid);receipt['commands'].append(row)
        (out/'started.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
        row['exitCode']=p.wait(timeout=timeout)
    (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    assert row['exitCode']==0,name
    return (out/(name+'.stdout.log')).read_bytes()
import numpy as np
from PIL import Image
fixture=out/'fixture';fixture.mkdir();assets=out/'project/assets';assets.mkdir(parents=True)
rgb=np.fromfile(root/'artifacts/pr-queue/issue74-letterbox-worker-v2/96x64/input.rgb',np.uint8).reshape(64,96,3)
for i in range(3):Image.fromarray(np.roll(rgb,i*9,axis=1)).save(fixture/f'{i}.png')
(fixture/'frames.ffconcat').write_text("ffconcat version 1.0\nfile '0.png'\nduration 0.04\nfile '1.png'\nduration 0.08\nfile '2.png'\nduration 0.04\nfile '2.png'\n",encoding='utf-8')
run('encode-owned-source',[str(ffbin/'ffmpeg.exe'),'-nostdin','-hide_banner','-loglevel','error','-f','concat','-safe','0','-i',str(fixture/'frames.ffconcat'),'-fps_mode','vfr','-c:v','libopenh264','-b:v','2M','-g','30','-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-color_range','tv','-output_ts_offset','0.01','-video_track_timescale','1000000',str(assets/'source.mp4')])
frames=json.loads(run('ffprobe-source',[str(ffbin/'ffprobe.exe'),'-v','error','-select_streams','v:0','-show_entries','frame=best_effort_timestamp_time','-of','json',str(assets/'source.mp4')]))['frames']
independent_pts=[round(float(f['best_effort_timestamp_time'])*1_000_000) for f in frames]
run('native-session',[str(binary),str(out)])
assert not (out/'native-session.stdout.log').read_bytes()
result=json.loads((out/'result.json').read_text(encoding='utf-8'));native=json.loads((out/'native-probe.json').read_text(encoding='utf-8'))
assert native['timestamps']==independent_pts
assert result['actualPtsUs']!=result['targetUs'] and result['actualNativeFfmpeg'] and result['actualInference']
index=independent_pts.index(result['actualPtsUs'])
run('independent-frame',[str(ffbin/'ffmpeg.exe'),'-nostdin','-hide_banner','-loglevel','error','-i',str(assets/'source.mp4'),'-vf',f'select=eq(n\\,{index}),scale=in_color_matrix=bt709:in_range=tv:out_range=pc','-frames:v','1','-pix_fmt','rgb24','-f','rawvideo',str(out/'independent.rgb')])
independent=np.fromfile(out/'independent.rgb',np.uint8).reshape(64,96,3)[5:57,7:87]
independent=np.rot90(independent,k=-1)[:,::-1].copy()
actual_rgb=np.fromfile(out/'input.rgb',np.uint8).reshape(80,52,3)
pixel_error=np.abs(actual_rgb.astype(np.int16)-independent.astype(np.int16))
assert int(pixel_error.max())<=4,('independent FFmpeg RGB differs',int(pixel_error.max()))
Image.fromarray(actual_rgb).save(out/'prepared-source.png')
assert sha(home/'models/depth_anything_v2_vits_518.onnx')=='274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
reference=home/'official-reference'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=reference,text=True).strip()=='a561b849ebae10a6f5ef49e26c83cbbcd36c71bf'
weights=home/'models/depth_anything_v2_vits.pth'
assert sha(weights)=='715fade13be8f229f8a70cc02066f656f2423a59effd0579197bbf57860e1378'
sys.path.insert(0,str(reference))
import cv2,torch
from depth_anything_v2.dpt import DepthAnythingV2
torch.set_num_threads(1);torch.set_num_interop_threads(1)
model=DepthAnythingV2(encoder='vits',features=64,out_channels=[48,96,192,384]).cpu().eval()
model.load_state_dict(torch.load(weights,map_location='cpu',weights_only=True),strict=True)
# Independent letterbox geometry, then official normalization/layout and PyTorch
# execution. Reference unletterboxing uses PyTorch's align_corners interpolation.
width,height=52,80;rw=math.floor(width*518/max(width,height)+0.5);rh=518
x,y=(518-rw)//2,0;boxed=np.zeros((518,518,3),np.uint8)
boxed[y:y+rh,x:x+rw]=cv2.resize(actual_rgb,(rw,rh),interpolation=cv2.INTER_CUBIC)
tensor,_=model.image2tensor(boxed[:,:,::-1].copy(),input_size=518)
with torch.no_grad():
    depth=model(tensor).unsqueeze(1)
    expected=torch.nn.functional.interpolate(depth[:,:,y:y+rh,x:x+rw],size=(height,width),mode='bilinear',align_corners=True)[0,0].numpy()
expected.astype('<f4').tofile(out/'official-reference.f32')
actual=np.fromfile(out/'output.f32','<f4').reshape(height,width)
error=np.abs(actual.astype(np.float64)-expected.astype(np.float64));amp=max(float(np.abs(expected).max()),1e-6)
maximum=float(error.max())/amp;mean=float(error.mean())/amp
assert maximum<=2e-4 and mean<=2e-5,(maximum,mean)
Image.fromarray(np.rint((actual-actual.min())/max(float(np.ptp(actual)),1e-6)*255).astype(np.uint8)).save(out/'relative-depth-visualization.png')
log=(out/'logs/motion-studio.log').read_text(encoding='utf-8');stderr=(out/'native-session.stderr.log').read_text(encoding='utf-8')
assert 'logging initialized level=INFO' in log and 'start #1 depth_infer asset=74' in log
assert log.index('start #1')<log.index('ERROR')
for stream in (log,stderr):
    assert 'ERROR' in stream and 'request=1 operation=depth_infer asset=74' in stream
    assert 'stage=source_prepare' in stream and 'video cache missing' in stream
assert f'phase=source_ready pts={result["actualPtsUs"]}/1000000' in log
assert 'start #1' not in stderr and 'logging initialized' not in stderr
assert before==source() and not subprocess.check_output(['git','status','--porcelain'],cwd=work)
receipt.update(result=result,maxNormalized=maximum,meanNormalized=mean,independentPixelMax=int(pixel_error.max()),
               independentFfprobePts=independent_pts,sourceUnchanged=True,errorFileAndStderr=True,stdoutEmpty=True,
               weightSha256=sha(weights),onnxSha256=sha(home/'models/depth_anything_v2_vits_518.onnx'))
receipt['artifacts']={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()}
(out/'verified.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('source','artifacts','commands')}),flush=True)
