"""Regenerated production-file probe after cleanup; previous failure is retained."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,tomllib
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/reference-depth76'
PROBE=ROOT/'artifacts/pr-queue/depth75-file-probe-resume-source'
OUT=ROOT/'artifacts/pr-queue/depth75-file-probe-resume-v1'
HEAD='5fb253a48b204c0fd52c97669f7c2bf01c401c13'
assert shutil.disk_usage(ROOT).free>=10<<30
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
assert json.loads((ROOT/'artifacts/pr-queue/depth75-resume-transition-native-v1/session-consumed.json').read_text(encoding='utf-8'))['exitCode']==0
old=ROOT/'artifacts/pr-queue/depth75-start-identity-native-v2'
assert json.loads((old/'session-consumed.json').read_text(encoding='utf-8'))['exitCode']==1
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
identity=lambda:{name:sha(WORK/name) for name in names}
before=identity();probe_before={name:sha(PROBE/name) for name in ('Cargo.toml','src/main.rs')}
assert before==json.loads((old/'receipt.json').read_text(encoding='utf-8'))['source']
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
assert not (PROBE/'Cargo.lock').exists()
(PROBE/'Cargo.lock').write_bytes((WORK/'Cargo.lock').read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/colmap88-isolated-check'),
 CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',
 TEMP=str(ROOT/'target/colmap88-isolated-check/tmp'),TMP=str(ROOT/'target/colmap88-isolated-check/tmp'),LOCALAPPDATA=str(OUT/'appdata'))
report=dict(status='running',sourceCommit=HEAD,source=before,probeSource=probe_before,stages=[],startedUtc=datetime.now(timezone.utc).isoformat(),
 limits=['Regenerated fixture has a new identity, not the lost fixture source','Preserve prior failed lock/build and two actual passed native tests',
 'Complete offline metadata resolution before locked build; every third party identity/checksum must match workspace',
 'Actual production sink + actual serial Jobs controlled blocking; no model/quality/full regression proof','Original10GiB admission, one own heavy task, all cache/temp/build on E'])
def save():(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
try:
 for name,cmd in [
  ('metadata',['cargo','metadata','--offline','--filter-platform','x86_64-pc-windows-msvc','--format-version','1','--manifest-path',str(PROBE/'Cargo.toml')]),
  ('build',['cargo','build','--offline','--locked','--manifest-path',str(PROBE/'Cargo.toml')]),
  ('actual-file',[str(ROOT/'target/colmap88-isolated-check/debug/motion-depth75-resumed-file-probe.exe'),str(OUT/'logs')])]:
  row=dict(name=name,command=cmd);report['stages'].append(row);save()
  with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
   child=subprocess.Popen(cmd,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();row['exitCode']=child.wait()
  save();assert row['exitCode']==0,name
  if name=='metadata':
   original=tomllib.loads((WORK/'Cargo.lock').read_text(encoding='utf-8'));resolved=tomllib.loads((PROBE/'Cargo.lock').read_text(encoding='utf-8'))
   known={(p['name'],p['version'],p.get('source')):p.get('checksum') for p in original['package']}
   for p in resolved['package']:
    if p.get('source'):assert known[(p['name'],p['version'],p['source'])]==p.get('checksum')
   report['dependenciesMatchWorkspaceLock']=True;save()
 observed=json.loads((OUT/'actual-file.stdout.log').read_text(encoding='utf-8'))
 assert observed['defaultInfo'] and len(observed['profiles'])==4 and (observed['completed'],observed['failed'])==(3,1)
 stderr=(OUT/'actual-file.stderr.log').read_text(encoding='utf-8')
 assert 'ERROR motion_host::depth:' in stderr and 'controlled blocked rejection' in stderr
 for item in observed['profiles']:
  assert ' INFO ' in item['fileInfoBeforeBackendReturn']
  assert item['processing'] in item['fileInfoBeforeBackendReturn'] and item['modelSha256'] in item['fileInfoBeforeBackendReturn']
 assert ' ERROR ' in observed['profiles'][-1]['errorFileRecord']
 assert 'controlled blocked rejection' in observed['profiles'][-1]['errorFileRecord']
 report.update(status='actual_default_file_before_return_and_error_stderr_stdout_isolation_passed',actual=observed)
except BaseException as error:report.update(status='failed_original_outputs_retained',failure=repr(error))
finally:
 report.update(sourceUnchanged=identity()==before,probeSourceUnchanged={name:sha(PROBE/name) for name in probe_before}==probe_before,completedUtc=datetime.now(timezone.utc).isoformat())
 for name in ('Cargo.toml','Cargo.lock','src/main.rs'):
  p=OUT/'probe-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((PROBE/name).read_bytes())
 save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','actual')}))
raise SystemExit(0 if report['status'].startswith('actual_default_file_before_return') and report['sourceUnchanged'] and report['probeSourceUnchanged'] else 1)
