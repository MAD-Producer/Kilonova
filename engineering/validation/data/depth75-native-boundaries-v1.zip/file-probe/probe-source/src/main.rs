//! Regenerated fixture after cleanup, not the lost fixture's source identity.
//! Uses production logging and real Jobs, without a model or inference runtime.
#[path = "E:/Dev/aem/.worktrees/reference-depth76/desktop/app/src/logging.rs"]
mod logging;
mod engine {
    pub fn current_command() -> Option<(u64, &'static str, std::time::Duration)> {
        None
    }
}
use motion_host::depth::{Backend, Cancellation, Costs, Error, Estimate, Input, Jobs, Key};
use motion_model::depth::{
    DepthDescriptor, DepthGeometry, DepthMeasure, DepthModel, DepthResource, DepthSource,
    DepthTime, NearDirection,
};
use std::{
    fs,
    path::{Path, PathBuf},
    sync::{mpsc, Arc},
    thread,
    time::{Duration, Instant},
};

struct Controlled {
    entered: mpsc::Sender<Key>,
    release: mpsc::Receiver<()>,
}
impl Backend for Controlled {
    fn infer(
        &mut self,
        input: &Input,
        cancellation: &Cancellation,
    ) -> motion_host::depth::Result<Estimate> {
        self.entered
            .send(input.key().clone())
            .map_err(|e| Error::Backend(e.to_string()))?;
        self.release
            .recv_timeout(Duration::from_secs(15))
            .map_err(|e| Error::Backend(e.to_string()))?;
        cancellation.check()?;
        let k = input.key();
        if k.source.asset == 75_750_103 {
            return Err(Error::Backend("controlled blocked rejection".into()));
        }
        Ok(Estimate {
            resource: DepthResource::new(
                DepthDescriptor {
                    size: [2, 1],
                    source: k.source.clone(),
                    geometry: k.geometry.clone(),
                    model: k.model.clone(),
                    measure: DepthMeasure::Relative {
                        near: NearDirection::Increasing,
                    },
                    scale: 1.,
                    offset: 0.,
                    valid_range: None,
                },
                vec![0.25, 2.],
                None,
                None,
            )?,
            provider: "controlled-file-probe".into(),
            costs: Costs::default(),
        })
    }
}
struct Release(mpsc::Sender<()>);
impl Drop for Release {
    fn drop(&mut self) {
        let _ = self.0.send(());
    }
}
fn wait_line(path: &Path, expected: &str) -> String {
    let until = Instant::now() + Duration::from_secs(5);
    loop {
        if let Ok(contents) = fs::read_to_string(path) {
            if let Some(line) = contents.lines().find(|line| line.contains(expected)) {
                return line.to_owned();
            }
        }
        assert!(
            Instant::now() < until,
            "production file record missing: {expected}"
        );
        thread::sleep(Duration::from_millis(10));
    }
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    assert!(std::env::var_os("MOTION_LOG").is_none());
    let dir = PathBuf::from(std::env::args_os().nth(1).ok_or("missing log directory")?);
    assert!(dir.is_absolute() && !dir.exists());
    let _logging = logging::init(dir.clone())?;
    assert_eq!(log::max_level(), log::LevelFilter::Info);
    let file = dir.join("motion-studio.log");
    let (entered, observed) = mpsc::channel();
    let (sender, blocked) = mpsc::channel();
    let mut jobs = Jobs::start(Controlled {
        entered,
        release: blocked,
    })?;
    // Release is dropped before Jobs joins if any fixture assertion unwinds.
    let release = Release(sender);
    let mut results = Vec::new();
    for (index, side) in [266u32, 392, 518, 266].into_iter().enumerate() {
        let processing = format!("dav2-small-rgb8-letterbox{side}-align-corners-relative-v1");
        let hash = [13u8 + index as u8; 32];
        let key = Key {
            source: DepthSource {
                asset: 75_750_100 + index as u64,
                revision: 3,
                pts: DepthTime {
                    ticks: 3,
                    timescale: 24,
                },
            },
            geometry: DepthGeometry {
                source_size: [2, 1],
                crop: [0, 0, 2, 1],
                quarter_turns: 0,
                mirror_x: false,
            },
            model: DepthModel {
                id: "controlled-file-probe".into(),
                revision: "r1".into(),
                sha256: hash,
                processing: processing.clone(),
            },
        };
        let input = Input::new(key.clone(), [2, 1], Arc::from([1u8, 2, 3, 4, 5, 6]))?;
        let request = jobs.request(input)?;
        assert!(observed
            .recv_timeout(Duration::from_secs(5))?
            .same_sample(&key));
        let flight = jobs
            .in_flight()?
            .ok_or("in-flight absent while handler blocked")?;
        assert_eq!(flight.request, request);
        assert_eq!(jobs.queue_depth()?, 0);
        let start = wait_line(&file, &format!("start #{request} depth_infer "));
        let hex: String = hash.iter().map(|byte| format!("{byte:02x}")).collect();
        assert!(
            start.contains(" INFO ")
                && start.contains(&format!("processing={processing} "))
                && start.contains(&format!("model_sha256={hex}"))
        );
        assert!(jobs.in_flight()?.is_some());
        // No explicit logger flush: the start must already be in the actual file.
        release.0.send(())?;
        let until = Instant::now() + Duration::from_secs(5);
        let outcome = loop {
            match jobs.take_ready(&key) {
                Ok(Some(value)) => break Ok(value),
                Err(error) => break Err(error),
                Ok(None) => {
                    assert!(Instant::now() < until, "completion missing");
                    thread::sleep(Duration::from_millis(1));
                }
            }
        };
        let failure = if index == 3 {
            match outcome {
                Err(Error::Backend(cause)) => assert_eq!(cause, "controlled blocked rejection"),
                other => panic!("original cause missing: {other:?}"),
            }
            let line = wait_line(&file, &format!("request={request} operation=depth_infer "));
            assert!(line.contains(" ERROR ") && line.contains("controlled blocked rejection"));
            Some(line)
        } else {
            assert_eq!(outcome?.resource.descriptor().model, key.model);
            None
        };
        assert!(jobs.in_flight()?.is_none());
        assert_eq!(jobs.queue_depth()?, 0);
        results.push(serde_json::json!({"request":request,"processing":processing,"modelSha256":hex,"fileInfoBeforeBackendReturn":start,"errorFileRecord":failure}));
    }
    let counts = jobs.counts()?;
    assert_eq!(
        (counts.completed, counts.failed, counts.canceled),
        (3, 1, 0)
    );
    println!(
        "{}",
        serde_json::json!({"defaultInfo":true,"profiles":results,"completed":counts.completed,"failed":counts.failed,"fixture":"regenerated-after-cleanup"})
    );
    Ok(())
}
