"""Resume exact-source native controls after user cleanup; original gates retained."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, time

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/depth-transition75'
OUT = ROOT / 'artifacts/pr-queue/depth75-resume-transition-native-v1'
HEAD = 'abf5d3512265ee50f6f5689e8b7788283b03b447'
assert shutil.disk_usage(ROOT).free >= 10 << 30
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip() == HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
for directory, code in [('depth75-backend-workspace-v3',1),('depth75-start-identity-native-v2',1)]:
    assert json.loads((ROOT/'artifacts/pr-queue'/directory/'session-consumed.json').read_text(encoding='utf-8'))['exitCode'] == code
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
placement = json.loads((ROOT/'artifacts/pr-queue/depth75-runtime-placement-v1/receipt.json').read_text(encoding='utf-8'))
assert len(placement['placements']) == 14
for row in placement['placements']:
    assert sha(Path(row['path'])) == row['sha256']
names = subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
identity = lambda: {name:sha(WORK/name) for name in names}
source = identity()
env = {k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT/'target/colmap88-isolated-check'),
           CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
           RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'appdata'),TEMP=str(ROOT/'target/colmap88-isolated-check/tmp'),
           TMP=str(ROOT/'target/colmap88-isolated-check/tmp'),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
Path(env['TEMP']).mkdir(parents=True,exist_ok=True)
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
command=['cargo','test','--locked','-p','motion-host','--features','ai-depth',
         '--test','depth_alignment','--test','depth_transition','--test','depth_transition_jobs','--','--test-threads=1']
report=dict(status='running',sourceCommit=HEAD,source=source,command=command,startedUtc=datetime.now(timezone.utc).isoformat(),
            freeBytesBefore=shutil.disk_usage(ROOT).free,limits=['Original10GiB admission and existing features/GPU/ignores/assertions retained',
             'One own native workload; all cache/build/temp on E; cleared dependency cache may be fetched at locked versions',
             'All14 alignment+9 admission+7 actualJobs controls must execute; no test filter/ignore',
             'Does not prove model/video quality, file logs or full-feature workspace regression'])
def save(): (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
try:
    with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        report['pid']=child.pid;save()
        report['exitCode']=child.wait()
    output=(OUT/'stdout.log').read_text(encoding='utf-8',errors='replace')
    summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out',output)
    report['summaries']=summaries;save()
    assert report['exitCode']==0
    assert sorted(tuple(map(int,s)) for s in summaries)==[(7,0,0,0),(9,0,0,0),(14,0,0,0)]
    report['namedPasses']=re.findall(r'^test (\w+) \.\.\. ok$',output,re.M)
    assert len(set(report['namedPasses']))==30
    report['status']='all30_native_controls_passed_file_probe_and_full_regression_pending'
except BaseException as error:
    report.update(status='failed_original_outputs_retained',failure=repr(error))
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=identity()==source,
                  freeBytesAfter=shutil.disk_usage(ROOT).free)
    save()
print(json.dumps({k:v for k,v in report.items() if k not in ('source','namedPasses')}))
raise SystemExit(0 if report['status'].startswith('all30_native_controls_passed') and report['sourceUnchanged'] else 1)
