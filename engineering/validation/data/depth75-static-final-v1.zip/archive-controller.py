"""Retain actual static output without substituting for source/native gates."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/reference-depth76'
source = root / 'artifacts/pr-queue/depth75-static-final-v1'
out = work / 'engineering/validation/data'
receipt = json.loads((source / 'receipt.json').read_text())
assert receipt['status'] == 'static_gates_passed'
assert all(stage['exitCode'] == 0 for stage in receipt['stages'])
assert 'Ran 114 tests' in (source / 'tools.stderr.log').read_text(encoding='utf-8')
assert 'OK (skipped=1)' in (source / 'tools.stderr.log').read_text(encoding='utf-8')
files = {p.name: p for p in source.iterdir() if p.is_file()}
files['archive-controller.py'] = Path(__file__)
archive = out / 'depth75-static-final-v1.zip'
entries = {}
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as target:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        entries[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        target.writestr(name, data)
with zipfile.ZipFile(archive) as target:
    for name, row in entries.items():
        data = target.read(name)
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
manifest = dict(status='static_gates_passed_full_native_regression_pending',
    createdUtc=datetime.now(timezone.utc).isoformat(), archive=archive.name,
    bytes=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    entries=entries, tests=114, passed=113, existingSkipped=1,
    limits=['Original system-Python discovery failed two imports; preserved in receipt, not counted as passing',
            'Existing optional Python supplies already-required PyYAML; TEMP/TMP are explicitly on E',
            'No complete workspace regression or new GPU qualification is claimed'])
(out / 'depth75-static-final-v1.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
print(json.dumps({k:v for k,v in manifest.items() if k!='entries'}))
