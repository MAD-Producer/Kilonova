"""Full existing Python discovery in the installed environment with explicit E temp."""
from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,time
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/reference-depth76'
OUT=ROOT/'artifacts/pr-queue/depth75-static-final-v1';OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
python=ROOT/'.tools/ai-depth74/venv/Scripts/python.exe'
env=os.environ.copy();env.update(TEMP=str(ROOT/'target/colmap88-isolated-check/tmp'),TMP=str(ROOT/'target/colmap88-isolated-check/tmp'),
    PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),python=str(python),temp=env['TEMP'],stages=[],
    precedingAttempt=dict(status='system_python_discovery_failed_imports',observedTests=86,errors=2,existingSkips=1,
        cause='Required PyYAML absent from system Python',temp='System default C temp; ephemeral test contexts have exited',
        evidenceScope='Observed original tool session40547; not a passing execution or a complete retained raw log'),
    limits=['No assertion/skip policy changes; installed optional model environment supplies existing CI PyYAML dependency',
        'No GPU/model inference and no whole-workspace Rust qualification'])
commands=[('tools',[python,'-B','-m','unittest','discover','-s','tools','-p','test_ci_*.py','-v']),
    ('provenance',[python,'-B','tools/validate_provenance.py']),('inventory',[python,'-B','tools/validation_inventory.py']),
    ('style',[python,'-B','-c','import sys;sys.path.insert(0,"tools");import ci_desktop;ci_desktop.verify_style_consumers()']),
    ('diff',['git','diff','--check'])]
for name,command in commands:
    began=time.monotonic()
    with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
        child=subprocess.run(list(map(str,command)),cwd=WORK,env=env,stdout=stdout,stderr=stderr)
    report['stages'].append(dict(name=name,command=list(map(str,command)),exitCode=child.returncode,elapsedSeconds=round(time.monotonic()-began,3)))
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    if child.returncode:break
report.update(status='static_gates_passed' if len(report['stages'])==len(commands) and all(s['exitCode']==0 for s in report['stages']) else 'failed_original_outputs_retained',completedUtc=datetime.now(timezone.utc).isoformat())
(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report));raise SystemExit(0 if report['status']=='static_gates_passed' else 1)
