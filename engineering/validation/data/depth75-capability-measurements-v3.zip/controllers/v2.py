"""Actual native + model qualification; never overlaps the frozen parent run.

Launch only after the parent session has actually been consumed. Merely seeing
a receipt, timeout, or quiet log does not authorize another heavy workload.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib, json, math, os, re, shutil, struct, subprocess, traceback

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-wgsl-cache75'
TARGET = ROOT / 'target/depth-wgsl-cache75-contract'
OUT = BASE / 'depth75-measured-capability-v2'
PARENT = BASE / 'depth75-measured-capability-v1'
parent = json.loads((PARENT/'receipt.json').read_text(encoding='utf-8'))
assert json.loads((PARENT/'session-consumed.json').read_text(encoding='utf-8')) == dict(session=16790, consumed=True, exit_code=1)
assert parent['status'] == 'failed_original_outputs_retained' and parent['source_unchanged']
assert parent['head'] == '26b9156d6294c72b87263a804fc3306ab92b45fc'
assert parent['full_target_coverage'] and len(parent['expected_targets']) == 175
assert parent['totals'] == dict(passed=1628, failed=0, original_ignored=3, filtered=0)
assert len(parent['qualified_named_controls']) == 103
assert [(r['name'],r.get('exit_code')) for r in parent['stages']] == [('changed-crates',0),('actual-product-build',0),('onnx-probe',0),('wgsl-probe',0),('authored-video-encode',0),('onnx-video-probe',1)]
assert b'assets must be inside the assets directory' in (PARENT/'onnx-video-probe.stderr.log').read_bytes()
assert not (PARENT/'onnx-video-probe.stdout.log').read_bytes()
assert shutil.disk_usage(ROOT).free >= 10 << 30
assert not {'RUST_MIN_STACK', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'} & os.environ.keys()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
HEAD = subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert HEAD == '8fdb718b5af88132821d829275fba4962ecdced6'
code = ['crates/motion-host/src/depth/capability.rs','crates/motion-host/src/depth/capability/policy.rs','crates/motion-host/tests/depth_capability.rs']
for name in code:
    expected=subprocess.check_output(['git','show','342e5337:'+name],cwd=WORK)
    assert (WORK/name).read_bytes().replace(b'\r\n',b'\n') == expected.replace(b'\r\n',b'\n')
video_example='crates/motion-desktop-media/examples/depth_video_capability.rs'
assert subprocess.check_output(['git','rev-parse','HEAD:'+video_example],cwd=WORK) == subprocess.check_output(['git','rev-parse','0872afb6:'+video_example],cwd=WORK)
changed=subprocess.check_output(['git','diff','--name-only',parent['head'],HEAD],cwd=WORK,text=True).splitlines()
assert set(n for n in changed if not n.startswith('engineering/validation/')) == set(code+[video_example])
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
paths = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def hashes(): return {p: sha(WORK / p) for p in paths}
env = {k: v for k, v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', TEMP=str(TARGET / 'tmp'), TMP=str(TARGET / 'tmp'), LOCALAPPDATA=str(OUT / 'appdata'), RUST_BACKTRACE='full')
runtime = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
env['PATH'] = str(runtime) + ';' + env['PATH']
report = dict(status='running', head=HEAD, source_sha256=hashes(), stages=[], started_utc=datetime.now(timezone.utc).isoformat(),
              predecessor=dict(head=parent['head'], status=parent['status'], receipt_sha256=sha(PARENT/'receipt.json'), totals=parent['totals'], targets=175, controls=103),
              limits=['Original assertions, GPU/FFmpeg features, ignores and deadlines preserved',
                      'Targeted28-case qualification plus corrected actual video, not a new complete workspace gate',
                      'Earlier static RGB probes and175 targets qualified26b; their failure receipt is retained',
                      'External policy report fixtures are not physical quality, whole-memory or thermal measurements',
                      'No Android, panel edits, subprocess inspection, foreign process stops, cleanup or concurrent own heavy workload'])
def save():
    pending = OUT / 'receipt.pending.json'
    pending.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(pending, OUT / 'receipt.json')
def run(name, command, expected_exit=0):
    assert shutil.disk_usage(ROOT).free >= 10 << 30
    row = dict(name=name, command=[str(x) for x in command], expected_exit=expected_exit)
    report['stages'].append(row); save()
    with (OUT / (name + '.stdout.log')).open('wb') as stdout, (OUT / (name + '.stderr.log')).open('wb') as stderr:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        row['pid'] = child.pid; save(); row['exit_code'] = child.wait()
    save()
    assert row['exit_code'] == expected_exit, (name, 'original failed outputs retained; no retry')
    return row
save()
try:
    report['runtime_colocation'] = parent['runtime_colocation']
    for item in report['runtime_colocation']:
        assert sha(Path(item['path'])) == item['sha256']
    features='motion-host/ai-depth,motion-host/gpu-tests,motion-render/gpu-tests,motion-desktop-media/ai-depth,motion-desktop-media/gpu-tests,motion-desktop-media/ffmpeg'
    run('qualified-policy', ['cargo','test','--locked','--offline','-p','motion-host','-p','motion-render','-p','motion-desktop-media','--features',features,'--test','depth_capability','--','--test-threads=1'])
    stdout=(OUT/'qualified-policy.stdout.log').read_text(encoding='utf-8',errors='replace')
    stderr=(OUT/'qualified-policy.stderr.log').read_text(encoding='utf-8',errors='replace')
    names=re.findall(r'^fn ([a-z_]+)\(\) \{',(WORK/code[-1]).read_text(encoding='utf-8'),re.M)
    assert len(names)==28 and len([n for n in names if n.startswith('capability_policy_')])==13
    for name in names:
        assert len(re.findall(r'^test '+re.escape(name)+r' \.\.\. ok$',stdout,re.M))==1
    summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
    assert summaries==[('ok','28','0','0','0','0')]
    assert "process didn't exit successfully:" not in stderr
    invocations=re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)',stderr,re.M)
    assert len(invocations)==1
    dep_info=Path(invocations[0]).with_suffix('.d').read_bytes()
    assert code[-1] in dep_info.decode('utf-8').replace('\\','/')
    report['policy_validation']=dict(named_passes=names, totals=dict(passed=28,failed=0,ignored=0,filtered=0),executable=invocations[0],dep_info_sha256=hashlib.sha256(dep_info).hexdigest())
    save()
    run('actual-product-build', ['cargo', 'build', '--locked', '--offline', '-p', 'motion-host', '-p', 'motion-desktop', '-p', 'motion-desktop-media', '--example', 'depth_capability', '--example', 'depth_video_capability', '--bin', 'motion-depth-wgsl', '--features', 'motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth'])
    python = ROOT / '.tools/ai-depth74/venv/Scripts/python.exe'
    model = BASE / 'depth75-resolution-models-v1/518/export/depth_anything_v2_vits_518.onnx'
    program = BASE / 'depth75-wgsl-cache-resources-v2/program.json'
    worker = TARGET / 'debug/motion-depth-wgsl.exe'
    driver = TARGET / 'debug/examples/depth_capability.exe'
    rgb = PARENT / 'authored.rgb'
    source_video = PARENT / 'authored-video.mp4'
    video_raw = PARENT / 'authored-video.rgb'
    assert sha(video_raw) == '1e242d9ff3869c00e78870f7f8d447675a760220e5411d1617835eadfbda4811'
    assert sha(source_video) == '01bc6b7d4b0e4deb77a3c02da39a625db97a2afbcb43ab04987f2d685733f18c'
    assert video_raw.stat().st_size == 27648 and source_video.stat().st_size == 3297
    report['actual_inputs']={str(p):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in (python,model,program,worker,driver,rgb,source_video,video_raw)}
    save()
    video_driver = TARGET / 'debug/examples/depth_video_capability.exe'
    report['actual_video_inputs'] = {str(p): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in (video_raw, source_video, video_driver)}; save()
    video_results = {}
    for kind in ('onnx', 'wgsl'):
        root = OUT / (kind + '-video-probe')
        run(kind + '-video-probe', [video_driver, root, kind, python, model, program if kind == 'wgsl' else '-', worker if kind == 'wgsl' else '-', source_video, '0', '2'])
        raw = (OUT / (kind + '-video-probe.stdout.log')).read_text(encoding='utf-8')
        result = json.loads(raw); assert raw.count('\n') == 1
        assert result == json.loads((root / 'measurements.json').read_text())
        assert result['source_sha256'] == list(hashlib.sha256(source_video.read_bytes()).digest())
        assert sha(root/'assets/source.mp4') == sha(source_video)
        assert result['source_bytes'] == source_video.stat().st_size and result['source_registration_ns'] > 0
        measured = result['measured']; rows = measured['samples']; assert len(rows) == 2
        assert measured['asset']['frame_count'] == 3 and measured['cache_hits'] == measured['restored'] == 0
        assert rows[0]['target_us'] < rows[1]['target_us'] and rows[0]['input']['rgb_sha256'] != rows[1]['input']['rgb_sha256']
        logs = (root / 'logs/motion-studio.log').read_text(encoding='utf-8')
        assert 'start depth_video_capability phase=source_probe' in logs
        for index, row in enumerate(rows):
            assert row['request'] == index + 1
            assert row['descriptor']['source']['pts'] == dict(ticks=row['target_us'], timescale=1_000_000)
            assert row['end_us'] > row['target_us'] and row['input']['rgb_size'] == [64,48]
            assert row['worker_total_ns'] >= row['source_prepare_ns'] > 0 and row['source_rgb_bytes'] == 64*48*3
            assert row['worker_total_ns'] >= row['resolve_ns'] > 0 and row['inference_ns'] > 0
            assert row['retained_gpu_buffer_capacity_bytes'] == (None if kind == 'onnx' else 227968156)
            assert f"start #{index+1} depth_infer asset=75 revision=1 target_us={row['target_us']} phase=video_decode" in logs
            assert f"start #{index+1} depth_capability asset=75 phase=backend" in logs
            data = (root / row['depth_file']).read_bytes(); assert len(data) == 64*48*4 and row['depth_values'] == 64*48
            assert row['depth_sha256'] == list(hashlib.sha256(data).digest())
        assert measured['depth_output_bytes'] == 2*64*48*4
        totals = sorted(row['worker_total_ns'] for row in rows)
        assert measured['profile'] == dict(samples=2, fastest_ns=totals[0], median_ns=totals[1], slowest_ns=totals[1], retained_gpu_buffer_capacity_bytes=None if kind == 'onnx' else 227968156)
        video_results[kind] = result
        report['actual_video_measurements'] = video_results; save()
    comparisons = []
    for index, (cpu, gpu) in enumerate(zip(video_results['onnx']['measured']['samples'], video_results['wgsl']['measured']['samples'])):
        assert cpu['input'] == gpu['input'] and cpu['descriptor'] == gpu['descriptor']
        cpu_data = (OUT / 'onnx-video-probe' / cpu['depth_file']).read_bytes()
        gpu_data = (OUT / 'wgsl-video-probe' / gpu['depth_file']).read_bytes()
        a = struct.unpack('<' + 'f'*(64*48), cpu_data); b = struct.unpack('<' + 'f'*(64*48), gpu_data)
        assert all(math.isfinite(x) for x in (*a,*b))
        span = max(a)-min(a); assert span > 1e-6
        errors = [abs(x-y)/span for x,y in zip(a,b)]
        assert max(errors) <= 2e-4 and sum(errors)/len(errors) <= 2e-5
        comparisons.append(dict(index=index, values=len(a), original_maximum_bound=2e-4, original_mean_bound=2e-5, normalized_maximum=max(errors), normalized_mean=sum(errors)/len(errors)))
    report['actual_video_measurements'] = video_results
    report['actual_video_same_model_comparisons'] = comparisons; save()
    corrupt = OUT / 'authored-corrupt.mp4'; corrupt.write_bytes(b'authored invalid video control')
    run('corrupt-video', [video_driver, OUT / 'corrupt-video-probe', 'onnx', python, model, '-', '-', corrupt, '0', '1'], 1)
    assert not (OUT / 'corrupt-video.stdout.log').read_bytes()
    errors = (OUT / 'corrupt-video.stderr.log').read_text(encoding='utf-8')
    logs = (OUT / 'corrupt-video-probe/logs/motion-studio.log').read_text(encoding='utf-8')
    assert 'ERROR' in errors and 'ERROR' in logs and 'operation=depth_video_capability' in errors and 'operation=depth_video_capability' in logs
    assert 'start depth_video_capability phase=source_probe' in logs
    assert not (OUT / 'corrupt-video-probe/measurements.json').exists()
    failure = OUT / 'missing-program'
    run('missing-program', [driver, failure, 'wgsl', python, model, OUT / 'absent-program.json', worker, rgb, '12x8', '1', '1000'], 1)
    assert not (OUT / 'missing-program.stdout.log').read_bytes()
    logs = (failure / 'logs/motion-studio.log').read_text(encoding='utf-8')
    error = (OUT / 'missing-program.stderr.log').read_text(encoding='utf-8')
    assert 'start #1 depth_capability asset=75 phase=capability_resolve' in logs
    assert 'ERROR' in logs and 'ERROR' in error and 'operation=depth_infer' in logs and 'operation=depth_infer' in error
    assert not (failure / 'measurements.json').exists()
    report['status'] = 'targeted_policy_and_corrected_actual_video_probes_passed'
except BaseException as cause:
    report.update(status='failed_original_outputs_retained', cause=repr(cause), traceback=traceback.format_exc())
finally:
    report.update(source_unchanged=hashes() == report['source_sha256'], completed_utc=datetime.now(timezone.utc).isoformat())
    report['logs'] = {p.name: dict(bytes=p.stat().st_size, sha256=sha(p)) for p in OUT.glob('*.log')}; save()
print(json.dumps({k: report.get(k) for k in ('status','head','cause','source_unchanged','completed_utc')}))
raise SystemExit(0 if report['status'] == 'targeted_policy_and_corrected_actual_video_probes_passed' and report['source_unchanged'] else 1)
