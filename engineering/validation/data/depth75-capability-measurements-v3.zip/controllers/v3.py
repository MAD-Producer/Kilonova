"""Actual native + model qualification; never overlaps the frozen parent run.

Launch only after the parent session has actually been consumed. Merely seeing
a receipt, timeout, or quiet log does not authorize another heavy workload.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib, json, math, os, re, shutil, struct, subprocess, traceback

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-wgsl-cache75'
TARGET = ROOT / 'target/depth-wgsl-cache75-contract'
OUT = BASE / 'depth75-measured-capability-v3'
PARENT = BASE/'depth75-measured-capability-v2'
ORIGINAL = BASE/'depth75-measured-capability-v1'
parent=json.loads((PARENT/'receipt.json').read_text(encoding='utf-8'))
assert json.loads((PARENT/'session-consumed.json').read_text()) == dict(session=45901,consumed=True,exit_code=1)
assert parent['status']=='failed_original_outputs_retained' and parent['source_unchanged']
assert parent['policy_validation']['totals']==dict(passed=28,failed=0,ignored=0,filtered=0)
assert [(s['name'],s['exit_code']) for s in parent['stages']]==[('qualified-policy',0),('actual-product-build',0),('onnx-video-probe',1)]
assert b'primaries=Unspecified transfer=Unspecified' in (PARENT/'onnx-video-probe.stderr.log').read_bytes()
assert not (PARENT/'onnx-video-probe.stdout.log').read_bytes()
assert shutil.disk_usage(ROOT).free>=10<<30
assert not {'RUST_MIN_STACK','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'} & os.environ.keys()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert HEAD==parent['head']=='8fdb718b5af88132821d829275fba4962ecdced6'
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
paths = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def hashes(): return {p: sha(WORK / p) for p in paths}
env = {k: v for k, v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', TEMP=str(TARGET / 'tmp'), TMP=str(TARGET / 'tmp'), LOCALAPPDATA=str(OUT / 'appdata'), RUST_BACKTRACE='full')
runtime = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
env['PATH'] = str(runtime) + ';' + env['PATH']
report = dict(status='running', head=HEAD, source_sha256=hashes(), stages=[], started_utc=datetime.now(timezone.utc).isoformat(),
              predecessor=dict(head=parent['head'], status=parent['status'], receipt_sha256=sha(PARENT/'receipt.json'), policy_validation=parent['policy_validation']),
              limits=['Original assertions, GPU/FFmpeg features, ignores and deadlines preserved',
                      'Reuse unchanged28-case native gate and built binaries; only corrected authored-metadata fixture plus actual video/failure controls executed',
                      'Earlier static RGB probes and175 targets qualified26b; their failure receipt is retained',
                      'External policy report fixtures are not physical quality, whole-memory or thermal measurements',
                      'No Android, panel edits, subprocess inspection, foreign process stops, cleanup or concurrent own heavy workload'])
def save():
    pending = OUT / 'receipt.pending.json'
    pending.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(pending, OUT / 'receipt.json')
def run(name, command, expected_exit=0):
    assert shutil.disk_usage(ROOT).free >= 10 << 30
    row = dict(name=name, command=[str(x) for x in command], expected_exit=expected_exit)
    report['stages'].append(row); save()
    with (OUT / (name + '.stdout.log')).open('wb') as stdout, (OUT / (name + '.stderr.log')).open('wb') as stderr:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        row['pid'] = child.pid; save(); row['exit_code'] = child.wait()
    save()
    assert row['exit_code'] == expected_exit, (name, 'original failed outputs retained; no retry')
    return row
save()
try:
    report['runtime_colocation']=parent['runtime_colocation']
    for item in report['runtime_colocation']:
        assert sha(Path(item['path']))==item['sha256']
    for path,record in {**parent['actual_inputs'],**parent['actual_video_inputs']}.items():
        assert sha(Path(path))==record['sha256']
    python = ROOT / '.tools/ai-depth74/venv/Scripts/python.exe'
    model = BASE / 'depth75-resolution-models-v1/518/export/depth_anything_v2_vits_518.onnx'
    program = BASE / 'depth75-wgsl-cache-resources-v2/program.json'
    worker = TARGET / 'debug/motion-depth-wgsl.exe'
    driver = TARGET / 'debug/examples/depth_capability.exe'
    rgb=ORIGINAL/'authored.rgb'
    video_raw=ORIGINAL/'authored-video.rgb'
    original_video=ORIGINAL/'authored-video.mp4'
    assert sha(original_video)=='01bc6b7d4b0e4deb77a3c02da39a625db97a2afbcb43ab04987f2d685733f18c'
    assert sha(video_raw)=='1e242d9ff3869c00e78870f7f8d447675a760220e5411d1617835eadfbda4811'
    source_video=OUT/'authored-video-declared-colour.mp4'
    ffmpeg=runtime/'ffmpeg.exe'; ffprobe=runtime/'ffprobe.exe'
    report['metadata_fixture']=dict(original=str(original_video),original_sha256=sha(original_video),ffmpeg_sha256=sha(ffmpeg),ffprobe_sha256=sha(ffprobe),scope='Authored fixture VUI declarations only; codec payload decoded YUV and exact PTS independently compared; product colour gate unchanged')
    run('declare-authored-colour',[ffmpeg,'-v','error','-nostdin','-n','-i',original_video,'-map','0:v:0','-c:v','copy','-bsf:v','h264_metadata=colour_primaries=1:transfer_characteristics=13:matrix_coefficients=1','-color_primaries','bt709','-color_trc','iec61966-2-1','-colorspace','bt709',source_video])
    decoded=[]
    for name,path in [('original',original_video),('declared',source_video)]:
        run(name+'-frame-md5',[ffmpeg,'-v','error','-nostdin','-i',path,'-map','0:v:0','-an','-c:v','rawvideo','-pix_fmt','yuv420p','-f','framemd5','-'])
        lines=(OUT/(name+'-frame-md5.stdout.log')).read_text().splitlines()
        rows=[line for line in lines if line and not line.startswith('#')]
        assert len(rows)==3
        decoded.append(rows)
        run(name+'-metadata',[ffprobe,'-v','error','-show_entries','stream=color_space,color_transfer,color_primaries,color_range,codec_name:frame=color_space,color_transfer,color_primaries,color_range','-of','json',path])
        meta=json.loads((OUT/(name+'-metadata.stdout.log')).read_text())
        assert len(meta['frames'])==3 and len(meta['streams'])==1
        for entry in meta['frames']+meta['streams']:
            assert entry['color_space']=='bt709' and entry['color_range']=='tv'
            if name=='original':
                assert 'color_primaries' not in entry and 'color_transfer' not in entry
            else:
                assert entry['color_primaries']=='bt709' and entry['color_transfer']=='iec61966-2-1'
    assert decoded[0]==decoded[1], 'Declared metadata must not change any decoded plane or PTS'
    report['metadata_fixture'].update(decoded_yuv_and_pts_identical=True,decoded_frame_rows=decoded[0],declared_sha256=sha(source_video))
    report['actual_inputs']={str(p):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in (python,model,program,worker,driver,rgb,source_video,video_raw)}
    save()
    video_driver = TARGET / 'debug/examples/depth_video_capability.exe'
    report['actual_video_inputs'] = {str(p): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in (video_raw, source_video, video_driver)}; save()
    video_results = {}
    for kind in ('onnx', 'wgsl'):
        root = OUT / (kind + '-video-probe')
        run(kind + '-video-probe', [video_driver, root, kind, python, model, program if kind == 'wgsl' else '-', worker if kind == 'wgsl' else '-', source_video, '0', '2'])
        raw = (OUT / (kind + '-video-probe.stdout.log')).read_text(encoding='utf-8')
        result = json.loads(raw); assert raw.count('\n') == 1
        assert result == json.loads((root / 'measurements.json').read_text())
        assert result['source_sha256'] == list(hashlib.sha256(source_video.read_bytes()).digest())
        assert sha(root/'assets/source.mp4') == sha(source_video)
        assert result['source_bytes'] == source_video.stat().st_size and result['source_registration_ns'] > 0
        measured = result['measured']; rows = measured['samples']; assert len(rows) == 2
        assert measured['asset']['frame_count'] == 3 and measured['cache_hits'] == measured['restored'] == 0
        assert rows[0]['target_us'] < rows[1]['target_us'] and rows[0]['input']['rgb_sha256'] != rows[1]['input']['rgb_sha256']
        logs = (root / 'logs/motion-studio.log').read_text(encoding='utf-8')
        assert 'start depth_video_capability phase=source_probe' in logs
        for index, row in enumerate(rows):
            assert row['request'] == index + 1
            assert row['descriptor']['source']['pts'] == dict(ticks=row['target_us'], timescale=1_000_000)
            assert row['end_us'] > row['target_us'] and row['input']['rgb_size'] == [64,48]
            assert row['worker_total_ns'] >= row['source_prepare_ns'] > 0 and row['source_rgb_bytes'] == 64*48*3
            assert row['worker_total_ns'] >= row['resolve_ns'] > 0 and row['inference_ns'] > 0
            assert row['retained_gpu_buffer_capacity_bytes'] == (None if kind == 'onnx' else 227968156)
            assert f"start #{index+1} depth_infer asset=75 revision=1 target_us={row['target_us']} phase=video_decode" in logs
            assert f"start #{index+1} depth_capability asset=75 phase=backend" in logs
            data = (root / row['depth_file']).read_bytes(); assert len(data) == 64*48*4 and row['depth_values'] == 64*48
            assert row['depth_sha256'] == list(hashlib.sha256(data).digest())
        assert measured['depth_output_bytes'] == 2*64*48*4
        totals = sorted(row['worker_total_ns'] for row in rows)
        assert measured['profile'] == dict(samples=2, fastest_ns=totals[0], median_ns=totals[1], slowest_ns=totals[1], retained_gpu_buffer_capacity_bytes=None if kind == 'onnx' else 227968156)
        video_results[kind] = result
        report['actual_video_measurements'] = video_results; save()
    comparisons = []
    for index, (cpu, gpu) in enumerate(zip(video_results['onnx']['measured']['samples'], video_results['wgsl']['measured']['samples'])):
        assert cpu['input'] == gpu['input'] and cpu['descriptor'] == gpu['descriptor']
        cpu_data = (OUT / 'onnx-video-probe' / cpu['depth_file']).read_bytes()
        gpu_data = (OUT / 'wgsl-video-probe' / gpu['depth_file']).read_bytes()
        a = struct.unpack('<' + 'f'*(64*48), cpu_data); b = struct.unpack('<' + 'f'*(64*48), gpu_data)
        assert all(math.isfinite(x) for x in (*a,*b))
        span = max(a)-min(a); assert span > 1e-6
        errors = [abs(x-y)/span for x,y in zip(a,b)]
        assert max(errors) <= 2e-4 and sum(errors)/len(errors) <= 2e-5
        comparisons.append(dict(index=index, values=len(a), original_maximum_bound=2e-4, original_mean_bound=2e-5, normalized_maximum=max(errors), normalized_mean=sum(errors)/len(errors)))
    report['actual_video_measurements'] = video_results
    report['actual_video_same_model_comparisons'] = comparisons; save()
    corrupt = OUT / 'authored-corrupt.mp4'; corrupt.write_bytes(b'authored invalid video control')
    run('corrupt-video', [video_driver, OUT / 'corrupt-video-probe', 'onnx', python, model, '-', '-', corrupt, '0', '1'], 1)
    assert not (OUT / 'corrupt-video.stdout.log').read_bytes()
    errors = (OUT / 'corrupt-video.stderr.log').read_text(encoding='utf-8')
    logs = (OUT / 'corrupt-video-probe/logs/motion-studio.log').read_text(encoding='utf-8')
    assert 'ERROR' in errors and 'ERROR' in logs and 'operation=depth_video_capability' in errors and 'operation=depth_video_capability' in logs
    assert 'start depth_video_capability phase=source_probe' in logs
    assert not (OUT / 'corrupt-video-probe/measurements.json').exists()
    failure = OUT / 'missing-program'
    run('missing-program', [driver, failure, 'wgsl', python, model, OUT / 'absent-program.json', worker, rgb, '12x8', '1', '1000'], 1)
    assert not (OUT / 'missing-program.stdout.log').read_bytes()
    logs = (failure / 'logs/motion-studio.log').read_text(encoding='utf-8')
    error = (OUT / 'missing-program.stderr.log').read_text(encoding='utf-8')
    assert 'start #1 depth_capability asset=75 phase=capability_resolve' in logs
    assert 'ERROR' in logs and 'ERROR' in error and 'operation=depth_infer' in logs and 'operation=depth_infer' in error
    assert not (failure / 'measurements.json').exists()
    run('undeclared-colour-video',[video_driver,OUT/'undeclared-colour-probe','onnx',python,model,'-','-',original_video,'0','1'],1)
    assert not (OUT/'undeclared-colour-video.stdout.log').read_bytes()
    logs=(OUT/'undeclared-colour-probe/logs/motion-studio.log').read_text()
    error=(OUT/'undeclared-colour-video.stderr.log').read_text()
    for text in (logs,error):
        assert 'ERROR' in text and 'primaries=Unspecified transfer=Unspecified' in text
    assert 'start #1 depth_infer asset=75 revision=1 target_us=0 phase=video_decode' in logs
    assert not (OUT/'undeclared-colour-probe/measurements.json').exists()
    report['status'] = 'corrected_authored_metadata_and_actual_video_probes_passed'
except BaseException as cause:
    report.update(status='failed_original_outputs_retained', cause=repr(cause), traceback=traceback.format_exc())
finally:
    report.update(source_unchanged=hashes() == report['source_sha256'], completed_utc=datetime.now(timezone.utc).isoformat())
    report['logs'] = {p.name: dict(bytes=p.stat().st_size, sha256=sha(p)) for p in OUT.glob('*.log')}; save()
print(json.dumps({k: report.get(k) for k in ('status','head','cause','source_unchanged','completed_utc')}))
raise SystemExit(0 if report['status'] == 'corrected_authored_metadata_and_actual_video_probes_passed' and report['source_unchanged'] else 1)
