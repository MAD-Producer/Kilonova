"""Archive original terminal capability evidence; never execute an inference."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import math
import re
import struct
import zipfile

BASE = Path('E:/Dev/aem/artifacts/pr-queue')
SOURCE = BASE / 'depth75-measured-capability-v1'
OUT = BASE / 'depth75-measured-capability-public-v3'
HEAD = '26b9156d6294c72b87263a804fc3306ab92b45fc'


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


result = read_json(SOURCE / 'receipt.json')
assert result['status'] == 'failed_original_outputs_retained'
assert result['head'] == HEAD and result['source_unchanged']
assert read_json(SOURCE / 'session-consumed.json') == dict(session=16790, consumed=True, exit_code=1)
assert result['full_target_coverage']
assert Counter(result['expected_targets']) == Counter(result['observed_targets'])
stdout = (SOURCE / 'changed-crates.stdout.log').read_text(encoding='utf-8')
stderr = (SOURCE / 'changed-crates.stderr.log').read_text(encoding='utf-8')
summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', stdout, re.M)
assert len(summaries) == len(result['expected_targets'])
totals = dict(passed=sum(int(s[1]) for s in summaries), failed=sum(int(s[2]) for s in summaries), original_ignored=sum(int(s[3]) for s in summaries), filtered=sum(int(s[5]) for s in summaries))
assert totals == result['totals'] and not totals['failed'] and not totals['filtered']
assert all(s[0] == 'ok' for s in summaries) and "process didn't exit successfully:" not in stderr
names = result['qualified_named_controls']
assert len(names) == len(set(names)) == 103
for name in names:
    assert len(re.findall(r'^test ' + re.escape(name) + r' \.\.\. ok$', stdout, re.M)) == 1

assert len(summaries)==175 and totals==dict(passed=1628,failed=0,original_ignored=3,filtered=0)
assert [(s['name'],s['exit_code']) for s in result['stages']]==[('changed-crates',0),('actual-product-build',0),('onnx-probe',0),('wgsl-probe',0),('authored-video-encode',0),('onnx-video-probe',1)]
assert not (SOURCE/'onnx-video-probe.stdout.log').read_bytes()
assert 'assets must be inside the assets directory' in (SOURCE/'onnx-video-probe.stderr.log').read_text()
original_result=result
for kind in ('onnx', 'wgsl'):
    root = SOURCE / (kind + '-probe')
    raw = (SOURCE / (kind + '-probe.stdout.log')).read_text(encoding='utf-8')
    value = json.loads(raw)
    assert raw.count('\n') == 1 and value == read_json(root / 'measurements.json') == result[kind + '_measurements']
    samples = value['samples']
    assert len(samples) == 2 and value['cache_hits'] == value['restored'] == 0
    assert all(s['worker_total_ns'] >= s['resolve_ns'] > 0 and s['inference_ns'] > 0 for s in samples)
    capacity = None if kind == 'onnx' else 227968156
    assert all(s['retained_gpu_buffer_capacity_bytes'] == capacity for s in samples)
    times = sorted(s['worker_total_ns'] for s in samples)
    assert value['profile'] == dict(samples=2, fastest_ns=times[0], median_ns=times[1], slowest_ns=times[1], resolve_slowest_ns=max(s['resolve_ns'] for s in samples), retained_gpu_buffer_capacity_bytes=capacity)
    decision = value['latency_selection']
    assert decision['requested']['maximum_worker_latency_ns'] == 1_000_000_000
    assert decision['requested']['minimum_samples'] == 2
    eligible = times[1] <= 1_000_000_000
    assert decision['candidate_admission'] == ('eligible' if eligible else 'over_latency_budget')
    assert decision['disposition'] == ('selected' if eligible else 'precomputed_required')
    assert (decision['resolved'] is not None) == eligible
    log = (root / 'logs/motion-studio.log').read_text(encoding='utf-8')
    for request in (1, 2):
        for phase in ('capability_resolve', 'backend'):
            assert f'start #{request} depth_capability asset=75 phase={phase}' in log

SECOND=BASE/'depth75-measured-capability-v2'
second=read_json(SECOND/'receipt.json')
assert read_json(SECOND/'session-consumed.json')==dict(session=45901,consumed=True,exit_code=1)
assert second['status']=='failed_original_outputs_retained' and second['source_unchanged']
assert second['policy_validation']['totals']==dict(passed=28,failed=0,ignored=0,filtered=0)
assert [(s['name'],s['exit_code']) for s in second['stages']]==[('qualified-policy',0),('actual-product-build',0),('onnx-video-probe',1)]
stdout=(SECOND/'qualified-policy.stdout.log').read_text()
assert re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)==[('ok','28','0','0','0','0')]
assert len(second['policy_validation']['named_passes'])==28
for name in second['policy_validation']['named_passes']:
    assert len(re.findall(r'^test '+re.escape(name)+r' \.\.\. ok$',stdout,re.M))==1
assert 'primaries=Unspecified transfer=Unspecified' in (SECOND/'onnx-video-probe.stderr.log').read_text()
assert not (SECOND/'onnx-video-probe.stdout.log').read_bytes()
FIRST=SOURCE
SOURCE=BASE/'depth75-measured-capability-v3'
result=read_json(SOURCE/'receipt.json')
consumed=read_json(SOURCE/'session-consumed.json')
assert consumed['consumed'] and consumed['exit_code']==0
assert result['status']=='corrected_authored_metadata_and_actual_video_probes_passed' and result['source_unchanged']
assert result['head']==second['head']=='8fdb718b5af88132821d829275fba4962ecdced6'
assert [(s['name'],s['exit_code']) for s in result['stages']]==[('declare-authored-colour',0),('original-frame-md5',0),('original-metadata',0),('declared-frame-md5',0),('declared-metadata',0),('onnx-video-probe',0),('wgsl-video-probe',0),('corrupt-video',1),('missing-program',1),('undeclared-colour-video',1)]
for name in ('original','declared'):
    rows=[s for s in (SOURCE/(name+'-frame-md5.stdout.log')).read_text().splitlines() if s and not s.startswith('#')]
    assert rows==result['metadata_fixture']['decoded_frame_rows'] and len(rows)==3
    meta=json.loads((SOURCE/(name+'-metadata.stdout.log')).read_text())
    assert len(meta['frames'])==3 and len(meta['streams'])==1
    for item in meta['frames']+meta['streams']:
        assert item['color_space']=='bt709' and item['color_range']=='tv'
        if name=='original':
            assert 'color_primaries' not in item and 'color_transfer' not in item
        else:
            assert item['color_primaries']=='bt709' and item['color_transfer']=='iec61966-2-1'
assert result['metadata_fixture']['decoded_yuv_and_pts_identical']
video = result['actual_video_measurements']
comparisons = []
for kind, value in video.items():
    assert kind in ('onnx', 'wgsl')
    root = SOURCE / (kind + '-video-probe')
    raw = (SOURCE / (kind + '-video-probe.stdout.log')).read_text(encoding='utf-8')
    assert raw.count('\n') == 1 and json.loads(raw) == value == read_json(root / 'measurements.json')
    assert digest((root / 'assets/source.mp4').read_bytes()) == bytes(value['source_sha256']).hex()
    assert (root / 'assets/source.mp4').read_bytes() == (SOURCE / 'authored-video-declared-colour.mp4').read_bytes()
    assert value['measured']['cache_hits'] == value['measured']['restored'] == 0
    assert value['measured']['asset']['frame_count'] == 3
    rows = value['measured']['samples']
    assert len(rows) == 2 and rows[0]['target_us'] < rows[1]['target_us']
    assert rows[0]['input']['rgb_sha256'] != rows[1]['input']['rgb_sha256']
    for index, row in enumerate(rows):
        data = (root / row['depth_file']).read_bytes()
        assert len(data) == 64 * 48 * 4 and row['depth_values'] == 64 * 48
        assert digest(data) == bytes(row['depth_sha256']).hex()
        assert row['worker_total_ns'] >= row['source_prepare_ns'] > 0
        assert row['worker_total_ns'] >= row['resolve_ns'] > 0
        assert row['request'] == index + 1 and row['end_us'] > row['target_us']
        assert row['descriptor']['source']['pts'] == dict(ticks=row['target_us'], timescale=1_000_000)
for index, (cpu, gpu) in enumerate(zip(video['onnx']['measured']['samples'], video['wgsl']['measured']['samples'])):
    assert cpu['input'] == gpu['input'] and cpu['descriptor'] == gpu['descriptor']
    a = struct.unpack('<3072f', (SOURCE / 'onnx-video-probe' / cpu['depth_file']).read_bytes())
    b = struct.unpack('<3072f', (SOURCE / 'wgsl-video-probe' / gpu['depth_file']).read_bytes())
    assert all(math.isfinite(x) for x in (*a, *b))
    span = max(a) - min(a)
    assert span > 1e-6
    errors = [abs(x-y) / span for x, y in zip(a, b)]
    assert max(errors) <= 2e-4 and sum(errors) / len(errors) <= 2e-5
    comparisons.append(dict(index=index, values=len(a), original_maximum_bound=2e-4, original_mean_bound=2e-5, normalized_maximum=max(errors), normalized_mean=sum(errors)/len(errors)))
assert comparisons == result['actual_video_same_model_comparisons']

for stage, root in [('corrupt-video', 'corrupt-video-probe'), ('missing-program', 'missing-program')]:
    assert not (SOURCE / (stage + '.stdout.log')).read_bytes()
    log = (SOURCE / root / 'logs/motion-studio.log').read_text(encoding='utf-8')
    error = (SOURCE / (stage + '.stderr.log')).read_text(encoding='utf-8')
    assert 'ERROR' in error and 'ERROR' in log
    assert not (SOURCE / root / 'measurements.json').exists()

assert not (SOURCE/'undeclared-colour-video.stdout.log').read_bytes()
for path in (SOURCE/'undeclared-colour-video.stderr.log',SOURCE/'undeclared-colour-probe/logs/motion-studio.log'):
    text=path.read_text();assert 'ERROR' in text and 'primaries=Unspecified transfer=Unspecified' in text
assert not (SOURCE/'undeclared-colour-probe/measurements.json').exists()
files={}
def put(path,name):
    raw=path.read_bytes()
    assert path.suffix in ('.json','.log','.py') and len(raw)<=4<<20
    assert name not in files and '..' not in Path(name).parts
    files[name]=raw
for tag,folder,value in [('v1',FIRST,original_result),('v2',SECOND,second),('v3',SOURCE,result)]:
    for name,recorded in value['logs'].items():
        raw=(folder/name).read_bytes()
        assert len(raw)==recorded['bytes'] and digest(raw)==recorded['sha256']
        put(folder/name,tag+'/'+name)
    for name in ('receipt.json','session-consumed.json'):
        put(folder/name,tag+'/'+name)
    if (folder/'controller.py').exists():put(folder/'controller.py','controllers/'+tag+'.py')
    else:put(BASE/('depth75-measured-capability-'+tag+'-controller.py'),'controllers/'+tag+'.py')
    for root in ('onnx-probe','wgsl-probe','onnx-video-probe','wgsl-video-probe','corrupt-video-probe','missing-program','undeclared-colour-probe'):
        for name in ('logs/motion-studio.log','measurements.json'):
            path=folder/root/name
            if path.exists():put(path,tag+'/'+root+'/'+name)
put(FIRST/'cargo-metadata.json','v1/cargo-metadata.json')
put(Path(__file__),'controllers/archive.py')
limits=['Original v1/v2 controllers remain failed; only their completed stages are qualified',
    '175 target1628 pass scope is26b;28 target controls and real video scope is8fdb; no new full-workspace claim',
    'Two actual uncached observations per CPU/WGSL backend; no warm/cold trimming or altered numeric bounds',
    'Authored source declares intended BT709/sRGB explicitly; decoded YUV and exact PTS unchanged, original undeclared source still rejected',
    'CPU/WGSL equivalence is not independent photographic quality, whole-memory, sustained/thermal or transition acceptance',
    'Policy external-report controls are explicit fixtures, not real device qualifications',
    'Bounded text only; no video, RGB, tensors, weights, plans or executable binaries redistributed',
    'No Android, panels, foreign PR review, cleanup, debugger, process stops or overlapping own heavy workload']
manifest=dict(version=3,status=result['status'],heads=dict(original_regression=HEAD,targeted_policy_video=result['head']),
    original_statuses=dict(v1=original_result['status'],v2=second['status'],v3=result['status']),
    native_targets=175,native_totals=totals,native_controls=103,policy_totals=second['policy_validation']['totals'],
    independently_recomputed_video_comparisons=comparisons,metadata_fixture=result['metadata_fixture'],limits=limits,
    members={name:dict(bytes=len(raw),sha256=digest(raw)) for name,raw in files.items()})
OUT.mkdir(exist_ok=False)
archive=OUT/'depth75-capability-measurements-v3.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in files.items():z.writestr(name,raw)
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(files)|{'manifest.json'}
    for name,raw in files.items():assert z.read(name)==raw
    assert json.loads(z.read('manifest.json'))==manifest
receipt=dict(status=result['status'],archive=archive.name,bytes=archive.stat().st_size,sha256=digest(archive.read_bytes()),
    members_readback_verified=len(files)+1,heads=manifest['heads'],original_statuses=manifest['original_statuses'],
    native_targets=175,native_totals=totals,native_controls=103,policy_totals=manifest['policy_totals'],
    independently_recomputed_video_comparisons=comparisons,metadata_fixture=manifest['metadata_fixture'],limits=limits)
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
