"""Actual native + model qualification; never overlaps the frozen parent run.

Launch only after the parent session has actually been consumed. Merely seeing
a receipt, timeout, or quiet log does not authorize another heavy workload.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib, json, math, os, re, shutil, struct, subprocess, traceback

ROOT = Path('E:/Dev/aem')
BASE = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-wgsl-cache75'
TARGET = ROOT / 'target/depth-wgsl-cache75-contract'
OUT = BASE / 'depth75-measured-capability-v1'
PARENT = BASE / 'depth75-wgsl-maintained-workspace-v1'
parent = json.loads((PARENT / 'receipt.json').read_text(encoding='utf-8'))
consumed = json.loads((PARENT / 'session-consumed.json').read_text(encoding='utf-8'))
assert consumed['consumed'] and consumed['exit_code'] == 0 and consumed['session'] == 27030
assert parent['status'] == 'complete_maintained_workspace_desktop_gpu_ffmpeg_passed' and parent['source_unchanged']
assert shutil.disk_usage(ROOT).free >= 10 << 30
assert not {'RUST_MIN_STACK', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'} & os.environ.keys()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
HEAD = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert HEAD == '26b9156d6294c72b87263a804fc3306ab92b45fc'
OUT.mkdir(exist_ok=False)
paths = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def hashes(): return {p: sha(WORK / p) for p in paths}
env = {k: v for k, v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', TEMP=str(TARGET / 'tmp'), TMP=str(TARGET / 'tmp'), LOCALAPPDATA=str(OUT / 'appdata'), RUST_BACKTRACE='full')
runtime = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
env['PATH'] = str(runtime) + ';' + env['PATH']
report = dict(status='running', head=HEAD, source_sha256=hashes(), stages=[], started_utc=datetime.now(timezone.utc).isoformat(),
              limits=['Original assertions, GPU/FFmpeg features, ignores and deadlines preserved',
                      'Actual prepared-RGB probes are not quality, memory peak, whole-media, warm-session or thermal qualification',
                      'No Android, panel edits, subprocess inspection, foreign process stops, cleanup or concurrent own heavy workload'])
def save():
    pending = OUT / 'receipt.pending.json'
    pending.write_text(json.dumps(report, indent=2), encoding='utf-8')
    os.replace(pending, OUT / 'receipt.json')
def run(name, command, expected_exit=0):
    assert shutil.disk_usage(ROOT).free >= 10 << 30
    row = dict(name=name, command=[str(x) for x in command], expected_exit=expected_exit)
    report['stages'].append(row); save()
    with (OUT / (name + '.stdout.log')).open('wb') as stdout, (OUT / (name + '.stderr.log')).open('wb') as stderr:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        row['pid'] = child.pid; save(); row['exit_code'] = child.wait()
    save()
    assert row['exit_code'] == expected_exit, (name, 'original failed outputs retained; no retry')
    return row
save()
try:
    expected_dlls = {Path(p['source']).name: p['sha256'] for p in parent['validation_runtime']}
    report['runtime_colocation'] = []
    for name, digest in expected_dlls.items():
        origin = runtime / name; assert sha(origin) == digest
        for folder in ('debug', 'debug/deps', 'debug/examples'):
            destination = TARGET / folder / name; destination.parent.mkdir(parents=True, exist_ok=True)
            if destination.exists(): assert sha(destination) == digest
            else: shutil.copy2(origin, destination)
            assert sha(destination) == digest
            report['runtime_colocation'].append(dict(path=str(destination), sha256=digest))
    save()
    metadata_raw = subprocess.check_output(['cargo', 'metadata', '--locked', '--offline', '--no-deps', '--format-version', '1'], cwd=WORK, env=env)
    (OUT / 'cargo-metadata.json').write_bytes(metadata_raw); metadata = json.loads(metadata_raw)
    features = 'motion-host/ai-depth,motion-host/gpu-tests,motion-render/gpu-tests,motion-desktop-media/ai-depth,motion-desktop-media/gpu-tests,motion-desktop-media/ffmpeg'
    run('changed-crates', ['cargo', 'test', '--locked', '--offline', '-p', 'motion-host', '-p', 'motion-render', '-p', 'motion-desktop-media', '--features', features, '--no-fail-fast', '--', '--test-threads=1'])
    stdout = (OUT / 'changed-crates.stdout.log').read_text(encoding='utf-8', errors='replace')
    stderr = (OUT / 'changed-crates.stderr.log').read_text(encoding='utf-8', errors='replace')
    expected, by_name, docs = [], {}, {}
    for package in metadata['packages']:
        if package['name'] not in ('motion-host', 'motion-render', 'motion-desktop-media'): continue
        for target in package['targets']:
            if not target['test']: continue
            relative = Path(target['src_path']).relative_to(WORK).as_posix()
            key = package['name'] + '::' + target['kind'][0] + '::' + relative
            expected.append(key); by_name.setdefault(target['name'].replace('-', '_'), []).append((relative, key))
        if any(t['doctest'] for t in package['targets']):
            key = 'doc::' + package['name']; expected.append(key); docs[package['name'].replace('-', '_')] = key
    observed = []; bindings = []
    for executable in re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)', stderr, re.M):
        path = Path(executable); raw = path.with_suffix('.d').read_bytes()
        dependencies = raw.decode('utf-8').splitlines()[0].split(': ', 1)[1].replace('\\', '/')
        name = re.sub(r'-[a-f0-9]+$', '', path.stem)
        owners = [key for relative, key in by_name[name] if re.search(r'(?<!\S)' + re.escape(relative) + r'(?!\S)', dependencies)]
        assert len(owners) == 1, (executable, owners)
        observed.extend(owners); bindings.append(dict(executable=executable, target=owners[0], dep_info_sha256=hashlib.sha256(raw).hexdigest()))
    observed.extend(docs[n] for n in re.findall(r'^\s*Doc-tests (\S+)\s*$', stderr, re.M))
    summaries = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', stdout, re.M)
    new_names = re.findall(r'^fn ([a-z_]+)\(\) \{', (WORK / 'crates/motion-host/tests/depth_capability.rs').read_text(), re.M)
    # Fifteen integration controls plus the concrete WGSL cancellation control.
    assert len(new_names) == 15
    new_names += ['depth::wgsl::tests::retained_capacity_is_key_bound_and_cleared_before_cancelled_work']
    video_names = re.findall(r'^fn (measured_original_video_[a-z_]+)\(\) \{', (WORK / 'crates/motion-host/tests/depth_video.rs').read_text(), re.M)
    assert len(video_names) == 3
    new_names += video_names
    named = parent['expected_named_controls'] + new_names
    assert all(len(re.findall(r'(?m)^test ' + re.escape(n) + r' \.\.\. ok$', stdout)) == 1 for n in named)
    report.update(expected_targets=expected, source_bound_invocations=bindings, observed_targets=observed,
                  full_target_coverage=Counter(expected) == Counter(observed) and len(summaries) == len(observed),
                  totals=dict(passed=sum(int(s[1]) for s in summaries), failed=sum(int(s[2]) for s in summaries), original_ignored=sum(int(s[3]) for s in summaries), filtered=sum(int(s[5]) for s in summaries)),
                  qualified_named_controls=named)
    assert report['full_target_coverage'] and not report['totals']['failed'] and not report['totals']['filtered']
    assert "process didn't exit successfully:" not in stderr
    run('actual-product-build', ['cargo', 'build', '--locked', '--offline', '-p', 'motion-host', '-p', 'motion-desktop', '-p', 'motion-desktop-media', '--example', 'depth_capability', '--example', 'depth_video_capability', '--bin', 'motion-depth-wgsl', '--features', 'motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth'])
    python = ROOT / '.tools/ai-depth74/venv/Scripts/python.exe'
    model = BASE / 'depth75-resolution-models-v1/518/export/depth_anything_v2_vits_518.onnx'
    program = BASE / 'depth75-wgsl-cache-resources-v2/program.json'
    worker = TARGET / 'debug/motion-depth-wgsl.exe'
    driver = TARGET / 'debug/examples/depth_capability.exe'
    rgb = OUT / 'authored.rgb'; rgb.write_bytes(bytes((n * 31 + n // 36) % 256 for n in range(288)))
    report['actual_inputs'] = {str(p): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in (python, model, program, worker, driver, rgb)}; save()
    for kind in ('onnx', 'wgsl'):
        root = OUT / (kind + '-probe')
        run(kind + '-probe', [driver, root, kind, python, model, program if kind == 'wgsl' else '-', worker if kind == 'wgsl' else '-', rgb, '12x8', '2', '1000'])
        raw = (OUT / (kind + '-probe.stdout.log')).read_text(encoding='utf-8')
        value = json.loads(raw); assert raw.count('\n') == 1 and len(value['samples']) == 2
        assert json.loads((root / 'measurements.json').read_text()) == value
        assert not value['cache_hits'] and not value['restored']
        logs = (root / 'logs/motion-studio.log').read_text(encoding='utf-8')
        for request in (1, 2):
            assert f'start #{request} depth_capability asset=75 phase=capability_resolve' in logs
            assert f'start #{request} depth_capability asset=75 phase=backend' in logs
        assert all(s['worker_total_ns'] >= s['resolve_ns'] > 0 and s['inference_ns'] > 0 for s in value['samples'])
        totals = sorted(s['worker_total_ns'] for s in value['samples'])
        capacity = None if kind == 'onnx' else 227968156
        assert all(s['retained_gpu_buffer_capacity_bytes'] == capacity for s in value['samples'])
        assert value['profile'] == dict(samples=2, fastest_ns=totals[0], median_ns=totals[1], slowest_ns=totals[1], resolve_slowest_ns=max(s['resolve_ns'] for s in value['samples']), retained_gpu_buffer_capacity_bytes=capacity)
        decision = value['latency_selection']
        assert decision['requested'] == dict(model=value['key']['model'], geometry=value['key']['geometry'], backend=value['samples'][0]['execution']['backend'], maximum_worker_latency_ns=1_000_000_000, minimum_samples=2)
        eligible = totals[-1] <= 1_000_000_000
        assert decision['candidate_admission'] == ('eligible' if eligible else 'over_latency_budget')
        assert decision['disposition'] == ('selected' if eligible else 'precomputed_required')
        if eligible:
            assert decision['resolved'] == dict(model=value['key']['model'], execution=value['samples'][0]['execution'], samples=2, slowest_ns=totals[-1])
        else:
            assert decision['resolved'] is None
        report[kind + '_measurements'] = value; save()
    # An authored moving-color H.264 source qualifies actual codec execution,
    # not photographed-video quality or a new temporal-accuracy threshold.
    video_raw = OUT / 'authored-video.rgb'
    video_raw.write_bytes(bytes((x * 5 + y * 7 + frame * 31 + channel * 17) % 256 for frame in range(3) for y in range(48) for x in range(64) for channel in range(3)))
    source_video = OUT / 'authored-video.mp4'
    ffmpeg = runtime / 'ffmpeg.exe'
    report['video_encoder'] = dict(path=str(ffmpeg), sha256=sha(ffmpeg)); save()
    run('authored-video-encode', [ffmpeg, '-v', 'error', '-nostdin', '-n', '-f', 'rawvideo', '-pixel_format', 'rgb24', '-video_size', '64x48', '-framerate', '30', '-i', video_raw, '-frames:v', '3', '-an', '-c:v', 'libopenh264', '-vf', 'scale=in_range=full:out_range=tv:out_color_matrix=bt709', '-pix_fmt', 'yuv420p', '-color_primaries', 'bt709', '-color_trc', 'iec61966-2-1', '-colorspace', 'bt709', '-color_range', 'tv', source_video])
    video_driver = TARGET / 'debug/examples/depth_video_capability.exe'
    report['actual_video_inputs'] = {str(p): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in (video_raw, source_video, video_driver)}; save()
    video_results = {}
    for kind in ('onnx', 'wgsl'):
        root = OUT / (kind + '-video-probe')
        run(kind + '-video-probe', [video_driver, root, kind, python, model, program if kind == 'wgsl' else '-', worker if kind == 'wgsl' else '-', source_video, '0', '2'])
        raw = (OUT / (kind + '-video-probe.stdout.log')).read_text(encoding='utf-8')
        result = json.loads(raw); assert raw.count('\n') == 1
        assert result == json.loads((root / 'measurements.json').read_text())
        assert result['source_sha256'] == list(hashlib.sha256(source_video.read_bytes()).digest())
        assert result['source_bytes'] == source_video.stat().st_size and result['source_registration_ns'] > 0
        measured = result['measured']; rows = measured['samples']; assert len(rows) == 2
        assert measured['asset']['frame_count'] == 3 and measured['cache_hits'] == measured['restored'] == 0
        assert rows[0]['target_us'] < rows[1]['target_us'] and rows[0]['input']['rgb_sha256'] != rows[1]['input']['rgb_sha256']
        logs = (root / 'logs/motion-studio.log').read_text(encoding='utf-8')
        assert 'start depth_video_capability phase=source_probe' in logs
        for index, row in enumerate(rows):
            assert row['request'] == index + 1
            assert row['descriptor']['source']['pts'] == dict(ticks=row['target_us'], timescale=1_000_000)
            assert row['end_us'] > row['target_us'] and row['input']['rgb_size'] == [64,48]
            assert row['worker_total_ns'] >= row['source_prepare_ns'] > 0 and row['source_rgb_bytes'] == 64*48*3
            assert row['worker_total_ns'] >= row['resolve_ns'] > 0 and row['inference_ns'] > 0
            assert row['retained_gpu_buffer_capacity_bytes'] == (None if kind == 'onnx' else 227968156)
            assert f"start #{index+1} depth_infer asset=75 revision=1 target_us={row['target_us']} phase=video_decode" in logs
            assert f"start #{index+1} depth_capability asset=75 phase=backend" in logs
            data = (root / row['depth_file']).read_bytes(); assert len(data) == 64*48*4 and row['depth_values'] == 64*48
            assert row['depth_sha256'] == list(hashlib.sha256(data).digest())
        assert measured['depth_output_bytes'] == 2*64*48*4
        totals = sorted(row['worker_total_ns'] for row in rows)
        assert measured['profile'] == dict(samples=2, fastest_ns=totals[0], median_ns=totals[1], slowest_ns=totals[1], retained_gpu_buffer_capacity_bytes=None if kind == 'onnx' else 227968156)
        video_results[kind] = result
    comparisons = []
    for index, (cpu, gpu) in enumerate(zip(video_results['onnx']['measured']['samples'], video_results['wgsl']['measured']['samples'])):
        assert cpu['input'] == gpu['input'] and cpu['descriptor'] == gpu['descriptor']
        cpu_data = (OUT / 'onnx-video-probe' / cpu['depth_file']).read_bytes()
        gpu_data = (OUT / 'wgsl-video-probe' / gpu['depth_file']).read_bytes()
        a = struct.unpack('<' + 'f'*(64*48), cpu_data); b = struct.unpack('<' + 'f'*(64*48), gpu_data)
        assert all(math.isfinite(x) for x in (*a,*b))
        span = max(a)-min(a); assert span > 1e-6
        errors = [abs(x-y)/span for x,y in zip(a,b)]
        assert max(errors) <= 2e-4 and sum(errors)/len(errors) <= 2e-5
        comparisons.append(dict(index=index, values=len(a), original_maximum_bound=2e-4, original_mean_bound=2e-5, normalized_maximum=max(errors), normalized_mean=sum(errors)/len(errors)))
    report['actual_video_measurements'] = video_results
    report['actual_video_same_model_comparisons'] = comparisons; save()
    corrupt = OUT / 'authored-corrupt.mp4'; corrupt.write_bytes(b'authored invalid video control')
    run('corrupt-video', [video_driver, OUT / 'corrupt-video-probe', 'onnx', python, model, '-', '-', corrupt, '0', '1'], 1)
    assert not (OUT / 'corrupt-video.stdout.log').read_bytes()
    errors = (OUT / 'corrupt-video.stderr.log').read_text(encoding='utf-8')
    logs = (OUT / 'corrupt-video-probe/logs/motion-studio.log').read_text(encoding='utf-8')
    assert 'ERROR' in errors and 'ERROR' in logs and 'operation=depth_video_capability' in errors and 'operation=depth_video_capability' in logs
    assert 'start depth_video_capability phase=source_probe' in logs
    assert not (OUT / 'corrupt-video-probe/measurements.json').exists()
    failure = OUT / 'missing-program'
    run('missing-program', [driver, failure, 'wgsl', python, model, OUT / 'absent-program.json', worker, rgb, '12x8', '1', '1000'], 1)
    assert not (OUT / 'missing-program.stdout.log').read_bytes()
    logs = (failure / 'logs/motion-studio.log').read_text(encoding='utf-8')
    error = (OUT / 'missing-program.stderr.log').read_text(encoding='utf-8')
    assert 'start #1 depth_capability asset=75 phase=capability_resolve' in logs
    assert 'ERROR' in logs and 'ERROR' in error and 'operation=depth_infer' in logs and 'operation=depth_infer' in error
    assert not (failure / 'measurements.json').exists()
    report['status'] = 'native_changed_crates_and_actual_uncached_capability_probes_passed'
except BaseException as cause:
    report.update(status='failed_original_outputs_retained', cause=repr(cause), traceback=traceback.format_exc())
finally:
    report.update(source_unchanged=hashes() == report['source_sha256'], completed_utc=datetime.now(timezone.utc).isoformat())
    report['logs'] = {p.name: dict(bytes=p.stat().st_size, sha256=sha(p)) for p in OUT.glob('*.log')}; save()
print(json.dumps({k: v for k, v in report.items() if k not in ('source_sha256', 'source_bound_invocations', 'actual_inputs')}))
raise SystemExit(0 if report['status'] == 'native_changed_crates_and_actual_uncached_capability_probes_passed' and report['source_unchanged'] else 1)
