from pathlib import Path
import hashlib,json,re,subprocess,zipfile
out=Path(__file__).resolve().parent;work=Path('E:/Dev/aem/.worktrees/node-port-labels');dest=work/'engineering/validation'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=load(out/'before-complete-receipt.json');after=load(out/'after-complete-receipt.json');regressions=load(out/'node-regressions-receipt.json');fault=load(out/'failure-path-receipt.json');comparison=load(out/'comparison.json')
assert all(r['exit_code']==0 and r['source_unchanged'] for r in [before,after,regressions,fault])
assert all(digest(work/p)==h for p,h in regressions['sources'].items())
assert (work/'desktop/app/src/node_editor.rs').read_bytes()==(out/'original-node-editor.rs').read_bytes()
summary=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',(out/'node-regressions.log').read_text(encoding='utf-8'));assert summary==[('164','0','0')]
assert 'test result: ok. 1 passed; 0 failed;' in (out/'baseline-identity-test.log').read_text(encoding='utf-8')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip();assert head=='7d5fc80932040676baacae0e4ace5ab67c0711c8'
items=[]
def add(name,p):items.append((name,p))
for name in ['base.json','branch-audit.json','probe.rs','allocator.rs','run_phase.py','finish_pair.py','package_evidence.py','original-node-editor.rs','original-canvas.rs','before-complete-receipt.json','after-complete-receipt.json','before-complete.log','after-complete.log','baseline-identity-test.log','comparison.json','node-regressions-receipt.json','node-regressions.log','regression-source-freeze.json','failure-path-receipt.json','failure-child-stdout.log','failure-child-stderr.log']:add(name,out/name)
add('failure-child/motion-studio.log',out/'failure-child/motion-studio.log')
for phase in ['before-complete','after-complete']:
    files=list((out/phase).iterdir());assert len([p for p in files if p.suffix=='.txt'])==44
    for p in files:
        if p.is_file():add(phase+'/'+p.name,p)
for path in regressions['sources']:add('final-source/'+path,work/path)
names=[name for name,_ in items];assert len(names)==len(set(names))
manifest=[dict(name=name,bytes=p.stat().st_size,sha256=digest(p)) for name,p in items]
(dest/'data').mkdir(exist_ok=True,parents=True);archive=dest/'data/node-port-labels-f521593d.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in items:z.writestr(name,p.read_bytes())
    z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
record=dict(issue=134,base=before['head'],code_revision=head,before=before,after=after,comparison=comparison,regressions=regressions,fault=fault,tests_passed=164,
    archive=dict(path='engineering/validation/data/'+archive.name,bytes=archive.stat().st_size,sha256=digest(archive),entries=len(items)+1),
    limits=['extra frame-local Card identity pointer increases fully culled scene requested bytes','allocation requests and requested bytes in this dev test corpus, not RSS or FPS','no persistent metadata cache; other node/frame allocations remain','no claim of complete #134, all DPI, native window presentation, or DESIGN section 12 acceptance','five non-skipped latest-head CI jobs pending'])
(dest/'node-port-labels-results.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rows='\n'.join(f"| {r['name'].removesuffix('.txt')} | {r['requests_before']} → {r['requests_after']} | {r['bytes_before']} → {r['bytes_after']} |" for r in comparison['cases'])
baseline=[('path_controls 六处行高','不改行高或纵向节奏'),('path_controls 双列宽度','不改列宽'),('path_controls 按钮高度','不改按钮尺寸或命中区域'),('path_controls 数值背景','不改字段状态绘制'),('path_controls 布尔控件','不改控件或事件路由'),('effect_controls 行高与步进','不改属性行布局'),('effect_controls 布尔按钮','不改布尔控件'),('effect_controls 枚举按钮','不改下拉控件'),('effect_controls 悬浮 alpha','不改 hover 或 token'),('effect_controls 缩进层级','不改属性树'),('timeline 标签列坐标','按兼容基线保留'),('timeline 吸附引导颜色','不改颜色，未新增 token')]
baseline_rows='\n'.join(f'| {name} | retained with reason | {reason} |' for name,reason in baseline)
doc=f'''# 节点卡片端口标签规格复用验收

基线 `{before['head']}`，本地仅代码提交 `{head}`，关联 #134。卡片构建已解析端口类型与标签规格，画布标签原先再次创建同一份 BTreeMap。现在对同一来源节点的非空插口卡片借用这份当帧数据，按原输入/输出排序绘制；空插口或节点身份不匹配时继续使用原解析与观察路径。

## 身份与生命周期

每张临时 Card 增加一个只比较、不解引用的节点身份指针，卡片只在当前绘制过程中使用。编辑、组导航、撤销及替换文档仍走现有卡片重建机制，没有跨帧缓存。指针不会进入工程、历史、绘制命令或日志。

该身份检查保留了畸形重复 ID 的首个匹配节点语义。新增回归对普通及逆序卡片、首节点可用/不支持、中英文，比较缓存标签与真实文档解析的全部字形结果；该回归在原实现和最终补丁上均通过。原有断言不改，两个合成卡片测试只补上空身份字段。

开始前检查开放 PR、588 个引用、15 个 canvas.rs 版本及 117 个包含该文件的工作树；现代实现均存在两次规格调用，没有此复用方案。其他人的 #499 关键帧选择改动未触及节点编辑器，已先进入所用基线；#500 处理 UI 裁剪，与本次源文件不同。

## 实际结果和代价

20 组真实 NodeEditor.draw 工作负载，覆盖中英文、900×600/1600×1000、普通四节点、Gradient 默认值、折叠节点、128 节点及全部不可见视野。每组三帧预热、20 帧计数，共 400 个测量帧；输入构造、文件写入和调试序列化不在计数范围。

共减少 14320 次分配请求，申请字节净减少 3825360。20 个静态快照与 24 个缩放、平移、拖动、撤销及组导航快照逐字节一致，内容包括完整绘制列表、文档、视图、动作、选中对象与历史状态。

身份指针有明确代价：在这次 64 位构建的四组全部不可见场景中，每帧额外申请 1024 字节，80 帧共增加 81920 字节，分配请求次数不变。这是临时卡片存储的申请量，不是常驻内存或峰值；净节省已包含此代价。没有据此推断 RSS 或帧率，也没有宣称所有视野的申请字节都下降。

| 场景 | 请求次数：前 → 后 | 申请字节：前 → 后 |
| --- | --- | --- |
{rows}

节点编辑器完整相关回归：164 passed、0 failed、0 ignored。最终测试移除了临时计数器模块，所有实际修改文件都与验证时的散列一致。

## 失败路径与审计处置

- NODE-PORT-01：新增观察证据是成功路径的当帧数据复用、400 帧计数和 44 个完整输出对照；没有新增产品日志或错误 UI。
- NODE-PORT-02：空插口、未知操作和身份不匹配沿用原 fallible 解析及原回退，不将失败伪装成缓存成功。首次探针误用不支持默认值的 Math 输入，被既有校验拒绝；该失败保留在本地，最终改用现有 compact_gradient 的 falloff 默认值，未修改产品校验。
- NODE-PORT-03：实际运行原有受控缺陷测试的子进程，默认 Info 文件日志核对 canvas.sockets、canvas.labels、context.ports、inspector.ports、inspector.help_ports、request.field、layout.arrange 七个站点。每站点保留首次 Warn 与第 60 次 Error，Error 同时出现在 stderr，stdout 无日志；文档、修订与既有断言均保留。
- NODE-PORT-04：上述原有计数器按 NodeEditor 实例及固定站点累计并饱和，成功不重置，新实例重新开始；本次不修改该生命周期策略，也不把 60 次解释成一秒。没有新观察键、持久错误原因、重试、线程或协议变更。
- NODE-PORT-05：节点高度、其他布局计算和逐帧分配仍有独立工作；未关闭整个 #134，也未宣称其他 DPI、原生窗口呈现或 DESIGN §12 全部验收通过。

## 复现与来源

在仓库 Windows/FFmpeg 构建环境及锁定依赖下，使用归档 probe.rs、allocator.rs 和 run_phase.py：向 node_editor.rs 临时添加 cfg(test) 探针模块，分别在基线与补丁执行指定的真实绘制探针，比较两个完整输出目录；完成后删除探针模块，再执行 `cargo test -p motion-desktop --bin motion-studio node_editor:: -- --test-threads=1`。实际命令包含本机内存控制构建选项，完整记录在 JSON 中。失败子进程直接复用了原测试，未修改原断言。路径为原机器证据位置，离线复验需重定位。

已核对 PROVENANCE.md、ATTRIBUTION.md、NOTICE；没有新依赖、兼容性名称或第三方资产。图形、样例和探针来自本仓库独立实现；没有复制 Adobe 资源。没有新增颜色、尺寸、样式 token、行高或命中区域，保留现有节点样式与布局问题的专项整改边界。

## DESIGN §0.7 逐项处置

下表只记录本次边界，不声称重新证明旧条目仍存在或已修复。

| 基线条目 | 状态 | 原因 |
| --- | --- | --- |
{baseline_rows}

[结构化结果](node-port-labels-results.json)；[原始证据](data/{archive.name})，SHA-256 `{record['archive']['sha256']}`。合并前仍须新提交的五项非跳过 CI 成功。
'''
(dest/'node-port-labels-progress.md').write_text(doc,encoding='utf-8')
print(json.dumps(dict(tests_passed=164,archive=record['archive']),ensure_ascii=False))
