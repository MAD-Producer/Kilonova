from pathlib import Path
import hashlib,json,os,re,subprocess,time
out=Path(__file__).resolve().parent;work=Path('E:/Dev/aem/.worktrees/node-port-labels')
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
baseline=load(out/'before-complete-receipt.json');assert baseline['exit_code']==0 and baseline['source_unchanged']
env=os.environ.copy();env['CARGO_TERM_COLOR']='never';env.pop('MOTION_LOG',None)
unit=Path(re.search(r'\(([^\r\n]+\.exe)\)',(out/'before-complete.log').read_text(encoding='utf-8')).group(1))
name='node_editor::view::frame_cards_tests::port_labels_keep_live_first_identity_for_duplicate_and_reordered_cards'
assert not (out/'baseline-identity-test.log').exists()
with (out/'baseline-identity-test.log').open('w',encoding='utf-8') as log:result=subprocess.run([str(unit),'--exact',name,'--nocapture'],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0,'The new identity test must pass the original implementation'
proposal=out/'identity-proposal';base=load(out/'base.json')['head']
for item in load(proposal/'manifest.json'):
    path=work/item['path'];original=subprocess.check_output(['git','show',base+':'+item['path']],cwd=work)
    assert path.read_bytes()==original
    data=(proposal/item['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==item['sha256'];path.write_bytes(data)
result=subprocess.run(['python',str(out/'run_phase.py'),'after-complete'],cwd=work,env=env);assert result.returncode==0
before=load(out/'before-complete/records.json');after=load(out/'after-complete/records.json');assert len(before)==len(after)==20
comparisons=[]
for old,new in zip(before,after):
    for key in ['name','nodes','frames','defaults','collapsed','culled']:assert old[key]==new[key]
    assert (out/'before-complete'/old['name']).read_bytes()==(out/'after-complete'/new['name']).read_bytes(),old['name']
    assert new['allocation_requests']<=old['allocation_requests'],old['name']
    comparisons.append(dict(name=old['name'],nodes=old['nodes'],frames=20,culled=old['culled'],requests_before=old['allocation_requests'],requests_after=new['allocation_requests'],bytes_before=old['requested_bytes'],bytes_after=new['requested_bytes']))
interactions=sorted((out/'before-complete').glob('interaction-*.txt'));assert len(interactions)==24
assert all(p.read_bytes()==(out/'after-complete'/p.name).read_bytes() for p in interactions)
record=dict(cases=comparisons,measured_frames=400,static_snapshots=20,interaction_snapshots=24,complete_paint_document_view_actions_and_history_equal=True,allocation_requests_removed=sum(r['requests_before']-r['requests_after'] for r in comparisons),requested_bytes_net_removed=sum(r['bytes_before']-r['bytes_after'] for r in comparisons),culled_extra_requested_bytes=sum(r['bytes_after']-r['bytes_before'] for r in comparisons if r['culled']))
(out/'comparison.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in record.items() if k!='cases'}),flush=True)
root_source=work/'desktop/app/src/node_editor.rs';original=(out/'original-node-editor.rs').read_bytes()
marker=b'\n#[cfg(test)]\n#[path = "E:/Dev/aem/.tools/node-port-labels/probe.rs"]\nmod port_label_probe;\n'
assert root_source.read_bytes()==original+marker;root_source.write_bytes(original)
paths=['desktop/app/src/node_editor.rs','desktop/app/src/node_editor/view/mod.rs','desktop/app/src/node_editor/view/canvas.rs','desktop/app/src/node_editor/view/frame_cards_tests.rs','desktop/app/src/node_editor/view/wire_target_tests.rs','desktop/app/src/node_editor/view/wires/socket_index_tests.rs']
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
frozen=freeze();(out/'regression-source-freeze.json').write_text(json.dumps(frozen,indent=2),encoding='utf-8')
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1','node_editor::','--','--test-threads=1']
start=time.monotonic();log=out/'node-regressions.log';assert not log.exists()
with log.open('w',encoding='utf-8') as stream:result=subprocess.run(command,cwd=work,env=env,stdout=stream,stderr=subprocess.STDOUT)
record=dict(command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),sources=frozen,source_unchanged=freeze()==frozen,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(out/'node-regressions-receipt.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
assert result.returncode==0 and record['source_unchanged'];assert re.search(r'test result: ok\. [1-9]\d* passed; 0 failed; 0 ignored;',log.read_text(encoding='utf-8'))
unit=Path(re.search(r'\(([^\r\n]+\.exe)\)',log.read_text(encoding='utf-8')).group(1));fault=out/'failure-child';assert not fault.exists()
env['MOTION_NODE_PORT_FALLBACK_CHILD']=str(fault)
name='node_editor::view::observability_tests::malformed_ports_and_rejected_requests_log_once_per_site_without_editing'
with (out/'failure-child-stdout.log').open('w',encoding='utf-8') as stdout,(out/'failure-child-stderr.log').open('w',encoding='utf-8') as stderr:result=subprocess.run([str(unit),'--exact',name,'--nocapture'],cwd=work,env=env,stdout=stdout,stderr=stderr,timeout=120)
assert result.returncode==0
text=(fault/'motion-studio.log').read_text(encoding='utf-8');stderr=(out/'failure-child-stderr.log').read_text(encoding='utf-8');stdout=(out/'failure-child-stdout.log').read_text(encoding='utf-8')
sites=['canvas.sockets','canvas.labels','context.ports','inspector.ports','inspector.help_ports','request.field','layout.arrange']
for site in sites:
    rows=[line for line in text.splitlines() if 'site='+site+' ' in line];assert len(rows)==2 and 'WARN' in rows[0] and 'ERROR' in rows[1]
    assert any('ERROR' in line and 'site='+site+' ' in line for line in stderr.splitlines())
assert 'node degradation' not in stdout and 'logging initialized' not in stdout
(out/'failure-path-receipt.json').write_text(json.dumps(dict(exit_code=0,sites=sites,default_info_log_verified=True,error_stderr_verified=True,stdout_isolated=True,original_assertions_unchanged=True,sources=frozen,source_unchanged=freeze()==frozen),indent=2),encoding='utf-8')
print('Node regressions and seven actual default-level fault observations passed',flush=True)
