from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,re,subprocess,time
root=Path('E:/Dev/aem'); work=root/'.worktrees/tracking-import88'
out=root/'artifacts/pr-queue/frame-rate85-native-readback-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','-z','crates','desktop','Cargo.toml','Cargo.lock'],cwd=work).decode().split('\0')
names.append('desktop/app/src/shell/rational_clock_native_tests.rs')
sources={n:sha(work/n) for n in names if n and (work/n).is_file()}
os.environ['MOTION_RATIONAL_CLOCK_UI_ARTIFACTS']=str(out/'captures')
os.environ['LOCALAPPDATA']=str(out/'owned-profile')
os.environ.pop('MOTION_LOG',None)
test='shell::rational_clock_native_tests::fractional_project_clocks_render_native_readouts_in_both_locales'
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--locked','--offline',test,'--','--exact','--test-threads=1','--nocapture']
report=dict(status='running',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),sources=sources,command=command,startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Real native attached-surface GPU readback; visual inspection required after execution','This differs from OS ImageGrab, whose original four blank outputs remain rejected','No final whole-desktop, renderer, cross-platform or precision-stack-overflow acceptance claim'])
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n');save();began=time.monotonic()
try:
    with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
        process=subprocess.Popen(command,cwd=work,stdout=stdout,stderr=stderr,env=os.environ.copy());report['pid']=process.pid;save();report['exitCode']=process.wait()
    report['summaries']=re.findall(r'^test result: .+$',(out/'stdout.log').read_text(errors='replace'),re.M)
    report['sourceUnchanged']=all(sha(work/n)==value for n,value in sources.items())
    ran=any('1 passed; 0 failed; 0 ignored;' in s for s in report['summaries'])
    report['status']='native_readbacks_passed_visual_inspection_pending' if report['exitCode']==0 and ran and report['sourceUnchanged'] else 'failed_original_outputs_retained'
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-began,3));save()
print(json.dumps({k:v for k,v in report.items() if k!='sources'}))
raise SystemExit(0 if report['status']=='native_readbacks_passed_visual_inspection_pending' else 1)
