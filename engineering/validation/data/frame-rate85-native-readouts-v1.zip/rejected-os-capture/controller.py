"""Capture actual native windows after the independent full GPU gate exits.

This uses the preserved product EXE and MCP; it neither draws a mock UI nor
changes product code. Captures require subsequent visual inspection.
"""
from datetime import datetime, timezone
from pathlib import Path
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
import queue
import subprocess
import threading
import time

from PIL import ImageGrab

root = Path('E:/Dev/aem')
prepared = root / 'artifacts/pr-queue/frame-rate85-native-clock-projects-v1'
gate = root / 'artifacts/pr-queue/professional-api86-combined-main-v3'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
# The caller must first consume the original exec handle's terminal result.
# A report file alone is not proof that the original process has exited.
permission = json.loads((prepared / 'full-gate-terminal-consumed.json').read_text())
assert permission['originalSession'] == 61610 and permission['terminalConsumed']
assert permission['gateReportSha256'] == sha(gate / 'exit.json')
full = json.loads((gate / 'exit.json').read_text())
assert full['status'] != 'running' and full.get('completedUtc')
source = json.loads((prepared / 'prepare.json').read_text())
binary = Path(source['binary']['path'])
assert sha(binary) == source['binary']['sha256']
out = root / 'artifacts/pr-queue/frame-rate85-native-clock-windows-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='running', sourceHead=source['sourceHead'],
    startedUtc=datetime.now(timezone.utc).isoformat(),
    binary=source['binary'], prerequisite=permission, cases=[],
    limits=['Actual native window/MCP captures, not a mock or helper-only test',
            'Screenshots must be visually inspected before declaring UI acceptance',
            'Empty projects test clock readouts only, not media decoding or full professional footage',
            'This binary predates any later fault-fixture-only repair'])

def save():
    (out / 'exit.json').write_text(json.dumps(report, indent=2) + '\n')

u32 = ctypes.WinDLL('user32', use_last_error=True)
callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
u32.EnumWindows.argtypes = [callback_type, wintypes.LPARAM]
u32.EnumWindows.restype = wintypes.BOOL
u32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
u32.GetWindowThreadProcessId.restype = wintypes.DWORD
u32.IsWindowVisible.argtypes = [wintypes.HWND]
u32.IsWindowVisible.restype = wintypes.BOOL
u32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
u32.GetWindowRect.restype = wintypes.BOOL
u32.GetForegroundWindow.restype = wintypes.HWND
u32.SetForegroundWindow.argtypes = [wintypes.HWND]
u32.SetForegroundWindow.restype = wintypes.BOOL
u32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
u32.SetWindowPos.restype = wintypes.BOOL
u32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
u32.PostMessageW.restype = wintypes.BOOL

def find_window(pid):
    found = []
    @callback_type
    def visit(hwnd, _):
        owner = wintypes.DWORD()
        u32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
        if owner.value == pid and u32.IsWindowVisible(hwnd):
            found.append(hwnd)
        return True
    assert u32.EnumWindows(visit, 0)
    return found[0] if found else None

def run_case(project, locale):
    name = Path(project['path']).name + '-' + locale
    folder = out / name
    folder.mkdir()
    project_path = Path(project['path']) / 'project.json'
    assert sha(project_path) == project['sha256']
    env = os.environ.copy()
    env.pop('MOTION_LOG', None)
    env['LOCALAPPDATA'] = str(folder / 'local-app-data')
    env['TEMP'] = str(root / 'target/ci-policy-validation-tmp')
    env['TMP'] = env['TEMP']
    command = [str(binary), '--project', project['path'], '--mcp-ui', '--locale', locale]
    case = dict(name=name, status='running', command=command, project=project)
    report['cases'].append(case)
    save()
    messages = queue.Queue()
    hwnd = None
    with (folder / 'stdout.log').open('wb') as stdout, (folder / 'stderr.log').open('wb') as stderr:
        process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=stderr, env=env, creationflags=subprocess.CREATE_NO_WINDOW)
        case['pid'] = process.pid
        save()
        def read_lines():
            try:
                for line in iter(process.stdout.readline, b''):
                    stdout.write(line)
                    stdout.flush()
                    messages.put(json.loads(line))
            except BaseException as cause:
                messages.put(cause)
            finally:
                messages.put(None)
        reader = threading.Thread(target=read_lines, daemon=True)
        reader.start()
        request = 0
        def rpc(method, params):
            nonlocal request
            request += 1
            payload = dict(jsonrpc='2.0', id=request, method=method, params=params)
            process.stdin.write(json.dumps(payload).encode() + b'\n')
            process.stdin.flush()
            deadline = time.monotonic() + 30
            while True:
                response = messages.get(timeout=max(0.01, deadline-time.monotonic()))
                if isinstance(response, BaseException):
                    raise response
                assert response is not None, 'MCP closed before response'
                assert 'error' not in response, response
                if response.get('id') == request:
                    return response['result']
        def tool(name, arguments):
            result = rpc('tools/call', dict(name=name, arguments=arguments))
            assert not result.get('isError'), result
            return result['structuredContent']
        try:
            rpc('initialize', dict(protocolVersion='2025-11-25', capabilities={},
                clientInfo=dict(name='native-clock-readout-acceptance', version='1')))
            process.stdin.write(b'{"jsonrpc":"2.0","method":"notifications/initialized"}\n')
            process.stdin.flush()
            state = tool('motion_seek', dict(frame=project['seekFrame']))
            assert state['project']['fps'] == project['fps']
            assert state['frame'] == project['seekFrame']
            (folder / 'seek-state.json').write_text(json.dumps(state, indent=2) + '\n')
            deadline = time.monotonic() + 20
            while hwnd is None and time.monotonic() < deadline:
                assert process.poll() is None, 'native editor exited before window capture'
                hwnd = find_window(process.pid)
                time.sleep(0.1)
            assert hwnd is not None, 'native editor window was not created'
            width = min(1280, u32.GetSystemMetrics(0)-48)
            height = min(900, u32.GetSystemMetrics(1)-72)
            assert width >= 900 and height >= 600, 'desktop too small for expected panel readouts'
            assert u32.SetWindowPos(hwnd, None, 16, 16, width, height, 0x0044)
            u32.SetForegroundWindow(hwnd)
            deadline = time.monotonic() + 25
            while True:
                presented = tool('motion_state', {})
                performance = presented.get('desktop', {}).get('uiPerformance', {})
                if (presented.get('lastPresentedFrame') == project['seekFrame']
                    and performance.get('compositionRenders', 0) > 0
                    and not presented.get('desktop', {}).get('headless', True)):
                    break
                assert time.monotonic() < deadline, 'requested frame was not actually presented'
                time.sleep(0.1)
            (folder / 'presented-state.json').write_text(json.dumps(presented, indent=2) + '\n')
            assert presented.get('renderError') is None, presented.get('renderError')
            time.sleep(0.2)
            assert u32.GetForegroundWindow() == hwnd, 'another window covers the native editor; capture refused'
            rect = wintypes.RECT()
            assert u32.GetWindowRect(hwnd, ctypes.byref(rect))
            bounds = [rect.left, rect.top, rect.right, rect.bottom]
            capture = ImageGrab.grab(bbox=tuple(bounds), all_screens=True)
            capture.save(folder / 'window.png')
            after = tool('motion_state', {})
            assert after['frame'] == project['seekFrame'] and after['project'] == state['project']
            assert after['revision'] == state['revision'], 'capture must not edit the document'
            (folder / 'after-state.json').write_text(json.dumps(after, indent=2) + '\n')
            case.update(status='captured_visual_inspection_pending', screenshot=dict(
                path=str(folder/'window.png'), sha256=sha(folder/'window.png'), bounds=bounds),
                expectedTimecode=project['expectedNominalTimecode'], stateUnchanged=True)
        finally:
            if hwnd is not None:
                u32.PostMessageW(hwnd, 0x0010, 0, 0)
            process.stdin.close()
            try:
                case['exitCode'] = process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                case['cleanupFailure'] = 'native editor did not exit after WM_CLOSE and MCP EOF'
                process.terminate()
                case['exitCode'] = process.wait(timeout=10)
            reader.join(timeout=5)
            save()
        assert case['exitCode'] == 0 and 'cleanupFailure' not in case, case
        assert sha(project_path) == project['sha256'], 'readout capture changed saved project bytes'

save()
try:
    for project in source['projects']:
        for locale in ['zh','en']:
            run_case(project, locale)
    report['status'] = 'native_captures_passed_visual_inspection_pending'
except BaseException as cause:
    report.update(status='failed_original_outputs_retained', failure=repr(cause))
    raise
finally:
    report['completedUtc'] = datetime.now(timezone.utc).isoformat()
    save()
