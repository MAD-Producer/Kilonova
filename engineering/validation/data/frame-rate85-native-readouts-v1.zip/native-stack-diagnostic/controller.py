from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess

root=Path('E:/Dev/aem')
out=root/'artifacts/pr-queue/project-precision-stack-diagnostic-v1'
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=root/'target/rational-rate85-contract/debug/deps/motion_studio-f036c14478d1f764.exe'
binary=out/source.name
shutil.copy2(source,binary)
pdb=source.with_suffix('.pdb')
if pdb.exists(): shutil.copy2(pdb,out/pdb.name)
driver=(root/'.tools/issue-closure-review/debug-native-child-v4.py').read_text()
assert driver.count('if not exception.firstChance:')==1
driver=driver.replace('if not exception.firstChance:', 'if not exception.firstChance or exception.record.code == 0xc00000fd:')
path=out/'debug-driver.py'
path.write_text(driver)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
command=[str(root/'.tools/ai-depth74/venv/Scripts/python.exe'),str(path),
    '--exe',str(binary),'--expected-sha256',sha(binary),
    '--test','shell::project_precision_tests::project_precision_menu_apply_cancel_history_and_gpu_screens_cover_locales_sizes_and_ratios',
    '--child-env','MOTION_PROJECT_PRECISION_UI_CHILD','--output',str(out/'debugger'),
    '--child-timeout','600','--standard-heap']
report=dict(sourceHead='162edfed2b90550b69d9ea59b42bb1138369e7a2',binary=str(binary),sha256=sha(binary),command=command,
    status='diagnostic_running_not_acceptance',startedUtc=datetime.now(timezone.utc).isoformat(),
    limits='One diagnostic at preserved failed binary; first-chance stack-overflow dump; no stack increase, retry, assertion or implicit-layer change; a pass cannot erase original full-suite failure')
(out/'receipt.json').write_text(json.dumps(report,indent=2))
env=os.environ.copy()
env.pop('MOTION_LOG',None)
assert not env.get('RUST_MIN_STACK')
env['TEMP']=str(root/'target/ci-policy-validation-tmp')
env['TMP']=env['TEMP']
with (out/'driver.stdout.log').open('wb') as stdout,(out/'driver.stderr.log').open('wb') as stderr:
    code=subprocess.run(command,stdout=stdout,stderr=stderr,env=env,cwd=root).returncode
report.update(driverExitCode=code,completedUtc=datetime.now(timezone.utc).isoformat(),status='diagnostic_completed_not_acceptance')
(out/'receipt.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
