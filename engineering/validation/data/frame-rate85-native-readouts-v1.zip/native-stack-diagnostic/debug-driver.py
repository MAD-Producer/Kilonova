"""One owned diagnostic target, preserving second-chance Windows exceptions.

No registry changes, retries, injected code or changed program assertions.
Uses the documented Windows debug event and MiniDumpWriteDump APIs.
"""
from pathlib import Path
import argparse
import ctypes as c
from ctypes import wintypes as w
import hashlib
import json
import msvcrt
import os
import struct
import subprocess
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--exe', type=Path, required=True)
selection = parser.add_mutually_exclusive_group(required=True)
selection.add_argument('--test')
selection.add_argument('--all-tests', type=int, metavar='EXPECTED_COUNT')
parser.add_argument('--expected-sha256', required=True)
parser.add_argument('--child-env', required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--wait-pid', type=int, action='append', default=[])
parser.add_argument('--disable-implicit-layers', action='store_true')
parser.add_argument('--child-timeout', type=int, default=120)
parser.add_argument('--ignored', action='store_true')
parser.add_argument('--standard-heap', action='store_true')
args = parser.parse_args()
assert struct.calcsize('P') == 8 and os.name == 'nt'
assert 1 <= args.child_timeout <= 1800
assert args.all_tests is None or 1 <= args.all_tests <= 1000
assert args.exe.resolve().is_relative_to(Path('E:/Dev/aem/artifacts/pr-queue').resolve())
args.output.mkdir(exist_ok=False)
kernel = c.WinDLL('kernel32', use_last_error=True)
dbghelp = c.WinDLL('dbghelp', use_last_error=True)

def api(lib, name, result, parameters):
    fn = getattr(lib, name)
    fn.restype, fn.argtypes = result, parameters
    return fn

open_process = api(kernel, 'OpenProcess', w.HANDLE, [w.DWORD, w.BOOL, w.DWORD])
wait = api(kernel, 'WaitForSingleObject', w.DWORD, [w.HANDLE, w.DWORD])
close = api(kernel, 'CloseHandle', w.BOOL, [w.HANDLE])
file_name = api(kernel, 'GetFinalPathNameByHandleW', w.DWORD, [w.HANDLE, w.LPWSTR, w.DWORD, w.DWORD])
handles = [open_process(0x100000, False, pid) for pid in args.wait_pid]
print(json.dumps(dict(waiting=args.wait_pid)), flush=True)
for handle in handles:
    if not handle:
        continue
    try:
        while True:
            status = wait(handle, 10000)
            if status == 0:
                break
            assert status == 258, f'owner wait failed: {status}'
    finally:
        close(handle)

active = subprocess.check_output(['powershell', '-NoProfile', '-Command',
    "@(Get-CimInstance Win32_Process | Where-Object { ($_.Name -in @('cargo.exe','rustc.exe','link.exe') -or $_.Name -like 'motion_studio*.exe') -and $_.CommandLine -match 'gltf-animation87-contract|cargo test --workspace' }).Count"]).decode().strip()
assert active == '0', f'owned validation still active: {active}'

class ExceptionRecord(c.Structure):
    _fields_ = [('code', w.DWORD), ('flags', w.DWORD), ('record', c.c_void_p),
                ('address', c.c_void_p), ('count', w.DWORD), ('information', c.c_size_t * 15)]

class ExceptionInfo(c.Structure):
    _fields_ = [('record', ExceptionRecord), ('firstChance', w.DWORD)]

class Payload(c.Union):
    _fields_ = [('exception', ExceptionInfo), ('file', w.HANDLE), ('exitCode', w.DWORD), ('raw', c.c_byte * 160)]

class DebugEvent(c.Structure):
    _fields_ = [('code', w.DWORD), ('process', w.DWORD), ('thread', w.DWORD), ('data', Payload)]

assert c.sizeof(ExceptionRecord) == 152 and c.sizeof(DebugEvent) == 176 and DebugEvent.data.offset == 16
wait_event = api(kernel, 'WaitForDebugEvent', w.BOOL, [c.POINTER(DebugEvent), w.DWORD])
continue_event = api(kernel, 'ContinueDebugEvent', w.BOOL, [w.DWORD, w.DWORD, w.DWORD])
dump = api(dbghelp, 'MiniDumpWriteDump', w.BOOL,
           [w.HANDLE, w.DWORD, w.HANDLE, w.DWORD, c.c_void_p, c.c_void_p, c.c_void_p])
report = dict(exeSha256=hashlib.sha256(args.exe.read_bytes()).hexdigest(), test=args.test, expectedAllTests=args.all_tests,
              status='running_diagnostic_only', exceptions=[],
              loadedModules=[], droppedModuleNames=0, disableImplicitLayers=args.disable_implicit_layers,
              limits='One diagnostic child; no full-suite acceptance, no retries. Minidump has all thread contexts but no synthetic exception context. No external process attached.')
assert report['exeSha256'] == args.expected_sha256, 'preserved binary identity changed'

def save():
    (args.output / 'report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')

env = os.environ.copy()
env.pop('MOTION_LOG', None)
env[args.child_env] = str(args.output)
env['LOCALAPPDATA'] = str(args.output / 'owned-profile')
Path(env['LOCALAPPDATA']).mkdir()
if args.standard_heap:
    env['_NO_DEBUG_HEAP'] = '1'
report['heapEnvironment'] = env.get('_NO_DEBUG_HEAP')
report['ownedProfile'] = env['LOCALAPPDATA']
if args.disable_implicit_layers:
    # Per-child Khronos loader controls only; no persistent environment,
    # registry, overlay installation or user application state is changed.
    env['VK_LOADER_LAYERS_DISABLE'] = '~implicit~'
    env.pop('VK_LOADER_LAYERS_ENABLE', None)
    env.pop('VK_LOADER_LAYERS_ALLOW', None)
    env['VK_LOADER_DEBUG'] = 'error,warn,layer'
report['loaderEnvironment'] = {key: env.get(key) for key in
    ('VK_LOADER_LAYERS_DISABLE','VK_LOADER_LAYERS_ENABLE','VK_LOADER_LAYERS_ALLOW','VK_LOADER_DEBUG','WGPU_BACKEND')}
shutil_path = Path(__file__)
(args.output / 'controller.py').write_bytes(shutil_path.read_bytes())
save()
with (args.output / 'stdout.log').open('wb') as stdout, (args.output / 'stderr.log').open('wb') as stderr:
    process = subprocess.Popen([str(args.exe), *(['--ignored'] if args.ignored else []), *(['--exact', args.test] if args.test else []), '--nocapture', '--test-threads=1'],
                               env=env, stdout=stdout, stderr=stderr, creationflags=2 | 0x08000000)
    report['pid'] = process.pid
    save()
    deadline = time.monotonic() + args.child_timeout
    initial_break = False
    try:
        while True:
            assert time.monotonic() < deadline, 'diagnostic child deadline'
            event = DebugEvent()
            if not wait_event(c.byref(event), 1000):
                error = c.get_last_error()
                assert error == 121, f'WaitForDebugEvent error={error}'
                continue
            assert event.process == process.pid, 'unexpected debugged process'
            continuation = 0x10002
            if event.code == 1:
                exception = event.data.exception
                row = dict(code=f'{exception.record.code:08x}', address=exception.record.address,
                           firstChance=bool(exception.firstChance), thread=event.thread,
                           information=list(exception.record.information)[:exception.record.count])
                report['exceptions'].append(row)
                if exception.record.code == 0x80000003 and not initial_break:
                    initial_break = True
                else:
                    continuation = 0x80010001
                if not exception.firstChance or exception.record.code == 0xc00000fd:
                    # NULL ExceptionParam deliberately avoids inventing an
                    # exception context. The stopped thread contexts and raw
                    # exception event remain independent pieces of evidence.
                    with (args.output / f'exception-{len(report["exceptions"])}.dmp').open('wb') as target:
                        row['dumpWritten'] = bool(dump(int(process._handle), process.pid,
                            msvcrt.get_osfhandle(target.fileno()), 0x1000, None, None, None))
                        row['dumpError'] = 0 if row['dumpWritten'] else c.get_last_error()
                save()
            elif event.code in (3, 6):
                if event.data.file:
                    name = c.create_unicode_buffer(32768)
                    if file_name(event.data.file, name, len(name), 0):
                        # Module names only: do not publish full user paths or
                        # inspect third-party executable contents.
                        if len(report['loadedModules']) < 256:
                            report['loadedModules'].append(Path(name.value).name)
                        else:
                            report['droppedModuleNames'] += 1
                    close(event.data.file)
            elif event.code == 5:
                report['debugExitCode'] = event.data.exitCode
                assert continue_event(event.process, event.thread, continuation)
                break
            assert continue_event(event.process, event.thread, continuation), c.get_last_error()
    except BaseException:
        process.kill()
        report['status'] = 'diagnostic_driver_failed'
        save()
        raise
    finally:
        process.wait(timeout=10)
report['exitCode'] = process.returncode
expected_count = args.all_tests or 1
report['testActuallyRan'] = f'{expected_count} passed; 0 failed; 0 ignored;' in (args.output / 'stdout.log').read_text(encoding='utf-8')
report['status'] = 'diagnostic_child_passed_not_full_acceptance' if process.returncode == 0 and report['testActuallyRan'] else 'diagnostic_child_failed_or_not_executed'
save()
print(json.dumps(report), flush=True)
