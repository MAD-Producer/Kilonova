from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, subprocess

root = Path('E:/Dev/aem')
gate = root/'artifacts/pr-queue/professional-api86-combined-main-v3'
report = json.loads((gate/'exit.json').read_text())
assert report['completedUtc'] and report['sourceUnchanged']
assert report['head'] == '162edfed2b90550b69d9ea59b42bb1138369e7a2'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
counts = {}
for item in report['results']:
    totals = [0, 0, 0]
    for line in item['summaries']:
        match = re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored;', line)
        if match:
            totals = [a + int(b) for a, b in zip(totals, match.groups())]
    counts[item['name']] = dict(passed=totals[0], failed=totals[1], ignored=totals[2], exitCode=item['exitCode'])
assert counts['render'] == dict(passed=957, failed=0, ignored=1, exitCode=0)
assert counts['desktop'] == dict(passed=1697, failed=1, ignored=69, exitCode=101)
receipt = dict(originalSession=61610, terminalConsumed=True, terminalExitCode=1,
    consumedUtc=datetime.now(timezone.utc).isoformat(), gateReportSha256=sha(gate/'exit.json'),
    sourceHead=report['head'], counts=counts, sourceUnchanged=True,
    failure='project_precision native child: motion-engine stack overflow',
    remaining=['helper-check not executed after desktop failure', 'final integrated source not validated by this run'])
destination = root/'artifacts/pr-queue/frame-rate85-native-clock-projects-v1/full-gate-terminal-consumed.json'
with destination.open('x') as stream:
    json.dump(receipt, stream, indent=2)
print(json.dumps(receipt))

out = root/'artifacts/pr-queue/frame-rate85-ci-9ea-v1'
out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
job = 125865601613
actual = json.loads(subprocess.check_output(['gh','api',f'repos/MAD-Producer/Kilonova/actions/jobs/{job}']))
run = json.loads(subprocess.check_output(['gh','api',f'repos/MAD-Producer/Kilonova/actions/runs/{actual["run_id"]}']))
assert actual['conclusion']=='failure' and run['head_sha']=='9ea8510721fe8fccbe52ac5c7ca6ef8991544e35'
raw = subprocess.check_output(['gh','api',f'repos/MAD-Producer/Kilonova/actions/jobs/{job}/logs'])
(out/'ubuntu.log').write_bytes(raw)
(out/'receipt.json').write_text(json.dumps(dict(head=run['head_sha'],job=job,run=actual['run_id'],sha256=sha(out/'ubuntu.log'),steps=actual['steps']),indent=2)+'\n')
for line in raw.decode(errors='replace').splitlines():
    if any(word in line for word in ['FAILED', 'panicked at', 'failures:', 'test result: FAILED']):
        print(line[:700])
