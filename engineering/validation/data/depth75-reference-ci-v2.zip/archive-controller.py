"""Archive actual discovered controls without relabeling the original missing-dependency failure."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75';OUT=BASE/'depth75-reference-ci-v2'
assert json.loads((OUT/'session-consumed.json').read_text())==dict(session=71343,consumed=True,exit_code=0)
r=json.loads((OUT/'receipt.json').read_text());assert r['status']=='actual11_reference_controls_and_complete_ci_tools_passed' and r['source_unchanged']
assert [s['tests'] for s in r['stages']]==[11,146] and all(s['exit_code']==0 for s in r['stages'])
text=(OUT/'complete-tools.stderr.log').read_text(encoding='utf-8');assert 'OK (skipped=1)' in text and 'FAILED' not in text
def sha(raw):return hashlib.sha256(raw).hexdigest()
for name,digest in r['source_sha256'].items():assert sha((WORK/name).read_bytes())==digest,name
members={name:(OUT/name).read_bytes() for name in ('controller.py','receipt.json','session-consumed.json',
 'reference-controls.stdout.log','reference-controls.stderr.log','complete-tools.stdout.log','complete-tools.stderr.log')}
for name in ('tools/depth_reference_inputs.py','tools/depth_reference_metrics.py','tools/test_ci_depth_reference_inputs.py',
 'tools/test_ci_depth_reference_metrics.py','tools/validation_inventory.json','crates/motion-host/Cargo.toml'):
 members['source/'+name]=(WORK/name).read_bytes()
members['archive-controller.py']=Path(__file__).read_bytes()
data=WORK/'engineering/validation/data';archive=data/'depth75-reference-ci-v2.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in members.items():z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
 for name,raw in members.items():assert z.read(name)==raw
manifest=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),head=r['head'],
 actual_reference_controls=dict(passed=11,failed=0,skipped=0),complete_ci_tools=dict(total=146,passed=145,failed=0,original_skipped=1),
 environment=r['yaml_environment'],limits=['Existing E-drive PyYAML6.0.3 supplied to this invocation; no install or source/test-expectation change',
 'Original missing-dependency invocation remains failed in its own archive',
 'The11 reference controls are included in146 full-suite entries; they are not157 unique tests',
 'Native default discovery and final-head cross-platform qualification remain separate'],
 members=[dict(path=name,bytes=len(raw),sha256=sha(raw)) for name,raw in members.items()])
(data/'depth75-reference-ci-v2.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:manifest[k] for k in ('archive','bytes','sha256')}))
