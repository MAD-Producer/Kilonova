from pathlib import Path
import subprocess,json,hashlib,time,importlib.util
root=Path('E:/Dev/aem');work=root/'.worktrees/viewer-guides';out=root/'.tools/viewer-guides';stage=out/'snap-stage-11'
r=json.loads((stage/'receipt.json').read_text(encoding='utf8'));n=json.loads((stage/'native-verified.json').read_text(encoding='utf8'))
assert r['source_unchanged'] and r['build_exit_code']==0 and all(x['exit_code']==0 for x in r['runs']) and n['export_rgba_equal']
folder=out/'queue-integration-check-01';folder.mkdir(exist_ok=False)
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in r['sources']}
assert freeze()==r['sources']
spec=importlib.util.spec_from_file_location('ci_desktop_queue_gate',work/'tools/ci_desktop.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.verify_style_consumers(work/'desktop/app/src/panels')
features='motion-host/diagnostics,motion-host/ai-depth,motion-host/gpu-tests,motion-ui/gpu-tests,motion-desktop/gpu-tests,motion-desktop/ffmpeg,motion-desktop-media/gpu-tests,motion-graph/gpu-tests,motion-render/gpu-tests'
command=['cargo','check','--workspace','--exclude','motion-android','--all-targets','--features',features,'--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1']
start=time.monotonic();print('Frozen queue/guide integration all-targets check started.',flush=True)
with (folder/'all-targets.log').open('w',encoding='utf8') as sink:result=subprocess.run(command,cwd=work,stdout=sink,stderr=subprocess.STDOUT)
record=dict(head=r['head'],base_main=r['base_main'],binary_sha256=r['binary_sha256'],style_consumers_passed=True,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),command=command,source_unchanged=freeze()==r['sources'],scope='Current2227 renderqueue plus guides all-targets compilation; native11 actual worker/pixels/export evidence separate. Unchanged model persistence/history runs remain historical at their recorded commits.')
(folder/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8');print(json.dumps(record),flush=True)
assert result.returncode==0 and record['source_unchanged']
