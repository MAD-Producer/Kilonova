from pathlib import Path
import subprocess,hashlib,json,time,re,sys,os
root=Path('E:/Dev/aem');work=root/'.worktrees/viewer-guides';out=root/'.tools/viewer-guides'
attempt=sys.argv[1];folder=out/('snap-stage-'+attempt);folder.mkdir(exist_ok=False)
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','*.rs','*.wgsl','*.toml','Cargo.lock','desktop/ui/styles/dark.json'],cwd=work,text=True).splitlines()
freeze=lambda:{p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
sources=freeze();roots=[p for p in paths if p.endswith('/src/lib.rs')]+['desktop/app/src/main.rs'] if attempt in ['01','09','10','11'] else ['desktop/app/src/main.rs']
for p in roots:(work/p).touch()
command=['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--config','profile.dev.package.motion-desktop.debug=0',
 '--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1','--no-run']
start=time.monotonic();print('Frozen-source current-main snap/worker regression build started.',flush=True)
with (folder/'build.log').open('w',encoding='utf8') as sink: build=subprocess.run(command,cwd=work,stdout=sink,stderr=subprocess.STDOUT)
records=[];binary_digest=None
if build.returncode==0:
 text=(folder/'build.log').read_text(encoding='utf8');binary=Path(re.search(r'Executable unittests[^\n]*\(([^\n]+\.exe)\)',text).group(1));binary_digest=hashlib.sha256(binary.read_bytes()).hexdigest()
 filters=[('guides','panels::viewer_guides::'),('transforms','panels::transform_controls::'),('composition','panels::composition::tests::')]
 if int(attempt)>=5:filters.append(('paths','panels::path_controls::'))
 for name,filter in filters:
  env=os.environ.copy();env['MOTION_GUIDE_WORKER_FAULT_ARTIFACTS']=str(folder/'worker-default-info');env['MOTION_VIEWER_GUIDE_FAULT_ARTIFACTS']=str(folder/'ui-default-info')
  started=time.monotonic()
  with (folder/(name+'.log')).open('w',encoding='utf8') as sink: result=subprocess.run([str(binary),filter,'--nocapture','--test-threads=1'],cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT)
  text=(folder/(name+'.log')).read_text(encoding='utf8');summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
  record=dict(name=name,filter=filter,exit_code=result.returncode,seconds=round(time.monotonic()-started,2),summary=summary)
  records.append(record);print(json.dumps(record),flush=True)
 if all(r['exit_code']==0 for r in records) and attempt!='01':
  env=os.environ.copy();env['MOTION_GUIDES_NATIVE_ARTIFACTS']=str(folder/'native')
  started=time.monotonic();name='panels::viewer_guides::native_tests::viewer_guides_native_main_float_dpi_transactions_pixels_and_export'
  with (folder/'native.log').open('w',encoding='utf8') as sink: result=subprocess.run([str(binary),'--exact',name,'--ignored','--nocapture','--test-threads=1'],cwd=work,env=env,stdout=sink,stderr=subprocess.STDOUT)
  text=(folder/'native.log').read_text(encoding='utf8');summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
  record=dict(name='native',filter=name,exit_code=result.returncode,seconds=round(time.monotonic()-started,2),summary=summary)
  records.append(record);print(json.dumps(record),flush=True)
record=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),base_main=subprocess.check_output(['git','merge-base','HEAD','origin/main'],cwd=work,text=True).strip(),
 build_exit_code=build.returncode,command=command,seconds=round(time.monotonic()-start,2),runs=records,binary_sha256=binary_digest,
 source_unchanged=freeze()==sources,sources=sources,forced_roots=roots,
 scope='Actual transform commands/host geometry and serial-worker guide transactions; native guide surfaces/export are counted only when the explicit native run succeeds and measurements exist.')
(folder/'receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in record.items() if k not in ['sources','command','forced_roots']}),flush=True)
expected_runs=(3 if attempt=='01' else 4)+(1 if int(attempt)>=5 else 0)
raise SystemExit(0 if build.returncode==0 and record['source_unchanged'] and len(records)==expected_runs and all(r['exit_code']==0 for r in records) else 1)
