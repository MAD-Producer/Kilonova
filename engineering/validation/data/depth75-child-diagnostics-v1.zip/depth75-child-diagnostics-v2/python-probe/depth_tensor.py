import faulthandler, sys
assert faulthandler.is_enabled(), 'owned Python fault observer was not enabled'
sys.stderr.write('owned-stack-observation-control\n')
sys.stderr.flush()
faulthandler.dump_traceback(file=sys.stderr, all_threads=True)
raise RuntimeError('original-owned-python-exit-sentinel')
