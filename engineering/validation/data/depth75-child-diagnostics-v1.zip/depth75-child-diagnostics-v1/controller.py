"""One owned host regression, Python observation probe and installed-model cache control."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,traceback
from datetime import datetime,timezone
ROOT=Path('E:/Dev/aem');ART=ROOT/'artifacts/pr-queue'
WORK=ROOT/'.worktrees/depth-retained-context75'
OUT=ART/'depth75-child-diagnostics-v1'
TARGET=ROOT/'target/depth-wgsl-cache75-contract'
CP=ART/'depth75-resume-current.json'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=WORK,text=True).strip()
def source():
    names=set(git('diff','--name-only').splitlines())
    names.update(git('ls-files','--others','--exclude-standard').splitlines())
    assert len(names)==5 and not any('/panels/' in n for n in names)
    return {n:sha(WORK/n) for n in sorted(names)}
state=read(CP)
assert state['versionedCache75']['activeController'] is None and not state['versionedCache75']['ownHeavyWorkloads']
assert read(ART/'depth75-live-cache-v1/session-consumed.json')['exit_code']==1
assert read(ART/'depth75-live-cache-v2/session-consumed.json')['exit_code']==0
assert shutil.disk_usage(ROOT).free>=10<<30
head=git('rev-parse','HEAD');bindings=source()
assert head=='84de8b11af53649b24f55cc56de079d7a7516b56'
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__,OUT/'controller.py')
for name in bindings:
    dest=OUT/'frozen-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WORK/name,dest)
env=os.environ.copy();env.pop('MOTION_LOG',None)
ffmpeg=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),
    CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
    TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'appdata'),
    LIBCLANG_PATH=str(ROOT/'.tools/python-libclang/clang/native'),PYTHONDONTWRITEBYTECODE='1',
    FFMPEG_DIR=str(ffmpeg),FFMPEG_INCLUDE_DIR=str(ffmpeg/'include'),FFMPEG_LIB_DIR=str(ffmpeg/'lib'))
env['PATH']=str(ffmpeg/'bin')+os.pathsep+env['PATH'];Path(env['LOCALAPPDATA']).mkdir()
fixture=read(ART/'depth75-live-service-v3/fixture.json')
write(OUT/'python-fixture.json',dict(python=fixture['python'],output=str(OUT/'python-probe')))
env['MOTION_DEPTH_PYTHON_DIAGNOSTIC_FIXTURE']=str(OUT/'python-fixture.json')
cache_root=OUT/'cache';cache_root.mkdir()
write(cache_root/'fixture.json',dict(fixture,scratch=str(cache_root/'scratch'),evidence=str(cache_root/'evidence.json')))
env['MOTION_DEPTH_RETAINED_TEST_FIXTURE']=str(cache_root/'fixture.json')
report=dict(status='running',source_head=head,changed_source_sha256=bindings,commands=[],
    started_utc=datetime.now(timezone.utc).isoformat(),
    limits=['Original79852 Python access violation retained and not retried or declared fixed',
        'Actual Python observer enablement/explicit stack/exception exit is not native access-violation reproduction',
        'Cache control checks changed diagnostic transport with installed real model, not source-wide acceptance',
        'No Android, panels, downloads, debugger, overlay inspection, process workaround or threshold change'])
state['versionedCache75'].update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(
    kind='host regression and owned child diagnostic controls',output=str(OUT),sourceFrozen=True)])
write(CP,state)
def save():write(OUT/'receipt.json',report)
def frozen():return source()==bindings and git('rev-parse','HEAD')==head
def command(label,args,timeout=None):
    item=dict(label=label,args=args,timeout_seconds=timeout,started_utc=datetime.now(timezone.utc).isoformat())
    report['commands'].append(item);save();began=time.monotonic()
    with (OUT/(label+'.stdout.log')).open('wb') as stdout,(OUT/(label+'.stderr.log')).open('wb') as stderr:
        result=subprocess.run(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr,timeout=timeout)
    item.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-began);save()
    assert result.returncode==0 and frozen(),item
start=time.monotonic()
try:
    command('host-lib',['cargo','test','-p','motion-host','--features','ai-depth','--lib','--locked','--offline','--','--test-threads=1'])
    command('python-probe',['cargo','test','-p','motion-host','--features','ai-depth','--lib',
        'depth::wgsl::tests::actual_owned_python_enables_fault_observation_and_retains_stack_and_exit_cause',
        '--locked','--offline','--','--ignored','--exact','--test-threads=1'],timeout=120)
    observed=read(OUT/'python-probe/receipt.json')
    assert [row['mode'] for row in observed['outcomes']]==['plain','resolve','attest']
    command('worker-build',['cargo','build','-p','motion-desktop','--features',
        'motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth',
        '--bin','motion-depth-wgsl','--locked','--offline'])
    report['worker_sha256']=sha(Path(fixture['worker']))
    command('actual-cache',['cargo','test','-p','motion-host','--features','ai-depth',
        '--test','depth_wgsl_retained','actual_retained_cache_reopens_without_inference_and_isolates_cold_execution',
        '--locked','--offline','--','--ignored','--exact','--test-threads=1'],timeout=300)
    evidence=read(cache_root/'evidence.json')
    assert evidence['inference_calls']==2 and evidence['cache_entries']==2
    assert evidence['all_owned_service_directories_removed']
    assert 'content SHA-256 differs' in (cache_root/'logs/motion-studio.log').read_text(encoding='utf-8')
    assert 'content SHA-256 differs' in (OUT/'actual-cache.stderr.log').read_text(encoding='utf-8')
    report['status']='host_regression_owned_python_observation_and_real_cache_controls_passed'
except BaseException:
    report.update(status='failed_original_outcome_retained',failure=traceback.format_exc())
finally:
    report.update(source_unchanged=frozen(),elapsed_seconds=time.monotonic()-start,completed_utc=datetime.now(timezone.utc).isoformat());save()
    print(json.dumps(dict(status=report['status'],commands=report['commands'],source_unchanged=report['source_unchanged'])))
raise SystemExit(0 if report['status']=='host_regression_owned_python_observation_and_real_cache_controls_passed' else 1)
