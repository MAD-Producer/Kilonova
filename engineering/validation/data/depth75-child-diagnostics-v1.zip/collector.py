"""Archive the original host failure separately from scoped diagnostic controls."""
from pathlib import Path
import hashlib, json, zipfile
ART = Path('E:/Dev/aem/artifacts/pr-queue')
WORK = Path('E:/Dev/aem/.worktrees/depth-retained-context75')
OUT = ART/'depth75-child-diagnostics-public-v1'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b): return hashlib.sha256(b).hexdigest()
members = {}
for name, session, code in [('depth75-child-diagnostics-v1',14287,1),
                            ('depth75-child-diagnostics-v2',24071,0)]:
    root = ART/name
    consumed = read(root/'session-consumed.json')
    receipt = read(root/'receipt.json')
    assert consumed['session'] == session and consumed['consumed'] and consumed['exit_code'] == code
    assert receipt['source_unchanged']
    for path in root.rglob('*'):
        relative = path.relative_to(root)
        # Exclude cache payloads and private runtime state. Include authored
        # sources, commands, receipts and the actual raw test/file logs only.
        if path.is_file() and path.suffix in {'.rs','.py','.json','.log'} and not any(
                part in {'appdata','scratch'} for part in relative.parts):
            assert path.stat().st_size < 32<<20
            members[f'{name}/{relative.as_posix()}'] = path.read_bytes()
original = read(ART/'depth75-child-diagnostics-v1/receipt.json')
assert len(original['commands']) == 1 and original['commands'][0]['exit_code'] == 3221225477
raw = (ART/'depth75-child-diagnostics-v1/host-lib.stderr.log').read_text(encoding='utf-8')
assert '0xc0000005' in raw and 'STATUS_ACCESS_VIOLATION' in raw
last = read(ART/'depth75-child-diagnostics-v2/receipt.json')
assert last['status'] == 'depth_components_python_observation_cache_passed_broad_failure_retained'
assert [c['label'] for c in last['commands']] == ['depth-components','python-probe','worker-build','actual-cache']
assert all(c['exit_code'] == 0 for c in last['commands'])
for name, digest in last['changed_source_sha256'].items():
    assert sha((WORK/name).read_bytes()) == digest
probe = read(ART/'depth75-child-diagnostics-v2/python-probe/receipt.json')
assert [o['mode'] for o in probe['outcomes']] == ['plain','resolve','attest']
for o in probe['outcomes']:
    assert all(s in o['original_cause'] for s in ['owned-stack-observation-control',
        'depth_tensor.py','original-owned-python-exit-sentinel','response= stderr='])
cache = read(ART/'depth75-child-diagnostics-v2/cache/evidence.json')
assert cache['inference_calls'] == 2 and cache['cache_entries'] == 2
assert cache['all_owned_service_directories_removed']
for filename in ['actual-cache.stderr.log','cache/logs/motion-studio.log']:
    assert 'content SHA-256 differs' in (ART/'depth75-child-diagnostics-v2'/filename).read_text(encoding='utf-8')
members['collector.py'] = Path(__file__).read_bytes()
OUT.mkdir(exist_ok=False)
archive = OUT/'depth75-child-diagnostics-v1.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name, data in sorted(members.items()): z.writestr(name,data)
manifest = dict(schema=1, archive=archive.name, bytes=archive.stat().st_size,
    sha256=sha(archive.read_bytes()),
    scope='Original full-host native failure and separate depth/Python/cache controls; no native-fault fix or full-source acceptance',
    members={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())})
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(members)
    for name,data in members.items():
        assert z.read(name) == data and sha(z.read(name)) == manifest['members'][name]['sha256']
(OUT/'depth75-child-diagnostics-v1.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
print(json.dumps(dict(bytes=manifest['bytes'],sha256=manifest['sha256'],members=len(members))))
