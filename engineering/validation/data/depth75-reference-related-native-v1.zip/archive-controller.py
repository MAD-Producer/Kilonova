"""Retain full related native target coverage and default example discovery."""
from pathlib import Path
from collections import Counter
import hashlib,json,zipfile
ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75';OUT=BASE/'depth75-reference-related-native-v1'
assert json.loads((OUT/'session-consumed.json').read_text())==dict(session=47248,consumed=True,exit_code=0)
r=json.loads((OUT/'receipt.json').read_text());assert r['status']=='all_related_native_targets_default_reference_controls_and_actual_build_passed' and r['source_unchanged']
assert r['full_target_coverage'] and Counter(r['expected_targets'])==Counter(r['observed_targets'])
assert len(r['expected_targets'])==176 and r['totals']['failed']==r['totals']['filtered']==0 and r['totals']['original_ignored']==3
assert all(row['exit_code']==0 for row in r['stages'])
assert 'motion-host::example::crates/motion-host/examples/depth_reference.rs' in r['observed_targets']
def sha(raw):return hashlib.sha256(raw).hexdigest()
for name,digest in r['source_sha256'].items():assert sha((WORK/name).read_bytes())==digest,name
members={name:(OUT/name).read_bytes() for name in ('controller.py','receipt.json','session-consumed.json','cargo-metadata.json',
 'changed-crates.stdout.log','changed-crates.stderr.log','actual-product-build.stdout.log','actual-product-build.stderr.log')}
for index,row in enumerate(r['source_bound_invocations']):
 path=Path(row['executable']).with_suffix('.d');raw=path.read_bytes();assert sha(raw)==row['dep_info_sha256']
 members[f'dep-info/{index:03}.d']=raw
for name in ('crates/motion-host/Cargo.toml','crates/motion-host/examples/depth_reference.rs'):
 members['source/'+name]=(WORK/name).read_bytes()
members['archive-controller.py']=Path(__file__).read_bytes()
data=WORK/'engineering/validation/data';archive=data/'depth75-reference-related-native-v1.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in members.items():z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(members)
 for name,raw in members.items():assert z.read(name)==raw
manifest=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),head=r['head'],
 targets=len(r['expected_targets']),source_bound_executables=len(r['source_bound_invocations']),totals=r['totals'],
 default_reference_example='observed_actual_test_harness',named_controls=r['qualified_named_controls'],
 limits=['Original full command, GPU/FFmpeg features, assertions, ignores, deadlines and no-fail-fast preserved',
 'Default test routing added the three reference caller controls; optional inference was not run by these analytic tests',
 'Original6d full-command fixture failure remains failed in its separate archive',
 'Three related crates and actual binaries, not the whole maintained workspace or new-head cross-platform CI'],
 members=[dict(path=name,bytes=len(raw),sha256=sha(raw)) for name,raw in members.items()])
(data/'depth75-reference-related-native-v1.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:manifest[k] for k in ('archive','bytes','sha256','totals')}))
