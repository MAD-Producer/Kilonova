E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\color_output-ea910d54b474a2de.d: crates\motion-render\tests\color_output.rs

E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\color_output-ea910d54b474a2de.exe: crates\motion-render\tests\color_output.rs

crates\motion-render\tests\color_output.rs:
