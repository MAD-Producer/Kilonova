E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\effects-02dacc370756f7dd.d: crates\motion-render\tests\effects.rs

E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\effects-02dacc370756f7dd.exe: crates\motion-render\tests\effects.rs

crates\motion-render\tests\effects.rs:
