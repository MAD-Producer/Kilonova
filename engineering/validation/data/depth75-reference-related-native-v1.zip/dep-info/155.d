E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\tracking_lens-5da74b150d877a41.d: crates\motion-render\tests\tracking_lens.rs crates\motion-render\tests\tracking_lens\ownership.rs crates\motion-render\tests\tracking_lens\photographed.rs crates\motion-render\tests\tracking_lens\..\..\..\motion-model\tests\support\photographed_camera.rs crates\motion-render\tests\tracking_lens\..\..\..\motion-model\tests\support\tracking_camera.rs crates\motion-render\tests\tracking_lens\..\..\..\motion-model\tests\support\tracking_plane.rs crates\motion-render\tests\tracking_lens\relaxation.rs crates\motion-render\tests\tracking_lens\resources.rs crates\motion-render\tests\tracking_lens\routing.rs crates\motion-render\tests\tracking_lens\video.rs crates\motion-render\tests\tracking_lens\..\..\..\motion-model\tests\support\../fixtures/tracking-photographs.json crates\motion-render\tests\tracking_lens\../../../motion-model/tests/fixtures/tracking-opencv-inverse.json

E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\tracking_lens-5da74b150d877a41.exe: crates\motion-render\tests\tracking_lens.rs crates\motion-render\tests\tracking_lens\ownership.rs crates\motion-render\tests\tracking_lens\photographed.rs crates\motion-render\tests\tracking_lens\..\..\..\motion-model\tests\support\photographed_camera.rs crates\motion-render\tests\tracking_lens\..\..\..\motion-model\tests\support\tracking_camera.rs crates\motion-render\tests\tracking_lens\..\..\..\motion-model\tests\support\tracking_plane.rs crates\motion-render\tests\tracking_lens\relaxation.rs crates\motion-render\tests\tracking_lens\resources.rs crates\motion-render\tests\tracking_lens\routing.rs crates\motion-render\tests\tracking_lens\video.rs crates\motion-render\tests\tracking_lens\..\..\..\motion-model\tests\support\../fixtures/tracking-photographs.json crates\motion-render\tests\tracking_lens\../../../motion-model/tests/fixtures/tracking-opencv-inverse.json

crates\motion-render\tests\tracking_lens.rs:
crates\motion-render\tests\tracking_lens\ownership.rs:
crates\motion-render\tests\tracking_lens\photographed.rs:
crates\motion-render\tests\tracking_lens\..\..\..\motion-model\tests\support\photographed_camera.rs:
crates\motion-render\tests\tracking_lens\..\..\..\motion-model\tests\support\tracking_camera.rs:
crates\motion-render\tests\tracking_lens\..\..\..\motion-model\tests\support\tracking_plane.rs:
crates\motion-render\tests\tracking_lens\relaxation.rs:
crates\motion-render\tests\tracking_lens\resources.rs:
crates\motion-render\tests\tracking_lens\routing.rs:
crates\motion-render\tests\tracking_lens\video.rs:
crates\motion-render\tests\tracking_lens\..\..\..\motion-model\tests\support\../fixtures/tracking-photographs.json:
crates\motion-render\tests\tracking_lens\../../../motion-model/tests/fixtures/tracking-opencv-inverse.json:
