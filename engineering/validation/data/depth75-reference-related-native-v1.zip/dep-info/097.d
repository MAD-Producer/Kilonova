E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\image_resources-cf90ea43c111fd83.d: crates\motion-render\tests\image_resources.rs crates\motion-render\tests\fixtures/image-resources-adam7.png

E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\image_resources-cf90ea43c111fd83.exe: crates\motion-render\tests\image_resources.rs crates\motion-render\tests\fixtures/image-resources-adam7.png

crates\motion-render\tests\image_resources.rs:
crates\motion-render\tests\fixtures/image-resources-adam7.png:
