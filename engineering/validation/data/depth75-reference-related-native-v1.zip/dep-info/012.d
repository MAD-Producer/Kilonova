E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\professional_screen_photo-3d00674e3131ee0a.d: crates\motion-desktop-media\tests\professional_screen_photo.rs crates\motion-desktop-media\tests\fixtures/professional-screen/destiny-screen.png

E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\professional_screen_photo-3d00674e3131ee0a.exe: crates\motion-desktop-media\tests\professional_screen_photo.rs crates\motion-desktop-media\tests\fixtures/professional-screen/destiny-screen.png

crates\motion-desktop-media\tests\professional_screen_photo.rs:
crates\motion-desktop-media\tests\fixtures/professional-screen/destiny-screen.png:
