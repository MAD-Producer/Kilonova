E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\color_image_processor-094b0a260872649d.d: crates\motion-render\tests\color_image_processor.rs crates\motion-render\tests\../../motion-effects/tests/color_processor/reference.json

E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\color_image_processor-094b0a260872649d.exe: crates\motion-render\tests\color_image_processor.rs crates\motion-render\tests\../../motion-effects/tests/color_processor/reference.json

crates\motion-render\tests\color_image_processor.rs:
crates\motion-render\tests\../../motion-effects/tests/color_processor/reference.json:
