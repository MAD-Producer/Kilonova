E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\vector_error_boundaries-d323f1692782d3b4.d: crates\motion-render\tests\vector_error_boundaries.rs crates\motion-render\tests\support\vector_error_fixture.rs

E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\vector_error_boundaries-d323f1692782d3b4.exe: crates\motion-render\tests\vector_error_boundaries.rs crates\motion-render\tests\support\vector_error_fixture.rs

crates\motion-render\tests\vector_error_boundaries.rs:
crates\motion-render\tests\support\vector_error_fixture.rs:
