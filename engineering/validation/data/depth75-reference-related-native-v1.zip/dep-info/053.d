E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\color_processor-658ce4f8cfa50093.d: crates\motion-render\tests\color_processor.rs crates\motion-render\tests\../../motion-effects/tests/color_processor/reference.json

E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\color_processor-658ce4f8cfa50093.exe: crates\motion-render\tests\color_processor.rs crates\motion-render\tests\../../motion-effects/tests/color_processor/reference.json

crates\motion-render\tests\color_processor.rs:
crates\motion-render\tests\../../motion-effects/tests/color_processor/reference.json:
