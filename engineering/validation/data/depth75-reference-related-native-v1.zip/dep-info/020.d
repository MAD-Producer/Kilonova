E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\depth_capability-dea3bf44ba48983d.d: crates\motion-host\tests\depth_capability.rs crates\motion-host\tests\depth_capability\bindings.rs crates\motion-host\tests\depth_capability\file_output.rs crates\motion-host\tests\..\..\..\desktop\app\src\logging\sink.rs

E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\depth_capability-dea3bf44ba48983d.exe: crates\motion-host\tests\depth_capability.rs crates\motion-host\tests\depth_capability\bindings.rs crates\motion-host\tests\depth_capability\file_output.rs crates\motion-host\tests\..\..\..\desktop\app\src\logging\sink.rs

crates\motion-host\tests\depth_capability.rs:
crates\motion-host\tests\depth_capability\bindings.rs:
crates\motion-host\tests\depth_capability\file_output.rs:
crates\motion-host\tests\..\..\..\desktop\app\src\logging\sink.rs:
