E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\image_capture-c0bdf6236f50e005.d: crates\motion-render\tests\image_capture.rs

E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\image_capture-c0bdf6236f50e005.exe: crates\motion-render\tests\image_capture.rs

crates\motion-render\tests\image_capture.rs:
