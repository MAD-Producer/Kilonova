E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\examples\depth_reference-59754846ad5dc6cd.d: crates\motion-host\examples\depth_reference.rs crates\motion-host\examples\..\..\..\desktop\app\src\logging\sink.rs

E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\examples\depth_reference-59754846ad5dc6cd.exe: crates\motion-host\examples\depth_reference.rs crates\motion-host\examples\..\..\..\desktop\app\src\logging\sink.rs

crates\motion-host\examples\depth_reference.rs:
crates\motion-host\examples\..\..\..\desktop\app\src\logging\sink.rs:
