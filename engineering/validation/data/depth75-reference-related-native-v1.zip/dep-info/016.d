E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\asset_registration-69b2240b61b1fbe6.d: crates\motion-host\tests\asset_registration.rs

E:\Dev\aem\target\depth-wgsl-cache75-contract\debug\deps\asset_registration-69b2240b61b1fbe6.exe: crates\motion-host\tests\asset_registration.rs

crates\motion-host\tests\asset_registration.rs:
