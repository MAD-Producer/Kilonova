"""Read back all retained learned outputs before creating pixel-free evidence."""
from pathlib import Path
import hashlib, json, subprocess, zipfile
ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
ACTUAL=BASE/'depth75-reference-remaining-v1';EQUIV=BASE/'depth75-reference-equivalence-v1'
assert json.loads((ACTUAL/'session-consumed.json').read_text())==dict(session=42461,consumed=True,exit_code=0)
a=json.loads((ACTUAL/'receipt.json').read_text());b=json.loads((EQUIV/'receipt.json').read_text())
assert a['status']=='remaining_five_routes_completed_three_measured_two_explicitly_unavailable' and a['source_unchanged']
assert b['status']=='all32_source_matched_cpu518_wgsl518_numerical_comparisons_passed'
assert (EQUIV/'tool-completed.json').is_file()
assert a['head']==b['source_head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
def sha(raw):return hashlib.sha256(raw).hexdigest()
for name,digest in a['source_sha256'].items():assert sha((WORK/name).read_bytes())==digest,name
members={name:(ACTUAL/name).read_bytes() for name in ('controller.py','receipt.json','session-consumed.json')}
assert [row['name'] for row in a['stages']]==['wgsl266','onnx392','wgsl392','onnx518','wgsl518']
for stage in a['stages']:
 name=stage['name'];root=ACTUAL/name
 for filename in (name+'.stdout.log',name+'.stderr.log',name+'/measurements.json',name+'/logs/motion-studio.log'):
  members[filename]=(ACTUAL/filename).read_bytes()
 assert not (ACTUAL/(name+'.stdout.log')).read_bytes()
 if stage['status']=='explicitly_unavailable_no_inference_or_fallback':continue
 members[name+'/quality.json']=(root/'quality.json').read_bytes()
 measured=json.loads((root/'measurements.json').read_text());assert len(measured['samples'])==32
 for row in measured['samples']:
  raw=(root/row['output']['filename']).read_bytes()
  assert len(raw)==row['output']['bytes']==640*480*4 and sha(raw)==row['output']['sha256']
for name in ('controller.py','receipt.json','tool-completed.json'):members['equivalence/'+name]=(EQUIV/name).read_bytes()
members['archive-controller.py']=Path(__file__).read_bytes()
data=WORK/'engineering/validation/data';archive=data/'depth75-reference-remaining-v1.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(members.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
 assert sorted(z.namelist())==sorted(members)
 for name,raw in members.items():assert z.read(name)==raw
manifest=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),head=a['head'],
 cohorts=[{k:stage.get(k) for k in ('name','status','cause','actual_summary','quality_aggregate','calibration')} for stage in a['stages']],
 same_weight_backend_comparison={k:b[k] for k in ('status','original_maximum_bound','original_mean_bound','maximum_observed','maximum_frame_mean')},
 limits=a['limits']+['All96 available-route raw outputs independently read back before archive; no arrays redistributed',
 'Same-weight backend numerical agreement is separate from independently sensed quality'],
 members=[dict(path=name,bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(members.items())])
(data/'depth75-reference-remaining-v1.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:manifest[k] for k in ('archive','bytes','sha256')}))
