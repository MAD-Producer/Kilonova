"""Finish the predeclared six-route cohort, including explicit unavailable routes.

Unavailable WGSL resolutions are refusals, never successful inference or fallback.
Each available route receives all original32 frames exactly once, with the same
8-frame fit/24-frame evaluation and no per-frame fitting or residual selection.
"""
from pathlib import Path
from datetime import datetime, timezone
import array, hashlib, json, os, shutil, subprocess, sys, traceback
ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
NATIVE=BASE/'depth75-reference-probe-native-v2';FIRST=BASE/'depth75-reference-onnx266-v2'
INPUTS=BASE/'depth75-reference-inputs-v1';OUT=BASE/'depth75-reference-remaining-v1'
TARGET=ROOT/'target/depth-wgsl-cache75-contract'
assert json.loads((FIRST/'session-consumed.json').read_text())==dict(session=76813,consumed=True,exit_code=0)
first=json.loads((FIRST/'receipt.json').read_text());native=json.loads((NATIVE/'receipt.json').read_text())
assert first['status']=='actual32_onnx266_measurements_and24_held_out_sensor_reduction_completed' and first['source_unchanged']
assert native['source_unchanged'] and native['status']=='three_controls_actual_build_and_default_cli_source_refusal_passed'
assert not json.loads((BASE/'depth75-resume-current.json').read_text())['versionedCache75']['ownHeavyWorkloads']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
assert not subprocess.check_output(['git','diff','--name-only',native['head'],'HEAD','--','crates','desktop','vendor','Cargo.toml','Cargo.lock','tools'],cwd=WORK)
assert shutil.disk_usage(ROOT).free>=10<<30 and not OUT.exists()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def hashes():return {name:sha(WORK/name) for name in paths}
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(TEMP=str(OUT),TMP=str(OUT),LOCALAPPDATA=str(OUT/'appdata'),PYTHONDONTWRITEBYTECODE='1')
env['PATH']=str(ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')+';'+env['PATH']
report=dict(status='running',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),
 source_sha256=hashes(),started_utc=datetime.now(timezone.utc).isoformat(),stages=[],
 order=[['wgsl',266],['onnx',392],['wgsl',392],['onnx',518],['wgsl',518]],
 limits=['Original CPU266 predecessor retained; complete fixed32 source pairs, first8fit and next24heldout for available routes',
 'WGSL266/392 are currently unimplemented; explicit original refusals only, no substitute backend/model/program',
 'No retries, per-frame fit, residual clipping/trimming, sample replacement or quality-tier decision',
 'No additional transition-jump, complete memory/thermal or arbitrary-domain certification',
 'No source/panel edit, cleanup, download or concurrent own heavy workload'])
def save():
 p=OUT/'receipt.pending.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(p,OUT/'receipt.json')
save()
try:
 preparation=json.loads((INPUTS/'receipt.json').read_text())
 assert preparation['source_unchanged'] and sha(INPUTS/'inputs.json')==preparation['inputs_sha256']
 inputs=json.loads((INPUTS/'inputs.json').read_text());assert len(inputs)==32
 for row in inputs:
  for kind in ('rgb','depth'):
   identity=row[kind+'_input'];assert sha(INPUTS/identity['filename'])==identity['sha256']
 driver=TARGET/'debug/examples/depth_reference.exe';assert sha(driver)==native['driver_sha256']==first['driver_sha256']
 report.update(driver_sha256=sha(driver),inputs_sha256=preparation['inputs_sha256']);save()
 sys.path.insert(0,str(WORK/'tools'));import depth_reference_metrics as metrics
 for backend,side in report['order']:
  name=f'{backend}{side}';root=OUT/name
  model=BASE/f'depth75-resolution-models-v1/{side}/export/depth_anything_v2_vits_{side}.onnx'
  manifest=json.loads(model.with_name('model.json').read_text())
  assert sha(model)==manifest['sha256'] and manifest['processing']==f'dav2-small-rgb8-letterbox{side}-align-corners-relative-v1'
  unavailable=backend=='wgsl' and side!=518
  stage=dict(name=name,phase='actual_inference',model_sha256=sha(model),expected_exit=1 if unavailable else 0)
  command=[driver,backend,ROOT/'.tools/ai-depth74/venv/Scripts/python.exe',model,
   BASE/'depth75-wgsl-cache-resources-v2/program.json',TARGET/'debug/motion-depth-wgsl.exe',INPUTS,root]
  stage['command']=[str(v) for v in command];report['stages'].append(stage);save()
  with (OUT/(name+'.stdout.log')).open('wb') as stdout,(OUT/(name+'.stderr.log')).open('wb') as stderr:
   child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);stage['pid']=child.pid;save();stage['exit_code']=child.wait()
  save();assert stage['exit_code']==stage['expected_exit'],(name,'original unexpected result retained, no retry')
  assert not (OUT/(name+'.stdout.log')).read_bytes()
  measured=json.loads((root/'measurements.json').read_text())
  if unavailable:
   cause='WGSL backend does not implement the requested model/processing identity'
   logs=(root/'logs/motion-studio.log').read_text();stderr=(OUT/(name+'.stderr.log')).read_text()
   assert measured['status']=='failed' and measured['samples']==[] and cause in measured['cause']
   assert cause in logs and cause in stderr and 'ERROR' in logs and 'ERROR' in stderr
   assert 'phase=capability_resolve' in logs and 'phase=native_inference' not in logs
   assert not list(root.glob('*.relative.f32le'))
   stage.update(phase='completed',status='explicitly_unavailable_no_inference_or_fallback',cause=measured['cause']);save();continue
  rows=measured['samples'];summary=measured['summary']
  assert measured['status']=='completed' and len(rows)==32
  assert summary['samples']==summary['submitted']==summary['completed']==32
  assert all(summary[name]==0 for name in ('failed','canceled','cache_hits','cache_misses','restored'))
  for i,(actual,source) in enumerate(zip(rows,inputs)):
   assert actual['index']==i and actual['split']==source['split']
   assert actual['key']['source']==dict(asset=750000+i,revision=1,pts=dict(ticks=source['rgb_ns'],timescale=1000000000))
   expected=hashlib.sha256(b'MotionStudio/depth/rgb8-srgb-opaque/v1\0'+(640).to_bytes(4,'little')+(480).to_bytes(4,'little')+(INPUTS/source['rgb_input']['filename']).read_bytes()).hexdigest()
   assert actual['input']['rgb_size']==[640,480] and bytes(actual['input']['rgb_sha256']).hex()==expected
   execution=actual['execution'];assert execution==summary['execution'] and execution['backend']==backend and execution['precision']=='float32'
   assert any(execution['runtime_sha256']) and any(execution['plan_sha256'])
   assert execution['provider']=='CPUExecutionProvider' if backend=='onnx' else execution['provider'].startswith('WGSL:Vulkan:')
   output=actual['output'];assert output['filename']==f'{i:02}.relative.f32le' and output['bytes']==640*480*4 and sha(root/output['filename'])==output['sha256']
   assert actual['worker_total_ns']>=actual['resolve_ns']>0
  stage.update(phase='held_out_reduction',actual_summary=summary,measurements_sha256=sha(root/'measurements.json'));save()
  def pair(index):
   prediction=array.array('f');prediction.frombytes((root/rows[index]['output']['filename']).read_bytes())
   sensor=array.array('H');sensor.frombytes((INPUTS/inputs[index]['depth_input']['filename']).read_bytes())
   assert prediction.itemsize==4 and sensor.itemsize==2
   if sys.byteorder!='little':prediction.byteswap();sensor.byteswap()
   assert len(prediction)==len(sensor)==640*480
   return prediction,sensor
  calibration=metrics.fit(pair(i) for i in range(8));assert calibration.reference_scale_inverse_metres==1.0
  evaluated=[]
  for i in range(8,32):
   prediction,sensor=pair(i);value=metrics.score(calibration,prediction,sensor);value['index']=i;evaluated.append(value)
  total=metrics.summarize(evaluated,calibration);assert total['frames']==24 and total['valid']+total['missing']==24*640*480
  quality=dict(status='initial_independent_sensor_measurement_not_a_qualification',model=manifest,execution=summary['execution'],
   calibration=calibration.__dict__,evaluation=evaluated,aggregate=total,maximum_additional_transition_jump=None,
   normalization='Exactly one inverse metre; fixed across all models/backends/frames',reference_sha256='e983d6830916e66dc4a46a71368046b149b283de87769690e7aa4e0b9483530c',limits=report['limits'])
  (root/'quality.json').write_text(json.dumps(quality,indent=2,allow_nan=False)+'\n',encoding='utf-8')
  stage.update(status='actual32_inferences_and24_held_out_sensor_reduction_completed',phase='completed',
   quality_sha256=sha(root/'quality.json'),quality_aggregate=total,calibration=calibration.__dict__);save()
 assert sha(driver)==report['driver_sha256']
 report.update(status='remaining_five_routes_completed_three_measured_two_explicitly_unavailable');save()
except BaseException:
 report['status']='failed_original_outputs_retained';report['cause']=traceback.format_exc();save();raise
finally:
 report['source_unchanged']=hashes()==report['source_sha256'];report['finished_utc']=datetime.now(timezone.utc).isoformat();save()
 assert report['source_unchanged'],'Source changed during original remaining model cohorts'
