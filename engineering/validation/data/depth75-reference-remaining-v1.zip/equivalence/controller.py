"""Compare all32 same-weight CPU518/WGSL518 outputs using the existing bounds."""
from pathlib import Path
import array, hashlib, json, math, subprocess, sys, traceback
ROOT=Path('E:/Dev/aem');BASE=ROOT/'artifacts/pr-queue';WORK=ROOT/'.worktrees/depth-wgsl-cache75'
PREVIOUS=BASE/'depth75-reference-remaining-v1';OUT=BASE/'depth75-reference-equivalence-v1'
assert json.loads((PREVIOUS/'session-consumed.json').read_text())==dict(session=42461,consumed=True,exit_code=0)
prior=json.loads((PREVIOUS/'receipt.json').read_text())
assert prior['status']=='remaining_five_routes_completed_three_measured_two_explicitly_unavailable' and prior['source_unchanged']
assert not json.loads((BASE/'depth75-resume-current.json').read_text())['versionedCache75']['ownHeavyWorkloads']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK) and not OUT.exists()
OUT.mkdir();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
report=dict(status='running',source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),
 prior_source=prior['head'],original_maximum_bound=2e-4,original_mean_bound=2e-5,comparisons=[],
 limits=['Original numerical bounds and CPU output-span normalization from measured-capability-v3 remain unchanged',
 'Every pixel of all32 source-matched frames; no clipping, trimming, affine refit, replacement or repeat inference',
 'This is same-weight backend equivalence, not independent sensor quality, temporal transition or tier admission'])
def save():(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save()
try:
 cpu=json.loads((PREVIOUS/'onnx518/measurements.json').read_text());gpu=json.loads((PREVIOUS/'wgsl518/measurements.json').read_text())
 assert cpu['status']==gpu['status']=='completed' and len(cpu['samples'])==len(gpu['samples'])==32
 assert cpu['summary']['model']==gpu['summary']['model']
 assert cpu['summary']['execution']['backend']=='onnx' and gpu['summary']['execution']['backend']=='wgsl'
 for i,(a,b) in enumerate(zip(cpu['samples'],gpu['samples'])):
  assert a['index']==b['index']==i and a['input']==b['input'] and a['key']==b['key'] and a['split']==b['split']
  arrays=[]
  for name,row in (('onnx518',a),('wgsl518',b)):
   path=PREVIOUS/name/row['output']['filename'];assert path.stat().st_size==640*480*4 and sha(path)==row['output']['sha256']
   values=array.array('f');values.frombytes(path.read_bytes());assert values.itemsize==4
   if sys.byteorder!='little':values.byteswap()
   assert len(values)==640*480 and all(map(math.isfinite,values));arrays.append(values)
  reference,actual=arrays;span=max(reference)-min(reference);assert span>1e-6
  residuals=[abs(x-y)/span for x,y in zip(reference,actual)]
  maximum=max(residuals);mean=math.fsum(residuals)/len(residuals)
  report['comparisons'].append(dict(index=i,values=len(residuals),reference_span=span,
   normalized_maximum=maximum,normalized_mean=mean,maximum_bound=2e-4,mean_bound=2e-5))
  save();assert maximum<=2e-4 and mean<=2e-5,(i,'original backend numerical bound exceeded')
 report.update(status='all32_source_matched_cpu518_wgsl518_numerical_comparisons_passed',
  maximum_observed=max(row['normalized_maximum'] for row in report['comparisons']),
  maximum_frame_mean=max(row['normalized_mean'] for row in report['comparisons']))
 save()
except BaseException:
 report['status']='failed_original_outputs_retained';report['cause']=traceback.format_exc();save();raise
