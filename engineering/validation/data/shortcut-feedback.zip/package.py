import hashlib, json, pathlib, subprocess, zipfile
root=pathlib.Path('E:/Dev/aem/artifacts/shortcut-feedback')
repo=pathlib.Path('E:/Dev/aem/.worktrees/shortcut-feedback')
def sha(data): return hashlib.sha256(data).hexdigest()
before=json.loads((root/'before-dispatch/records.json').read_text(encoding='utf-8'))
after=json.loads((root/'after-dispatch/records.json').read_text(encoding='utf-8'))
assert [r['name'] for r in before]==[r['name'] for r in after]
manifest=[]; objects={}
for stage,rows in [('before',before),('after',after)]:
 for row in rows:
  data=(root/f'{stage}-dispatch'/f"{row['name']}.txt").read_bytes()
  digest=sha(data);objects[digest]=data
  manifest.append(dict(stage=stage,name=row['name'],sha256=digest,bytes=len(data)))
for old,new in zip(before,after):
 assert (root/'before-dispatch'/f"{old['name']}.txt").read_bytes()==(root/'after-dispatch'/f"{new['name']}.txt").read_bytes()
 for k in ['allocation_requests','requested_bytes']: assert new[k]<=old[k],new['name']
results={'baseline':'712665126277a980fa3546a9d3b9ed415be68328','panels_final':{'passed':711,'failed':0,'ignored':28,'filtered_out':685},'scenarios_per_stage':128,
 'measured_frames_per_scenario':8,'warmup_frames_per_scenario':3,'identical_snapshots':128,
 'allocation_request_or_byte_regressions':0,'before':before,'after':after,
 'native_input_scope':'production normalized Input, not physical OS key injection',
 'executables':{},'sources':{}}
for name in ['before-runtime','probe-before-runtime','probe-after-runtime','verified-runtime','noffmpeg-runtime']:
 p=root/name/'acceptance.exe'
 if p.exists():results['executables'][name]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
files=['desktop/app/src/panels/mod.rs','desktop/app/src/panels/input_routes.rs',
 'desktop/app/src/panels/keyboard.rs','desktop/app/src/panels/keyboard_node_tests.rs',
 'desktop/app/src/panels/keyboard_redo_tests.rs','desktop/app/src/shortcuts.rs',
 'desktop/app/src/shortcuts/bindings.rs','desktop/app/src/shortcuts/redo_contract_tests.rs',
 'desktop/DEFAULT-KEY-BINDINGS.md','desktop/KEYBOARD-SHORTCUTS.md','desktop/README.md']
for name in files:results['sources'][name]=sha((repo/name).read_bytes())
(root/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
(root/'snapshot-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
destination=repo/'engineering/validation/data/shortcut-feedback.zip'
destination.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in root.glob('*.log'):z.write(p,'logs/'+p.name)
 for name in ['results.json','snapshot-manifest.json','probe.rs','reference/allocator.rs','package.py']:
  z.write(root/name,name)
 for stage in ['before','after']:z.write(root/f'{stage}-dispatch/records.json',f'{stage}-dispatch/records.json')
 for digest,data in objects.items():z.writestr('objects/'+digest+'.txt',data)
 for p in (root/'native-final').glob('*'):
  if p.is_file():z.write(p,'native/'+p.name)
 for name in files:z.write(repo/name,'final-source/'+name)
 for p in (root/'audio-symbol-inspection/logs').glob('*.log'):z.write(p,'audio-symbol-inspection/'+p.name)
 z.writestr('production.diff',subprocess.check_output(['git','diff','--',*files],cwd=repo))
data=destination.read_bytes()
print(json.dumps({'path':str(destination),'sha256':sha(data),'bytes':len(data),'objects':len(objects)}))
