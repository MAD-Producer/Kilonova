use super::*;
use motion_ui::InputSource;
#[path="E:/Dev/aem/artifacts/shortcut-feedback/reference/allocator.rs"]
mod counts;

fn layout(panels:&[Panel],depth:usize)->Node {
    if panels.len()==1 {return Node::dock(panels[0].dock());}
    let mid=panels.len()/2;
    Node::Split { edge:if depth%2==0 {dock::Edge::Left}else{dock::Edge::Top},split:0.5,
        first:Box::new(layout(&panels[..mid],depth+1)),second:Box::new(layout(&panels[mid..],depth+1)) }
}
#[test]
fn measure_real_panel_dispatch() {
    let root=std::path::PathBuf::from(std::env::var_os("MOTION_PANEL_DISPATCH_PROBE").unwrap());
    std::fs::create_dir_all(&root).unwrap();
    let project=motion_core::Project::new(640,360,30,120).unwrap();
    let state=serde_json::json!({"root":"input-probe","composition":motion_core::composition::MAIN_COMPOSITION,
        "frame":0,"revision":1,"project":project,"timeline_layers":project.timeline_layers(0.).unwrap()});
    let original=state.clone();
    let choices=[Panel::Info,Panel::Project,Panel::Preview,Panel::Align,Panel::Effects,Panel::Properties,Panel::Timeline,Panel::Nodes];
    let mut records=vec![];
    for locale in [Locale::En,Locale::Zh] {
        let mut atlas=TextAtlas::from_system_language(12.,locale==Locale::Zh).unwrap();
        for n in [1,2,4,8] {
            let layout=layout(&choices[..n],0);
            for mode in ["normal","composing","ime-consumed","focus-lost"] {
                for payload in [false,true] {
                    for pointer in [false,true] {
                        let name=format!("{locale:?}-{n}-{mode}-payload{payload}-press{pointer}");
                        let input=Input {mouse:[20.,160.],pressed:pointer.then_some((MouseButton::Left,[20.,160.])),
                            keys:if payload {vec![(Key::F8,Default::default());128]}else{vec![]},
                            key_repeats:if payload {vec![false;128]}else{vec![]},
                            held_keys:if payload {vec![Key::F8;128]}else{vec![]},
                            released_keys:if payload {vec![Key::F8;128]}else{vec![]},
                            text:if payload {"测🙂e\u{301}".repeat(8192)}else{String::new()},
                            composing:mode=="composing",ime_consumed:mode=="ime-consumed",focus_lost:mode=="focus-lost",..Default::default()};
                        let input_before=format!("{:?}",input.input_view());
                        let mut requests=0;let mut bytes=0;let mut snapshot=None;
                        for i in 0..11 {
                            let mut panels=Panels {locale,focused:Some(Panel::Info),..Default::default()};
                            let mut paint=PaintList::default();let mut output=None;
                            let measured=counts::measure(||output=Some(chrome(&mut paint,&mut atlas,[1600.,1000.],&layout,&mut panels,&state,&input)));
                            let actions=output.unwrap();assert!(actions.is_empty(),"{name}: {actions:?}");
                            assert_eq!(state,original);assert_eq!(format!("{:?}",input.input_view()),input_before);
                            if i>=3 {
                                requests+=measured.0;bytes+=measured.1;
                                if snapshot.is_none() {snapshot=Some(format!("{:?}",(
                                    paint.shapes,paint.colors,paint.glyphs,paint.images,paint.order,
                                    panels.selected,panels.focused,panels.message,panels.timeline.timeline_query,
                                    panels.node_editor.document(),&state)));}
                            }
                        }
                        std::fs::write(root.join(format!("{name}.txt")),snapshot.unwrap()).unwrap();
                        records.push(serde_json::json!({"name":name,"locale":format!("{locale:?}"),"panels":n,
                            "mode":mode,"payload":payload,"pointer":pointer,"frames":8,"allocation_requests":requests,
                            "requested_bytes":bytes,"payload_bytes":input.text.len()}));
                    }
                }
            }
        }
    }
    assert_eq!(records.len(),128);
    std::fs::write(root.join("records.json"),serde_json::to_vec_pretty(&records).unwrap()).unwrap();
}
