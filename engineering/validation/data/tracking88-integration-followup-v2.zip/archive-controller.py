"""Retain failed and successful gates separately; read back every archive member."""
from pathlib import Path
import hashlib, json, zipfile

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
DEST = ROOT / '.worktrees/tracking-colmap88/engineering/validation/data'
DEST.mkdir(exist_ok=True)
ARCHIVE = DEST / 'tracking88-integration-followup-v2.zip'
RECEIPT = DEST / 'tracking88-integration-followup-v2.json'
assert not ARCHIVE.exists() and not RECEIPT.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
groups = {
    'tracking88-integration-final-v1': ['controller.py', 'exit.json', 'cargo-metadata.json', 'desktop-ui.stdout.log', 'desktop-ui.stderr.log', 'host-media.stdout.log', 'host-media.stderr.log'],
    'tracking88-optional-depth-check-v1': ['controller.py', 'exit.json', 'stdout.log', 'stderr.log'],
    'tracking88-optional-depth-check-v2': ['controller.py', 'exit.json', 'stdout.log', 'stderr.log'],
    'tracking88-ci-cancelled-3e2-v1': ['controller.py', 'receipt.json', 'job.stdout', 'logs.stdout', 'annotations.json'],
    'tracking88-exposure-original-child-v1': ['controller.py', 'receipt.json', 'stdout.log', 'stderr.log', 'child/motion-studio.log', 'child/primary-causes.json'],
}
files = {}
for group, names in groups.items():
    for name in names:
        path = ART / group / name
        assert path.is_file(), path
        files[f'{group}/{name}'] = path.read_bytes()
events = json.loads((ART / 'tracking88-exposure-original-child-v1/windows-events.json').read_text(encoding='utf-8-sig'))
assert {e['RecordId'] for e in events} == {16775, 16776}
files['tracking88-exposure-original-child-v1/windows-event-summary.json'] = (json.dumps({
    'scope': 'Selected metadata only; original local Windows messages retained separately, no dump inspected',
    'events': [{'recordId': e['RecordId'], 'utc': e['Utc'], 'eventId': e['Id']} for e in events],
    'executable': 'motion_studio-b7699da1cd4142ae.exe', 'exception': '0xc0000005',
    'processIdHex': '0x126c', 'module': 'unknown', 'offset': '0x0000000000000000',
    'reportId': '348f86d2-9d22-41c0-b975-8e8f428444aa',
    'limit': 'Confirms an OS access-violation record for this executable; does not identify the faulting code or driver',
}, indent=2) + '\n').encode()
files['archive-controller.py'] = Path(__file__).read_bytes()
with zipfile.ZipFile(ARCHIVE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, content in sorted(files.items()):
        z.writestr(name, content)
with zipfile.ZipFile(ARCHIVE) as z:
    assert set(z.namelist()) == set(files)
    for name, content in files.items():
        assert z.read(name) == content
report = {
    'archive': ARCHIVE.name, 'bytes': ARCHIVE.stat().st_size, 'sha256': sha(ARCHIVE.read_bytes()),
    'integrationSource': '3e2e2bee8372a9a5afe2026630cfb06908d1bc9d',
    'dispositions': {
        'fullDesktopUi': 'FAILED: 1985 passed, 1 failed, 72 original ignores, 32 targets',
        'fullHostMedia': 'NOT EXECUTED: foreign worktree metadata compile failure',
        'optionalDepthV1': 'FAILED: shared target reused foreign motion-model metadata',
        'optionalDepthV2': 'PASS all-target typecheck in fresh dedicated target, no inference/runtime',
        'exposureDirectChild': 'PASS unchanged original executable; original full-gate native crash unresolved',
        'requiredRustGpuJob': 'CANCELLED after 45-minute job budget; tests and SDK steps passed, release-loop step incomplete',
    },
    'limits': ['No complete four-package regression or complete issue closure', 'No minidump or proprietary binary inspection', 'Compilation and focused child success do not replace a full passing gate'],
    'members': {n: {'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(files.items())},
}
RECEIPT.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in report.items() if k != 'members'}))
