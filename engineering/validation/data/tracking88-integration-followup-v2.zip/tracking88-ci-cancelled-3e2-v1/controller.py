"""Retain the terminal own Rust/GPU job without treating cancellation as pass."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess
ROOT = Path('E:/Dev/aem')
OUT = ROOT / 'artifacts/pr-queue/tracking88-ci-cancelled-3e2-v1'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
base = 'repos/MAD-Producer/Kilonova/actions/jobs/126997537556'
result = {}
for label, suffix in [('job', ''), ('logs', '/logs')]:
    command = ['gh', 'api', base + suffix]
    with (OUT / (label + '.stdout')).open('wb') as stdout, (OUT / (label + '.stderr')).open('wb') as stderr:
        child = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr)
    result[label] = dict(command=command, exitCode=child.returncode)
    assert child.returncode == 0, label
job = json.loads((OUT / 'job.stdout').read_text(encoding='utf-8'))
result.update(status='terminal_job_collected_not_passed', jobId=job['id'], conclusion=job['conclusion'],
              startedAt=job['started_at'], completedAt=job['completed_at'],
              checkRunUrl=job['check_run_url'], collectedUtc=datetime.now(timezone.utc).isoformat())
assert job['status'] == 'completed'
raw = (OUT / 'logs.stdout').read_bytes()
result['logs'].update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
lines = raw.decode('utf-8', errors='replace').splitlines()
(OUT / 'tail.txt').write_text('\n'.join(lines[-100:]) + '\n', encoding='utf-8')
result['limits'] = ['Original cancelled job, not a successful check', 'Cause requires inspecting retained logs/annotations; no rerun or merge performed']
(OUT / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
