"""Complete desktop/UI and host/media on the published integration follow-up."""
from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,os,time,re,traceback
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-colmap88'
OUT=ROOT/'artifacts/pr-queue/tracking88-integration-final-v1';OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert head=='3e2e2bee8372a9a5afe2026630cfb06908d1bc9d'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
names=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={n:sha(WORK/n) for n in names if (WORK/n).is_file() and (n.startswith(('crates/','desktop/','tools/')) and Path(n).suffix in ('.rs','.wgsl','.json','.toml','.py') or n in ('Cargo.toml','Cargo.lock','ATTRIBUTION.md','NOTICE','PROVENANCE.md'))}
def identity():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head
    for n,digest in source.items():assert sha(WORK/n)==digest,n
env=os.environ.copy()
for k in list(env):
    if k.startswith('MOTION_'):env.pop(k,None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/rational-rate85-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'appdata'),TEMP=str(ROOT/'target/ci-policy-validation-tmp'),TMP=str(ROOT/'target/ci-policy-validation-tmp'))
metadata=json.loads(subprocess.check_output(['cargo','metadata','--no-deps','--format-version','1','--locked','--offline'],cwd=WORK,env=env))
(OUT/'cargo-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
tail=['--no-fail-fast','--locked','--offline','--','--test-threads=1']
steps=[('desktop-ui',['cargo','test','-p','motion-desktop','-p','motion-ui','--features','motion-desktop/ffmpeg']+tail,['motion-desktop','motion-ui']),('host-media',['cargo','test','-p','motion-host','-p','motion-desktop-media','--features','motion-desktop-media/ffmpeg']+tail,['motion-host','motion-desktop-media'])]
report=dict(status='running',controllerPid=os.getpid(),baseCommit=head,integratedMain='eeada782742cae29935f59b9d89ee5145b92712a',source=source,steps=[],startedUtc=datetime.now(timezone.utc).isoformat(),limits=['Complete four selected packages; not full workspace; Android excluded','No four-unit override: Cargo default test codegen units; same previously documented dev/test debug0, jobs1 and no incremental; production profiles unchanged','Original assertions, ignores, budgets, stack and backend preserved; default Info; one own serial GPU workload; controlled cache/temp E','Original099 link failure remains unaltered; a new pass alone does not establish its root cause'])
def save():
    p=OUT/'exit.pending.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(p,OUT/'exit.json')
save();began=time.monotonic()
try:
    for label,cmd,packages in steps:
        identity();row=dict(label=label,status='running',command=cmd,startedUtc=datetime.now(timezone.utc).isoformat());report['steps'].append(row);save();start=time.monotonic()
        with (OUT/(label+'.stdout.log')).open('wb') as stdout,(OUT/(label+'.stderr.log')).open('wb') as stderr:
            p=subprocess.Popen(cmd,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=p.pid;save();code=p.wait()
        identity()
        summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',(OUT/(label+'.stdout.log')).read_text(encoding='utf-8',errors='replace'),re.M)
        invocations=re.findall(r'^\s*(?:Running|Doc-tests) .+$',(OUT/(label+'.stderr.log')).read_text(encoding='utf-8',errors='replace'),re.M)
        row.update(status='passed' if code==0 else 'failed',exitCode=code,elapsedSeconds=round(time.monotonic()-start,3),summaries=summaries,invocations=invocations)
        if code==0:
            assert summaries and len(summaries)==len(invocations)
            assert all(s[0]=='ok' and s[2]==s[5]=='0' for s in summaries)
            expected=[]
            for package in metadata['packages']:
                if package['name'] in packages:
                    expected.extend((t['name'],t['kind'][0]) for t in package['targets'] if t['test'])
                    if any(t['doctest'] for t in package['targets']):expected.append((package['name'].replace('-','_'),'doc'))
            assert len(expected)==len(invocations),(label,len(expected),len(invocations))
            for name,kind in expected:assert any((f'Doc-tests {name}' if kind=='doc' else name.replace('-','_')+'-') in v for v in invocations),name
            row['totals']=dict(passed=sum(int(s[1]) for s in summaries),failed=0,originalIgnored=sum(int(s[3]) for s in summaries),filtered=0,targets=len(summaries))
        save()
    report.update(status='complete_desktop_ui_host_media_passed' if all(s['exitCode']==0 for s in report['steps']) else 'failed_original_outputs_retained',sourceUnchanged=True)
except BaseException:
    report.update(status='observer_failed_original_outputs_retained',traceback=traceback.format_exc());raise
finally:
    report.update(elapsedSeconds=round(time.monotonic()-began,3),completedUtc=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({k:v for k,v in report.items() if k!='source'}))
raise SystemExit(0 if report['status']=='complete_desktop_ui_host_media_passed' else 1)
