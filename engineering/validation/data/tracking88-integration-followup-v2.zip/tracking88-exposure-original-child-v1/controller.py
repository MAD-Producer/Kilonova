"""Run the failed original child directly, retaining its native exit status."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, time

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-colmap88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-exposure-original-child-v1'
EXE = ROOT / 'target/rational-rate85-contract/debug/deps/motion_studio-b7699da1cd4142ae.exe'
NAME = 'engine::failure::composition_tests::plan_error::exposure_frame::actual_exposure_io_and_terminal_replay_reach_default_reply_channels_then_new_task_recovers'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == '3e2e2bee8372a9a5afe2026630cfb06908d1bc9d'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
original = sha(EXE)
env = os.environ.copy()
for key in list(env):
    if key.startswith('MOTION_'):
        env.pop(key, None)
env.update(MOTION_EXPOSURE_NATIVE_ERROR_CHILD=str(OUT / 'child'),
           LOCALAPPDATA=str(OUT / 'appdata'),
           TEMP=str(ROOT / 'target/ci-policy-validation-tmp'),
           TMP=str(ROOT / 'target/ci-policy-validation-tmp'), RUST_BACKTRACE='full')
command = [str(EXE), '--exact', NAME, '--test-threads=1', '--nocapture']
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(),
              executableSha256=original, command=command,
              limits=['Original full-regression executable, direct child branch; no rebuild or assertion change',
                      'Default Info, original stack/backend and one own GPU process',
                      'A direct-child success cannot replace the failed original full regression'])
(OUT / 'receipt.json').write_text(json.dumps(report, indent=2))
began = time.monotonic()
with (OUT / 'stdout.log').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
    process = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
    report['pid'] = process.pid
    (OUT / 'receipt.json').write_text(json.dumps(report, indent=2))
    code = process.wait()
assert sha(EXE) == original
report.update(status='direct_child_passed_original_suite_failure_unresolved' if code == 0 else 'direct_child_failed_original_outputs_retained',
              exitCode=code, nativeExitHex=f'0x{code & 0xffffffff:08x}',
              elapsedSeconds=round(time.monotonic() - began, 3),
              completedUtc=datetime.now(timezone.utc).isoformat())
(OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
raise SystemExit(0 if code == 0 else 1)
