"""Current integration's optional depth closure: CPU-only all-target type check."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, time, traceback
ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-colmap88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-optional-depth-check-v1'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert head == '3e2e2bee8372a9a5afe2026630cfb06908d1bc9d'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK)

def identity():
    names = subprocess.check_output(['git', 'ls-files'], cwd=WORK, text=True).splitlines()
    return {n: hashlib.sha256((WORK / n).read_bytes()).hexdigest() for n in names if (WORK / n).is_file() and (n.startswith(('crates/', 'desktop/')) or n in ('Cargo.toml', 'Cargo.lock'))}

before = identity()
env = os.environ.copy()
for key in list(env):
    if key.startswith('MOTION_'):
        env.pop(key, None)
env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT / 'target/rational-rate85-contract'), CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', TEMP=str(ROOT / 'target/ci-policy-validation-tmp'), TMP=str(ROOT / 'target/ci-policy-validation-tmp'))
command = ['cargo', 'check', '-p', 'motion-desktop', '-p', 'motion-host', '-p', 'motion-desktop-media', '--all-targets', '--features', 'motion-desktop/ffmpeg,motion-desktop-media/ai-depth', '--locked', '--offline']
report = dict(status='running', baseCommit=head, source=before, command=command, startedUtc=datetime.now(timezone.utc).isoformat(), limits=['All targets compile with optional inference and FFmpeg; no runtime/ONNX inference or GPU assertions execute', 'One compiler job with controlled cache/temp E; current source-frozen native regression remains separate', 'Original issue74 domain/reference evidence remains source-scoped; compilation alone cannot close74'])

def save():
    pending = OUT / 'exit.pending.json'
    pending.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    os.replace(pending, OUT / 'exit.json')

save()
began = time.monotonic()
try:
    with (OUT / 'stdout.log').open('wb') as stdout, (OUT / 'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = child.pid
        save()
        code = child.wait()
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == head
    assert identity() == before, 'Frozen integration source changed during optional-depth check'
    report.update(status='all_targets_typechecked_not_executed' if code == 0 else 'failed_original_outputs_retained', exitCode=code, sourceUnchanged=True)
except BaseException:
    report.update(status='observer_failed_original_outputs_retained', traceback=traceback.format_exc())
    raise
finally:
    report.update(elapsedSeconds=round(time.monotonic() - began, 3), completedUtc=datetime.now(timezone.utc).isoformat())
    save()
print(json.dumps({k: v for k, v in report.items() if k != 'source'}))
raise SystemExit(code)
