
use motion_host::depth::{
    alignment::{Limits, Rejection},
    transition::{
        admission::{Admission, Error},
        Activity, Choices, Controller, Policy, Ticket,
    },
    Backend, Cancellation, Costs, Estimate, Input, Jobs, Key, PreparedEstimate,
};
use motion_model::depth::{
    DepthDescriptor, DepthGeometry, DepthMeasure, DepthModel, DepthResource, DepthSource,
    DepthTime, NearDirection,
};
use std::{
    sync::Arc,
    time::{Duration, Instant},
};

fn choices() -> Choices {
    let first = Key {
        source: DepthSource {
            asset: 75,
            revision: 1,
            pts: DepthTime {
                ticks: 0,
                timescale: 24,
            },
        },
        geometry: DepthGeometry {
            source_size: [20, 1],
            crop: [0, 0, 20, 1],
            quarter_turns: 0,
            mirror_x: false,
        },
        model: DepthModel {
            id: "admission-control".into(),
            revision: "r1".into(),
            sha256: [1; 32],
            processing: "reference".into(),
        },
    };
    let mut second = first.clone();
    second.model.processing = "candidate".into();
    Choices {
        interactive: first,
        settled: second,
    }
}
fn controller() -> Controller {
    Controller::new(Policy {
        idle_delay: Duration::from_millis(100),
        minimum_interactive_residence: Duration::from_millis(300),
    })
    .unwrap()
}
fn limits() -> Limits {
    Limits {
        minimum_fit_pairs: 3,
        minimum_validation_pairs: 3,
        minimum_pair_fraction: 1.,
        minimum_confidence: None,
        minimum_reference_stddev: 1e-8,
        scale_bounds: [0.1, 10.],
        maximum_normalized_rms: 1e-8,
        maximum_normalized_error: 1e-8,
    }
}
struct Analytic;
impl Backend for Analytic {
    fn infer(&mut self, input: &Input, _: &Cancellation) -> motion_host::depth::Result<Estimate> {
        let key = input.key();
        let values = (0..20)
            .map(|i| {
                let x = i as f32 * 0.25;
                if key.model.processing == "reference" {
                    2. * x + 3.
                } else {
                    x
                }
            })
            .collect();
        Ok(Estimate {
            resource: DepthResource::new(
                DepthDescriptor {
                    size: [20, 1],
                    source: key.source.clone(),
                    geometry: key.geometry.clone(),
                    model: key.model.clone(),
                    measure: DepthMeasure::Relative {
                        near: NearDirection::Increasing,
                    },
                    scale: 1.,
                    offset: 0.,
                    valid_range: None,
                },
                values,
                None,
                None,
            )?,
            provider: "actual-analytic-worker".into(),
            costs: Costs {
                inference: Duration::from_millis(7),
                ..Costs::default()
            },
        })
    }
}
fn ready(c: &mut Controller, jobs: &mut Jobs, ticket: &Ticket, pixel: u8) -> PreparedEstimate {
    c.request(
        ticket,
        jobs,
        Input::new(ticket.key().clone(), [20, 1], Arc::from(vec![pixel; 60])).unwrap(),
    )
    .unwrap()
    .unwrap();
    let deadline = Instant::now() + Duration::from_secs(5);
    loop {
        if let Some(value) = c.take_ready(ticket, jobs, ticket.key()).unwrap() {
            return value;
        }
        assert!(
            Instant::now() < deadline,
            "actual admission fixture worker did not finish"
        );
        std::thread::sleep(Duration::from_millis(1));
    }
}
fn pair(pixel: u8) -> (Controller, Ticket, PreparedEstimate, PreparedEstimate) {
    let mut c = controller();
    let mut jobs = Jobs::start(Analytic).unwrap();
    let first = c
        .observe(choices(), Activity::Idle, Duration::ZERO)
        .unwrap()
        .unwrap();
    let reference = ready(&mut c, &mut jobs, &first, 1);
    let second = c
        .observe(choices(), Activity::Idle, Duration::from_millis(300))
        .unwrap()
        .unwrap();
    let candidate = ready(&mut c, &mut jobs, &second, pixel);
    (c, second, reference, candidate)
}

#[path="E:/Dev/aem/.worktrees/depth-transition75/desktop/app/src/logging/sink.rs"]
mod logging;
mod engine { pub fn current_command() -> Option<(u64,&'static str,std::time::Duration)> { None } }
fn main() -> Result<(),Box<dyn std::error::Error>> {
    assert!(std::env::var_os("MOTION_LOG").is_none());
    let out=std::path::PathBuf::from(std::env::args_os().nth(1).ok_or("missing output")?);
    assert!(out.is_absolute());std::fs::create_dir(&out)?;
    let _logging=logging::init(out.join("logs"))?;
    let (entered,seen)=std::sync::mpsc::channel();
    let (release,wait)=std::sync::mpsc::channel();
    struct Release(std::sync::mpsc::Sender<()>);
    impl Drop for Release { fn drop(&mut self) { let _=self.0.send(()); } }
    let release=Release(release);
    let thread=std::thread::spawn(move || {
        let (c,ticket,reference,candidate)=pair(1);
        let mut blocked=false;
        let admitted=Admission::prepare(&c,&ticket,ticket.key(),&reference,candidate,limits(),|| {
            if !blocked {blocked=true;entered.send(()).unwrap();wait.recv_timeout(Duration::from_secs(5)).unwrap();}
            false
        }).unwrap().unwrap();
        assert_eq!(admitted.view(&c,ticket.key()).unwrap().unwrap().sample(19).unwrap(),Some(12.5));
    });
    seen.recv_timeout(Duration::from_secs(5))?;
    let log=std::fs::read_to_string(out.join("logs/motion-studio.log"))?;
    assert!(log.lines().any(|l|l.contains(" INFO ") && l.contains("start depth_transition_align generation=2 source_id=75")));
    drop(release);thread.join().map_err(|_|"alignment probe panicked")?;
    let (c,ticket,reference,candidate)=pair(2);
    assert!(matches!(Admission::prepare(&c,&ticket,ticket.key(),&reference,candidate,limits(),||false),Err(Error::Pixels)));
    let log=std::fs::read_to_string(out.join("logs/motion-studio.log"))?;
    assert!(log.lines().any(|l| l.contains(" ERROR ") && l.contains("cause=prepared_pixels_differ")));
    println!("{}",serde_json::json!({"status":"blocked_start_and_pixel_error_verified"}));
    Ok(())
}
