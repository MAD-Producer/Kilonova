from pathlib import Path
from datetime import datetime,timezone
import os,json,hashlib,subprocess,shutil,tomllib
root=Path("E:/Dev/aem");base=root/"artifacts/pr-queue";work=root/".worktrees/depth-transition75";probe=base/"depth75-aligned-file-source";out=base/"depth75-aligned-file-v2"
assert shutil.disk_usage(root).free>=10<<30
out.mkdir(exist_ok=False);(out/"tmp").mkdir();(out/"controller.py").write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=["crates/motion-host/src/depth/transition.rs","crates/motion-host/src/depth/transition/admission.rs","crates/motion-host/tests/depth_aligned_admission.rs","desktop/app/src/logging/sink.rs"]
source={n:sha(work/n) for n in files}
env={k:v for k,v in os.environ.items() if not k.startswith("MOTION_")}
env.update(CARGO_HOME=str(root/".tools/prerender-cargo-home"),CARGO_TARGET_DIR=str(root/"target/colmap88-isolated-check"),CARGO_INCREMENTAL="0",CARGO_BUILD_JOBS="1",CARGO_PROFILE_DEV_DEBUG="0",CARGO_PROFILE_TEST_DEBUG="0",TEMP=str(out/"tmp"),TMP=str(out/"tmp"),LOCALAPPDATA=str(out/"appdata"))
r=dict(status="running",source=source,stages=[],startedUtc=datetime.now(timezone.utc).isoformat())
def save(): (out/"receipt.json").write_text(json.dumps(r,indent=2)+"\n")
def stage(name,args):
 row=dict(name=name,command=args);r["stages"].append(row);save()
 with (out/(name+".stdout.log")).open("wb") as stdout,(out/(name+".stderr.log")).open("wb") as stderr:
  row["exitCode"]=subprocess.call(args,cwd=work,env=env,stdout=stdout,stderr=stderr)
 save();return row["exitCode"]
try:
 if not (probe/"Cargo.lock").exists():shutil.copyfile(work/"Cargo.lock",probe/"Cargo.lock")
 assert stage("metadata",["cargo","metadata","--offline","--format-version","1","--manifest-path",str(probe/"Cargo.toml")])==0
 known={(p["name"],p["version"],p.get("source")):p.get("checksum") for p in tomllib.loads((work/"Cargo.lock").read_text())["package"]}
 for p in tomllib.loads((probe/"Cargo.lock").read_text())["package"]:
  if p.get("source"):assert known[(p["name"],p["version"],p["source"])]==p.get("checksum")
 assert stage("build",["cargo","build","--offline","--locked","--manifest-path",str(probe/"Cargo.toml")])==0
 assert stage("actual",[str(root/"target/colmap88-isolated-check/debug/motion-depth75-aligned-file-probe.exe"),str(out/"execution")])==0
 assert json.loads((out/"actual.stdout.log").read_text())==dict(status="blocked_start_and_pixel_error_verified")
 assert len((out/"actual.stdout.log").read_text().splitlines())==1
 assert "ERROR motion_host::depth::transition::admission:" in (out/"actual.stderr.log").read_text()
 assert "cause=prepared_pixels_differ" in (out/"actual.stderr.log").read_text()
 r["status"]="actual_blocked_start_and_error_channels_passed"
except BaseException as error:r.update(status="failed_original_outputs_retained",cause=repr(error))
finally:
 r.update(sourceUnchanged={n:sha(work/n) for n in files}==source,completedUtc=datetime.now(timezone.utc).isoformat());save()
print(json.dumps({k:v for k,v in r.items() if k!="source"}))
raise SystemExit(0 if r["status"]=="actual_blocked_start_and_error_channels_passed" and r["sourceUnchanged"] else 1)
