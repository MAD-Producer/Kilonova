from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess

root=Path('E:/Dev/aem')
work=root/'.worktrees/native-camera-dof'
probe=root/'.tools/scene87-normative-alpha'
fixtures=root/'.tools/gltf-scene87-normative-extra'
oracle=root/'.tools/issue-closure-review/check-normative-alpha-v2.py'
out=root/'artifacts/pr-queue/normative-alpha-native-v2'
out.mkdir(exist_ok=False)
prior=json.loads((root/'artifacts/pr-queue/native-camera-dof-regression-v2/accepted.json').read_text(encoding='utf-8'))
assert prior['sourceUnchanged'] and prior['unexecutedIgnored']==0
for path,sha in prior['source'].items():
    assert hashlib.sha256((work/path).read_bytes()).hexdigest()==sha,path
env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',
           CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='1')
env.pop('MOTION_LOG',None)
paths=[probe/'Cargo.toml',probe/'src/main.rs',oracle,Path(__file__)]
report=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip(),
            inheritedSource=prior['source'],steps=[],
            toolSource={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
for path in paths:
    dest=out/'source'/path.relative_to(root)
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(path,dest)
def step(name,command):
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as so,(out/(name+'.stderr.log')).open('wb') as se:
        code=subprocess.run(command,cwd=work,env=env,stdout=so,stderr=se).returncode
    row=dict(name=name,command=[str(c) for c in command],exitCode=code)
    report['steps'].append(row)
    (out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    assert code==0,row
# Derive and persist the expected pixels and negative-control selection first.
step('reference-prepare',['python',str(oracle),'--prepare',str(out/'native')])
reference_path=out/'native/independent-input-reference.json'
reference_sha=hashlib.sha256(reference_path.read_bytes()).hexdigest()
shutil.copyfile(work/'Cargo.lock',probe/'Cargo.lock')
step('lock',['cargo','metadata','--manifest-path',str(probe/'Cargo.toml'),'--format-version','1','--offline'])
report['toolLockSha256']=hashlib.sha256((probe/'Cargo.lock').read_bytes()).hexdigest()
shutil.copyfile(probe/'Cargo.lock',out/'source/Cargo.lock')
step('build',['cargo','build','--manifest-path',str(probe/'Cargo.toml'),'--locked','--offline'])
binary=root/'target/gltf-animation87-contract/debug/motion-scene87-normative-alpha.exe'
report['binarySha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
step('native',[str(binary),str(fixtures/'Models/AlphaBlendModeTest/glTF/AlphaBlendModeTest.gltf'),str(out/'native')])
assert not (out/'native.stdout.log').read_bytes(),'unexpected stdout'
step('independent-reference',['python',str(oracle),'--check',str(out/'native')])
assert hashlib.sha256(reference_path.read_bytes()).hexdigest()==reference_sha,'reference changed after native output'
for path,sha in prior['source'].items():
    assert hashlib.sha256((work/path).read_bytes()).hexdigest()==sha,path
for path in paths:
    assert hashlib.sha256(path.read_bytes()).hexdigest()==report['toolSource'][str(path.relative_to(root))],path
logs=(out/'native/logs/motion-studio.log').read_text(encoding='utf-8')
assert 'start #87007 normative_alpha' in logs,'default Info start absent'
report.update(completedUtc=datetime.now(timezone.utc).isoformat(),sourceUnchanged=True,
              expectedPixelsPreparedBeforeNative=True,expectedPixelsSha256=reference_sha,
              native=json.loads((out/'native/native.json').read_text(encoding='utf-8')),
              reference=json.loads((out/'native/independent-reference.json').read_text(encoding='utf-8')),
              fixtureManifest=json.loads((fixtures/'manifest.json').read_text(encoding='utf-8')),
              scope='Unmodified official AlphaBlendModeTest, source rays and independent filtered alpha/source-over reference; four precisions and exact frozen restore; no claim of intersecting order-independent transparency')
(out/'accepted.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(accepted=True,scope=report['scope'])),flush=True)
