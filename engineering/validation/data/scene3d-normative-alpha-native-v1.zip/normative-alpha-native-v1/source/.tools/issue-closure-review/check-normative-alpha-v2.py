"""Independent source-ray/area-mip filtered reference for the unmodified alpha sample."""
from pathlib import Path
from PIL import Image
import hashlib,json,math,struct,sys
import numpy as np

root=Path('E:/Dev/aem/.tools/gltf-scene87-normative-extra')
out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
assert manifest['revision']=='8f492390ddc7a2ae221a1369ef560589cf8c70fb'
for item in manifest['files']:
    data=(root/item['path']).read_bytes()
    assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
folder=root/'Models/AlphaBlendModeTest/glTF'
d=json.loads((folder/'AlphaBlendModeTest.gltf').read_text(encoding='utf-8'))
assert not d.get('extensionsRequired') and all(not n.get('children') for n in d['nodes'])
buffers=[(folder/b['uri']).read_bytes() for b in d['buffers']]

def accessor(index):
    a=d['accessors'][index];v=d['bufferViews'][a['bufferView']]
    assert not a.get('normalized')
    count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
    fmt='<'+{5121:'B',5123:'H',5125:'I',5126:'f'}[a['componentType']]*count
    offset=a.get('byteOffset',0)+v.get('byteOffset',0)
    stride=v.get('byteStride',struct.calcsize(fmt))
    return [struct.unpack_from(fmt,buffers[v['buffer']],offset+k*stride) for k in range(a['count'])]

def transform(n,p):
    assert 'matrix' not in n
    x,y,z,w=n.get('rotation',[0.,0.,0.,1.]);length=math.sqrt(x*x+y*y+z*z+w*w)
    x,y,z,w=[q/length for q in (x,y,z,w)]
    q=[p[i]*n.get('scale',[1.,1.,1.])[i] for i in range(3)]
    # Independent quaternion-vector rotation, then authored node translation.
    cross=lambda a,b:(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
    t=[2*v for v in cross((x,y,z),q)];u=cross((x,y,z),t)
    return tuple(q[i]+w*t[i]+u[i]+n.get('translation',[0.,0.,0.])[i] for i in range(3))

triangles=[]
for node in d['nodes']:
    if 'mesh' not in node:continue
    for primitive in d['meshes'][node['mesh']]['primitives']:
        positions=[transform(node,p) for p in accessor(primitive['attributes']['POSITION'])]
        uv=accessor(primitive['attributes']['TEXCOORD_0'])
        indices=[i[0] for i in accessor(primitive['indices'])]
        material=d['materials'][primitive['material']]
        for k in range(0,len(indices),3):
            ids=indices[k:k+3];p=[positions[i] for i in ids];t=[uv[i] for i in ids]
            a,b,c=p;den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
            if abs(den)<1e-12 or (den<0 and not material.get('doubleSided',False)):continue
            dx=((b[1]-c[1])/den,(c[1]-a[1])/den,(a[1]-b[1])/den)
            dy=((c[0]-b[0])/den,(a[0]-c[0])/den,(b[0]-a[0])/den)
            derivatives=tuple(tuple(sum(weights[i]*t[i][ch] for i in range(3))*step for ch in range(2))
                              for weights,step in [(dx,9.2/1025),(dy,2.6/289)])
            triangles.append((p,t,material,den,derivatives))

images=[Image.open(folder/i['uri']).convert('RGBA') for i in d['images']]
linear=lambda x:x/12.92 if x<=0.04045 else ((x+0.055)/1.055)**2.4
mul=lambda a,b:(a[0]*b[0],a[1]*b[1])
# Independent offline reference: area-integrated mip images, standard normalized
# bilinear samples, and trilinear interpolation. Float64 NumPy is independent of
# the native Rust decoder/mip uploader and of the WGSL material program.
# The source textures here are all power-of-two, so each area cell is exact.
mip_cache={}
def mipmaps(index,color):
    key=(index,color)
    if key in mip_cache:return mip_cache[key]
    current=np.asarray(images[index],dtype=np.float64)/255
    if color:
        current=current.copy()
        rgb=current[:,:,:3]
        current[:,:,:3]=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)
    levels=[]
    while True:
        stored=current.copy()
        if color:
            rgb=stored[:,:,:3]
            stored[:,:,:3]=np.where(rgb<=.0031308,rgb*12.92,1.055*np.maximum(rgb,0)**(1/2.4)-.055)
        stored=np.floor(np.clip(stored,0,1)*255+.5)/255
        if color:
            rgb=stored[:,:,:3]
            stored[:,:,:3]=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)
        levels.append(stored)
        h,w,_=current.shape
        if h==w==1:break
        assert h%2==w%2==0
        current=current.reshape(h//2,2,w//2,2,4).mean(axis=(1,3))
    mip_cache[key]=levels
    return levels

def texture(slot,uv,derivatives,color=False):
    if slot is None:return [(1.,1.)]*4
    assert slot.get('texCoord',0)==0
    tex=d['textures'][slot['index']];sampler=d['samplers'][tex['sampler']]
    assert sampler.get('wrapS',10497)==sampler.get('wrapT',10497)==10497
    assert sampler.get('minFilter') is None and sampler.get('magFilter') is None
    levels=mipmaps(tex['source'],color);h,w,_=levels[0].shape
    rho=max(math.hypot(v[0]*w,v[1]*h) for v in derivatives)
    lod=max(0.,math.log2(max(rho,1.)))
    def sample(level):
        im=levels[level];h,w,_=im.shape
        x=(uv[0]%1)*w-.5;y=(uv[1]%1)*h-.5
        ix=math.floor(x);iy=math.floor(y);fx=x-ix;fy=y-iy
        return ((1-fy)*((1-fx)*im[iy%h,ix%w]+fx*im[iy%h,(ix+1)%w])+
                fy*((1-fx)*im[(iy+1)%h,ix%w]+fx*im[(iy+1)%h,(ix+1)%w]))
    # Hardware may approximate log2 LOD. Enclose +/- 0.02 mip levels before
    # looking at any native values; the existing output tolerances also remain.
    samples=[]
    for perturbation in [-.02,0.,.02]:
        level=min(max(lod+perturbation,0.),len(levels)-1)
        low=math.floor(level);high=min(low+1,len(levels)-1);f=level-low
        samples.append((1-f)*sample(low)+f*sample(high))
    values=np.asarray(samples)
    return [(max(0.,float(values[:,ch].min())-.001),min(1.,float(values[:,ch].max())+.001)) for ch in range(4)]

def hits(x,y):
    result=[]
    for p,t,m,den,derivatives in triangles:
        a,b,c=p
        u=((b[1]-c[1])*(x-c[0])+(c[0]-b[0])*(y-c[1]))/den
        v=((c[1]-a[1])*(x-c[0])+(a[0]-c[0])*(y-c[1]))/den
        weights=(u,v,1-u-v)
        if min(weights)<0:continue
        if min(weights)<.01:return None
        uv=tuple(sum(weights[i]*t[i][ch] for i in range(3)) for ch in range(2))
        z=sum(weights[i]*p[i][2] for i in range(3))
        result.append((z,m,uv,derivatives))
    return result

def shade(hit,policy='normal'):
    z,m,uv,derivatives=hit;p=m['pbrMetallicRoughness']
    assert 'emissiveFactor' not in m
    base=texture(p.get('baseColorTexture'),uv,derivatives,True)
    factor=p.get('baseColorFactor',[1.]*4)
    base=[tuple(q*factor[ch] for q in pair) for ch,pair in enumerate(base)]
    detail=texture(p.get('metallicRoughnessTexture'),uv,derivatives)
    metal=tuple(v*p.get('metallicFactor',1.) for v in detail[2])
    occlusion=texture(m.get('occlusionTexture'),uv,derivatives)[0]
    strength=m.get('occlusionTexture',{}).get('strength',1.)
    occlusion=tuple(1-strength+strength*v for v in occlusion)
    color=[mul(mul(pair,(1-metal[1],1-metal[0])),occlusion) for pair in base[:3]]
    mode='OPAQUE' if policy=='opaque' else m.get('alphaMode','OPAQUE')
    if mode=='OPAQUE':return z,color,[(1.,1.)],False
    if mode=='MASK':
        cutoff=.5 if policy=='default_cutoff' else m.get('alphaCutoff',.5)
        if base[3][1]<cutoff:return False
        if base[3][0]<cutoff:return None
        return z,color,[(1.,1.)],False
    assert mode=='BLEND'
    return z,color,[base[3]],True

def compose(fragments,policy='normal'):
    opaque=[];blend=[]
    for hit in fragments:
        f=shade(hit,policy)
        if f is None:return None
        if f is False:continue
        (blend if f[3] else opaque).append(f)
    front=max(opaque,key=lambda f:f[0]) if opaque else None
    color=front[1] if front else [(0.,0.)]*3
    alpha=(1.,1.) if front else (0.,0.)
    for z,source,a,_ in sorted(blend,key=lambda f:f[0]):
        if front is not None and z<front[0]:continue
        incoming=a[0]
        def over(s,b):
            return (min(s[0]*v+b[0]*(1-v) for v in incoming),max(s[1]*v+b[1]*(1-v) for v in incoming))
        color=[over(s,b) for s,b in zip(source,color)]
        alpha=over((1.,1.),alpha)
    return color+[alpha]

if sys.argv[1]=='--prepare':
    selected=[];groups={};rejects={'opaque':0,'default_cutoff':0}
    nodes=[n for n in d['nodes'] if n.get('name','').startswith('Test')]
    assert len(nodes)==5
    for node in nodes:
        group=node['name'];groups[group]=0
        for offset in [-.4,-.2,0.,.2,.4]:
            px=math.floor(((node.get('translation',[0,0,0])[0]+offset)/9.2+.5)*1025)
            for py in range(65,235,2):
                x=((px+.5)/1025-.5)*9.2;y=1.1+(0.5-(py+.5)/289)*2.6
                f=hits(x,y)
                if not f:continue
                expected=compose(f)
                if expected is None or max(hi-lo for lo,hi in expected)>.12:continue
                controls={}
                for policy in rejects:
                    wrong=compose(f,policy)
                    controls[policy]=wrong is not None and any(a[0]>b[1]+.04 or b[0]>a[1]+.04 for a,b in zip(expected,wrong))
                    rejects[policy]+=controls[policy]
                groups[group]+=1
                selected.append(dict(group=group,pixel=[px,py],bounds=expected,rejectingControls=controls))
    assert len(selected)>=300 and all(v>=50 for v in groups.values()),groups
    assert rejects['opaque']>=20 and rejects['default_cutoff']>=20,rejects
    report=dict(width=1025,height=289,oracle='Independent source rays, original node transforms, independent linear area mips and bilinear/trilinear sRGB/data samples, alpha cutoff and source-over',
                groups=groups,rejectingControls=rejects,pixels=selected,fixtureRevision=manifest['revision'])
    (out/'independent-input-reference.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(dict(prepared=len(selected),groups=groups,controls=rejects)),flush=True)
else:
    assert sys.argv[1]=='--check'
    reference=json.loads((out/'independent-input-reference.json').read_text(encoding='utf-8'))
    native=json.loads((out/'native.json').read_text(encoding='utf-8'))
    assert native['width']==1025 and native['height']==289 and len(native['formats'])==4
    report=dict(oracle=reference['oracle'],groups=reference['groups'],rejectingControls=reference['rejectingControls'],formats=[])
    for frame in native['formats']:
        precision=frame['precision'];data=(out/(precision+'.raw')).read_bytes();epsilon=.016 if precision=='Unorm8' else .012
        def pixel(x,y):
            offset=y*1025+x
            if precision=='Unorm8':
                values=data[offset*4:offset*4+4]
                return tuple(v/255 if ch==3 else linear(v/255) for ch,v in enumerate(values))
            code,size={'Unorm16':('H',8),'Float16':('e',8),'Float32':('f',16)}[precision]
            values=struct.unpack_from('<4'+code,data,offset*size)
            return tuple(v/65535 for v in values) if precision=='Unorm16' else values
        failures=[];excess=0.
        for sample in reference['pixels']:
            actual=pixel(*sample['pixel'])
            distance=max(max(lo-v,v-hi,0) for v,(lo,hi) in zip(actual,sample['bounds']))
            excess=max(excess,distance)
            if distance>epsilon:failures.append(dict(pixel=sample['pixel'],group=sample['group'],actual=actual,bounds=sample['bounds'],excess=distance))
        result=dict(precision=precision,checkedPixels=len(reference['pixels']),maximumExcess=excess,epsilon=epsilon,failures=len(failures),examples=failures[:8])
        report['formats'].append(result)
        (out/'independent-reference.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        assert not failures,result
        assert frame['draws']==9 and frame['blendedDraws']==2 and frame['frozenPixelsExact'],frame
        assert all(abs(v)<epsilon for v in pixel(0,0))
    print(json.dumps(report),flush=True)
