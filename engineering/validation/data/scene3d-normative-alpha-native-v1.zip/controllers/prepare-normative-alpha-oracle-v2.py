from pathlib import Path
import json, hashlib

root = Path('E:/Dev/aem')
tools = root / '.tools/issue-closure-review'
old = tools / 'check-normative-alpha-v1.py'
saved = root / 'artifacts/pr-queue/normative-alpha-oracle-preparation-v1'
saved.mkdir(exist_ok=True)
(saved / old.name).write_bytes(old.read_bytes())
(saved / 'disposition.json').write_text(json.dumps(dict(
    status='CPU reference preparation failed before native execution',
    cause='Unweighted source-neighborhood extrema excluded excessive filtered pixels',
    groups=dict(TestBlend=1, TestCutoff25=7, TestCutoff75=42, TestCutoffDefault=13, TestOpaque=41),
    sourceSha256=hashlib.sha256(old.read_bytes()).hexdigest(),
    assertionsPreserved=True), indent=2), encoding='utf-8')
text = old.read_text(encoding='utf-8')
text = text.replace('Independent source-ray/texture-footprint bounds', 'Independent source-ray/area-mip filtered reference')
text = text.replace('import hashlib,json,math,struct,sys', 'import hashlib,json,math,struct,sys\nimport numpy as np')
start = text.index('def texture(')
end = text.index('\ndef hits(', start)
replacement = '''# Independent offline reference: area-integrated mip images, standard normalized
# bilinear samples, and trilinear interpolation. Float64 NumPy is independent of
# the native Rust decoder/mip uploader and of the WGSL material program.
# The source textures here are all power-of-two, so each area cell is exact.
mip_cache={}
def mipmaps(index,color):
    key=(index,color)
    if key in mip_cache:return mip_cache[key]
    current=np.asarray(images[index],dtype=np.float64)/255
    if color:
        current=current.copy()
        rgb=current[:,:,:3]
        current[:,:,:3]=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)
    levels=[]
    while True:
        stored=current.copy()
        if color:
            rgb=stored[:,:,:3]
            stored[:,:,:3]=np.where(rgb<=.0031308,rgb*12.92,1.055*np.maximum(rgb,0)**(1/2.4)-.055)
        stored=np.floor(np.clip(stored,0,1)*255+.5)/255
        if color:
            rgb=stored[:,:,:3]
            stored[:,:,:3]=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)
        levels.append(stored)
        h,w,_=current.shape
        if h==w==1:break
        assert h%2==w%2==0
        current=current.reshape(h//2,2,w//2,2,4).mean(axis=(1,3))
    mip_cache[key]=levels
    return levels

def texture(slot,uv,derivatives,color=False):
    if slot is None:return [(1.,1.)]*4
    assert slot.get('texCoord',0)==0
    tex=d['textures'][slot['index']];sampler=d['samplers'][tex['sampler']]
    assert sampler.get('wrapS',10497)==sampler.get('wrapT',10497)==10497
    assert sampler.get('minFilter') is None and sampler.get('magFilter') is None
    levels=mipmaps(tex['source'],color);h,w,_=levels[0].shape
    rho=max(math.hypot(v[0]*w,v[1]*h) for v in derivatives)
    lod=max(0.,math.log2(max(rho,1.)))
    def sample(level):
        im=levels[level];h,w,_=im.shape
        x=(uv[0]%1)*w-.5;y=(uv[1]%1)*h-.5
        ix=math.floor(x);iy=math.floor(y);fx=x-ix;fy=y-iy
        return ((1-fy)*((1-fx)*im[iy%h,ix%w]+fx*im[iy%h,(ix+1)%w])+
                fy*((1-fx)*im[(iy+1)%h,ix%w]+fx*im[(iy+1)%h,(ix+1)%w]))
    # Hardware may approximate log2 LOD. Enclose +/- 0.02 mip levels before
    # looking at any native values; the existing output tolerances also remain.
    samples=[]
    for perturbation in [-.02,0.,.02]:
        level=min(max(lod+perturbation,0.),len(levels)-1)
        low=math.floor(level);high=min(low+1,len(levels)-1);f=level-low
        samples.append((1-f)*sample(low)+f*sample(high))
    values=np.asarray(samples)
    return [(max(0.,float(values[:,ch].min())-.001),min(1.,float(values[:,ch].max())+.001)) for ch in range(4)]
'''
text = text[:start] + replacement + text[end:]
text = text.replace('original node transforms, sRGB/data texture footprint bounds', 'original node transforms, independent linear area mips and bilinear/trilinear sRGB/data samples')
(tools/'check-normative-alpha-v2.py').write_text(text,encoding='utf-8')
