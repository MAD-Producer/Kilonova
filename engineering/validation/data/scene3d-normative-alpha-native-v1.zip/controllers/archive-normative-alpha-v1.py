from pathlib import Path
from datetime import datetime, timezone
from PIL import Image
import hashlib,json,zipfile

root=Path('E:/Dev/aem');art=root/'artifacts/pr-queue'
work=root/'.worktrees/native-camera-dof'
run=art/'normative-alpha-native-v2'
d=json.loads((run/'accepted.json').read_text(encoding='utf-8'))
assert d['sourceUnchanged'] and d['expectedPixelsPreparedBeforeNative']
assert len(d['reference']['formats'])==4 and all(f['failures']==0 and f['checkedPixels']==2024 for f in d['reference']['formats'])
assert all(f['defaultBudgetRefused'] and f['decodedImageBudgetBytes']==256<<20 and f['frozenPixelsExact'] for f in d['native']['formats'])
for path,sha in d['inheritedSource'].items():assert hashlib.sha256((work/path).read_bytes()).hexdigest()==sha,path
log=(run/'native/logs/motion-studio.log').read_text(encoding='utf-8')
stderr=(run/'native.stderr.log').read_text(encoding='utf-8')
assert log.count('decoded pixels exceed transient allowance')==stderr.count('decoded pixels exceed transient allowance')==4
assert 'start #87007 normative_alpha' in log and not (run/'native.stdout.log').read_bytes()
audit=dict(defaultInfoStart=True,errorFileAndStderr=True,stdoutBytes=0,defaultBudgetRefusals=4,
           explicitTransientBudgetBytes=256<<20,requiredPerImageBytes=192<<20,
           defaultProductBudgetBytes=128<<20,productBudgetUnchanged=True)
(run/'output-observation-audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
im=Image.frombytes('RGBA',(1025,289),(run/'native/Unorm8.raw').read_bytes())
im.save(run/'native/alpha-native-preview.png')
stage=art/'scene87-final-acceptance-staging';(stage/'data').mkdir(parents=True,exist_ok=True)
archive=stage/'data/scene3d-normative-alpha-native-v1.zip'
assert not archive.exists()
members={}
for name in ['normative-alpha-native-v2','normative-alpha-native-v1','normative-alpha-oracle-preparation-v1']:
    for path in (art/name).rglob('*'):
        if path.is_file():members[name+'/'+path.relative_to(art/name).as_posix()]=path
members['fixtures/manifest.json']=root/'.tools/gltf-scene87-normative-extra/manifest.json'
for name in ['prepare-normative-alpha-oracle-v2.py','archive-normative-alpha-v1.py']:
    members['controllers/'+name]=root/'.tools/issue-closure-review'/name
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,path in members.items():z.write(path,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,path in members.items():assert z.read(name)==path.read_bytes(),name
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
table='\n'.join(f"| {f['precision']} | {f['checkedPixels']} | {f['maximumExcess']:.9g} | {f['epsilon']} |" for f in d['reference']['formats'])
doc=f'''# Independent native alpha sample checkpoint

Issue 87's normative transparency comparison now has actual native pixels
from the unmodified Khronos AlphaBlendModeTest. The product source matches
PR 558 head `{d['head']}` and the accepted 1041-test aperture gate.
This checkpoint does not by itself close the issue or prove universal OIT.

## Source and licensing

The sample is pinned to glTF Sample Assets revision
`8f492390ddc7a2ae221a1369ef560589cf8c70fb`, by Ed Mackey / Analytical Graphics
Inc., 2018, CC-BY-4.0. Author, exact source, license and modification scope
are recorded in `ATTRIBUTION.md`; the external manifest retains every original
URL, byte length and SHA-256. Original glTF, buffers and textures are unchanged
and remain external. This archive contains independently authored probes,
reference code, native validation readbacks and reports; no upstream original
assets or screenshots are bundled in the product.

## Independent reference

The [glTF 2.0 specification](https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html#alpha-coverage)
defines OPAQUE, MASK and source-over BLEND, with linear alpha and sRGB base
color. The probe imports the whole original scene (nine draws, two blended
draws), including the occluding textured bed and arrows. An orthographic
camera and constant diffuse irradiance with no direct lights isolate these
rules from direct-light/normal-map differences. This is not a beauty-render
or environment-lighting reference.

Python independently decodes raw buffer accessors and original node
transforms, intersects source triangles at output pixel centres, interpolates
UVs, decodes original textures with Pillow, integrates linear area mip levels
with float64 NumPy, samples bilinear/trilinear repeat textures and applies
alpha cutoff and source-over. It does not consume converted importer geometry,
read back shader inputs or replay the native WGSL program. The reference and
negative-control pixel selection were persisted and hashed before native
execution, and their hash was verified unchanged after comparison.

There are 2024 interior pixels per precision: OPAQUE 415, BLEND 401,
cutoff 0.25 400, default cutoff 0.5 404, cutoff 0.75 404. Source-derived
triangle ties and uncertain cutoff/filter boundary pixels are excluded before
the GPU run. A fixed +/-0.02 mip LOD envelope and 0.001 sample rounding bound
account for hardware filtering; fixed final tolerances allow independent JPEG
decoder and output quantization differences. The controls distinguish an
all-opaque implementation at 953 pixels and a forced-default-cutoff
implementation at 158 pixels. Neither tolerances nor coverage assertions were
relaxed after seeing native values.

| Precision | Checked pixels | Maximum error outside reference bounds | Allowed error |
| --- | --- | --- | --- |
{table}

Each precision also checks a transparent clear corner and exact byte equality
after freezing, dropping the original GPU scene owner and restoring its owned
assets. All comparisons passed. This proves this source/camera/light/material
profile, not arbitrary intersecting translucent surfaces, which retain the
documented sorted-alpha limitation.

## Budget and output observations

The original 2048-square textures require 192 MiB conservative transient
decode admission. Default 128 MiB refusal is asserted in each precision, then
an explicit 256 MiB scene allowance is used for the reference run. No product
default, asset size or texture content was changed. Default-level Info start
is present, all four actual budget Errors reach both file and stderr, and
native stdout remains empty. The existing missing Epic overlay manifest
messages are retained in raw logs; they did not prevent successful rendering.

## Retained failures and evidence

The first CPU reference used unweighted neighborhood extrema and failed its
minimum stable-pixel coverage assertion before native execution. Version 2
replaced that conservative approximation with independently filtered source
samples while preserving the coverage/tolerance assertions. The first native
attempt then correctly refused the default decode budget; its original probe,
panic stack and logs are retained. The final probe explicitly tests that
refusal before using the larger admission. These are separate setup/reference
failures, not silently omitted product regressions.

Archive: `data/{archive.name}`, {len(members)} entries, {archive.stat().st_size}
bytes, SHA-256 `{sha}`. CRC and every member were read back and compared with
the original files. Full-workspace and exact-head maintained-desktop platform
acceptance remain separate gates. No UI, panels, product dependencies or
rendering source changed for this checkpoint.
'''
(stage/'scene3d-normative-alpha-native-current.md').write_text(doc,encoding='utf-8')
receipt=dict(archive=str(archive),sha256=sha,entries=len(members),bytes=archive.stat().st_size,sourceHead=d['head'],completedUtc=datetime.now(timezone.utc).isoformat())
(art/'scene3d-normative-alpha-archive-v1.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt),flush=True)
