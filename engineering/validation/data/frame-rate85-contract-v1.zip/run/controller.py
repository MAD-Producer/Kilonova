from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
out = root / 'artifacts/pr-queue/frame-rate85-contract-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
paths = ['crates/motion-model/src/frame_rate.rs','crates/motion-model/src/lib.rs','crates/motion-model/tests/frame_rate.rs']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = {p:sha(work / p) for p in paths}
env = os.environ.copy()
env.update(CARGO_HOME=str(root / '.tools/prerender-cargo-home'),
    CARGO_TARGET_DIR=str(root / 'target/rational-rate85-contract'), CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1',
    TEMP=str(root / 'target/ci-policy-validation-tmp'), TMP=str(root / 'target/ci-policy-validation-tmp'))
command = ['cargo','test','-p','motion-model','--test','frame_rate','--locked','--offline','--','--test-threads=1']
report = dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),source=sources,command=command,
    base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
    scope='Exact rate primitive and explicit quantized boundary conversions only; project/render/export adoption is unfinished')
def save():
    (out / 'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
save()
started = time.monotonic()
try:
    with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    assert report['exitCode'] == 0, 'rate contract gate failed; retain logs'
    assert '5 passed; 0 failed; 0 ignored' in (out/'stdout.log').read_text()
    assert all(sha(work/p) == value for p,value in sources.items())
    report['status'] = 'exact_rate_primitive_gate_passed_project_adoption_pending'
except BaseException as cause:
    report.update(status='failed',failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-started,3))
    save()
    print(json.dumps({k:report.get(k) for k in ['status','exitCode','elapsedSeconds','failure']},indent=2),flush=True)
