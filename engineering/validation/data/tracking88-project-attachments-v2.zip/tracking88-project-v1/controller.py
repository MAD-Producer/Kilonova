"""One serial owner for the new managed tracking attachment source snapshot."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-project-v1'

def now(): return datetime.now(timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
    return {n: sha(WORK / n) for n in git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
            if n and n.endswith(('.rs', '.toml', '.lock', '.wgsl', '.json', '.md', '.py', '.yml', '.yaml'))}

OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
report = dict(status='running', controllerPid=os.getpid(), startedUtc=now(), head=git('rev-parse','HEAD'),
              main=git('rev-parse','origin/main'), source=sources(), steps=[],
              limits='Managed original tracking attachments only; no pose evaluation, UI import, decoder PTS proof, Android or full-issue closure. Prior native AV remains unexplained; a later changed-source success does not repair it.')
def save():
    p=OUT/'exit.next.json'
    p.write_text(json.dumps(report,indent=2),encoding='utf-8')
    os.replace(p,OUT/'exit.json')
env=os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',
    PYTHONPATH=str(ROOT/'.tools/build-validation-python'),TEMP=str(ROOT/'target/ci-policy-validation-tmp'),TMP=str(ROOT/'target/ci-policy-validation-tmp'))

def step(name,args,count=None):
    row=dict(name=name,command=args,startedUtc=now())
    report['steps'].append(row);save()
    print(json.dumps(dict(start=name)),flush=True)
    with (OUT/f'{name}.stdout.log').open('wb') as stdout,(OUT/f'{name}.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        row['pid']=child.pid;save()
        row['exitCode']=child.wait()
    row['completedUtc']=now();save()
    assert row['exitCode']==0,f'{name}: actual failure retained; inspect before a later build'
    output=(OUT/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace')
    row['counts']=[tuple(map(int,x)) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',output)]
    save()
    if count is not None: assert row['counts']==[(count,0,0)],f'{name}: exact source coverage required'
    if name=='model-core-tests': assert row['counts'] and all(f==0 for _,f,_ in row['counts'])
    assert report['head']==git('rev-parse','HEAD') and report['source']==sources(),'source changed during validation'
    row['passed']=True;save()

save()
try:
    root=WORK/'crates/motion-host/src/lib.rs'
    before=sha(root);os.utime(root,None);assert sha(root)==before
    report['freshnessControl']=dict(root='crates/motion-host/src/lib.rs',sha256=before,appliedUtc=now());save()
    step('tracking76',['cargo','test','-p','motion-host','--lib','tracking::','--locked','--offline','--','--test-threads=1'],76)
    step('model-core-tests',['cargo','test','-p','motion-model','-p','motion-core','--locked','--offline','--','--test-threads=1'])
    step('desktop-check',['cargo','check','-p','motion-desktop','--locked','--offline'])
    step('host189',['cargo','test','-p','motion-host','--lib','--locked','--offline','--','--test-threads=1'],189)
    step('whitespace',['git','diff','--check'])
    report['status']='accepted_managed_attachment_increment_not_full_issue'
except BaseException as error:
    report.update(status='failed',failure=repr(error));raise
finally:
    report['completedUtc']=now();save()
