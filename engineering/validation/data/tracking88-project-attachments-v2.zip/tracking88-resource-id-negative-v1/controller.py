"""Actual failing control for resource allocation before the prepared correction."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-resource-id-negative-v1'
def now():return datetime.now(timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['git',*a],cwd=WORK).decode().strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():return {n:sha(WORK/n) for n in git('ls-files','--cached','--others','--exclude-standard','-z').split('\0') if n and n.endswith(('.rs','.toml','.lock','.wgsl','.json','.md','.py','.yml','.yaml'))}
prior=json.loads((ROOT/'artifacts/pr-queue/tracking88-project-v1/exit.json').read_text(encoding='utf-8'))
assert prior.get('completedUtc') and all('exitCode' in row for row in prior['steps'])
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report=dict(status='running',controllerPid=os.getpid(),head=git('rev-parse','HEAD'),source=sources(),startedUtc=now())
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
env=os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',PYTHONPATH=str(ROOT/'.tools/build-validation-python'),TEMP=str(ROOT/'target/ci-policy-validation-tmp'),TMP=str(ROOT/'target/ci-policy-validation-tmp'))
save()
try:
    root=WORK/'crates/motion-host/src/lib.rs'
    before=sha(root);os.utime(root,None);assert sha(root)==before
    command=['cargo','test','-p','motion-host','--lib','tracking::project::tests::subsequent_image_paste_skips_tracking_resource_ids','--locked','--offline','--','--exact','--test-threads=1']
    report['command']=command;save()
    with (OUT/'control.stdout.log').open('wb') as stdout,(OUT/'control.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        report['pid']=child.pid;save();report['exitCode']=child.wait()
    output=(OUT/'control.stdout.log').read_text(encoding='utf-8',errors='replace')
    report['counts']=[list(map(int,x)) for x in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',output)]
    assert report['exitCode']==101 and report['counts']==[[0,1,0]],'expected original collision not established'
    assert 'asset IDs must be unique and nonzero' in output,'failure was not the intended resource collision'
    assert report['source']==sources() and report['head']==git('rev-parse','HEAD')
    report['status']='expected_resource_id_collision_observed'
except BaseException as error:
    report.update(status='unexpected_failure',failure=repr(error));raise
finally:
    report['completedUtc']=now();save()
