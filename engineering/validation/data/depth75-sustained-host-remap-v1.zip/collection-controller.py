"""Retain the original sustained outcome; never run inference or change its gates."""
from pathlib import Path
import csv
import hashlib
import json
import math
import shutil
import zipfile

ART = Path('E:/Dev/aem/artifacts/pr-queue')
SOURCE = ART / 'depth75-sustained-host-remap-v1'
WORK = Path('E:/Dev/aem/.worktrees/depth-retained-context75')
OUT = ART / 'depth75-sustained-host-remap-public-v1'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def nearest_rank(values, proportion):
    ordered = sorted(values)
    return ordered[max(0, math.ceil(len(ordered) * proportion) - 1)] if ordered else None


report = read(SOURCE / 'receipt.json')
consumed = read(SOURCE / 'session-consumed.json')
assert report['status'] != 'running' and report['source_unchanged']
assert consumed['session'] == 71816 and consumed['original_tool_result_consumed']
assert consumed['head'] == report['head'] and consumed['source_freeze_released']
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'collection-controller.py')


def retain(origin, name):
    destination = OUT / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(origin, destination)


for name in ('controller.py', 'protocol.md', 'receipt.json', 'session-consumed.json',
             'owned-job-counter-control.json', 'readings.jsonl'):
    origin = SOURCE / name
    if origin.is_file():
        retain(origin, name)
retain(ART / 'depth75-sustained-host-remap-v1-consume.py', 'consume-controller.py')
for name, expected in report['retained_logs'].items():
    origin = SOURCE / name
    assert origin.stat().st_size == expected['bytes'] and sha(origin) == expected['sha256']
    retain(origin, name)
for name in ('crates/motion-host/examples/depth_reference.rs',
             'crates/motion-host/examples/depth_reference/sustained.rs'):
    assert sha(WORK / name) == report['source_sha256'][name]
    retain(WORK / name, 'source/' + name)
for path in sorted((SOURCE / 'workload/logs').rglob('*')):
    if path.is_file():
        retain(path, 'workload/logs/' + path.relative_to(SOURCE / 'workload/logs').as_posix())
sustained_path = SOURCE / 'workload/sustained.json'
sustained = read(sustained_path) if sustained_path.is_file() else None
if sustained is not None:
    retain(sustained_path, 'workload/sustained.json')
rows = []
cohorts = []
outputs = []
for path in sorted((SOURCE / 'workload').glob('cohort-*/measurements.json')):
    measured = read(path)
    retain(path, 'workload/' + path.relative_to(SOURCE / 'workload').as_posix())
    cohorts.append(dict(directory=path.parent.name, status=measured['status'],
                        samples=len(measured['samples']), cause=measured['cause']))
    for row in measured['samples']:
        output = path.parent / row['output']['filename']
        assert output.stat().st_size == row['output']['bytes'] and sha(output) == row['output']['sha256']
        rows.append(row)
        outputs.append(dict(cohort=row['cohort'], index=row['index'], request=row['request'],
                            output=row['output'], execution=row['execution'], input=row['input']))
(OUT / 'output-identities.json').write_text(json.dumps(outputs, indent=2) + '\n', encoding='utf-8')
latencies = {field: dict(samples=len(rows), minimum=min([r[field] for r in rows], default=None),
                         median_nearest_rank=nearest_rank([r[field] for r in rows], .5),
                         p95_nearest_rank=nearest_rank([r[field] for r in rows], .95),
                         maximum=max([r[field] for r in rows], default=None))
             for field in ('worker_total_ns', 'resolve_ns', 'preprocess_ns', 'inference_ns',
                           'postprocess_ns', 'host_transport_ns', 'caller_rgb_load_ns', 'caller_output_ns')}
readings_path = SOURCE / 'readings.jsonl'
readings = [json.loads(line) for line in readings_path.read_text().splitlines()] if readings_path.is_file() else []
jobs = [r['job'] for r in readings]
assert all(r['limit_flags'] == 0 and r['resident_bytes'] is None and r['device_bytes'] is None for r in jobs)
fields = ['uuid', 'name', 'driver_version', 'temperature.gpu', 'memory.used', 'memory.total',
          'power.draw', 'power.limit', 'clocks.current.graphics', 'clocks.current.memory',
          'utilization.gpu', 'clocks_event_reasons.hw_thermal_slowdown',
          'clocks_event_reasons.sw_thermal_slowdown']
sensor_rows = []
for item in readings:
    raw = item['sensor']
    if raw.get('exit_code') == 0 and not raw.get('stderr'):
        values = list(csv.reader(raw['stdout'].splitlines(), skipinitialspace=True))
        if len(values) == 1 and len(values[0]) == len(fields):
            sensor_rows.append(dict(zip(fields, [v.strip() for v in values[0]])))
thermal_active = [dict(index=i, field=field) for i, r in enumerate(sensor_rows)
                  for field in fields[-2:] if r[field] == 'Active']
collection = dict(status=report['status'], head=report['head'], session=71816,
                  exit_code=consumed['exit_code'], qualified=False,
                  sustained_status=sustained['status'] if sustained else None,
                  duration_ns=sustained['elapsed_ns'] if sustained else None,
                  cohorts=cohorts, complete_rows=len(rows), latency_ns=latencies,
                  observations=len(readings), parsed_sensor_rows=len(sensor_rows),
                  maximum_job_committed_bytes=max([r['peak_job_commit_bytes'] for r in jobs], default=None),
                  whole_device_allocation_peak_bytes=None, thermal_active=thermal_active,
                  controller_summary={k: report.get(k) for k in
                      ('cause', 'complete_outputs', 'native_gpu_pids', 'sampled_sensors',
                       'maximum_observation_gap_seconds', 'job_after_workload',
                       'original_child_exit_after_observation_failure')},
                  limits=['Raw outputs stay local; every retained output was rehashed without rerunning inference',
                          'Whole-job committed peak is not physical resident or device allocation',
                          'Whole-device sensor samples include unrelated activity',
                          'Repeated inputs are not independent domain-quality samples',
                          'All original failed commands, partial cohorts and refusal limits remain unchanged'])
(OUT / 'collection.json').write_text(json.dumps(collection, indent=2) + '\n', encoding='utf-8')
members = {p.relative_to(OUT).as_posix(): dict(bytes=p.stat().st_size, sha256=sha(p))
           for p in sorted(OUT.rglob('*')) if p.is_file()}
archive = OUT / 'depth75-sustained-host-remap-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
    for name in members:
        target.write(OUT / name, name)
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(members)
    for name, expected in members.items():
        raw = target.read(name)
        assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256']
manifest = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=members,
                readback='Every member CRC, byte length and SHA-256 verified', qualified=False)
(OUT / 'depth75-sustained-host-remap-v1.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: manifest[k] for k in ('archive', 'bytes', 'sha256')}))
