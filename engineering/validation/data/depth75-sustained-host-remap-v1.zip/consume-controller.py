"""Consume the original sustained controller result, without executing workloads."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import subprocess

ART = Path('E:/Dev/aem/artifacts/pr-queue')
WORK = Path('E:/Dev/aem/.worktrees/depth-retained-context75')
OUT = ART / 'depth75-sustained-host-remap-v1'
CP = ART / 'depth75-resume-current.json'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument('--original-exit-code', required=True, type=int)
parser.add_argument('--original-chunk-id', required=True)
args = parser.parse_args()
report = read(OUT / 'receipt.json')
assert report['status'] != 'running' and report.get('completed_utc')
expected = 0 if report['status'] == 'one_service_complete_sustained_exact_output_observed_not_qualified' and report['source_unchanged'] else 1
assert args.original_exit_code == expected
assert report['source_unchanged']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == report['head']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK, text=True).strip()
for name, digest in report['source_sha256'].items():
    assert sha(WORK / name) == digest, name
for name, expected_log in report['retained_logs'].items():
    path = OUT / name
    assert path.stat().st_size == expected_log['bytes'] and sha(path) == expected_log['sha256']
receipt = dict(session=71816, exit_code=args.original_exit_code,
               original_tool_result_consumed=True, original_chunk_id=args.original_chunk_id,
               source_unchanged=True, source_freeze_released=True, head=report['head'],
               observation_status=report['status'], qualified=False,
               observed_utc=datetime.now(timezone.utc).isoformat())
with (OUT / 'session-consumed.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
state = read(CP)
v = state['versionedCache75']
assert Path(v['activeController']) == ART / 'depth75-sustained-host-remap-v1-controller.py'
assert v['currentSustainedHostRemap']['session'] == 71816
v.update(activeController=None, ownHeavyWorkloads=[], currentSustainedHostRemap=receipt,
         currentLocalSourceHead=report['head'], localUnpublishedHead=report['head'])
temporary = CP.with_suffix('.json.pending')
temporary.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
temporary.replace(CP)
print(json.dumps(receipt))
