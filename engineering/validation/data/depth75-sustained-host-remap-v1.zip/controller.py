"""Pending one-service sustained observation. Never rerun a failed invocation.

Only launch after the original full run is consumed, the pending source is
applied/committed, and the separate owned-job counter control has passed.
"""
from pathlib import Path
from datetime import datetime, timezone
import csv
import hashlib
import importlib.util
import json
import math
import os
import platform
import shutil
import subprocess
import time
import traceback

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-retained-context75'
TARGET = ROOT / 'target/depth-wgsl-cache75-contract'
OUT = ART / 'depth75-sustained-host-remap-v1'
CP = ART / 'depth75-resume-current.json'
INPUTS = ART / 'depth75-reference-inputs-v1'
COLD = ART / 'depth75-sustained-reference-v1/cohort-00'
SENSOR = Path('C:/Windows/System32/nvidia-smi.exe')
FIELDS = ['uuid', 'name', 'driver_version', 'temperature.gpu', 'memory.used',
          'memory.total', 'power.draw', 'power.limit', 'clocks.current.graphics',
          'clocks.current.memory', 'utilization.gpu',
          'clocks_event_reasons.hw_thermal_slowdown',
          'clocks_event_reasons.sw_thermal_slowdown']


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def write(path, value):
    pending = path.with_suffix(path.suffix + '.pending')
    pending.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    pending.replace(path)


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=WORK, text=True).strip()


def finite_number(value):
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except (TypeError, ValueError):
        return None


def main():
    assert shutil.disk_usage(ROOT).free >= 10 << 30
    state = read(CP)
    current = state['versionedCache75']
    assert current['activeController'] is None and not current['ownHeavyWorkloads']
    consumed = read(ART / 'depth75-host-remap-workspace-v1/session-consumed.json')
    assert consumed['original_tool_result_consumed'] and consumed['session'] == 82855
    assert consumed['source_unchanged'] and consumed['source_freeze_released']
    component_root = ART / 'depth75-sustained-host-example-controls-v1'
    component = read(component_root / 'receipt.json')
    component_consumed = read(component_root / 'session-consumed.json')
    assert component_consumed['original_tool_result_consumed'] and component_consumed['exit_code'] == 0
    assert component['complete_example_controls'] == dict(passed=4, failed=0, ignored=0, filtered=0)
    for name in ('crates/motion-host/examples/depth_reference.rs',
                 'crates/motion-host/examples/depth_reference/sustained.rs'):
        assert sha(WORK / name) == component['source_sha256'][name]
    # This is a new explicitly selected observation, never a substitute for the
    # failed full command or a restart of its sampled-playback child.
    control_path = ART / 'depth75-owned-job-memory-control-v1/receipt.json'
    control = read(control_path)
    assert control['status'] == 'passed' and not control['cleanup_failures']
    assert not git('status', '--porcelain')
    source_file = WORK / 'crates/motion-host/examples/depth_reference/sustained.rs'
    assert source_file.read_bytes() == (ART / 'depth75-sustained-host-proposal/sustained.rs').read_bytes()
    assert not {'RUST_MIN_STACK', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'} & os.environ.keys()
    head = git('rev-parse', 'HEAD')
    paths = git('ls-files').splitlines()

    def sources():
        return {name: sha(WORK / name) for name in paths}

    OUT.mkdir(exist_ok=False)
    shutil.copyfile(__file__, OUT / 'controller.py')
    shutil.copyfile(ART / 'depth75-sustained-host-proposal/protocol.md', OUT / 'protocol.md')
    shutil.copyfile(control_path, OUT / 'owned-job-counter-control.json')
    ff = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
    env = {k: v for k, v in os.environ.items() if not k.startswith('MOTION_')}
    env.update(CARGO_HOME=str(ROOT / '.tools/prerender-cargo-home'),
               CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
               CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
               TEMP=str(TARGET / 'tmp'), TMP=str(TARGET / 'tmp'),
               LOCALAPPDATA=str(OUT / 'appdata'), RUST_BACKTRACE='full', PYTHONDONTWRITEBYTECODE='1',
               LIBCLANG_PATH=str(ROOT / '.tools/python-libclang/clang/native'),
               FFMPEG_DIR=str(ff), FFMPEG_INCLUDE_DIR=str(ff / 'include'), FFMPEG_LIB_DIR=str(ff / 'lib'))
    env['PATH'] = str(ff / 'bin') + os.pathsep + env['PATH']
    report = dict(status='running', head=head, source_sha256=sources(), started_utc=now(),
                  stages=[], observations=0, protocol_sha256=sha(OUT / 'protocol.md'), qualified=False,
                  protocol=dict(minimum_seconds=1800, maximum_cohorts=64, samples_per_cohort=32,
                                maximum_readings=4500, requested_gap_seconds=1,
                                maximum_observation_gap_seconds=5, sensor_query_timeout_seconds=10,
                                request_wait_seconds=60),
                  limits=[
                      'One original ordered repeated cohort stream; no retry, warmup deletion or hidden cached inference',
                      'Repeated frames are load observations, not independent domain-quality samples',
                      'Job committed-memory peak includes this observer, its sensors and all workload descendants',
                      'Job committed memory is not RSS, physical memory or GPU allocation',
                      'Whole-device sensors include unrelated activity; sampled maxima are not continuous allocation peaks',
                      'Prior Python, native and full-workspace failures remain failed; no fallback or waiver',
                      'No Android, panels, acquisition, process inspection, resource limit or foreign process change',
                  ])

    def save():
        write(OUT / 'receipt.json', report)

    def frozen():
        return git('rev-parse', 'HEAD') == head and not git('status', '--porcelain') and sources() == report['source_sha256']

    def command(label, arguments):
        row = dict(label=label, arguments=[str(a) for a in arguments], started_utc=now())
        report['stages'].append(row)
        save()
        with (OUT / (label + '.stdout.log')).open('wb') as stdout, (OUT / (label + '.stderr.log')).open('wb') as stderr:
            child = subprocess.Popen(arguments, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
            row['pid'] = child.pid
            save()
            row['exit_code'] = child.wait()
        save()
        assert row['exit_code'] == 0 and frozen(), row

    current.update(activeController=str(Path(__file__)), ownHeavyWorkloads=[dict(
        kind='one retained GPU service sustained host-remap observation', head=head,
        sourceFrozen=True, output=str(OUT))])
    write(CP, state)
    save()
    child = None
    job = None
    try:
        # The complete unchanged four-test example target already passed and its
        # original result was consumed above. Build binds the actual run binary.
        command('example-build', ['cargo', 'build', '-p', 'motion-host', '--features', 'ai-depth',
                                 '--example', 'depth_reference', '--locked', '--offline'])
        plan = read(INPUTS / 'inputs.json')
        cold = read(COLD / 'measurements.json')
        assert len(plan) == len(cold['samples']) == 32 and cold['status'] == 'completed'
        assert sha(INPUTS / 'inputs.json') == '5d04789d924786b1b6513a97cad2bd10957a3245aa6fb934ef6f209b4a82679a'
        assert sha(COLD / 'measurements.json') == 'd1ce532291ca2b29647c3c57544e9801114a61943b3d3223d89fb949e2938a8e'
        for index, source in enumerate(plan):
            assert source['index'] == index and sha(INPUTS / source['rgb_input']['filename']) == source['rgb_input']['sha256']
            output = cold['samples'][index]['output']
            assert sha(COLD / output['filename']) == output['sha256']
        driver = TARGET / 'debug/examples/depth_reference.exe'
        worker = TARGET / 'debug/motion-depth-wgsl.exe'
        python = ROOT / '.tools/ai-depth74/venv/Scripts/python.exe'
        model = ART / 'depth75-resolution-models-v1/518/export/depth_anything_v2_vits_518.onnx'
        program = ART / 'depth75-wgsl-cache-resources-v2/program.json'
        assert sha(model) == '274368034c0fcef08f9b197d33b606bae9c578acca861ef72feb268143b21434'
        assert sha(program) == '2ec1d8012905198cfd5af1430f88d1770edbf752531fe817dfcc65e1477fef6a'
        bindings = {str(p): sha(p) for p in (driver, worker, python, model, program, INPUTS / 'inputs.json')}
        report['identities'] = bindings
        module_path = ART / 'depth75-owned-job-memory-proposal.py'
        assert sha(module_path) == '6afcfc4357d6c46dd3e0198ae693e816d75522b88d6ff9f83df11283e517bb9d'
        spec = importlib.util.spec_from_file_location('owned_depth_job_observer', module_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        # Compilation children already exited. No resource limits or external
        # handles are configured by this newly created observer-owned job.
        job = module.OwnedJob()
        report['job_before_workload'] = job.snapshot()
        report['environment'] = dict(os=platform.platform(), machine=platform.machine())
        readings = []

        def observe():
            assert len(readings) < 4500, 'observation bound reached; no eviction or extension'
            start = time.monotonic_ns()
            row = dict(start_monotonic_ns=start, utc=now(), job=job.snapshot())
            try:
                result = subprocess.run([str(SENSOR), '--query-gpu=' + ','.join(FIELDS),
                                         '--format=csv,noheader,nounits'], capture_output=True,
                                        timeout=10, env=env)
                row['sensor'] = dict(exit_code=result.returncode,
                                     stdout=result.stdout.decode('utf-8', errors='replace'),
                                     stderr=result.stderr.decode('utf-8', errors='replace'))
            except subprocess.TimeoutExpired as cause:
                row['sensor'] = dict(timeout=True, stdout=repr(cause.stdout), stderr=repr(cause.stderr))
            row['end_monotonic_ns'] = time.monotonic_ns()
            with (OUT / 'readings.jsonl').open('a', encoding='utf-8') as stream:
                stream.write(json.dumps(row) + '\n')
            readings.append(row)
            report['observations'] = len(readings)
            raw = row['sensor']
            assert raw.get('exit_code') == 0 and not raw['stderr'], 'original sensor failure retained'
            assert len(raw['stdout'].encode()) <= 4096
            values = list(csv.reader(raw['stdout'].splitlines(), skipinitialspace=True))
            assert len(values) == 1 and len(values[0]) == len(FIELDS)
            row['values'] = dict(zip(FIELDS, (v.strip() for v in values[0])))
            identity = {k: row['values'][k] for k in ('uuid', 'name', 'driver_version')}
            if 'gpu' not in report['environment']:
                report['environment']['gpu'] = identity
            assert report['environment']['gpu'] == identity
            save()

        observe()
        arguments = [str(p) for p in (driver, 'wgsl-retained-rust-remap-sustained', python,
                                      model, program, worker, INPUTS, OUT / 'workload')]
        stage = dict(label='actual-sustained', arguments=arguments, started_utc=now())
        report['stages'].append(stage)
        save()
        with (OUT / 'actual-sustained.stdout.log').open('wb') as stdout, (OUT / 'actual-sustained.stderr.log').open('wb') as stderr:
            child = subprocess.Popen(arguments, cwd=WORK, env=env, stdout=stdout, stderr=stderr)
            stage['pid'] = child.pid
            save()
            assert job.contains_owned_child(child)
            while child.poll() is None:
                observe()
                time.sleep(1)
            stage['exit_code'] = child.wait()
            # Close only our completed direct child's retained Windows handle;
            # this does not terminate it or alter the kernel-maintained peak.
            child._handle.Close()
        observe()
        save()
        assert stage['exit_code'] == 0, 'original sustained failure retained; no retry'
        assert not (OUT / 'actual-sustained.stdout.log').read_bytes()
        sustained = read(OUT / 'workload/sustained.json')
        assert sustained['status'] == 'completed' and sustained['elapsed_ns'] >= 1800 * 10**9
        assert 1 <= len(sustained['cohorts']) <= 64
        gpu_pids = set()
        execution = None
        total = 0
        for ordinal, cohort in enumerate(sustained['cohorts']):
            assert cohort['cohort'] == ordinal and cohort['directory'] == f'cohort-{ordinal:02}'
            directory = OUT / 'workload' / cohort['directory']
            measured = read(directory / 'measurements.json')
            assert measured['status'] == 'completed' and len(measured['samples']) == 32
            for index, sample in enumerate(measured['samples']):
                assert sample['index'] == index and sample['cohort'] == ordinal
                assert sample['request'] == ordinal * 32 + index + 1
                assert sample['split'] == plan[index]['split']
                if execution is None:
                    execution = sample['execution']
                assert sample['execution'] == execution
                output = directory / sample['output']['filename']
                assert output.stat().st_size == 640 * 480 * 4
                expected = COLD / cold['samples'][index]['output']['filename']
                assert sha(output) == sample['output']['sha256'] == cold['samples'][index]['output']['sha256']
                assert output.read_bytes() == expected.read_bytes()
                memory = sample['process_memory']
                children = memory['children']
                assert children['backend'] == 'wgsl_retained_host_remap'
                assert memory['host']['pid'] == children['host_remap']['pid'] == child.pid
                gpu_pids.add(children['inference']['pid'])
                assert sample['retained_gpu_buffer_capacity_bytes'] == 227968156
                assert sample['observed_resident_sum_bytes'] is None
                total += 1
            summary = measured['summary']
            assert summary['submitted'] == summary['completed'] == (ordinal + 1) * 32
            assert all(summary[k] == 0 for k in ('failed', 'canceled', 'cache_hits', 'cache_misses', 'restored'))
        assert len(gpu_pids) == 1 and not list((OUT / 'workload/scratch').iterdir())
        assert all(any(pid in row['job']['member_pids'] for row in readings) for pid in gpu_pids)
        gaps = [(b['start_monotonic_ns'] - a['end_monotonic_ns']) / 1e9 for a, b in zip(readings, readings[1:])]
        assert gaps and max(gaps) <= 5, 'original observation gap exceeded; no interpolation or retry'
        temperatures = [finite_number(row['values']['temperature.gpu']) for row in readings]
        known_temperatures = [value for value in temperatures if value is not None]
        assert all(-273.15 <= value <= 200 for value in known_temperatures)
        memories = [finite_number(row['values']['memory.used']) for row in readings]
        known_memories = [value for value in memories if value is not None]
        thermal_fields = ('clocks_event_reasons.hw_thermal_slowdown',
                          'clocks_event_reasons.sw_thermal_slowdown')
        thermal_values = [row['values'][field] for row in readings for field in thermal_fields]
        known_flags = [value for value in thermal_values if value in ('Active', 'Not Active')]
        report.update(status='one_service_complete_sustained_exact_output_observed_not_qualified',
                      complete_outputs=total, cohorts=len(sustained['cohorts']), native_gpu_pids=sorted(gpu_pids),
                      driver_report_sha256=sha(OUT / 'workload/sustained.json'),
                      maximum_observation_gap_seconds=max(gaps), job_after_workload=job.snapshot(),
                      maximum_job_committed_bytes=job.snapshot()['peak_job_commit_bytes'],
                      whole_device_allocation_peak_bytes=None,
                      sampled_sensors=dict(
                          count=len(readings), usable_temperature_samples=len(known_temperatures),
                          maximum_temperature_celsius=max(known_temperatures) if known_temperatures else None,
                          first_temperature_celsius=temperatures[0], last_temperature_celsius=temperatures[-1],
                          complete_temperature_coverage=len(known_temperatures) == len(readings),
                          thermal_slowdown_observed='Active' in known_flags if known_flags else None,
                          complete_thermal_flag_coverage=len(known_flags) == len(thermal_values),
                          maximum_whole_device_memory_observed_mib=max(known_memories) if known_memories else None,
                          complete_memory_sample_coverage=len(known_memories) == len(readings)))
    except BaseException:
        report.update(status='failed_original_outputs_retained', cause=traceback.format_exc())
    finally:
        # Observe the originally launched model process to its own terminal
        # state after an observer error; no termination/restart is introduced.
        if child is not None and child.poll() is None:
            report['original_child_exit_after_observation_failure'] = child.wait()
        if job is not None:
            try:
                job.close()
            except BaseException:
                report['job_handle_cleanup_failure'] = traceback.format_exc()
                if report['status'] != 'failed_original_outputs_retained':
                    report['status'] = 'failed_original_outputs_retained'
        report.update(source_unchanged=frozen(), completed_utc=now())
        report['retained_logs'] = {p.name: dict(bytes=p.stat().st_size, sha256=sha(p))
                                   for p in OUT.glob('*.log')}
        save()
        print(json.dumps({k: report.get(k) for k in ('status', 'complete_outputs', 'cohorts', 'source_unchanged')}))
    return 0 if report['status'] == 'one_service_complete_sustained_exact_output_observed_not_qualified' and report['source_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
