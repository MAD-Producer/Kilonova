from pathlib import Path
import subprocess,json,hashlib,shutil,time,os
root=Path('E:/Dev/aem');out=root/'.tools/empty-layer-selection';work=root/'.worktrees/empty-layer-selection'
load=lambda n:json.loads((out/n).read_text(encoding='utf8'))
frozen=load('current-main-receipt.json');assert frozen['exit_code']==0 and frozen['source_unchanged']
assert '550 passed; 0 failed; 1 ignored' in (out/'current-main-panels.log').read_text(encoding='utf8')
assert all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in frozen['sources'].items())
command=['cargo','build','-p','motion-desktop','--bin','motion-studio','--config','profile.dev.package.motion-desktop.debug=0','--config','profile.dev.package.motion-desktop.codegen-units=256','--locked','--offline','-j1'];start=time.monotonic()
with (out/'native-build.log').open('w',encoding='utf8') as log:r=subprocess.run(command,cwd=work,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
folder=out/'native';folder.mkdir(exist_ok=False);binary=folder/'motion-studio.exe';shutil.copy2(root/'target/debug/motion-studio.exe',binary)
record=dict(frozen,command=command,seconds=round(time.monotonic()-start,2),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),source_unchanged=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in frozen['sources'].items()))
assert record['source_unchanged'];(out/'native-build-receipt.json').write_text(json.dumps(record,indent=2),encoding='utf8')
s=(root/'.tools/cache-current-main-integration/run_native_case.py').read_text(encoding='utf8').replace('E:/Dev/aem/.worktrees/cache-current-main-integration','E:/Dev/aem/.worktrees/empty-layer-selection');(out/'run_native_case.py').write_text(s,encoding='utf8')
env=os.environ.copy();env.pop('MOTION_LOG',None)
with (out/'default-en-properties.log').open('w',encoding='utf8') as log:r=subprocess.run(['python',str(out/'run_native_case.py'),'default-en-properties'],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=270)
assert r.returncode==0
print('Current-main panels and native English property capture passed; upstream manual key-drag capture remains ignored.',flush=True)
