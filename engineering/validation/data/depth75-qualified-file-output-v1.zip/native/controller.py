"""Supplementary real-sink proof; run only after original native33029 consumed."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, traceback

ROOT=Path('E:/Dev/aem'); BASE=ROOT/'artifacts/pr-queue'
WORK=ROOT/'.worktrees/depth-wgsl-cache75';TARGET=ROOT/'target/depth-wgsl-cache75-contract'
PARENT=BASE/'depth75-qualified-runtime-binding-v1';OUT=BASE/'depth75-qualified-file-output-v1'
parent=json.loads((PARENT/'receipt.json').read_text(encoding='utf-8'))
assert json.loads((PARENT/'session-consumed.json').read_text())==dict(session=33029,consumed=True,exit_code=1)
assert parent['status']=='failed_original_outputs_retained' and parent['source_unchanged']
audit=json.loads((PARENT/'independent-failure-audit.json').read_text(encoding='utf-8'))
assert audit['full_target_coverage'] and len(audit['observed_targets'])==175
assert audit['totals']['failed']==1 and audit['totals']['filtered']==0
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
assert shutil.disk_usage(ROOT).free>=10<<30
assert not {'RUST_MIN_STACK','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'} & os.environ.keys()
HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
production=['crates/motion-host/src/depth.rs','crates/motion-host/src/depth/capability/policy.rs',
 'crates/motion-host/src/session/depth.rs','crates/motion-host/Cargo.toml','Cargo.toml','Cargo.lock']
for name in production:
    assert subprocess.check_output(['git','rev-parse',HEAD+':'+name],cwd=WORK)==subprocess.check_output(['git','rev-parse',parent['head']+':'+name],cwd=WORK),name
assert (WORK/'crates/motion-host/tests/depth_capability/file_output.rs').exists()
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def hashes():return {p:sha(WORK/p) for p in paths}
env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(TARGET),
 CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',
 TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),LOCALAPPDATA=str(OUT/'appdata'),RUST_BACKTRACE='full',
 MOTION_TEST_QUALIFIED_FILE_EVIDENCE=str(OUT/'default-file-proof'))
env['PATH']=str(ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')+';'+env['PATH']
report=dict(status='running',head=HEAD,source_sha256=hashes(),stages=[],started_utc=datetime.now(timezone.utc).isoformat(),
 predecessor=dict(head=parent['head'],receipt_sha256=sha(PARENT/'receipt.json'),totals=audit['totals'],source_bound_targets=175,
 status='original full command remains failed; new fixture did not submit settled request'),
 limits=['Production identity/source/cache/manifest bytes match the complete175-target failed predecessor',
 'New fixture gains initial Idle100 tick; existing assertions, policy, product source and ignored cases unchanged',
 'New actual-sink test and both complete capability/Session targets run without filtering; skipped actual product build also runs',
 'Controlled backend and external admission fixtures, not actual learned-model/device qualification',
 'Child stdout must contain only the expected Rust test harness; no product records are allowed',
 'No retry, weakened assertion/deadline, own concurrent heavy workload, Android, panel edits or cleanup'])
def save():
    p=OUT/'receipt.pending.json';p.write_text(json.dumps(report,indent=2),encoding='utf-8');os.replace(p,OUT/'receipt.json')
save()
try:
    for item in parent['runtime_colocation']:assert sha(Path(item['path']))==item['sha256']
    features='motion-host/ai-depth,motion-host/gpu-tests,motion-render/gpu-tests,motion-desktop-media/ai-depth,motion-desktop-media/gpu-tests,motion-desktop-media/ffmpeg'
    command=['cargo','test','--locked','--offline','-p','motion-host','-p','motion-render','-p','motion-desktop-media',
      '--features',features,'--test','depth_capability','--test','depth_session','--','--test-threads=1']
    row=dict(name='complete-capability-and-session-with-file-proof',command=command);report['stages'].append(row);save()
    with (OUT/'native.stdout.log').open('wb') as stdout,(OUT/'native.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        row['pid']=child.pid;save();row['exit_code']=child.wait()
    save();assert row['exit_code']==0,'original failed outputs retained; no retry'
    stdout=(OUT/'native.stdout.log').read_text(encoding='utf-8');stderr=(OUT/'native.stderr.log').read_text(encoding='utf-8')
    names=[]
    for name,prefix in [('crates/motion-host/tests/depth_capability.rs',''),
                        ('crates/motion-host/tests/depth_capability/bindings.rs','bindings::'),
                        ('crates/motion-host/tests/depth_capability/file_output.rs','bindings::file_output::'),
                        ('crates/motion-host/tests/depth_session/transitions/qualified.rs','transitions::qualified::')]:
        names.extend(prefix+n for n in re.findall(r'#\[test\]\s*fn ([a-z_]+)\(', (WORK/name).read_text(encoding='utf-8')))
    assert len(names)==40
    for name in names:assert len(re.findall(r'^test '+re.escape(name)+r' \.\.\. ok$',stdout,re.M))==1,name
    summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',stdout,re.M)
    assert summaries==[('ok','38','0','0','0','0'),('ok','32','0','0','0','0')]
    invocations=re.findall(r'^\s*Running .+?\(([^\r\n]+\.exe)\)',stderr,re.M);assert len(invocations)==2
    dep_info=Path(invocations[0]).with_suffix('.d').read_bytes()
    for name in ('depth_capability.rs','depth_capability/file_output.rs','logging/sink.rs'):
        assert name in dep_info.decode('utf-8').replace('\\','/')
    proof=json.loads((OUT/'default-file-proof/proof.json').read_text())
    assert proof['default_level']=='Info' and proof['file_start_before_resolution_return'] and proof['error_file_before_drop']
    assert proof['backend_inferences']==0 and proof['failed']==1 and proof['asset']==75002
    logs=(OUT/'default-file-proof/motion-studio.log').read_text(encoding='utf-8')
    console=(OUT/'default-file-proof/child.stderr.log').read_text(encoding='utf-8')
    harness=(OUT/'default-file-proof/child.stdout.log').read_text(encoding='utf-8')
    assert proof['cause'] in logs and proof['cause'] in console
    assert 'qualified execution differs' not in harness and 'depth_qualification' not in harness
    session_dep_info=Path(invocations[1]).with_suffix('.d').read_bytes()
    assert 'depth_session/transitions/qualified.rs' in session_dep_info.decode('utf-8').replace('\\','/')
    report.update(native_validation='complete70_capability_session_and_actual_default_file_stderr_stdout_isolation_passed',
      named_passes=names,totals=dict(passed=70,failed=0,ignored=0,filtered=0),actual_proof=proof,
      executables=invocations,dep_info_sha256=[hashlib.sha256(v).hexdigest() for v in (dep_info,session_dep_info)])
    save()
    command=['cargo','build','--locked','--offline','-p','motion-host','-p','motion-desktop','-p','motion-desktop-media',
      '--example','depth_capability','--example','depth_video_capability','--bin','motion-depth-wgsl',
      '--features','motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth']
    row=dict(name='actual-product-build',command=command);report['stages'].append(row);save()
    with (OUT/'actual-product-build.stdout.log').open('wb') as stdout,(OUT/'actual-product-build.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        row['pid']=child.pid;save();row['exit_code']=child.wait()
    save();assert row['exit_code']==0,'original failed product build retained; no retry'
    report['status']='complete70_capability_session_default_file_proof_and_product_build_passed'
except BaseException:
    report['status']='failed_original_outputs_retained';report['cause']=traceback.format_exc();save();raise
finally:
    report['source_unchanged']=hashes()==report['source_sha256'];report['finished_utc']=datetime.now(timezone.utc).isoformat();save()
    assert report['source_unchanged'],'source changed while supplementary native controller ran'
