"""Archive the completed supplement without relabeling its failed predecessor."""
from pathlib import Path
import hashlib,json,subprocess,zipfile

ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/depth-wgsl-cache75'
OUT=ROOT/'artifacts/pr-queue/depth75-qualified-file-output-v1'
r=json.loads((OUT/'receipt.json').read_text(encoding='utf-8'))
consumed=json.loads((OUT/'session-consumed.json').read_text(encoding='utf-8'))
assert consumed['consumed'] is True and consumed['exit_code']==0 and isinstance(consumed['session'],int)
assert r['status']=='complete70_capability_session_default_file_proof_and_product_build_passed'
assert r['source_unchanged'] and r['totals']==dict(passed=70,failed=0,ignored=0,filtered=0)
assert len(r['stages'])==2 and all(v['exit_code']==0 for v in r['stages'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==r['head']
def sha(raw):return hashlib.sha256(raw).hexdigest()
for name,digest in r['source_sha256'].items():assert sha((WORK/name).read_bytes())==digest,name
failure=WORK/'engineering/validation/data/depth75-qualified-runtime-binding-failure-v1.json'
previous=json.loads(failure.read_text(encoding='utf-8'))
assert sha((failure.parent/previous['archive']).read_bytes())==previous['sha256']
assert previous['audit']['totals']['failed']==1 and previous['audit']['full_target_coverage']
assert r['predecessor']['status'].startswith('original full command remains failed')

members={}
for name in ('controller.py','receipt.json','session-consumed.json','native.stdout.log','native.stderr.log',
             'actual-product-build.stdout.log','actual-product-build.stderr.log'):
    members['native/'+name]=(OUT/name).read_bytes()
for name in ('motion-studio.log','proof.json','child.stdout.log','child.stderr.log'):
    members['actual-default-file-proof/'+name]=(OUT/'default-file-proof'/name).read_bytes()
for name in ('crates/motion-host/tests/depth_capability.rs',
             'crates/motion-host/tests/depth_capability/bindings.rs',
             'crates/motion-host/tests/depth_capability/file_output.rs',
             'crates/motion-host/tests/depth_session/transitions/qualified.rs',
             'desktop/app/src/logging/sink.rs'):
    members['source/'+name]=(WORK/name).read_bytes()
members['archive-controller.py']=Path(__file__).read_bytes()
data=WORK/'engineering/validation/data';archive=data/'depth75-qualified-file-output-v1.zip'
manifest=data/'depth75-qualified-file-output-v1.json'
assert not archive.exists() and not manifest.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(members.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
    assert sorted(z.namelist())==sorted(members)
    for name,raw in members.items():assert z.read(name)==raw
value=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
 members=[dict(path=n,bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(members.items())],
 head=r['head'],native_status=r['status'],totals=r['totals'],predecessor=r['predecessor'],
 actual_default_file_proof=r['actual_proof'],limits=r['limits']+[
 'Predecessor full175-target command remains failed; this is two complete related targets plus product build, not a new whole-workspace pass',
 'No original assertion, product source, deadline, ignore or selection threshold changed',
 'No model weights, binaries, media, RGB/depth arrays or upstream assets redistributed; issues75/88 remain incomplete'])
manifest.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:value[k] for k in ('archive','bytes','sha256')},indent=2))
