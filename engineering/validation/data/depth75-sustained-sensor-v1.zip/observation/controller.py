"""Explicit eight-request learned workload with bounded documented GPU sensors.

All attempts/cold work retained. No device, independent quality, CPU temperature
or process-peak guarantee is inferred from sampled GPU telemetry.
"""
from pathlib import Path
from datetime import datetime,timezone
import csv,hashlib,json,os,platform,shutil,subprocess,time,traceback
ROOT=Path('E:/Dev/aem'); BASE=ROOT/'artifacts/pr-queue'
WORK=ROOT/'.worktrees/depth-wgsl-cache75'; TARGET=ROOT/'target/depth-wgsl-cache75-contract'
PREVIOUS=BASE/'depth75-measured-capability-v3'; OUT=BASE/'depth75-sustained-sensor-v1'
previous=json.loads((PREVIOUS/'receipt.json').read_text())
assert previous['status']=='corrected_authored_metadata_and_actual_video_probes_passed' and previous['source_unchanged']
assert json.loads((PREVIOUS/'session-consumed.json').read_text())==dict(session=93439,consumed=True,exit_code=0)
assert shutil.disk_usage(ROOT).free>=10<<30
assert not subprocess.check_output(['git','status','--porcelain'],cwd=WORK)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()
assert head=='d68a9d659f617e1551b02b30e5bdcfbe49e9551c'
changed=subprocess.check_output(['git','diff','--name-only',previous['head'],head],cwd=WORK,text=True).splitlines()
assert all(p.startswith('engineering/validation/') for p in changed)
OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
def sources():return {p:sha(WORK/p) for p in paths}
def now():return datetime.now(timezone.utc).isoformat()
fields=['uuid','name','driver_version','temperature.gpu','memory.used','memory.total','power.draw','power.limit','clocks.current.graphics','clocks.current.memory','utilization.gpu','clocks_event_reasons.hw_thermal_slowdown','clocks_event_reasons.sw_thermal_slowdown']
sensor=Path('C:/Windows/System32/nvidia-smi.exe')
protocol=dict(version=1,attempts=8,backend='wgsl_vulkan',input='same authored12x8 RGB independently inferred each request, learned518x518 letterbox',sensor='documented nvidia-smi GPU counters, entire physical device including unrelated activity',fields=fields,sample_interval_seconds=1,maximum_retained_readings=512,no_removed_warmup_or_cold_samples=True,maximum_original_request_wait_seconds=60,latency_request_ms=1000,limits=['Sampled whole-GPU memory is not a proven allocation peak or process attribution','Temperature sensor maximum is the sampled maximum, not a continuous sensor bound','No CPU temperature, host peak, independent domain quality or transition measurement','One finite workload duration, not long-run stability, power attribution or realtime inference'])
report=dict(status='running',head=head,source_sha256=sources(),protocol=protocol,protocol_sha256=hashlib.sha256(json.dumps(protocol,sort_keys=True,separators=(',',':')).encode()).hexdigest(),started_utc=now(),readings=[])
def save():
    p=OUT/'receipt.pending.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');os.replace(p,OUT/'receipt.json')
def reading():
    if len(report['readings'])>=512:raise ValueError('Original observation count bound exceeded; no older readings dropped')
    before=time.monotonic_ns()
    sample=subprocess.run([str(sensor),'--query-gpu='+','.join(fields),'--format=csv,noheader,nounits'],capture_output=True,text=True)
    after=time.monotonic_ns()
    assert sample.returncode==0 and not sample.stderr and len(sample.stdout)<=4096
    rows=list(csv.reader(sample.stdout.splitlines(),skipinitialspace=True))
    assert len(rows)==1 and len(rows[0])==len(fields)
    value=dict(zip(fields,[v.strip() for v in rows[0]]))
    assert value['name']=='NVIDIA GeForce RTX 4070 Laptop GPU'
    assert -273.15<=float(value['temperature.gpu'])<=200
    assert 0<=int(value['memory.used'])<=int(value['memory.total'])
    item=dict(start_monotonic_ns=before,end_monotonic_ns=after,utc=now(),values=value)
    report['readings'].append(item);save()
    return item
child=None
try:
    for path,record in previous['actual_inputs'].items():assert sha(Path(path))==record['sha256']
    initial=reading()
    environment=dict(os=platform.platform(),machine=platform.machine(),gpu={k:initial['values'][k] for k in ('uuid','name','driver_version')})
    report['environment']=environment
    report['environment_sha256']=hashlib.sha256(json.dumps(environment,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    python=ROOT/'.tools/ai-depth74/venv/Scripts/python.exe'
    model=BASE/'depth75-resolution-models-v1/518/export/depth_anything_v2_vits_518.onnx'
    program=BASE/'depth75-wgsl-cache-resources-v2/program.json'
    worker=TARGET/'debug/motion-depth-wgsl.exe'
    driver=TARGET/'debug/examples/depth_capability.exe'
    rgb=BASE/'depth75-measured-capability-v1/authored.rgb'
    report['identities']={str(p):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in (sensor,python,model,program,worker,driver,rgb)}
    env={k:v for k,v in os.environ.items() if not k.startswith('MOTION_')}
    env.update(TEMP=str(TARGET/'tmp'),TMP=str(TARGET/'tmp'),LOCALAPPDATA=str(OUT/'appdata'),RUST_BACKTRACE='full')
    command=[str(p) for p in (driver,OUT/'probe','wgsl',python,model,program,worker,rgb,'12x8','8','1000')]
    report['command']=command;save()
    with (OUT/'probe.stdout.log').open('wb') as stdout,(OUT/'probe.stderr.log').open('wb') as stderr:
        start=time.monotonic_ns();child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
        report.update(pid=child.pid,workload_started_monotonic_ns=start);save()
        while child.poll() is None:
            reading();time.sleep(1)
        report.update(exit_code=child.wait(),workload_duration_ns=time.monotonic_ns()-start);save()
    reading()
    assert report['exit_code']==0,'Original failed workload retained, no retry'
    value=json.loads((OUT/'probe.stdout.log').read_text())
    assert value==json.loads((OUT/'probe/measurements.json').read_text())
    assert len(value['samples'])==8 and value['cache_hits']==value['restored']==0
    assert value['profile']['samples']==8
    rows=value['samples']
    assert all(r['worker_total_ns']>=r['resolve_ns']>0 and r['inference_ns']>0 and r['retained_gpu_buffer_capacity_bytes']==227968156 for r in rows)
    assert len({json.dumps(r['execution'],sort_keys=True) for r in rows})==1
    logs=(OUT/'probe/logs/motion-studio.log').read_text()
    for request in range(1,9):
        for phase in ('capability_resolve','backend'):
            assert f'start #{request} depth_capability asset=75 phase={phase}' in logs
    assert all(r['values']['uuid']==initial['values']['uuid'] and r['values']['driver_version']==initial['values']['driver_version'] for r in report['readings'])
    readings=report['readings'];temps=[float(r['values']['temperature.gpu']) for r in readings]
    gaps=[(b['start_monotonic_ns']-a['end_monotonic_ns'])/1e9 for a,b in zip(readings,readings[1:])]
    report.update(status='complete_finite_eight_request_gpu_sensor_observation',measurements=value,attempts=8,completed=8,failed=0,canceled=0,
        sampled_summary=dict(readings=len(readings),minimum_temperature_celsius=min(temps),maximum_temperature_celsius=max(temps),first_temperature_celsius=temps[0],last_temperature_celsius=temps[-1],whole_device_memory_maximum_observed_mib=max(int(r['values']['memory.used']) for r in readings),maximum_observation_gap_seconds=max(gaps),thermal_slowdown_observed=any(r['values'][k]=='Active' for r in readings for k in ('clocks_event_reasons.hw_thermal_slowdown','clocks_event_reasons.sw_thermal_slowdown'))))
except BaseException as cause:
    report.update(status='failed_original_outputs_retained',cause=repr(cause),traceback=traceback.format_exc())
finally:
    # Never leave an original child running and launch another workload.
    if child is not None and child.poll() is None:
        report['exit_code']=child.wait()
    report.update(source_unchanged=sources()==report['source_sha256'],completed_utc=now())
    report['logs']={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in OUT.glob('*.log')};save()
print(json.dumps({k:report.get(k) for k in ('status','cause','source_unchanged','workload_duration_ns','sampled_summary')}))
raise SystemExit(0 if report['status']=='complete_finite_eight_request_gpu_sensor_observation' and report['source_unchanged'] else 1)
