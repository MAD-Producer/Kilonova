"""Independently reduce and archive a finite documented GPU sensor observation."""
from pathlib import Path
import hashlib,json,zipfile
BASE=Path('E:/Dev/aem/artifacts/pr-queue');SOURCE=BASE/'depth75-sustained-sensor-v1';OUT=BASE/'depth75-sustained-sensor-public-v1'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
r=load(SOURCE/'receipt.json')
assert r['status']=='complete_finite_eight_request_gpu_sensor_observation' and r['source_unchanged']
assert load(SOURCE/'session-consumed.json')==dict(session=71826,consumed=True,exit_code=0)
assert r['head']=='d68a9d659f617e1551b02b30e5bdcfbe49e9551c'
assert r['attempts']==r['completed']==8 and r['failed']==r['canceled']==0
assert r['protocol']['attempts']==8 and r['protocol']['sample_interval_seconds']==1
assert sha(json.dumps(r['protocol'],sort_keys=True,separators=(',',':')).encode())==r['protocol_sha256']
assert sha(json.dumps(r['environment'],sort_keys=True,separators=(',',':')).encode())==r['environment_sha256']
value=load(SOURCE/'probe/measurements.json')
assert value==json.loads((SOURCE/'probe.stdout.log').read_text())==r['measurements']
assert value['cache_hits']==value['restored']==0 and len(value['samples'])==8
samples=value['samples'];totals=sorted(s['worker_total_ns'] for s in samples)
assert value['profile']['fastest_ns']==totals[0] and value['profile']['median_ns']==totals[4] and value['profile']['slowest_ns']==totals[-1]
assert all(s['worker_total_ns']>=s['resolve_ns']>0 and s['retained_gpu_buffer_capacity_bytes']==227968156 for s in samples)
log=(SOURCE/'probe/logs/motion-studio.log').read_text()
for request in range(1,9):
 for phase in ('capability_resolve','backend'):
  assert f'start #{request} depth_capability asset=75 phase={phase}' in log
readings=r['readings'];assert 2<=len(readings)<=512
assert readings[0]['start_monotonic_ns']<=r['workload_started_monotonic_ns']
assert readings[-1]['end_monotonic_ns']>=r['workload_started_monotonic_ns']+r['workload_duration_ns']
assert all(item['start_monotonic_ns']<=item['end_monotonic_ns'] for item in readings)
assert all(item['values']['uuid']==r['environment']['gpu']['uuid'] and item['values']['driver_version']==r['environment']['gpu']['driver_version'] for item in readings)
temps=[float(item['values']['temperature.gpu']) for item in readings]
gaps=[(b['start_monotonic_ns']-a['end_monotonic_ns'])/1e9 for a,b in zip(readings,readings[1:])]
summary=dict(readings=len(readings),minimum_temperature_celsius=min(temps),maximum_temperature_celsius=max(temps),first_temperature_celsius=temps[0],last_temperature_celsius=temps[-1],whole_device_memory_maximum_observed_mib=max(int(item['values']['memory.used']) for item in readings),maximum_observation_gap_seconds=max(gaps),thermal_slowdown_observed=any(item['values'][k]=='Active' for item in readings for k in ('clocks_event_reasons.hw_thermal_slowdown','clocks_event_reasons.sw_thermal_slowdown')))
assert summary==r['sampled_summary']
files={}
def put(path,name):
 raw=path.read_bytes();assert path.suffix in ('.json','.py','.log') and len(raw)<=4<<20
 assert name not in files;files[name]=raw
for name in ('receipt.json','session-consumed.json','controller.py','probe.stdout.log','probe.stderr.log','probe/measurements.json','probe/logs/motion-studio.log'):
 put(SOURCE/name,'observation/'+name)
put(Path(__file__),'archive.py')
for name,record in r['logs'].items():
 raw=(SOURCE/name).read_bytes();assert len(raw)==record['bytes'] and sha(raw)==record['sha256']
limits=r['protocol']['limits']+['Actual finite eight-request workload, no dropped cold/warm/slow attempts; not long-run stability or a product qualification','GPU memory includes unrelated activity and is sampled; host/weight/activation peaks remain unmeasured','Physical-device sensor values do not attribute heat, power or memory to this process','No independent quality or continuous transition acceptance and no automatic tier enabled','No media, tensors, weights, executable binaries or model plans redistributed']
manifest=dict(version=1,status=r['status'],head=r['head'],attempts=8,completed=8,failed=0,canceled=0,workload_duration_ns=r['workload_duration_ns'],worker_totals_ns=[s['worker_total_ns'] for s in samples],sampled_summary=summary,protocol_sha256=r['protocol_sha256'],environment_sha256=r['environment_sha256'],limits=limits,members={name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in files.items()})
OUT.mkdir(exist_ok=False);archive=OUT/'depth75-sustained-sensor-v1.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in files.items():z.writestr(name,raw)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)|{'manifest.json'}
 for name,raw in files.items():assert z.read(name)==raw
 assert json.loads(z.read('manifest.json'))==manifest
result={k:v for k,v in manifest.items() if k!='members'}
result.update(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),members_readback_verified=len(files)+1)
(OUT/'receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
