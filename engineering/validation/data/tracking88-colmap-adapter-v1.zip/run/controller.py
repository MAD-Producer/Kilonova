from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, subprocess, time

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-colmap88'
out = root / 'artifacts/pr-queue/tracking88-colmap-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
git = lambda *a: subprocess.check_output(['git', *a], cwd=work).decode().strip()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
paths = [n for n in git('ls-files', '--cached', '--others', '--exclude-standard', 'crates', 'Cargo.toml', 'Cargo.lock').splitlines() if n.endswith(('.rs', '.wgsl', 'Cargo.toml', 'Cargo.lock')) and (work / n).is_file()]
record = dict(status='queued_for_existing_cargo_lock', head=git('rev-parse', 'HEAD'), source={n: sha(work / n) for n in paths}, steps=[], startedUtc=datetime.now(timezone.utc).isoformat(), limits=['CPU-only model test target and host check; no renderer or UI acceptance', 'Same E-drive target waits for existing desktop/UI gate before compiling', 'No assertion, deadline, ignore or production-profile changes'])
env = os.environ.copy()
env.pop('MOTION_LOG', None)
commands = [
    ('conversion', ['cargo', 'test', '-p', 'motion-model', '--test', 'tracking_colmap', '--locked', '--offline', '--', '--test-threads=1']),
    ('host-check', ['cargo', 'check', '-p', 'motion-host', '--locked', '--offline'])
]
def save():
    (out / 'exit.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
save()
began = time.monotonic()
try:
    for name, command in commands:
        step = dict(name=name, command=command)
        record['steps'].append(step)
        save()
        with (out / f'{name}.stdout.log').open('wb') as stdout, (out / f'{name}.stderr.log').open('wb') as stderr:
            process = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
            step['pid'] = process.pid
            save()
            step['exitCode'] = process.wait()
        step['summaries'] = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', (out / f'{name}.stdout.log').read_text(encoding='utf-8', errors='replace'), re.M)
        record['sourceUnchanged'] = all(sha(work / n) == h for n, h in record['source'].items())
        save()
        assert step['exitCode'] == 0 and record['sourceUnchanged'], name
        if name == 'conversion':
            assert len(step['summaries']) == 1 and step['summaries'][0][0] == 'ok'
            assert all(step['summaries'][0][i] == '0' for i in (2, 3, 5))
    record['status'] = 'passed'
except BaseException as cause:
    record.update(status='failed_original_outputs_retained', failure=repr(cause))
    raise
finally:
    record.update(elapsedSeconds=round(time.monotonic() - began, 3), completedUtc=datetime.now(timezone.utc).isoformat())
    save()
print(json.dumps({k:v for k,v in record.items() if k not in ['source', 'steps']}, indent=2), flush=True)
