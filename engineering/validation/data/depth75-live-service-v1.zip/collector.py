"""Publish authored source/receipts/logs, excluding all model and image bytes."""
from pathlib import Path
import hashlib, json, re, shutil, zipfile
ART=Path('E:/Dev/aem/artifacts/pr-queue')
WORK=Path('E:/Dev/aem/.worktrees/depth-retained-context75')
OUT=ART/'depth75-live-service-public-v1'
runs=['depth75-live-service-v1','depth75-live-service-v2','depth75-live-service-v3',
      'depth75-live-mailbox-controls-v1','depth75-live-mailbox-controls-v2']
sessions=[29112,88534,87782,14447,12787]
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
receipts={}
for name,session,exit_code in zip(runs,sessions,[1,0,0,0,0]):
    receipt=read(ART/name/'receipt.json')
    consumed=read(ART/name/'session-consumed.json')
    assert consumed['session']==session and consumed['consumed'] and consumed['exit_code']==exit_code
    assert receipt['source_unchanged']
    receipts[name]=receipt
current=receipts['depth75-live-service-v3']
controls=receipts['depth75-live-mailbox-controls-v2']
assert controls['binary_unchanged'] and len(controls['controls'])==9
assert all(r['exit_code']==1 and r['stdout_empty'] and r['default_file_error_and_stderr_verified'] for r in controls['controls'])
assert current['changed_source_sha256']==controls['changed_source_sha256']
assert current['worker_sha256']==controls['worker_sha256']
for name,digest in current['changed_source_sha256'].items():
    assert sha((WORK/name).read_bytes())==digest
tests=[]
for command in current['commands']:
    assert command['exit_code']==0
    stdout=(ART/'depth75-live-service-v3'/(command['label']+'.stdout.log')).read_text(encoding='utf-8')
    for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out',stdout):
        tests.append(dict(command=command['label'],passed=int(row[0]),failed=int(row[1]),ignored=int(row[2]),filtered=int(row[3])))
assert sum(row['passed'] for row in tests)==68
assert all(row['failed']==0 and row['ignored']==0 for row in tests)
evidence=read(ART/'depth75-live-service-v3/jobs-evidence.json')
assert len(evidence['outputs'])==3 and evidence['completed']==3 and evidence['canceled']==1 and evidence['failed']==1
assert evidence['service_directory_removed']
OUT.mkdir(exist_ok=False)
members={}
for run in runs:
    for path in (ART/run).rglob('*'):
        if not path.is_file(): continue
        relative=path.relative_to(ART/run)
        # Small owned receipts, control commands, Rust/Python source and logs;
        # explicitly exclude RGB, tensors, depth, executables and runtimes.
        if path.suffix not in {'.json','.log','.rs','.py','.toml'}: continue
        assert path.stat().st_size<32<<20
        members[f'{run}/{relative.as_posix()}']=path.read_bytes()
members['collector.py']=Path(__file__).read_bytes()
members['failed-source-reconstruction.py']=(ART/'depth75-live-service-v1-source-reconstruction.py').read_bytes()
summary=dict(status='actual_jobs_reuse_cancel_and_nine_native_refusals_verified',
    source_base=current['source_head'],changed_source_sha256=current['changed_source_sha256'],
    worker_sha256=current['worker_sha256'],tests=tests,passed=68,
    original_failed_session=29112,corrected_jobs_session=87782,current_refusals_session=12787,
    actual_jobs=evidence,native_refusals=controls['controls'],
    limits=['Explicit experimental retained backend, not automatic qualified selection or Session/export acceptance',
        'Current source not yet run through full maintained-workspace regression or remote CI',
        'Old broad regression failures, cross-resolution refusals and thermal outcomes retained',
        'No Android, panels, asset/model/runtime acquisition or existing assertion changes'])
members['summary.json']=(json.dumps(summary,indent=2)+'\n').encode()
archive=OUT/'depth75-live-service-v1.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()): z.writestr(name,data)
manifest=dict(schema=1,archive=archive.name,bytes=archive.stat().st_size,
    sha256=sha(archive.read_bytes()),members={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())})
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for name,data in members.items():
        actual=z.read(name)
        assert actual==data and sha(actual)==manifest['members'][name]['sha256']
(OUT/'depth75-live-service-v1.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(bytes=manifest['bytes'],sha256=manifest['sha256'],members=len(members),passed=68)))
