"""One owned native build and real Jobs control; retain every original outcome."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, time, traceback
from datetime import datetime, timezone

ROOT = Path('E:/Dev/aem')
ART = ROOT / 'artifacts/pr-queue'
WORK = ROOT / '.worktrees/depth-retained-context75'
OUT = ART / 'depth75-live-service-v1'
TARGET = ROOT / 'target/depth-wgsl-cache75-contract'
FFMPEG = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
CHECKPOINT = ART / 'depth75-resume-current.json'

def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=WORK, text=True).strip()
def bindings():
    files = set(git('diff', '--name-only').splitlines())
    files.update(git('ls-files', '--others', '--exclude-standard').splitlines())
    assert not any('/panels/' in name for name in files)
    return {name: sha(WORK/name) for name in sorted(files)}

state = json.loads(CHECKPOINT.read_text(encoding='utf-8-sig'))
assert state['versionedCache75']['activeController'] is None
assert not state['versionedCache75']['ownHeavyWorkloads']
assert shutil.disk_usage(ROOT).free >= 10 << 30
head, source = git('rev-parse', 'HEAD'), bindings()
assert head == 'a459112a1871e81d027ec86037a0c1e7e2832e83'
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT/'controller.py')
env = os.environ.copy()
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(TARGET),
    CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0',
    CARGO_PROFILE_TEST_DEBUG='0', TEMP=str(TARGET/'tmp'), TMP=str(TARGET/'tmp'),
    LOCALAPPDATA=str(OUT/'appdata'), PYTHONDONTWRITEBYTECODE='1', RUST_BACKTRACE='full',
    LIBCLANG_PATH=str(ROOT/'.tools/python-libclang/clang/native'), FFMPEG_DIR=str(FFMPEG),
    FFMPEG_INCLUDE_DIR=str(FFMPEG/'include'), FFMPEG_LIB_DIR=str(FFMPEG/'lib'))
env['PATH'] = str(FFMPEG/'bin') + os.pathsep + env['PATH']
env.pop('MOTION_LOG', None)
Path(env['LOCALAPPDATA']).mkdir()
prior = json.loads((ART/'depth75-retained-context-v1/receipt.json').read_text(encoding='utf-8'))
reference = json.loads((ART/'depth75-reference-inputs-v1/inputs.json').read_text(encoding='utf-8'))
fixture = dict(python=str(ROOT/'.tools/ai-depth74/venv/Scripts/python.exe'),
    worker=str(TARGET/'debug/motion-depth-wgsl.exe'),
    program=str(ART/'depth75-wgsl-cache-resources-v2/program.json'), scratch=str(OUT/'scratch'),
    rgb=[str(ART/'depth75-reference-inputs-v1'/f'{n:02}.rgb') for n in range(2)],
    rgb_sha256=[reference[n]['rgb_input']['sha256'] for n in range(2)],
    expected_output_sha256=[prior['cold'][n]['remapped_output_sha256'] for n in range(2)],
    evidence=str(OUT/'jobs-evidence.json'))
write(OUT/'fixture.json', fixture)
env['MOTION_DEPTH_RETAINED_TEST_FIXTURE'] = str(OUT/'fixture.json')
report = dict(status='running', source_head=head, changed_source_sha256=source,
    controller_sha256=sha(OUT/'controller.py'), commands=[],
    started_utc=datetime.now(timezone.utc).isoformat(),
    limits=['One owned native controller; no Android, panels, downloads, retries or foreign process changes',
        'Existing full-workspace failure remains failed; these controls do not replace it',
        'Real retained Jobs reuse/cancellation, not full Session/export/thermal qualification'])
state['versionedCache75'].update(activeController=str(Path(__file__)), ownHeavyWorkloads=[dict(
    kind='retained service build and real Jobs GPU control', output=str(OUT), sourceFrozen=True)])
write(CHECKPOINT, state)
start = time.monotonic()

def command(label, args, timeout=None):
    item = dict(label=label, args=args, timeout_seconds=timeout,
        started_utc=datetime.now(timezone.utc).isoformat())
    report['commands'].append(item)
    write(OUT/'receipt.json', report)
    began = time.monotonic()
    with (OUT/(label+'.stdout.log')).open('wb') as stdout, (OUT/(label+'.stderr.log')).open('wb') as stderr:
        result = subprocess.run(args, cwd=WORK, env=env, stdout=stdout, stderr=stderr, timeout=timeout)
    item.update(exit_code=result.returncode, elapsed_seconds=time.monotonic()-began)
    write(OUT/'receipt.json', report)
    assert result.returncode == 0, item
    assert bindings() == source and git('rev-parse','HEAD') == head

try:
    common = ['--locked','--offline','--','--test-threads=1']
    command('host-wgsl-unit', ['cargo','test','-p','motion-host','--features','ai-depth',
        '--lib','depth::wgsl::',*common])
    command('host-memory-unit', ['cargo','test','-p','motion-host','--features','ai-depth',
        '--lib','process_memory::tests::',*common])
    features = 'motion-desktop/ffmpeg,motion-host/ai-depth,motion-desktop-media/ai-depth'
    targets = ['depth-worker-admission','depth-worker-convolution-admission','depth-worker-index-admission',
        'depth-worker-graph-admission','depth-worker-batch-admission','depth-worker-service-admission','depth-worker-panic']
    command('worker-admission', ['cargo','test','-p','motion-desktop','--features',features,
        *[arg for name in targets for arg in ('--test',name)],*common])
    command('worker-build', ['cargo','build','-p','motion-desktop','--features',features,
        '--bin','motion-depth-wgsl','--locked','--offline'])
    report['worker_sha256'] = sha(Path(fixture['worker']))
    command('actual-jobs', ['cargo','test','-p','motion-host','--features','ai-depth',
        '--test','depth_wgsl_retained','actual_jobs_reuse_one_gpu_context_and_reap_it_on_cancel_without_restart',
        '--locked','--offline','--','--ignored','--exact','--test-threads=1'], timeout=300)
    evidence = json.loads((OUT/'jobs-evidence.json').read_text(encoding='utf-8'))
    assert len(evidence['outputs']) == 3 and evidence['canceled'] >= 1
    assert evidence['failed'] == 1 and evidence['completed'] == 3
    assert evidence['service_directory_removed'] is True
    log = (OUT/'logs/motion-studio.log').read_text(encoding='utf-8')
    assert 'start #1 depth_infer' in log and 'no implicit restart' in log
    assert 'no implicit restart' in (OUT/'actual-jobs.stderr.log').read_text(encoding='utf-8')
    report['status'] = 'actual_retained_jobs_reuse_and_cancellation_controls_passed'
except BaseException:
    report['status'] = 'failed_original_outcome_retained'
    report['failure'] = traceback.format_exc()
finally:
    report.update(source_unchanged=bindings()==source and git('rev-parse','HEAD')==head,
        elapsed_seconds=time.monotonic()-start, completed_utc=datetime.now(timezone.utc).isoformat())
    write(OUT/'receipt.json', report)
    print(json.dumps(report, ensure_ascii=True))
raise SystemExit(0 if report['status']=='actual_retained_jobs_reuse_and_cancellation_controls_passed' else 1)
