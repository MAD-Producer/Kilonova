"""Declared actual native protocol refusals after the Jobs controller is consumed."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, time, traceback
from datetime import datetime, timezone

ROOT = Path('E:/Dev/aem')
ART = ROOT/'artifacts/pr-queue'
WORK = ROOT/'.worktrees/depth-retained-context75'
OUT = ART/'depth75-live-mailbox-controls-v1'
PRIOR = ART/'depth75-live-service-v2'
OLD = ART/'depth75-retained-context-v1'
EXE = ROOT/'target/depth-wgsl-cache75-contract/debug/motion-depth-wgsl.exe'
CP = ART/'depth75-resume-current.json'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value): path.write_text(json.dumps(value, indent=2)+'\n',encoding='utf-8')
def git(*args): return subprocess.check_output(['git',*args],cwd=WORK,text=True).strip()
def sources():
    names=set(git('diff','--name-only').splitlines())
    names.update(git('ls-files','--others','--exclude-standard').splitlines())
    return {n:sha(WORK/n) for n in sorted(names)}
consumed=json.loads((PRIOR/'session-consumed.json').read_text(encoding='utf-8-sig'))
assert consumed['consumed'] and consumed['exit_code']==0
prior=json.loads((PRIOR/'receipt.json').read_text(encoding='utf-8'))
assert prior['status']=='actual_retained_jobs_reuse_and_cancellation_controls_passed'
assert sha(EXE)==prior['worker_sha256'] and sources()==prior['changed_source_sha256']
state=json.loads(CP.read_text(encoding='utf-8-sig'))
assert state['versionedCache75']['activeController'] is None
assert not state['versionedCache75']['ownHeavyWorkloads']
assert shutil.disk_usage(ROOT).free>=10<<30
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__,OUT/'controller.py')
source=sources()
env=os.environ.copy()
env.pop('MOTION_LOG',None)
env.update(TMP=str(OUT),TEMP=str(OUT),LOCALAPPDATA=str(OUT/'appdata'),RUST_BACKTRACE='full')
Path(env['LOCALAPPDATA']).mkdir()
report=dict(status='running',source_head=git('rev-parse','HEAD'),changed_source_sha256=source,
    worker_sha256=sha(EXE),controls=[],started_utc=datetime.now(timezone.utc).isoformat(),
    limits=['Real native mailbox controls only; not qualified Session/cache/export or broad regression',
        'No Android, panel, model, thresholds or original failures changed; no retries'])
state['versionedCache75'].update(activeController=str(Path(__file__)),ownHeavyWorkloads=[dict(
    kind='actual native mailbox declared refusals',output=str(OUT),sourceFrozen=True)])
write(CP,state)
def save(): write(OUT/'receipt.json',report)
def read(path): return json.loads(path.read_text(encoding='utf-8'))
def native_path(path):
    value=str(path.resolve())
    return '\\\\?\\'+value if os.name=='nt' and not value.startswith('\\\\?\\') else value
def until(predicate,child,seconds=60):
    began=time.monotonic()
    while time.monotonic()-began<seconds:
        value=predicate()
        if value: return value
        assert child.poll() is None, f'child exited before observation: {child.returncode}'
        time.sleep(.002)
    raise AssertionError('native observation deadline exceeded')
def command_bytes(root, value):
    path=root/'service/command.tmp'
    path.write_bytes(value if isinstance(value,bytes) else json.dumps(value).encode())
    path.rename(root/'service/command.json')
def graph_job(root):
    job=root/'job'
    job.mkdir()
    cold=read(OLD/'cold-0.json')
    shutil.copyfile(OLD/cold['input']['file'],job/'tensor.f32')
    cold['input']['file']='tensor.f32'
    request=job/'native-request.json'
    write(request,cold)
    return request,job/'native'

try:
    resolve=read(OLD/'cold-0.json')
    del resolve['input']
    request=OUT/'resolve.json'
    write(request,resolve)
    with (OUT/'resolve.stdout.log').open('wb') as stdout,(OUT/'resolve.stderr.log').open('wb') as stderr:
        result=subprocess.run([str(EXE),'--resolve',str(request),str(OUT/'resolved')],env=env,cwd=WORK,
            stdout=stdout,stderr=stderr,timeout=60)
    assert result.returncode==0 and (OUT/'resolve.stdout.log').stat().st_size==0
    execution=read(OUT/'resolved/receipt.json')['execution']
    for name in ['changed_execution','malformed','oversized','unknown_field','wrong_sequence',
                 'escaped_path','changed_program','wrong_digest','replay_after_completed_input']:
        root=OUT/name
        root.mkdir()
        write(root/'resolve.json',resolve)
        expected=json.loads(json.dumps(execution))
        if name=='changed_execution': expected['runtime_sha256'][0]^=1
        write(root/'execution.json',expected)
        stdout=(root/'stdout.log').open('wb')
        stderr=(root/'stderr.log').open('wb')
        child=None
        record=dict(name=name,expected_exit=1,started_utc=datetime.now(timezone.utc).isoformat())
        report['controls'].append(record)
        save()
        try:
            child=subprocess.Popen([str(EXE),'--serve',str(root/'execution.json'),str(root/'resolve.json'),
                str(root/'service')],env=env,cwd=WORK,stdout=stdout,stderr=stderr,
                creationflags=0x08000000 if os.name=='nt' else 0)
            if name!='changed_execution':
                ack=root/'service/ack.json'
                until(lambda: ack.is_file(),child)
                ready=read(ack)
                assert ready['sequence']==0 and ready['pid']==child.pid and ready['execution']==execution
                ack.unlink()
                request,output=graph_job(root)
                command=dict(schema=1,sequence=1,request=native_path(request),output=native_path(output))
                if name=='malformed': command=b'{}'
                elif name=='oversized': command=b' '*(16384+1)
                elif name=='unknown_field': command['extra']=True
                elif name=='wrong_sequence': command['sequence']=2
                elif name=='escaped_path': command['request']=str(OUT/'resolve.json')
                elif name=='changed_program':
                    value=read(request);value['program_sha256']='0'*64;write(request,value)
                elif name=='wrong_digest':
                    value=read(request);value['input']['sha256']='0'*64;write(request,value)
                command_bytes(root,command)
                if name=='replay_after_completed_input':
                    until(lambda:ack.is_file(),child)
                    completed=read(ack)
                    assert completed['sequence']==1 and completed['execution']==execution
                    ack.unlink()
                    native=read(output/'receipt.json')
                    assert native['encoded_operations']==429 and native['final_readbacks']==1
                    assert native['context_preparations']==1
                    expected_sha=read(OLD/'receipt.json')['cold'][0]['digest']
                    assert sha(output/'relative_inverse_depth.f32')==expected_sha==native['output_sha256']
                    record['original_completed_output_sha256']=expected_sha
                    command_bytes(root,command)
            record['exit_code']=child.wait(timeout=60)
            assert record['exit_code']==1
        finally:
            if child is not None and child.poll() is None:
                child.kill(); child.wait()
            stdout.close();stderr.close()
        native=read(root/'service/receipt.json')
        assert native['status']=='failed_original_cause_retained'
        log=(root/'service/logs/motion-studio.log').read_text(encoding='utf-8')
        error=(root/'stderr.log').read_text(encoding='utf-8')
        assert native['failure'] in log and native['failure'] in error
        assert ' ERROR ' in log and 'start #0 retained_depth_service' in log
        assert (root/'stdout.log').stat().st_size==0
        if name=='changed_execution':
            assert 'native execution changed since cache resolution' in native['failure']
            assert 'prepare_context_seconds' not in native and 'allocate_fixed_pool' not in log
        elif name=='replay_after_completed_input':
            assert native['completed_inputs']==1
            assert sha(root/'job/native/relative_inverse_depth.f32')==record['original_completed_output_sha256']
        else:
            assert native['completed_inputs']==0
            assert not (root/'job/native/relative_inverse_depth.f32').exists()
        record.update(original_cause=native['failure'],stdout_empty=True,
            default_file_error_and_stderr_verified=True,receipt_sha256=sha(root/'service/receipt.json'))
        save()
    report['status']='nine_declared_native_retained_refusals_passed'
except BaseException:
    report.update(status='failed_original_outcome_retained',failure=traceback.format_exc())
finally:
    report.update(source_unchanged=sources()==source,binary_unchanged=sha(EXE)==prior['worker_sha256'],
        completed_utc=datetime.now(timezone.utc).isoformat())
    save()
    print(json.dumps(dict(status=report['status'],controls=len(report['controls']),source_unchanged=report['source_unchanged'])))
raise SystemExit(0 if report['status']=='nine_declared_native_retained_refusals_passed' else 1)
