"""Recover only exact hash-matching pre-correction source for failed evidence.

This runs no test/model and edits no worktree. Reconstructed bytes are accepted
only if they match the hashes captured by the original failed controller.
"""
from pathlib import Path
import hashlib, json
ART=Path('E:/Dev/aem/artifacts/pr-queue')
OLD=ART/'depth75-live-service-v1'
NEW=ART/'depth75-live-service-v2/frozen-source'
expected=json.loads((OLD/'receipt.json').read_text(encoding='utf-8'))['changed_source_sha256']
verified={}
for name,digest in expected.items():
    data=(NEW/name).read_bytes()
    if hashlib.sha256(data).hexdigest()!=digest:
        text=data.decode('utf-8')
        if name.endswith('/wgsl.rs'):
            start=text.index('        // Stop/reap the worker first,')
            end=text.index('        let result = match (result, directory.close()) {',start)
            text=text[:start]+'''        let result = if self.retained {
            result.map_err(|error| self.close_failed_service(error))
        } else {
            result
        };
        match (result, directory.close()) {'''+text[end+len('        let result = match (result, directory.close()) {'):]
            text=text.replace('''        };
        drop(failed_service);
        result
    }
}
enum TransformInvocation''','''        }
    }
}
enum TransformInvocation''')
        elif name.endswith('/service.rs'):
            writes='''        fs::write(out.join("command.tmp"), bytes)?;
        fs::rename(out.join("command.tmp"), out.join("command.json"))?;
'''
            text=text.replace(writes,'')
            text=text.replace('''        let out = self.output();
        log::info!(''','''        let out = self.output();
'''+writes+'''        log::info!(''')
            text=text.replace('''                if self.stdout_written.load(Ordering::Acquire) {
                    log::error!(
                        "operation=depth_wgsl phase=retained_service_closed cause=worker_wrote_stdout diagnostic={diagnostic}"
                    );
                } else if !diagnostic.is_empty() {''','''                if !diagnostic.is_empty() {''')
        elif name.endswith('/depth_wgsl_retained.rs'):
            start=text.index('''        fs::write(
            &fixture.evidence,''')
            end=text.index('''    }
    assert_eq!(jobs.counts().unwrap().completed, 3);''',start)
            text=text[:start]+text[end:]
        else:
            raise AssertionError('Unexpected changed source '+name)
        data=text.encode('utf-8')
    assert hashlib.sha256(data).hexdigest()==digest,name
    destination=OLD/'reconstructed-frozen-source'/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    if destination.exists():
        assert destination.read_bytes()==data
    else:
        destination.write_bytes(data)
    verified[name]=digest
(OLD/'source-reconstruction.json').write_text(json.dumps(dict(
    status='all_original_frozen_hashes_recovered_exactly',
    provenance='Reverse the explicitly recorded correction from v2 frozen copies; accept only original v1 SHA-256',
    worktree_modified=False,tests_rerun=False,files=verified),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='original_failed_source_exactly_recovered',files=len(verified))))
