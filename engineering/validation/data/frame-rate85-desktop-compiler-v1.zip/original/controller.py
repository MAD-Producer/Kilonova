from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,sys,time
root=Path('E:/Dev/aem');work=root/'.worktrees/rational-frame-rates85'
out=root/'artifacts/pr-queue/frame-rate85-complete-desktop-v1';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=work).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip()
assert head=='a45bbe94e418be68c2ed996bbf2f0eb17db5d7bc'
subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],cwd=work,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','-z','crates','desktop','tools','.github','Cargo.toml','Cargo.lock'],cwd=work).decode().split('\0')
sources={n:sha(work/n) for n in names if n and (work/n).is_file()}
os.environ.pop('MOTION_LOG',None);os.environ['LOCALAPPDATA']=str(out/'appdata');os.environ['RUST_BACKTRACE']='full'
metadata=json.loads(subprocess.check_output(['cargo','metadata','--no-deps','--format-version','1','--locked','--offline'],cwd=work))
targets={p['name']:[t for t in p['targets'] if t['test'] or 'lib' in t['kind']] for p in metadata['packages'] if p['name'] in ['motion-desktop','motion-ui']}
(out/'expected-targets.json').write_text(json.dumps(dict(head=head,packages=targets),indent=2)+'\n',encoding='utf-8')
report=dict(status='running',head=head,main=subprocess.check_output(['git','rev-parse','origin/main'],cwd=work).decode().strip(),sources=sources,results=[],startedUtc=datetime.now(timezone.utc).isoformat(),
            environment=dict(RUST_BACKTRACE=os.environ.get('RUST_BACKTRACE'),RUST_MIN_STACK=os.environ.get('RUST_MIN_STACK'),CARGO_PROFILE_TEST_DEBUG=os.environ.get('CARGO_PROFILE_TEST_DEBUG')),
            limits=['Complete desktop and UI targets cover the authorized overflow fixture, integrated ten panel clocks, cold expression preparation, native clock readouts and current-main UI changes',
                    'Default real GPU sequential commands; no retries, test filtering, changed assertions, budgets, original ignores or stack size changes',
                    'Earlier stack overflow and heap corruption remain unresolved unless actual fault evidence establishes a fix; no Android acceptance'])
commands=[('check',['cargo','check','-p','motion-desktop','-p','motion-ui','--all-targets','--locked','--offline']),
          ('desktop-ui',['cargo','test','-p','motion-desktop','-p','motion-ui','--no-fail-fast','--locked','--offline','--','--test-threads=1']),
          ('helper-check',[sys.executable,'tools/build_desktop.py','--task','check','--debug','--target-dir',os.environ['CARGO_TARGET_DIR'],'--','--offline'])]
save=lambda:(out/'exit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
save();start=time.monotonic()
try:
    for name,command in commands:
        row=dict(name=name,command=command,status='running');report['results'].append(row);began=time.monotonic();save()
        with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
            process=subprocess.Popen(command,cwd=work,stdout=stdout,stderr=stderr,env=os.environ.copy());row['pid']=process.pid;save();row['exitCode']=process.wait()
        row.update(status='passed' if row['exitCode']==0 else 'failed',elapsedSeconds=round(time.monotonic()-began,3),summaries=re.findall(r'^test result: .+$',(out/f'{name}.stdout.log').read_text(encoding='utf-8',errors='replace'),re.M));save();print(json.dumps(row),flush=True)
        if row['exitCode']:
            if name=='desktop-ui':
                log=(out/f'{name}.stderr.log').read_text(encoding='utf-8',errors='replace')
                preserved=[]
                for text in re.findall(r'\((E:[^\r\n]+?\.exe)\)',log):
                    binary=Path(text)
                    if binary.is_file() and binary.resolve().is_relative_to((root/'target/rational-rate85-contract').resolve()):
                        dest=out/'original-failed-programs'/binary.name;dest.parent.mkdir(exist_ok=True);shutil.copyfile(binary,dest)
                        preserved.append(dict(path=dest.name,sha256=sha(dest),bytes=dest.stat().st_size))
                report['preservedPrograms']=preserved;save()
            break
    report['sourceUnchanged']=all(sha(work/n)==digest for n,digest in sources.items());assert report['sourceUnchanged']
    report['status']='passed_complete_targets_final_ci_and_professional_samples_pending' if len(report['results'])==len(commands) and all(r['exitCode']==0 for r in report['results']) else 'failed_original_outputs_and_programs_retained'
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(),elapsedSeconds=round(time.monotonic()-start,3));save()
raise SystemExit(0 if report['status']=='passed_complete_targets_final_ci_and_professional_samples_pending' else 1)
