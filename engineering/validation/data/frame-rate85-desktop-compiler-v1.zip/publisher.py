from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/rational-frame-rates85'
raw = root / 'artifacts/pr-queue/frame-rate85-complete-desktop-v1'
out = root / 'artifacts/pr-queue/frame-rate85-desktop-compiler-review-v1'
out.mkdir(exist_ok=False)
report = json.loads((raw / 'exit.json').read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work).decode().strip() == report['head']
assert all(sha((work / name).read_bytes()) == digest for name, digest in report['sources'].items())
err = (raw / 'desktop-ui.stderr.log').read_text(encoding='utf-8')
assert 'memory allocation of 34603024 bytes failed' in err
assert '0xc0000409, STATUS_STACK_BUFFER_OVERRUN' in err
assert (raw / 'desktop-ui.stdout.log').stat().st_size == 0
review = dict(status='compiler_allocation_failed_before_tests_controller_terminal_unavailable',
    head=report['head'], main=report['main'], reviewedUtc=datetime.now(timezone.utc).isoformat(),
    sourceUnchanged=True, allTargetCheck=report['results'][0], executedTests=0,
    compilerDiagnostic='memory allocation of 34603024 bytes failed',
    compilerReportedExit='0xc0000409, STATUS_STACK_BUFFER_OVERRUN',
    controllerReportStatus=report['status'], controllerSession=21238,
    limits=['Original controller and cargo processes no longer exist; session lookup returned unknown; controller terminal code cannot be recovered',
            'Original running exit.json retained unchanged, with an additive review rather than a manufactured cargo/controller exit code',
            'No test executable ran; no test failure/pass count or full regression acceptance is claimed',
            'Compiler allocation diagnostic is distinct from earlier product stack-overflow and heap-corruption failures; their causes remain unresolved',
            'No retry, assertion/ignore/budget/stack-size change, cache deletion or Android test'])
(out / 'review.json').write_text(json.dumps(review, indent=2)+'\n', encoding='utf-8')
entries = {'review.json': (out/'review.json').read_bytes(), 'publisher.py': Path(__file__).read_bytes()}
for path in raw.iterdir():
    if path.is_file(): entries['original/'+path.name] = path.read_bytes()
entries['manifest.json'] = (json.dumps({name:dict(bytes=len(data),sha256=sha(data)) for name,data in entries.items()}, indent=2)+'\n').encode()
dest = work / 'engineering/validation/data/frame-rate85-desktop-compiler-v1.zip'
with zipfile.ZipFile(dest, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name,data in entries.items(): archive.writestr(name,data)
with zipfile.ZipFile(dest) as archive:
    assert archive.testzip() is None
    for name,data in entries.items(): assert archive.read(name) == data
receipt = dict(review=review, archive=dict(path=dest.name,bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),members=len(entries)))
dest.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n', encoding='utf-8')
(work/'engineering/validation/frame-rate85-complete-desktop-current.md').write_text('''# Integrated desktop/UI regression: compiler failure

The approved readout fixture passed its unchanged original regression, including
two fresh default-log hover processes. That scoped pass remains valid. It does
not constitute complete package acceptance.

The full desktop/UI attempt used `a45bbe94`, including main `77f61452`. The
all-target check passed in 103.422 seconds. The following unfiltered, sequential
`cargo test -p motion-desktop -p motion-ui --no-fail-fast --locked --offline --
--test-threads=1` did not reach a test executable. While building the desktop
test program, rustc reported `memory allocation of 34603024 bytes failed` and
terminated with the reported `0xc0000409, STATUS_STACK_BUFFER_OVERRUN` status.
The allocation diagnostic is the available evidence; the status name alone
does not establish a stack-buffer bug in the product.

The controller and cargo processes were absent on resumption, and original
session 21238 was no longer accessible. Its final controller/cargo return code
was not recovered. The original running receipt is preserved unchanged; the
additive review records this observation explicitly. No test counts are inferred
from metadata, and no previous test executable is relabelled as this build.

The [receipt](data/frame-rate85-desktop-compiler-v1.json) and
[archive](data/frame-rate85-desktop-compiler-v1.zip) retain original raw logs,
commands, environment, source hashes, target inventory and a verified manifest.
All recorded source hashes still match. No retry or modification of assertions,
ignore markers, budgets or stack size was used to turn the failure green.

Full desktop/UI acceptance remains pending, as do final CI and the separately
retained earlier native product stack-overflow and heap-corruption failures.
This report does not diagnose or resolve those failures. Android is excluded.
''', encoding='utf-8', newline='\n')
print(json.dumps(receipt['archive']))
