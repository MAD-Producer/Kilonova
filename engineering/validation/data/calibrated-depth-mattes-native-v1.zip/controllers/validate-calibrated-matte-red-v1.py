from pathlib import Path
import hashlib, json, os, re, subprocess

root=Path('E:/Dev/aem'); work=root/'.worktrees/calibrated-depth-mattes'
out=root/'artifacts/pr-queue/calibrated-matte-red-v1';out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',CARGO_BUILD_JOBS='1');env.pop('MOTION_LOG',None)
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=work).decode().split('\0')
source={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and p.endswith(('.rs','.toml','.wgsl'))}
report={'source':source,'steps':[]}
for name,command in [('clean-render',['cargo','clean','-p','motion-render']),('red',['cargo','test','-p','motion-render','--test','depth_surface','calibrated_receiver_four_matte_modes_use_screen_coverage_before_depth','--locked','--offline','--','--exact','--nocapture','--test-threads=1'])]:
    # The exact name includes the module path.
    if name=='red': command[command.index('calibrated_receiver_four_matte_modes_use_screen_coverage_before_depth')]='calibrated_mattes::calibrated_receiver_four_matte_modes_use_screen_coverage_before_depth'
    print(json.dumps({'start':name}),flush=True)
    with (out/f'{name}.stdout.log').open('wb') as stdout,(out/f'{name}.stderr.log').open('wb') as stderr:
        code=subprocess.run(command,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
    report['steps'].append(dict(name=name,command=command,exitCode=code));(out/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report['steps'][-1]),flush=True)
    if name=='clean-render':assert code==0
    else:
        text=(out/'red.stdout.log').read_text(encoding='utf-8')
        err=(out/'red.stderr.log').read_text(encoding='utf-8')
        assert code!=0 and '0 passed; 1 failed; 0 ignored' in text,(text,err)
        assert 'depth composition path' in text+err,(text,err)
assert source=={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in source}
(out/'expected-red.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
