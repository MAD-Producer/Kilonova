"""Keep original numeric bounds; reproduce the CI adapter class locally."""
from pathlib import Path
import json,os,runpy,sys
root=Path('E:/Dev/aem')
driver=root/'.tools/android-sdk/emulator/lib64/vulkan/lvp_icd.json'
assert driver.is_file()
os.environ.update(WGPU_BACKEND='vulkan',VK_DRIVER_FILES=str(driver))
os.environ['PATH']=str(driver.parent)+os.pathsep+os.environ['PATH']
source=(root/'.tools/issue-closure-review/validate-issue78-five-proofs.py').read_text(encoding='utf-8')
source=source.replace("commands=[", "commands=[\n ('coordinate-and-grid-cpu',base+['--lib','plane_coordinates::tests','--','--test-threads=1']),\n ('portable-plane-shaders',base+['--lib','plane_sampling::tests','--','--test-threads=1']),\n ('plane-coverage',base+['--test','sampling_pixel_grid','--','--test-threads=1']),\n ('perspective-sampling',base+['--test','projected_planes','--','--test-threads=1']),")
assert "('coordinate-and-grid-cpu'" in source
exec(compile(source,__file__,'exec'))
