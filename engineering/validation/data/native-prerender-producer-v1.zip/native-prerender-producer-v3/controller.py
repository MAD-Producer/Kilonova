"""Serialize actual source-bound prerender controls behind the cache owner."""
from pathlib import Path
from datetime import datetime, timezone
from ctypes import wintypes
import ctypes, hashlib, json, os, re, shutil, subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/native-prerender-runtime'
OUT = ROOT / 'artifacts/pr-queue/native-prerender-producer-v3'
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__, OUT / 'controller.py')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=WORK).decode().strip()

def sources():
    paths = git('ls-files', '--cached', '--others', '--exclude-standard', '-z').split('\0')
    return {p: hashlib.sha256((WORK / p).read_bytes()).hexdigest() for p in paths if p and
            (p.endswith(('.rs', '.toml', '.wgsl', '.py', '.json', '.yml', '.yaml')) or p == 'Cargo.lock')}

assert not git('status', '--porcelain')
source = sources()
report = dict(head=git('rev-parse', 'HEAD'), source=source, status='queued', steps=[])
previous = 76664
command = subprocess.check_output(['powershell', '-NoProfile', '-Command',
    f'(Get-CimInstance Win32_Process -Filter "ProcessId = {previous}").CommandLine'], text=True).strip()
assert 'validate-composition-frame-cache-v2.py' in command, command
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.WaitForSingleObject.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
handle = kernel.OpenProcess(0x00100000, False, previous)
assert handle, ctypes.get_last_error()
report['previousController'] = dict(pid=previous, command=command)
(OUT / 'waiting.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(dict(waitingForController=previous, controllerPid=os.getpid())), flush=True)
while True:
    status = kernel.WaitForSingleObject(handle, 1000)
    if status == 0: break
    assert status == 258, status
kernel.CloseHandle(handle)
prior = json.loads((ROOT / 'artifacts/pr-queue/composition-frame-cache-v2/accepted.json').read_text(encoding='utf-8'))
assert prior['status'] == 'accepted' and prior['sourceUnchanged']
assert sources() == source

env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_TARGET_DIR=str(ROOT / 'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0',
           CARGO_BUILD_JOBS='1', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
test = ['cargo', 'test', '-p', 'motion-desktop-media', '--features', 'ffmpeg,ai-depth', '--locked', '--offline']
manual = 'movie::prerender::tests::all_four_precisions_keep_native_hdr_alpha_and_exposure_without_sdr_conversion'
steps = [
    ('focused', [*test, 'movie::prerender::', '--', '--test-threads=1'], 6),
    ('four-precision', [*test, manual, '--', '--ignored', '--exact', '--test-threads=1'], 1),
    ('media-regression', [*test, '--', '--test-threads=1'], None),
    ('desktop-check', ['cargo', 'check', '-p', 'motion-desktop', '--features', 'ffmpeg,motion-host/ai-depth', '--locked', '--offline'], 0),
    ('provenance', ['python', 'tools/validate_provenance.py'], 0),
]
report['status'] = 'running'
for name, args, expected in steps:
    print(json.dumps(dict(start=name)), flush=True)
    with (OUT / (name + '.stdout.log')).open('wb') as so, (OUT / (name + '.stderr.log')).open('wb') as se:
        code = subprocess.run(args, cwd=WORK, env=env, stdout=so, stderr=se).returncode
    stdout = (OUT / (name + '.stdout.log')).read_text(encoding='utf-8')
    counts = re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored', stdout)
    row = dict(name=name, command=args, exitCode=code, counts=counts, sourceUnchanged=sources() == source,
               ignoredTests=re.findall(r'^test (\S+) \.\.\. ignored(?:, (.*))?$', stdout, re.M))
    report['steps'].append(row)
    (OUT / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    assert code == 0 and row['sourceUnchanged'], row
    if expected != 0:
        assert counts and all(int(f) == 0 for _, f, _ in counts), row
        passed = sum(int(p) for p, _, _ in counts)
        assert passed > 0 and (expected is None or expected == passed), row
        if name == 'four-precision': assert all(int(i) == 0 for _, _, i in counts)
report.update(status='accepted', sourceUnchanged=sources() == source,
              completedUtc=datetime.now(timezone.utc).isoformat(),
              scope='Frozen full-resolution authored-camera native producer only. Scheduler runtime, foreground consumer, completion quota, preview profiles and P95 remain pending. Background capability stays disabled.')
(OUT / 'accepted.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(dict(accepted=True)), flush=True)


