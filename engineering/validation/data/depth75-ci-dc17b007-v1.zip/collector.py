"""Collect one exact-head terminal CI result without dispatching or retrying CI."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess
import zipfile

ART = Path('E:/Dev/aem/artifacts/pr-queue')
OUT = ART / 'depth75-ci-dc17b007-terminal-v1'
REPO = 'MAD-Producer/Kilonova'
RUN = 42582989141
HEAD = 'dc17b0071e79e5485882c8cce5f0be2fe8e50757'


def api(path):
    return subprocess.check_output(['gh', 'api', path])


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


run = json.loads(api(f'repos/{REPO}/actions/runs/{RUN}'))
assert run['head_sha'] == HEAD and run['status'] == 'completed'
jobs = json.loads(api(f'repos/{REPO}/actions/runs/{RUN}/jobs?per_page=100'))['jobs']
assert jobs and all(j['status'] == 'completed' and j['head_sha'] == HEAD for j in jobs)
OUT.mkdir(exist_ok=False)
write(OUT / 'run.json', run)
write(OUT / 'jobs.json', jobs)
names = [
    'depth::wgsl::rust_remap::tests::owned_output_verifies_digest_and_preserves_an_existing_publication',
    'depth::wgsl::rust_remap::tests::canceled_host_remap_does_not_read_input_or_create_an_output',
    'depth::wgsl::rust_remap::tests::exact_endpoints_and_single_pixel_axes_do_not_sample_padding',
    'depth::wgsl::rust_remap::tests::constant_and_affine_planes_follow_independent_source_coordinates',
    'depth::wgsl::rust_remap::tests::wrong_extent_nonfinite_input_invalid_dimensions_and_cancellation_are_refused',
    'depth::wgsl::rust_remap::tests::host_procedure_and_runtime_cannot_masquerade_as_the_python_only_mode',
    'process_memory::tests::host_remap_is_explicit_and_cannot_be_summed_as_a_separate_child',
]
records = []
controls = []
for job in jobs:
    if job['conclusion'] == 'skipped':
        continue
    path = OUT / f'{job["id"]}.log'
    with path.open('wb') as stdout, (OUT / f'{job["id"]}.download.stderr.log').open('wb') as stderr:
        result = subprocess.run(['gh', 'api', f'repos/{REPO}/actions/jobs/{job["id"]}/logs'], stdout=stdout, stderr=stderr)
    raw = path.read_bytes()
    records.append(dict(job=job['id'], name=job['name'], conclusion=job['conclusion'],
                        download_exit=result.returncode, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
    if job['name'].startswith('Desktop tests (') and result.returncode == 0:
        text = raw.decode('utf-8')
        counts = {name: len(re.findall(r'(?m)^.*?test ' + re.escape(name) + r' \.\.\. ok\s*$', text)) for name in names}
        controls.append(dict(job=job['id'], name=job['name'], named_pass_occurrences=counts,
                             all_seven_named_controls_once=all(value == 1 for value in counts.values())))
collection = dict(status='terminal_exact_head_ci_retained', run=RUN, head=HEAD,
                  conclusion=run['conclusion'], jobs=records, named_controls=controls,
                  observed_utc=datetime.now(timezone.utc).isoformat(),
                  limits=['Named controls are verified log observations, not new tests or additive pass totals',
                          'External model, live cache/Session controls and sustained qualification are not run by CI',
                          'This exact source precedes the later one-service scheduler commit',
                          'Remote outcomes do not replace the original failed local full-workspace command'])
write(OUT / 'collection.json', collection)
members = {p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
members['collector.py'] = Path(__file__).read_bytes()
archive = OUT / 'depth75-ci-dc17b007-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as target:
    for name, raw in sorted(members.items()):
        target.writestr(name, raw)
manifest = dict(archive=archive.name, bytes=archive.stat().st_size,
                sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), source_head=HEAD, run=RUN,
                members={name: dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) for name, raw in members.items()})
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(members)
    for name, raw in members.items():
        assert target.read(name) == raw
write(OUT / 'depth75-ci-dc17b007-v1.json', manifest)
print(json.dumps(dict(conclusion=run['conclusion'], jobs=len(jobs), archive=archive.name,
                     bytes=manifest['bytes'], sha256=manifest['sha256'], named_controls=controls)))
