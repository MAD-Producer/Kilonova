"""Retain the executed temporal control plus reconstructable source delta."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path('E:/Dev/aem')
WORK=ROOT/'.worktrees/reference-depth76'
OUT=ROOT/'artifacts/pr-queue/depth76-native-sequence-v1'
DATA=WORK/'engineering/validation/data'
sha=lambda b:hashlib.sha256(b).hexdigest()
receipt=json.loads((OUT/'exit.json').read_text())
assert receipt['status']=='passed_selected_complete_targets' and receipt['sourceUnchanged']
assert len(receipt['phases'])==1 and receipt['phases'][0]['exitCode']==0
assert '52 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in (OUT/'0-stdout.log').read_text()
costs=json.loads((OUT/'native/sequence-costs.json').read_text())
assert len(costs)==48 and all(r['checked_pixels']>4000 for r in costs)
ffmpeg=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
movie=OUT/'native/masked-depth-sequence.mp4'
command=[str(ffmpeg),'-v','error','-nostdin','-framerate','24','-i',str(OUT/'native/sequence/%03d.png'),
         '-frames:v','48','-vf','scale=520:520:flags=neighbor','-c:v','mpeg4','-q:v','2','-pix_fmt','yuv420p',str(movie)]
assert not movie.exists()
with (OUT/'encode-stdout.log').open('wb') as stdout,(OUT/'encode-stderr.log').open('wb') as stderr:
    code=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=30).returncode
assert code==0
(OUT/'video.json').write_text(json.dumps(dict(command=command,exitCode=code,frames=48,frameRate=24,
    sourceSize=[65,65],displaySize=[520,520],displayOnly='Nearest upscaling of actual captures; MPEG-4 video is not a pixel oracle',
    ffmpegSha256=sha(ffmpeg.read_bytes()),sha256=sha(movie.read_bytes())),indent=2)+'\n')
entries={str(p.relative_to(OUT)).replace('\\','/'):p.read_bytes() for p in OUT.rglob('*') if p.is_file()}
entries['archive-controller.py']=Path(__file__).read_bytes()
base=DATA/'depth76-native-metric-v3.zip'
base_sha='f4fba9edc288ffccefd71dcd7003c26c5688998501f8832ca68c668633fa8a37'
assert sha(base.read_bytes())==base_sha
overrides=[]
with zipfile.ZipFile(base) as baseline:
    for path,expected in receipt['source'].items():
        data=(WORK/path).read_bytes();assert sha(data)==expected,path
        key='source/'+path
        if key not in baseline.namelist() or baseline.read(key)!=data:
            entries[key]=data;overrides.append(path)
archive=DATA/'depth76-native-sequence-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as output:
    for path,data in sorted(entries.items()):output.writestr(path,data)
with zipfile.ZipFile(archive) as verify:
    assert set(verify.namelist())==set(entries)
    for path,data in entries.items():assert verify.read(path)==data
manifest=dict(status='verified_controlled_masked_native_temporal_oracle_not_universal_footage_quality',
    head=receipt['baseCommit'],sourceUnchanged=True,tests=dict(passed=52,failed=0,ignored=0,filtered=0,completeTargets=1),
    elapsedSeconds=receipt['elapsedSeconds'],frames=48,cycles=4,checkedPixels=sum(r['checked_pixels'] for r in costs),
    blendCpuUs=dict(min=min(r['blend_cpu_us'] for r in costs),max=max(r['blend_cpu_us'] for r in costs)),
    submitAndReadbackWallUs=dict(min=min(r['submit_and_readback_wall_us'] for r in costs),max=max(r['submit_and_readback_wall_us'] for r in costs)),
    sourceBaseArchive=dict(path=base.name,sha256=base_sha),sourceOverrides=overrides,
    archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),
    members=[dict(path=p,bytes=len(d),sha256=sha(d)) for p,d in sorted(entries.items())],
    limits=['Analytically authored moving scene and exact registration; not arbitrary real-footage motion estimation',
            'Exact triangle-edge raster ownership excluded; over4000 other pixels checked on every frame',
            'All 48 original capture PNGs are pixel evidence; upscaled compressed video is a display derivative',
            'Source reconstruction requires the committed base archive plus source overrides in this archive',
            'Submit/readback wall timing includes waiting; it is not isolated GPU duration'])
(DATA/'depth76-native-sequence-v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='members'}))
