"""Full original photographed sequence: independent corner errors and all losses."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys,zipfile

ROOT=Path('E:/Dev/aem');WORK=ROOT/'artifacts/pr-queue/tracking88-window-support-candidate-v1/candidate'
INPUT=ROOT/'artifacts/pr-queue/tracking88-real-planar-acquisition-v1'
OUT=ROOT/'artifacts/pr-queue/tracking88-window-support-candidate-v1/real-candidate'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
sys.path.insert(0,str(WORK))
from plate_contract import require
from track_plate import atomic_json,digest
import cv2,numpy as np
import plate_flow as flow
cv2.setNumThreads(1)
source=INPUT/'phone.avi';annotations=INPUT/'phone-gt.zip'
require(digest(source)=='c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9','real source differs')
require(digest(annotations)=='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886','annotation archive differs')
report=dict(status='running',pid=os.getpid(),startedUtc=datetime.now(timezone.utc).isoformat(),
    scope='External local full photographed phone sequence; numeric measurement, not native/whole-issue acceptance',
    sourceSha256=digest(source),annotationSha256=digest(annotations),
    convention='Source ZIP row then column; MATLAB coordinates converted to zero-based x,y by subtracting one; video frame 0 maps img_00200.txt',
    sourceFiles={name:digest(WORK/name) for name in ('plate_contract.py','plate_flow.py','track_plate.py')},runs=[])
def save():atomic_json(OUT/'measurement.json',report)
save()
try:
    with zipfile.ZipFile(annotations) as bundle:
        names=sorted(i.filename for i in bundle.infolist() if not i.is_dir())
        require(names==[f'img_{i:05d}.txt' for i in range(200,2500)],'ground truth file mapping differs')
        corners=[]
        for name in names:
            info=bundle.getinfo(name);require(info.file_size<=1024,'annotation exceeds byte budget')
            values=np.array([float(x) for x in bundle.read(name).decode('ascii').split()])
            require(values.size==8 and np.isfinite(values).all(),'invalid source corner annotation')
            values=values.reshape(2,4)
            corners.append(np.column_stack((values[1]-1.,values[0]-1.)))
    corners=np.array(corners)
    point=corners[0,0].tolist();roi=[160.,180.,340.,210.]
    matrices=[cv2.getPerspectiveTransform(corners[0].astype(np.float32),quad.astype(np.float32)) for quad in corners]
    ffmpeg=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
    ffprobe=ffmpeg.with_name('ffprobe.exe')
    for mode in ('no-corrections','periodic-manual-200'):
        corrections=[]
        if mode=='periodic-manual-200':
            for index in range(200,2300,200):
                x,y=corners[index,0]
                visible=bool(0<=x<640 and 0<=y<480)
                corrections.append(dict(track='feature',source_index=index,visibility='visible' if visible else 'lost',observation=dict(kind='point',pixels=[float(x),float(y)]) if visible else None))
                try:
                    flow.plane_matrix(matrices[index],roi)
                    observation=dict(kind='plane',matrix=matrices[index].tolist())
                except ValueError as cause:
                    report.setdefault('unsupportedManualPlanes',[]).append(dict(index=index,cause=str(cause)))
                    observation=None
                corrections.append(dict(track='plane',source_index=index,visibility='visible' if observation is not None else 'lost',observation=observation))
        request=dict(version=1,source_sha256=report['sourceSha256'],stream_index=0,
            tracks=[dict(id='feature',kind='point',position=point),dict(id='plane',kind='plane',roi=roi)],corrections=corrections)
        config=OUT/(mode+'.request.json');atomic_json(config,request)
        command=[sys.executable,str(WORK/'track_plate.py'),'--source',str(source),'--request',str(config),'--output',str(OUT/mode),'--ffmpeg',str(ffmpeg),'--ffprobe',str(ffprobe)]
        row=dict(mode=mode,status='running',command=command,manualSamples=len(corrections));report['runs'].append(row);save()
        env=os.environ.copy();env.pop('MOTION_LOG',None)
        with (OUT/(mode+'.stdout.log')).open('wb') as stdout,(OUT/(mode+'.stderr.log')).open('wb') as stderr:
            child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();row['exitCode']=child.wait()
        require(row['exitCode']==0,'photographed measurement child failed: '+mode)
        require((OUT/(mode+'.stdout.log')).read_bytes()==b'','tracker polluted stdout')
        asset=json.loads((OUT/mode/'tracks.mstrack').read_text())
        require(len(asset['source_pts'])==2300 and asset['ticks_per_second']==100 and asset['source_pts']==list(range(2300)),'original complete photographed timeline differs')
        summaries=[]
        for track in asset['tracks']:
            errors=[];lost=[];visible=0;manual=0
            for index,sample in enumerate(track['samples']):
                require(sample['source_index']==index,'sample order differs')
                if sample['manual_correction']:manual+=1;continue
                if index==0:continue
                if sample['visibility']!='visible':lost.append(index);continue
                visible+=1
                if track['kind']=='point':
                    error=float(np.linalg.norm(np.array(sample['observation']['pixels'])-corners[index,0]))
                else:
                    matrix=np.array(sample['observation']['matrix']);h=np.column_stack((corners[0],np.ones(4)))@matrix.T
                    predicted=h[:,:2]/h[:,2:]
                    error=float(np.linalg.norm(predicted-corners[index],axis=1).max())
                errors.append(error)
            summaries.append(dict(track=track['id'],automaticVisible=visible,automaticLost=len(lost),manualSamples=manual,
                firstLost=lost[0] if lost else None,maxPixels=max(errors) if errors else None,
                rmsPixels=float(np.sqrt(np.mean(np.square(errors)))) if errors else None,p95Pixels=float(np.percentile(errors,95)) if errors else None,
                automaticOver5Pixels=sum(x>5. for x in errors),automaticOver15Pixels=sum(x>15. for x in errors)))
        row.update(status='measured_not_accepted',tracks=summaries);save()
    for name,expected in report['sourceFiles'].items():require(digest(WORK/name)==expected,'tracker source changed during measurement')
    report['status']='measured_full_real_sequence_acceptance_review_pending'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
