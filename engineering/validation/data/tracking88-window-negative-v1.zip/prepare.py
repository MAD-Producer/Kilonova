"""Prepare one fixed larger-patch hypothesis; do not execute during native gates."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import subprocess

ROOT = Path('E:/Dev/aem')
OUT = ROOT / 'artifacts/pr-queue/tracking88-window-support-candidate-v1'
BASE = '72423ec2aaf877147d20daa6827a2929bf3649b3'
OUT.mkdir(exist_ok=False)
(OUT / 'prepare.py').write_bytes(Path(__file__).read_bytes())
names = ('plate_flow.py', 'plate_contract.py', 'track_plate.py', 'test_flow.py',
         'validate_prototype.py', 'validate_manual_absence.py')
for variant in ('baseline', 'candidate'):
    folder = OUT / variant
    folder.mkdir()
    for name in names:
        (folder / name).write_bytes(subprocess.check_output(
            ['git', 'show', BASE + ':tools/tracking/' + name], cwd=ROOT))
path = OUT / 'candidate/plate_flow.py'
original = path.read_text(encoding='utf-8')
assert original.count('winSize=(21,21)') == 1
assert original.count('np.ones((23,23),np.uint8)') == 1
assert original.count('# Include the 21-pixel LK window and its interpolation neighbours.') == 1
candidate = original.replace('winSize=(21,21)', 'winSize=(31,31)')
candidate = candidate.replace('np.ones((23,23),np.uint8)', 'np.ones((33,33),np.uint8)')
candidate = candidate.replace('# Include the 21-pixel LK window and its interpolation neighbours.',
                              '# Include the 31-pixel LK window and its interpolation neighbours.')
restored = candidate.replace('winSize=(31,31)', 'winSize=(21,21)').replace(
    'np.ones((33,33),np.uint8)', 'np.ones((23,23),np.uint8)').replace(
    '# Include the 31-pixel LK window and its interpolation neighbours.',
    '# Include the 21-pixel LK window and its interpolation neighbours.')
assert restored == original
ast.parse(candidate)
path.write_text(candidate, encoding='utf-8')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
files = {v + '/' + n: sha(OUT / v / n) for v in ('baseline', 'candidate') for n in names}
report = dict(status='prepared_unexecuted_not_adopted', baseline=BASE,
              preparedUtc=datetime.now(timezone.utc).isoformat(), files=files,
              hypothesis='A larger fixed image patch measures perspective flow with more spatial context; matched erosion excludes every padded LK window',
              changes=['LK image measurement window 21 to 31 pixels',
                       'Matching valid-source erosion 23 to 33 pixels, preserving the two-pixel interpolation margin'],
              limits=[
                  'No parameter sweep or label-based selection; this is a single predefined measurement hypothesis',
                  'All source ROI, seeds, PTS, scheduled corrections and 15-pixel quality gate remain unchanged',
                  'Original FB, appearance, residual, fit, inlier and independent-consensus limits remain unchanged',
                  'Point behavior also uses the larger patch and must pass all original controls and real-sequence comparisons',
                  'Run only after the original complete native regression terminates; do not compete with its timing controls',
                  'Require all original CV controls, analytic sequence, absence/logging and full original two-mode photographed comparisons',
                  'Reject remaining false-visible errors or reduced coverage; lost outputs are not a quality repair',
                  'No source worktree mutation, product adoption, new dependency or third-party asset publication'])
(OUT / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in report.items() if k != 'files'}))
