"""Isolated candidate experiment; preserves original controls and real benchmark."""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback

ROOT = Path('E:/Dev/aem')
OUT = ROOT / 'artifacts/pr-queue/tracking88-window-support-candidate-v1'
CANDIDATE = OUT / 'candidate'
BASELINE = OUT / 'baseline'
NATIVE = ROOT / 'artifacts/pr-queue/tracking88-prototype-workspace-integration-v3/exit.json'
ORIGINAL = ROOT / 'artifacts/pr-queue/tracking88-photographed-prototype-v6/controller.py'
FFMPEG = ROOT / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity():
    return {p.relative_to(OUT).as_posix(): digest(p)
            for folder in (CANDIDATE, BASELINE)
            for p in sorted(folder.glob('*.py'))}


def main():
    native = json.loads(NATIVE.read_text(encoding='utf-8'))
    assert native['status'] != 'running' and 'completedUtc' in native, 'Native gate still active; do not compete with its timing controls'
    assert not (OUT / 'experiment.json').exists(), 'Preserve an existing experiment; never overwrite a failed attempt'
    expected = json.loads((OUT / 'preparation.json').read_text(encoding='utf-8'))['files']
    before = identity()
    assert all(before[name] == value for name, value in expected.items())
    for path in CANDIDATE.glob('*.py'):
        ast.parse(path.read_text(encoding='utf-8'))
    env = os.environ.copy()
    env.pop('MOTION_LOG', None)
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1', OMP_NUM_THREADS='1',
               OPENBLAS_NUM_THREADS='1', TEMP=str(ROOT / 'target/colmap88-isolated-check/tmp/cv-window-support-v1'),
               TMP=str(ROOT / 'target/colmap88-isolated-check/tmp/cv-window-support-v1'))
    Path(env['TEMP']).mkdir(parents=True, exist_ok=True)
    report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(),
                  source=before, controllerSha256=digest(Path(__file__)), nativeGateStatus=native['status'], stages=[], limits=[
                      'Known benchmark motivated the candidate; not an unseen validation set',
                      'External experiment only; no product/native/whole-issue acceptance',
                      'Original controls, ROI, all2300frames, labels, corrections and15pixel gate retained',
                      'Missing samples remain reported separately; low error does not establish adequate coverage',
                      'No third-party video, annotations or derived images published'])
    began = time.monotonic()

    def save():
        pending = OUT / 'experiment.pending.json'
        pending.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
        os.replace(pending, OUT / 'experiment.json')

    def run(name, command, cwd):
        row = dict(name=name, command=[str(x) for x in command], status='running')
        report['stages'].append(row)
        start = time.monotonic()
        save()
        with (OUT / (name + '.stdout.log')).open('wb') as stdout, (OUT / (name + '.stderr.log')).open('wb') as stderr:
            child = subprocess.Popen(row['command'], cwd=cwd, env=env, stdout=stdout, stderr=stderr)
            row['pid'] = child.pid
            save()
            code = child.wait()
        row.update(exitCode=code, elapsedSeconds=round(time.monotonic() - start, 3),
                   status='passed' if code == 0 else 'failed')
        save()
        assert code == 0, name + ' failed; retain original output and reject this attempt'

    save()
    try:
        run('baseline-controls', [sys.executable, '-m', 'unittest', '-v', 'test_flow'], BASELINE)
        run('candidate-controls', [sys.executable, '-m', 'unittest', '-v', 'test_flow'], CANDIDATE)
        run('analytic', [sys.executable, CANDIDATE / 'validate_prototype.py', '--ffmpeg', FFMPEG,
                        '--ffprobe', FFMPEG.with_name('ffprobe.exe'), '--output', OUT / 'analytic'], CANDIDATE)
        run('manual-absence', [sys.executable, CANDIDATE / 'validate_manual_absence.py', '--ffmpeg', FFMPEG,
                              '--ffprobe', FFMPEG.with_name('ffprobe.exe'), '--output', OUT / 'manual-absence'], CANDIDATE)
        original_text = ORIGINAL.read_text(encoding='utf-8')
        report['realObservers'] = []
        measurements = {}
        for variant in ('baseline', 'candidate'):
            real_text = original_text.replace("ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'",
                                             "ROOT=Path('E:/Dev/aem');WORK=ROOT/'artifacts/pr-queue/tracking88-window-support-candidate-v1/" + variant + "'")
            real_text = real_text.replace("OUT=ROOT/'artifacts/pr-queue/tracking88-photographed-prototype-v6'",
                                         "OUT=ROOT/'artifacts/pr-queue/tracking88-window-support-candidate-v1/real-" + variant + "'")
            real_text = real_text.replace("WORK/'tools/tracking'", 'WORK')
            real_text = real_text.replace("WORK/'tools/tracking/track_plate.py'", "WORK/'track_plate.py'")
            assert real_text != original_text and 'tracking-import88' not in real_text and "WORK/'tools/tracking" not in real_text
            ast.parse(real_text)
            controller = OUT / ('real-' + variant + '-controller.py')
            controller.write_text(real_text, encoding='utf-8')
            report['realObservers'].append(dict(variant=variant, originalSha256=digest(ORIGINAL), executedSha256=digest(controller),
                                                modificationScope='Only source/output routing changed; original measurement logic retained'))
            run('real-full-' + variant, [sys.executable, controller], OUT / variant)
            measurement = json.loads((OUT / ('real-' + variant) / 'measurement.json').read_text(encoding='utf-8'))
            assert len(measurement['runs']) == 2
            measurements[variant] = [dict(mode=row['mode'], **track)
                                     for row in measurement['runs'] for track in row['tracks']]
        for mode in ('no-corrections', 'periodic-manual-200'):
            assert (OUT / 'real-baseline' / (mode + '.request.json')).read_bytes() == (OUT / 'real-candidate' / (mode + '.request.json')).read_bytes()
        quality = measurements['candidate']
        baseline = {(row['mode'], row['track']): row for row in measurements['baseline']}
        assert len(quality) == len(baseline) == 4
        report['realMeasurements'] = measurements
        report['original15PixelGatePassed'] = all(x['automaticVisible'] > 0 and x['automaticOver15Pixels'] == 0 for x in quality)
        report['coverageNoRegression'] = all(x['automaticVisible'] >= baseline[(x['mode'], x['track'])]['automaticVisible'] for x in quality)
        report['status'] = ('measured_quality_and_coverage_gates_passed_native_review_pending'
                            if report['original15PixelGatePassed'] and report['coverageNoRegression'] else
                            'rejected_original_real_quality_gate' if not report['original15PixelGatePassed'] else 'rejected_real_coverage_regression')
    except BaseException:
        report.update(status='rejected_original_failure_retained', traceback=traceback.format_exc())
        raise
    finally:
        report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - began, 3),
                      sourceUnchanged=identity() == before)
        save()
    assert report['sourceUnchanged']
    print(json.dumps({k: v for k, v in report.items() if k != 'source'}))
    if not report['original15PixelGatePassed'] or not report['coverageNoRegression']:
        print('Candidate rejected: unchanged 15-pixel error budget or fresh-baseline coverage gate failed; measurements retained', file=sys.stderr)
        raise SystemExit(2)


if __name__ == '__main__':
    main()
