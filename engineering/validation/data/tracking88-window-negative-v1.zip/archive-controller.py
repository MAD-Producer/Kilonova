"""Retain the rejected window candidate without benchmark media or labels."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path('E:/Dev/aem')
RUN=ROOT/'artifacts/pr-queue/tracking88-window-support-candidate-v1'
OUT=ROOT/'artifacts/pr-queue/tracking88-window-negative-archive-v1'
WORK=ROOT/'.worktrees/planar-tracker88'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((RUN/'experiment.json').read_text())
assert receipt['status']=='rejected_original_real_quality_gate' and receipt['sourceUnchanged']
assert not receipt['original15PixelGatePassed'] and not receipt['coverageNoRegression']
files={p.name:p for p in RUN.iterdir() if p.is_file() and p.suffix in ('.json','.log','.py')}
for side in ('baseline','candidate'):
    for p in (RUN/side).glob('*.py'): files[f'{side}/{p.name}']=p
files['validation-controller.py']=ROOT/'.tools/issue-closure-review/validate-tracking88-window-support-v1.py'
files['archive-controller.py']=Path(__file__)
entries={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(files.items())}
OUT.mkdir(exist_ok=False)
archive=OUT/'tracking88-window-negative-v1.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in sorted(files.items()):z.writestr(n,p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(entries)
    for n,e in entries.items():
        raw=z.read(n)
        assert len(raw)==e['bytes'] and hashlib.sha256(raw).hexdigest()==e['sha256']
manifest=dict(status=receipt['status'],archive=archive.name,bytes=archive.stat().st_size,
              sha256=sha(archive),entries=entries,
              limits=['Rejected; no product algorithm change or real quality acceptance',
                      'Original ROI, correction schedule, labels and 15 px gate unchanged',
                      'Media, derived images, per-frame annotations and solves excluded'])
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for p in (archive,OUT/'manifest.json'):
    dest=WORK/'engineering/validation/data'/p.name
    assert not dest.exists()
    dest.write_bytes(p.read_bytes());assert sha(dest)==sha(p)
print(json.dumps({k:v for k,v in manifest.items() if k!='entries'}))
