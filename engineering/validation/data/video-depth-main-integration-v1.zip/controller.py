from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess
root=Path('E:/Dev/aem'); work=root/'.worktrees/video-depth-geometry'
out=root/'artifacts/pr-queue/video-depth-main-integration-v1'; out.mkdir(exist_ok=False)
native=root/'artifacts/pr-queue/video-depth-geometry-green-v1/accepted.json'
prior=json.loads(native.read_text(encoding='utf-8')); assert all(row['exitCode']==0 and row['sourceUnchanged'] for row in prior['steps'])
git=lambda *args: subprocess.check_output(['git',*args],cwd=work).decode().strip()
assert git('rev-parse','HEAD')=='12f2bf0cc0f8425566c9bec061ef55e0306e7f4e'
subprocess.run(['git','merge-base','--is-ancestor','8f870211b77f443d785e432ba0f34f5f86e00d13','HEAD'],cwd=work,check=True)
changed=[p for p,h in prior['source'].items() if not (work/p).is_file() or hashlib.sha256((work/p).read_bytes()).hexdigest()!=h]
assert changed and all(p.startswith('desktop/') for p in changed), changed
# Native tests remain bound to byte-identical crate sources/manifests/lockfile;
# the newly merged desktop menu code is recompiled below, not silently ignored.
paths=subprocess.check_output(['git','ls-files','-z'],cwd=work).decode().split('\0')
source={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths if p and (p.endswith(('.rs','.toml','.wgsl','.py','.json','.yml','.yaml')) or p=='Cargo.lock')}
shutil.copyfile(__file__,out/'controller.py'); shutil.copyfile(native,out/'native-accepted.json')
env=os.environ.copy(); env.update(CARGO_TARGET_DIR=str(root/'target/gltf-animation87-contract'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_NET_OFFLINE='true'); env.pop('MOTION_LOG',None)
r=dict(head=git('rev-parse','HEAD'),main='8f870211b77f443d785e432ba0f34f5f86e00d13',source=source,nativeGateSha256=hashlib.sha256(native.read_bytes()).hexdigest(),changedSources=changed,nativeLibrarySourceUnchanged=True,steps=[],startedUtc=datetime.now(timezone.utc).isoformat(),limits='Native test results apply to byte-identical crates and locked dependencies; this integration adds desktop compilation, style and provenance, not a final full-workspace or remote acceptance')
for name,cmd in [
('desktop',['cargo','check','-p','motion-desktop','--features','ffmpeg,motion-host/ai-depth','--locked','--offline']),
('style',['python','-c',"import runpy;runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"]),
('provenance',['python','tools/validate_provenance.py'])]:
    print(json.dumps(dict(start=name)),flush=True)
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        code=subprocess.run(cmd,cwd=work,env=env,stdout=stdout,stderr=stderr).returncode
    row=dict(name=name,command=cmd,exitCode=code,sourceUnchanged=all(hashlib.sha256((work/p).read_bytes()).hexdigest()==h for p,h in source.items()))
    r['steps'].append(row); (out/'exit.json').write_text(json.dumps(r,indent=2),encoding='utf-8'); print(json.dumps(row),flush=True)
    assert code==0 and row['sourceUnchanged'],name
r['completedUtc']=datetime.now(timezone.utc).isoformat(); (out/'accepted.json').write_text(json.dumps(r,indent=2),encoding='utf-8'); print('accepted',flush=True)
