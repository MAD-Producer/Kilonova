from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import time

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-import88'
out = root / 'artifacts/pr-queue/tracking88-prototype-surface-v1'
out.mkdir(exist_ok=False)
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
git = lambda *a: subprocess.check_output(['git', *a], cwd=work, encoding='utf-8').strip()
assert git('branch', '--show-current') == 'feat/88-planar-tracker-prototype'
files = sorted(set(git('ls-files', '--cached', '--others', '--exclude-standard').splitlines()))
sources = {p: sha(work / p) for p in files if p.endswith(('.rs', '.wgsl', 'Cargo.toml', 'Cargo.lock')) and (work / p).is_file()}
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(root / '.tools/prerender-cargo-home'),
    CARGO_TARGET_DIR=str(root / 'target/gltf-animation87-contract'), CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_BUILD_JOBS='1', RUST_BACKTRACE='full',
    LIBCLANG_PATH=str(root / '.tools/python-libclang/clang/native'),
    TEMP=str(root / 'target/ci-policy-validation-tmp'), TMP=str(root / 'target/ci-policy-validation-tmp'),
    MOTION_TRACKED_SURFACE_ARTIFACTS=str(out / 'surface-camera'),
    MOTION_TRACKED_BINDINGS_SURFACE_ARTIFACTS=str(out / 'surface-bindings'),
    MOTION_TRACKED_PROTOTYPE_SURFACE_ARTIFACTS=str(out / 'surface-prototype'))
ffmpeg = root / '.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
env.update(FFMPEG_DIR=str(ffmpeg), FFMPEG_INCLUDE_DIR=str(ffmpeg / 'include'), FFMPEG_LIB_DIR=str(ffmpeg / 'lib'))
env['PATH'] = str(ffmpeg / 'bin') + os.pathsep + env['PATH']
command = ['cargo', 'test', '-p', 'motion-desktop', '--features', 'ffmpeg', '--bin', 'motion-studio',
    '--locked', '--offline', 'engine::tracking_video_replacement_tests::paired::surface::',
    '--', '--test-threads=1', '--nocapture']
report = dict(status='running', startedUtc=datetime.now(timezone.utc).isoformat(),
    source=sources, head=git('rev-parse', 'HEAD'), integratedParent=git('rev-parse', 'MERGE_HEAD'), command=command)
def save():
    (out / 'exit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
save()
started = time.monotonic()
try:
    with (out / 'surface.stdout.log').open('wb') as stdout, (out / 'surface.stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = child.pid
        save()
        report['exitCode'] = child.wait()
    text = (out / 'surface.stdout.log').read_text(encoding='utf-8', errors='replace')
    report['summaries'] = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    save()
    assert report['exitCode'] == 0, 'native Surface command failed; retain both raw logs'
    assert report['summaries'] == [('ok', '3', '0', '0')], report['summaries']
    observed = json.loads((out / 'surface-prototype/report.json').read_text(encoding='utf-8'))
    assert [row['index'] for row in observed['samples']] == [0, 10, 19, 30, 40, 60, 95]
    assert all(row['mismatched'] == 0 and row['planeInterior'] > 5000 and row['pointPixels'] >= 25 for row in observed['samples'])
    assert observed['historyAndReopenExact'] and observed['missing']['frontPreserved']
    assert all(sha(work / p) == digest for p, digest in sources.items()), 'source changed during validation'
    report.update(status='actual_windows_prototype_surface_retention_missing_recovery_history_and_reopen_passed',
        observation=observed, sourceUnchanged=True)
except BaseException as cause:
    report.update(status='failed', failure=repr(cause))
    raise
finally:
    report.update(completedUtc=datetime.now(timezone.utc).isoformat(), elapsedSeconds=round(time.monotonic() - started, 3))
    save()
    print(json.dumps({k: report.get(k) for k in ['status', 'failure', 'exitCode', 'elapsedSeconds']}, indent=2), flush=True)
