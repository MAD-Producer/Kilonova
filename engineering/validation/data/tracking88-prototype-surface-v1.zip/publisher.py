from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path('E:/Dev/aem')
work = root / '.worktrees/tracking-import88'
run = root / 'artifacts/pr-queue/tracking88-prototype-surface-v3'
previous = root / 'artifacts/pr-queue/tracking88-prototype-surface-v1'
interrupted = root / 'artifacts/pr-queue/tracking88-prototype-surface-v2'
review = root / 'artifacts/pr-queue/tracking88-prototype-surface-review-v1'
review.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
result = json.loads((run / 'exit.json').read_text(encoding='utf-8'))
assert result['status'] == 'actual_windows_prototype_surface_retention_missing_recovery_history_and_reopen_passed'
assert result['exitCode'] == 0 and result['summaries'] == [['ok', '3', '0', '0']]
assert all(sha(work / p) == digest for p, digest in result['source'].items())
source_paths = [
    'desktop/app/src/engine/tracking_video_surface_tests.rs',
    'desktop/app/src/engine/tracking_surface_binding_tests.rs',
    'desktop/app/src/engine/tracking_prototype_surface_tests.rs',
    'desktop/app/src/engine/tracking_prototype_surface_oracle.rs',
    'desktop/app/tests/fixtures/tracking-prototype/README.md',
    'ATTRIBUTION.md', 'PROVENANCE.md', 'NOTICE',
]
fixture = work / 'desktop/app/tests/fixtures/tracking-prototype'
fixtures = {name: dict(bytes=(fixture / name).stat().st_size, sha256=sha(fixture / name))
    for name in ['motion.webm', 'tracks.mstrack']}
assert fixtures['motion.webm']['sha256'] == '3d83869cf562e3708faac68567a85cb1c429c538286805139927c9b26b04fc06'
assert fixtures['tracks.mstrack']['sha256'] == 'bf02b43596c206cef0d9451e08a98409076ede774a8257a87141a260ad05cf55'
prototype = run / 'surface-prototype'
observed = json.loads((prototype / 'report.json').read_text(encoding='utf-8'))
log = (prototype / 'logs/motion-studio.log').read_text(encoding='utf-8')
stderr = (prototype / 'stderr.log').read_text(encoding='utf-8', errors='replace')
stdout = (prototype / 'stdout.log').read_text(encoding='utf-8', errors='replace')
cause = 'plane observation unavailable source_index=22 visibility=Lost'
assert cause in log and cause in stderr and cause not in stdout
assert 'logging initialized level=INFO' in log
assert any('start #' in line and line.endswith(' import_tracking') for line in log.splitlines())
assert not any('start #' in line and line.endswith(' present') for line in log.splitlines())
archive = review / 'tracking88-prototype-surface-v1.zip'
members = {}
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    def add(name, data):
        assert name not in members
        z.writestr(name, data)
        members[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    for directory in [previous, interrupted, run]:
        for path in sorted(directory.rglob('*')):
            if not path.is_file() or 'project' in path.relative_to(directory).parts:
                continue
            add(directory.name + '/' + path.relative_to(directory).as_posix(), path.read_bytes())
    for p in source_paths:
        add('source/' + p, (work / p).read_bytes())
    add('fixture-identities.json', json.dumps(fixtures, indent=2).encode())
    add('publisher.py', Path(__file__).read_bytes())
with zipfile.ZipFile(archive) as z:
    assert sorted(z.namelist()) == sorted(members)
    for name, item in members.items():
        data = z.read(name)
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
manifest = dict(scope='Actual Windows Surface qualification of frozen measured synthetic output; not real photographed tracking acceptance',
    sourceHead=result['head'], integratedParent=result['integratedParent'],
    exitCode=result['exitCode'], summaries=result['summaries'], elapsedSeconds=result['elapsedSeconds'],
    archive=dict(file=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=members),
    fixtures=fixtures, observed=observed,
    limits=['No new complete workspace or desktop-package regression', 'No final-head cross-platform CI claim',
        'Windows HWND event-pumped test, not full interactive UI acceptance',
        'Real photographed tracker accuracy and useful coverage still failed', 'Android retired and excluded'])
manifest_path = review / 'tracking88-prototype-surface-v1.json'
manifest_path.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
destination = work / 'engineering/validation/data'
for p in [archive, manifest_path]:
    target = destination / p.name
    assert not target.exists()
    target.write_bytes(p.read_bytes())
document = work / 'engineering/validation/tracking88-prototype-surface-current.md'
assert not document.exists()
rows = '\n'.join(f"| {r['index']} | {r['planeInterior']} | {r['mismatched']} | {r['pointPixels']} |" for r in observed['samples'])
document.write_text(f'''# Tracking #88: measured prototype output on an actual Surface

This is a bounded Windows qualification of the previously frozen synthetic
optical-flow output. It does not qualify photographed tracker accuracy, complete
issue #88, or complete the 3D roadmap. The draft status of #582 is retained.
Android remains excluded. No product behavior, UI, panel files, dependencies,
existing assertions or acceptance thresholds were changed by this increment.

## Source and test boundary

The prototype branch incorporates `599c35e3` and its maintained-main baseline
`e2347558`. The adjacent manifest records all tested source hashes, original
process exit, elapsed time, fixture identities, raw logs, screenshots and child
process receipts. All ZIP members were read back and checked by SHA-256.

The two independently authored MIT fixtures are frozen, byte-for-byte copies
of the synthetic-v4 source and actual measured solve. Their README records
provenance and regeneration limits. Native CI does not install OpenCV/NumPy or
rerun a numerically different tracker to manufacture a successful render.

The new ordinary GPU test is under the existing Windows/FFmpeg module, alongside
the two existing Surface controls. It creates an actual HWND and wgpu Surface,
pumps the window event loop, decodes the original video and binds the measured
point/plane tracks. `CaptureUi` reads the already committed scratch front;
it does not substitute an offscreen composition render. The UI paint list is
empty: this is not a full mouse/keyboard/interactive editor acceptance claim.

## Newly executed checks

The original Cargo invocation exited 0: **3 passed, 0 failed, 0 ignored**,
including both existing Surface wrappers and the new prototype wrapper.
Elapsed controller time: {result['elapsedSeconds']} seconds.

At 125 composition fps, original millisecond PTS map exactly to eighth frames.
The independent oracle uses the measured point and homography without calling
product projection helpers. It retains the prior native qualification's
2-pixel plane edge exclusion, more than 5000 stable interior pixels with zero
mismatches, at least 25 point pixels, and less than 0.75-pixel centroid error.
Outside those colored markers, each frame must also contain more than 5000
grayscale source pixels spanning more than 32 intensity levels. This checks
the actual native video draw, rather than merely starting a decoder worker.
Every successful Surface result must have no current render error.

The initial three-test run also passed. The final run adds these explicit
native-background and error-state checks without weakening earlier assertions;
both invocations and their different source identities are retained.
An intermediate v2 invocation has no recorded exit or test result. Its tool
handle and original processes were absent when inspected on November 3;
the original running report, raw logs and observation receipt are retained.
It is incomplete evidence, not a passing test or a diagnosed product failure.
The final v3 invocation rechecks the complete strengthened three-test group.

| Original source index | Stable plane interior | Mismatches | Point pixels |
| ---: | ---: | ---: | ---: |
{rows}

- Every paused repeat advances presentation/reuse counters without increasing
  composition renders and preserves the committed image exactly
- Strict missing observation 22 fails both seek and actual Present, retains
  the last successful Surface image and last-presented frame, and invents no
  replacement geometry
- Manual recovery at 30 produces the measured current pixels; the successful
  Surface render follows the existing error-state policy without a new reset,
  retry or product behavior change
- Binding undo/redo invalidates the front, with exact redone pixels, and save/
  reopen preserves the project, managed solve bytes and actual frame-40 image
- Default Info logs include the non-Present import start; missing-state errors
  appear in file and stderr, not stdout; healthy Present starts remain absent

## Remaining limits

The original real 2300-frame photographed quality gate remains failed, with
915 automatically visible plane observations, 1373 lost and 21 errors over
15 pixels in the unchanged baseline. Synthetic Surface success does not change
that result. Full final-source desktop/workspace regression and final-head
cross-platform CI are separate unfinished gates; historical package passes
are not new execution on this source. Project rational-rate #85 and shared
API/E2E #86 remain separate prerequisites. No issue is closed by this record.

Evidence: [manifest](data/tracking88-prototype-surface-v1.json) and
[archive](data/tracking88-prototype-surface-v1.zip).
''', encoding='utf-8')
for p in ['engineering/validation/tracking88-prototype-current.md', 'engineering/validation/tracking88-acceptance-map-current.md']:
    path = work / p
    path.write_text(path.read_text(encoding='utf-8') + '''

## Frozen prototype output Surface qualification

The [new Windows Surface record](tracking88-prototype-surface-current.md)
executes the actual measured synthetic point/plane output through a native
window, retained-front reuse, strict missing refusal, manual recovery, history
and reopen. It retains the failed photographed quality conclusion and does not
claim final full regression or cross-platform CI completion.
''', encoding='utf-8')
print(json.dumps(dict(archiveBytes=archive.stat().st_size, memberCount=len(members), document=str(document)), indent=2))
