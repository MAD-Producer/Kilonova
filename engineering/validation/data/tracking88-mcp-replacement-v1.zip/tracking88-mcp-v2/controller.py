from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess

ROOT = Path('E:/Dev/aem')
WORK = ROOT / '.worktrees/tracking-import88'
OUT = ROOT / 'artifacts/pr-queue/tracking88-mcp-v2'
OUT.mkdir(exist_ok=False)
(OUT / 'controller.py').write_bytes(Path(__file__).read_bytes())
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard'], cwd=WORK, text=True).splitlines()
source = {p: hashlib.sha256((WORK/p).read_bytes()).hexdigest() for p in set(paths) if p.endswith('.rs') and (WORK/p).is_file()}
commands = [
    ('tests', ['cargo','test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline','--','mcp::tracked_video::tests::','--test-threads=1','--nocapture']),
    ('build', ['cargo','build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline']),
]
report = dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),source=source,commands=commands,results=[])
def save(): (OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'), CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),
    CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', RUST_BACKTRACE='full', MOTION_TRACKED_RPC_DIR=str(OUT))
save()
try:
    for label, command in commands:
        with (OUT/f'{label}.stdout.log').open('wb') as stdout, (OUT/f'{label}.stderr.log').open('wb') as stderr:
            child=subprocess.Popen(command,cwd=WORK,env=env,stdout=stdout,stderr=stderr)
            report.update(phase=label,childPid=child.pid); save()
            code=child.wait()
        report['results'].append(dict(phase=label,exitCode=code)); save()
        assert all(hashlib.sha256((WORK/p).read_bytes()).hexdigest()==h for p,h in source.items()), 'source changed during validation'
        assert code==0,(label,code)
        if label=='tests':
            assert '3 passed; 0 failed' in (OUT/'tests.stdout.log').read_text(encoding='utf-8')
    binary=ROOT/'target/gltf-animation87-contract/debug/motion-studio.exe'
    report.update(status='focused_controls_and_native_binary_build_passed',binarySha256=hashlib.sha256(binary.read_bytes()).hexdigest())
except BaseException as cause:
    report.update(status='failed',failure=repr(cause)); raise
finally:
    report['completedUtc']=datetime.now(timezone.utc).isoformat(); save()

