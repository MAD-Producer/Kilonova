from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, queue, shutil, subprocess, threading, time

ROOT=Path('E:/Dev/aem'); WORK=ROOT/'.worktrees/tracking-import88'
BUILD=ROOT/'artifacts/pr-queue/tracking88-mcp-v3'
OUT=ROOT/'artifacts/pr-queue/tracking88-mcp-wire-v1'
OUT.mkdir(exist_ok=False); (OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
fixture=json.loads((BUILD/'rpc-fixture.json').read_text())
validated=json.loads((BUILD/'exit.json').read_text())
assert validated['status']=='focused_controls_and_native_binary_build_passed'
source=validated['source']
assert all(hashlib.sha256((WORK/p).read_bytes()).hexdigest()==h for p,h in source.items())
binary=ROOT/'target/gltf-animation87-contract/debug/motion-studio.exe'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==validated['binarySha256']
project=OUT/'project'; shutil.copytree(fixture['project'],project)
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(LOCALAPPDATA=str(OUT/'appdata'),CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),
    TEMP=str(ROOT/'target/ci-policy-validation-tmp'),TMP=str(ROOT/'target/ci-policy-validation-tmp'))
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),binarySha256=validated['binarySha256'],source=source,checks=[])
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def checked(name):report['checks'].append(name);save()

class Client:
    def __init__(self,label,read_only=False):
        self.id=0;self.lines=queue.Queue();self.raw=[];self.label=label
        self.stderr=(OUT/f'{label}.stderr.log').open('wb')
        command=[str(binary),'--project',str(project),'--mcp']+(['--mcp-read-only'] if read_only else [])
        self.child=subprocess.Popen(command,cwd=WORK,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr)
        report.update(childPid=self.child.pid,phase=label);save()
        def reader():
            for line in self.child.stdout:
                self.raw.append(line);self.lines.put(line)
            self.lines.put(None)
        self.thread=threading.Thread(target=reader);self.thread.start()
        self.rpc('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='tracked-video-wire-validation',version='1')))
        self.send(dict(jsonrpc='2.0',method='notifications/initialized'))
    def send(self,value):
        self.child.stdin.write((json.dumps(value)+'\n').encode());self.child.stdin.flush()
    def rpc(self,method,params):
        self.id+=1;self.send(dict(jsonrpc='2.0',id=self.id,method=method,params=params))
        line=self.lines.get(timeout=90);assert line is not None,'unexpected server exit'
        value=json.loads(line);assert value['jsonrpc']=='2.0' and value['id']==self.id,value
        assert 'error' not in value,value
        return value['result']
    def tool(self,name,args,error=None):
        value=self.rpc('tools/call',dict(name=name,arguments=args))
        if error is not None:
            assert value['isError'] is True and error in value['content'][0]['text'],value
            return value
        assert value['isError'] is False,value
        assert json.loads(value['content'][0]['text'])==value['structuredContent']
        return value['structuredContent']
    def close(self):
        if not self.child.stdin.closed:self.child.stdin.close()
        code=self.child.wait();self.thread.join();self.stderr.close()
        (OUT/f'{self.label}.stdout.jsonl').write_bytes(b''.join(self.raw))
        assert code==0,(self.label,code)
        for line in self.raw: assert json.loads(line)['jsonrpc']=='2.0'
        return len(self.raw)

save();client=None
try:
    client=Client('edit')
    tools=client.rpc('tools/list',{})['tools'];tool=next(t for t in tools if t['name']=='tracked_video_replacement')
    assert len(tool['inputSchema']['oneOf'])==5;checked('real_stdio_advertises_five_actions')
    before=client.tool('motion_state',{});assert before['project']==fixture['initialProject']
    disk=(project/'project.json').read_bytes()
    def context(args):
        return dict(args,expectedRevision=before['revision'],expectedDocumentGeneration=before['document_generation'])
    prepare=context(fixture['prepare']);finish=context(fixture['finish'])
    bad=dict(prepare,expectedRevision=before['revision']+1)
    client.tool('tracked_video_replacement',bad,error='superseded')
    client.tool('tracked_video_replacement',dict(prepare,extra=True),error='unknown field')
    assert (project/'project.json').read_bytes()==disk;checked('prepare_rejects_stale_context_and_unknown_fields')
    cancel=dict(prepare,requestId='wire-cancel')
    client.tool('tracked_video_replacement',cancel)
    client.tool('tracked_video_replacement',dict(action='release',requestId='wire-cancel'),error='finish or cancel')
    client.tool('tracked_video_replacement',dict(action='cancel',requestId='wire-cancel'))
    assert client.tool('tracked_video_replacement',dict(action='status',requestId='wire-cancel'))['state']=='cancelled'
    client.tool('tracked_video_replacement',dict(action='release',requestId='wire-cancel'))
    assert client.tool('motion_state',{})['project']==before['project'];checked('cancel_release_preserve_author_state')
    client.tool('tracked_video_replacement',prepare)
    began=time.monotonic()
    while True:
        status=client.tool('tracked_video_replacement',dict(action='status',requestId=prepare['requestId']))
        if status['state']=='ready':break
        assert status['state']=='running',status
        assert time.monotonic()-began<30,status
        time.sleep(.05)
    assert (project/'project.json').read_bytes()==disk
    assert client.tool('motion_state',{})['project']==before['project'];checked('native_prepare_ready_does_not_publish_author_state')
    client.tool('tracked_video_replacement',dict(finish,expectedDocumentGeneration=before['document_generation']+1),error='superseded')
    bad=dict(finish,solves=[dict(finish['solves'][0],path=str(BUILD/'old.mstrack'))])
    client.tool('tracked_video_replacement',bad,error='tracking source content differs')
    assert client.tool('motion_state',{})['project']==before['project']
    assert (project/'project.json').read_bytes()==disk;checked('finish_rejects_stale_document_and_wrong_original')
    result=client.tool('tracked_video_replacement',finish)['state']
    assert result['revision']==before['revision']+1
    assert result['project']['video_assets'][0]['id']==before['project']['video_assets'][0]['id']
    assert result['project']['tracking_assets'][0]['id']==before['project']['tracking_assets'][0]['id']
    assert (project/'project.json').read_bytes()!=disk;checked('native_commit_is_one_revision_with_stable_ids_and_saved_project')
    assert client.tool('motion_history',dict(operation='undo'))['project']==before['project']
    assert client.tool('motion_history',dict(operation='redo'))['project']==result['project']
    client.tool('motion_save',{});checked('wire_undo_redo_and_save_preserve_atomic_pair')
    client.tool('tracked_video_replacement',dict(action='release',requestId=prepare['requestId']))
    count=client.close();client=None;report['editReplyCount']=count
    logs=(OUT/'appdata/MotionStudio/logs/motion-studio.log').read_text(encoding='utf-8')
    (OUT/'edit.motion-studio.log').write_text(logs,encoding='utf-8')
    stderr=(OUT/'edit.stderr.log').read_text(encoding='utf-8')
    for signal in ['prepare_tracked_video_replacement','finish_tracked_video_replacement']:
        assert any(' INFO ' in line and 'start #' in line and signal in line for line in logs.splitlines()),signal
    assert 'tracked video replacement failed request=rpc-native' in logs
    assert 'tracked video replacement failed request=rpc-native' in stderr
    assert not any(' ERROR ' in line and 'superseded' in line for line in logs.splitlines())
    checked('default_info_start_error_file_and_stderr_with_pure_jsonrpc_stdout')
    client=Client('readonly-reopen',True)
    reopened=client.tool('motion_state',{});assert reopened['project']==result['project'];checked('new_process_reopens_saved_plate_and_solve')
    for request in [prepare,finish,dict(action='cancel',requestId='x'),dict(action='release',requestId='x')]:
        client.tool('tracked_video_replacement',request,error='disabled')
    client.tool('tracked_video_replacement',dict(action='status',requestId='x'),error='video task missing')
    report['readonlyReplyCount']=client.close();client=None;checked('readonly_wire_denies_every_mutation_and_allows_status_dispatch')
    assert all(hashlib.sha256((WORK/p).read_bytes()).hexdigest()==h for p,h in source.items())
    report['status']='native_stdio_workflow_default_logs_history_and_reopen_passed'
except BaseException as cause:
    report.update(status='failed',failure=repr(cause));raise
finally:
    if client is not None:
        try:client.close()
        except BaseException as cause:report['closureFailure']=repr(cause)
    report['completedUtc']=datetime.now(timezone.utc).isoformat();save()

