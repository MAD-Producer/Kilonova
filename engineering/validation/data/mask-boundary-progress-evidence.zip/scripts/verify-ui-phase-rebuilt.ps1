$ErrorActionPreference = 'Stop'
Set-Location 'E:/Dev/aem/.worktrees/mask-boundary-handles'
. E:/Dev/aem/artifacts/multiple-camera-layers/env.ps1
$env:CARGO_TARGET_DIR = 'E:/Dev/aem/target/host-error-contract-verified'
$env:CARGO_BUILD_JOBS = '1'
$source = 'd47cd6e81dce25a0f92cb1396bcef75153e8236c'
$outputRoot = 'E:/Dev/aem/artifacts/pr-ci-followups/mask-boundary-handles/ui-phase-rebuilt'
$env:MOTION_MASK_BOUNDARY_EVIDENCE = Join-Path $outputRoot 'native'
New-Item -ItemType Directory -Force -Path $outputRoot | Out-Null
$results = [System.Collections.Generic.List[object]]::new()
function Assert-Source {
    if ((& git rev-parse HEAD).Trim() -ne $source) { throw 'source HEAD changed' }
    & git diff --quiet HEAD -- desktop crates
    if ($LASTEXITCODE -ne 0) { throw 'dirty implementation source' }
}
function Run-Check([string]$name, [string[]]$arguments) {
    Assert-Source
    Write-Output "start $name source=$source"
    $timer = [Diagnostics.Stopwatch]::StartNew()
    & cargo @arguments *> (Join-Path $outputRoot "$name.log")
    $status = $LASTEXITCODE
    Assert-Source
    $results.Add(@{ name=$name; source=$source; arguments=$arguments; exit=$status; elapsed_ms=$timer.ElapsedMilliseconds })
    $results | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 (Join-Path $outputRoot 'results.json')
    Write-Output "done $name exit=$status elapsed=$($timer.Elapsed)"
    if ($status -ne 0) { throw "$name failed; preserve its log" }
}
Assert-Source
# Shared targets can retain a different worktree's UI crate. Refresh only this
# tree's root timestamp before building; contents remain the frozen source.
$roots = & rg --files crates desktop -g Cargo.toml; foreach ($manifest in $roots) { $crateRoot = Split-Path $manifest; foreach ($entry in @('src/lib.rs', 'src/main.rs')) { $rootSource = Join-Path $crateRoot $entry; if (Test-Path -LiteralPath $rootSource) { (Get-Item -LiteralPath $rootSource).LastWriteTime = Get-Date } } }
$testArgs = @('test','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline')
Run-Check 'path-controls' ($testArgs + @('panels::path_controls','--','--test-threads=1'))
Run-Check 'native-mask-link' ($testArgs + @('panels::path_controls::mask_boundaries::tests::native::native_mask_feather_link_main_and_float_pixels_and_transactions','--','--exact','--ignored','--nocapture','--test-threads=1'))
Assert-Source
Write-Output "UI link phase passed source=$source; viewer boundary handles remain pending"

