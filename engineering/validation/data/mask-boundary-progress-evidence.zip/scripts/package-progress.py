import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path('E:/Dev/aem/artifacts/pr-ci-followups/mask-boundary-handles')
repo = Path('E:/Dev/aem/.worktrees/mask-boundary-handles')
ui_source = 'd47cd6e81dce25a0f92cb1396bcef75153e8236c'
source = '4135e910e71518c6659e8d04577fbced86a183b7'
def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args])
assert git('rev-parse','HEAD').decode().strip() == source
assert not git('diff', ui_source, '--', 'desktop', 'crates/motion-model', 'crates/motion-core')
assert not git('diff','HEAD','--','desktop','crates')
phases = {}
for directory, count in [('model-phase',2),('ui-phase-rebuilt',2),('boundary-geometry',3)]:
    results = json.loads((root / directory / 'results.json').read_text(encoding='utf-8-sig'))
    assert len(results) == count and all(row['exit'] == 0 for row in results)
    phases[directory] = results
assert 'test result: ok. 3 passed;' in (root/'boundary-geometry/final-boundary-gpu.log').read_text(encoding='utf-8-sig')
payloads = {}
for directory in phases:
    for path in sorted((root / directory).rglob('*')):
        if path.is_file():
            payloads[str(path.relative_to(root)).replace('\\','/')] = path.read_bytes()
for name in ['verify-model-phase.ps1','verify-ui-phase.ps1','verify-ui-phase-rebuilt.ps1',
             'verify-boundary-geometry.ps1','package-progress.py']:
    payloads['scripts/'+name] = (root/name).read_bytes()
payloads['failed/ui-phase/path-controls.log'] = (root/'ui-phase/path-controls.log').read_bytes()
for revision, base in [(ui_source,'72f1037aea7a71047f1920347756d63dedf3e41b'),(source,ui_source)]:
    paths = git('diff','--name-only',base,revision,'--','desktop','crates').decode().splitlines()
    for path in paths:
        payloads[f'source/{revision}/{path}'] = git('show',f'{revision}:{path}')
images = sorted((root/'ui-phase-rebuilt/native').glob('*.png'))
assert len(images) == 24
output = repo/'engineering/validation/mask-feather-link'
output.mkdir(parents=True,exist_ok=True)
selected = []
for state in ['linked','unlinked']:
    path = root/f'ui-phase-rebuilt/native/mask-feather-zh-floating-route-1x-{state}.png'
    target = output/f'zh-floating-{state}.png'
    target.write_bytes(path.read_bytes())
    selected.append({'file':target.name,'original':str(path),'source':ui_source,
                     'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'modified':False})
(output/'screenshots.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
summary = {'ui_source':ui_source,'geometry_source':source,'partial':True,
           'pending':['viewer drawing and gesture input','zoom and parent-transform interaction','independent native owner focus/input'],
           'phases':phases,'final_boundary_gpu':{'source':source,'passed':3,'failed':0},
           'screenshots':len(images)}
manifest = {'summary':summary,'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
                                     for name,data in payloads.items()}}
payloads['manifest.json'] = json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8')
target = repo/'engineering/validation/data/mask-boundary-progress-evidence.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(payloads.items()): archive.writestr(name,data)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(payloads)
    for name,data in payloads.items(): assert archive.read(name) == data
summary['archive'] = {'entries':len(payloads),'bytes':target.stat().st_size,
                      'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
(repo/'engineering/validation/mask-boundary-progress-results.json').write_text(
    json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary['archive']))
