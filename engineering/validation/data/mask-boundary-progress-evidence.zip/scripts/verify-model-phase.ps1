$ErrorActionPreference = 'Stop'
Set-Location 'E:/Dev/aem/.worktrees/mask-boundary-handles'
. E:/Dev/aem/artifacts/multiple-camera-layers/env.ps1
$env:CARGO_TARGET_DIR = 'E:/Dev/aem/target/host-error-contract-verified'
$env:CARGO_BUILD_JOBS = '1'
$source = (& git rev-parse HEAD).Trim()
if (-not $source.StartsWith('d47cd6e8')) { throw "unexpected source $source" }
$outputRoot = 'E:/Dev/aem/artifacts/pr-ci-followups/mask-boundary-handles/model-phase'
New-Item -ItemType Directory -Force -Path $outputRoot | Out-Null
$results = [System.Collections.Generic.List[object]]::new()
function Assert-Source {
    if ((& git rev-parse HEAD).Trim() -ne $source) { throw 'source HEAD changed' }
    & git diff --quiet HEAD -- desktop crates
    if ($LASTEXITCODE -ne 0) { throw 'dirty implementation source' }
}
function Run-Check([string]$name, [string[]]$arguments) {
    Assert-Source
    Write-Output "start $name source=$source"
    $timer = [Diagnostics.Stopwatch]::StartNew()
    & cargo @arguments *> (Join-Path $outputRoot "$name.log")
    $status = $LASTEXITCODE
    Assert-Source
    $results.Add(@{ name=$name; source=$source; arguments=$arguments; exit=$status; elapsed_ms=$timer.ElapsedMilliseconds })
    $results | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 (Join-Path $outputRoot 'results.json')
    Write-Output "done $name exit=$status elapsed=$($timer.Elapsed)"
    if ($status -ne 0) { throw "$name failed; preserve its log" }
}
Run-Check 'model' @('test','-p','motion-model','--locked','--offline')
Run-Check 'layer-masks' @('test','-p','motion-core','--test','layer_masks','--locked','--offline')
Assert-Source
Write-Output "model phase passed source=$source; viewer boundary handles remain pending"
