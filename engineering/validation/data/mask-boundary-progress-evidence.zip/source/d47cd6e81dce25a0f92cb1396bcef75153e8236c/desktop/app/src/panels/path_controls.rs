//! Source path editing. Rendering supplies the matrix; commands own persisted data.
use crate::{
    i18n::{Locale, Text as T},
    panels::Action,
};
use glam::{DMat4, DVec4};
use motion_core::masks::{LayerMask, MaskAction, MaskMode, MaskProperty};
use motion_core::vector::{
    FillRule, LineCap, LineJoin, PathNode, Stroke, VectorAction, VectorContent, VectorPath,
    VectorSource,
};
use motion_core::{Command, Content, Layer, Track};
use motion_ui::{
    input::{Input, Key, MouseButton, Rect},
    paint::{self, PaintList},
    text::TextAtlas,
    theme::Color,
    ui::{self, Align},
};
use serde_json::Value;
pub(in crate::panels) mod groups;
pub(in crate::panels) mod mask_header;
mod mask_inspector;
mod mask_boundaries;
mod mask_keys;
mod mask_path;
mod source_geometry;
mod point_selection;
mod clipboard;
mod context_menu;
mod pen_tools;
#[cfg(test)]
mod property_focus_tests;
#[cfg(test)]
mod clipboard_tests;
pub(in crate::panels) mod timeline;

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Tool {
    #[default]
    Select,
    Pen,
    Mask,
}
impl Tool {
    pub fn title(self) -> T {
        match self {
            Self::Select => T::SelectTool,
            Self::Pen => T::Pen,
            Self::Mask => T::Mask,
        }
    }
}

#[derive(Clone)]
pub struct Projection {
    matrix: DMat4,
    inverse: DMat4,
    pub image: Rect,
}
impl Projection {
    pub fn new(matrix: [f64; 16], view: Rect, size: [f32; 2]) -> Option<Self> {
        if size.iter().any(|v| !v.is_finite() || *v <= 0.)
            || view.width() <= 0.
            || view.height() <= 0.
        {
            return None;
        }
        let scale = (view.width() / size[0]).min(view.height() / size[1]);
        let image = Rect::new(
            view.min[0] + (view.width() - size[0] * scale) * 0.5,
            view.min[1] + (view.height() - size[1] * scale) * 0.5,
            size[0] * scale,
            size[1] * scale,
        );
        let matrix = DMat4::from_cols_array(&matrix);
        if !matrix.is_finite() || matrix.determinant().abs() < 1e-15 {
            return None;
        }
        Some(Self {
            inverse: matrix.inverse(),
            matrix,
            image,
        })
    }
    pub fn screen(&self, p: [f32; 2]) -> Option<[f32; 2]> {
        let v = self.matrix * DVec4::new(p[0] as f64, -(p[1] as f64), 0., 1.);
        if !v.is_finite() || v.w <= 1e-8 {
            return None;
        }
        Some([
            self.image.min[0] + ((v.x / v.w + 1.) * 0.5) as f32 * self.image.width(),
            self.image.min[1] + ((1. - v.y / v.w) * 0.5) as f32 * self.image.height(),
        ])
    }
    pub fn local(&self, p: [f32; 2]) -> Option<[f32; 2]> {
        let x = 2. * ((p[0] - self.image.min[0]) / self.image.width()) as f64 - 1.;
        let y = 1. - 2. * ((p[1] - self.image.min[1]) / self.image.height()) as f64;
        let ray = |z| {
            let p = self.inverse * DVec4::new(x, y, z, 1.);
            (p.is_finite() && p.w.abs() > 1e-10).then(|| p.truncate() / p.w)
        };
        let a = ray(0.)?;
        let b = ray(1.)?;
        let d = b - a;
        if d.z.abs() < 1e-10 {
            return None;
        }
        let p = a + d * (-a.z / d.z);
        let local = [p.x as f32, -p.y as f32];
        if local.iter().any(|v| !v.is_finite() || v.abs() > 32768.) || self.screen(local).is_none()
        {
            None
        } else {
            Some(local)
        }
    }
}
fn composition_size(state: &Value) -> [f32; 2] {
    [
        state["project"]["width"].as_f64().unwrap_or(1920.) as f32,
        state["project"]["height"].as_f64().unwrap_or(1080.) as f32,
    ]
}
pub fn layer_projection(state: &Value, object: u64, view: Rect) -> Option<Projection> {
    let entry = state["source_transforms"]
        .as_array()?
        .iter()
        .find(|v| v["id"].as_u64() == Some(object))?;
    let m = entry["mvp"].as_array()?;
    if m.len() != 16 {
        return None;
    }
    let mut matrix = [0.; 16];
    for (a, b) in matrix.iter_mut().zip(m) {
        *a = b.as_f64()?;
    }
    Projection::new(matrix, view, composition_size(state))
}
fn identity_projection(state: &Value, view: Rect) -> Option<Projection> {
    let [w, h] = composition_size(state);
    let m = DMat4::from_cols_array(&[
        2. / w as f64,
        0.,
        0.,
        0.,
        0.,
        2. / h as f64,
        0.,
        0.,
        0.,
        0.,
        1.,
        0.,
        0.,
        0.,
        0.,
        1.,
    ]);
    Projection::new(m.to_cols_array(), view, [w, h])
}
pub fn new_vector(path: VectorPath) -> VectorContent {
    VectorContent {
        source: VectorSource::Paths {
            paths: vec![path.clone()],
        },
        fill: path.closed.then(|| Track::constant([0.16, 0.55, 0.94, 1.])),
        fill_rule: FillRule::NonZero,
        trim: None,
        stroke: Some(Stroke {
            color: Track::constant([0.16, 0.55, 0.94, 1.]),
            width: Track::constant(3.),
            cap: LineCap::Round,
            join: LineJoin::Round,
            miter_limit: 4.,
            dashes: None,
        }),
    }
}
#[derive(Clone, Debug)]
enum Target {
    New,
    Vector { object: u64 },
    Mask { object: u64, mask: u64 },
}
struct Draft {
    target: Target,
    projection: Projection,
    offset: [f32; 2],
    path: VectorPath,
    base_paths: Vec<VectorPath>,
    revision: u64,
    frame: f64,
    selection: Option<u64>,
    root: String,
    placing: bool,
}

// Alt leaves the opposite handle unchanged, for both new and existing nodes.
fn move_handle(geometry: &mut [f32; 6], axis: usize, delta: [f32; 2], independent: bool) {
    geometry[axis] = delta[0];
    geometry[axis + 1] = delta[1];
    if !independent {
        let other = if axis == 2 { 4 } else { 2 };
        geometry[other] = -delta[0];
        geometry[other + 1] = -delta[1];
    }
}
struct Drag {
    target: Target,
    path: u64,
    node: u64,
    axis: usize,
    value: [f32; 6],
    last_geometry: [f32; 6],
    start: [f32; 2],
    projection: Projection,
    offset: [f32; 2],
    animated: bool,
    frame: u32,
    begun: bool,
    item: Option<u64>,
    bounds: Option<source_geometry::Bounds>,
    root: String,
    composition: String,
}
#[derive(Default)]
pub struct Controls {
    context_menu: Option<context_menu::Menu>,
    context_owner: Option<motion_ui::dock::Panel>,
    #[cfg(test)]
    pub(crate) context_rows: Vec<(String, Rect, bool)>,
    geometry_failures: motion_render::observability::FailureCounter,
    pub(crate) selection_probe: crate::panels::property_focus::HitProbe,
    pub tool: Tool,
    pub mask: Option<u64>,
    draft: Option<Draft>,
    drag: Option<Drag>,
    point_selection: point_selection::Selection,
    pen_tools: pen_tools::Controls,
    selected: Option<(u64, u64)>,
    selected_item: Option<u64>,
    focus: bool,
    pub notice: Option<String>,
    parameter: Option<Parameter>,
    parameter_context: Option<(String, String, u32)>,
    inspector_context: Option<(String, String, u64, motion_ui::dock::Panel)>,
    inspector_cache: Option<InspectorLayer>,
    inspector_add: Option<(motion_ui::dock::Panel, Rect)>,
    inspector_overlays: Option<PaintList>,
    #[cfg(test)]
    pub(in crate::panels) inspector_modes: std::collections::HashMap<(u64, u64), Rect>,
    #[cfg(test)]
    feather_link_rects: std::collections::HashMap<(u64, u64), Rect>,
    add_mask_menu: motion_ui::widgets::Dropdown,
    timeline_add_mask_menu: Option<mask_header::AddMenu>,
    mode_dropdowns: std::collections::HashMap<(u64, u64), motion_ui::widgets::Dropdown>,
    collapsed_mask_cards: std::collections::HashSet<(u64, u64)>,
    pub masks_open: bool,
    keys: mask_keys::Controls,
    pub(super) groups: groups::Controls,
}
struct InspectorLayer {
    context: (String, String, u64, u64),
    layer: std::sync::Arc<Layer>,
}
struct Parameter {
    host: motion_ui::dock::Panel,
    object: u64,
    mask: u64,
    property: MaskProperty,
    axis: usize,
    values: Vec<f32>,
    text: String,
    replace: bool,
    editor: motion_ui::widgets::TextEditor,
    rect: Rect,
    start: Option<f32>,
    begun: bool,
    last_value: f32,
    linked: bool,
    range: [f32; 2],
}
fn label(list: &mut PaintList, atlas: &mut TextAtlas, r: Rect, text: &str, color: Color) {
    ui::text(list, atlas, r, text, color, Align::Left);
}
fn click(input: &Input, r: Rect) -> bool {
    input
        .pressed
        .is_some_and(|(b, p)| b == MouseButton::Left && r.contains(p))
}
fn distance(a: [f32; 2], b: [f32; 2]) -> f32 {
    ((a[0] - b[0]).powi(2) + (a[1] - b[1]).powi(2)).sqrt()
}
/// Screen-space grip radius shared by picking and hover, so the highlight never
/// promises a grab that the press would miss.
const HIT_RADIUS: f32 = 7.;
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[cfg(test)]
struct HoverTarget {
    path: u64,
    node: usize,
    handle: Option<usize>,
}
/// Nearest visible node or Bezier handle under the pointer, mirroring the paint
/// rules: handles are only reachable for the selected node (or for all nodes
/// while nothing is selected).
#[cfg(test)]
fn hovered_target(
    projection: &Projection,
    paths: &[(u64, &[[f32; 6]])],
    offset: [f32; 2],
    mouse: [f32; 2],
    selected: Option<u64>,
) -> Option<HoverTarget> {
    let sampled: Vec<_> = paths.iter().map(|(id,nodes)| serde_json::json!({
        "id":id,"nodes":nodes.iter().enumerate().map(|(i,g)|
            serde_json::json!({"id":i+1,"geometry":g})).collect::<Vec<_>>()
    })).collect();
    let mut selection=point_selection::Selection::default();
    if let Some(node)=selected {
        for (path,_) in paths {
            selection.points.insert(point_selection::Point {mask:None,item:None,path:*path,node});
        }
    }
    selection.hovered(&sampled,projection,offset,mouse,None)
        .map(|(point,node,handle)|HoverTarget {path:point.path,node,handle})
}
fn layer(state: &Value, id: u64) -> Option<Layer> {
    observe!("path.layer", serde_json::from_value(
        state["project"]["layers"]
            .as_array()?
            .iter()
            .find(|v| v["id"].as_u64() == Some(id))?
            .clone(),
    ), "object={id} fallback=no_layer")
    .ok()
}
fn icons_pen_button(
    list: &mut PaintList,
    rect: Rect,
    input: &Input,
    enabled: bool,
    active: bool,
) -> bool {
    let styles = list.styles();
    let mut states = motion_ui::style::States::default();
    if !enabled {
        states = states.with(motion_ui::style::State::Disabled);
    }
    if active {
        states = states.with(motion_ui::style::State::Selected);
    }
    motion_ui::icons::button(
        list,
        rect,
        motion_ui::icons::Icon::Pen,
        input,
        styles.as_ref(),
        states,
    )
    .clicked
}
fn geometry(node: &Value) -> Option<[f32; 6]> {
    let a = node["geometry"].as_array()?;
    if a.len() != 6 {
        return None;
    }
    let mut g = [0.; 6];
    for (x, v) in g.iter_mut().zip(a) {
        *x = v.as_f64()? as f32;
    }
    Some(g)
}
impl Controls {
    pub(super) fn text_menu(&mut self, request: &mut super::text_menu::Request<'_>) {
        if let Some(field) = self.parameter.as_mut().filter(|field| field.start.is_none()) {
            request.value(&mut field.editor, &mut field.text, &mut field.replace);
        }
    }
    pub(in crate::panels) fn reveal_masks(&mut self, object: u64) {
        self.masks_open = true;
        self.collapsed_mask_cards.retain(|(id,_)| *id != object);
    }
    pub(super) fn mask_key_shortcuts(
        &mut self,
        state: &Value,
        selected: Option<u64>,
        input: &Input,
        out: &mut Vec<Action>,
    ) -> bool {
        self.groups.keys.shortcuts(state, selected, input, out)
            || self.keys.delete_selected(state, selected, input, out)
            || self.keys.navigate(state, selected, input, out)
    }
    pub fn editing(&self) -> bool {
        self.context_menu.is_some()
            || self.draft.is_some()
            || self.drag.is_some()
            || self.point_selection.editing()
            || self.pen_tools.editing()
            || self.parameter.is_some()
            || self.keys.editing()
            || self.groups.editing()
            || self.add_mask_menu.open
            || self.timeline_add_mask_menu.is_some()
            || self.mode_dropdowns.values().any(|d| d.open)
    }
    pub(crate) fn gesture_active(&self) -> bool {
        self.drag.as_ref().is_some_and(|d| d.begun)
            || self.point_selection.begun()
            || self.parameter.as_ref().is_some_and(|p| p.begun)
    }
    pub(crate) fn nudge(
        &mut self,
        state: &Value,
        selected: Option<u64>,
        delta: [f32; 2],
    ) -> Option<motion_core::Result<Vec<Command>>> {
        if self.point_selection.points.is_empty() || self.tool == Tool::Select {
            return None;
        }
        Some((|| {
            let object = selected
                .ok_or_else(|| motion_core::Error::Invalid("path nudge layer missing".into()))?;
            let layer = layer(state, object)
                .ok_or_else(|| motion_core::Error::Invalid("path nudge source missing".into()))?;
            if layer.locked {
                return Ok(vec![]);
            }
            let [w, h] = composition_size(state);
            let base =
                layer_projection(state, object, Rect::new(0., 0., w, h)).ok_or_else(|| {
                    motion_core::Error::Invalid("path nudge projection unavailable".into())
                })?;
            let paths = if self.tool == Tool::Mask {
                state["mask_layers"]
                    .as_array()
                    .into_iter()
                    .flatten()
                    .find(|v| v["id"].as_u64() == Some(object))
                    .and_then(|v| v["masks"].as_array())
                    .into_iter()
                    .flatten()
                    .map(|m| {
                        let mut p = m["path"].clone();
                        p["mask"] = m["id"].clone();
                        p
                    })
                    .collect()
            } else {
                source_geometry::paths(&layer, state["frame"].as_f64().unwrap_or(0.))?
            };
            self.point_selection.nudge(
                &layer,
                &paths,
                &base,
                state["frame"].as_f64().unwrap_or(0.).floor() as u32,
                delta,
            )
        })())
    }
    pub fn wants_keyboard(&self) -> bool {
        self.editing() || (self.tool != Tool::Select && self.focus)
    }
    pub fn cancel(&mut self) -> bool {
        self.context_menu = None;
        let drag = self.drag.take().is_some_and(|d| d.begun);
        let points = self.point_selection.cancel();
        let param = self.parameter.take().is_some_and(|p| p.begun);
        self.draft = None;
        self.pen_tools.cancel();
        self.parameter_context = None;
        self.focus = false;
        self.add_mask_menu.open = false;
        self.timeline_add_mask_menu = None;
        for dropdown in self.mode_dropdowns.values_mut() {
            dropdown.open = false;
        }
        let keys = self.keys.cancel();
        let group = self.groups.cancel();
        drag || points || param || keys || group
    }
    pub fn choose(&mut self, tool: Tool, out: &mut Vec<Action>) {
        if self.cancel() {
            out.push(Action::History(4));
        }
        self.tool = tool;
        self.pen_tools.mode = pen_tools::Mode::Draw;
        self.selected = None;
        self.selected_item = None;
        self.point_selection.clear();
        self.mask = None;
        self.notice = None;
        if tool == Tool::Mask {
            self.masks_open = true;
        }
    }
    fn finish(&mut self, closed: bool, out: &mut Vec<Action>) {
        let Some(mut draft) = self.draft.take() else {
            return;
        };
        if draft.path.nodes.len() < 2
            || (matches!(draft.target, Target::Mask { .. }) && draft.path.nodes.len() < 3)
        {
            self.draft = Some(draft);
            return;
        }
        draft.path.closed = closed || matches!(draft.target, Target::Mask { .. });
        match draft.target {
            Target::New => out.push(Action::AddPath(draft.path)),
            Target::Vector { object } => {
                draft.base_paths.push(draft.path);
                out.push(Action::Edit(Command::Vector {
                    object,
                    action: VectorAction::SetPaths {
                        paths: draft.base_paths,
                    },
                }));
            }
            Target::Mask { object, mask } => {
                let mut m = LayerMask::new(mask, draft.path);
                m.name = format!("Mask {mask}");
                out.push(Action::Edit(Command::Mask {
                    object,
                    action: MaskAction::Add { mask: m },
                }));
                self.mask = Some(mask);
            }
        }
    }
    fn begin(&mut self, state: &Value, selected: Option<u64>, view: Rect) -> Option<()> {
        let mut target = Target::New;
        let mut offset = [0., 0.];
        let mut base_paths = vec![];
        let mut id = 1;
        let projection = if self.tool == Tool::Mask {
            let selected = observe!(
                "path.begin_selection",
                selected.ok_or("no selected layer"),
                "tool=mask"
            )
            .ok()?;
            let l = observe!(
                "path.begin_layer",
                layer(state, selected).ok_or("selected layer missing or malformed"),
                "object={selected} tool=mask"
            )
            .ok()?;
            if l.locked
                || matches!(
                    l.content,
                    Content::Null | Content::Camera { .. } | Content::Audio { .. } | Content::Adjustment
                )
            {
                log::debug!(
                    "path begin refused object={} reason=locked_or_nonvisual_layer",
                    l.id
                );
                return None;
            }
            let mask = l
                .masks
                .iter()
                .map(|m| m.id)
                .max()
                .unwrap_or(0)
                .checked_add(1)
                .or_else(|| {
                    log::error!("path begin refused reason=id_overflow selected={selected:?}");
                    None
                })?;
            target = Target::Mask { object: l.id, mask };
            offset = l.size.map(|v| v * 0.5);
            observe!(
                "path.begin_projection",
                layer_projection(state, l.id, view).ok_or("layer projection unavailable"),
                "object={} view={view:?}",
                l.id
            )
            .ok()?
        } else if let Some(l) = selected
            .and_then(|id| layer(state, id))
            .filter(|l| !l.locked)
        {
            if let Content::Vector {
                vector:
                    VectorContent {
                        source: VectorSource::Paths { paths },
                        ..
                    },
            } = l.content
            {
                id = paths
                    .iter()
                    .map(|p| p.id)
                    .max()
                    .unwrap_or(0)
                    .checked_add(1)
                    .or_else(|| {
                        log::error!("path begin refused reason=id_overflow selected={selected:?}");
                        None
                    })?;
                target = Target::Vector { object: l.id };
                base_paths = paths;
                observe!(
                    "path.begin_projection",
                    layer_projection(state, l.id, view).ok_or("layer projection unavailable"),
                    "object={} view={view:?}",
                    l.id
                )
                .ok()?
            } else {
                observe!(
                    "path.begin_identity",
                    identity_projection(state, view).ok_or("composition projection unavailable"),
                    "selected={selected:?} view={view:?}"
                )
                .ok()?
            }
        } else {
            observe!(
                "path.begin_identity",
                identity_projection(state, view).ok_or("composition projection unavailable"),
                "selected={selected:?} view={view:?}"
            )
            .ok()?
        };
        self.draft = Some(Draft {
            target,
            projection,
            offset,
            path: VectorPath {
                id,
                closed: false,
                nodes: vec![],
            },
            base_paths,
            revision: state["revision"].as_u64().unwrap_or(0),
            frame: state["frame"].as_f64().unwrap_or(0.),
            selection: selected,
            root: state["root"].as_str().unwrap_or("").into(),
            placing: false,
        });
        Some(())
    }
    #[cfg(test)]
    pub fn draw(
        &mut self,
        list: &mut PaintList,
        atlas: &mut TextAtlas,
        view: Rect,
        state: &Value,
        selected: Option<u64>,
        input: &Input,
        locale: Locale,
        out: &mut Vec<Action>,
    ) -> bool {
        self.draw_in_viewport(list, atlas, view, view, state, selected, input, locale, out)
    }
    pub fn draw_in_viewport(
        &mut self,
        list: &mut PaintList,
        atlas: &mut TextAtlas,
        clip: Rect,
        view: Rect,
        state: &Value,
        selected: Option<u64>,
        input: &Input,
        locale: Locale,
        out: &mut Vec<Action>,
    ) -> bool {
        self.draw_with_handles(list,atlas,clip,view,state,selected,input,locale,true,out)
    }
    pub(super) fn draw_with_handles(
        &mut self, list:&mut PaintList, atlas:&mut TextAtlas, clip:Rect, view:Rect,
        state:&Value, selected:Option<u64>, input:&Input, locale:Locale, handles_visible:bool, out:&mut Vec<Action>,
    ) -> bool {
        let styles = list.styles();
        let colors = styles.colors();

        if self.tool == Tool::Select {
            return false;
        }
        let mut tool_overlay = list.child();
        let tool_owned = self.draw_pen_tools(&mut tool_overlay, atlas, clip, input, locale, out);
        let neutral = Input { mouse: input.mouse, ..Default::default() };
        let input = if tool_owned { &neutral } else { input };
        if input.pressed.is_some_and(|(_, p)| clip.contains(p)) {
            self.focus = true;
        } else if input.pressed.is_some() && !self.editing() {
            self.focus = false;
        }
        if self.draft.as_ref().is_some_and(|d| {
            d.revision != state["revision"].as_u64().unwrap_or(0)
                || d.frame != state["frame"].as_f64().unwrap_or(0.)
                || d.selection != selected
                || d.root != state["root"].as_str().unwrap_or("")
        }) {
            self.draft = None;
            self.notice = Some(
                if locale == Locale::Zh {
                    "工程或时间已变化，绘制已取消"
                } else {
                    "Project or time changed; drawing cancelled"
                }
                .into(),
            );
        }
        let target = selected.and_then(|id| layer(state, id));
        let projection = selected.and_then(|id| layer_projection(state, id, view));
        let offset = if self.tool == Tool::Mask {
            target
                .as_ref()
                .map_or([0., 0.], |l| l.size.map(|v| v * 0.5))
        } else {
            [0., 0.]
        };
        let sampled = if self.tool == Tool::Mask {
            self.geometry_failures.success();
            state["mask_layers"]
                .as_array()
                .and_then(|v| v.iter().find(|v| v["id"].as_u64() == selected))
                .and_then(|v| v["masks"].as_array())
                .filter(|_| self.mask.is_some())
                .map(|masks| masks.iter().map(|mask| {
                    let mut path = mask["path"].clone();
                    path["mask"] = mask["id"].clone();
                    path
                }).collect())
                .unwrap_or_default()
        } else {
            match target.as_ref().map(|layer| (layer.id,
                source_geometry::paths(layer,state["frame"].as_f64().unwrap_or(0.)))) {
                Some((_,Ok(paths))) => {self.geometry_failures.success();paths},
                Some((object,Err(error))) => {
                    self.geometry_failures.failure("path.source_geometry",
                        format_args!("object={object} frame={} phase=authored_grips reason={error}",state["frame"]));
                    vec![]
                },
                None => {self.geometry_failures.success();vec![]},
            }
        };
        if self.point_selection.sync(state, selected, self.tool == Tool::Mask, &sampled, out) {
            self.selected = None;
            self.selected_item = None;
        }
        // Keep source/selection validation, but never pick hidden authored grips.
        // The pen's own local draft remains available for new authoring.
        let sampled = if handles_visible {sampled} else {vec![]};
        let context_owned = self.open_context_menu(clip, &sampled, projection.as_ref(), offset, state, selected, input);
        let context_neutral = Input { mouse: input.mouse, ..Default::default() };
        let input = if context_owned { &context_neutral } else { input };
        let pen_owned = self.pen_tool_input(clip, &sampled, projection.as_ref(), offset,
            target.as_ref(), state, selected, input, locale, out)
            || !handles_visible && self.draft.is_none() && input.modifiers.control;
        if self.focus && self.parameter.is_none() && !input.composing {
            for (key, mods) in &input.keys {
                if mods.control && *key == Key::S {
                    self.finish(
                        self.draft.as_ref().is_some_and(|d| d.path.nodes.len() >= 3),
                        out,
                    );
                    if self.draft.is_none() {
                        out.push(Action::Save);
                    }
                }
                if mods.control && matches!(*key, Key::Z | Key::Y) {
                    if let Some(d) = self.draft.as_mut() {
                        d.path.nodes.pop();
                        d.placing = false;
                    } else if self.drag.is_none() && !self.point_selection.editing() {
                        out.push(Action::History(if *key == Key::Y || mods.shift {
                            1
                        } else {
                            0
                        }));
                    }
                }
            }
            if input.keys.iter().any(|(k, _)| *k == Key::Enter) {
                self.finish(
                    self.draft.as_ref().is_some_and(|d| d.path.nodes.len() >= 3),
                    out,
                );
            }
            if input
                .keys
                .iter()
                .any(|(k, _)| *k == Key::Backspace || *k == Key::Delete)
            {
                if let Some(d) = self.draft.as_mut() {
                    d.path.nodes.pop();
                    d.placing = false;
                } else if self.drag.is_none() && !self.point_selection.editing()
                    && !self.point_selection.points.is_empty() {
                    if let Some(l) = target.as_ref().filter(|l| !l.locked && state["observing"] != true) {
                        match self.point_selection.delete(l) {
                            Ok(commands) if !commands.is_empty() => {
                                out.push(Action::EditBatch(commands));
                                self.point_selection.clear();
                                self.selected = None;
                            }
                            Ok(_) => {}
                            Err(error) => self.point_selection.report(l.id, "delete", &error),
                        }
                    }
                } else if self.drag.is_none() && !self.point_selection.editing() {
                    if let (Some(l), Some((path, node))) = (target.as_ref(), self.selected) {
                        self.remove_node(l, path, node, out);
                        self.selected = None;
                    }
                }
            }
        }
        let selection_owned = self.point_selection.drive(&sampled, projection.as_ref(), offset,
            target.as_ref(), state, input, out);
        let mut hits = vec![];
        if let Some(p) = &projection {
            for path in &sampled {
                let Some(p) = source_geometry::projection(p,path) else {continue};
                for n in path["nodes"].as_array().into_iter().flatten() {
                    if let Some(g) = geometry(n) {
                        let pid = path["id"].as_u64().unwrap_or(1);
                        let nid = n["id"].as_u64().unwrap_or(1);
                        for axis in [0, 2, 4] {
                            if axis != 0 && (g[axis].abs()+g[axis+1].abs()<0.01 || path["bounds_size"].is_array()
                                || !(self.point_selection.points.contains(&point_selection::Point::new(path,nid))
                                    || self.selected.is_none() && self.point_selection.points.is_empty()
                                    || self.selected == Some((pid,nid)) && self.selected_item==path["item"].as_u64()
                                        && (self.tool!=Tool::Mask || self.mask==path["mask"].as_u64()))) {
                                continue;
                            }
                            let local = if axis == 0 {
                                [g[0] - offset[0], g[1] - offset[1]]
                            } else {
                                [g[0] + g[axis] - offset[0], g[1] + g[axis + 1] - offset[1]]
                            };
                            if let Some(screen) = p.screen(local) {
                                let point = input.pressed.map_or(input.mouse, |(_, point)| point);
                                hits.push((distance(point, screen), pid, nid, axis, g,
                                    path, n["animated"].as_bool().unwrap_or(false)));
                            }
                        }
                    }
                }
            }
        }
        if let Some((MouseButton::Left, point)) = input.pressed.filter(|(_, p)| clip.contains(*p)
            && !selection_owned && !pen_owned && self.drag.is_none() && state["observing"] != true) {
            let hit = hits
                .into_iter()
                .filter(|h| h.0 <= HIT_RADIUS)
                .min_by(|a, b| a.0.total_cmp(&b.0))
                .and_then(|(distance,path,node,axis,value,source,animated)| {
                    let p=source_geometry::projection(projection.as_ref()?,source)?;
                    Some((distance,path,node,axis,value,p,source["item"].as_u64(),source["mask"].as_u64(),
                        source_geometry::Bounds::from_path(source,node),animated))
                });
            if let (Some((_, path, node, axis, value, p, item, mask, bounds, animated)), Some(l)) = (
                hit,
                target.as_ref().filter(|l| !l.locked),
            ) {
                if let Some(start) = p.local(point) {
                    let point_key = point_selection::Point {mask,item,path,node};
                    if axis == 0 && bounds.is_some() { self.point_selection.clear(); }
                    if axis != 0 { self.point_selection.points.insert(point_key); }
                    let keep = axis != 0 || bounds.is_some()
                        || self.point_selection.click(point_key,input.modifiers);
                    let multiple = axis == 0 && bounds.is_none() && keep
                        && self.point_selection.points.len() > 1;
                    if self.tool == Tool::Mask { self.mask = mask; }
                    let t = if self.tool == Tool::Mask {
                        Target::Mask {
                            object: l.id,
                            mask: mask.expect("sampled mask carries its owner"),
                        }
                    } else {
                        Target::Vector { object: l.id }
                    };
                    if multiple {
                        if let Some(base) = projection.as_ref() {
                            if let Err(error) = self.point_selection.start_move(&sampled,base,offset,point,
                                state["frame"].as_f64().unwrap_or(0.).floor() as u32) {
                                self.point_selection.report(l.id,"node_press",&error);
                            }
                        }
                    } else if keep {
                    self.drag = Some(Drag {
                        target: t,
                        path,
                        node,
                        axis,
                        value,
                        last_geometry: value,
                        start,
                        projection: p,
                        offset,
                        animated,
                        frame: state["frame"].as_f64().unwrap_or(0.).floor() as u32,
                        begun: false,
                        item,
                        bounds,
                        root: state["root"].as_str().unwrap_or("").into(),
                        composition: state["composition"].as_str().unwrap_or("").into(),
                    });
                    }
                    self.selected = keep.then_some((path, node));
                    self.selected_item = keep.then_some(item).flatten();
                }
            } else {
                self.selected = None;
                self.selected_item = None;
                let handled = handles_visible && self.draft.is_none() && target.as_ref().is_some_and(|l| !l.locked)
                    && projection.as_ref().is_some_and(|base| self.point_selection.blank_press(
                        &sampled,base,offset,point,input,state["frame"].as_f64().unwrap_or(0.).floor() as u32,
                        selected.unwrap_or(0)));
                if handled {
                    self.selected = None;
                    self.selected_item = None;
                } else if target.as_ref().is_some_and(|l| {
                    matches!(
                        &l.content,
                        Content::Vector {
                            vector: VectorContent {
                                source: VectorSource::Shape { .. },
                                ..
                            }
                        }
                    )
                }) && self.tool == Tool::Pen
                {
                    self.notice=Some(if locale==Locale::Zh {"拖动角点调整宽高；自由编辑节点请先在属性中转换为路径"}
                        else {"Drag a corner to resize; use Convert to path in Properties for free node editing"}.into());
                } else {
                    if self.draft.is_none() {
                        if self.begin(state, selected, view).is_none() {
                            log::debug!("path begin produced no draft selected={selected:?} tool={:?} revision={}", self.tool, state["revision"]);
                        }
                        if self.draft.is_some() {
                            out.push(Action::Seek(state["frame"].as_f64().unwrap_or(0.)));
                        }
                    }
                    if let Some(d) = self.draft.as_mut() {
                        if let Some(local) = d.projection.local(point) {
                            let closes = handles_visible && d.path.nodes.len() >= 3
                                && d.path
                                    .nodes
                                    .first()
                                    .and_then(|n| {
                                        d.projection.screen([
                                            n.geometry.value[0] - d.offset[0],
                                            n.geometry.value[1] - d.offset[1],
                                        ])
                                    })
                                    .is_some_and(|p| distance(p, point) < 8.);
                            if closes {
                                self.finish(true, out);
                            } else if d.path.nodes.len() < 2048 {
                                let id = d.path.nodes.last().map_or(1, |n| n.id + 1);
                                d.path.nodes.push(PathNode {
                                    id,
                                    geometry: Track::constant([
                                        local[0] + d.offset[0],
                                        local[1] + d.offset[1],
                                        0.,
                                        0.,
                                        0.,
                                        0.,
                                    ]),
                                });
                                d.placing = true;
                            }
                        }
                    } else {
                        self.notice=Some(if locale==Locale::Zh {"请选中可编辑的可视图层；调整图层暂不支持源蒙版"}else{"Select an editable visual layer; source masks exclude adjustment layers"}.into());
                    }
                }
            }
        }
        if let Some(mut drag) = self.drag.take() {
            let released = input.released.filter(|(b, _)| *b == MouseButton::Left);
            let release = released.is_some();
            let object = match drag.target {
                Target::Vector { object } | Target::Mask { object, .. } => object,
                Target::New => unreachable!(),
            };
            let cancelled = input.focus_lost
                || input.keys.iter().any(|(k, _)| *k == Key::Escape)
                || selected != Some(object)
                || target.as_ref().is_none_or(|l| l.locked)
                || state["observing"] == true
                || drag.frame != state["frame"].as_f64().unwrap_or(0.).floor() as u32
                || drag.root != state["root"].as_str().unwrap_or("")
                || drag.composition != state["composition"].as_str().unwrap_or("");
            let lost_button = !input.dragging()
                && !release
                && !input.pressed.is_some_and(|(b, _)| b == MouseButton::Left);
            // Release can wait behind an engine reply while later motion is
            // coalesced. Its own point, not the newest mouse position, ends it.
            let point = released.map_or(input.mouse, |(_, point)| point);
            if !cancelled && !lost_button {
                if let Some(p) = drag.projection.local(point) {
                    if (input.dragging() || release) && (distance(p, drag.start) > 0.1 || drag.begun) {
                        if !drag.begun {
                            out.push(Action::History(2));
                            drag.begun = true;
                        }
                        let mut g = drag.value;
                        if drag.axis == 0 {
                            g[0] += p[0] - drag.start[0];
                            g[1] += p[1] - drag.start[1];
                        } else {
                            let delta = [p[0] + drag.offset[0] - g[0], p[1] + drag.offset[1] - g[1]];
                            move_handle(&mut g, drag.axis, delta, input.modifiers.alt);
                        }
                        if g != drag.last_geometry
                            && g.iter().all(|v| v.is_finite() && v.abs() <= 32768.)
                        {
                            if let (Target::Vector { object }, Some(bounds)) =
                                (&drag.target, &drag.bounds)
                            {
                                if let Some(edits) = bounds.edit(
                                    *object,
                                    drag.item,
                                    drag.frame,
                                    [p[0] - drag.start[0], p[1] - drag.start[1]],
                                ) {
                                    drag.last_geometry = g;
                                    out.extend(edits);
                                }
                            } else {
                                let edit = match drag.target {
                                    Target::Vector { object } => {
                                        let action = if let Some(item) = drag.item {
                                            VectorAction::SetGroupParameter {
                                                item,
                                                parameter: format!("node:{}:{}", drag.path, drag.node),
                                                frame: drag.frame,
                                                value: motion_core::vector::groups::ParameterValue::Geometry(g),
                                                animated: None,
                                            }
                                        } else {
                                            VectorAction::SetNode {
                                                path: drag.path,
                                                node: drag.node,
                                                frame: drag.frame,
                                                value: g,
                                                animated: drag.animated,
                                            }
                                        };
                                        Some(Action::Edit(Command::Vector { object, action }))
                                    }
                                    Target::Mask { object, mask } => target.as_ref().and_then(|layer| {
                                        let source = layer.masks.iter().find(|m| m.id == mask)?;
                                        mask_path::node_command(
                                            object, source,
                                            layer.timeline.map_or(0, |t| t.offset_frame),
                                            drag.node, drag.frame, g,
                                        )
                                    }),
                                    Target::New => unreachable!(),
                                };
                                if let Some(edit) = edit {
                                    drag.last_geometry = g;
                                    out.push(edit);
                                }
                            }
                        }
                    }
                }
            }
            if cancelled || lost_button || release {
                if drag.begun {
                    out.push(Action::History(if cancelled { 4 } else { 3 }));
                }
            } else {
                self.drag = Some(drag);
            }
        }
        if let Some(d) = self.draft.as_mut() {
            let released = input.released.filter(|(b, _)| *b == MouseButton::Left);
            if d.placing && !input.focus_lost && (input.dragging() || released.is_some()) {
                if let (Some(local), Some(n)) =
                    (d.projection.local(released.map_or(input.mouse, |(_, point)| point)), d.path.nodes.last_mut())
                {
                    let g = &mut n.geometry.value;
                    let dx = local[0] + d.offset[0] - g[0];
                    let dy = local[1] + d.offset[1] - g[1];
                    if dx.abs() <= 32768. && dy.abs() <= 32768. {
                        move_handle(g, 4, [dx, dy], input.modifiers.alt);
                    }
                }
            }
            if released.is_some() || input.focus_lost || !input.dragging() {
                d.placing = false;
            }
        }
        let hovered = projection.as_ref().and_then(|p| {
            // A drag keeps its own node visible; hover only decorates idle nodes.
            if self.drag.is_some() || self.point_selection.editing()
                || !view.contains(input.mouse)
                || state["observing"] == true
                || target.as_ref().is_none_or(|layer| layer.locked)
            {
                return None;
            }
            self.point_selection.hovered(&sampled,p,offset,input.mouse,self.selected.map(|(path,node)|
                point_selection::Point {path,node,item:self.selected_item,
                    mask:if self.tool==Tool::Mask {self.mask}else{None}}))
        });
        if let Some(p) = projection {
            let base = p.clone();
            for path in &sampled {
                let Some(p)=source_geometry::projection(&p,path) else {continue};
                let id = path["id"].as_u64().unwrap_or(1);
                let nodes: Vec<_> = path["nodes"]
                    .as_array()
                    .into_iter()
                    .flatten()
                    .filter_map(geometry)
                    .collect();
                // Node IDs survive deletion/reordering; they are not array indices.
                let selected = self.selected.filter(|(id, _)| Some(*id) == path["id"].as_u64() && self.selected_item==path["item"].as_u64()
                    && (self.tool!=Tool::Mask || self.mask==path["mask"].as_u64()))
                    .and_then(|(_, node)| path["nodes"].as_array()?.iter()
                        .filter(|n| geometry(n).is_some()).position(|n| n["id"].as_u64() == Some(node)))
                    .filter(|_| self.point_selection.points.is_empty())
                    .or_else(|| (!self.point_selection.points.is_empty()).then_some(usize::MAX));
                paint_path(
                    list,
                    &p,
                    &nodes,
                    path["closed"].as_bool().unwrap_or(false),
                    offset,
                    selected,
                    self.tool == Tool::Mask,
                    colors.ACCENT,
                    hovered
                        .filter(|(key,_,_)| key.path == id && key.item==path["item"].as_u64()
                            && key.mask==path["mask"].as_u64())
                        .map(|(_,node,handle)| (node,handle)),
                );
            }
            self.point_selection.paint(list,&sampled,&base,offset,hovered);
        }
        if let Some(d) = &self.draft {
            let draft_color=list.styles().color("path.draft");
            let nodes: Vec<_> = d.path.nodes.iter().map(|n| n.geometry.value).collect();
            if handles_visible {
            paint_path(
                list,
                &d.projection,
                &nodes,
                false,
                d.offset,
                None,
                true,
                draft_color,
                None,
            );
            } else {
                paint_path_curve(list,&d.projection,&nodes,false,d.offset,draft_color);
            }
        }
        let padding = styles.metric("padding.panel", 8.);
        label(
            list,
            atlas,
            Rect::new(clip.min[0]+padding, clip.min[1]+padding+styles.metric("field.height",18.)+padding,
                (clip.width()-padding*2.).max(1.), styles.metric("row.height",22.)),
            self.notice.as_deref().or_else(||self.pen_tools.mode.hint(locale)).unwrap_or_else(|| {
                if self.tool==Tool::Pen && sampled.iter().any(|path|path["bounds_size"].is_array()) {
                    if locale==Locale::Zh {"拖动角点调整宽高 · 对角固定 · Esc取消"}
                    else {"Drag corners to resize · Opposite corner stays fixed · Esc cancels"}
                } else if !sampled.is_empty() {
                    if locale==Locale::Zh {"Shift点选追加/切换 · Ctrl框选 · Shift框选追加 · 拖动路径段 · Esc取消"}
                    else {"Shift-click toggles points · Ctrl-drag selects · Shift-drag adds · Drag segments · Esc cancels"}
                } else {locale.t(T::DrawingHint)}
            }),
            colors.TEXT_MUTED,
        );
        list.append(tool_overlay);
        clip.contains(input.mouse) || self.editing()
    }
    fn remove_node(&self, l: &Layer, path: u64, node: u64, out: &mut Vec<Action>) {
        if l.locked {
            return;
        }
        if self.tool == Tool::Mask {
            if let Some(m) = l.masks.iter().find(|m| Some(m.id) == self.mask) {
                let mut p = m.path.clone();
                p.nodes.retain(|n| n.id != node);
                p.closed &= p.nodes.len() >= 3;
                out.push(Action::Edit(Command::Mask {
                    object: l.id,
                    action: MaskAction::Path {
                        mask: m.id,
                        path: p,
                    },
                }));
            }
        } else if let Content::Vector {
            vector:
                VectorContent {
                    source: VectorSource::Paths { paths },
                    ..
                },
        } = &l.content
        {
            let mut paths = paths.clone();
            if let Some(p) = paths.iter_mut().find(|p| p.id == path) {
                p.nodes.retain(|n| n.id != node);
                p.closed &= p.nodes.len() >= 3;
                out.push(Action::Edit(Command::Vector {
                    object: l.id,
                    action: VectorAction::SetPaths { paths },
                }));
            }
        }
    }
}
impl Controls {
    pub fn height(&self, l: &Layer, styles: &motion_ui::style::StyleSheet) -> f32 {
        let row = styles.metric("row.height", 22.);
        let gap = styles.metric("padding", 5.);
        if !self.masks_open {
            row
        } else {
            row + l
                .masks
                .iter()
                .map(|m| {
                    if self.collapsed_mask_cards.contains(&(l.id, m.id)) {
                        row + gap
                    } else {
                        row * 6. + gap
                    }
                })
                .sum::<f32>()
        }
    }
    pub fn inspector_section(
        &mut self,
        vector_only: bool,
        list: &mut PaintList,
        atlas: &mut TextAtlas,
        area: Rect,
        y: &mut f32,
        l: &Layer,
        state: &Value,
        input: &Input,
        locale: Locale,
        out: &mut Vec<Action>,
    ) {
        let styles = list.styles();
        let colors = styles.colors();

        if vector_only {
            self.groups.property_filter = super::types::PropertyFilter::All;
            self.groups.render(
                list,
                atlas,
                area,
                y,
                l,
                state,
                input,
                locale,
                motion_ui::dock::Panel::Vector,
                out,
            );
            if let Content::Vector { vector } = &l.content {
                let row = styles.metric("row.height", 22.);
                let pad = styles.metric("padding.panel", 8.);
                let slot = styles.metric("icon.slot", 20.);
                if !matches!(vector.source, VectorSource::Group { .. }) {
                    let neutral = Input::default();
                    let action_input = if self.groups.menu_in(motion_ui::dock::Panel::Vector) {
                        &neutral
                    } else {
                        input
                    };
                    let fields = mask_inspector::property_row(
                        styles.as_ref(),
                        area,
                        *y,
                        0,
                        1,
                        motion_ui::dock::Panel::Properties,
                    );
                    label(
                        list,
                        atlas,
                        fields.caption,
                        if locale == Locale::Zh {
                            "路径编辑"
                        } else {
                            "Path editing"
                        },
                        colors.TEXT_MUTED,
                    );
                    let pen = Rect::new(fields.number.min[0], *y, slot, row);
                    if icons_pen_button(list, pen, action_input, !l.locked, self.tool == Tool::Pen)
                    {
                        self.choose(Tool::Pen, out);
                    }
                    if matches!(vector.source, VectorSource::Shape { .. }) {
                        let text = if locale == Locale::Zh {
                            "转换为路径"
                        } else {
                            "Convert to path"
                        };
                        let x = pen.max[0] + pad;
                        let rect = Rect::new(
                            x,
                            *y,
                            (atlas.measure(text) + pad * 2.).min((area.max[0] - pad - x).max(0.)),
                            row,
                        );
                        if ui::button_styled(
                            list,
                            atlas,
                            rect,
                            text,
                            action_input,
                            !l.locked,
                            &styles,
                            "button.icon",
                        )
                        .clicked
                        {
                            out.push(Action::Edit(Command::Vector {
                                object: l.id,
                                action: VectorAction::ConvertToPath {
                                    frame: state["frame"].as_f64().unwrap_or(0.).floor() as u32,
                                },
                            }));
                            self.choose(Tool::Pen, out);
                        }
                    }
                    *y += row;
                }
                self.groups.finish_paint(
                    list,
                    atlas,
                    area,
                    state,
                    input,
                    locale,
                    motion_ui::dock::Panel::Vector,
                    out,
                );
            }
        }
        if vector_only {
            return;
        }
        self.compact_masks(
            list,
            atlas,
            area,
            y,
            l,
            state,
            input,
            locale,
            motion_ui::dock::Panel::Masks,
            crate::panels::types::PropertyFilter::All,
            out,
        );
    }
    pub(super) fn inspector_layer(
        &mut self,
        state: &Value,
        value: &Value,
    ) -> Option<std::sync::Arc<Layer>> {
        let revision = state["revision"].as_u64();
        let context = (
            state["root"].as_str().unwrap_or("").into(),
            state["composition"].as_str().unwrap_or("").into(),
            value["id"].as_u64()?,
            revision.unwrap_or(0),
        );
        if revision.is_some() {
            if let Some(cached) = &self.inspector_cache {
                if cached.context == context {
                    return Some(cached.layer.clone());
                }
            }
        }
        let layer = std::sync::Arc::new(observe!("path.inspector_layer", serde_json::from_value::<Layer>(value.clone()), "object={} revision={:?} fallback=no_layer", context.2, revision).ok()?);
        self.inspector_cache = Some(InspectorLayer {
            context,
            layer: layer.clone(),
        });
        Some(layer)
    }
    pub(super) fn masks_in_properties(
        &mut self,
        list: &mut PaintList,
        atlas: &mut TextAtlas,
        area: Rect,
        y: &mut f32,
        layer: &Layer,
        state: &Value,
        input: &Input,
        locale: Locale,
        filter: crate::panels::types::PropertyFilter,
        out: &mut Vec<Action>,
    ) {
        self.compact_masks(
            list,
            atlas,
            area,
            y,
            layer,
            state,
            input,
            locale,
            motion_ui::dock::Panel::Properties,
            filter,
            out,
        );
    }
    pub(super) fn inspector_menu_in(&self, host: motion_ui::dock::Panel) -> bool {
        self.inspector_context
            .as_ref()
            .is_some_and(|context| context.3 == host)
            && (self.add_mask_menu.open || self.mode_dropdowns.values().any(|d| d.open))
            || self.groups.menu_in(host)
    }
    pub(crate) fn mask_add_rect(&self, host: motion_ui::dock::Panel) -> Option<Rect> {
        self.inspector_add
            .filter(|(owner, _)| *owner == host)
            .map(|(_, rect)| rect)
    }
    pub(crate) fn begin_shape_probe(&mut self) { self.groups.selection_probe.start(); }
    pub(crate) fn shape_probe_rect(&self) -> Option<Rect> { self.groups.selection_probe.rect() }
    pub(super) fn append_inspector_overlays(&mut self, list: &mut PaintList) {
        if let Some(overlays) = self.inspector_overlays.take() {
            list.append(overlays);
        }
    }
    pub(crate) fn vector_add_rect(&self, host: motion_ui::dock::Panel) -> Option<Rect> {
        self.groups
            .add_rect
            .filter(|(owner, _)| *owner == host)
            .map(|(_, r)| r)
    }
    pub(crate) fn reveal_vector_item(&mut self, state: &Value, object: u64, item: u64) {
        if let Some(l) = layer(state, object) {
            if let Content::Vector { vector } = &l.content {
                let root = if let VectorSource::Group { group } = &vector.source {
                    group.id
                } else {
                    1
                };
                self.groups.reveal_item(object, root, item);
            }
        }
    }
    pub(super) fn clear_mask_selection(&mut self) {
        self.keys.clear_selection();
        self.groups.keys.clear_selection();
    }
    pub(super) fn project_key(&mut self, state: &Value, target: &motion_core::KeyframeTarget, frame: u32) {
        match target {
            motion_core::KeyframeTarget::Mask {object,mask,property} => {
                let index=match property {MaskProperty::Opacity=>0,MaskProperty::Feather=>1,MaskProperty::Expansion=>2,MaskProperty::Node(_)=>mask_path::CHANNEL};
                self.keys.project_key(state,*object,*mask,index,frame);
            }
            motion_core::KeyframeTarget::Vector {object,item,parameter} => {
                // Flat source geometry is displayed as the existing virtual item 2.
                self.groups.keys.project_key(state,*object,item.unwrap_or(2),parameter,frame);
            }
            _=>{}
        }
    }
    pub(super) fn take_mask_selection_intent(&mut self) -> bool {
        self.keys.take_selection_intent()
    }
    pub(in crate::panels) fn clipboard_selection(&self, state: &Value, object: u64) -> Option<super::keyframe_clipboard::Selection> {
        self.keys.clipboard_selection(state, object).or_else(|| self.groups.keys.clipboard_selection(state, object))
    }
    pub(super) fn take_shape_selection_intent(&mut self) -> bool {
        self.groups.keys.take_selection_intent()
    }
    pub(super) fn clear_mask_channel(&mut self) {
        self.keys.clear_selection();
    }
    pub(super) fn clear_shape_channel(&mut self) {
        self.groups.keys.clear_selection();
    }
    pub(super) fn numeric_owner(&self) -> Option<motion_ui::dock::Panel> {
        self.parameter.as_ref().map(|p| p.host)
    }
    pub(super) fn mask_menu(&self) -> bool {
        self.keys.modal()
            || self.timeline_add_mask_menu.is_some()
            || self.groups.menu_in(motion_ui::dock::Panel::Timeline)
            || self.groups.keys.modal()
    }
    pub(super) fn mask_overlay(
        &mut self,
        list: &mut PaintList,
        atlas: &mut TextAtlas,
        area: Rect,
        state: &Value,
        input: &Input,
        locale: Locale,
        out: &mut Vec<Action>,
    ) {
        self.timeline_mask_add_overlay(list, atlas, area, state, input, locale, out);
        self.keys.overlay(list, atlas, area, input, locale, out);
        self.groups.append_overlays(list);
        self.groups
            .keys
            .overlay(list, atlas, area, input, locale, out);
        self.groups.overlay(
            list,
            atlas,
            area,
            state,
            input,
            locale,
            motion_ui::dock::Panel::Timeline,
            out,
        );
    }
    pub fn numeric_cursor(&self) -> Option<(Rect, bool)> {
        self.parameter.as_ref().map(|p| (p.rect, p.begun))
    }
    pub fn parameter_input(
        &mut self,
        state: &Value,
        input: &Input,
        out: &mut Vec<Action>,
        drag_threshold: f32,
    ) {
        let Some(mut p) = self.parameter.take() else {
            return;
        };
        let frame = state["frame"].as_f64().unwrap_or(0.).floor() as u32;
        let context = self.parameter_context.take();
        let stale = context.as_ref().is_some_and(|(root, composition, at)| {
            root != state["root"].as_str().unwrap_or("")
                || composition != state["composition"].as_str().unwrap_or("")
                || *at != frame
        }) || state["project"]["layers"].as_array().is_some_and(|layers| {
            !layers.iter().any(|l| {
                l["id"].as_u64() == Some(p.object)
                    && l["locked"] != true
                    && l["masks"].as_array().is_some_and(|masks| masks.iter().any(|m|
                        m["id"].as_u64() == Some(p.mask) && (!matches!(p.property, MaskProperty::Feather)
                            || m["feather_linked"].as_bool() == Some(p.linked))))
            })
        });
        if stale {
            if p.begun {
                out.push(Action::History(4));
            }
            return;
        }
        let command = |p: &Parameter, value: f32| {
            let mut v = p.values.clone();
            if p.linked && matches!(p.property, MaskProperty::Feather) {
                v = mask_boundaries::linked_feather([v[0], v[1]], p.axis, value, p.range[1]).to_vec();
            } else {
                v[p.axis] = value;
            }
            Action::Edit(Command::Mask {
                object: p.object,
                action: MaskAction::Set {
                    mask: p.mask,
                    property: p.property.clone(),
                    frame,
                    value: v,
                    animated: None,
                },
            })
        };
        if input.focus_lost || input.key_presses().any(|(k, _, repeat)| k == Key::Escape && !repeat) {
            if p.begun {
                out.push(Action::History(4));
            }
            return;
        }
        if p.begun && input.pressed.is_some_and(|(button,_)| button == MouseButton::Left) {
            // A new press starts a new gesture, even if a prior release was lost.
            out.push(Action::History(3));
            return;
        }
        if p.start.is_none()
            && !input.composing
            && input
                .pressed
                .is_some_and(|(b, point)| b == MouseButton::Left && p.rect.contains(point))
        {
            if let Ok(value) = p.text.parse::<f32>() {
                if value.is_finite() {
                    let value = value.clamp(p.range[0], p.range[1]);
                    if p.linked && matches!(p.property, MaskProperty::Feather) {
                        p.values = mask_boundaries::linked_feather([p.values[0],p.values[1]],p.axis,value,p.range[1]).to_vec();
                    } else {
                        p.values[p.axis] = value;
                    }
                }
            }
            p.start = Some(input.pressed.unwrap().1[0]);
            p.last_value = p.values[p.axis];
        }
        let release = input.released.is_some_and(|(b, _)| b == MouseButton::Left);
        let outside = input
            .pressed
            .is_some_and(|(_, point)| !p.rect.contains(point));
        if let Some(start) = p.start {
            if !input.dragging() && !release && !input.pressed.is_some_and(|(button,_)| button == MouseButton::Left) {
                if p.begun {
                    out.push(Action::History(3));
                    return;
                }
                p.start = None;
            }
            let point = input.released.filter(|(b,_)| *b == MouseButton::Left).map_or(input.mouse, |(_,point)| point);
            let delta = point[0] - start;
            if (input.dragging() || release)
                && (motion_ui::widgets::numeric_behavior::started(
                    delta,
                    input.pointer_travel,
                    drag_threshold,
                ) || p.begun)
            {
                if !p.begun {
                    out.push(Action::History(2));
                    p.begun = true;
                }
                let step = motion_ui::widgets::numeric_behavior::step(input) as f32;
                let value = (p.values[p.axis] + delta * step).clamp(p.range[0], p.range[1]);
                let value = if p.linked && matches!(p.property, MaskProperty::Feather) {
                    mask_boundaries::linked_feather([p.values[0],p.values[1]],p.axis,value,p.range[1])[p.axis]
                } else { value };
                p.text = format!("{value:.1}");
                if value != p.last_value {
                    p.last_value = value;
                    out.push(command(&p, value));
                }
            }
            if release || outside {
                if p.begun {
                    out.push(Action::History(3));
                    return;
                }
                p.start = None;
            }
        }
        if p.start.is_none() {
            let event = p.editor.input_value(&mut p.text, &mut p.replace, input);
            if outside || matches!(event, Some(motion_ui::widgets::TextEvent::Commit(_))) {
                if p.text.trim().is_empty() {
                    return;
                }
                if let Ok(v) = p.text.parse::<f32>() {
                    if v.is_finite() {
                        out.push(command(&p, v.clamp(p.range[0], p.range[1])));
                        return;
                    }
                }
            }
        }
        self.parameter = Some(p);
        self.parameter_context = context;
    }
}
fn paint_path(
    list: &mut PaintList,
    projection: &Projection,
    nodes: &[[f32; 6]],
    closed: bool,
    offset: [f32; 2],
    selected: Option<usize>,
    show_all_handles: bool,
    color: Color,
    hovered: Option<(usize, Option<usize>)>,
) {
    let colors = list.styles().colors();
    paint_path_curve(list,projection,nodes,closed,offset,color);
    for (i, g) in nodes.iter().enumerate() {
        let Some(p) = projection.screen([g[0] - offset[0], g[1] - offset[1]]) else {
            continue;
        };
        let node = Rect::new(p[0] - 3., p[1] - 3., 6., 6.);
        if hovered == Some((i, None)) {
            paint::box_rect(list, node, colors.ACCENT, colors.TEXT, 1., 0.);
        } else {
            paint::box_rect(list, node, color, Color([0.; 4]), 0., 0.);
        }
        if show_all_handles || selected == Some(i) || selected.is_none() {
            for axis in [2, 4] {
                if g[axis].abs() + g[axis + 1].abs() < 0.01 {
                    continue;
                }
                if let Some(h) =
                    projection.screen([g[0] + g[axis] - offset[0], g[1] + g[axis + 1] - offset[1]])
                {
                    let handle_color = if selected.is_some() && selected != Some(i) {
                        color.with_alpha(list.styles().metric("path.handle.opacity", 0.7))
                    } else { color };
                    let connector = handle_color.with_alpha(list.styles().metric("path.handle.opacity", 0.7));
                    paint::line(list, vec![p, h], connector);
                    if hovered == Some((i, Some(axis))) {
                        paint::diamond(list, h, 4., colors.TEXT);
                        paint::diamond(list, h, 2.6, colors.ACCENT);
                    } else {
                        paint::diamond(list, h, 3., handle_color);
                    }
                }
            }
        }
    }
}

fn paint_path_curve(list:&mut PaintList,projection:&Projection,nodes:&[[f32;6]],closed:bool,offset:[f32;2],color:Color) {
    let edges = nodes.len().saturating_sub(1) + usize::from(closed && nodes.len() > 2);
    for i in 0..edges {
        let a = nodes[i];
        let b = nodes[(i + 1) % nodes.len()];
        let mut points = vec![];
        for step in 0..=20 {
            let t = step as f32 / 20.;
            let u = 1. - t;
            let xy = std::array::from_fn(|axis| {
                u * u * u * a[axis]
                    + 3. * u * u * t * (a[axis] + a[axis + 4])
                    + 3. * u * t * t * (b[axis] + b[axis + 2])
                    + t * t * t * b[axis]
                    - offset[axis]
            });
            if let Some(p) = projection.screen(xy) {
                points.push(p);
            }
        }
        paint::line(list, points, color);
    }
}

#[cfg(test)]
mod pen_tests;
#[cfg(test)]
mod drag_lifecycle_tests;
#[cfg(test)]
mod resize_tests;
#[cfg(test)]
mod handle_visibility_tests;
#[cfg(test)]
mod hidden_handles_tests;

#[cfg(test)]
mod hover_tests {
    use super::*;

    /// Identity-ish matrix that maps local units to one screen pixel around the
    /// composition centre, so the expectations below stay readable.
    fn projection() -> Projection {
        let mut m = [0.; 16];
        m[0] = 0.01;
        m[5] = 0.02;
        m[10] = 1.;
        m[15] = 1.;
        Projection::new(m, Rect::new(0., 0., 200., 100.), [200., 100.]).unwrap()
    }
    fn nodes() -> Vec<[f32; 6]> {
        vec![
            [0., 0., 0., 0., 0., 0.],
            [20., 0., 8., 0., 0., 0.],
            [40., 0., 0., 0., 0., 0.],
        ]
    }

    #[test]
    fn hover_reports_only_the_nearest_grip_within_tolerance() {
        let p = projection();
        let nodes = nodes();
        let paths = [(1, nodes.as_slice())];
        assert_eq!(
            hovered_target(&p, &paths, [0., 0.], [121., 50.], None),
            Some(HoverTarget {
                path: 1,
                node: 1,
                handle: None
            })
        );
        // Outside the shared grip radius nothing is hovered.
        assert_eq!(hovered_target(&p, &paths, [0., 0.], [112., 50.], None), None);
        // The second path wins when it owns the closer node.
        let other = vec![[0., 10., 0., 0., 0., 0.]];
        assert_eq!(
            hovered_target(
                &p,
                &[(1, nodes.as_slice()), (2, other.as_slice())],
                [0., 0.],
                [100.5, 59.5],
                None
            ),
            Some(HoverTarget {
                path: 2,
                node: 0,
                handle: None
            })
        );
    }
    #[test]
    fn hover_reaches_handles_only_where_paint_draws_them() {
        let p = projection();
        let nodes = nodes();
        let paths = [(1, nodes.as_slice())];
        let handle = HoverTarget {
            path: 1,
            node: 1,
            handle: Some(2),
        };
        // Node 2 is selected, so its bezier handle is visible and hoverable.
        assert_eq!(
            hovered_target(&p, &paths, [0., 0.], [128., 50.], Some(2)),
            Some(handle)
        );
        // Node 1 selected: node 2's handle is not painted, so it cannot win.
        assert_eq!(
            hovered_target(&p, &paths, [0., 0.], [128., 50.], Some(1)),
            None
        );
    }
}

#[cfg(test)]
mod numeric_tests {
    use super::*;
    #[test]
    fn mask_scrub_obeys_shared_threshold_and_commit_or_cancel_restores_engine_bytes() {
        for threshold in [0., 12.] {
            for canceled in [false, true] {
                let mut project = motion_core::Project::new(640, 480, 30, 120).unwrap();
                let mut layer = motion_core::Layer::solid(
                    7,
                    "Mask numeric",
                    [100., 100.],
                    [0., 0., 0.],
                    [1.; 4],
                );
                let path = VectorPath {
                    id: 1,
                    closed: true,
                    nodes: [[0., 0.], [100., 0.], [0., 100.]]
                        .into_iter()
                        .enumerate()
                        .map(|(i, p)| PathNode {
                            id: i as u64 + 1,
                            geometry: Track::constant([p[0], p[1], 0., 0., 0., 0.]),
                        })
                        .collect(),
                };
                let mut mask = LayerMask::new(1, path);
                mask.opacity = Track::constant(50.);
                layer.masks.push(mask);
                project.layers.push(layer);
                let mut engine = motion_core::Engine::new(project).unwrap();
                let before = serde_json::to_vec(engine.project()).unwrap();
                let mut controls = Controls::default();
                controls.parameter = Some(Parameter {
                    host: motion_ui::dock::Panel::Masks,
                    object: 7,
                    mask: 1,
                    property: MaskProperty::Opacity,
                    axis: 0,
                    values: vec![50.],
                    text: "50".into(),
                    replace: true,
                    editor: Default::default(),
                    rect: Rect::new(90., 0., 120., 30.),
                    start: Some(100.),
                    begun: false,
                    last_value: 50.,
                    linked: false,
                    range: [0., 100.],
                });
                let state = serde_json::json!({"frame":0});
                let mut actions = vec![];
                controls.parameter_input(
                    &state,
                    &Input {
                        mouse: [105., 15.],
                        held: Some(MouseButton::Left),
                        ..Default::default()
                    },
                    &mut actions,
                    threshold,
                );
                assert_eq!(
                    actions
                        .iter()
                        .filter(|a| matches!(a, Action::History(2)))
                        .count(),
                    usize::from(threshold == 0.)
                );
                controls.parameter_input(
                    &state,
                    &Input {
                        mouse: [120., 15.],
                        held: Some(MouseButton::Left),
                        ..Default::default()
                    },
                    &mut actions,
                    threshold,
                );
                assert!(controls.numeric_cursor().unwrap().1);
                controls.parameter_input(
                    &state,
                    &Input {
                        mouse: [100., 15.],
                        held: Some(MouseButton::Left),
                        pointer_travel: 20.,
                        ..Default::default()
                    },
                    &mut actions,
                    threshold,
                );
                let end = if canceled {
                    Input {
                        keys: vec![(Key::Escape, Default::default())],
                        ..Default::default()
                    }
                } else {
                    Input {
                        mouse: [120., 15.],
                        released: Some((MouseButton::Left, [120., 15.])),
                        ..Default::default()
                    }
                };
                controls.parameter_input(&state, &end, &mut actions, threshold);
                assert_eq!(
                    actions
                        .iter()
                        .filter(|a| matches!(a, Action::History(2)))
                        .count(),
                    1
                );
                for action in actions {
                    match action {
                        Action::History(2) => engine.begin_gesture().unwrap(),
                        Action::History(3) => engine.end_gesture(true).unwrap(),
                        Action::History(4) => engine.end_gesture(false).unwrap(),
                        Action::Edit(command) => {
                            engine.apply(command).unwrap();
                        }
                        _ => panic!("unexpected mask action"),
                    }
                }
                if !canceled {
                    assert_ne!(serde_json::to_vec(engine.project()).unwrap(), before);
                    engine.undo().unwrap();
                }
                assert_eq!(serde_json::to_vec(engine.project()).unwrap(), before);
                assert!(controls.numeric_cursor().is_none());
            }
        }
    }
}

#[cfg(test)]
mod fallback_tests {
    use super::*;
    #[test]
    fn malformed_layers_keep_path_fallback_and_emit_bounded_evidence() {
        const CHILD: &str = "MOTION_PATH_LAYER_FALLBACK_CHILD";
        if let Some(root) = std::env::var_os(CHILD) {
            let root = std::path::PathBuf::from(root);
            let _logger = crate::logging::init(root.clone()).unwrap();
            let value = serde_json::json!({"id":7,"content":17});
            let state = serde_json::json!({"revision":1,"project":{"layers":[value.clone()]}});
            let mut controls = Controls::default();
            for _ in 0..120 {
                assert!(layer(&state,7).is_none());
                assert!(controls.inspector_layer(&state,&value).is_none());
            }
            let text = std::fs::read_to_string(root.join("motion-studio.log")).unwrap();
            for site in ["path.layer","path.inspector_layer"] {
                let records = text.lines().filter(|l| l.contains(&format!("site={site} "))).collect::<Vec<_>>();
                assert_eq!(records.len(),2,"{site}: {text}");
                assert!(records[1].contains("ERROR") && records[1].contains("object=7"));
            }
            assert!(controls.inspector_cache.is_none());
            return;
        }
        let temp = tempfile::tempdir().unwrap();
        let output = std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact", "panels::path_controls::fallback_tests::malformed_layers_keep_path_fallback_and_emit_bounded_evidence"]).env_remove("MOTION_LOG").env(CHILD,temp.path()).output().unwrap();
        assert!(output.status.success(),"{}\n{}",String::from_utf8_lossy(&output.stdout),String::from_utf8_lossy(&output.stderr));
        assert!(String::from_utf8_lossy(&output.stderr).contains("site=path.layer"));
        assert!(!String::from_utf8_lossy(&output.stdout).contains("panel degradation"));
    }
}


#[cfg(test)]
mod review327_regressions {
    use super::*;
    use motion_ui::paint::{Shape, Pattern};

    fn projection() -> Projection {
        let mut m = [0.; 16]; m[0] = 0.01; m[5] = 0.02; m[10] = 1.; m[15] = 1.;
        Projection::new(m, Rect::new(0., 0., 200., 100.), [200., 100.]).unwrap()
    }

    #[test]
    fn review327_only_the_hovered_bezier_handle_is_highlighted() {
        let p = projection();
        let nodes = [[0., 0., -20., 0., 20., 0.]];
        for x in [80., 120.] {
            let hover = hovered_target(&p, &[(1, &nodes)], [0.;2], [x,50.], Some(1)).unwrap();
            let mut list = PaintList::default();
            let color = list.styles().colors().ACCENT;
            paint_path(&mut list, &p, &nodes, false, [0.;2], Some(0), false, color, Some((hover.node, hover.handle)));
            let highlighted: Vec<_> = list.shapes.iter().filter_map(|s| match s {
                Shape::Procedural { area, kind: Pattern::Diamond, .. } if (area.width()-8.).abs()<0.01 => Some(*area),
                _ => None,
            }).collect();
            assert_eq!(highlighted.len(), 1, "one hovered handle must not highlight its opposite handle");
            assert!(((highlighted[0].min[0] + highlighted[0].max[0]) * 0.5 - x).abs() < 0.01);
        }
    }

    #[test]
    fn review327_locked_path_does_not_advertise_hover() {
        let mut project = motion_core::Project::new(640, 480, 30, 120).unwrap();
        let mut layer = Layer::solid(7, "Locked path", [100.;2], [0.;3], [1.;4]);
        layer.content = Content::Vector { vector: new_vector(VectorPath { id: 1, closed: false, nodes: vec![
            PathNode { id: 1, geometry: Track::constant([0.;6]) },
            PathNode { id: 2, geometry: Track::constant([60.,0.,0.,0.,0.,0.]) },
        ] }) };
        layer.locked = true;
        project.layers.push(layer);
        let engine = motion_core::Engine::new(project).unwrap();
        let project = engine.project();
        let mut state = serde_json::json!({"root":"review327", "revision":0, "frame":0, "project":project,
            "source_transforms":[{"id":7, "mvp":DMat4::from_scale(glam::DVec3::new(2./640., 2./480., 1.)).to_cols_array()}],
            "vector_layers":[{"id":7,"paths":[{"id":1,"closed":false,"nodes":[{"id":1,"geometry":[0.,0.,0.,0.,0.,0.]}]}]}]});
        let mut atlas = TextAtlas::from_system(12.).unwrap();
        for observing in [false, true] {
            state["project"]["layers"][0]["locked"] = (!observing).into();
            state["observing"] = observing.into();
            let mut controls = Controls::default(); controls.tool = Tool::Pen;
            let mut list = PaintList::default();
            let mut actions = vec![];
            controls.draw(&mut list, &mut atlas, Rect::new(0.,0.,640.,480.), &state, Some(7), &Input { mouse:[320.,240.], ..Default::default() }, Locale::En, &mut actions);
            let highlighted = list.shapes.iter().filter(|s| matches!(s, Shape::Procedural { area, kind: Pattern::Box { width, .. }, .. } if (area.min[0]-317.).abs()<0.01 && (area.min[1]-237.).abs()<0.01 && *width > 0.)).count();
            assert_eq!(highlighted, 0, "locked or read-only path must not promise an editable grip");
            assert!(actions.is_empty());
        }
    }
}
