from pathlib import Path
import hashlib, json, os, re, subprocess, sys

root = Path('E:/Dev/aem')
work = root / '.worktrees/ai-depth'
out = root / 'artifacts/pr-queue/issue74-depth-regression-v4'
out.mkdir(exist_ok=False)

def source():
    names = set()
    for args in [('ls-files', '-z'), ('ls-files', '--others', '--exclude-standard', '-z')]:
        names.update(p.decode() for p in subprocess.check_output(['git', *args], cwd=work).split(b'\0') if p)
    return {p: hashlib.sha256((work / p).read_bytes()).hexdigest() for p in sorted(names)
            if (work / p).is_file() and (p.endswith(('.rs', '.py', '.toml')) or p == 'Cargo.lock')}

before = source()
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(root / 'target/ai-depth74-contract'), CARGO_BUILD_JOBS='1',
           CARGO_INCREMENTAL='0', CARGO_NET_OFFLINE='true', CARGO_PROFILE_DEV_DEBUG='0',
           CARGO_PROFILE_TEST_DEBUG='0')
env.pop('MOTION_LOG', None)
steps = [
    ('onnx-unit', ['cargo', 'test', '-p', 'motion-host', '--lib', '--features', 'ai-depth',
                   'depth::onnx::tests::', '--locked', '--offline', '--', '--test-threads=1'], 4),
    ('job-integration', ['cargo', 'test', '-p', 'motion-host', '--no-default-features',
                         '--features', 'ai-depth', '--test', 'depth_jobs', '--locked', '--offline',
                         '--', '--test-threads=1'], 6),
]
steps.append(('model-regression', ['cargo', 'test', '-p', 'motion-model', '--locked', '--offline', '--', '--test-threads=1'], None))
receipt = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip(),
               source=before, controllerPid=os.getpid(), steps=[])
(out / 'controller.py').write_bytes(Path(__file__).read_bytes())
for name, command, count in steps:
    step = dict(name=name, command=command, expectedTests=count)
    with (out / (name + '.stdout.log')).open('wb') as stdout, (out / (name + '.stderr.log')).open('wb') as stderr:
        process = subprocess.Popen(command, cwd=work, env=env, stdout=stdout, stderr=stderr)
        step['pid'] = process.pid
        receipt['steps'].append(step)
        (out / 'started.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        step['exitCode'] = process.wait()
    step['sourceUnchanged'] = before == source()
    (out / 'exit.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    assert step['sourceUnchanged']
    if step['exitCode']:
        sys.exit(step['exitCode'])
    results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (out/(name+'.stdout.log')).read_text(encoding='utf-8'))
    assert results and all(int(r[1])==0 and int(r[2])==0 for r in results)
    step['passed']=sum(int(r[0]) for r in results)
    assert step['passed']>0 and (count is None or step['passed']==count)
(out / 'accepted.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(dict(passed=sum(s['passed'] for s in receipt['steps']), failed=0, ignored=0)), flush=True)
