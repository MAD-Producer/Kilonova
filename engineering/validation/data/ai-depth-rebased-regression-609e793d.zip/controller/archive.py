from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('E:/Dev/aem');work=root/'.worktrees/ai-depth';runs=root/'artifacts/pr-queue'
run=runs/'issue74-depth-regression-v4'
receipt=json.loads((run/'accepted.json').read_text(encoding='utf-8'))
assert sum(s['passed'] for s in receipt['steps'])==91
assert all(s['exitCode']==0 and s['sourceUnchanged'] for s in receipt['steps'])
sha=lambda b:hashlib.sha256(b).hexdigest()
runtime=['crates/motion-host/src/depth.rs','crates/motion-host/src/depth/onnx.rs','tools/ai_depth_onnx.py','tools/export_ai_depth.py']
previous=json.loads((runs/'issue74-real-rust-v3/accepted.json').read_text(encoding='utf-8'))
for name in runtime:assert sha((work/name).read_bytes())==receipt['source'][name]==previous['source'][name],name
payload={'run/'+p.name:p.read_bytes() for p in run.iterdir() if p.is_file()}
for name in ['.github/workflows/ci.yml','tools/test_ci_workflow.py']:
    payload['source/'+name]=(work/name).read_bytes()
for name in ['issue74-workflow-regression.log','issue74-provenance-validation.log','issue74-workflow-missing-yaml.log']:
    payload['logs/'+name]=(runs/name).read_bytes()
assert b'Ran 12 tests' in payload['logs/issue74-workflow-regression.log'] and b'\nOK' in payload['logs/issue74-workflow-regression.log']
payload['controller/archive.py']=Path(__file__).read_bytes()
manifest=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
    parent78='8ffb5af7030372d180131d732579b5c036c3b13c',runtimeUnchanged=True,
    scope='91 rebased Rust tests; separately validated workflow-only feature selection added afterward; no new real-model or remote acceptance claim',
    files={n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(payload.items())})
payload['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=work/'engineering/validation/data/ai-depth-rebased-regression-609e793d.zip';assert not dest.exists()
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(payload.items()):archive.writestr(name,data)
with zipfile.ZipFile(dest) as archive:
    assert set(archive.namelist())==set(payload)
    for name,data in payload.items():assert sha(archive.read(name))==sha(data)
result=dict(file=dest.name,bytes=dest.stat().st_size,files=len(payload),sha256=sha(dest.read_bytes()))
(runs/'issue74-rebased-archive.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
