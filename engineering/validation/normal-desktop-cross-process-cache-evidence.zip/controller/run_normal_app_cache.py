"""Exercise the normal desktop/MCP/window entrypoint in independent processes.

Only this controller's own windows and isolated account configuration are used.
No test-only Engine constructor or driver-cache callback is available here.
"""
from pathlib import Path
import copy
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
from PIL import Image

ROOT = Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
OUT = Path(sys.argv[2]).resolve() if len(sys.argv)>2 else Path(__file__).parent/'normal-app-cache-evidence'
assert not OUT.exists(), 'Never overwrite an earlier run'
OUT.mkdir()
BINARY = Path(sys.argv[1]).resolve(strict=True)
PACKAGE = ROOT/'crates/motion-effects/builtin-library/builtin-effects.msfx'
manifest = json.loads((PACKAGE.parent/'manifest.json').read_text(encoding='utf-8'))
definition = next(x for x in manifest['effects'] if x['id'] == 'invert')
instance = dict(id=1,plugin=manifest['id'],effect=definition['id'],version=manifest['version'],
                hash=hashlib.sha256(PACKAGE.read_bytes()).hexdigest(),enabled=True,seed=1,
                params={p['id']:{k:p[k] for k in ['kind','animatable','min','max','implemented','default']}
                        | {'track':{'value':p['default'],'keys':[]}} for p in definition['params']})
template = Path(__file__).parent/'frame-completion-existing-model-layer-evidence/project/project.json'
project = json.loads(template.read_text(encoding='utf-8'))
project.update(name='Pipeline process qualification',width=64,height=64,fps={'numerator':30,'denominator':1},frames=60,
               work_area={'in_frame':0,'out_frame':60},assets=[],model_assets=[],tracking_assets=[],
               plugin_dependencies=[],layers=[])
layer = json.loads(template.read_text(encoding='utf-8'))['layers'][0]
layer.update(name='Authored color',content={'kind':'solid','color':[0.8,0.2,0.1,1]},size=[48,48],
             three_d=False,effects=[])
layer['transform'].update(position={'value':[32,32,0],'keys':[]},
                          rotation={'value':[0,0,0],'keys':[]})
project['layers'] = [layer]
user32 = ctypes.WinDLL('user32',use_last_error=True)
CALLBACK = ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
user32.ShowWindow.argtypes = [wintypes.HWND,ctypes.c_int]
user32.PostMessageW.argtypes = [wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM]
user32.EnumWindows.argtypes = [CALLBACK,wintypes.LPARAM]

def windows(pid):
    found=[]
    @CALLBACK
    def collect(handle,_):
        owner=wintypes.DWORD()
        user32.GetWindowThreadProcessId(handle,ctypes.byref(owner))
        if owner.value == pid:
            found.append(handle)
        return True
    assert user32.EnumWindows(collect,0)
    return found

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(pair,kind,with_effect):
    case=OUT/pair/kind
    case.mkdir(parents=True)
    account=OUT/pair/'account'
    account.mkdir(exist_ok=True)
    cache=account/'MotionStudio/driver-pipeline-cache-v1'
    before_cache=[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in cache.glob('*') if p.is_file()]
    if kind=='cold': assert not before_cache
    else: assert before_cache, 'Warm process must receive an actual saved native cache'
    fixture=copy.deepcopy(project)
    if with_effect:
        fixture['layers'][0]['effects']=[copy.deepcopy(instance)]
        fixture['plugin_dependencies']=[{k:instance[k] for k in ['plugin','version','hash']}]
    root=case/'project'
    root.mkdir()
    source=root/'project.json'
    source.write_text(json.dumps(fixture,ensure_ascii=False,indent=2),encoding='utf-8')
    fixture_sha=sha(source)
    env=os.environ.copy()
    env['LOCALAPPDATA']=str(account)
    env['MOTION_UI_LAYOUT']=str(case/'workspace.json')
    env.pop('MOTION_LOG',None)
    env.pop('MOTION_PROJECT',None)
    stderr=(case/'stderr.log').open('w',encoding='utf-8')
    stdout=(case/'stdout.jsonl').open('w',encoding='utf-8')
    transcript=(case/'requests.jsonl').open('w',encoding='utf-8')
    started=time.monotonic()
    proc=subprocess.Popen([str(BINARY),'--mcp-ui','--project',str(root),'--locale','en',
                           '--diagnostics-report',str(case/'diagnostics.json')],
                          stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,
                          text=True,encoding='utf-8',env=env,creationflags=subprocess.CREATE_NO_WINDOW)
    received=queue.Queue()
    def read():
        for line in proc.stdout:
            stdout.write(line);stdout.flush();received.put(line)
        received.put(None)
    threading.Thread(target=read,daemon=True).start()
    stop=threading.Event()
    def keep_normal_window():
        shown=set()
        while not stop.wait(.02) and proc.poll() is None:
            for handle in windows(proc.pid):
                if handle not in shown:
                    # A hidden normal window is correctly occluded, so its
                    # event loop stops redraw polling. Exercise the actual
                    # visible-window path, without activating another app.
                    user32.ShowWindow(handle,4);shown.add(handle)
    threading.Thread(target=keep_normal_window,daemon=True).start()
    seq=0
    def send(method,params):
        nonlocal seq
        seq+=1
        request={'jsonrpc':'2.0','id':seq,'method':method,'params':params}
        transcript.write(json.dumps({'at_ms':(time.monotonic()-started)*1000,'request':request})+'\n');transcript.flush()
        proc.stdin.write(json.dumps(request)+'\n');proc.stdin.flush()
        line=received.get(timeout=20)
        assert line is not None, 'Application exited before MCP response'
        response=json.loads(line)
        assert response.get('id')==seq and 'error' not in response, response
        result=response['result']
        assert not result.get('isError'), result
        return result
    def tool(name,args=None):
        return send('tools/call',{'name':name,'arguments':args or {}})['structuredContent']
    def ready(revision=None,effect=True):
        deadline=time.monotonic()+30
        while True:
            s=tool('motion_state')
            p=s['preview']['pipelinePreparation']
            rev=s['revision'] if revision is None else revision
            if s.get('lastPresentedRevision')==rev and not p['preparing'] and s['presented']>0:
                if effect: assert p['task']['phase']=='installed', p
                return s
            assert time.monotonic()<deadline, {'reason':'normal application never completed its frame','state':s}
            time.sleep(.02)
    def snapshot(label,s):
        (case/(label+'-state.json')).write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8')
    def capture(label,s):
        builds=s['preview']['effectPipelineBuilds']
        result=tool('render_preview')
        image=Path(result['path'])
        dest=case/(label+'.png')
        shutil.copy2(image,dest)
        pixels=Image.open(dest).convert('RGBA')
        assert pixels.size==(64,64)
        following=tool('motion_state')
        assert following['preview']['effectPipelineBuilds']==builds, 'Capture compiled an unprepared native effect pipeline'
        return {'png':dest.relative_to(OUT).as_posix(),'rgba_sha256':hashlib.sha256(pixels.tobytes()).hexdigest(),
                'center':list(pixels.getpixel((32,32))),'effectPipelineBuilds':builds}
    receipt={'pid':proc.pid,'pair':pair,'kind':kind,'binary_sha256':sha(BINARY),
             'production_entrypoint':'--mcp-ui','window_mode':'visible_no_activation','isolated_account_base':str(account),
             'original_fixture_sha256':fixture_sha,'cache_before':before_cache}
    try:
        send('initialize',{'protocolVersion':'2025-11-25','capabilities':{},
                          'clientInfo':{'name':'pipeline-process-qualification','version':'1'}})
        initialized={'jsonrpc':'2.0','method':'notifications/initialized'}
        transcript.write(json.dumps({'at_ms':(time.monotonic()-started)*1000,'request':initialized})+'\n');transcript.flush()
        proc.stdin.write(json.dumps(initialized)+'\n');proc.stdin.flush()
        s=ready(effect=with_effect)
        receipt['first_complete_ms']=(time.monotonic()-started)*1000
        snapshot('startup',s)
        receipt['startup']=capture('startup',s)
        receipt['driver_load']=s['preview']['pipelinePreparation']['driverCache']['load']
        assert receipt['driver_load']==('missing' if kind=='cold' else 'restored'),receipt['driver_load']
        if with_effect:
            assert receipt['startup']['center'][1]>receipt['startup']['center'][0]
            assert sha(source)==fixture_sha,'Application startup changed the authored project'
        else:
            assert receipt['startup']['center'][0]>receipt['startup']['center'][1]
            timings=[]
            for label in ['first-add','re-add']:
                t=time.monotonic()
                s=tool('motion_edit',{'expectedRevision':s['revision'],'commands':[
                    {'op':'effect','object':1,'action':{'kind':'insert','instance':instance}}]})
                edit_ms=(time.monotonic()-t)*1000
                s=ready(s['revision'])
                elapsed=(time.monotonic()-t)*1000
                snapshot(label,s)
                pic=capture(label,s)
                assert pic['center'][1]>pic['center'][0]
                timings.append({'operation':label,'edit_reply_ms':edit_ms,'first_complete_ms':elapsed,'capture':pic})
                s=tool('motion_edit',{'expectedRevision':s['revision'],'commands':[
                    {'op':'effect','object':1,'action':{'kind':'remove','effect':1}}]})
                s=ready(s['revision'],effect=False)
            assert timings[0]['capture']['rgba_sha256']==timings[1]['capture']['rgba_sha256']
            assert timings[0]['capture']['effectPipelineBuilds']==timings[1]['capture']['effectPipelineBuilds'], 'Re-add rebuilt the retained native effect pipelines'
            receipt['effect_edits']=timings
        tool('motion_save')
        deadline=time.monotonic()+10
        while not any(p.is_file() for p in cache.glob('*')):
            assert time.monotonic()<deadline,'Normal application did not save its native cache'
            tool('motion_state');time.sleep(.02)
        for handle in windows(proc.pid): user32.PostMessageW(handle,0x0010,0,0)
        proc.stdin.close()
        receipt['exit_code']=proc.wait(timeout=20)
        assert receipt['exit_code']==0
        receipt['cache_after']=[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in cache.glob('*') if p.is_file()]
        log=account/'MotionStudio/logs/motion-studio.log'
        assert log.exists(),str(log)
        shutil.copy2(log,case/'motion-studio.log')
        receipt['elapsed_ms']=(time.monotonic()-started)*1000
        (case/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps({'pair':pair,'kind':kind,'pid':proc.pid,'first_complete_ms':receipt['first_complete_ms'],'driver_load':receipt['driver_load']}),flush=True)
        return receipt
    except BaseException:
        (case/'partial-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
        raise
    finally:
        stop.set()
        if proc.poll() is None:
            proc.kill();proc.wait(timeout=10)
        (case/'process-exit.json').write_text(json.dumps({'exit_code':proc.returncode,'exit_hex':hex(proc.returncode & 0xffffffff)}),encoding='utf-8')
        stderr.close();transcript.close()
        stdout.flush()

results=[]
for pair,with_effect in [('authored-startup',True),('first-and-repeat-add',False)]:
    cold=run(pair,'cold',with_effect)
    warm=run(pair,'warm',with_effect)
    assert cold['pid']!=warm['pid']
    assert cold['original_fixture_sha256']==warm['original_fixture_sha256']
    assert cold['startup']['rgba_sha256']==warm['startup']['rgba_sha256']
    if not with_effect:
        assert cold['effect_edits'][0]['capture']['rgba_sha256']==warm['effect_edits'][0]['capture']['rgba_sha256']
    results.extend([cold,warm])
(OUT/'report.json').write_text(json.dumps({'runs':results,'scope':'Independent normal desktop application processes; isolated LOCALAPPDATA; debug build; application-owned cache cold/warm, not cleared driver-global or OS caches'},ensure_ascii=False,indent=2),encoding='utf-8')
