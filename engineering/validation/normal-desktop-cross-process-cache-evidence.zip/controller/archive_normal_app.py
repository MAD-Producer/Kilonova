from pathlib import Path
import copy,hashlib,json,subprocess,zipfile

P=Path(__file__).parent
S=Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
OUT=P/'normal-desktop-cross-process-cache-evidence.zip'
assert not OUT.exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
assert head=='624c79e2b9c5d1f93cefe469a1ae4f58bfaa2e7f'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
report=json.loads((P/'normal-app-visible-cache-evidence/report.json').read_text(encoding='utf-8'))
assert len(report['runs'])==4 and len({r['pid'] for r in report['runs']})==4
for r in report['runs']:
    assert r['exit_code']==0
    assert r['driver_load']==('missing' if r['kind']=='cold' else 'restored')
source=None
for f in P.glob('pipeline-normal-app-*.json'):
    r=json.loads(f.read_text(encoding='utf-8'))
    assert r['source_before']==r['source_after']
    if source is None:source=r['source_before']
    assert source==r['source_before']

members={}
def add(name,data):
    assert name not in members
    members[name]=data

for f in P.glob('pipeline-normal-app-*'):
    if f.is_file():add('runs/'+f.name,f.read_bytes())
for name in ['normal-app-cache-evidence','normal-app-bundled-cache-evidence',
             'normal-app-rational-cache-evidence','normal-app-protocol-cache-evidence',
             'normal-app-visible-cache-evidence']:
    for f in sorted((P/name).rglob('*')):
        if not f.is_file():continue
        relative=f.relative_to(P/name)
        if 'account' in relative.parts and f.suffix!='.log':continue
        if f.suffix not in ['.json','.jsonl','.log','.png','.py']:continue
        add('attempts/'+name+'/'+relative.as_posix(),f.read_bytes())
for name in ['run.py','run_normal_app_cache.py','archive_normal_app.py',
             'normal-app-loader-probe.json','normal-app-packaged-loader-probe.json']:
    add('controller/'+name,(P/name).read_bytes())
template=P/'frame-completion-existing-model-layer-evidence/project/project.json'
add('controller/template-project.json',template.read_bytes())
# Reconstruct exact initial fixtures, before normal Save rewrites JSON layout.
project=json.loads(template.read_text(encoding='utf-8'))
project.update(name='Pipeline process qualification',width=64,height=64,fps={'numerator':30,'denominator':1},frames=60,
               work_area={'in_frame':0,'out_frame':60},assets=[],model_assets=[],tracking_assets=[],plugin_dependencies=[],layers=[])
layer=json.loads(template.read_text(encoding='utf-8'))['layers'][0]
layer.update(name='Authored color',content={'kind':'solid','color':[0.8,0.2,0.1,1]},size=[48,48],three_d=False,effects=[])
layer['transform'].update(position={'value':[32,32,0],'keys':[]},rotation={'value':[0,0,0],'keys':[]})
project['layers']=[layer]
manifest=json.loads((S/'crates/motion-effects/builtin-library/manifest.json').read_text(encoding='utf-8'))
definition=next(x for x in manifest['effects'] if x['id']=='invert')
instance=dict(id=1,plugin=manifest['id'],effect='invert',version=manifest['version'],
              hash=hashlib.sha256((S/'crates/motion-effects/builtin-library/builtin-effects.msfx').read_bytes()).hexdigest(),
              enabled=True,seed=1,params={p['id']:{k:p[k] for k in ['kind','animatable','min','max','implemented','default']}
                 | {'track':{'value':p['default'],'keys':[]}} for p in definition['params']})
for pair,with_effect in [('authored-startup',True),('first-and-repeat-add',False)]:
    fixture=copy.deepcopy(project)
    if with_effect:
        fixture['layers'][0]['effects']=[copy.deepcopy(instance)]
        fixture['plugin_dependencies']=[{k:instance[k] for k in ['plugin','version','hash']}]
    # The original Windows Path.write_text used the default CRLF translation.
    data=json.dumps(fixture,ensure_ascii=False,indent=2).replace('\n','\r\n').encode('utf-8')
    assert all(hashlib.sha256(data).hexdigest()==r['original_fixture_sha256'] for r in report['runs'] if r['pair']==pair)
    add('fixtures/'+pair+'.json',data)
runtime=[]
for f in sorted((P/'normal-app-runtime').iterdir()):
    if f.is_file():
        with f.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
        runtime.append({'name':f.name,'bytes':f.stat().st_size,'sha256':digest})
add('runtime-identity.json',json.dumps({'head':head,'members':runtime,'method':'hardlinks to the locally built normal executable and existing FFmpeg development DLLs; no binaries embedded'},indent=2).encode())
add('source-identity.json',json.dumps(source,indent=2).encode())
manifest=[{'name':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(members.items())]
add('manifest.json',json.dumps(manifest,indent=2).encode())
with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(members.items()):z.writestr(n,b)
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    for r in manifest:assert hashlib.sha256(z.read(r['name'])).hexdigest()==r['sha256']
receipt={'archive':str(OUT),'members':len(members),'bytes':OUT.stat().st_size,
         'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'source_head':head,
         'source_count':len(source),'normal_app_runs':4,'exit_code':0}
(P/'normal-app-archive-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
