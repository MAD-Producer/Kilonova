from pathlib import Path
import ast, hashlib, importlib.util, json, os, subprocess, time, traceback

root = Path('E:/Dev/aem/.worktrees/desktop-release-contracts')
out = Path('E:/Dev/aem/artifacts/issue-goal-current/ui-text-layout/font-app-native')
binary = out / 'runtime/motion-studio.exe'
expected = 'e5920e01c544a7854e593dfea552f25fa4735324437dc161d6252667e86d9b6e'
assert hashlib.sha256(binary.read_bytes()).hexdigest() == expected
source = root / 'tools/ci_desktop.py'
tree = ast.parse(source.read_text(encoding='utf-8-sig'))
main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
loop = next(n for n in main.body if isinstance(n, ast.For))
index = next(i for i, n in enumerate(loop.body) if isinstance(n, ast.Assign)
             and any(isinstance(t, ast.Name) and t.id == 'node_report' for t in n.targets))
block = loop.body[:index]
function = ast.FunctionDef(name='original_smoke_phase', args=ast.arguments(
    posonlyargs=[], args=[ast.arg(arg=n) for n in ['binary','output','locale']],
    vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=block, decorator_list=[])
module = ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[]))
(out/'original-smoke-phase.py').write_text(ast.unparse(module), encoding='utf-8')
spec = importlib.util.spec_from_file_location('exact_native_verifier', source)
ci = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ci)
exec(compile(module, str(source), 'exec'), ci.__dict__)
os.environ['MOTION_LOG'] = 'info'
os.environ['LOCALAPPDATA'] = str(out / 'local-app-data')
os.environ['TEMP'] = os.environ['TMP'] = str(out/'temp')
(out/'temp').mkdir(exist_ok=True)
os.environ['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + os.environ['PATH']
os.environ.pop('RUST_MIN_STACK', None)
(out/'source.json').write_text(json.dumps({
    'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'binary_sha256': expected, 'verifier_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'smoke_phase_ast_sha256': hashlib.sha256(ast.dump(ast.Module(body=block,type_ignores=[]),include_attributes=False).encode()).hexdigest(),
    'profile': 'dev; primary binary debug information disabled after LLVM OOM; all optimization and assertions unchanged',
    'scope': 'original smoke phase and all its assertions; not full node/panels/MCP acceptance',
    'original_smoke_deadline_seconds': 40,
}, indent=2), encoding='utf-8')
results = {}
for locale in ['en','zh']:
    started = time.monotonic()
    try:
        ci.original_smoke_phase(binary,out,locale)
        result = {'passed': True}
    except BaseException as error:
        result = {'passed':False, 'error':repr(error)}
        (out/f'{locale}-failure.txt').write_text(traceback.format_exc(), encoding='utf-8')
        if isinstance(error,subprocess.TimeoutExpired):
            for name,value in [('stdout',error.stdout),('stderr',error.stderr)]:
                if value is not None:
                    (out/f'{locale}-timeout.{name}').write_bytes(value if isinstance(value,bytes) else value.encode())
    result['elapsed_seconds'] = time.monotonic() - started
    results[locale] = result
    (out/'results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(locale,result,flush=True)
raise SystemExit(0 if all(r['passed'] for r in results.values()) else 1)
