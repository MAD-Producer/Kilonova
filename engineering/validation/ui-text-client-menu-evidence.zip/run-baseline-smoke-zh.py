from pathlib import Path
import hashlib,json,os,subprocess,time
out=Path('E:/Dev/aem/artifacts/issue-goal-current/ui-text-layout/font-parent-smoke-zh')
out.mkdir(exist_ok=True)
binary=Path('E:/Dev/aem/artifacts/issue-goal-current/node-drag-delta/isolated-runtime/motion-studio.exe')
digest=hashlib.sha256(binary.read_bytes()).hexdigest()
assert digest=='3c1aa322120c7611408552980e263204c17aca9e0f59da7228a0be17e8a37665'
env=os.environ.copy()
env.update(MOTION_LOG='info',LOCALAPPDATA=str(out/'local-app-data'),TEMP=str(out/'temp'),TMP=str(out/'temp'))
(out/'temp').mkdir(exist_ok=True)
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
env.pop('RUST_MIN_STACK',None)
started=time.monotonic()
result={'purpose':'existing parent runtime visual control for missing Chinese numeric fields; full 40-second smoke result retained separately',
        'binary_sha256':digest,'source_receipt':'../node-current-native-dev/source.json',
        'profile':'previously recorded dev diagnostic build, codegen-units=8, debug info disabled; not identical compiler settings to current primary bin'}
try:
    process=subprocess.run([str(binary),'--smoke',str(out/'smoke-zh.json'),'--locale','zh'],env=env,capture_output=True,timeout=40)
    result.update(exit=process.returncode,completed=True)
    (out/'stdout.log').write_bytes(process.stdout);(out/'stderr.log').write_bytes(process.stderr)
except subprocess.TimeoutExpired as error:
    result.update(completed=False,error=repr(error))
    (out/'stdout.log').write_bytes(error.stdout or b'');(out/'stderr.log').write_bytes(error.stderr or b'')
result['elapsed_seconds']=time.monotonic()-started
(out/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
