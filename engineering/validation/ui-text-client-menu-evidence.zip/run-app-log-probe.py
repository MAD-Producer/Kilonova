from pathlib import Path
import ctypes as c
from ctypes import wintypes as w
import hashlib,json,os,queue,re,subprocess,threading,time,traceback
from PIL import ImageGrab

out=Path('E:/Dev/aem/artifacts/issue-goal-current/ui-text-layout/font-app-log-probe')
out.mkdir(exist_ok=True)
binary=Path('E:/Dev/aem/artifacts/issue-goal-current/ui-text-layout/font-app-native/runtime/motion-studio.exe')
digest=hashlib.sha256(binary.read_bytes()).hexdigest()
assert digest=='e5920e01c544a7854e593dfea552f25fa4735324437dc161d6252667e86d9b6e'
env=os.environ.copy()
env.update(MOTION_LOG='info',LOCALAPPDATA=str(out/'local-app-data'),TEMP=str(out/'temp'),TMP=str(out/'temp'))
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
env.pop('RUST_MIN_STACK',None)
(out/'temp').mkdir(exist_ok=True)
log=out/'local-app-data/MotionStudio/logs/motion-studio.log'
errors=(out/'stderr.log').open('w',encoding='utf-8')
process=subprocess.Popen([str(binary),'--mcp-ui','--project',str(out/'project'),'--locale','en'],
    stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors,text=True,encoding='utf-8',env=env,
    creationflags=subprocess.CREATE_NO_WINDOW)
received=queue.Queue()
raw=[]
def read():
    for line in process.stdout:
        raw.append(line)
        received.put(line)
    received.put(None)
threading.Thread(target=read,daemon=True).start()
sequence=0
def send(method,params=None,notification=False):
    global sequence
    sequence+=1
    message={'jsonrpc':'2.0','method':method}
    if not notification:message['id']=sequence
    if params is not None:message['params']=params
    process.stdin.write(json.dumps(message)+'\n');process.stdin.flush()
    if notification:return {}
    line=received.get(timeout=20)
    if line is None:raise RuntimeError('MCP exited before reply')
    response=json.loads(line)
    assert response.get('id')==sequence and 'error' not in response,response
    return response['result']
def tool(name,arguments=None):
    result=send('tools/call',{'name':name,'arguments':arguments or {}})
    assert not result.get('isError'),result
    return result.get('structuredContent')
def edit(command):
    revision=tool('motion_state')['revision']
    return tool('motion_edit',{'expectedRevision':revision,'commands':[command]})
def events():
    text=log.read_text(encoding='utf-8') if log.exists() else ''
    return [line for line in text.splitlines() if 'site=text.shaped_missing key="U+10FFFF" ' in line]

u=c.WinDLL('user32',use_last_error=True)
callback=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
u.EnumWindows.argtypes=[callback,w.LPARAM]
u.GetWindowThreadProcessId.argtypes=[w.HWND,c.POINTER(w.DWORD)]
u.IsWindowVisible.argtypes=[w.HWND]
u.GetClientRect.argtypes=[w.HWND,c.POINTER(w.RECT)]
u.ClientToScreen.argtypes=[w.HWND,c.POINTER(w.POINT)]
u.SetForegroundWindow.argtypes=[w.HWND]
u.PostMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM]
u.ShowWindow.argtypes=[w.HWND,c.c_int]
def window():
    matches=[]
    @callback
    def collect(handle,_):
        pid=w.DWORD();u.GetWindowThreadProcessId(handle,c.byref(pid))
        if pid.value==process.pid and u.IsWindowVisible(handle):
            rect=w.RECT();u.GetClientRect(handle,c.byref(rect))
            if rect.right>400 and rect.bottom>300:matches.append(handle)
        return True
    u.EnumWindows(collect,0)
    if not matches:raise RuntimeError('Native editor window not visible')
    return matches[0]
def screenshot(name):
    handle=window();u.ShowWindow(handle,9);u.SetForegroundWindow(handle)
    time.sleep(.25)
    rect=w.RECT();u.GetClientRect(handle,c.byref(rect));point=w.POINT();u.ClientToScreen(handle,c.byref(point))
    image=ImageGrab.grab((point.x,point.y,point.x+rect.right,point.y+rect.bottom),all_screens=True)
    assert image.width>400 and image.height>300
    image.save(out/name)
    return {'width':image.width,'height':image.height,'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()}

started=time.monotonic();result={'binary_sha256':digest,'scope':'real MCP/shared native editor and product default Info sink under isolated LOCALAPPDATA; not entire CI smoke acceptance'}
try:
    send('initialize',{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'font-log-probe','version':'1'}})
    send('notifications/initialized',notification=True)
    catalogue=tool('command_list');(out/'catalogue.json').write_text(json.dumps(catalogue,indent=2),encoding='utf-8')
    healthy='العربية e\u0301 中文'
    edit({'op':'add_shape','id':1002,'name':healthy,'shape':'rectangle','size':[120,120],'position':[960,540,0]})
    for i in range(12):tool('motion_seek',{'frame':i%2});time.sleep(.1)
    assert not events(),'Unexpected fault before injection'
    result['healthy_screenshot']=screenshot('healthy.png')
    edit({'op':'rename','object':1002,'name':'\U0010ffff FONT-PROBE'})
    for i in range(90):
        tool('motion_seek',{'frame':i%2});time.sleep(.1)
    fault=events()
    assert fault,'Actual editor never observed the missing glyph'
    owners={re.search(r'owner=(\d+)',line).group(1) for line in fault}
    for owner in owners:
        lines=[s for s in fault if f'owner={owner} ' in s]
        assert len(lines)==2 and ' WARN ' in lines[0] and 'count=1 ' in lines[0] and ' ERROR ' in lines[1] and 'count=60 ' in lines[1],lines
    stderr=(out/'stderr.log').read_text(encoding='utf-8')
    stderr_fault=[s for s in stderr.splitlines() if 'site=text.shaped_missing key="U+10FFFF" ' in s]
    assert len(stderr_fault)==len(owners),stderr_fault
    assert all('count=60 ' in s and s.startswith('ERROR ') for s in stderr_fault)
    assert all('FONT-PROBE' not in line for line in fault)
    edit({'op':'rename','object':1002,'name':healthy})
    for i in range(15):tool('motion_seek',{'frame':i%2});time.sleep(.1)
    assert events()==fault,'Healthy labels added missing-glyph records'
    tool('motion_save')
    saved=json.loads((out/'project/project.json').read_text(encoding='utf-8'))
    assert any(layer['id']==1002 and layer['name']==healthy for layer in saved['layers'])
    result['recovered_screenshot']=screenshot('recovered.png')
    result.update(passed=True,observed_owners=sorted(owners),fault_records=fault,error_stderr_records=stderr_fault,requests=sequence)
    process.stdin.close();u.PostMessageW(window(),0x0010,0,0)
    result['exit']=process.wait(timeout=10)
    assert result['exit']==0,result
except BaseException as error:
    result.update(passed=False,error=repr(error))
    (out/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8')
finally:
    if process.poll() is None:
        process.kill();process.wait(timeout=10);result['stopped_by_harness']=True
    errors.close()
    (out/'stdout.jsonl').write_text(''.join(raw),encoding='utf-8')
    result['stdout_json_only']=all(isinstance(json.loads(line),dict) and json.loads(line).get('jsonrpc')=='2.0' for line in raw)
    result['elapsed_seconds']=time.monotonic()-started
    (out/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=True),flush=True)
raise SystemExit(0 if result.get('passed') and result.get('stdout_json_only') else 1)
