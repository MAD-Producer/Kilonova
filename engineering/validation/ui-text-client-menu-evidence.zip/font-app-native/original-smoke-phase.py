def original_smoke_phase(binary, output, locale):
    report = output / f'smoke-{locale}.json'
    result = subprocess.run([str(binary), '--smoke', str(report), '--locale', locale], capture_output=True, text=True, encoding='utf-8', timeout=40)
    (output / f'smoke-{locale}.stderr.log').write_text(result.stderr, encoding='utf-8')
    if result.returncode:
        raise RuntimeError(f'{locale} desktop acceptance failed: {result.stderr}')
    snapshot = json.loads(report.read_text(encoding='utf-8'))
    verify_design_screens(snapshot, locale)
    workspace_probe = snapshot['workspacePresentationProbe']
    maximize = snapshot['panelMaximizeProbe']
    if maximize['restored'] is not True or maximize['layoutAndProjectUntouched'] is not True:
        raise RuntimeError(f'{locale} temporary panel maximize changed persistent state')
    if len(maximize['screenshots']) != 4:
        raise RuntimeError(f'{locale} missing panel maximize and restore captures')
    for screenshot in maximize['screenshots']:
        data = Path(screenshot).read_bytes()
        if len(data) < 1024 or not data.startswith(b'\x89PNG\r\n\x1a\n'):
            raise RuntimeError(f'{locale} invalid panel maximize capture: {screenshot}')
    floating_maximize = report.with_suffix('.panel-3-backquote.png')
    data = floating_maximize.read_bytes()
    if len(data) < 1024 or not data.startswith(b'\x89PNG\r\n\x1a\n'):
        raise RuntimeError(f'{locale} missing native floating Backquote evidence')
    presentations = workspace_probe['presentations']
    if workspace_probe['projectUntouched'] is not True or len(presentations) != 6 or {record['preset'] for record in presentations} != {'default', 'nodes', 'drawing', 'all', 'animation'} or (not any((record['nodeOverlay'] for record in presentations))):
        raise RuntimeError(f'{locale} did not present workspace changes with a live node overlay')
    verify_expanded_workspace_previews(snapshot, locale)
    if snapshot['locale'] != locale or snapshot['floatingFrames'].get('3', 0) < 2:
        raise RuntimeError(f'{locale} did not validate the floating composition')
    layer_menu = Path(snapshot['layerContextMenuScreenshot'])
    data = layer_menu.read_bytes()
    if len(data) < 1024 or not data.startswith(b'\x89PNG\r\n\x1a\n'):
        raise RuntimeError(f'{locale} did not render the timeline layer context menu')