$ErrorActionPreference='Stop'
. E:/Dev/aem/.tools/msvc-portable/env.ps1
$taskOut='E:/Dev/aem/artifacts/issue-goal-current/ui-text-layout'
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:MOTION_LOG='info'
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:LIBCLANG_PATH='E:/Dev/aem/.tools/python-libclang/clang/native'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
$taskHead=(git rev-parse HEAD).Trim()
if ($taskHead -ne '7405614fa62c6808131d0cdf84fbb99db264671b') { throw 'Unexpected source commit' }
if (git status --porcelain) { throw 'Source worktree is dirty' }
$taskStart=Get-Date
@{head=$taskHead;started=$taskStart.ToString('o');reason='Previous ordinary dev compiler explicitly reported LLVM out of memory. Disable only primary binary debug information; do not change source, optimization, assertions or acceptance timeouts.';command='cargo rustc -p motion-desktop --bin motion-studio --features ffmpeg --locked --offline --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --message-format=json -- -C debuginfo=0 -C link-arg=/DEBUG:NONE'} | ConvertTo-Json | Set-Content -LiteralPath "$taskOut/font-app-nodebug-source.json" -Encoding utf8
cargo rustc -p motion-desktop --bin motion-studio --features ffmpeg --locked --offline --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --message-format=json -- -C debuginfo=0 -C link-arg=/DEBUG:NONE 1> "$taskOut/font-app-nodebug.stdout" 2> "$taskOut/font-app-nodebug.stderr"
$taskExit=$LASTEXITCODE
@{exit=$taskExit;headBefore=$taskHead;headAfter=(git rev-parse HEAD).Trim();completed=(Get-Date).ToString('o');elapsedSeconds=((Get-Date)-$taskStart).TotalSeconds;sourceStatus=(git status --porcelain | Out-String)} | ConvertTo-Json | Set-Content -LiteralPath "$taskOut/font-app-nodebug-result.json" -Encoding utf8
exit $taskExit
