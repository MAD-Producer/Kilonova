import re,json
from pathlib import Path
p=Path(__file__).resolve().parent
lines=(p/'initial-lens-precision.log').read_text(errors='replace').splitlines()
values=[]
for line in lines:
    if line.startswith(('  left: Object',' right: Object')):
        s=line.split(': ',1)[1]
        s=re.sub(r'\b(?:Object|Array) ', '',s)
        s=re.sub(r'Number\(([^)]+)\)',r'\1',s)
        s=re.sub(r'String\(("(?:[^"\\]|\\.)*")\)',r'\1',s)
        s=re.sub(r'Bool\((true|false)\)',r'\1',s).replace('Null','null')
        values.append(json.loads(s))
def diff(a,b,path=''):
    if isinstance(a,dict) and isinstance(b,dict):
        for k in a.keys()|b.keys():diff(a.get(k),b.get(k),path+'/'+k)
    elif isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
        for i,(x,y) in enumerate(zip(a,b)):diff(x,y,path+'/'+str(i))
    elif a!=b:print(path,json.dumps(a),json.dumps(b))
diff(*values)
(p/'initial-actual.json').write_text(json.dumps(values[0],indent=2))
(p/'initial-expected.json').write_text(json.dumps(values[1],indent=2))

