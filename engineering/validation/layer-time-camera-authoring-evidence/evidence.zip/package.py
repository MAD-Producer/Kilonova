import hashlib,json,re,subprocess,zipfile,shutil
from pathlib import Path
root=Path(__file__).resolve().parent;repo=Path.cwd()
dest=repo/'engineering/validation/layer-time-camera-authoring-evidence';dest.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((root/'source-hashes.json').read_text())
assert all(sha(repo/p)==v for p,v in sources.items()),'tested source changed'
results=json.loads((root/'results-all.json').read_text())
groups={r['group']:r for r in results}
assert set(groups)=={'mapped','camera','observation','lens','lens-time','native'},groups
passed=set();ignored=set()
for name,row in groups.items():
    assert row['exit']==0,row
    assert sha(Path(row['exe']))==row['exeSha256'],'tested executable changed'
    log=(root/(name+'.log')).read_text(errors='replace')
    row['passed']=re.findall(r'^test (\S+) \.\.\. ok$',log,re.M)
    row['ignored']=re.findall(r'^test (\S+) \.\.\. ignored.*$',log,re.M)
    passed.update(row['passed']);ignored.update(row['ignored'])
assert len({r['exeSha256'] for r in groups.values() if 'motion_studio-' in r['exe']})==1
checks=json.loads((root/'checks.json').read_text(encoding='utf-8-sig'));assert all(v==0 for v in checks.values()),checks
assert set(checks)=={'style','rustfmt','diff','workspace'}
assert len(list((root/'native').rglob('*.png')))==40
assert len(list((root/'native').rglob('reopened.json')))==8
capture=json.loads((root/'native/capture-process.json').read_text());reopen=json.loads((root/'native/reopen-process.json').read_text());assert capture['pid']!=reopen['pid']
for source,name in [('Zh-false-false/lens.png','camera-main-zh.png'),('En-true-true/lens.png','camera-floating-en.png')]:shutil.copyfile(root/'native'/source,dest/name)
for source,name in [('Zh-false-false/reset-menu.png','reset-main-zh.png'),('En-true-true/reset-menu.png','reset-floating-en.png')]:shutil.copyfile(root/'native'/source,dest/name)
archive=dest/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.suffix.lower() in {'.log','.json','.py','.ps1','.png'}:z.write(p,p.relative_to(root).as_posix())
manifest=dict(issue=257,pr=579,stage='exact camera pose and lens numeric authoring',base='85cf16601b84bdba08d68e21b268bf8336190d49',sourceHashes=sources,
    checks=checks,passed=len(passed),unrunManual=sorted(ignored-passed),groups=list(groups.values()),
    native=dict(cases=8,screenshots=40,separateProcessReopens=8,capturePid=capture['pid'],reopenPid=reopen['pid'],input='synthetic native chrome Input with production worker and native GPU captures; not physical OS mouse input'),
    observations=dict(new=['camera.numeric_time'],scope='process lifetime, Warn first and Error at 60; healthy calls do not reset',existing=['worker Info start and atomic rollback','camera sample and lens failures']),
    originalFailures=['initial-fixture-build.log: Camera requires Box','initial-fixture-runtime.log: solid transform violates camera invariant; use Layer::camera; guards unchanged','initial-lens-precision.log: new expected value must include the existing f32 protocol input conversion; full equality preserved'],
    limits=['Windows verification only','no global DESIGN compliance claim','continuous spatial camera stopwatch and legacy continuous editors still need audit','real media devices, prewarm and high-speed sampling acceptance pending','issue 257 remains open'],
    archive=dict(file='evidence.zip',sha256=sha(archive),bytes=archive.stat().st_size))
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(passed=len(passed),unrun=len(ignored-passed),screenshots=40,reopens=8,archiveBytes=archive.stat().st_size)))
