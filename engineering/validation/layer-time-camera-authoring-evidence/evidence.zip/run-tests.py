import os,subprocess,json,time,sys,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
deps=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps')
env=os.environ.copy();env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH'];env.pop('MOTION_LOG',None)
env['MOTION_MAPPED_CAMERA_ARTIFACTS']=str(root/'native')
env['MOTION_MAPPED_CAMERA_FAULT_ARTIFACTS']=str(root/'faults')
def binary(name):
    # Exact Cargo build outputs, not another agent's binary in the shared target.
    suffix={'motion_studio':'b34b3a7e7eb835e8','camera_lens':'4c7ef5b3471bbe12','camera_lens_time':'2dea86e4e80f7534'}[name]
    result=deps/(name+'-'+suffix+'.exe')
    assert result.is_file(),result
    return result
groups=[('mapped','motion_studio',['panels::camera_controls::mapped_tests::']),
    ('camera','motion_studio',['panels::camera_controls::','--skip','panels::camera_controls::mapped_tests::']),
    ('observation','motion_studio',['panels::tools::camera::']),
    ('lens','camera_lens',[]),('lens-time','camera_lens_time',[]),
    ('native','motion_studio',['--exact','panels::camera_controls::mapped_tests::native::native_mapped_cameras_commit_cancel_and_reopen_in_both_hosts_languages_and_directions','--ignored'])]
results=[]
for name,stem,args in groups:
    if len(sys.argv)>1 and name not in sys.argv[1:]:continue
    exe=binary(stem);before=hashlib.sha256(exe.read_bytes()).hexdigest();start=time.time()
    with (root/(name+'.log')).open('wb') as log:r=subprocess.run([str(exe),*args,'--nocapture','--test-threads=1'],stdout=log,stderr=subprocess.STDOUT,env=env)
    row=dict(group=name,args=args,exit=r.returncode,seconds=round(time.time()-start,3),exe=str(exe),exeSha256=before);results.append(row)
    (root/('results-'+('-'.join(sys.argv[1:]) if len(sys.argv)>1 else 'all')+'.json')).write_text(json.dumps(results,indent=2));print(json.dumps(row),flush=True)
    assert hashlib.sha256(exe.read_bytes()).hexdigest()==before,'test executable changed during run'
    if r.returncode:break
raise SystemExit(any(x['exit'] for x in results))
