import hashlib,json,pathlib,re,subprocess,zipfile
ROOT=pathlib.Path('E:/Dev/aem/.worktrees/layer-time-mapping')
RAW=pathlib.Path(__file__).resolve().parent
DEST=ROOT/'engineering/validation/composition-pass-runs-evidence'
def read(path):
 b=path.read_bytes();return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8-sig')
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
results={}
for name,count in [('runs',3),('frame',1),('planning',4),('admission',5),('integration',12),('workspace',0)]:
 assert int(read(RAW/f'final-{name}.exit'))==0,name
 log=read(RAW/f'final-{name}.log')
 matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',log)
 assert sum(int(x[0]) for x in matches)==count,(name,matches)
 assert all(x[1:]==('0','0') for x in matches),(name,matches)
 results[name]={'passed':count,'exit_code':0,'log':f'final-{name}.log'}
assert int(read(RAW/'before.exit'))==101
assert 'left: 0' in read(RAW/'before.log')
assert 'right: 1' in read(RAW/'before.log')
measurements={}
for phase,path in [('planning',RAW.parent/'matte-planning-storage/final-frame.log'),('batched',RAW/'final-frame.log')]:
 rows=[json.loads(m.group(1)) for line in read(path).splitlines() if (m:=re.search(r'(\{.*\})$',line))]
 assert len(rows)==144
 measurements[phase]=[]
 for kind in ['solid','vector','matte']:
  for layers in [1,8,32]:
   group=[r for r in rows if r['kind']==kind and r['layers']==layers]
   assert [r['frame'] for r in group]==list(range(4,20))
   measurements[phase].append({'kind':kind,'layers':layers,'frames':16,
    'ranges':{key:[min(r[key] for r in group),max(r[key] for r in group)] for key in ['sample','prepare','create','encode','submit','poll','total']}})
sources=['crates/motion-render/src/renderer.rs','crates/motion-render/src/renderer/composition_runs.rs',
 'crates/motion-render/src/renderer/composition_run_tests.rs','crates/motion-render/src/renderer/preview_allocation_tests.rs',
 'engineering/validation/composition-pass-runs.md']
binaries={}
for name in ['runs','frame','planning','admission','integration']:
 for item in re.findall(r'Running[^\n]*\(([^\n]+\.exe)\)',read(RAW/f'final-{name}.log')):
  path=pathlib.Path(item);binaries[path.name]=sha(path)
assert len(binaries)==3,binaries
DEST.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(DEST/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in RAW.iterdir():
  if p.is_file() and p.suffix in ['.log','.exit','.py']:z.write(p,'raw/'+p.name)
 z.write(RAW.parent/'matte-planning-storage/final-frame.log','baseline/planning-frame.log')
 for s in sources:z.write(ROOT/s,'final-source/'+s)
 z.writestr('baseline/renderer.rs',subprocess.check_output(['git','show','e99a24c6d013d8f8f1f653c6ab7c8142187b026f:crates/motion-render/src/renderer.rs'],cwd=ROOT))
manifest={'base_commit':'e99a24c6d013d8f8f1f653c6ab7c8142187b026f','pr':590,'issue':126,'issue_complete':False,
 'results':results,'distinct_tests':25,'frame_allocation_counts':measurements,
 'source_sha256_raw_files':{s:sha(ROOT/s) for s in sources},'binary_sha256':binaries,
 'evidence_zip_sha256':sha(DEST/'evidence.zip'),'ci':'pending for final head',
 'limits':['Calling-thread allocation counts, not bytes, FPS, other threads or external driver memory.',
 'Full-frame growth remains; issue 126 open.','Two new defensive missing-state branches not injected; no new full desktop logging acceptance.',
 'Interrupted build retained without exit code, confirmed missing tool handle and no compiler before restart.']}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'tests':25,'archive_bytes':(DEST/'evidence.zip').stat().st_size,'binaries':list(binaries)}))
