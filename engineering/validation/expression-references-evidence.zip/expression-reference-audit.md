# #244 实施前能力核对

核对基线：`e8034c5986dcec32de0bd27c97d5d695f87a34c7`（#243 表达式编辑器及 main 的素材事务、曲线输入优化）。后续独立 worktree 为 `E:/Dev/aem/.worktrees/expression-references`，分支 `feat/expression-references`。尚未修改生产代码或宣称完成 #244。

已检查开放 PR 的分支名称及本地 expression/text/pick 相关分支：没有另一条正在实现表达式属性引用的分支。#511 属于主窗输入借用性能工作，#508 属于渲染 DAG；不审阅或修改其 PR。

| 核对点 | 当前实现及实际缺口 |
|---|---|
| 稳定目标 | `motion-model/src/expressions.rs` 的 `ExpressionTarget` 已有对象 ID、效果实例 ID、参数名、属性枚举、可选轴。可复用，无须新增工程字段。u64 ID 生成 JS 代码时不得经过 Number，否则大于 2^53 会丢精度。 |
| 当前跨属性能力 | `motion-core/src/expressions/helpers.js` 暴露 `thisComp` 元信息和 `thisLayer` 元信息；没有属性查询入口。`valueAtTime()` 只调用当前目标的 `__msSample`。不能把“有元信息”当成已有依赖采样。 |
| 采样时间 | `expressions/mod.rs::evaluate` 把秒换算为合成帧，再减被采样图层 clip.offset；复用该边界，不能使用拖拽源图层的局部时间去采样目标。当前不裁剪为可见区间。 |
| 随机语义 | 种子由表达式 seed、目标对象 ID 和序列化目标组合；被引用属性须保留其自身 seed 和对象上下文，不能继承引用方上下文。 |
| 表达式相互依赖 | 当前 evaluated_at 独立求每个表达式，并从原工程采样。增加一个 JS 函数和拖拽按钮不足以实现依赖；必须显式处理被引用属性自身的表达式、整属性/分轴关系、效果禁用和循环。 |
| 运行时边界 | `runtime.rs::with_engine` 在整个执行中持有 thread-local RefCell 可变借用，重入被明确拒绝为 recursive expression evaluation。不能从 Rust 回调直接递归调用现有 evaluate，更不能通过新开无限 Runtime、加线程重试或放宽现有预算掩盖这一边界。 |
| 原始原因 | `evaluate_source` 已保留首个原生采样失败，即使 JS 捕获回调异常也不会静默成功。跨属性采样需保留同等契约及目标链，并限制链长/消息长度。 |
| 模型事务 | SetExpression 先验证编译和实际取样，失败不替换原表达式。新依赖需在候选表达式已进入临时求值图时检查循环，否则 A→B、后写 B→A 会漏检。 |
| 既有拾取交互 | `panels/parent_controls/picking.rs` 已处理原生窗口所属、释放提交、Escape/失焦/非左键取消和丢失 release。只借鉴项目已有输入契约，不修改父级拾取，不在所有面板永久保留命中几何。 |

下一步先实现可验证的宿主引用求值契约，再接入属性行拾取和多行草稿插入。独立准备重命名/重排、u64 精度、偏移与负时间、分轴/整属性、效果启用、缺失目标、依赖循环、执行预算、保存重开、单步撤销和默认错误信道用例。原生 UI 验收需涵盖中文/英文主窗与真实浮窗，并留存实际拖拽/取消截图。
