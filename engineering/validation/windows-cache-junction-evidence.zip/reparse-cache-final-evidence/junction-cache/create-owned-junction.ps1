param([string]$junctionPath, [string]$targetPath)
$ErrorActionPreference = "Stop"
New-Item -ItemType Junction -Path $junctionPath -Target $targetPath | Out-Null
