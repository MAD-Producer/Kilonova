"""Verify a real Windows junction refusal via the normal desktop process.

Derive only the setup and transport from the immutable nested-run controller;
additional assertions require typed cache failure and unchanged link targets.
"""
from pathlib import Path

P = Path(__file__).parent
text = (P/'run_nested_lookahead_normal_app.py').read_text(encoding='utf-8')
text = text.split('\nhealthy = run(')[0]
setup_old = "    account.mkdir()\n    fixture = copy.deepcopy(project)"
setup_new = r'''    account.mkdir()
    junction = None
    outside = None
    if label == 'junction-cache':
        outside = case / 'outside-cache'
        outside.mkdir()
        sentinel = outside / 'sentinel.txt'
        sentinel.write_bytes(b'Application must not modify this linked cache target')
        owner = account / 'MotionStudio'
        owner.mkdir()
        junction = owner / 'driver-pipeline-cache-v1'
        helper = case / 'create-owned-junction.ps1'
        helper.write_text('param([string]$junctionPath, [string]$targetPath)\n'
            '$ErrorActionPreference = "Stop"\n'
            'New-Item -ItemType Junction -Path $junctionPath -Target $targetPath | Out-Null\n',
            encoding='utf-8')
        result = subprocess.run(['pwsh', '-NoProfile', '-File', str(helper),
            str(junction), str(outside)], capture_output=True, text=True, encoding='utf-8')
        (case / 'junction-setup.stdout').write_text(result.stdout, encoding='utf-8')
        (case / 'junction-setup.stderr').write_text(result.stderr, encoding='utf-8')
        assert result.returncode == 0, result.stderr
        assert os.path.isjunction(junction), 'Fixture must be an actual Windows junction'
        assert junction.resolve() == outside.resolve()
        original_target = {item.name: sha(item) for item in outside.iterdir()}
    fixture = copy.deepcopy(project)'''
assert text.count(setup_old) == 1
text = text.replace(setup_old, setup_new)
state_old = "        assert prep['error'] is None, prep\n"
state_new = '''        assert prep['error'] is None, prep
        cache_status = prep['driverCache']
        if junction is not None:
            assert cache_status['enabled'] and cache_status['disabled'], cache_status
            assert cache_status['restored'], cache_status
            assert cache_status['load'] is None, cache_status
            assert 'reparse point' in cache_status['lastError'], cache_status
            assert cache_status['task']['phase'] == 'failed', cache_status
            assert cache_status['savedCreations'] == 0, cache_status
        else:
            assert not cache_status['disabled'] and cache_status['lastError'] is None, cache_status
            assert cache_status['load'] == 'missing', cache_status
'''
assert text.count(state_old) == 1
text = text.replace(state_old, state_new)
log_old = "        receipt['elapsed_ms'] = (time.monotonic()-started)*1000\n"
log_new = '''        if junction is not None:
            assert os.path.isjunction(junction)
            assert {item.name: sha(item) for item in outside.iterdir()} == original_target
            errors = [line for line in file_text.splitlines()
                      if 'ERROR' in line and 'reparse point' in line]
            assert len(errors) == 1, errors
            failure = errors[0]
            for field in ['request=', 'generation=', 'revision=', 'phase=storage',
                          'elapsed_ms=', 'driver-pipeline-cache-v1']:
                assert field in failure, failure
            request_id = failure.split('request=')[1].split()[0]
            start = 'driver cache start request='+request_id+' '
            assert any(start in line for line in file_text[:file_text.index(failure)].splitlines())
            assert 'reparse point' in error_text
            assert sum('reparse point' in line for line in error_text.splitlines()) == 1
            receipt['junction_target_unchanged'] = True
            receipt['default_reparse_failure_channels'] = True
            receipt['cache_failure_records'] = errors
        receipt['elapsed_ms'] = (time.monotonic()-started)*1000
'''
assert text.count(log_old) == 1
text = text.replace(log_old, log_new)
exec(compile(text, str(Path(__file__)), 'exec'))

healthy = run('healthy-cache', 1)
rejected = run('junction-cache', 1)
assert healthy['pid'] != rejected['pid']
assert healthy['rgba_sha256'] == rejected['rgba_sha256']
assert rejected['junction_target_unchanged']
(OUT/'report.json').write_text(json.dumps({'runs': [healthy, rejected],
    'scope': 'Real Windows cache-directory junction, ordinary desktop entrypoint; same full current pixels, default failure channels, no cache target mutation'},
    ensure_ascii=False, indent=2), encoding='utf-8')
