from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

P = Path(__file__).parent
S = Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
evidence = P/'reparse-cache-final-evidence'
phase = json.loads((P/'reparse-cache-normal-app-qualified.json').read_text(encoding='utf-8'))
assert phase['exit_code'] == 0 and phase['source_before'] == phase['source_after']
report = json.loads((evidence/'report.json').read_text(encoding='utf-8'))
healthy, rejected = report['runs']
assert healthy['pid'] != rejected['pid'] and healthy['rgba_sha256'] == rejected['rgba_sha256']
assert rejected['junction_target_unchanged'] and rejected['default_reparse_failure_channels']
assert all(run['exit_code'] == 0 for run in report['runs'])
junction = evidence/'junction-cache/account/MotionStudio/driver-pipeline-cache-v1'
target = evidence/'junction-cache/outside-cache'
metadata = junction.lstat()
assert metadata.st_reparse_tag == 0xA0000003 and metadata.st_file_attributes & 0x400
assert junction.resolve() == target.resolve()
assert [file.name for file in target.iterdir()] == ['sentinel.txt']
cache_files = list((evidence/'healthy-cache/account/MotionStudio/driver-pipeline-cache-v1').glob('*.cache'))
assert len(cache_files) == 1 and cache_files[0].stat().st_size > 0
def identity(path):
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'name': path.name, 'bytes': path.stat().st_size, 'sha256': digest}
native = {'reparse_tag': metadata.st_reparse_tag, 'file_attributes': metadata.st_file_attributes,
          'resolved_target': str(junction.resolve()), 'target_files': [identity(file) for file in target.iterdir()],
          'healthy_cache_files': [identity(file) for file in cache_files]}
(P/'reparse-cache-native-identity.json').write_text(json.dumps(native, indent=2), encoding='utf-8')
members = {}
def add(name, data):
    assert name not in members
    members[name] = data
for file in sorted(P.glob('reparse-cache-*')):
    if file.is_file() and file.suffix in ['.json', '.stdout', '.stderr']:
        add('commands/'+file.name, file.read_bytes())
for directory in sorted(P.glob('reparse-cache-*evidence')):
    if not directory.is_dir():
        continue
    # Never traverse junction/account directories into another tree.
    for case in directory.iterdir():
        if case.is_file() and case.suffix == '.json':
            add(directory.name+'/'+case.name, case.read_bytes())
        elif case.is_dir():
            for file in case.iterdir():
                if file.is_file() and file.suffix in ['.json', '.jsonl', '.log', '.png', '.stdout', '.stderr', '.ps1']:
                    add(directory.name+'/'+case.name+'/'+file.name, file.read_bytes())
for name in ['run.py', 'run_current_registry_normal_app.py', 'run_nested_lookahead_normal_app.py',
             'run_reparse_cache_normal_app.py', 'run_reparse_cache_normal_app_first.py',
             'run_reparse_cache_normal_app_second.py', 'run_reparse_cache_normal_app_third.py',
             'run_reparse_cache_normal_app_fourth.py', 'archive_reparse_cache.py']:
    add('controller/'+name, (P/name).read_bytes())
add('controller/template-project.json', (P/'frame-completion-existing-model-layer-evidence/project/project.json').read_bytes())
add('runtime-identity.json', json.dumps([identity(file) for file in (P/'nested-lookahead-runtime').iterdir()], indent=2).encode())
manifest = [{'name': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(members.items())]
add('manifest.json', json.dumps(manifest, indent=2).encode())
out = P/'windows-cache-junction-evidence.zip'
assert not out.exists()
with zipfile.ZipFile(out, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(out) as archive:
    assert archive.testzip() is None
    for item in manifest:
        assert hashlib.sha256(archive.read(item['name'])).hexdigest() == item['sha256']
receipt = {'archive': str(out), 'members': len(members), 'bytes': out.stat().st_size,
           'sha256': hashlib.sha256(out.read_bytes()).hexdigest(), 'qualified_processes': 2,
           'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=S, text=True).strip()}
(P/'reparse-cache-archive-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt))
