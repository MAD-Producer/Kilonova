import hashlib,json,os,re,subprocess,sys
from pathlib import Path
out=Path(__file__).parent
root=Path.cwd()
compiled=json.loads((out/'compile.json').read_bytes())
assert compiled['exit_code']==0 and compiled['source_before']==compiled['source_after']
frozen=compiled['source_after']
for name,digest in frozen.items(): assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
programs=[]
for line in (out/'compile.stdout').read_text(encoding='utf-8').splitlines():
    record=json.loads(line)
    if record.get('reason')=='compiler-artifact' and record.get('executable') and record.get('target',{}).get('name')=='motion-studio': programs.append(record['executable'])
assert len(programs)==1
program=Path(programs[0])
(out/'executable.json').write_bytes(json.dumps({'path':str(program),'sha256':hashlib.file_digest(program.open('rb'),'sha256').hexdigest(),'source':frozen},indent=2).encode())
def run(phase,args):
    os.environ['MOTION_PRESET_NATIVE_CAUSE_EVIDENCE']=str(out/(phase+'-native'))
    os.environ['MOTION_ANIMATION_PRESET_FAILURE_ARTIFACTS']=str(out/(phase+'-existing'))
    result=subprocess.run([sys.executable,str(out/'run.py'),phase,*args])
    if result.returncode: raise SystemExit(result.returncode)
    actual=json.loads((out/(phase+'.json')).read_bytes())
    assert actual['source_before']==actual['source_after']==frozen,phase
    return (out/(phase+'.stdout')).read_text(encoding='utf-8')
text=run('native-causes',[str(program),'animation_presets::tests::native_errors::','--test-threads=1','--nocapture'])
assert '2 passed; 0 failed; 0 ignored' in text
text=run('preset-regression',[str(program),'animation_presets::tests::','--test-threads=1','--nocapture'])
assert '7 passed; 0 failed; 1 ignored' in text
run('all-targets',['cargo','check','--locked','-p','motion-desktop','-p','motion-host','--all-targets','--features','motion-desktop/ffmpeg,motion-host/diagnostics,motion-host/ai-depth'])
