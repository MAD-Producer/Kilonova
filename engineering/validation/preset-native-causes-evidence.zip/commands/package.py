import hashlib,json,re,subprocess,zipfile
from pathlib import Path
out=Path(__file__).parent;root=Path.cwd()
frozen=json.loads((out/'compile.json').read_bytes())['source_after']
summary={}
for name in ['compile','native-causes','preset-regression','all-targets','verification-wrapper']:
    d=json.loads((out/(name+'.json')).read_bytes())
    assert d['exit_code']==0 and d['source_before']==d['source_after']==frozen,name
    text=(out/(name+'.stdout')).read_text(encoding='utf-8')
    counts=[tuple(map(int,c)) for c in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
    summary[name]={'exit_code':0,'elapsed_seconds':d['elapsed_seconds'],'passed':sum(c[0] for c in counts),'ignored':sum(c[2] for c in counts),'source_stable':True}
assert summary['native-causes']['passed']==2
assert summary['preset-regression']['passed']==7 and summary['preset-regression']['ignored']==1
for name,digest in frozen.items(): assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
exe=json.loads((out/'executable.json').read_bytes())
assert exe['source']==frozen
assert hashlib.file_digest(Path(exe['path']).open('rb'),'sha256').hexdigest()==exe['sha256']
for phase in ['native-causes','preset-regression']:
    child=out/(phase+'-native')
    evidence=json.loads((child/'native-cause.json').read_bytes())
    assert evidence['os_error'] is not None and evidence['project_and_revision_preserved'] and evidence['same_native_identity'] and evidence['recovered_catalog_empty']
    assert b'animation preset failed' not in (child/'stdout.log').read_bytes()
    assert b'animation preset failed' in (child/'stderr.log').read_bytes()
    log=(child/'motion-studio.log').read_text(encoding='utf-8')
    assert log.index('animation preset start')<log.index('animation preset failed')
    assert ' ERROR ' in log
names=subprocess.check_output(['git','diff','--name-only','--','desktop'],text=True).splitlines()
names+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','desktop'],text=True).splitlines()
assert len(set(names))==5,names
(out/'verification-summary.json').write_bytes(json.dumps({'phases':summary,'source_files':len(frozen),'executable_sha256':exe['sha256'],'different_tests':7,'existing_manual_ignore':1,'scope':'Actual preset IO worker and controller; no complete desktop runtime, GPU pixel, or native screenshot acceptance'},indent=2).encode())
payload={}
for p in sorted(out.rglob('*')):
    if p.is_file() and p.name!='package-receipt.json' and p.suffix!='.exe':payload['commands/'+p.relative_to(out).as_posix()]=p.read_bytes()
for name in sorted(set(names)):
    data=(root/name).read_bytes();assert hashlib.sha256(data).hexdigest()==frozen[name]
    payload['source/after/'+name]=data
    before=subprocess.run(['git','show','d6e0e84b:'+name],capture_output=True)
    if before.returncode==0:payload['source/before/'+name]=before.stdout
manifest={n:{'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(payload.items())}
payload['manifest.json']=json.dumps(manifest,indent=2).encode()
archive=root/'engineering/validation/preset-native-causes-evidence.zip'
assert not archive.exists(),'do not overwrite immutable evidence'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(payload.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(payload)
    for name,data in payload.items():assert z.read(name)==data,name
receipt={'members':len(payload),'bytes':archive.stat().st_size,'sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'source_files':len(frozen),'phases':summary}
(out/'package-receipt.json').write_bytes(json.dumps(receipt,indent=2).encode())
print(json.dumps(receipt))
