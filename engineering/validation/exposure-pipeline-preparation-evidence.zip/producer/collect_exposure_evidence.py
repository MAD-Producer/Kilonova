"""Archive completed exposure preparation commands; never replace prior evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path.cwd()
out = Path(__file__).parent
target = root / 'engineering/validation/exposure-pipeline-preparation-evidence.zip'
assert not target.exists()
phases = ['exposure-preparation-check', 'exposure-surface-native',
          'exposure-nested-recovery', 'exposure-nested-corrected',
          'exposure-all-targets', 'exposure-render-regression', 'exposure-all-targets-recheck',
          'exposure-host-lib-regression', 'exposure-desktop-default-log',
          'exposure-desktop-sink-record']
members = {}
reports = []
def executable_identity(path):
    with path.open('rb') as stream:
        return {'bytes': path.stat().st_size, 'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}
for phase in phases:
    record = json.loads((out / (phase + '.json')).read_text(encoding='utf-8'))
    assert 'exit_code' in record, phase + ' is not terminal'
    assert record['source_before'] == record['source_after'], phase + ' source changed'
    reports.append({key: record[key] for key in ['command', 'exit_code', 'elapsed_seconds']}
                   | {'phase': phase, 'source_unchanged': True})
    for suffix in ['.json', '.stdout', '.stderr']:
        path = out / (phase + suffix)
        members['commands/' + path.name] = path.read_bytes()
for directory in ['exposure-surface-native-evidence', 'exposure-nested-corrected-evidence',
                  'exposure-desktop-sink-evidence']:
    for path in sorted((out / directory).rglob('*')):
        if path.is_file():
            members['native/' + path.relative_to(out).as_posix()] = path.read_bytes()
baseline = '92ea38dfffddb1c961fade6252ad3593e72e49a7'
names = subprocess.check_output(['git', 'diff', '--name-only', baseline, '--', 'crates'], text=True).splitlines()
for name in names:
    members['source/current/' + name] = (root / name).read_bytes()
    members['source/baseline/' + name] = subprocess.check_output(['git', 'show', baseline + ':' + name])
for name in ['run.py', 'collect_exposure_evidence.py']:
    members['producer/' + name] = (out / name).read_bytes()
for name in ['exposure-warning-scope.json', 'exposure-memory-before-recheck.json']:
    members['environment/' + name] = (out / name).read_bytes()
members['summary.json'] = json.dumps({
    'baseline': baseline, 'reports': reports,
    'native_executables': {
        name: executable_identity(path)
        for name in ['motion_render-4e278093648f3252.exe', 'motion_host-9819308cd86120da.exe',
                     'motion_studio-a9ea002b22e1a2a1.exe']
        for path in [Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps') / name]
    },
    'limits': ['not a complete desktop or host integration regression',
               'initial desktop all-targets failed actual 2097152-byte allocation; preserve both attempts',
               'typed panic propagation test is not desktop panic-hook qualification',
               'foregroundBuilds counts only effects, not fixed presentation pipelines',
               'no cold/warm or sustained exposure playback speed claim'],
}, ensure_ascii=False, indent=2).encode('utf-8')
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(members.items())}
members['manifest.json'] = json.dumps(manifest, indent=2).encode('utf-8')
with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for name, entry in manifest.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == entry['sha256']
receipt = {'path': str(target), 'members': len(members), 'bytes': target.stat().st_size,
           'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'reports': reports}
(out / 'exposure-evidence-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({key: receipt[key] for key in ['path', 'members', 'bytes', 'sha256']}, ensure_ascii=False))
