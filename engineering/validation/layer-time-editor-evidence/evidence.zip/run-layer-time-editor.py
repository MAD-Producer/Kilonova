import hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
r=Path('E:/Dev/aem/artifacts/issue-goal-current')
exe=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-b34b3a7e7eb835e8.exe')
mode=sys.argv[1];attempt=os.environ.get('MOTION_EDITOR_ATTEMPT','first')
env=os.environ.copy();env.update(TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp',TMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp',WGPU_BACKEND='vulkan')
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH'];env.pop('MOTION_LOG',None)
for name in ['LAYER_TIME_EDITOR_ERROR','LOCAL_TIMING_LOG','LOCAL_SELECTION_LOG','TYPED_KEYS_LOG','TIMED_GRAPH_LOG','LOCAL_KEYS_ERROR','KEY_TIMING_ERROR','CURVE_READOUT_FAULT','CURVE_RANGE_FAULT']:
    env['MOTION_'+name+'_ARTIFACTS']=str(r/('layer-time-editor-'+mode+'-'+attempt+'-'+name.lower()))
env['MOTION_LAYER_TIME_EDITOR_NATIVE_ARTIFACTS']=str(r/('layer-time-editor-native-'+attempt))
env['MOTION_KEY_TIMING_GPU_ARTIFACTS']=str(r/('layer-time-editor-old-native-'+attempt))
filters={'draft':'dialogs::layer_time::','shell':'shell::layer_time::tests::','menu':'panels::animation_menu::tests::'}
if mode=='all':filters.update({'dialogs':'dialogs::','layers':'panels::layer_actions::','selection':'panels::key_selection::',
    'timeline':'panels::timeline::','shortcuts':'panels::timeline_shortcuts','timing_worker':'engine::keyframe_timing_tests::'})
if mode=='native':filters={'native':'shell::layer_time::native_tests::layer_time_native_menus_drafts_transactions_owners_and_reopen'}
if mode=='old-native':filters={'old_native':'shell::keyframe_timing::native_tests::timing_dialog_native_pixels_focus_transactions_and_independent_reopen'}
report={'program':str(exe),'sha256_before':hashlib.sha256(exe.read_bytes()).hexdigest(),'suites':{}}
for tag,pattern in filters.items():
    cmd=[str(exe),pattern,'--test-threads=1','--nocapture']
    if mode in ('native','old-native'):cmd+=['--exact','--ignored']
    start=time.monotonic();p=subprocess.run(cmd,env=env,capture_output=True)
    stem='layer-time-editor-'+mode+'-'+attempt+'-'+tag
    (r/(stem+'-stdout.log')).write_bytes(p.stdout);(r/(stem+'-stderr.log')).write_bytes(p.stderr)
    output=p.stdout.decode('utf-8',errors='replace');blocks=re.split(r'^test ([^\s]+) \.\.\. ',output,flags=re.M)
    passed=[];ignored=[];failed=[]
    for i in range(1,len(blocks),2):
        name,body=blocks[i:i+2];body=re.split(r'^failures:|^test result:',body,flags=re.M)[0].strip()
        if body=='ok' or re.search(r'(^|\n)ok$',body):passed.append(name)
        elif body.startswith('ignored'):ignored.append(name)
        else:failed.append(name)
    report['suites'][tag]={'command':cmd,'exit_code':p.returncode,'elapsed_s':round(time.monotonic()-start,3),'passed':passed,'ignored':ignored,'failed':failed,'summary':re.findall(r'test result: .*',output)}
    file=r/('layer-time-editor-'+mode+'-'+attempt+'-results.json');file.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(tag,p.returncode,report['suites'][tag]['summary'],flush=True)
    if p.returncode:print((output+p.stderr.decode('utf-8',errors='replace'))[-13000:],flush=True);raise SystemExit(p.returncode)
report['sha256_after']=hashlib.sha256(exe.read_bytes()).hexdigest();assert report['sha256_before']==report['sha256_after']
report['distinct_passed']=sorted({t for s in report['suites'].values() for t in s['passed']})
report['distinct_ignored']=sorted({t for s in report['suites'].values() for t in s['ignored']})
file.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print('distinct',len(report['distinct_passed']),len(report['distinct_ignored']),flush=True)
