from pathlib import Path
import hashlib,json,re,shutil,zipfile
raw=Path(__file__).resolve().parent
repo=Path('E:/Dev/aem/.worktrees/layer-time-mapping')
dest=repo/'engineering/validation/layer-time-spatial-gestures-evidence'
dest.mkdir(exist_ok=True)
sources=json.loads((raw/'source-hashes.json').read_text(encoding='utf-8'))
for file,sha in sources.items():
 assert hashlib.sha256((repo/file).read_bytes()).hexdigest()==sha,file
results=json.loads((raw/'results-all.json').read_text(encoding='utf-8'))
assert len(results)==7 and sum(x['passed'] for x in results)==96
assert all(x['exit']==0 and x['passed']>0 for x in results)
assert len({x['exeSha256'] for x in results})==1
assert hashlib.sha256(Path(results[0]['exe']).read_bytes()).hexdigest()==results[0]['exeSha256']
ignored=set(re.findall(r'test (\S+) \.\.\. ignored',(raw/'mapped.log').read_text(encoding='utf-8')+(raw/'selection.log').read_text(encoding='utf-8')))
executed={x['args'][1] for x in results if x['args'][0]=='--exact'}
unrun=sorted(ignored-executed)
assert len(unrun)==6
assert len(list((raw/'native').rglob('*.png')))==80
assert len(list(raw.rglob('*.png')))==104
for direction in ['forward','reverse']:
 folder=raw/'native'/direction
 assert len(json.loads((folder/'cases.json').read_text(encoding='utf-8')))==20
 saved=json.loads((folder/'saved.json').read_text(encoding='utf-8'))
 reopened=json.loads((folder/'reopened.json').read_text(encoding='utf-8'))
 assert saved['project']==reopened['project']
 assert reopened['history']['undoEntries']==0
capture=json.loads((raw/'native/capture-process.json').read_text(encoding='utf-8'))
reopen=json.loads((raw/'native/reopen-process.json').read_text(encoding='utf-8'))
assert capture['pid']!=reopen['pid']
checks=json.loads((raw/'checks.json').read_text(encoding='utf-8'))
assert all(x==0 for x in checks.values())
pictures={
 'timeline-main-zh.png':'forward/zh-main-property-after.png',
 'timeline-floating-en.png':'reverse/en-float-property-after.png',
 'curve-floating-en.png':'reverse/en-float-comparison-after.png',
 'curve-main-zh.png':'forward/zh-main-value-after.png',
 'drag-preview-zh.png':'forward/zh-main-property-preview.png',
}
for name,source in pictures.items():shutil.copyfile(raw/'native'/source,dest/name)
manifest=dict(sourceSha256=sources,results=results,checks=checks,passed=96,
 nativeMappedCases=40,nativeMappedScreenshots=80,totalScreenshots=104,
 actualWorkerReopens=2,captureProcess=capture,reopenProcess=reopen,
 unrunManualTests=unrun,fullIssueComplete=False,
 retainedLimits=['Epic Vulkan overlay JSON registration errors',
  'existing crowded and truncated timeline headings',
  'remaining spatial mini editor, initial local roving selection and companion compensation',
  'real media device, prewarm and high-speed final acceptance'])
archive=dest/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for file in sorted(raw.rglob('*')):
  if file.is_file() and file.suffix in ['.json','.log','.png','.py','.ps1','.msproj']:
   z.write(file,file.relative_to(raw).as_posix())
manifest['archiveBytes']=archive.stat().st_size
manifest['archiveSha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(passed=96,screenshots=104,archiveBytes=archive.stat().st_size)))

