. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:LIBCLANG_PATH='E:/Dev/aem/.tools/python-libclang/clang/native'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
cargo test -p motion-core -p motion-desktop --bin motion-studio --test spatial_key_time --test spatial_keyframes --no-run --features motion-desktop/ffmpeg,motion-host/diagnostics --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target *> E:/Dev/aem/artifacts/issue-goal-current/spatial-gestures/build.log
exit $LASTEXITCODE





