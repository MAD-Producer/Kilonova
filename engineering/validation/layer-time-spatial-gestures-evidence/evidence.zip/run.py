import os, subprocess, json, hashlib, time, re, sys
from pathlib import Path
root=Path(__file__).resolve().parent
exe=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-b34b3a7e7eb835e8.exe')
env=os.environ.copy()
env.pop('MOTION_LOG',None)
env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
env['MOTION_MAPPED_SPATIAL_NATIVE_ARTIFACTS']=str(root/'native')
env['MOTION_MAPPED_SPATIAL_PLAN_ARTIFACTS']=str(root/'faults')
env['MOTION_SPATIAL_TIMELINE_GPU_ARTIFACTS']=str(root/'old-timeline')
env['MOTION_SPATIAL_GRAPH_GPU_ARTIFACTS']=str(root/'old-graph')
env['MOTION_SPATIAL_COMPARISON_GPU_ARTIFACTS']=str(root/'old-comparison')
base='panels::key_selection::tests::ui::spatial::'
groups=[
 ('mapped',[base+'mapped::']),
 ('selection',['panels::key_selection::','--skip',base+'mapped::']),
 ('roving',['panels::animation_menu::roving::tests::']),
 ('native',['--exact',base+'mapped::native::mapped_spatial_native_views_commit_and_reopen','--ignored']),
 ('old-timeline',['--exact',base+'native::native_spatial_timeline_pixels_and_atomic_worker_moves','--ignored']),
 ('old-graph',['--exact',base+'native::native_spatial_graph_pixels_and_atomic_worker_moves','--ignored']),
 ('old-comparison',['--exact',base+'native::native_spatial_comparison_pixels_and_atomic_worker_moves','--ignored']),
]
results=[]
for name,args in groups:
 if len(sys.argv)>1 and name not in sys.argv[1:]:continue
 sha=hashlib.sha256(exe.read_bytes()).hexdigest(); started=time.time()
 with (root/(name+'.log')).open('wb') as f:
  proc=subprocess.run([str(exe),*args,'--nocapture','--test-threads=1'],stdout=f,stderr=subprocess.STDOUT,env=env)
 text=(root/(name+'.log')).read_text(errors='replace')
 match=re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
 row=dict(group=name,args=args,exit=proc.returncode,seconds=round(time.time()-started,3),exe=str(exe),exeSha256=sha)
 if match: row.update(passed=int(match[1]),failed=int(match[2]),ignored=int(match[3]))
 results.append(row)
 (root/('results-'+('-'.join(sys.argv[1:]) or 'all')+'.json')).write_text(json.dumps(results,indent=2))
 print(json.dumps(row),flush=True)
 assert hashlib.sha256(exe.read_bytes()).hexdigest()==sha
 if proc.returncode:raise SystemExit(proc.returncode)
 assert row['passed']>0,'empty test filter'
