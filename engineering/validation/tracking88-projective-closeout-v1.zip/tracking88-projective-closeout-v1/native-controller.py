"""Actual published-head executable consumes the frozen measured tracker output."""
from pathlib import Path
from datetime import datetime, timezone
import copy, hashlib, json, os, re, shutil, struct, subprocess, time

ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-prototype-native-v6'
EVAL=ROOT/'artifacts/pr-queue/tracking88-prototype-synthetic-v5/evaluation'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def require(condition,cause):
    if not condition: raise ValueError(cause)
def now():return datetime.now(timezone.utc).isoformat()
names=subprocess.check_output(['git','ls-files'],cwd=WORK,text=True).splitlines()
sources={n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in names if (WORK/n).is_file()}
report=dict(status='running',startedUtc=now(),controllerPid=os.getpid(),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),source=sources,steps=[])
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
def identity():
    for name,digest in sources.items():require(hashlib.sha256((WORK/name).read_bytes()).hexdigest()==digest,'source changed: '+name)
env=os.environ.copy();env.pop('MOTION_LOG',None)
env.update(CARGO_HOME=str(ROOT/'.tools/prerender-cargo-home'),CARGO_TARGET_DIR=str(ROOT/'target/gltf-animation87-contract'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_BACKTRACE='full',LOCALAPPDATA=str(OUT/'local-appdata'))
EXE=ROOT/'target/gltf-animation87-contract/debug/motion-studio.exe'
project_root=OUT/'project';active=[]
class Rpc:
    def __init__(self,name,readonly=False):
        identity();self.name=name;self.inputs=[];self.raw=[];self.next_id=0
        args=[str(EXE),'--mcp','--project',str(project_root)]+(['--mcp-read-only'] if readonly else [])
        self.row=dict(name=name,command=args,startedUtc=now(),exeSha256=hashlib.sha256(EXE.read_bytes()).hexdigest());report['steps'].append(self.row)
        self.stderr=(OUT/f'{name}.stderr.log').open('wb')
        self.p=subprocess.Popen(args,cwd=WORK,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr,text=True,encoding='utf-8');active.append(self)
        self.row['pid']=self.p.pid;save()
        self.request('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='owned-prototype-native-proof',version='1')))
        self.send(dict(jsonrpc='2.0',method='notifications/initialized'))
    def send(self,message):
        self.inputs.append(message);self.p.stdin.write(json.dumps(message)+'\n');self.p.stdin.flush()
    def request(self,method,params):
        self.next_id+=1;self.send(dict(jsonrpc='2.0',id=self.next_id,method=method,params=params))
        line=self.p.stdout.readline();self.raw.append(line);require(bool(line),self.name+': stdout closed')
        reply=json.loads(line);require(reply.get('jsonrpc')=='2.0' and reply.get('id')==self.next_id and 'error' not in reply,str(reply)[:2000])
        return reply['result']
    def call(self,name,args):return self.request('tools/call',dict(name=name,arguments=args))
    def ok(self,name,args):
        result=self.call(name,args);require(not result['isError'],str(result)[:4000]);return result['structuredContent']
    def state(self):return self.ok('motion_state',{})
    def close(self):
        if self.p.stdin and not self.p.stdin.closed:self.p.stdin.close()
        trailing=self.p.stdout.read();require(not trailing,'unexpected protocol tail')
        self.row['exitCode']=self.p.wait();self.stderr.close();self.row['completedUtc']=now()
        (OUT/f'{self.name}.stdin.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in self.inputs),encoding='utf-8')
        (OUT/f'{self.name}.stdout.jsonl').write_text(''.join(self.raw),encoding='utf-8')
        log=OUT/'local-appdata/MotionStudio/logs/motion-studio.log'
        if log.exists():(OUT/f'{self.name}.file.log').write_bytes(log.read_bytes())
        active.remove(self);save();require(self.row['exitCode']==0,'native exit failure')
def layer(id,name,size,position,color):
    track=lambda v:dict(value=v,keys=[])
    return dict(id=id,name=name,content=dict(kind='solid',color=color),size=size,
        transform=dict(position=track(position),rotation=track([0.,0.,0.]),scale=track([100.,100.,100.]),opacity=track(1.),anchor=[.5,.5]),
        visible=True,locked=False,solo=False,effects_enabled=True,shy=False,three_d=False,
        sampling=dict(frame_blend='hold',motion_blur=None,continuous_rasterization=False),rotation_order='local_xyz',effects=[],
        blend=dict(mode='normal',space='linear'),timeline=dict(in_frame=0,out_frame=500,offset_frame=0),audio_source_channel='stereo')
def project(matrix,point):
    x,y=point;den=matrix[2][0]*x+matrix[2][1]*y+matrix[2][2]
    return [(matrix[0][0]*x+matrix[0][1]*y+matrix[0][2])/den,(matrix[1][0]*x+matrix[1][1]*y+matrix[1][2])/den]
save()
try:
    args=['cargo','build','-p','motion-desktop','--bin','motion-studio','--features','ffmpeg','--locked','--offline']
    row=dict(name='current-source-native-build',command=args,startedUtc=now());report['steps'].append(row);save()
    with (OUT/'build.stdout.log').open('wb') as stdout,(OUT/'build.stderr.log').open('wb') as stderr:
        child=subprocess.Popen(args,cwd=WORK,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();row['exitCode']=child.wait()
    row['completedUtc']=now();save();require(row['exitCode']==0,'native build failed');identity()
    boot=Rpc('bootstrap');p=boot.state()['project'];boot.close()
    p.update(width=256,height=192,fps=125,frames=500,work_area=dict(in_frame=0,out_frame=500),background=[.02,.02,.02,1.])
    source=project_root/'assets/plate.webm';source.parent.mkdir(exist_ok=True);shutil.copyfile(EVAL/'motion.webm',source)
    original=(EVAL/'motion-tracking/tracks.mstrack').read_bytes();solve=json.loads(original)
    require(hashlib.sha256(source.read_bytes()).hexdigest()==solve['source_sha256'],'frozen original identity changed')
    pts=solve['source_pts'];ticks=solve['ticks_per_second'];truth=json.loads((EVAL/'independent-truth.json').read_text())['matrices']
    p['video_assets']=[dict(id=1,path='assets/plate.webm',bytes=source.stat().st_size,mime='video/x-vnd.on2.vp9',track=0,width=256,height=192,rotation=0,display_width=256,display_height=192,video_start_us=0,video_end_us=4000000,duration_us=4000000,frame_count=96,variable_frame_rate=True,nominal_frame_rate=24.,color_standard=1,color_range=2,audio_asset=None)]
    video=layer(600,'Original measured plate',[256.,192.],[128.,96.,0.],[1.,1.,1.,1.]);video['content']=dict(kind='video',video=dict(asset=1,source_offset_us=0,volume=1.,muted=True))
    p['layers']=[video]
    (project_root/'project.json').write_text(json.dumps(p),encoding='utf-8')
    cache=project_root/'cache/video-v2/plate/index.pts';cache.parent.mkdir(parents=True)
    cache.write_bytes(b'MSVID001'+struct.pack('<Q',source.stat().st_size)+b''.join(struct.pack('<Q',v*1000000//ticks) for v in pts))
    document=OUT/'original.mstrack';document.write_bytes(original)
    live=Rpc('prototype-binding');before=live.state()
    imported=live.ok('import_tracking',dict(path=str(document),source=dict(kind='video',id=1),expectedRevision=before['revision'],expectedDocumentGeneration=before['document_generation']))
    require(imported['trackingImport']['decodedTimelineVerified'] is True,'native original timeline not verified')
    descriptor=imported['project']['tracking_assets'][0]
    require(descriptor['id']==2 and (project_root/descriptor['path']).read_bytes()==original,'native import did not preserve measured output')
    report['nativeImport']=imported['trackingImport'];save()
    def edit(commands):return live.ok('motion_edit',dict(commands=commands,expectedRevision=live.state()['revision']))
    def capture(frame,name):
        began=time.monotonic()
        while True:
            result=live.call('render_preview',dict(frame=frame))
            if not result['isError']:
                destination=OUT/(name+'.png');shutil.copyfile(result['structuredContent']['path'],destination);return destination
            message=result['content'][0]['text']
            require('video capture pending; request frames and retry' in message and time.monotonic()-began<30.,message)
            time.sleep(.01)
    native_video=capture(0.,'native-original')
    from PIL import Image
    import numpy as np
    pixels=np.array(Image.open(native_video).convert('RGB'))
    require(pixels.shape==(192,256,3) and pixels.std()>20.,'actual native original video is blank')
    # Isolate measured tracking layers from the plate for an independent pixel oracle.
    edit([dict(op='delete',object=600)])
    plane=layer(700,'Automatically measured plane',[128.,104.],[96.,76.,0.],[0.,1.,0.,1.])
    manifest=json.loads((WORK/'crates/motion-effects/builtin-library/manifest.json').read_text())
    definition=next(e for e in manifest['effects'] if e['id']=='corner_pin');params={}
    for param in definition['params']:
        value=param['default'].copy()
        if param.get('relative_default') is not None:value[:2]=[param['relative_default'][i]*plane['size'][i] for i in range(2)]
        params[param['id']]=dict(kind=param['kind'],animatable=param['animatable'],min=param['min'],max=param['max'],implemented=param['implemented'],default=value,track=dict(value=value,keys=[]))
    plane['effects']=[dict(id=99,plugin=manifest['id'],effect='corner_pin',version=manifest['version'],hash=hashlib.sha256((WORK/'crates/motion-effects/builtin-library/builtin-effects.msfx').read_bytes()).hexdigest(),enabled=True,seed=99,params=params)]
    marker=layer(701,'Automatically measured point',[7.,7.],[80.,70.,0.],[1.,0.,0.,1.])
    edit([dict(op='add',layer=plane),dict(op='add',layer=marker)])
    common=dict(asset=2,anchor_local_frame=0,source_anchor_pts=pts[0],speed_numerator=1,speed_denominator=1,rotation='none',interpolation='linear',max_gap_ticks=50,minimum_confidence=0.,missing='error')
    pb=dict(common,track='plane',effect=99,reference_quad=[[32.,24.],[160.,24.],[160.,128.],[32.,128.]],crop=[32.,24.,128.,104.])
    qb=dict(common,track='feature',reference_pixels=[80.,70.],crop=[0.,0.,256.,192.])
    commands=[dict(op='set_tracking_plane',object=700,binding=pb),dict(op='set_tracking_point',object=701,binding=qb)]
    bound=edit(commands)['project']
    undone=live.ok('motion_history',dict(operation='undo'))['project'];require(all(l.get('tracking_plane') is None and l.get('tracking_point') is None for l in undone['layers']),'binding undo failed')
    require(live.ok('motion_history',dict(operation='redo'))['project']==bound,'binding redo differs')
    plane_samples=next(t for t in solve['tracks'] if t['id']=='plane')['samples'];point_samples=next(t for t in solve['tracks'] if t['id']=='feature')['samples']
    rows=[]
    def verify(index,label,images=True,expected_render_error=None):
        frame=(pts[index]-pts[0])*125./ticks
        state=live.ok('motion_seek',dict(frame=frame));require(state['renderError']==expected_render_error,'unexpected current or retained render error: '+str(state['renderError']))
        anchor=next(l['anchor'] for l in state['projectedLayers'] if l['id']==701)
        wanted=point_samples[index]['observation']['pixels'];require(max(abs(anchor[i]-wanted[i]) for i in range(2))<.001,'native point differs from measured sample')
        values=next(e['values'] for e in state['sampledEffects'] if e['layer']==700 and e['instance']==99)
        quad=[project(plane_samples[index]['observation']['matrix'],point) for point in pb['reference_quad']]
        for key,point in zip(('tl','tr','br','bl'),quad):require(max(abs(values[key][i]-(point[i]-(32.,24.)[i])) for i in range(2))<.001,'native plane differs from measured sample')
        row=dict(index=index,frame=frame,anchor=anchor,measuredPoint=wanted,quad=quad,sampled=values)
        if images:
            destination=capture(frame,label);row['image']=str(destination)
            image=np.array(Image.open(destination).convert('RGB'))
            y,x=np.mgrid[0:192,0:256];x=x+.5;y=y+.5
            inside=np.ones((192,256),bool);stable=np.ones_like(inside)
            for a,b in zip(quad,quad[1:]+quad[:1]):
                cross=(b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0]);distance=cross/np.hypot(b[0]-a[0],b[1]-a[1])
                inside&=cross>0;stable&=np.abs(distance)>2.
            stable&=(np.abs(x-wanted[0])>6.)|(np.abs(y-wanted[1])>6.)
            seen=(image[:,:,1]>180)&(image[:,:,0]<40)&(image[:,:,2]<40)
            errors=int(np.count_nonzero(stable&(inside!=seen)));interior=int(np.count_nonzero(stable&inside))
            require(interior>5000 and errors==0,'native plane pixel mismatch '+str((index,interior,errors)))
            red=(image[:,:,0]>180)&(image[:,:,1]<40)&(image[:,:,2]<40)
            require(int(red.sum())>=25,'native point marker absent')
            cy,cx=np.where(red);require(max(abs(float(cx.mean()+.5)-wanted[0]),abs(float(cy.mean()+.5)-wanted[1]))<.75,'native point pixels do not align')
            row['pixelOracle']=dict(planeInterior=interior,mismatched=errors,pointPixels=int(red.sum()),edgeExclusionPixels=2.)
        rows.append(row);report['samples']=rows;save()
    # At 125 fps, every original millisecond PTS maps exactly to an eighth frame.
    # This tests a different composition FPS without epsilon rounding at missing boundaries.
    for index in (0,10,19,30,40,60,95):verify(index,'measured-'+str(index))
    # Strict missing policy must refuse authored occlusion and recovered samples must work.
    live.ok('motion_seek',dict(frame=0.))
    failed=live.call('motion_seek',dict(frame=pts[22]*125./ticks));require(failed['isError'] and all(message in failed['content'][0]['text'] for message in ('tracking_plane phase=sample object=700 asset=2 track=plane', 'plane observation unavailable source_index=22 visibility=Lost')),'occluded measured data was silently invented')
    retained_error=failed['content'][0]['text']
    verify(30,'manual-resume-after-error',True,retained_error)
    report['recovery']=dict(strictMissingError=retained_error,retainedHistoricalError=live.state()['renderError'],currentSampleAndPixelsVerified=True)
    require(report['recovery']['retainedHistoricalError']==retained_error,'the primary error was cleared or replaced')
    require(live.state()['project']['tracking_assets'][0]['data']==bound['tracking_assets'][0]['data'],'native binding modified raw solve')
    live.ok('motion_save',{});live.close();document.unlink()
    reopen=Rpc('readonly-reopen',True)
    require(reopen.state()['project']==bound,'native save/reopen changed project or original correction states')
    require((project_root/descriptor['path']).read_bytes()==original,'managed original solve changed')
    reopen.close()
    live=Rpc('reopened-render')
    verify(40,'reopened-measured-40')
    live.close()
    log=(OUT/'prototype-binding.file.log').read_text(encoding='utf-8');stderr=(OUT/'prototype-binding.stderr.log').read_text(encoding='utf-8',errors='replace')
    require(re.search(r'start #\d+ import_tracking',log) is not None,'default Info start absent')
    require(all('plane observation unavailable source_index=22 visibility=Lost' in sink for sink in (log,stderr)),'native missing error not present in both sinks')
    identity();report.update(status='accepted_measured_native_import_binding_gpu_history_persistence_real_motion_pending',sourceSha256=solve['source_sha256'],solveSha256=hashlib.sha256(original).hexdigest())
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:
    for rpc in list(active):
        try:rpc.close()
        except BaseException as secondary:report.setdefault('cleanupFailures',[]).append(repr(secondary))
    report['completedUtc']=now();save()
