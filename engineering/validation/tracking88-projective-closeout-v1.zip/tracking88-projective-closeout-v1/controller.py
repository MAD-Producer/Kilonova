"""Serial, source-bound controls, full tools, synthetic, real and native proof."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-projective-closeout-v1'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
names=('plate_contract.py','plate_flow.py','track_plate.py','test_flow.py','validate_prototype.py')
sources={name:digest(WORK/'tools/tracking'/name) for name in names}
for name in names:(OUT/name).write_bytes((WORK/'tools/tracking'/name).read_bytes())
controllers=ROOT/'.tools/issue-closure-review'
synthetic=(controllers/'accept-tracking88-prototype-synthetic-v4.py').read_text().replace('synthetic-v4','synthetic-v5')
(OUT/'synthetic-controller.py').write_text(synthetic)
real=(controllers/'measure-tracking88-photographed-v5.py').read_text().replace('photographed-prototype-v5','photographed-prototype-v6')
(OUT/'real-controller.py').write_text(real)
native=(controllers/'accept-tracking88-prototype-native-v5.py').read_text().replace('native-v5','native-v6').replace('synthetic-v4','synthetic-v5').replace('published-native-build','current-source-native-build')
(OUT/'native-controller.py').write_text(native)
report=dict(status='running',pid=os.getpid(),startedUtc=datetime.now(timezone.utc).isoformat(),
    gitHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),
    dirtySources=True,sourceFiles=sources,steps=[])
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2))
save()
cv=ROOT/'.tools/ai-depth74/venv/Scripts/python.exe'
ci=ROOT/'.tools/ui-pr-validation-env/Scripts/python.exe'
steps=[('flow-controls',[str(cv),'tools/tracking/test_flow.py','-v']),
       ('tools-regression',[str(ci),'-m','unittest','discover','-s','tools','-p','test_ci_*.py','-v']),
       ('synthetic',[str(cv),str(OUT/'synthetic-controller.py')]),
       ('photographed',[str(cv),str(OUT/'real-controller.py')]),
       ('native',[str(cv),str(OUT/'native-controller.py')])]
try:
    for phase,command in steps:
        print('start '+phase,flush=True)
        row=dict(phase=phase,command=command);report['steps'].append(row);save()
        with (OUT/(phase+'.stdout.log')).open('wb') as stdout,(OUT/(phase+'.stderr.log')).open('wb') as stderr:
            child=subprocess.Popen(command,cwd=WORK,stdout=stdout,stderr=stderr);row['pid']=child.pid;save();row['exitCode']=child.wait()
        for name,sha in sources.items():assert digest(WORK/'tools/tracking'/name)==sha,'source changed: '+name
        save();assert row['exitCode']==0,phase+' failed'
        print('done '+phase,flush=True)
    report['status']='controls_synthetic_native_pass_real_measured_not_accepted'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
