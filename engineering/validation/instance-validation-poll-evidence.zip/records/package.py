import hashlib
import json
from pathlib import Path
import re
import zipfile

root = Path('E:/Dev/aem/.worktrees/instance-validation-poll')
out = Path(__file__).parent
sha = lambda data: hashlib.sha256(data).hexdigest()
render = json.loads((out / 'render-final.json').read_text(encoding='utf-8'))
desktop = json.loads((out / 'desktop-default-final.json').read_text(encoding='utf-8'))
for record in [render, desktop]:
    assert record['exit'] == 0 and 'source_changed_during_run' not in record
    for file, digest in record['sources'].items():
        assert sha((root / file).read_bytes()) == digest, file
counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out', (out / 'render-final.stdout').read_text(encoding='utf-8'))
assert len(counts) == 4 and sum(int(row[0]) for row in counts) == 316
assert all(all(int(value) == 0 for value in row[1:]) for row in counts)
assert 'test result: ok. 2 passed; 0 failed; 0 ignored;' in (out / 'desktop-default-final.stdout').read_text(encoding='utf-8')
negative = json.loads((out / 'final-tests-restored-wait-negative.json').read_text(encoding='utf-8'))
assert negative['exit'] == 101
test = 'crates/motion-render/src/effect_gpu/instance_data/tests.rs'
assert negative['sources'][test] == render['sources'][test]
assert '0 passed; 4 failed;' in (out / 'final-tests-restored-wait-negative.stdout').read_text(encoding='utf-8')
assert (out / 'instance_data.fixed.rs').read_bytes() == (root / 'crates/motion-render/src/effect_gpu/instance_data.rs').read_bytes()
channels = []
for mode in ['portable', 'native', 'warm-cache/portable', 'warm-cache/native']:
    folder = out / 'native-default' / mode
    counts = []
    for file in ['logs/motion-studio.log', 'stderr.txt', 'stdout.txt']:
        text = (folder / file).read_text(encoding='utf-8')
        counts.append(sum('motion_render::pointwise_compile' in line and 'phase=failure' in line for line in text.splitlines()))
    assert counts == [1, 1, 0], (mode, counts)
    channels.append({'scenario': mode, 'fileErrorStderrStdoutFailureCounts': counts})
executables = re.findall(r'Running unittests.*\(([^\r\n]+\.exe)\)', (out / 'desktop-default-final.stderr').read_text(encoding='utf-8'))
assert len(executables) == 1
exe = Path(executables[0])
summary = {'parent': '6b0bbeb5ee96b77249dfaa0ef386d02cf3835790', 'renderTests': 316, 'desktopParentTests': 2, 'distinctTests': 318, 'childScenariosIncludedInParentTests': channels, 'negativeRestoredWaitFailures': 4, 'defaultLogEnvironment': desktop['environment']['MOTION_LOG'], 'desktopExecutable': {'path': str(exe), 'bytes': exe.stat().st_size, 'sha256': sha(exe.read_bytes())}, 'limits': ['Existing compiler channel regression is not instance-binding failure through Engine.', 'Synthetic secondary PollError is not a reproduced hardware failure.', 'No end-to-end UI responsiveness or frame allocation acceptance is claimed.']}
(out / 'test-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
members = {}
for file in out.iterdir():
    if file.suffix in ['.json', '.stdout', '.stderr', '.rs', '.py'] and file.name not in ['archive-receipt.json', 'pr-created.json']:
        members['records/' + file.name] = file.read_bytes()
for folder in ['frame-imports', 'native-default']:
    for file in (out / folder).rglob('*'):
        if file.is_file() and file.suffix in ['.json', '.txt', '.log']:
            members['records/' + file.relative_to(out).as_posix()] = file.read_bytes()
for file in desktop['sources']:
    members['source/' + file] = (root / file).read_bytes()
members['manifest.json'] = json.dumps({name: {'bytes': len(data), 'sha256': sha(data)} for name, data in members.items()}, indent=2).encode()
archive = root / 'engineering/validation/instance-validation-poll-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, data in members.items():
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, data in members.items():
        assert z.read(name) == data
receipt = {'members': len(members), 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()), 'summary': summary}
(out / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt))
