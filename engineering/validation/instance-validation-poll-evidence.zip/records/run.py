import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('E:/Dev/aem/.worktrees/instance-validation-poll')
out = Path(__file__).parent
phase = sys.argv[1]
command = sys.argv[2:]
sources = {}
for file in ['crates/motion-render/src/effect_gpu/instance_data.rs', 'crates/motion-render/src/effect_gpu/instance_data/tests.rs', 'crates/motion-render/tests/frame_image_imports.rs', 'crates/motion-render/tests/support/import_fixture.rs', 'crates/motion-render/src/effect_gpu.rs', 'desktop/app/src/logging.rs', 'desktop/app/src/logging/pointwise_compile_tests.rs']:
    sources[file] = hashlib.sha256((root / file).read_bytes()).hexdigest()
start = time.time()
with (out / (phase + '.stdout')).open('wb') as stdout, (out / (phase + '.stderr')).open('wb') as stderr:
    result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr)
record = {'command': command, 'exit': result.returncode, 'elapsed_seconds': time.time() - start, 'sources': sources, 'environment': {k: os.environ.get(k) for k in ['CARGO_TARGET_DIR', 'MOTION_EXECUTION_ARTIFACTS', 'MOTION_POINTWISE_FILE_ARTIFACTS', 'MOTION_LOG']}}
for file, sha in sources.items():
    if hashlib.sha256((root / file).read_bytes()).hexdigest() != sha:
        record['source_changed_during_run'] = file
(out / (phase + '.json')).write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps(record), flush=True)
print((out / (phase + '.stdout')).read_text(encoding='utf-8', errors='replace')[-7000:], flush=True)
print((out / (phase + '.stderr')).read_text(encoding='utf-8', errors='replace')[-2000:], flush=True)
