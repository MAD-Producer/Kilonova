import hashlib,json,os,subprocess
from pathlib import Path
root=Path('E:/Dev/aem/.worktrees/layer-time-mapping');out=Path(__file__).parent
path=root/'desktop/app/src/panels/frame_cache.rs';original=path.read_bytes();text=original.decode('utf-8')
start=text.index('        if entry.size != size.map(f32::to_bits) {',text.index('pub(super) fn get('));end=text.index('        Some(entry.values.clone())',start)
altered=text[:start]+text[end:]
try:
 path.write_bytes(altered.encode('utf-8'))
 script=out/'build-negative-stale.ps1';script.write_text((out/'build-app.ps1').read_text('utf-8').replace('/app-build.','/negative-stale-build.'),'utf-8')
 result=subprocess.run(['pwsh','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script)],cwd=root);assert result.returncode==0
 rows=[json.loads(l) for l in (out/'negative-stale-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')];exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
 env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH'];env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp';env.pop('MOTION_LAYOUT_COST_EVIDENCE',None)
 command=[exe,'--exact','panels::workload_tests::real_presets_resize_maximize_and_tab_changes_invalidate_once_without_stale_geometry','--nocapture'];result=subprocess.run(command,env=env,capture_output=True)
 (out/'negative-stale.stdout').write_bytes(result.stdout);(out/'negative-stale.stderr').write_bytes(result.stderr)
 receipt={'kind':'actual cache lookup ignores layout/size identity','command':command,'exit':result.returncode,'executable_sha256':hashlib.sha256(Path(exe).read_bytes()).hexdigest()};(out/'negative-stale.json').write_text(json.dumps(receipt,indent=2),'utf-8');print(json.dumps(receipt),flush=True);assert result.returncode==101
finally:
 path.write_bytes(original);assert path.read_bytes()==original
 (out/'stale-control-restored.json').write_text(json.dumps({'path':str(path.relative_to(root)),'sha256':hashlib.sha256(original).hexdigest()},indent=2),'utf-8')
