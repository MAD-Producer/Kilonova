import hashlib,json,os,subprocess
from pathlib import Path
root=Path('E:/Dev/aem/.worktrees/layer-time-mapping');out=Path(__file__).parent
paths={kind:root/path for kind,path in [('cache','desktop/app/src/panels/mod.rs'),('double-chrome','desktop/app/src/shell/presentation.rs')]};originals={k:p.read_bytes() for k,p in paths.items()}
try:
 for kind,path in paths.items():
  original=originals[kind];text=original.decode('utf-8')
  if kind=='cache':
   needle='pub fn frames(layout: &Node, size: [f32; 2]) -> Vec<Frame> {';assert text.count(needle)==1
   altered=text.replace(needle,needle+'\n    FRAME_CACHE.with(|slot| *slot.borrow_mut() = frame_cache::Cache::new());')
  else:
   needle='        if self.home.is_some() {\n            panels::titlebar::render(';assert text.count(needle)==1
   extra='''        if self.home.is_none() {
            let _ = panels::chrome(&mut paint, &mut self.atlas, size,
                self.workspace.display_root(), &mut self.panels, &self.state, &Input::default());
        }
'''
   altered=text.replace(needle,extra+needle)
  path.write_bytes(altered.encode('utf-8'))
  try:
   script=out/('build-negative-'+kind+'.ps1');script.write_text((out/'build-app.ps1').read_text('utf-8').replace('/app-build.','/negative-'+kind+'-build.'),'utf-8')
   result=subprocess.run(['pwsh','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script)],cwd=root);assert result.returncode==0
   rows=[json.loads(l) for l in (out/('negative-'+kind+'-build.jsonl')).read_text('utf-8-sig').splitlines() if l.startswith('{')];exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
   env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH'];env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp';env.pop('MOTION_WORKSPACE_COST_EVIDENCE',None)
   command=[exe,'--exact','panels::workload_tests::complete_shell_drag_frames_match_static_work_and_solve_once_for_each_stable_layout','--nocapture'];result=subprocess.run(command,env=env,capture_output=True)
   (out/('negative-'+kind+'.stdout')).write_bytes(result.stdout);(out/('negative-'+kind+'.stderr')).write_bytes(result.stderr);assert result.returncode==101
   receipt={'kind':kind,'command':command,'exit':result.returncode,'executable_sha256':hashlib.sha256(Path(exe).read_bytes()).hexdigest()};(out/('negative-'+kind+'.json')).write_text(json.dumps(receipt,indent=2),'utf-8');print(json.dumps(receipt),flush=True)
  finally:
   path.write_bytes(original);assert path.read_bytes()==original
finally:
 for kind,path in paths.items():
  path.write_bytes(originals[kind]);assert path.read_bytes()==originals[kind]
 (out/'controls-restored.json').write_text(json.dumps({str(path.relative_to(root)):hashlib.sha256(originals[kind]).hexdigest() for kind,path in paths.items()},indent=2),'utf-8')
