import hashlib,json,os,subprocess
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(l) for l in (p/'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH'];env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp';env['MOTION_WORKSPACE_COST_EVIDENCE']=str(p/'costs.json')
command=[exe,'--exact','panels::workload_tests::complete_shell_drag_frames_match_static_work_and_solve_once_for_each_stable_layout','--test-threads=1','--nocapture']
r=subprocess.run(command,env=env,capture_output=True);(p/'cost-test.stdout').write_bytes(r.stdout);(p/'cost-test.stderr').write_bytes(r.stderr);(p/'cost-test.json').write_text(json.dumps({'command':command,'exit':r.returncode,'executable_sha256':hashlib.sha256(Path(exe).read_bytes()).hexdigest(),'runtime_stack_override':False},indent=2),'utf-8');print(r.stdout.decode('utf-8',errors='replace')[-3000:]);print(r.stderr.decode('utf-8',errors='replace')[-3000:]);assert r.returncode==0
