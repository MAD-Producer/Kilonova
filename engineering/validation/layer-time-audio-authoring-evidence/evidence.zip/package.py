import hashlib, json, re, shutil, zipfile
from pathlib import Path

root=Path(__file__).resolve().parent
repo=Path.cwd()
dest=repo/'engineering/validation/layer-time-audio-authoring-evidence'
dest.mkdir(exist_ok=True)
hash_file=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((root/'source-hashes.json').read_text())
for name,digest in sources.items():
    assert hash_file(repo/name)==digest,name
groups=[]
unique=set()
for name,binary in [('core','core-tested.exe'),('audio','tested.exe'),('effects','pre-font-test.exe'),('properties','pre-font-test.exe'),('numeric','pre-font-test.exe'),('native','tested.exe')]:
    text=(root/(name+'.log')).read_text(errors='replace')
    assert 'test result: ok.' in text and 'test result: FAILED' not in text,name
    passed=re.findall(r'^test (\S+) \.\.\. ok$',text,re.M)
    ignored=re.findall(r'^test (\S+) \.\.\. ignored.*$',text,re.M)
    unique.update(passed)
    groups.append(dict(group=name,binary=binary,passed=passed,ignored=ignored))
assert len(list((root/'native').rglob('*.png')))==24
assert len(list((root/'native').rglob('reopened.json')))==8
first=json.loads((root/'native/capture-process.json').read_text())
second=json.loads((root/'native/reopen-process.json').read_text())
assert first['pid']!=second['pid']
checks=json.loads((root/'checks.json').read_text())
assert all(value==0 for value in checks.values()),checks
for source,name in [('Zh-false-false/committed.png','audio-main-zh.png'),('En-true-true/committed.png','audio-floating-en.png')]:
    shutil.copyfile(root/'native'/source,dest/name)
archive=dest/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.suffix.lower() in {'.log','.json','.ps1','.py','.png','.wav'}:
            z.write(p,p.relative_to(root).as_posix())
manifest=dict(issue=257,stage='exact-time audio envelope authoring and navigation',base='d66bd83ca7719030b6fc8eb10cee6f9d3b266d39',branch='feat/layer-time-mapping',sourceHashes=sources,checks=checks,passed=len(unique),testResults=groups,unrunManual=sorted({name for group in groups for name in group['ignored']}-unique),
    binaries=[dict(path=str(root/name),sha256=hash_file(root/name),bytes=(root/name).stat().st_size) for name in ['core-tested.exe','pre-font-test.exe','tested.exe']],
    binaryScope='Only new mapped audio test fixture font selection differs between pre-font-test.exe and tested.exe; unchanged production sources. Effects/properties/numeric groups were not needlessly repeated.',
    native=dict(cases=8,screenshots=24,separateProcessReopens=8,capturePid=first['pid'],reopenPid=second['pid'],input='synthetic Input through production main/floating chrome; real native GPU capture, not physical mouse input or an audio device'),
    originalFailures=['initial-core.log and initial-ui.log: raw clip fixture in=0 offset=2 invalid recoverable source interval','fixture-storage-failure.log: missing audio asset and invalid remap on solid negative control','compiler-heap-failure.log: rustc STATUS_HEAP_CORRUPTION','audio-initial-timeout.log: existing waveform controlled-panic wait deadline failed; same assertion rerun after compilation','initial-native/: first captures used non-language-specific fixture font, Chinese text missing; not accepted as final visuals'],
    normalBranches=['optional envelope means unity','fractional local time disables integer key insertion','focus or time-context cancellation rolls back once'],
    observationSites=['audio.numeric_time_begin','audio.numeric_time_continue','audio.rail_times','audio.rail_select_navigate','audio.rail_select_toggle','audio.navigation_time'],
    limits=['Windows only','no real audio device or DSP/pitch verification in this stage','pre-existing compiler warnings and Epic Overlay missing Vulkan JSON errors retained','DESIGN baseline retained, no product-wide visual compliance claim','issue 257 remains open'],
    archive=dict(file='evidence.zip',sha256=hash_file(archive),bytes=archive.stat().st_size))
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(passed=len(unique),archiveBytes=archive.stat().st_size,sources=len(sources)),ensure_ascii=False))
