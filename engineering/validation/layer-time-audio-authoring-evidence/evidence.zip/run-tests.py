import os, subprocess, json, time, sys
from pathlib import Path

root = Path(__file__).resolve().parent
target = Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps')
env = os.environ.copy()
env['TEMP'] = env['TMP'] = 'E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + env['PATH']
env.pop('MOTION_LOG', None)
env['MOTION_AUDIO_AUTHORING_ARTIFACTS'] = str(root/'native')
env['MOTION_AUDIO_AUTHORING_FAULT_ARTIFACTS'] = str(root/'faults')
tests = [
 ('core', target/'track_at-cb45ee6ee68bb498.exe', []),
 ('audio', target/'motion_studio-b34b3a7e7eb835e8.exe', ['panels::audio::']),
 ('effects', target/'motion_studio-b34b3a7e7eb835e8.exe', ['panels::effect_controls::']),
 ('properties', target/'motion_studio-b34b3a7e7eb835e8.exe', ['panels::properties::']),
 ('numeric', target/'motion_studio-b34b3a7e7eb835e8.exe', ['panels::numeric::']),
 ('waveform-followup', target/'motion_studio-b34b3a7e7eb835e8.exe', ['--exact','panels::audio::waveform::tests::audio_waveform_blocked_and_panicking_handlers_publish_state_and_default_diagnostics']),
 ('native', target/'motion_studio-b34b3a7e7eb835e8.exe', ['--exact','panels::audio::tests::mapped::native::native_audio_envelopes_keep_exact_time_and_cancel_in_both_owners_and_languages','--ignored']),
]
results=[]
for name, exe, args in tests:
    if len(sys.argv) > 1 and name not in sys.argv[1:]: continue
    start=time.time()
    with (root/(name+'.log')).open('wb') as log:
        result=subprocess.run([str(exe), *args, '--nocapture', '--test-threads=1'],env=env,stdout=log,stderr=subprocess.STDOUT)
    row=dict(name=name,exit=result.returncode,elapsedSeconds=round(time.time()-start,3))
    results.append(row)
    (root/('test-results'+('-'+'-'.join(sys.argv[1:]) if len(sys.argv)>1 else '')+'.json')).write_text(json.dumps(results,indent=2))
    print(json.dumps(row),flush=True)
    if result.returncode: break
raise SystemExit(any(x['exit'] for x in results))
