import hashlib, subprocess, json
from pathlib import Path
repo=Path.cwd()
root=Path(__file__).resolve().parent
files=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())
files.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
hashes={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in sorted(files) if p.endswith('.rs')}
path=root/'source-hashes.json'
if path.exists():
    assert json.loads(path.read_text())==hashes, 'source changed since freeze'
else:
    path.write_text(json.dumps(hashes,indent=2))
print(f'{len(hashes)} source hashes verified')
