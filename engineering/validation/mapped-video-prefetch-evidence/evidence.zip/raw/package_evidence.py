import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path('E:/Dev/aem/.worktrees/layer-time-mapping')
RAW = Path('E:/Dev/aem/artifacts/issue-goal-current/mapped-prefetch')
OUT = ROOT / 'engineering/validation/mapped-video-prefetch-evidence'
TARGET = Path('E:/Dev/aem/.tools/viewer-inspection/native-target')
SOURCES = [
    'crates/motion-host/src/video_cache.rs',
    'crates/motion-host/src/video_frames.rs',
    'crates/motion-host/src/video_frames/mapped_prefetch.rs',
    'crates/motion-host/src/video_frames/mapped_prefetch/tests.rs',
    'desktop/app/src/engine.rs',
    'desktop/app/src/engine/mapped_video_prefetch_tests.rs',
    'engineering/validation/mapped-video-prefetch.md',
]

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def read(path):
    data = path.read_bytes()
    return data.decode('utf-16' if data[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig')

results = {}
for key, stem in [('host_video', 'host-video-final'), ('native_ffmpeg', 'app-tests-final'), ('workspace', 'workspace-final')]:
    code = int(read(RAW / (stem + '.exit')).strip())
    assert code == 0, (key, code)
    results[key] = {'exit_code': code, 'log': stem + '.log'}
report = json.loads(read(RAW / 'native-report-final.json'))
assert len(report) == 8 and sum(item['points'] for item in report) == 64
fault = RAW / 'fault-final'
channels = {}
for path in fault.rglob('*'):
    if path.is_file():
        channels[str(path.relative_to(fault))] = read(path).count('site=video_prefetch_plan')
assert sorted(channels.values()) == [0, 2, 2], channels
manifest = {
    'base_commit': '9d085c0f1fb63106babb48d5781b700e20da6eac',
    'branch': 'fix/mapped-video-prefetch',
    'issue': 257,
    'issue_complete': False,
    'results': results,
    'host_video_tests_passed': 46,
    'native_ffmpeg_tests_passed': 2,
    'native_sample_points': 64,
    'default_level_fault_channel_record_counts': channels,
    'commands': [
        'cargo test -p motion-host --lib --features diagnostics --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target video_ -- --test-threads=1',
        'cargo test -p motion-desktop --bin motion-studio --features ffmpeg,motion-host/diagnostics --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target engine::mapped_video_prefetch_tests:: -- --test-threads=1 --nocapture',
        'cargo check --workspace --all-targets --exclude motion-android --locked --features motion-desktop/ffmpeg,motion-host/diagnostics --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target',
    ],
    'environment': {'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0', 'MOTION_LOG_fault_test': 'unset (default info)', 'ffmpeg': 'ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'},
    'source_sha256': {name: sha(ROOT / name) for name in SOURCES},
    'binary_sha256': {name: sha(TARGET / 'debug/deps' / name) for name in ['motion_studio-b34b3a7e7eb835e8.exe', 'motion_host-c9a9d3369fb6fb6e.exe']},
    'ci': {'followup': 'pending at submission', 'base_run': 'https://github.com/MAD-Producer/Kilonova/actions/runs/41414993528'},
    'limits': ['Only currently sampled instances are predicted; no decoder creation for upcoming inactive layers.', 'Exact/export APIs do not enable speculative lookahead.', 'No UI acceptance claimed; no user-visible UI changes.'],
    'first_failures': {'host-build.exit': 101, 'native-tests-first.exit': 101},
}
OUT.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(OUT / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(RAW.rglob('*')):
        if path.is_file():
            archive.write(path, 'raw/' + path.relative_to(RAW).as_posix())
    for name in SOURCES:
        archive.write(ROOT / name, 'final-source/' + name)
manifest['evidence_zip_sha256'] = sha(OUT / 'evidence.zip')
(OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'results': results, 'channels': channels, 'zip_bytes': (OUT / 'evidence.zip').stat().st_size}))
