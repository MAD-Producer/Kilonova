图层伸缩、倒放和素材时间重映射此前缺少统一的属性时间寻址，编辑还可能把局部关键帧取整到相邻键。本改动建立共享图层时钟，让视频、音频和桌面编辑使用同一时间映射。

关联 #257，提交已完成阶段供审查，issue 保持打开。

实现范围：

- 图层时钟、伸缩／倒放／重映射命令、持久化及可见入口。视频与音频覆盖嵌套采样、冻结和倒放末样本；音频采用音高随速度变化策略。
- 局部关键帧身份贯通时间轴投影、拖动、吸附、复制粘贴、缓动和曲线手柄；空间键按稳定 ID 编辑，不用取整值寻找邻键。首次 Roving 转换只在来源、revision 与完整目标轨道匹配时认领结果，失败批次回滚。
- 属性数值、小曲线编辑器、三维轴／平面手柄及二维／三维自由拖动保留连续空间键身份。Roving 重排时间后继续修改原键，目标失效时取消预览。
- 自由拖动宿主使用捕获键的值及实际祖先变换保持屏幕位移；普通映射位置和分离维度按精确作者局部帧写入。效果拾取、路径导航、矢量／蒙版参数、音量及摄影机参数也使用精确属性时间。

自由拖动阶段验证：

- 同一最终二进制 53 个不同用例通过，覆盖二维／三维、普通／正放／倒放、固定／Roving、连续三次预览、完整工程、取消、保存重开和一次撤销重做。
- Windows 实际 GPU：中文主窗二维正放、英文浮窗三维倒放，六张修改前／后／独立进程重开截图；既有轴手柄原生用例也重新通过。两个其他手工原生用例未运行，不宣称全平台验收。
- 真实缺失键故障经普通 drag 和 viewer_drag 验证默认文件日志、Error stderr、stdout 隔离、完整工程／revision／history 不变及恢复；原有错误观察阈值和 worker 协议保留。
- 带 FFmpeg workspace all-targets 检查、最终测试程序编译、样式消费者、改动小模块格式和 diff 检查通过。
- [最新验证、剩余范围与首轮失败处置](https://github.com/MAD-Producer/Kilonova/blob/ddadbf3113eddee74df5c824e977ebd39dc24549/engineering/validation/layer-time-free-position.md)、[逐组结果和证据清单](https://github.com/MAD-Producer/Kilonova/blob/ddadbf3113eddee74df5c824e977ebd39dc24549/engineering/validation/layer-time-free-position-evidence/manifest.json)。原生自由位移用例用已有 Alt 语义关闭吸附，未改生产吸附或放宽位移断言。

实际效果：

![中文主窗二维自由移动](https://raw.githubusercontent.com/MAD-Producer/Kilonova/ddadbf3113eddee74df5c824e977ebd39dc24549/engineering/validation/layer-time-free-position-evidence/zh-main-forward-after.png)

![英文浮窗三维自由移动](https://raw.githubusercontent.com/MAD-Producer/Kilonova/ddadbf3113eddee74df5c824e977ebd39dc24549/engineering/validation/layer-time-free-position-evidence/en-floating-reverse-after.png)

前阶段证据独立保留，不将分阶段用例数累加成整条分支的最终验收：[三维轴手柄](https://github.com/MAD-Producer/Kilonova/blob/ddadbf3113eddee74df5c824e977ebd39dc24549/engineering/validation/layer-time-spatial-viewport.md)、[小曲线编辑器](https://github.com/MAD-Producer/Kilonova/blob/ddadbf3113eddee74df5c824e977ebd39dc24549/engineering/validation/layer-time-spatial-mini.md)、[稳定数值](https://github.com/MAD-Producer/Kilonova/blob/ddadbf3113eddee74df5c824e977ebd39dc24549/engineering/validation/layer-time-stable-numeric-drafts.md)、[首次 Roving 转换](https://github.com/MAD-Producer/Kilonova/blob/ddadbf3113eddee74df5c824e977ebd39dc24549/engineering/validation/layer-time-roving-conversion.md)。前阶段整组 graph_ranges 被外层期限中断的记录保留；本次已取得独立完整终态，见上述结果。

本次补充验证与 CI 修正：

- 新增真实音频设备用例显式运行通过，覆盖二倍速、半速、倒放、冻结、往返重映射和 30→60 fps 嵌套。六种场景均在实际 48 kHz 回调消费 24,000 帧 PCM，播放头到第 15 帧，underrun 为零；冻结电平为零。没有物理扬声器录音，峰值不替代精确源采样地址的离线验证。
- 同一最终二进制音频回归 27 项通过；新增设备用例默认忽略，以免无声卡 CI 误判。参见[真实设备结果与边界](https://github.com/MAD-Producer/Kilonova/blob/ddadbf3113eddee74df5c824e977ebd39dc24549/engineering/validation/layer-time-device.md)和[设备报告及证据](https://github.com/MAD-Producer/Kilonova/blob/ddadbf3113eddee74df5c824e977ebd39dc24549/engineering/validation/layer-time-device-evidence/manifest.json)。
- Linux 上一轮在编译测试程序时磁盘耗尽。缓存恢复前清理托管 runner 不使用的 Android／.NET SDK，输出清理前后容量，保留构建与故障产物；工作流策略 14 项及 actionlint 通过。没有改测试断言、预算或重试策略，[失败原因和待验证边界](https://github.com/MAD-Producer/Kilonova/blob/ddadbf3113eddee74df5c824e977ebd39dc24549/engineering/validation/layer-time-ci-disk.md)。修正后的 Linux 完整构建和测试已在最新 CI 通过。
- 此前中断的完整 graph_ranges 分组已在同一最终二进制跑完：24 项通过、1 项原生用例仍忽略，耗时 538.24 秒，退出码为 0。原阶段中断记录保留；新终态和原始日志已进入上述证据包。

剩余：伴随锚点补偿的连续空间键、真实媒体预热／高倍速音频及最终集成。空间曲线复制粘贴、空间值方向拖动及 Roving 区间缓动保留既有边界。

基准头 9027bbaa 的[全部必需 CI 已通过](https://github.com/MAD-Producer/Kilonova/actions/runs/41396544004)。更早的表达式预算失败未在本地复现，不声称已修复根因；本轮没有改预算。提交 ddadbf31 的全部必需 CI 已通过：[最终验收](https://github.com/MAD-Producer/Kilonova/actions/runs/41414993528)。

无新增依赖或第三方素材，没有布局、颜色、尺寸、图标或命中范围改动。既有 DESIGN 基线逐项保留，未宣称全局 UI 整改完成。
