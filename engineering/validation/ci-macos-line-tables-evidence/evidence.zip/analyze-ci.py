import datetime,json,re
from pathlib import Path
p=Path(__file__).parent
last=None;rows=[];suite=''
for line in (p/'pr602-macos.log').read_text('utf-8-sig').splitlines():
    fields=line.split('\t',2)
    if len(fields)<3 or fields[1]!='Run desktop unit tests':continue
    match=re.match(r'(\S+)\s+(.*)',fields[2])
    if not match:continue
    ts=datetime.datetime.fromisoformat(match[1].lstrip('\ufeff').replace('Z','+00:00'));msg=match[2]
    if 'Running ' in msg:suite=msg.strip()
    if msg.startswith('test ') and (' ... ' in msg):
        if last:
            rows.append(dict(seconds=(ts-last).total_seconds(),test=msg,suite=suite))
        last=ts
(p/'ci-test-gaps.json').write_text(json.dumps(rows,indent=2),'utf-8')
print(json.dumps(sorted(rows,key=lambda r:r['seconds'],reverse=True)[:18],indent=2))
groups={}
for row in rows:
    name=row['test'].split(' ')[1].split('::')[0]
    groups[name]=groups.get(name,0)+row['seconds']
print(json.dumps(sorted(groups.items(),key=lambda r:r[1],reverse=True)[:20],indent=2))
print('NOTE: gaps include harness setup and intervening suites; they are not per-test timers.')
