import hashlib,json,re,subprocess,zipfile
from pathlib import Path
raw=Path('E:/Dev/aem/artifacts/issue-goal-current/release-overflow-policy')
out=Path('engineering/validation/release-overflow-policy-evidence');out.mkdir(parents=True,exist_ok=True)
artifacts=[]
counts={}
for stage,expected in [('restored-model',28),('effects-release',37)]:
    assert int((raw/(stage+'.exit')).read_text(encoding='utf-8-sig').strip())==0
    text=(raw/(stage+'.jsonl')).read_text(encoding='utf-8-sig')
    names=re.findall(r'^test (\S+) \.\.\. ok$',text,re.M)
    assert len(names)==len(set(names))==expected
    counts[stage]=len(names)
    records=[json.loads(l) for l in text.splitlines() if l.startswith('{')]
    records=[r for r in records if r.get('reason')=='compiler-artifact']
    assert records and all(r['profile']['overflow_checks'] for r in records)
    for r in records:
        if r.get('executable') and r['profile']['test']:
            assert r['profile']['test'] and r['profile']['opt_level']=='3' and r['profile']['debuginfo']=='line-tables-only'
            p=Path(r['executable']);pdb=p.with_suffix('.pdb')
            assert pdb.is_file() and pdb.stat().st_size>0
            artifacts.append(dict(target=r['target']['name'],profile=r['profile'],path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),pdbBytes=pdb.stat().st_size))
assert len(artifacts)==6
assert int((raw/'negative.exit').read_text(encoding='utf-8-sig').strip())==101
assert 'unsigned add silently wrapped' in (raw/'negative.log').read_text(encoding='utf-8-sig')
assert int((raw/'workflow-validated-env.exit').read_text(encoding='utf-8-sig').strip())==0
assert re.search(r'Ran 14 tests', (raw/'workflow-validated-env.log').read_text(encoding='utf-8-sig'))
assert (raw/'restored-model.stderr').read_text(encoding='utf-8-sig').count('panicked at')==6
paths=['Cargo.toml','crates/motion-model/tests/arithmetic_policy.rs','engineering/release-profile.md']
sources=[dict(path=p,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest()) for p in paths]
receipt=dict(codeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),tests=counts,pythonWorkflowTests=14,artifacts=artifacts,sources=sources)
(raw/'final-basis.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
entries=[]
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(raw.rglob('*')):
        if p.is_file() and p.name not in {'git-api-payload.json','git-api-ref-payload.json'}:
            b=p.read_bytes();rel=p.relative_to(raw).as_posix()
            entries.append(dict(path=rel,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))
            z.writestr(rel,b)
manifest=dict(**receipt,stage='local release acceptance passed; current-head remote CI pending',negativeControl=dict(exit=101,cause='unsigned add silently wrapped',override='final test crate only: -C overflow-checks=off'),retainedFailures=['initial rustc image STATUS_ACCESS_VIOLATION: no test execution','initial default Python lacks PyYAML; reuse existing 6.0.3 tools path later passed','cargo fmt --all --check: Windows os error 206, not a formatting pass'],pending=['current-head cross-platform CI','workspace fmt/clippy gates and remaining #125 invariants','continuous release invocation for model arithmetic policy','release archive symbol distribution and cross-platform symbolication','performance impact outside selected regression suites'],evidence=entries)
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f'Packaged {len(entries)} files; 65 release tests + 14 workflow tests; 6 actual release executables')

