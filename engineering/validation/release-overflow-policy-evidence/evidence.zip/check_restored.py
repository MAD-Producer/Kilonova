import hashlib,json
from pathlib import Path
raw=Path('E:/Dev/aem/artifacts/issue-goal-current/release-overflow-policy')
records=[]
for line in (raw/'restored-model.jsonl').read_text(encoding='utf-8-sig').splitlines():
    if not line.startswith('{'): continue
    item=json.loads(line)
    if item.get('reason')=='compiler-artifact': records.append(item)
assert records and all(x['profile']['overflow_checks'] for x in records)
artifacts=[]
for item in records:
    if item.get('executable') and item['target']['kind']==['test']:
        assert item['profile']['opt_level']=='3' and item['profile']['test']
        assert item['profile']['debuginfo']=='line-tables-only'
        p=Path(item['executable']); pdb=p.with_suffix('.pdb')
        assert pdb.is_file() and pdb.stat().st_size>0
        artifacts.append(dict(target=item['target']['name'],profile=item['profile'],path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),pdbBytes=pdb.stat().st_size))
assert len(artifacts)==4
(raw/'restored-artifacts.json').write_text(json.dumps(dict(checkedArtifacts=len(records),tests=artifacts),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Verified actual release profiles, 4 binaries and 4 nonempty PDBs')

