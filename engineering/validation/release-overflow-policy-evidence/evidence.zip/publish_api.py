import base64
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

repo = 'MAD-Producer/Kilonova'
branch = 'ci/release-overflow-policy'
raw = Path('E:/Dev/aem/artifacts/issue-goal-current/release-overflow-policy')

def git(*args):
    return subprocess.check_output(['git', *args])

def api(endpoint, data):
    payload = raw / 'git-api-payload.json'
    payload.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    result = subprocess.run(['gh', 'api', '--method', 'POST', f'repos/{repo}/{endpoint}', '--input', str(payload)], capture_output=True, text=True, encoding='utf-8')
    if result.returncode:
        raise RuntimeError(result.stderr)
    return json.loads(result.stdout)

local = git('rev-parse', 'HEAD').decode().strip()
parent = git('rev-parse', 'HEAD^').decode().strip()
assert git('branch', '--show-current').decode().strip() == branch
matches = json.loads(subprocess.check_output(['gh', 'api', f'repos/{repo}/git/matching-refs/heads/{branch}'], text=True, encoding='utf-8'))
assert not matches, 'remote branch already exists; inspect before updating'
paths = git('diff', '--name-only', parent, local).decode().splitlines()
assert set(paths) == {'Cargo.toml', 'crates/motion-model/tests/arithmetic_policy.rs', 'engineering/release-profile.md', 'engineering/validation/release-overflow-policy.md'}
entries = []
for path in paths:
    content = git('show', f'{local}:{path}')
    blob = api('git/blobs', dict(content=base64.b64encode(content).decode(), encoding='base64'))
    expected = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
    assert blob['sha'] == expected
    entries.append(dict(path=path, mode='100644', type='blob', sha=expected))
tree = api('git/trees', dict(base_tree=git('rev-parse', f'{parent}^{{tree}}').decode().strip(), tree=entries))
assert tree['sha'] == git('rev-parse', f'{local}^{{tree}}').decode().strip()
fields = git('show', '-s', '--format=%an%x00%ae%x00%at%x00%cn%x00%ce%x00%ct', local).decode().strip().split('\0')
an, ae, at, cn, ce, ct = fields
def date(value):
    return datetime.datetime.fromtimestamp(int(value), datetime.timezone.utc).isoformat().replace('+00:00', 'Z')
message = git('show', '-s', '--format=%B', local).decode().rstrip('\n') + '\n'
commit = api('git/commits', dict(message=message, tree=tree['sha'], parents=[parent], author=dict(name=an, email=ae, date=date(at)), committer=dict(name=cn, email=ce, date=date(ct))))
content = (f"tree {tree['sha']}\nparent {parent}\nauthor {an} <{ae}> {at} +0000\ncommitter {cn} <{ce}> {ct} +0000\n\n" + message).encode()
sha = subprocess.check_output(['git', 'hash-object', '-t', 'commit', '-w', '--stdin'], input=content).decode().strip()
assert sha == commit['sha']
api('git/refs', dict(ref='refs/heads/' + branch, sha=sha))
subprocess.run(['git', 'update-ref', 'refs/heads/' + branch, sha, local], check=True)
subprocess.run(['git', 'update-ref', 'refs/remotes/origin/' + branch, sha], check=True)
(raw / 'git-api-publication.json').write_text(json.dumps(dict(localOriginal=local, published=sha, tree=tree['sha'], reason='Git HTTPS unavailable; verified identical tree via Git Data API'), indent=2) + '\n', encoding='utf-8')
print('Published verified tree:', sha)
