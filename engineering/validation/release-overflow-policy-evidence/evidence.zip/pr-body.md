## 问题与变更

release 的整数检查原来只覆盖 motion-effects，其余工作区 crate 默认可能回绕。本 PR 将 overflow-checks=true 收敛到工作区，显式 strip=none，保留既有 line-tables-only、thin LTO 和单代码生成分区。可失败的外部输入仍必须走受检运算与结构化 Err，不能用 panic 代替验证。

新增运行时算术策略回归，覆盖有符号/无符号加减乘的六种溢出和正常结果；需要在实际 release 下运行，另用显式关闭检查的最终测试 crate 验证负对照。

## 当前验证与草稿原因

- 新模块 rustfmt、差异检查通过；没有改动既有断言、预算、等待期限或重试。
- 正常 release 首轮编译在第三方 image 的 rustc 中发生 STATUS_ACCESS_VIOLATION，未执行测试，原始记录保留。同源码的后续编译与模型边界测试正在运行，未宣称通过。
- 本机额外工作流路由测试缺少 PyYAML，未能启动；本 PR 没有工作流或依赖改动。
- 实际 Cargo profile、边界测试、关闭检查的负对照及可移植证据仍待补齐，先开草稿。

开工已核对其他 PR 文件及活跃分支，避开有理帧率、跟踪和预渲染工作。无 UI 或素材改动；符号归档/分发与全平台符号化未由本配置代替。

[策略说明](engineering/release-profile.md) · [验收状态](engineering/validation/release-overflow-policy.md)

Refs #125；全仓 fmt/clippy 与剩余不变量审计仍未完成，不关闭 issue。
