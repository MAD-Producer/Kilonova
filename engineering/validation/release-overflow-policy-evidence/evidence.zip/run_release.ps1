param([string]$Stage='final')
$ErrorActionPreference='Stop'
. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$evidenceRoot='E:/Dev/aem/artifacts/issue-goal-current/release-overflow-policy'
cargo test --release --locked -p motion-model --test arithmetic_policy --test composition_frame_mapping --test node_resources --test layer_time --message-format=json --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture 1> "$evidenceRoot/$Stage-model.jsonl" 2> "$evidenceRoot/$Stage-model.stderr"
$runExit=$LASTEXITCODE
Set-Content -LiteralPath "$evidenceRoot/$Stage-model.exit" -Value $runExit
exit $runExit

