import hashlib,json,pathlib,re,subprocess,zipfile
root=pathlib.Path.cwd()
out=pathlib.Path(__file__).parent
cache=out.parent/'driver-pipeline-cache'
base='daf806b5f29c2ec0a70e41068445230fb7b13585'
cache_head='5a31ac638ece28314f13384856fb06edc9e72915'
code_head='a7a243c56978d289bce6eefd2748172048dfb7a1'
payload={}
summary={}
checks=[(cache,'compile-final'),(cache,'native-temp-corrected'),(cache,'render-full'),(cache,'prepared-all-targets'),(out,'policy-job-link'),(out,'policy-job-native'),(out,'native-all-lib')]
for folder,phase in checks:
 m=json.loads((folder/(phase+'.json')).read_text(encoding='utf-8'))
 assert m['exit_code']==0 and m['source_before']==m['source_after'],phase
 if 'dependencies_before' in m: assert m['dependencies_before']==m['dependencies_after']
 stdout=(folder/(phase+'.stdout')).read_text(encoding='utf-8')
 counts=[tuple(map(int,x)) for x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout)]
 assert all(x[1]==0 for x in counts)
 summary[phase]=dict(exit_code=0,elapsed_seconds=m['elapsed_seconds'],passed=sum(x[0] for x in counts),ignored=sum(x[2] for x in counts),source_files=len(m['source_before']),source_unchanged=True)
assert summary['render-full']['passed']==978 and summary['render-full']['ignored']==1
assert summary['native-all-lib']['passed']==323 and summary['native-all-lib']['ignored']==0
assert summary['policy-job-native']['passed']==5
linked=json.loads((out/'policy-job-link.json').read_text(encoding='utf-8'))
assert hashlib.file_digest((out/'motion-render-preparation.exe').open('rb'),'sha256').hexdigest()==linked['executable_sha256']
final=json.loads((out/'native-all-lib.json').read_text(encoding='utf-8'))['source_before']
for name,digest in final.items(): assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert all(x['unchanged_from_base'] for x in json.loads((cache/'prepared-warning-scope.json').read_text(encoding='utf-8')))
# Include original output from failed attempts as well; these are not rewritten.
# Only final, baseline and stage-one source bytes are archived, not every failed edit.
for folder in [cache,out]:
 for file in folder.iterdir():
  if file.is_file() and file.suffix in ['.json','.stdout','.stderr','.py','.txt'] and file.name not in ['package-receipt.json','verification-summary.json']:
   payload['commands/'+folder.name+'/'+file.name]=file.read_bytes()
paths=subprocess.check_output(['git','diff','--name-only',base,code_head],text=True).splitlines()
for revision,label in [(base,'baseline'),(cache_head,'cache-stage'),(code_head,'preparation-stage')]:
 for name in paths:
  source=subprocess.run(['git','show',revision+':'+name],capture_output=True)
  if source.returncode==0: payload['source/'+label+'/'+name]=source.stdout
report=dict(base=base,cache_stage=cache_head,preparation_stage=code_head,executable_sha256=linked['executable_sha256'],phases=summary,scope='cache-stage full render regression; final preparation 323 unit tests and locked host/desktop all-targets; host runtime and process timing pending')
data=json.dumps(report,ensure_ascii=False,indent=2).encode('utf-8')
payload['verification-summary.json']=data
(out/'verification-summary.json').write_bytes(data)
manifest={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in sorted(payload.items())}
payload['manifest.json']=json.dumps(manifest,indent=2).encode('utf-8')
archive=root/'engineering/validation/pipeline-cache-and-preparation-evidence.zip'
assert not archive.exists(),'evidence is immutable'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,content in sorted(payload.items()): z.writestr(name,content)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(payload)
 for name,content in payload.items(): assert z.read(name)==content
receipt=dict(path=str(archive),members=len(payload),bytes=archive.stat().st_size,sha256=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),code_head=code_head)
(out/'package-receipt.json').write_bytes(json.dumps(receipt,indent=2).encode('utf-8'))
print(json.dumps(receipt))
