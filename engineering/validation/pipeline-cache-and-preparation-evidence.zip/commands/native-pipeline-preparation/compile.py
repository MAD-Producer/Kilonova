"""Compile the real render test crate with immutable Cargo-produced dependencies.

Output lives outside Cargo's target directory; this never mutates the target of
the concurrently running full regression. It is not a substitute for final
locked Cargo workspace checks.
"""
import hashlib, json, os, pathlib, subprocess, sys, time
root = pathlib.Path.cwd()
out = pathlib.Path(__file__).parent
phase = sys.argv[1]
link = phase.endswith('link')
records = [json.loads(x) for x in pathlib.Path('E:/Dev/aem/artifacts/issue-goal-current/driver-pipeline-cache/compile-final.stdout').read_text(encoding='utf-8').splitlines() if x.startswith('{')]
names = ['log','serde','motion_effects','motion_model','motion_scene','wgpu','glam','bytemuck','image','png','sha2','pollster','thiserror','serde_json','lyon_tessellation','ash','motion_core','motion_media','tempfile']
cmd = ['rustc','--crate-name','motion_render','--edition=2021','crates/motion-render/src/lib.rs','--test',
       '--emit=link' if link else '--emit=metadata','--cfg','feature="default"','--cfg','feature="gpu-tests"',
       '-C','debuginfo=2','-C','metadata=native_pipeline_preparation',
       '-L','dependency=E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps',
       '-o',str(out/('motion-render-preparation.exe' if link else 'motion-render-preparation.rmeta'))]
deps = []
for name in names:
    matches = [x for x in records if x.get('reason')=='compiler-artifact' and x['target']['name']==name and any(y.endswith('.rlib') for y in x['filenames'])]
    if len(matches) != 1: raise SystemExit(f'Ambiguous dependency {name}')
    file = next(y for y in matches[0]['filenames'] if y.endswith('.rlib'))
    deps.append(file)
    cmd += ['--extern', name+'='+file]
for record in records:
    if record.get('reason') == 'build-script-executed':
        for path in record['linked_paths']: cmd += ['-L', path]
env = os.environ.copy()
env.update(CARGO_PKG_NAME='motion-render',CARGO_PKG_VERSION='0.1.0',CARGO_MANIFEST_DIR=str(root/'crates/motion-render'))
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def sources():
    tracked = subprocess.check_output(['git','ls-files','crates/motion-render','Cargo.toml','Cargo.lock'],text=True).splitlines()
    added = subprocess.check_output(['git','ls-files','--others','--exclude-standard','crates/motion-render'],text=True).splitlines()
    return {n:sha(root/n) for n in sorted(set(tracked+added)) if (root/n).is_file()}
meta = dict(command=cmd,cwd=str(root),scope='direct rustc; exact existing locked Cargo dependencies; final Cargo checks remain required',source_before=sources(),dependencies_before={p:sha(p) for p in deps})
(out/(phase+'.json')).write_bytes(json.dumps(meta,indent=2).encode('utf-8'))
started = time.monotonic()
with (out/(phase+'.stdout')).open('wb') as stdout, (out/(phase+'.stderr')).open('wb') as stderr:
    done = subprocess.run(cmd,env=env,stdout=stdout,stderr=stderr)
meta.update(exit_code=done.returncode,elapsed_seconds=time.monotonic()-started,source_after=sources(),dependencies_after={p:sha(p) for p in deps})
if done.returncode == 0 and link: meta['executable_sha256'] = sha(out/'motion-render-preparation.exe')
(out/(phase+'.json')).write_bytes(json.dumps(meta,indent=2).encode('utf-8'))
print(json.dumps({k:meta[k] for k in ['exit_code','elapsed_seconds','scope']}))
sys.exit(done.returncode)
