import hashlib, json, subprocess, zipfile
from pathlib import Path
from PIL import Image

repo = Path('E:/Dev/aem/.worktrees/layer-time-mapping')
root = Path('E:/Dev/aem/artifacts/issue-goal-current')
out = repo / 'engineering/validation/layer-time-key-gestures-evidence'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda name: json.loads((root / name).read_text(encoding='utf-8'))
results = read('layer-time-key-gestures-results.json')
native = read('layer-time-key-gestures-native-result.json')
assert len(results['suites']) == 8
assert all(s['exit_code'] == 0 and not s['failed'] for s in results['suites'].values())
assert native['exit_code'] == 0
assert results['sha256_before'] == results['sha256_after'] == native['program_sha256']
folder = root / 'layer-time-key-gestures-final-static-anchor-native'
images = []
for path in sorted(folder.glob('*.png')):
    with Image.open(path) as image:
        assert image.size == (1000, 800)
        assert len(image.convert('RGB').getcolors(800000) or []) > 20
        images.append({'path': str(path.relative_to(root)), 'sha256': sha(path), 'size': list(image.size)})
assert len(images) == 16
capture = json.loads((folder / 'capture-process.json').read_text())
reopen = json.loads((folder / 'reopen-process.json').read_text())
assert capture['pid'] != reopen['pid']
passed = set(results['distinct_passed']) | {native['command'][2]}
ignored = set(results['distinct_ignored']) - passed

doc = repo / 'engineering/validation/layer-time-key-gestures.md'
placeholder = '待本轮执行完成后填写确切命令、逐项身份、失败原始证据和最终结果。'
text = doc.read_text(encoding='utf-8')
assert placeholder in text
table = ['| 验证组 | 通过 | 忽略 | 用时秒 |', '|---|---:|---:|---:|']
for tag, suite in results['suites'].items():
    table.append(f"| {tag} | {len(suite['passed'])} | {len(suite['ignored'])} | {suite['elapsed_s']} |")
table.append(f"| 原生 GPU/worker/独立进程重开 | 1 | 0 | {native['elapsed_s']} |")
paragraph = f'''最终程序 SHA-256：`{results['sha256_after']}`。默认回归去重后
{len(results['distinct_passed'])} 项通过；另外显式执行原生忽略用例后，共 {len(passed)} 个不同测试通过，
剩余 {len(ignored)} 个忽略用例未执行，不把它们算成通过。具体测试身份、命令、退出码、耗时、
程序身份与原始 stdout/stderr 见本目录证据包和 manifest。

''' + '\n'.join(table) + '''

原生窗口输出 16 张 1000×800 PNG，覆盖主窗/浮窗、中文/英文、普通时间轴/曲线的
拖动预览和提交后状态。预览不改工程；实际串行 worker 提交、全工程撤销、落盘和
不同 PID 的重新打开均执行。已人工查看中文主窗时间轴预览及浮窗曲线提交后截图。
这是 chrome 输入事件/GPU 验收，不声称进行了物理操作系统鼠标输入。

工作区 `cargo check --workspace --all-targets --exclude motion-android --locked
--features motion-desktop/ffmpeg,motion-host/diagnostics` 通过；四个新增模块的
`rustfmt --check --edition 2021`、样式消费者规则和 `git diff --check` 通过。
编译仍有既有 unused/dead-code 警告。原生 stderr 保留本机 Vulkan loader 的
Epic Overlay 缺失 JSON 错误，未修改系统配置、屏蔽日志或将它们计为本功能成功信号。
默认日志的界面故障夹具还保留 Segoe UI、无字体回退时的既有 CJK missing_glyph
Error；没有以四个目标观察站点通过推断整个日志没有其他 Error。原生中文截图
可正常读字，夹具字体配置和字体观察的全面整改不由本阶段测试证明。

默认日志验证在真实子进程执行，包含四个站点的首次/第 60 次/抑制、图缓存故障恢复
以及 worker 错误与恢复；检查文件、Error stderr 和 stdout 隔离。图形预算负对照
确实触发受限采样，不用 mock 成功返回替代故障验证。首次编译、Hold 新测试和
静态锚点全选测试的失败输出也保留在证据包，最终结果不覆盖这些原始记录。
'''
doc.write_text(text.replace(placeholder, paragraph), encoding='utf-8')

out.mkdir(parents=True, exist_ok=True)
entries = []
paths = set()
for candidate in root.iterdir():
    if 'layer-time-key-gestures' not in candidate.name:
        continue
    if candidate.is_dir():
        paths.update(p for p in candidate.rglob('*') if p.is_file())
    elif candidate.is_file():
        paths.add(candidate)
allowed = {'.log', '.json', '.png', '.py', '.txt'}
paths = sorted(p for p in paths if p.suffix.lower() in allowed)
assert sum(p.stat().st_size for p in paths) < 100 * 1024 * 1024
archive = out / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for path in paths:
        relative = path.relative_to(root).as_posix()
        bundle.write(path, relative)
        entries.append({'path': relative, 'bytes': path.stat().st_size, 'sha256': sha(path)})
changed = subprocess.check_output(['git', 'diff', '--name-only', '-z'], cwd=repo).decode().split('\0')
changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=repo).decode().split('\0')
sources = {name: sha(repo / name) for name in sorted(set(changed))
           if name and (repo / name).is_file() and 'layer-time-key-gestures-evidence/' not in name}
manifest = {
    'base': '268625a9d4076987996803d4a1e5dff501d98830', 'branch': 'feat/layer-time-mapping',
    'issue': 257, 'issue_complete': False,
    'results': results, 'native': native, 'native_processes': {'capture': capture, 'reopen': reopen},
    'passed': sorted(passed), 'remaining_ignored': sorted(ignored), 'images': images,
    'source_sha256': sources, 'archive_sha256': sha(archive), 'archive_entries': entries,
    'limits': ['visible time controls and remaining clock-aware channels are incomplete',
               'OS physical input and other platforms not executed',
               'existing Track f32 Hold boundary unchanged',
               'external Epic Overlay Vulkan JSON loader errors retained']}
(out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for entry in entries:
        assert hashlib.sha256(bundle.read(entry['path'])).hexdigest() == entry['sha256']
print(json.dumps({'passed': len(passed), 'ignored': len(ignored), 'images': len(images),
                  'entries': len(entries), 'archive_bytes': archive.stat().st_size}, ensure_ascii=False))
