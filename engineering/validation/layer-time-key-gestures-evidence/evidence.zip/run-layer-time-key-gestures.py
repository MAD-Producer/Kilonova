import hashlib,json,os,re,subprocess,time
from pathlib import Path
root=Path('E:/Dev/aem/artifacts/issue-goal-current')
exe=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-b34b3a7e7eb835e8.exe')
env=os.environ.copy()
env.update(TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp',TMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp',FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1',WGPU_BACKEND='vulkan')
env['PATH']=env['FFMPEG_DIR']+'/bin;'+env['PATH']
env.pop('MOTION_LOG',None)
for name in ['LOCAL_TIMING_LOG','LOCAL_SELECTION_LOG','TIMED_GRAPH_LOG','SPATIAL_GRAPH_ERROR','LOCAL_KEYS_ERROR','KEY_TIMING_ERROR','CURVE_READOUT_FAULT','CURVE_RANGE_FAULT']:
    env['MOTION_'+name+'_ARTIFACTS']=str(root/('layer-time-key-gestures-final-static-anchor-'+name.lower()))
filters={'selection':'panels::key_selection::','graph':'panels::timeline_graph::','graph_helpers':'panels::graph_','menu':'panels::animation_menu','shortcuts':'panels::timeline_shortcuts','clipboard':'panels::keyframe_clipboard','comparison':'panels::curve_comparison','worker':'engine::keyframe_timing_tests::'}
result={'program':str(exe),'sha256_before':hashlib.sha256(exe.read_bytes()).hexdigest(),'env':{k:env[k] for k in ['TEMP','TMP','FFMPEG_DIR','WGPU_BACKEND']},'suites':{}}
for tag,pattern in filters.items():
    command=[str(exe),pattern,'--test-threads=1','--nocapture']
    began=time.monotonic(); run=subprocess.run(command,env=env,capture_output=True)
    (root/('layer-time-key-gestures-'+tag+'-stdout.log')).write_bytes(run.stdout)
    (root/('layer-time-key-gestures-'+tag+'-stderr.log')).write_bytes(run.stderr)
    output=run.stdout.decode('utf-8',errors='replace')
    tests=[];ignored=[];failed=[]
    blocks=re.split(r'^test ([^\s]+) \.\.\. ',output,flags=re.M)
    for i in range(1,len(blocks),2):
        name,body=blocks[i:i+2]
        body=re.split(r'^failures:|^test result:',body,flags=re.M)[0].strip()
        if re.search(r'(^|\n)ok$',body) or body=='ok': tests.append(name)
        elif body.startswith('ignored'): ignored.append(name)
        else: failed.append(name)
    summary=re.findall(r'test result: .*',output)
    result['suites'][tag]={'filter':pattern,'command':command,'exit_code':run.returncode,'elapsed_s':round(time.monotonic()-began,3),'passed':tests,'ignored':ignored,'failed':failed,'summary':summary}
    print(tag,run.returncode,summary,flush=True)
    (root/'layer-time-key-gestures-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    if run.returncode:
        print(output[-10000:],flush=True);raise SystemExit(run.returncode)
result['sha256_after']=hashlib.sha256(exe.read_bytes()).hexdigest()
result['distinct_passed']=sorted({t for group in result['suites'].values() for t in group['passed']})
result['distinct_ignored']=sorted({t for group in result['suites'].values() for t in group['ignored']})
(root/'layer-time-key-gestures-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print('distinct',len(result['distinct_passed']),'ignored',len(result['distinct_ignored']),flush=True)
