import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('E:/Dev/aem/artifacts/issue-goal-current')
exe=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-b34b3a7e7eb835e8.exe')
env=os.environ.copy();env.update(TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp',TMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp',FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1',WGPU_BACKEND='vulkan',MOTION_LOCAL_TIMING_GPU_ARTIFACTS=str(root/'layer-time-key-gestures-final-static-anchor-native'));env['PATH']=env['FFMPEG_DIR']+'/bin;'+env['PATH'];env.pop('MOTION_LOG',None)
name='panels::key_selection::tests::ui::local_timing::native::fractional_key_drag_pixels_transactions_and_reopen'
cmd=[str(exe),'--exact',name,'--ignored','--nocapture','--test-threads=1']
start=time.monotonic();run=subprocess.run(cmd,env=env,capture_output=True)
(root/'layer-time-key-gestures-native-stdout.log').write_bytes(run.stdout);(root/'layer-time-key-gestures-native-stderr.log').write_bytes(run.stderr)
result={'command':cmd,'exit_code':run.returncode,'elapsed_s':round(time.monotonic()-start,3),'program_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
(root/'layer-time-key-gestures-native-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result));print(run.stdout.decode('utf-8',errors='replace')[-7000:]);print(run.stderr.decode('utf-8',errors='replace')[-3000:]);raise SystemExit(run.returncode)
