from pathlib import Path
import hashlib,json,subprocess,zipfile

work=Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
out=Path(__file__).parent
coord=out.parent/'next-priority'
target=work/'engineering/validation/desktop-driver-cache-storage-evidence.zip'
assert not target.exists(), 'Never replace an existing evidence archive'
def git(*args):
    return subprocess.check_output(['git',*args],cwd=work)
members={}
def add(name,data):
    assert name not in members,name
    members[name]=data
phases=['cache-storage-host','cache-storage-host-surface','cache-storage-desktop',
    'cache-storage-desktop-playback-fix','cache-storage-original-paced','cache-storage-playback-barriers',
    'cache-storage-dx12','cache-storage-original-log-regression','cache-storage-all-targets',
    'cache-storage-render-regression','cache-storage-existing-single-present']
reports=[]
for phase in phases:
    report=json.loads((out/(phase+'.json')).read_text(encoding='utf8'))
    expected=101 if phase=='cache-storage-existing-single-present' else 0
    assert report['exit_code']==expected,(phase,report.get('exit_code'))
    assert report['source_before']==report['source_after'],phase
    reports.append({'phase':phase,'exit':expected,'sourceCount':len(report['source_before']),
        'seconds':report['elapsed_seconds']})
    for suffix in ['.json','.stdout','.stderr']:
        path=out/(phase+suffix);add('commands/'+path.name,path.read_bytes())
for directory in ['cache-storage-host-evidence','cache-storage-desktop-evidence',
    'cache-storage-desktop-final-evidence','cache-storage-dx12-evidence','cache-storage-paced-evidence']:
    for path in sorted((out/directory).rglob('*')):
        if path.is_file():add('native/'+path.relative_to(out).as_posix(),path.read_bytes())
for name in ['pr627-windows-cache-storage-failed.log','pr627-cache-storage-checks-followup.json',
    'pr627-windows-cache-storage-annotations.json','open-prs-cache-integration-current.json']:
    add('coordination/'+name,(coord/name).read_bytes())
for name in ['run.py',Path(__file__).name]:add('controllers/'+name,(out/name).read_bytes())
tracked=git('diff','--name-only','HEAD').decode('utf8').splitlines()
untracked=git('ls-files','--others','--exclude-standard').decode('utf8').splitlines()
names=sorted(set(tracked+untracked))
source={}
for name in names:
    if name.startswith('engineering/validation/'):continue
    path=work/name
    assert path.is_file(),name
    data=path.read_bytes();source[name]=hashlib.sha256(data).hexdigest()
    add('source/current/'+name,data)
    if name in tracked:add('source/base/'+name,git('show','HEAD:'+name))
add('source/tracked.patch',git('diff','--binary','HEAD'))
exe=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-23245631dbb5fb4e.exe')
identity={'path':str(exe),'bytes':exe.stat().st_size,'sha256':hashlib.file_digest(exe.open('rb'),'sha256').hexdigest()}
manifest={'base':git('rev-parse','HEAD').decode().strip(),'issue':64,'draftPR':627,
    'commands':reports,'currentSource':source,'desktopExecutable':identity,
    'limits':['One final native single-Present regression remains a real failure, not a passing control',
        'No original assertion, deadline, ignore or sample count changed',
        'Earlier and final source maps are kept per command; each run was immutable',
        'Session native surfaces are not independent application process startup qualification',
        'Vulkan real private-storage failure and Dx12 real owner-thread error are distinct branches',
        'Cross-process cold/warm performance and remaining issue scope stay open'],
    'members':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in members.items()}}
add('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf8'))
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in members.items():archive.writestr(name,data)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist())==set(members)
    for name,data in members.items():assert hashlib.sha256(archive.read(name)).digest()==hashlib.sha256(data).digest(),name
receipt={'path':str(target),'members':len(members),'bytes':target.stat().st_size,
    'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'commands':reports,'desktopExecutable':identity}
(out/'cache-storage-archive-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['commands']},ensure_ascii=True))
