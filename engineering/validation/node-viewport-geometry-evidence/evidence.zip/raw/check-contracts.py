import hashlib,json,os,subprocess
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(l) for l in (p/'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
receipts=[]
for i,name in enumerate(['navigation_rebuilds_current_geometry_without_editing_the_document','uncommitted_node_moves_release_and_cancel_keep_fresh_geometry_and_history']):
 command=[exe,'--exact','node_editor::view::frame_cards_tests::'+name,'--test-threads=1','--nocapture']
 r=subprocess.run(command,env=env,capture_output=True)
 (p/f'old-count-contract-{i}.stdout').write_bytes(r.stdout);(p/f'old-count-contract-{i}.stderr').write_bytes(r.stderr)
 receipts.append(dict(command=command,exit=r.returncode,executable_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest()))
 print(json.dumps(receipts[-1]),flush=True)
(p/'old-count-contracts.json').write_text(json.dumps(receipts,indent=2),'utf-8')
assert all(r['exit']==101 for r in receipts)
