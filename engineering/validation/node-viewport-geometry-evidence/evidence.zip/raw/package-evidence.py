import hashlib,json,re,subprocess,zipfile
from pathlib import Path
raw=Path(__file__).parent
root=Path.cwd()
out=root/'engineering/validation/node-viewport-geometry-evidence'
out.mkdir(exist_ok=True)
base='68e1415ea919f8215acc03801d0dbb2312f957c8'
source_paths=[
 'desktop/app/src/node_editor/view/mod.rs',
 'desktop/app/src/node_editor/view/canvas.rs',
 'desktop/app/src/node_editor/view/frame_cards_tests.rs',
 'desktop/app/src/node_editor/view/frame_cards_tests/viewport_geometry.rs',
]
def digest(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args])
before=json.loads((raw/'before-paint.json').read_text('utf-8'))
final=json.loads((raw/'final-paint.json').read_text('utf-8'))
assert before==final and len(final)==24 and all(len(frames)==13 for frames in final.values())
comparison=dict(equal=True,configurations=24,frames=312,compared_fields='complete shapes/colors/glyphs/order, response fields, EditorSnapshot and undo length; no normalization',before_sha256=digest((raw/'before-paint.json').read_bytes()),final_sha256=digest((raw/'final-paint.json').read_bytes()))
(raw/'final-paint-comparison.json').write_text(json.dumps(comparison,indent=2),'utf-8')
selected=[]
for index in range(4):
 text=(raw/f'regression-{index}.stdout').read_text('utf-8')
 match=re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',text)
 assert match,text[-500:]
 selected.append(int(match[1]))
for name in ['costs.json','layouts.json']:
 assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in (raw/(name+'.stdout')).read_text('utf-8')
assert selected==[186,4,13,7]
assert len(json.loads((raw/'costs.json').read_text('utf-8')))==48
assert len(json.loads((raw/'layouts.json').read_text('utf-8')))==48
receipt=dict(selected_distinct_tests=sum(selected)+2,by_filter=selected,workspace_tests=2,negative_baseline_exits=[r['exit'] for r in json.loads((raw/'before-tests.json').read_text('utf-8'))],final_probe_exits=[r['exit'] for r in json.loads((raw/'final-tests.json').read_text('utf-8'))],baseline=base,source_snapshot=git('rev-parse','HEAD').decode().strip())
assert receipt['negative_baseline_exits']==[101,101,0]
assert receipt['final_probe_exits']==[0,0,0]
(raw/'summary.json').write_text(json.dumps(receipt,indent=2),'utf-8')
sources={path:(root/path).read_bytes() for path in source_paths}
baseline={path:git('show',f'{base}:{path}') for path in source_paths[:3]}
baseline[source_paths[2]]=baseline[source_paths[2]].replace(b'mod drag_geometry;\n',b'mod drag_geometry;\nmod viewport_geometry;\n')
baseline[source_paths[3]]=sources[source_paths[3]]
files=[]
for file in sorted(raw.iterdir()):
 if file.is_file() and file.suffix in ['.json','.jsonl','.stdout','.stderr','.py','.ps1'] and not file.name.startswith(('publication-','publish_api','setup-publication','github_api')):
  files.append((f'raw/{file.name}',file.read_bytes()))
for path,content in sources.items():files.append((f'final-source/{path}',content))
for path,content in baseline.items():files.append((f'baseline-source/{path}',content))
files.append(('README.txt',b'Baseline production is PR #602 head 68e1415e with only the new tests/declaration added. Projected runs retain the old >=2 performance assertions; final runs tighten those assertions to ==1 after exact paint/state equivalence. Runtime RUST_MIN_STACK is unset. Compile profiles/arguments are retained in scripts and compiler JSON. Test source and runtime evidence are not GPU/Native Present, physical-input, peak-memory or universal frame-cost acceptance. Controlled LOCALAPPDATA startup does not establish that the original default directory permission issue is fixed. No source restoration, failure deletion or assertion weakening was used.\n'))
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,content in files:z.writestr(name,content)
manifest=dict(**receipt,archive_sha256=digest(archive.read_bytes()),source_sha256={path:digest(content) for path,content in sources.items()},records=[dict(path=name,bytes=len(content),sha256=digest(content)) for name,content in files])
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n','utf-8')
with zipfile.ZipFile(archive) as z:
 for row in manifest['records']:assert digest(z.read(row['path']))==row['sha256']
print(json.dumps(dict(tests=receipt['selected_distinct_tests'],frames=comparison['frames'],records=len(files),zip_bytes=archive.stat().st_size,zip_sha256=manifest['archive_sha256'])),flush=True)
