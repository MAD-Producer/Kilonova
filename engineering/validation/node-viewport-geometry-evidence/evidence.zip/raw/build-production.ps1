. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:RUST_MIN_STACK='33554432'
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:LIBCLANG_PATH='E:/Dev/aem/.tools/python-libclang/clang/native'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
cargo rustc -p motion-desktop --bin motion-studio --profile dev --features ffmpeg --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --config profile.dev.package.motion-render.debug=0 --config profile.dev.package.motion-model.debug=0 --config profile.dev.package.motion-host.debug=0 --config profile.dev.package.motion-core.debug=0 --config profile.dev.package.motion-media.debug=0 --config profile.dev.package.motion-scene.debug=0 --config profile.dev.package.motion-effects.debug=0 --config profile.dev.package.motion-ui.debug=0 --config profile.dev.package.motion-desktop-media.debug=0 --config profile.dev.package.motion-graph.debug=0 --message-format=json -- -C codegen-units=8 -C debuginfo=0 -C link-arg=/DEBUG:NONE 1> E:/Dev/aem/artifacts/issue-goal-current/node-viewport-geometry/production-build.jsonl 2> E:/Dev/aem/artifacts/issue-goal-current/node-viewport-geometry/production-build.stderr
exit $LASTEXITCODE
