. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:RUST_MIN_STACK='33554432'
$env:RUST_BACKTRACE='full'
$env:RUSTC_LOG='rustc_codegen_ssa::back::link=info'
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:LIBCLANG_PATH='E:/Dev/aem/.tools/python-libclang/clang/native'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
$diagDir='E:/Dev/aem/artifacts/issue-goal-current/node-release-diagnostic'
git rev-parse HEAD > "$diagDir/source-head.txt"
git status --porcelain=v1 | Out-File "$diagDir/source-status.txt" -Encoding utf8
git diff 85ae6868 -- crates desktop/app desktop/ui/src Cargo.toml Cargo.lock | Out-File "$diagDir/runtime-source-diff.patch" -Encoding utf8
Get-CimInstance Win32_OperatingSystem | Select-Object FreePhysicalMemory,TotalVisibleMemorySize | ConvertTo-Json > "$diagDir/memory-before.json"
$started=(Get-Date).ToString('o')
cargo build --package motion-desktop --bin motion-studio --release --features ffmpeg --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --message-format=json 1> "$diagDir/release-build.jsonl" 2> "$diagDir/release-build.stderr"
$buildExit=$LASTEXITCODE
@{exit=$buildExit;started=$started;completed=(Get-Date).ToString('o');diagnostic_log='rustc_codegen_ssa::back::link=info';backtrace='full'} | ConvertTo-Json > "$diagDir/result.json"
exit $buildExit
