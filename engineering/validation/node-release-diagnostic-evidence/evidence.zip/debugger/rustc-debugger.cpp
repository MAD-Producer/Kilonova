// Repository-authored diagnostic launcher; does not modify the debuggee.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <minidumpapiset.h>
#include <cstdio>
#include <string>

int wmain(int argc, wchar_t** argv) {
    if (argc != 4) return 2;
    HMODULE dbghelp = LoadLibraryW(L"dbghelp.dll");
    if (!dbghelp) return 3;
    auto write_dump = reinterpret_cast<decltype(&MiniDumpWriteDump)>(
        GetProcAddress(dbghelp, "MiniDumpWriteDump"));
    if (!write_dump) return 4;
    std::wstring command = argv[3];
    STARTUPINFOW startup{};
    startup.cb = sizeof(startup);
    PROCESS_INFORMATION process{};
    if (!CreateProcessW(argv[1], command.data(), nullptr, nullptr, TRUE,
                        DEBUG_ONLY_THIS_PROCESS, nullptr, nullptr, &startup, &process)) {
        std::fprintf(stderr, "debugger create_error=%lu\n", GetLastError());
        return 5;
    }
    std::fprintf(stderr, "debugger pid=%lu\n", process.dwProcessId);
    std::fflush(stderr);
    bool dumped = false;
    DWORD exit_code = 6;
    for (;;) {
        DEBUG_EVENT event{};
        if (!WaitForDebugEvent(&event, INFINITE)) return 7;
        DWORD disposition = DBG_CONTINUE;
        if (event.dwDebugEventCode == CREATE_PROCESS_DEBUG_EVENT) {
            if (event.u.CreateProcessInfo.hFile) CloseHandle(event.u.CreateProcessInfo.hFile);
            if (event.u.CreateProcessInfo.hProcess && event.u.CreateProcessInfo.hProcess != process.hProcess)
                CloseHandle(event.u.CreateProcessInfo.hProcess);
            if (event.u.CreateProcessInfo.hThread && event.u.CreateProcessInfo.hThread != process.hThread)
                CloseHandle(event.u.CreateProcessInfo.hThread);
        } else if (event.dwDebugEventCode == CREATE_THREAD_DEBUG_EVENT) {
            if (event.u.CreateThread.hThread) CloseHandle(event.u.CreateThread.hThread);
        } else if (event.dwDebugEventCode == LOAD_DLL_DEBUG_EVENT) {
            if (event.u.LoadDll.hFile) CloseHandle(event.u.LoadDll.hFile);
        } else if (event.dwDebugEventCode == EXCEPTION_DEBUG_EVENT) {
            auto& exception = event.u.Exception;
            const DWORD code = exception.ExceptionRecord.ExceptionCode;
            const bool fatal = !exception.dwFirstChance || code == 0xc0000374 || code == 0xc0000409;
            std::fprintf(stderr, "debugger exception=0x%08lx first_chance=%lu thread=%lu address=%p\n",
                         code, exception.dwFirstChance, event.dwThreadId,
                         exception.ExceptionRecord.ExceptionAddress);
            std::fflush(stderr);
            if (fatal && !dumped) {
                HANDLE thread = OpenThread(THREAD_GET_CONTEXT | THREAD_QUERY_INFORMATION,
                                           FALSE, event.dwThreadId);
                CONTEXT context{};
                context.ContextFlags = CONTEXT_ALL;
                BOOL got_context = thread && GetThreadContext(thread, &context);
                EXCEPTION_RECORD record = exception.ExceptionRecord;
                record.ExceptionRecord = nullptr;
                EXCEPTION_POINTERS pointers{&record, &context};
                MINIDUMP_EXCEPTION_INFORMATION info{event.dwThreadId, &pointers, FALSE};
                HANDLE file = CreateFileW(argv[2], GENERIC_WRITE, 0, nullptr,
                                          CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
                BOOL saved = file != INVALID_HANDLE_VALUE && write_dump(
                    process.hProcess, process.dwProcessId, file,
                    static_cast<MINIDUMP_TYPE>(MiniDumpNormal | MiniDumpWithThreadInfo | MiniDumpWithUnloadedModules),
                    got_context ? &info : nullptr, nullptr, nullptr);
                DWORD error = saved ? 0 : GetLastError();
                if (file != INVALID_HANDLE_VALUE) CloseHandle(file);
                if (thread) CloseHandle(thread);
                std::fprintf(stderr, "debugger dump_saved=%d context=%d error=%lu\n", saved, got_context, error);
                std::fflush(stderr);
                dumped = saved != FALSE;
            }
            disposition = code == EXCEPTION_BREAKPOINT && exception.dwFirstChance
                ? DBG_CONTINUE : DBG_EXCEPTION_NOT_HANDLED;
        } else if (event.dwDebugEventCode == EXIT_PROCESS_DEBUG_EVENT) {
            exit_code = event.u.ExitProcess.dwExitCode;
            ContinueDebugEvent(event.dwProcessId, event.dwThreadId, disposition);
            break;
        }
        if (!ContinueDebugEvent(event.dwProcessId, event.dwThreadId, disposition)) return 8;
    }
    std::fprintf(stderr, "debugger child_exit=0x%08lx dump=%d\n", exit_code, dumped);
    CloseHandle(process.hThread);
    CloseHandle(process.hProcess);
    FreeLibrary(dbghelp);
    return static_cast<int>(exit_code);
}
