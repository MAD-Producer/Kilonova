#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdio>
int main() {
    wchar_t value[8]{};
    if (GetEnvironmentVariableW(L"MOTION_DEBUG_CAPTURE_CONTROL", value, 8)) {
        std::fprintf(stderr, "capture control: deliberate unhandled exception 0xe0860001\n");
        std::fflush(stderr);
        RaiseException(0xe0860001, EXCEPTION_NONCONTINUABLE, 0, nullptr);
    }
    std::fprintf(stderr, "capture control: clean exit\n");
    return 0;
}
