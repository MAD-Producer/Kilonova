import hashlib,json,pathlib,shutil,zipfile
root=pathlib.Path(__file__).parent
workspace=pathlib.Path('E:/Dev/aem/.worktrees/layer-time-mapping')
dest=workspace/'engineering/validation/layer-time-anchor-compensation-evidence'
dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((root/'source-hashes.json').read_text(encoding='utf-8'))
for n,d in sources.items(): assert sha(workspace/n)==d,n
results=json.loads((root/'test-results.json').read_text(encoding='utf-8'))
assert len(results)==7 and all(r['exit']==0 for r in results)
passed={p for r in results for p in r['passed']}
unrun={p for r in results for p in r['ignored']}-passed
assert len(list((root/'native').glob('*.png')))==4
with zipfile.ZipFile(dest/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in root.rglob('*'):
        if p.is_file() and p.suffix.lower()!='.exe': z.write(p,p.relative_to(root).as_posix())
    for n in sources: z.write(workspace/n,'source/'+n)
for original,name in [('Properties-Zh-False-committed.png','properties-main-zh.png'),
                      ('Timeline-En-True-committed.png','timeline-floating-en.png')]:
    shutil.copyfile(root/'native'/original,dest/name)
manifest={'issue':257,'stage':'exact-time anchor compensation','branch':'feat/layer-time-mapping',
'base':'f4cabfb2c428b7c6ff4514543897b432e7e911d3','sourceHashes':sources,
'binaries':json.loads((root/'binaries.json').read_text()),'passed':len(passed),'unrunManual':sorted(unrun),
'testResults':results,'nativeCases':2,'nativeScreenshots':4,
'boundary':'Roving edits that change the current compensated sample are explicitly rejected; fixed spatial IDs are supported.',
'bundle':{'path':'evidence.zip','sha256':sha(dest/'evidence.zip'),'bytes':(dest/'evidence.zip').stat().st_size},
'screenshots':{p.name:sha(p) for p in dest.glob('*.png')}}
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('packaged passes',len(passed),'unrun manual',len(unrun),'zip bytes',(dest/'evidence.zip').stat().st_size)
