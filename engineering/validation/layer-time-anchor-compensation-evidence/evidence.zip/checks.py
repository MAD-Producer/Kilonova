import json,pathlib,subprocess
root=pathlib.Path(__file__).parent
jobs=[('format',['rustfmt','--check','--edition','2021','--config','skip_children=true',
'crates/motion-model/src/keyframe_clipboard/authoring.rs','crates/motion-model/src/keyframe_clipboard/authoring/anchor.rs',
'crates/motion-core/tests/layer_anchor_animation/mapped.rs','desktop/app/src/panels/properties/mapped_anchor_tests.rs',
'desktop/app/src/panels/transform_controls/mapped_anchor_tests.rs']),
('styles',['python','-c',"import sys;sys.path.insert(0,'tools');import ci_desktop;ci_desktop.verify_style_consumers()"]),
('diff',['git','diff','--check'])]
results=[]
for name,args in jobs:
    p=subprocess.run(args,capture_output=True,text=True,encoding='utf-8')
    results.append({'name':name,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    print(name,p.returncode)
(root/'checks.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
assert all(p['exit']==0 for p in results)
