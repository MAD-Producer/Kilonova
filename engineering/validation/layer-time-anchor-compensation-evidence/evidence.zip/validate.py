import hashlib,json,os,pathlib,re,shutil,subprocess,time
root=pathlib.Path(__file__).parent
workspace=pathlib.Path('E:/Dev/aem/.worktrees/layer-time-mapping')
sources=[
'crates/motion-core/src/command_registry.rs','crates/motion-core/src/editor.rs',
'crates/motion-core/tests/layer_anchor_animation.rs','crates/motion-core/tests/layer_anchor_animation/mapped.rs',
'crates/motion-model/src/commands.rs','crates/motion-model/src/keyframe_clipboard/authoring.rs',
'crates/motion-model/src/keyframe_clipboard/authoring/anchor.rs',
'desktop/app/src/panels/properties.rs','desktop/app/src/panels/properties/tree_tests.rs',
'desktop/app/src/panels/properties/mapped_anchor_tests.rs','desktop/app/src/panels/transform_controls.rs',
'desktop/app/src/panels/transform_controls/mapped_anchor_tests.rs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--freeze' in __import__('sys').argv:
    (root/'source-hashes.json').write_text(json.dumps({n:sha(workspace/n) for n in sources},indent=2),encoding='utf-8')
    raise SystemExit(0)
hashes=json.loads((root/'source-hashes.json').read_text(encoding='utf-8'))
def unchanged():
    for n,d in hashes.items(): assert sha(workspace/n)==d,n
unchanged()
files={}
for line in (root/'build.log').read_text(encoding='utf-8').splitlines():
    if 'Executable' not in line: continue
    source=pathlib.Path(line.rsplit('(',1)[1].rstrip(')'))
    name=next(n for key,n in [('layer_anchor_animation','anchor-tested.exe'),('track_at','track-at-tested.exe'),('motion_studio','motion-studio-tested.exe')] if key in source.name)
    shutil.copyfile(source,root/name)
    files[name]=sha(root/name)
assert len(files)==3
(root/'binaries.json').write_text(json.dumps(files,indent=2),encoding='utf-8')
env=os.environ.copy()
env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
env['MOTION_ANCHOR_TIME_NATIVE_ARTIFACTS']=str(root/'native')
env['MOTION_ANCHOR_TIME_FAULT_ARTIFACTS']=str(root/'fault')
jobs=[('core-anchor','anchor-tested.exe',[]),('core-track','track-at-tested.exe',[])]
for name in ['properties','transform_controls','numeric','effect_controls']:
    jobs.append((name,'motion-studio-tested.exe',['panels::'+name+'::']))
jobs.append(('native','motion-studio-tested.exe',['--ignored','--exact',
'panels::properties::mapped_anchor_tests::native_mapped_anchor_controls_render_cancel_commit_and_undo_in_two_windows']))
results=[]
for name,exe,args in jobs:
    start=time.monotonic()
    with (root/(name+'-stdout.log')).open('wb') as out,(root/(name+'-stderr.log')).open('wb') as err:
        r=subprocess.run([str(root/exe),*args,'--nocapture','--test-threads=1'],cwd=workspace,env=env,stdout=out,stderr=err,timeout=600)
    output=(root/(name+'-stdout.log')).read_text(encoding='utf-8',errors='replace')
    results.append({'group':name,'exit':r.returncode,'seconds':round(time.monotonic()-start,3),
'passed':re.findall(r'^test (\S+) \.\.\. ok$',output,re.M),
'ignored':re.findall(r'^test (\S+) \.\.\. ignored[^\n]*$',output,re.M)})
    (root/'test-results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(name,r.returncode,'passed',len(results[-1]['passed']),'ignored',len(results[-1]['ignored']),flush=True)
    if r.returncode:
        print(output[-6000:],flush=True)
        print((root/(name+'-stderr.log')).read_text(encoding='utf-8',errors='replace')[-6000:],flush=True)
        raise SystemExit(r.returncode)
unchanged()
print('unchanged sources',len(hashes),'unique passes',len({p for r in results for p in r['passed']}),flush=True)
