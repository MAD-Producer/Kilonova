from pathlib import Path
import hashlib
import json
import zipfile

base = Path(__file__).parent
repo = Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
phases = {
    'idle-preparation-fault-native-v1': 101,
    'idle-preparation-fault-native-v2': 0,
    'idle-preparation-fault-native-v3': 0,
    'idle-preparation-fault-regression-v1': 101,
    'idle-preparation-fault-regression-v2': 0,
    'idle-preparation-fault-normal-build-v1': 0,
}
final = None
members = {}
receipts = {}
for phase, expected in phases.items():
    receipt = json.loads((base/(phase+'.json')).read_text(encoding='utf-8'))
    assert receipt['exit_code'] == expected, (phase, receipt['exit_code'])
    assert receipt['source_before'] == receipt['source_after'], phase
    if phase in ['idle-preparation-fault-native-v3', 'idle-preparation-fault-regression-v2',
                 'idle-preparation-fault-normal-build-v1']:
        if final is None: final = receipt['source_before']
        assert final == receipt['source_before'], phase
    receipts[phase] = dict(exitCode=expected, elapsedSeconds=receipt['elapsed_seconds'])
    for suffix in ['.json', '.stdout', '.stderr']:
        path = base/(phase+suffix)
        members['commands/'+path.name] = path.read_bytes()
    for path in sorted(base.glob(phase+'-source.rs')):
        members['first-sources/'+path.name] = path.read_bytes()
    for path in sorted(base.glob(phase+'-boundary.rs')):
        members['first-sources/'+path.name] = path.read_bytes()

for relative, expected in final.items():
    path = repo/relative
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, relative

for directory in [base/'idle-preparation-fault-native-v1-evidence',
                  base/'idle-preparation-fault-native-v2-evidence',
                  base/'idle-preparation-fault-native-v3-evidence',
                  base/'idle-preparation-fault-regression-v2-frame-evidence',
                  base/'idle-preparation-fault-regression-v2-orphan-evidence',
                  base/'idle-preparation-fault-regression-v2-status-evidence']:
    assert directory.is_dir(), directory
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            assert path.suffix.lower() not in ['.exe', '.dll', '.cache', '.dmp'], path
            members['evidence/'+path.relative_to(base).as_posix()] = path.read_bytes()

report = json.loads((base/'idle-preparation-fault-native-v3-evidence/report.json').read_text(encoding='utf-8'))
assert report['cacheSupported'] is True
assert len(report['cases']) == 2
for case in report['cases']:
    assert case['queuedReplies'] == 2 and case['queueDepth'] == 0
    assert case['preparing'] is False
    assert case['reopened'] and case['projectBytesUnchanged'] and case['resourcesReleased']
for relative in ['desktop/app/src/engine/preparation_progress.rs',
                 'desktop/app/src/engine/preparation_progress/native_tests.rs',
                 'desktop/app/src/engine.rs', 'desktop/app/src/engine/error.rs',
                 'desktop/app/src/engine/failure.rs', 'desktop/app/src/engine/shutdown.rs']:
    members['source/'+relative] = (repo/relative).read_bytes()
members['controller/'+Path(__file__).name] = Path(__file__).read_bytes()
manifest = {name: dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
            for name, data in sorted(members.items())}
members['MANIFEST.json'] = json.dumps(manifest, indent=2).encode()
destination = repo/'engineering/validation/pipeline-preparation-owner-fault-evidence.zip'
assert not destination.exists(), 'Preserve previously committed evidence'
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members)
    for name, data in members.items():
        assert archive.read(name) == data
receipt = dict(path=str(destination), members=len(members), bytes=destination.stat().st_size,
               sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
               finalSourceFiles=len(final), phases=receipts)
(base/'idle-preparation-fault-archive-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt, indent=2))
