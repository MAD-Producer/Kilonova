import hashlib, json, shutil
from pathlib import Path
p = Path(__file__).parent
paths = json.loads((p / 'before-source.json').read_text('utf-8'))
hashes = {}
for path in paths:
    data = Path(path).read_bytes()
    output = p / 'candidate-source' / path
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(data)
    hashes[path] = hashlib.sha256(data).hexdigest()
(p / 'candidate-source.json').write_text(json.dumps(hashes, indent=2), 'utf-8')
for suffix in ['jsonl', 'stderr']:
    shutil.copyfile(p / ('app-build.' + suffix), p / ('candidate-build.' + suffix))
