import hashlib, json, shutil, subprocess
from pathlib import Path
p = Path(__file__).parent
root = Path.cwd()
base = 'f1c3ae8f2af38bf14a6b893a953aad864bc7a538'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == base
paths = ['desktop/app/src/node_editor/view/' + name for name in
    ['mod.rs', 'interaction.rs', 'frame_cards_tests.rs', 'frame_cards_tests/restore_geometry.rs', 'frame_cards_tests/viewport_geometry.rs']]
hashes = {}
for path in paths:
    data = (root / path).read_bytes()
    dest = p / 'before-source' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    hashes[path] = hashlib.sha256(data).hexdigest()
    if path.endswith(('/mod.rs', '/interaction.rs', '/viewport_geometry.rs')):
        assert subprocess.check_output(['git', 'show', base + ':' + path]) == data
(p / 'before-source.json').write_text(json.dumps(hashes, indent=2), 'utf-8')
for suffix in ['jsonl', 'stderr']:
    shutil.copyfile(p / ('app-build.' + suffix), p / ('before-build.' + suffix))
print(json.dumps(hashes))
