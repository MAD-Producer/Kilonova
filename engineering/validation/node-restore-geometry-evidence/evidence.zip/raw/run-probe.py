import ast, hashlib, json, os, re, subprocess, sys
from pathlib import Path
p = Path(__file__).parent
stage = sys.argv[1]
rows = [json.loads(l) for l in (p / 'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
assert rows[-1] == dict(reason='build-finished', success=True)
exe = [r['executable'] for r in rows if r.get('reason') == 'compiler-artifact' and r['target']['name'] == 'motion-studio' and r.get('executable')][-1]
env = os.environ.copy()
env.pop('RUST_MIN_STACK', None)
env['MOTION_LOG'] = 'info'
env['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + env['PATH']
receipts = []
for index, name in enumerate(['lost_held_restoration_builds_only_the_final_cards_and_preserves_revision_semantics', 'record_complete_restoration_frames_for_original_path_comparison']):
    local = env.copy()
    if index == 1: local['MOTION_NODE_RESTORE_EVIDENCE'] = str(p / (stage + '-paint.json'))
    command = [exe, '--exact', 'node_editor::view::frame_cards_tests::restore_geometry::' + name, '--test-threads=1', '--nocapture']
    result = subprocess.run(command, env=local, capture_output=True)
    (p / f'{stage}-{index}.stdout').write_bytes(result.stdout)
    (p / f'{stage}-{index}.stderr').write_bytes(result.stderr)
    assert b'running 1 test' in result.stdout
    row = dict(command=command, exit=result.returncode, expected_exit=101 if stage == 'before' and index == 0 else 0,
        executable_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest())
    receipts.append(row)
    print(json.dumps(row), flush=True)
(p / (stage + '-tests.json')).write_text(json.dumps(receipts, indent=2), 'utf-8')
assert all(r['exit'] == r['expected_exit'] for r in receipts)
if stage == 'before':
    match = re.search(r'one final card build after restoration: (\[.*\])', (p / 'before-0.stderr').read_text('utf-8'))
    assert match, 'functional failure is not a performance negative control'
    counts = ast.literal_eval(match[1])
    assert len(counts) == 320 and all(ports == builds * nodes for _, builds, ports, nodes in counts)
    changed = [r for r in counts if r[0].endswith('-lost')]
    assert len(changed) == 64 and all(r[1] == 2 for r in changed)
    (p / 'before-counts.json').write_text(json.dumps(counts, indent=2), 'utf-8')
else:
    before = json.loads((p / 'before-paint.json').read_text('utf-8'))
    final = json.loads((p / (stage + '-paint.json')).read_text('utf-8'))
    assert len(before) == len(final) == 320 and before == final
    comparison_path = p / ('restore-comparison.json' if stage == 'final' else stage + '-comparison.json')
    comparison_path.write_text(json.dumps(dict(frames=320, exact_equal=True, normalization=False,
        before_sha256=hashlib.sha256((p / 'before-paint.json').read_bytes()).hexdigest(),
        final_sha256=hashlib.sha256((p / (stage + '-paint.json')).read_bytes()).hexdigest()), indent=2), 'utf-8')
old_name = 'initial_pointer_batch_and_normal_release_reuse_metadata_but_identity_restoration_rebuilds'
if stage == 'final': old_name = 'initial_pointer_batch_release_and_restoration_use_current_geometry_once'
command = [exe, '--exact', 'node_editor::view::frame_cards_tests::viewport_geometry::' + old_name, '--test-threads=1', '--nocapture']
result = subprocess.run(command, env=env, capture_output=True)
(p / (stage + '-existing-count.stdout')).write_bytes(result.stdout)
(p / (stage + '-existing-count.stderr')).write_bytes(result.stderr)
assert b'running 1 test' in result.stdout
receipt = dict(command=command, exit=result.returncode, expected_exit=101 if stage == 'candidate' else 0)
(p / (stage + '-existing-count.json')).write_text(json.dumps(receipt, indent=2), 'utf-8')
assert result.returncode == receipt['expected_exit']
if stage == 'candidate':
    assert b'left: 1' in result.stderr and b'right: 2' in result.stderr
print(json.dumps(receipt), flush=True)
