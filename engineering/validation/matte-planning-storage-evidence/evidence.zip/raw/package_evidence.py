import hashlib, json, pathlib, re, subprocess, zipfile

ROOT = pathlib.Path('E:/Dev/aem/.worktrees/layer-time-mapping')
RAW = pathlib.Path(__file__).resolve().parent
DEST = ROOT / 'engineering/validation/matte-planning-storage-evidence'
BASE = '9a2ae9f09136107038387fd4417115b867da80d4'

def read(name):
    data = (RAW / name).read_bytes()
    return data.decode('utf-16' if data[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig')

def sha(path):
    return hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()

results = {}
for name, expected in [('before-frame', 1), ('final-planning', 4), ('final-frame', 1),
                       ('final-admission', 5), ('final-integration', 12), ('final-workspace', 0)]:
    assert int(read(name + '.exit')) == 0, name
    log = read(name + '.log')
    matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', log)
    assert sum(int(x[0]) for x in matches) == expected, (name, matches)
    assert all(x[1:] == ('0', '0') for x in matches), (name, matches)
    results[name] = {'exit_code': 0, 'passed': expected, 'log': name + '.log'}
for name in ['fixture-compile-failure', 'fixture-depth-failure', 'before-planning']:
    assert int(read(name + '.exit')) == 101, name
assert '2 failed' in read('before-planning.log')
assert 'allocations=600' in read('before-planning.log')
assert 'allocations=120' in read('before-planning.log')
measurements = {}
for phase in ['before', 'final']:
    # The Rust harness prefixes the first nocapture record with its test name.
    rows = [json.loads(match.group(1)) for line in read(phase + '-frame.log').splitlines()
            if (match := re.search(r'(\{.*\})$', line))]
    assert len(rows) == 144
    summary = []
    for kind in ['solid', 'vector', 'matte']:
        for layers in [1, 8, 32]:
            group = [x for x in rows if x['kind'] == kind and x['layers'] == layers]
            assert [x['frame'] for x in group] == list(range(4, 20))
            summary.append({'kind': kind, 'layers': layers, 'frames': len(group),
                'ranges': {key: [min(x[key] for x in group), max(x[key] for x in group)]
                    for key in ['sample', 'prepare', 'create', 'encode', 'submit', 'poll', 'total']}})
    measurements[phase] = summary
(RAW / 'frame-allocation-summary.json').write_text(json.dumps(measurements, indent=2) + '\n', encoding='utf-8')
sources = ['crates/motion-render/src/compositing_gpu.rs', 'crates/motion-render/src/renderer.rs',
    'crates/motion-render/src/renderer/compositing.rs',
    'crates/motion-render/src/renderer/compositing/tests.rs',
    'crates/motion-render/src/renderer/preview_allocation_tests.rs',
    'crates/motion-render/src/renderer/admission_tests/matte_textures.rs',
    'crates/motion-render/src/test_allocations.rs',
    'crates/motion-render/tests/layer_compositing.rs',
    'crates/motion-render/tests/composition_precision.rs',
    'engineering/validation/matte-planning-storage.md']
binaries = {}
for name in ['final-planning', 'final-frame', 'final-admission', 'final-integration']:
    for item in re.findall(r'Running[^\n]*\(([^\n]+\.exe)\)', read(name + '.log')):
        path = pathlib.Path(item)
        binaries[path.name] = sha(path)
assert len(binaries) == 3, binaries
DEST.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(DEST / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(RAW.iterdir()):
        if path.is_file() and (path.suffix in ['.log', '.exit', '.py', '.json']
                              or path.name == 'packaging-first-failure.txt'):
            archive.write(path, 'raw/' + path.name)
    for relative in sources:
        archive.write(ROOT / relative, 'final-source/' + relative)
    for relative in sources[:3]:
        archive.writestr('base-production/' + relative,
            subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=ROOT))
manifest = {'base_commit': BASE, 'issue': 126, 'issue_complete': False,
    'branch': 'perf/matte-planning-storage', 'stack_base': 589,
    'results': results, 'final_distinct_tests': 22,
    'frame_allocation_counts': measurements,
    'measurement_scope': 'Successful alloc/alloc_zeroed/realloc on test calling thread; real sampling, asset preparation, encoder creation, preview encoding, finish/submit, blocking completion poll. No readback/reference drawing, bytes, other threads or driver external memory.',
    'baseline_failures': ['fixture-compile-failure', 'fixture-depth-failure', 'before-planning'],
    'baseline_binary_identity': 'Not retained; baseline production sources and raw execution logs archived. Full-frame fixture behavior unchanged; coverage test owner adapted without weakening assertions.',
    'commands': [
        'cargo test -p motion-render --lib renderer::compositing::tests --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture',
        'cargo test -p motion-render --lib preview_allocation_tests --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture',
        'cargo test -p motion-render --lib renderer::admission_tests::matte_textures --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture',
        'cargo test -p motion-render --test layer_compositing --test composition_precision --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture',
        'cargo check --workspace --all-targets --exclude motion-android --locked --features motion-desktop/ffmpeg,motion-host/diagnostics --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target'],
    'source_sha256_raw_files': {name: sha(ROOT / name) for name in sources},
    'binary_sha256': binaries, 'evidence_zip_sha256': sha(DEST / 'evidence.zip'),
    'limits': ['Whole-frame allocation requirement still unmet.', 'Local native GPU only; cross-platform CI pending.',
        'No new observability channel; existing actual rejection and resource recovery regression exercised.'],
    'ci': 'pending for final head'}
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'final_distinct_tests': 22, 'source_files': len(sources),
    'binaries': list(binaries), 'archive_bytes': (DEST / 'evidence.zip').stat().st_size}))
