import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('E:/Dev/aem/.worktrees/vector-animation-acceptance')
out = Path(__file__).parent
phase = sys.argv[1]
command = sys.argv[2:]
sources = {}
for file in ['.github/workflows/ci.yml', 'crates/motion-render/tests/vector_upload_reuse.rs', 'crates/motion-render/src/layer_gpu.rs', 'crates/motion-render/src/layer_gpu/groups.rs', 'crates/motion-render/src/vector_upload.rs']:
    sources[file] = hashlib.sha256((root / file).read_bytes()).hexdigest()
start = time.time()
with (out / (phase + '.stdout')).open('wb') as stdout, (out / (phase + '.stderr')).open('wb') as stderr:
    result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr)
record = {'command': command, 'exit': result.returncode, 'elapsed_seconds': time.time() - start, 'sources': sources}
for file, sha in sources.items():
    if hashlib.sha256((root / file).read_bytes()).hexdigest() != sha:
        record['source_changed_during_run'] = file
(out / (phase + '.json')).write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps(record), flush=True)
print((out / (phase + '.stdout')).read_text(encoding='utf-8', errors='replace')[-7000:], flush=True)
print((out / (phase + '.stderr')).read_text(encoding='utf-8', errors='replace')[-2000:], flush=True)
