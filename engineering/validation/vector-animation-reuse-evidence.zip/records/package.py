import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

root = Path('E:/Dev/aem/.worktrees/vector-animation-acceptance')
out = Path(__file__).parent
record = json.loads((out / 'vector-regression.json').read_text())
assert record['exit'] == 0 and 'source_changed_during_run' not in record
results = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out', (out / 'vector-regression.stdout').read_text())
assert len(results) == 5 and sum(int(row[0]) for row in results) == 26
assert all(all(int(v) == 0 for v in row[1:]) for row in results)
test_sha = record['sources']['crates/motion-render/tests/vector_upload_reuse.rs']
for phase in ['negative-recreate', 'negative-stale']:
    failed = json.loads((out / (phase + '.json')).read_text())
    assert failed['exit'] == 101 and 'source_changed_during_run' not in failed
    assert failed['sources']['crates/motion-render/tests/vector_upload_reuse.rs'] == test_sha
for file, sha in record['sources'].items():
    assert hashlib.sha256((root / file).read_bytes()).hexdigest() == sha
for file in record['sources']:
    if '/src/' in file:
        original = subprocess.run(['git', 'show', 'HEAD:' + file], cwd=root, capture_output=True, check=True).stdout
        assert original == (root / file).read_bytes()
rows = []
for line in (out / 'vector-regression.stderr').read_text().splitlines():
    if line.startswith('{"admittedBytes":'):
        rows.append(json.loads(line))
assert len(rows) == 60
increments = [rows[i]['uploads']['encodedUploadBytesTotal'] - rows[i - 1]['uploads']['encodedUploadBytesTotal'] for i in range(1, 60)]
summary = {
    'base': 'e314cc92232dcd366b01e10454ae1100d4e24d63',
    'nativeGpuTests': 26,
    'nativeTargets': 5,
    'policyTests': 15,
    'newTestIncludedInNativeCount': True,
    'warmFrames': 60,
    'measuredFrames': 60,
    'independentReferenceFrames': [0, 1, 15, 30, 45, 59],
    'distinctMeasuredUploadSizes': sorted(set(increments)),
    'destinationCreationTotals': sorted({r['uploads']['destinationBuffersCreatedTotal'] for r in rows}),
    'stagingCreationTotals': sorted({r['uploads']['stagingBuffersCreatedTotal'] for r in rows}),
    'admittedBytes': sorted({r['admittedBytes'] for r in rows}),
    'expectedNegativeFailures': ['negative-recreate', 'negative-stale'],
    'testSha256': test_sha,
    'productionSourceUnchanged': True,
}
(out / 'test-summary.json').write_text(json.dumps(summary, indent=2))
archive = root / 'engineering/validation/vector-animation-reuse-evidence.zip'
members = {}
for file in out.iterdir():
    if file.suffix in ['.json', '.stdout', '.stderr', '.rs', '.txt', '.patch', '.py'] and file.name not in ['archive-receipt.json', 'pr-created.json', 'pr-body.md', 'commit.txt']:
        members['records/' + file.name] = file.read_bytes()
for file in record['sources']:
    members['source/' + file] = (root / file).read_bytes()
members['manifest.json'] = json.dumps({name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in members.items()}, indent=2).encode()
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, data in members.items():
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, data in members.items():
        assert z.read(name) == data
receipt = {'members': len(members), 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'summary': summary}
(out / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt))
