from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd()
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
files=[p for p in files if p.endswith('.rs')]
out=Path('E:/Dev/aem/artifacts/issue-goal-current/local-roving')
rows={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
(out/'source-hashes.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print(json.dumps(rows,indent=2))
