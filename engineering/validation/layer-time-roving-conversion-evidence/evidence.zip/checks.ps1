rustfmt --edition 2021 --config skip_children=true --check crates/motion-model/src/keyframe_clipboard/spatial.rs crates/motion-core/tests/spatial_key_time.rs desktop/app/src/panels/animation_menu/roving.rs desktop/app/src/panels/animation_menu/roving/mapped_tests.rs desktop/app/src/panels/animation_menu/roving/mapped_tests/native.rs desktop/app/src/engine/animation_action_tests/spatial_enable.rs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python -c "import runpy; runpy.run_path('tools/ci_desktop.py')['verify_style_consumers']()"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
git diff --check
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Output 'rustfmt (six changed/new modules), style consumers and git diff --check passed'
