import os, subprocess, json, hashlib, time, re, sys
from pathlib import Path
root=Path(__file__).resolve().parent
target=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps')
exe=target/'motion_studio-b34b3a7e7eb835e8.exe'
env=os.environ.copy()
env.pop('MOTION_LOG',None)
env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
env['MOTION_LOCAL_ROVING_NATIVE_ARTIFACTS']=str(root/'native-accepted')
env['MOTION_LOCAL_ROVING_CLOCK_ARTIFACTS']=str(root/'clock-faults-accepted')
env['MOTION_LOCAL_ROVING_WORKER_ARTIFACTS']=str(root/'worker-faults-accepted')
env['MOTION_MAPPED_SPATIAL_ERROR_ARTIFACTS']=str(root/'old-worker-faults-accepted')
env['MOTION_ROVING_MENU_ERROR_ARTIFACTS']=str(root/'old-menu-faults-accepted')
groups=[
 ('model-time',target/'spatial_key_time-fd14e61b96ce2202.exe',[]),
 ('model-spatial',target/'spatial_keyframes-72e6c7630329e05f.exe',[]),
 ('mapped-ui',exe,['panels::animation_menu::roving::mapped_tests::']),
 ('old-menu',exe,['panels::animation_menu::roving::tests::']),
 ('workers',exe,['engine::animation_action_tests::spatial_time::']),
 ('selection',exe,['panels::key_selection::']),
 ('native',exe,['--exact','panels::animation_menu::roving::mapped_tests::native::signed_local_native_menus_and_floating_views_use_real_worker_conversion','--ignored']),
]
results=[]
for name,binary,args in groups:
 if len(sys.argv)>1 and name not in sys.argv[1:]:continue
 sha=hashlib.sha256(binary.read_bytes()).hexdigest(); started=time.time()
 with (root/(name+'.log')).open('wb') as f:
  proc=subprocess.run([str(binary),*args,'--nocapture','--test-threads=1'],stdout=f,stderr=subprocess.STDOUT,env=env)
 text=(root/(name+'.log')).read_text(encoding='utf-8',errors='replace')
 match=re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
 row=dict(group=name,args=args,exit=proc.returncode,seconds=round(time.time()-started,3),exe=str(binary),exeSha256=sha)
 if match: row.update(passed=int(match[1]),failed=int(match[2]),ignored=int(match[3]))
 results.append(row)
 (root/('results-'+('-'.join(sys.argv[1:]) or 'all')+'.json')).write_text(json.dumps(results,indent=2),encoding='utf-8')
 print(json.dumps(row),flush=True)
 assert hashlib.sha256(binary.read_bytes()).hexdigest()==sha
 if proc.returncode:raise SystemExit(proc.returncode)
 assert row['passed']>0,'empty test filter'
