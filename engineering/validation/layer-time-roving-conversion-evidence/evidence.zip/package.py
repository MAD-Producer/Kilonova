from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
raw=Path('E:/Dev/aem/artifacts/issue-goal-current/local-roving')
repo=Path.cwd()
out=repo/'engineering/validation/layer-time-roving-conversion-evidence'
out.mkdir(exist_ok=True)
old=json.loads((raw/'pre-menu-open/results-all.json').read_text(encoding='utf-8'))
old=[g for g in old if g['group']!='native']
new=json.loads((raw/'results-native.json').read_text(encoding='utf-8'))
assert len(new)==1 and new[0]['group']=='native'
assert all(r['exit']==0 and r['failed']==0 for r in old+new)
assert sum(r['passed'] for r in old+new)==117
previous=json.loads((raw/'pre-menu-open/source-hashes.json').read_text(encoding='utf-8'))
current=json.loads((raw/'source-hashes.json').read_text(encoding='utf-8'))
for name,sha in current.items():
 assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==sha,name
 if not name.endswith('mapped_tests/native.rs'):assert previous[name]==sha,name
ignored=[]
for name in ['mapped-ui.log','selection.log']:
 ignored += [line.split(' ... ')[0].removeprefix('test ') for line in (raw/'pre-menu-open'/name).read_text(encoding='utf-8',errors='replace').splitlines() if ' ... ignored,' in line]
ignored=[name for name in ignored if name not in new[0]['args']]
assert len(ignored)==10
native=raw/'native-accepted'
assert len(list(native.glob('*.png')))==24
for source,dest in [('forward-zh-main-menu-ordinary.png','menu-before-zh.png'),('forward-zh-main-menu-roving.png','menu-roving-zh.png'),('reverse-en-float-fixed.png','timeline-floating-en.png')]:
 shutil.copy2(native/source,out/dest)
allowed=['build-initial.log','model-time-initial.log','mapped-ui-initial.log','results-model-time-mapped-ui-initial.json','results-mapped-ui-initial.json','build.log','build.ps1','run.py','freeze.py','source-hashes.json','results-native.json','native.log','workspace-check-pre-menu.log','workspace-check.log','workspace.ps1','checks.log','checks.ps1','package.py']
folders=['pre-menu-open','clock-faults','native-accepted']
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in allowed:
  p=raw/name
  if p.exists():z.write(p,name)
 for folder in folders:
  for p in (raw/folder).rglob('*'):
   if p.is_file():z.write(p,p.relative_to(raw).as_posix())
 for name in current:z.write(repo/name,'sources/'+name)
archive=out/'evidence.zip'
manifest={'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'issue':257,'pr':579,'tests':old+new,'distinctPassed':117,'manualNotRun':ignored,'nativePng':24,'sourceHashes':current,'previousSourceHashes':previous,'scope':'116 passing checks use unchanged production sources; the final native-only rebuild adds menu-reopen capture assertions and is rerun explicitly','archiveBytes':archive.stat().st_size,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({k:manifest[k] for k in ['distinctPassed','nativePng','archiveBytes','archiveSha256']},indent=2))
