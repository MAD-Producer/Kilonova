from pathlib import Path
import hashlib, json, subprocess, zipfile

P = Path(__file__).parent
S = Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
OUT = P / 'desktop-current-registry-evidence.zip'
assert not OUT.exists()
report = json.loads((P/'current-registry-renderer-normal-app-evidence/report.json').read_text(encoding='utf-8'))
assert len(report['runs']) == 8
assert len({r['pid'] for r in report['runs']}) == 8
for r in report['runs']:
    assert r['exit_code'] == 0
    assert r['driver_load'] == ('missing' if r['kind'] == 'cold' else 'restored')
    if r['pair'] == 'damaged-archive':
        assert r['default_error_file_stderr_stdout_isolation']

source = None
for phase in ['current-registry-renderer-native-tests-corrected','current-registry-renderer-effects-tests',
              'current-registry-renderer-host-observation','current-registry-renderer-archive-pixels',
              'current-registry-renderer-normal-app-build','current-registry-renderer-all-targets',
              'current-registry-renderer-normal-app-run']:
    r = json.loads((P/(phase+'.json')).read_text(encoding='utf-8'))
    assert r['exit_code'] == 0, phase
    assert r['source_before'] == r['source_after'], phase
    if source is None: source = r['source_before']
    assert source == r['source_before'], phase

members = {}
def add(name, data):
    assert name not in members, name
    members[name] = data

for f in sorted(P.glob('current-registry-*')):
    if f.is_file() and f.suffix in ['.json','.stdout','.stderr']:
        add('commands/'+f.name, f.read_bytes())
for directory, prefix in [('current-registry-renderer-normal-app-evidence','application'),
                          ('current-registry-normal-app-evidence','historical-partial-fix'),
                          ('current-registry-baseline-repeat-evidence','baseline-repeat')]:
    for f in sorted((P/directory).rglob('*')):
        if not f.is_file(): continue
        relative=f.relative_to(P/directory)
        if 'account' in relative.parts: continue
        if f.suffix not in ['.json','.jsonl','.log','.png']: continue
        add(prefix+'/'+relative.as_posix(),f.read_bytes())
for name in ['run.py','run_current_registry_normal_app.py','run_registry_baseline_repeat.py','archive_current_registry.py','validate_registry_renderer.ps1']:
    add('controller/'+name,(P/name).read_bytes())
add('controller/template-project.json',
    (P/'frame-completion-existing-model-layer-evidence/project/project.json').read_bytes())
add('tested-source-identity.json',json.dumps(source,indent=2).encode())
add('working.patch',subprocess.check_output(['git','diff','--binary','HEAD'],cwd=S))
add('current_registry.rs',(S/'crates/motion-effects/tests/current_registry.rs').read_bytes())
add('initial_registry_tests.rs',(S/'crates/motion-render/src/renderer/initial_registry_tests.rs').read_bytes())
runtime=[]
for f in sorted((P/'current-registry-renderer-runtime').iterdir()):
    if f.is_file():
        with f.open('rb') as stream: sha=hashlib.file_digest(stream,'sha256').hexdigest()
        runtime.append({'name':f.name,'bytes':f.stat().st_size,'sha256':sha})
add('runtime-identity.json',json.dumps(runtime,indent=2).encode())
manifest=[{'name':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
          for n,b in sorted(members.items())]
add('manifest.json',json.dumps(manifest,indent=2).encode())
with zipfile.ZipFile(OUT,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(members.items()): z.writestr(n,b)
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    for r in manifest: assert hashlib.sha256(z.read(r['name'])).hexdigest()==r['sha256']
receipt={'archive':str(OUT),'members':len(members),'bytes':OUT.stat().st_size,
         'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'source_count':len(source),
         'base_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),
         'normal_app_runs':8,'baseline_repeat_runs':4,'exit_code':0}
(P/'current-registry-archive-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
