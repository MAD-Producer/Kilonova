$ErrorActionPreference = 'Stop'
. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:CARGO_TARGET_DIR='E:\Dev\aem\.tools\viewer-inspection\native-target'
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:TEMP='E:\Dev\aem\artifacts\issue-goal-current\native-pipeline-preparation\temp'
$env:TMP=$env:TEMP
$env:TMPDIR=$env:TEMP
$env:FFMPEG_DIR='E:\Dev\aem\.tools\ffmpeg-dev\ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:LIBCLANG_PATH='E:\Dev\aem\.tools\python-libclang\clang\native'
$env:PATH="$env:FFMPEG_DIR\bin;$env:PATH"
$env:PYTHONIOENCODING='utf-8'
$evidence='E:/Dev/aem/artifacts/issue-goal-current/native-pipeline-preparation'
Set-Location -LiteralPath 'E:/Dev/aem/.worktrees/desktop-arm-runner'
python "$evidence/run.py" current-registry-renderer-native-tests-corrected cargo test --locked -p motion-render --lib initial_registry_tests -- --test-threads=1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python "$evidence/run.py" current-registry-renderer-effects-tests cargo test --locked -p motion-effects --test current_registry --test packages --test archive_identity --test retired_builtins --test package_budget -- --test-threads=1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python "$evidence/run.py" current-registry-renderer-host-observation cargo test --locked -p motion-host --lib --features diagnostics,ai-depth registry_observation -- --test-threads=1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python "$evidence/run.py" current-registry-renderer-archive-pixels cargo test --locked -p motion-render --test effect_loop_parity -- --test-threads=1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python "$evidence/run.py" current-registry-renderer-normal-app-build cargo build --locked -p motion-desktop --bin motion-studio --features ffmpeg,motion-host/diagnostics,motion-host/ai-depth
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python "$evidence/run.py" current-registry-renderer-all-targets cargo check --locked -p motion-desktop --all-targets --features ffmpeg,motion-host/diagnostics,motion-host/ai-depth
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$bundle=Join-Path $evidence 'current-registry-renderer-runtime'
if (Test-Path -LiteralPath $bundle) { throw 'Never overwrite a runtime bundle' }
New-Item -ItemType Directory -Path $bundle | Out-Null
Copy-Item -LiteralPath "$env:CARGO_TARGET_DIR/debug/motion-studio.exe" -Destination (Join-Path $bundle 'motion-studio.exe')
Get-ChildItem -LiteralPath "$env:FFMPEG_DIR/bin" -Filter '*.dll' | ForEach-Object {
    New-Item -ItemType HardLink -Path (Join-Path $bundle $_.Name) -Target $_.FullName | Out-Null
}
python "$evidence/run.py" current-registry-renderer-normal-app-run python "$evidence/run_current_registry_normal_app.py" "$bundle/motion-studio.exe" "$evidence/current-registry-renderer-normal-app-evidence"
exit $LASTEXITCODE

