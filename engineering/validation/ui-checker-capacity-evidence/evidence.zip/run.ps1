. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:RUST_MIN_STACK='33554432'
$env:MOTION_LOG='info'
git rev-parse HEAD > E:/Dev/aem/artifacts/issue-goal-current/ui-checker-capacity/source-head.txt
git diff -- desktop/ui > E:/Dev/aem/artifacts/issue-goal-current/ui-checker-capacity/source.patch
cargo test -p motion-ui --lib --features gpu-tests --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --message-format=json -- paint::buffer_tests:: --test-threads=1 --nocapture 1> E:/Dev/aem/artifacts/issue-goal-current/ui-checker-capacity/buffer.stdout 2> E:/Dev/aem/artifacts/issue-goal-current/ui-checker-capacity/buffer.stderr
$bufferExit=$LASTEXITCODE
cargo test -p motion-ui --test path_antialiasing --features gpu-tests --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --message-format=json -- --test-threads=1 --nocapture 1> E:/Dev/aem/artifacts/issue-goal-current/ui-checker-capacity/path.stdout 2> E:/Dev/aem/artifacts/issue-goal-current/ui-checker-capacity/path.stderr
$pathExit=$LASTEXITCODE
@{buffer_exit=$bufferExit;path_exit=$pathExit;completed=(Get-Date).ToString('o')} | ConvertTo-Json | Set-Content E:/Dev/aem/artifacts/issue-goal-current/ui-checker-capacity/results.json
if($bufferExit -ne 0 -or $pathExit -ne 0){exit 1}
