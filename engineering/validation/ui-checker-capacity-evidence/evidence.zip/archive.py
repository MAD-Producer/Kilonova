from pathlib import Path
import json,hashlib,subprocess,zipfile,re
root=Path('E:/Dev/aem/.worktrees/layer-time-mapping');raw=Path('E:/Dev/aem/artifacts/issue-goal-current/ui-checker-capacity')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
results=json.loads((raw/'final-results.json').read_text(encoding='utf-8-sig'))
assert results['library_exit']==results['path_exit']==0
for name,n in [('ui-library-writable-temp.stdout',91),('path-final.stdout',12)]:
 text=(raw/name).read_text(encoding='utf-8-sig');assert f'{n} passed; 0 failed; 0 ignored' in text
sources=['desktop/ui/tests/path_antialiasing.rs','desktop/ui/tests/path_antialiasing/checkerboard.rs','desktop/ui/src/paint/buffer_tests.rs','desktop/ui/src/paint.rs','desktop/ui/src/shaders/panel.wgsl']
receipt={'head':git('rev-parse','HEAD'),'ui_source_tree':git('rev-parse','HEAD:desktop/ui/src'),'runtime_source_diff_empty':not git('diff','85ae6868','--','crates','desktop/app','desktop/ui/src','Cargo.toml','Cargo.lock'),'sources':{s:sha(root/s) for s in sources},'unique_passing_tests':103,'library_tests':91,'path_tests':12,'buffer_tests_subset':6,'invalid_cpu_sizes':6,'positive_cpu_configurations':14,'invalid_gpu_images':30,'subminimum_gpu_images':20,'one_pixel_reference_images':5,'independent_cpu_gpu_images':8}
assert receipt['runtime_source_diff_empty']
for name in ['buffer.stdout','path-final.stdout']:
 items=[]
 for line in (raw/name).read_text(encoding='utf-8-sig').splitlines():
  try:item=json.loads(line)
  except ValueError:continue
  if item.get('reason')=='compiler-artifact' and item.get('executable'):
   exe=Path(item['executable']);items.append({'path':str(exe),'sha256':sha(exe),'profile':item['profile'],'features':item['features']})
 receipt[name+'_executables']=items
(raw/'source-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
out=root/'engineering/validation/ui-checker-capacity-evidence';out.mkdir(exist_ok=True)
files={p.name:p for p in raw.iterdir() if p.is_file() and p.suffix not in ['.exe','.pdb']}
for source in sources:files['source/'+source]=root/source
manifest={name:{'sha256':sha(p),'bytes':p.stat().st_size} for name,p in files.items()}
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(out/'evidence.zip') as z:
 assert set(z.namelist())==set(manifest)
 for name,data in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==data['sha256']
(out/'manifest.json').write_text(json.dumps({'archive_sha256':sha(out/'evidence.zip'),'members':manifest},indent=2),encoding='utf-8')
print(json.dumps({'tests':103,'zip_bytes':(out/'evidence.zip').stat().st_size,'source_receipt':receipt['ui_source_tree']}))
