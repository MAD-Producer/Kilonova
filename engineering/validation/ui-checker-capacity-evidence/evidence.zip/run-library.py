import json,subprocess,hashlib,time,os,uuid
from pathlib import Path
p=Path('E:/Dev/aem/artifacts/issue-goal-current/ui-checker-capacity')
previous=json.loads((p/'ui-library.json').read_text(encoding='utf-8'))
exe=Path(previous['command'][0]);assert hashlib.sha256(exe.read_bytes()).hexdigest()==previous['exe_sha256']
probe=Path(os.environ['TEMP'])/('motion-ui-write-probe-'+uuid.uuid4().hex)
try:
 probe.write_bytes(b'probe');probe.unlink();probe_result={'path':str(probe),'writable':True}
except OSError as e:probe_result={'path':str(probe),'writable':False,'error':repr(e),'winerror':e.winerror}
(p/'default-temp-probe.json').write_text(json.dumps(probe_result,indent=2),encoding='utf-8')
root=p/'runtime-temp';root.mkdir(exist_ok=True)
env=os.environ.copy();env['MOTION_LOG']='info';env['TEMP']=str(root);env['TMP']=str(root);env.pop('RUST_MIN_STACK',None)
started=time.time();cmd=previous['command']
with (p/'ui-library-writable-temp.stdout').open('wb') as out,(p/'ui-library-writable-temp.stderr').open('wb') as err:
 result=subprocess.run(cmd,stdout=out,stderr=err,env=env)
receipt={'command':cmd,'exit':result.returncode,'elapsed_seconds':time.time()-started,'exe_sha256':previous['exe_sha256'],'temp':str(root),'source_changed':False}
(p/'ui-library-writable-temp.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
raise SystemExit(result.returncode)
