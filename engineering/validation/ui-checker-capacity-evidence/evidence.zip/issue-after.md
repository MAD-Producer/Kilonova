核验日期：2026-10-12

核验基线：[1771a00](https://github.com/Yukk1o/motion-studio/commit/1771a006104952d2ca7e47df004e729724239b89)，位于 `codex/desktop-shortcuts-20261011`、领先 main；结论仅对该提交成立

## 已核验现状

UI 框架层的一组独立缺陷，与 [issue 114](https://github.com/MAD-Producer/motion-studio/issues/114)（绘制顺序）、[issue 116](https://github.com/MAD-Producer/motion-studio/issues/116)（DPI）、[issue 117](https://github.com/MAD-Producer/motion-studio/issues/117)（列表与标签索引）不重叠，逐条列出以便各自回归。

### 一、`clip_to` 是钳制而非裁剪，会产生沿边界的幽灵线

[paint.rs:53-69](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/paint.rs#L53-L69)

剔除条件是「既无顶点落入矩形、又在两个轴上都不跨越」；跨越时保留全部顶点并逐点 `clamp`。以 `Shape::Line` 的折线 `[(200,100),(200,200),(-50,200)]` 裁剪到 `Rect::new(0,0,100,100)` 为例：无顶点落入，但 X 方向跨越（−50…200），因此被保留并钳制为 `[(100,100),(100,100),(0,100)]`，`expand_line` 会在裁剪区底边渲染出一条水平 1px 线，而原折线从未触及该区域。

钳制本身对背景矩形是必要的（跨越 `bounds` 的面板背景需要折叠到较窄的 clip），因此不能简单删除；正确做法是让 `Line` 走与 `clip_triangles`（Sutherland–Hodgman）相同的多边形裁剪。

### 二、字形图集耗尽时中途清空，已发出的 UV 全部失效

[text.rs:217-222](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/text.rs#L217-L222)

```rust
if self.cursor[1] + height as f32 + padding as f32 > self.config.height as f32 {
    self.clear();     // 清空 entries 与像素，随后继续执行并从 (0,0) 重排
}
```

本帧此前已拷入 `list.glyphs` 的 `GlyphEntry` 仍携带旧 UV，而这些区域现在对应完全不同的字形。结果是全窗口一帧乱码（`dirty` 标志会触发下一帧全量重传，因此可自愈）。图集为 1024×1024，缓存键含字号位模式，配合 CJK 字形广度可达该上限。注释提到可增长，但未实现增长或淘汰策略。

另有边界：[text.rs:217-237](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/text.rs#L217-L237) 的写入索引只对字形的宽高做检查、不对图集边界做检查，`height > config.height` 时越界 panic。经样式表字号限制（1..=128，见 [style.rs:342](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/style.rs#L342)）当前不可达，但 `TextAtlas::from_system(scale)` 接受任意 `f32`。

### 三、scrub_field 的标签与数值区域重叠

[ui.rs:227-241](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/ui.rs#L227-L241)。标签以**完整** `area` 排版，数值占右侧 55%；任何超过 45% 宽度的标签都会伸到数值下方，两者都是字形，数值后绘制并覆盖标签尾部。`widgets.rs:98` 与 `tabs.rs:119-122` 都正确地把标签裁到 `end - x`，此处未遵循。

### 四、控件与导航

| 位置 | 问题 |
|---|---|
| [paint.rs:256-259](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/paint.rs#L256-L259) | `checkerboard` 不校验 `size`。`size = 0` 时 `x/0.0 = inf`，`inf.ceil() as i32` 饱和为 `i32::MAX`，在渲染线程进入约 4×10¹⁸ 次迭代；`< 1.0` 的有限值则生成足够多的方块触发顶点缓冲超限。对比 `icons::draw`（[icons.rs:161](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/icons.rs#L161)）**确实**校验了 `is_finite` |
| [paint.rs:613-618](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/paint.rs#L613-L618) | `SOLID_CAPACITY`(1<<16，约 10922 个四边形)与 `GLYPH_CAPACITY` 在 `write_buffer` 前从不校验，wgpu 超限直接 panic |
| [widgets.rs:293-303](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/widgets.rs#L293-L303) | `NumberEditor` 外层对 `input.released.is_some()` 无条件结束拖拽，内层分支却检查了 `button == Left`。右键或中键松开会提交并中止正在进行的数值拖拽 |
| [widgets.rs:459-464](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/widgets.rs#L459-L464) | 直接读 `input.keys` 忽略并行的 `input.key_repeats`，长按空格／回车会以系统自动重复频率反复触发。框架已有正确的 `KeyChord::pressed`（[input.rs:90-94](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/input.rs#L90-L94)，同时过滤 `repeat` 与 IME） |
| [interaction.rs:101-113](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/interaction.rs#L101-L113) | `targets.dedup()` 只合并相邻重复，非相邻重复会让 Shift-Tab 停在同一控件；焦点在浮窗时 `current` 为 `None`，Tab 总是落到 `targets[0]` 而非新焦点窗口的首个控件 |
| [input.rs:263-282](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/input.rs#L263-L282) | `Scroll::pending` 在同一次 `consume` 内赋值又清零，永不累积；`Input::begin_frame` 又会清空 `wheel`，因此该字段是带误导性注释的死代码（另见 [issue 117](https://github.com/MAD-Producer/motion-studio/issues/117) 同源问题） |

### 五、每帧分配

`Input` 持有 4 个 `Vec` 与 1 个 `String`，[interaction.rs:117-118](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/interaction.rs#L117-L118) 的 `input_for` 经 `PanelFrame::input_for`（[panel.rs:40-43](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/panel.rs#L40-L43)）**每控件每帧深拷贝一次**（5 次堆分配）；`widgets.rs:454` 与 `widgets.rs:471` 另有整份克隆。200 个控件即约 1000 次分配／帧。

其余同类：[ui.rs:148](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/ui.rs#L148) 经 `atlas.ellipsize`（[text.rs:261-278](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/text.rs#L261-L278)，`to_owned()`）为每个标签分配 `String`；[style.rs:412-423](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/style.rs#L412-L423) 每标签新建 `PaintList` 并 `clip_to` 再分配两个 `Vec`；[icons.rs:177-189](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/icons.rs#L177-L189) 每图标 3 个分配；[paint.rs:113,120](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/paint.rs#L113-L120) `clip_triangles` **每三角形 5 个 `Vec`**；[paint.rs:556,584,630,638](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/paint.rs#L556-L638) 每帧两个顶点 `Vec` 与两个 bind group。

### 六、样式与布局不一致

- [tabs.rs:150-154](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/tabs.rs#L150-L154) 的 `draw` 没有 `&StyleSheet` 参数，溢出菜单图标硬编码 `default_stylesheet()`，绕过 `PanelHost::set_stylesheet`（[panel.rs:87](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/panel.rs#L87)）。热重载样式后标签 ⋮ 颜色不更新
- [dock.rs:514](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/dock.rs#L514) `(minimum / extent).clamp(0.05, 0.45)` 与 [workspace.rs:447](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/workspace.rs#L447) `(minimum / size.max(1.0)).min(0.45)` 是两套互相矛盾的最小尺寸策略（extent=4000px 时分别为 0.05 与 0.04）
- [dock.rs:66-69](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/dock.rs#L66-L69) `Node::split` 对已有 `Split` 也执行钳制，拖放到已分割区域会拽动用户已调好的分隔条
- [paint.rs:277-297](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/paint.rs#L277-L297) `expand_line` 无拐角连接、线宽硬编码半宽 0.5，且无 API 请求更粗的描边
- [paint.rs:196-208](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/paint.rs#L196-L208) `diamond` 的文档注释逐字复制自 `stroke`，且不校验颜色 alpha 与有限性（`rect`/`line` 均校验）
- [widgets.rs:76-94](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/widgets.rs#L76-L94) `TextEditor` 以标量计 `cursor`，退格删除一个标量会拆开组合序列（`e` + U+0301）或 emoji ZWJ 序列；[text.rs:195](https://github.com/Yukk1o/motion-studio/blob/1771a006104952d2ca7e47df004e729724239b89/desktop/ui/src/text.rs#L195) 亦不做标记定位，组合符与前一个字形重叠绘制

## 实施范围

- [x] `clip_to` 对 `Line` 改用与 `clip_triangles` 一致的多边形裁剪，保留背景折叠所需的钳制语义
- [ ] 图集耗尽改为提前扩张或实现淘汰策略；写入前校验图集边界
- [ ] `scrub_field` 的标签裁到 `end - x`，与 `widgets.rs` / `tabs.rs` 对齐
- [x] `checkerboard` 校验 `size`（有限、非零、下限）；`write_buffer` 前校验容量或分批提交
- [ ] `NumberEditor` 的拖拽结束按按键判定；`Button` 改用 `KeyChord::pressed`
- [ ] `Router` 的 `dedup` 改为全量去重，并在跨窗口时按焦点窗口排序
- [ ] `Input` 改为引用传递 + `Copy` 字段的轻量路由视图，消除每控件每帧深拷贝
- [ ] `ellipsize` / `text_style` / `icons::draw` / `clip_triangles` 的每帧分配复用缓冲区
- [ ] `tabs::draw` 接受 `&StyleSheet`；统一两处最小尺寸钳制；`Node::split` 仅在必要时钳制
- [ ] `expand_line` 增加拐角连接与可配置线宽；`diamond` 修正文档并补校验
- [ ] `TextEditor` 与字形布局改为按 grapheme cluster 操作并处理组合标记

## 验收标准

- [x] 完全位于裁剪区外的折线不再产生边缘幽灵线，背景折叠行为不变
- [ ] 填满图集后不出现一帧乱码
- [ ] 长属性名不再与数值重叠
- [x] `checkerboard` 遇 `size = 0` 返回错误或空结果，不冻结线程
- [ ] 每帧分配量不随控件数线性增长
- [ ] 组合字符与 emoji 的编辑、绘制与测量一致

## 依赖与来源

- 混合模式与 alpha 前提已核验一致（straight alpha + `SrcAlpha/OneMinusSrcAlpha`），本 issue 不涉及渲染语义

收益与排期须由基线对照确认；本 issue 是待实现/待验证任务，不表示这些改造已完成

### 2026-11-04 线段裁剪当前复核

主线 0790404f 已有描边多边形裁剪，本次没有重复修改生产代码。当前实现通过四侧 × 五种 DPI × 两种线宽 × 直线/带转角折线，共 80 组实际 GPU 全图透明检查；旧中心线钳制的 80 组负对照均可见。完整路径抗锯齿目标 9 通过、0 失败、0 忽略，原断言和预算不变。

新增回归与原始输出已推送 fix/ui-line-clipping，待后续合批 PR，不称测试已合入。这两条原复选项还包含“背景折叠行为不变”，本批未独立验收该部分，因此复合复选项暂不勾选，issue 保持开放。此前短暂勾选现已恢复，避免把部分验证算作完整验收。离屏 GPU 读回不是窗口或全应用性能验收。


### 2026-11-04 背景矩形范围已补验

已补齐上述复合条目的背景条件：五种矩形范围 × 五种 DPI × 不透明/半透明，共 50 组 GPU 全图结果与直接绘制交集矩形逐字节一致；包括没有原始顶点落在裁剪区内的大背景。新增原幽灵线等价案例后，区外直线/折线共 90 组、可见钳制负对照 90 组，完整路径抗锯齿目标 10/0/0。

因此勾选 Line 多边形裁剪与区外折线/背景行为两项，表示主线已有实现经本次复核通过；其余条目和整个 issue 继续开放。新增回归及原始结果已合批提交草稿 #605（基于 #604），测试尚未合入。该 PR 的当前正式 release 编译失败独立保留，不能将离屏 GPU 验收转述为窗口或完整工作区通过。


### 2026-11-04 棋盘格和容量复核

已有实现通过当前复核：六种无效尺寸产生空命令和透明 GPU 结果；正尺寸始终只提交一个图元，着色器提供一像素下限。四种极小尺寸 × 五种 DPI 的 GPU 全图与一像素参考相同，另有八张图与独立 CPU 棋盘格全图相同。已有容量回归实际复现 5,856,576 字节写入旧容量的错误，正常扩容、设备上限拒绝及下一帧恢复均通过。

标准 Cargo 路径目标 12/0/0；同源码完整 UI 库 91/0/0，六项容量测试包含其中，共 103 项不同测试。首次完整 UI 库因临时文件/目录操作失败为 87/4/0；同一 EXE 显式工作区 TEMP 后通过。默认目录 Python 探针成功，访问失败根因仍未证明，原失败完整保留。

因此勾选棋盘格/缓冲容量实施及零值不冻结验收两项，其余原清单保持不变，整个 issue 继续开放。新增测试与归档合批放入草稿 #605；测试未合入，正式 release 编译失败也未被这些组件测试抵消。详见该分支 engineering/validation/ui-checker-capacity-current.md。
