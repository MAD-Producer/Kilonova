"""Replay unchanged production tool; external truth is observer-only."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys,zipfile,collections,os
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88';ART=ROOT/'artifacts/pr-queue'
OUT=ART/'tracking88-plane-support-diagnostic-v1';OUT.mkdir(exist_ok=False)
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
sys.path.insert(0,str(WORK/'tools/tracking'))
import track_plate as tool
import plate_flow as flow
import cv2,numpy as np
cv2.setNumThreads(1);cv2.setRNGSeed(88)
source=ART/'tracking88-real-planar-acquisition-v1/phone.avi'
request=ART/'tracking88-photographed-prototype-v6/periodic-manual-200.request.json'
gt=ART/'tracking88-real-planar-acquisition-v1/phone-gt.zip'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source)=='c67202dc312ec945bed714c8c812ab6165ca526c1694a705a40eeb8a578b16b9'
assert sha(gt)=='d4e36ea6f58d11fcdaab2e604786401725059581c767c65b9923595f79567886'
with zipfile.ZipFile(gt) as z:
 corners=[]
 for i in range(200,2500):
  v=np.array([float(x) for x in z.read(f'img_{i:05d}.txt').decode('ascii').split()]).reshape(2,4)
  corners.append(np.column_stack((v[1]-1,v[0]-1)))
corners=np.array(corners);truth=[cv2.getPerspectiveTransform(corners[0].astype(np.float32),q.astype(np.float32)) for q in corners]
sources={name:sha(WORK/'tools/tracking'/name) for name in ['plate_flow.py','plate_contract.py','track_plate.py']}
report=dict(status='running',pid=os.getpid(),startedUtc=datetime.now(timezone.utc).isoformat(),sourceFiles=sources,sourceSha256=sha(source),truthSha256=sha(gt),rows=[])
def save():tool.atomic_json(OUT/'diagnostic.json',report)
current_index=0
original_frames=tool.frames
def observed_frames(*args):
 global current_index
 for i,data in enumerate(original_frames(*args)):
  current_index=i;yield data
tool.frames=observed_frames
original_tracker=flow.Tracker
class ObservedTracker(original_tracker):
 def observe(self,previous,current):
  result=super().observe(previous,current)
  if self.seed['kind']=='plane':
   row=dict(index=current_index,visible=result[0] is not None,reason=self.reason)
   if result[0] is not None:
    matrix=np.array(result[0]['matrix']);index=current_index
    probes=np.array([[160.,180.],[500.,180.],[500.,390.],[160.,390.]])
    row.update(confidence=float(result[1]),features=len(self.reference),
     roiMaxPixels=float(np.linalg.norm(flow.transform(matrix,probes)-flow.transform(truth[index],probes),axis=1).max()),
     cornerMaxPixels=float(np.linalg.norm(flow.transform(matrix,corners[0])-corners[index],axis=1).max()))
    errors=np.linalg.norm(flow.transform(truth[index],self.reference)-self.points,axis=1)
    bounds=np.ptp(self.reference,axis=0)
    row.update(featureOracleMedian=float(np.median(errors)),featureOracleMax=float(errors.max()),
     supportWidthFraction=float(bounds[0]/340.),supportHeightFraction=float(bounds[1]/210.),
     supportHullFraction=float(cv2.contourArea(cv2.convexHull(self.reference.astype(np.float32)))/(340.*210.)))
   report['rows'].append(row)
  return result
flow.Tracker=ObservedTracker
save()
try:
 ffmpeg=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin/ffmpeg.exe'
 tool.track(source,request,OUT/'tracker',ffmpeg,ffmpeg.with_name('ffprobe.exe'))
 assert all(sha(WORK/'tools/tracking'/n)==h for n,h in sources.items())
 rows=report['rows'];visible=[r for r in rows if r['visible']]
 report['summary']=dict(automaticFrames=len(rows),visible=len(visible),lost=sum(not r['visible'] for r in rows),
  maxCornerPixels=max(r['cornerMaxPixels'] for r in visible),
  over15=[r for r in visible if r['cornerMaxPixels']>15.],
  worst=sorted(visible,key=lambda r:r['cornerMaxPixels'],reverse=True)[:20],
  lossReasons=dict(collections.Counter(r['reason'] for r in rows if not r['visible'])))
 report['status']='diagnosed_full_sequence_without_modifying_tracker_or_thresholds'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
print(json.dumps({k:v for k,v in report['summary'].items() if k not in ['over15','worst']},indent=2))
