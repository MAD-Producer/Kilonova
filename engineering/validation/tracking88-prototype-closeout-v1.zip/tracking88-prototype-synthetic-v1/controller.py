"""Source-bound external prototype measurement, with no native completion claim."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,subprocess
ROOT=Path('E:/Dev/aem');WORK=ROOT/'.worktrees/tracking-import88'
OUT=ROOT/'artifacts/pr-queue/tracking88-prototype-synthetic-v1'
OUT.mkdir(exist_ok=False);(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=WORK,text=True).splitlines()
sources={n:hashlib.sha256((WORK/n).read_bytes()).hexdigest() for n in sorted(set(paths)) if (WORK/n).is_file() and (n.startswith('tools/') or n in ('ATTRIBUTION.md','PROVENANCE.md','NOTICE'))}
for name in ['tools/tracking/track_plate.py','tools/tracking/plate_contract.py','tools/tracking/plate_flow.py','tools/tracking/validate_prototype.py','tools/test_ci_plate_tracking.py']:
    p=OUT/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((WORK/name).read_bytes())
runtime=ROOT/'.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
command=[str(ROOT/'.tools/ai-depth74/venv/Scripts/python.exe'),'tools/tracking/validate_prototype.py','--ffmpeg',str(runtime/'ffmpeg.exe'),'--ffprobe',str(runtime/'ffprobe.exe'),'--output',str(OUT/'evaluation')]
report=dict(status='running',startedUtc=datetime.now(timezone.utc).isoformat(),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),controllerPid=os.getpid(),source=sources,command=command)
def save():(OUT/'exit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
save()
try:
    with (OUT/'stdout.log').open('wb') as stdout,(OUT/'stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=WORK,stdout=stdout,stderr=stderr);report['pid']=child.pid;save();report['exitCode']=child.wait()
    for name,digest in sources.items():assert hashlib.sha256((WORK/name).read_bytes()).hexdigest()==digest,name
    assert report['exitCode']==0,report['exitCode']
    report['status']='accepted_external_synthetic_prototype_native_pending'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
