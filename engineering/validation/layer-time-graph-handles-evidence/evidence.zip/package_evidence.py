import hashlib,json,pathlib,shutil,zipfile
root=pathlib.Path(__file__).parent
workspace=pathlib.Path('E:/Dev/aem/.worktrees/layer-time-mapping')
destination=workspace/'engineering/validation/layer-time-graph-handles-evidence'
destination.mkdir(parents=True,exist_ok=True)
results=json.loads((root/'test-results.json').read_text(encoding='utf-8'))
assert len(results)==13 and all(r['exit']==0 for r in results)
hashes=json.loads((root/'source-hashes.json').read_text(encoding='utf-8'))
for name,digest in hashes.items():assert hashlib.sha256((workspace/name).read_bytes()).hexdigest()==digest,name
allowed={'.json','.log','.png','.py','.patch','.rs'}
for previous in ['time-handles-dev','time-handles-final-validation']:
    source=root.parent/previous
    for p in source.rglob('*'):
        if p.is_file() and p.suffix.lower() in allowed:
            target=root/'earlier-attempts'/previous/p.relative_to(source)
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
for tag in ['zh-main-forward','en-floating-reverse']:
    shutil.copy2(root/'native'/tag/'values.png',destination/(tag+'-values.png'))
passed={(r['group'],test) for r in results for test in r['passed']}
passed_names={test for r in results for test in r['passed']}
ignored=sorted({test for r in results for test in r['ignored']} - passed_names)
binaries={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*tested.exe')}
manifest={'scope':'#257 mapped main graph handles; issue remains open','baseCommit':'0469d212da849c5978fba01ea9d751dbdf8310ae',
    'artifactRoot':str(root),'sourceHashes':hashes,'binaryHashes':binaries,'passedCount':len(passed),
    'corePassedCount':sum(len(r['passed']) for r in results if r['group'].startswith('core-')),
    'desktopPassedCount':sum(len(r['passed']) for r in results if not r['group'].startswith('core-')),
    'notRunIgnoredCount':len(ignored),'notRunIgnored':ignored,'results':results,
    'nativeCaptureProcess':json.loads((root/'native/capture-process.json').read_text()),
    'nativeReopenProcess':json.loads((root/'native/reopen-process.json').read_text()),
    'images':{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'native').rglob('*.png')},
    'checks':json.loads((root/'checks.json').read_text()),
    'limits':['Native windows use actual GPU and chrome Input, without physical OS mouse injection.',
        'Default panel counters are process-lifetime, not consecutive failure counters.',
        'Earlier attempts are retained diagnostic records and do not contribute to current passed counts.',
        'All counted tests ran on the frozen programs for these exact source hashes.',
        'No full cross-platform/DPI or all DESIGN acceptance claim.']}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
shutil.copy2(root/'manifest.json',destination/'manifest.json')
with zipfile.ZipFile(destination/'evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.suffix.lower() in allowed:archive.write(p,p.relative_to(root))
print(json.dumps({k:manifest[k] for k in ['passedCount','corePassedCount','desktopPassedCount','notRunIgnoredCount','binaryHashes','nativeCaptureProcess','nativeReopenProcess']},indent=2))
