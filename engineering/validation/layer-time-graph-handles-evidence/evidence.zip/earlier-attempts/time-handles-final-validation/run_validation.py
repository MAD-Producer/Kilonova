import hashlib, json, os, pathlib, re, subprocess, time
root=pathlib.Path(__file__).parent
workspace=pathlib.Path('E:/Dev/aem/.worktrees/layer-time-mapping')
env=os.environ.copy()
env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
env['MOTION_GRAPH_HANDLE_FAULT_ARTIFACT_DIR']=str(root/'fault')
env['MOTION_GRAPH_HANDLES_ARTIFACT_DIR']=str(root/'native')
hashes=json.loads((root/'source-hashes.json').read_text(encoding='utf-8'))
def unchanged():
    for name,digest in hashes.items():
        assert hashlib.sha256((workspace/name).read_bytes()).hexdigest()==digest,name
unchanged()
jobs=[('core-local','local-keyframes-tested.exe',[]),('core-clipboard','keyframe-clipboard-tested.exe',[])]
for name in ['key_selection','graph_handles','timeline_shortcuts_tests','property_followup_tests','animation_controls','effect_timeline','curve_comparison','animation_menu','keyframe_clipboard','graph_ranges']:
    jobs.append((name,'motion-studio-tested.exe',['panels::'+name+'::']))
jobs.append(('native','motion-studio-tested.exe',['--ignored','--exact','panels::key_selection::tests::ui::local_timing::handles::native::native_local_handles_edit_undo_save_pixels_and_reopen']))
results=[]
for label,exe,args in jobs:
    started=time.monotonic()
    with (root/(label+'-stdout.log')).open('wb') as stdout,(root/(label+'-stderr.log')).open('wb') as stderr:
        r=subprocess.run([str(root/exe),*args,'--nocapture','--test-threads=1'],env=env,stdout=stdout,stderr=stderr,timeout=600,cwd=workspace)
    text=(root/(label+'-stdout.log')).read_text(encoding='utf-8',errors='replace')
    passed=re.findall(r'^test (\S+) \.\.\. ok$',text,re.M)
    ignored=re.findall(r'^test (\S+) \.\.\. ignored[^\n]*$',text,re.M)
    result={'group':label,'exit':r.returncode,'elapsedSeconds':round(time.monotonic()-started,3),'passed':passed,'ignored':ignored}
    results.append(result)
    (root/'test-results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(label,'exit',r.returncode,'passed',len(passed),'ignored',len(ignored),'seconds',result['elapsedSeconds'],flush=True)
    if r.returncode:
        print(text[-4500:],flush=True)
        print((root/(label+'-stderr.log')).read_text(encoding='utf-8',errors='replace')[-5000:],flush=True)
        raise SystemExit(r.returncode)
unchanged()
print('all groups complete; unchanged sources',len(hashes),flush=True)
