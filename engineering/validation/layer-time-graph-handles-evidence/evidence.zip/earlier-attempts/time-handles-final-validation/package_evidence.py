import hashlib,json,pathlib,shutil,zipfile
root=pathlib.Path(__file__).parent
workspace=pathlib.Path('E:/Dev/aem/.worktrees/layer-time-mapping')
destination=workspace/'engineering/validation/layer-time-graph-handles-evidence'
destination.mkdir(parents=True,exist_ok=True)
attempts=json.loads((root/'test-results.json').read_text(encoding='utf-8'))
fix=root/'native-oracle-fix'
results=[r for r in attempts if r['group']!='native']+json.loads((fix/'test-results.json').read_text(encoding='utf-8'))
assert len(results)==14 and all(r['exit']==0 for r in results)
hashes=json.loads((fix/'source-hashes.json').read_text(encoding='utf-8'))
baseline=json.loads((root/'source-hashes.json').read_text(encoding='utf-8'))
assert [n for n in hashes if hashes[n]!=baseline[n]]==['desktop/app/src/panels/key_selection/local_handle_native_tests.rs']
for name,digest in hashes.items():assert hashlib.sha256((workspace/name).read_bytes()).hexdigest()==digest,name
development=root.parent/'time-handles-dev'
for p in development.rglob('*.log'):
    target=root/'development'/p.relative_to(development);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
for tag in ['zh-main-forward','en-floating-reverse']:
    shutil.copy2(fix/'native'/tag/'values.png',destination/(tag+'-values.png'))
passed={(r['group'] if r['group'].startswith('core-') else 'desktop',test) for r in results for test in r['passed']}
passed_names={test for r in results for test in r['passed']}
ignored=sorted({test for r in results for test in r['ignored']} - passed_names)
binaries={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in [*root.glob('*tested.exe'),*fix.glob('*tested.exe')]}
for r in results:
    r['binary']=('local-keyframes-tested.exe' if r['group']=='core-local' else 'keyframe-clipboard-tested.exe' if r['group']=='core-clipboard' else 'native-oracle-fix/motion-studio-tested.exe' if r['group'] in ['handles-recheck','native-fixed'] else 'motion-studio-tested.exe')
manifest={'scope':'#257 mapped main graph handles; issue remains open','baseCommit':'0469d212da849c5978fba01ea9d751dbdf8310ae',
    'artifactRoot':str(root),'sourceHashes':hashes,'binaryHashes':binaries,'passedCount':len(passed),
    'corePassedCount':sum(len(r['passed']) for r in results if r['group'].startswith('core-')),
    'desktopPassedCount':sum(1 for family,_ in passed if family=='desktop'),
    'regressionSourceHashes':baseline,'firstAttemptResults':attempts,'oracleFix':json.loads((fix/'delta.json').read_text()),
    'notRunIgnoredCount':len(ignored),'notRunIgnored':ignored,'results':results,
    'nativeCaptureProcess':json.loads((fix/'native/capture-process.json').read_text()),
    'nativeReopenProcess':json.loads((fix/'native/reopen-process.json').read_text()),
    'images':{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*.png')},
    'checks':json.loads((root/'checks.json').read_text()),
    'limits':['Native windows use actual GPU and chrome Input, without physical OS mouse injection.',
        'Default panel counters are process-lifetime, not consecutive failure counters.',
        'Initial development failures are diagnostic records, not final binary validation.',
        '346 regression tests ran on the regression binary; the only subsequent source change corrected a newly written native test oracle. Native acceptance and four handle tests ran on the corrected test binary. Production sources are byte-identical.',
        'No full cross-platform/DPI or all DESIGN acceptance claim.']}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
shutil.copy2(root/'manifest.json',destination/'manifest.json')
with zipfile.ZipFile(destination/'evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.suffix.lower() in {'.json','.log','.png','.py','.patch','.rs'}:
            archive.write(p,p.relative_to(root))
print(json.dumps({k:manifest[k] for k in ['passedCount','corePassedCount','desktopPassedCount','notRunIgnoredCount','binaryHashes','nativeCaptureProcess','nativeReopenProcess']},indent=2))
