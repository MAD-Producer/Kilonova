import hashlib
import json
import pathlib
import subprocess
import zipfile

out = pathlib.Path(__file__).parent
root = pathlib.Path.cwd()
def gh(*args):
    return json.loads(subprocess.check_output(['gh', *args], encoding='utf-8'))

pr = gh('pr', 'view', '620', '--repo', 'MAD-Producer/Kilonova', '--json',
        'number,state,headRefOid,mergeCommit,statusCheckRollup')
assert pr['state'] == 'MERGED'
assert pr['headRefOid'] == 'aa1aeb038dcfbe5f9527337360e4c3878ce4d986'
required = [c for c in pr['statusCheckRollup'] if c['name'] not in
            ['Desktop libav backend', 'Publish desktop release']]
assert len(required) == 8
assert all(c['status'] == 'COMPLETED' and c['conclusion'] == 'SUCCESS' for c in required)
job = json.loads((out / 'main-ffmpeg-job.json').read_text(encoding='utf-8'))
assert job['conclusion'] == 'success'
assert job['head_sha'] == '5935e637170455100731a74139cf827e800d0395'
log = (out / 'main-ffmpeg-job.log').read_text(encoding='utf-8')
test = 'sixty_clip_frozen_exports_release_shared_admissions_after_cancel_success_and_nested_reopen'
assert 'Running' in log and 'tests/video_retirement_export.rs' in log
assert 'test ' + test + ' ... ok' in log
tail = log.split('tests/video_retirement_export.rs')[-1]
assert '1 passed; 0 failed; 0 ignored' in tail
assert subprocess.run(['git','merge-base','--is-ancestor',pr['mergeCommit']['oid'],job['head_sha']],cwd=root).returncode == 0

names = ['crates/motion-render/tests/video_retirement_pressure.rs',
         'crates/motion-desktop-media/tests/video_retirement_export.rs']
sources = {}
for name in names:
    before = subprocess.check_output(['git','show',pr['headRefOid']+':'+name],cwd=root)
    after = subprocess.check_output(['git','show',job['head_sha']+':'+name],cwd=root)
    assert before == after
    sources[name] = hashlib.sha256(after).hexdigest()
archive = root / 'engineering/validation/video-resource-retirement-evidence.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == '70a7fb5186e814db8441b31725604dfa45685950905150620e161ce9bcf79502'
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
receipt = {
    'pr':pr, 'main_job':{'id':job['id'],'head':job['head_sha'],'conclusion':job['conclusion'],
                       'url':job['html_url'],'verified_test':test},
    'unchanged_new_test_sources':sources,
    'local_evidence_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'scope':[
        {'id':'V68-ENTRY','disposition':'Existing active-set retention audited across preview, nested capture, frozen movie, standalone inputs, project replacement and sampled hidden/clipped inputs.'},
        {'id':'V68-COUNTS','disposition':'YUV planes and RGBA outputs have distinct identities/capacities; shared allocation budget includes in-flight leases. External decoder surfaces have no implemented VideoPixels variant and are outside current inputs, tracked by #70; driver-resident VRAM is not measured.'},
        {'id':'V68-COLD','disposition':'No evidence supporting idle/LRU; retain existing active-set deletion, no invented leak or replacement strategy.'},
        {'id':'V68-PRESSURE','disposition':'60 native conversion instances; cache owners removed while GPU tokens retain allocations; exact refusal and ordered retirement verified with a real failure control.'},
        {'id':'V68-TRAVERSE','disposition':'Existing traversal/reverse seek, hidden matte, empty gap, replacement, standalone and retained-input recovery tests are covered in 47 distinct local tests and exact-head required CI.'},
        {'id':'V68-EXPORT','disposition':'Local and main native FFmpeg test actually ran direct/nested 60-frame exports, cancellation after progress, complete outputs, decoded pixel checks and zero allocation/encoder/category counts.'},
        {'id':'V68-CLOSE','disposition':'Close as completed audit/regression work, not as a newly fixed production leak. Whole main publication remains separate; ARM runner repair is #622.'}
    ]}
(out/'closure-audit.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'required_checks':len(required),'main_native_test':test,'eligible_to_close':True}))
