核验日期：2026-10-11

核验基线：[b385116](https://github.com/Yukk1o/motion-studio/commit/b385116faaf6ea5c2be0abc3b04b75b89d19631d)，为核验时的主分支；不把未提交 UI/节点工作树计作已合入功能

## 已核验现状

VideoGpu虽有inputs HashMap，但Renderer.retain_video_instances已同时删除失活RGBA和YUV平面：[renderer.rs:613](https://github.com/Yukk1o/motion-studio/blob/b385116faaf6ea5c2be0abc3b04b75b89d19631d/crates/motion-render/src/renderer.rs#L613-L641)；不能定性为“常驻无淘汰”泄漏。共享解码器也已有4帧lookahead与有界CPU缓存：[video_frames.rs:1](https://github.com/Yukk1o/motion-studio/blob/b385116faaf6ea5c2be0abc3b04b75b89d19631d/crates/motion-host/src/video_frames.rs#L1-L61)、[video_cache.rs:7](https://github.com/Yukk1o/motion-studio/blob/b385116faaf6ea5c2be0abc3b04b75b89d19631d/crates/motion-host/src/video_cache.rs#L7-L60)。

## 实施范围

- [x] 按实际入口核对预览、nested、export/capture、standalone输入、换工程与隐藏/裁剪视频是否及时调用回收
- [x] 为YUV平面、RGBA输出、外部surface引用分别统计峰值和释放，不重复缓存同源/同PTS（已实现的 YUV/RGBA 已验；当前无外部解码 surface 输入，互操作仍由 #70 单独验收）
- [x] 只有实测确认保留冷纹理有益时引入idle/LRU，并遵守全局预算；不替换已正确的active-set删除
- [x] 压力下先驱逐可再生的非活动资源，保留正在GPU消费的帧

## 验收标准

- [x] 依次遍历几十个视频clip、反复seek/删除/重开工程后容量回落
- [x] 多实例同源、nested、冻结导出与取消均不悬挂/丢帧
- [x] 无泄漏时记录已有覆盖并作为优化/测试问题关闭，不能虚构bug

## 依赖与来源

- 路线总览：https://github.com/Yukk1o/motion-studio/issues/59
- 前置任务：https://github.com/Yukk1o/motion-studio/issues/61
- 前置任务：https://github.com/Yukk1o/motion-studio/issues/60

收益与排期须由基线对照确认；本issue是待实现/待验证任务，不表示这些改造已完成


## 2026-11-06 回收验收补齐（#620）

已提交 [PR #620](https://github.com/MAD-Producer/Kilonova/pull/620)，由分支 `test/video-resource-retirement` 推进。新增真实 GPU 的 60 clip 在途压力、精确拒绝/分阶段回收负对照，以及直接/嵌套冻结电影取消、正常输出与共享预算归零。本地渲染 31、宿主 15、显式 FFmpeg 电影 1，共 47 个不同测试通过。没有发现需要替换活动集删除策略的证据，没有增加 idle/LRU。外部解码 surface 尚未接入，不能用当前 YUV/RGBA 控制冒称互操作验收。当前提交 CI 和合入后的原生门禁尚待完成，暂不关闭或勾选全部验收项。


## 2026-11-06 最终核验与关闭

[#620](https://github.com/MAD-Producer/Kilonova/pull/620) 已合并为 `72e8ef41bff397f8580bbd185861eb2860e56ff6`，最终 head `aa1aeb038dcfbe5f9527337360e4c3878ce4d986` 的八项必需测试/构建全部成功；PR 跳过的 libav 不计为原生验收。

随后主线 `5935e637170455100731a74139cf827e800d0395` 的 [FFmpeg 原生任务](https://github.com/MAD-Producer/Kilonova/actions/runs/42152024103/job/127688566129) 已实际通过。原始日志明确执行 `tests/video_retirement_export.rs` 中 `sixty_clip_frozen_exports_release_shared_admissions_after_cancel_success_and_nested_reopen`：1 passed、0 failed、0 ignored，13.67 秒。两份新增压力/电影测试源码与 PR 最终 head 逐字节相同。先前主线的 FrameRate 编译失败保留，已由 #606 修复，未把失败或取消算作通过。

结合已归档的 47 个不同本地测试及实际负对照，本项按已有回收实现的审计与回归补齐关闭；没有虚构泄漏，也没有增加未经测量的 idle/LRU。峰值与释放是应用账本/共享预算，不是驱动驻留显存。当前 `VideoPixels` 仅有 YUV 与 RGBA，未实现的外部解码 surface 互操作仍由 #70 跟踪，不能把这次验证当成该能力已交付。

主线完整发布仍受 ARM runner 配置阻断，由 #622 修复；本次关闭不宣称整条发布流水线已经通过。实现入口、在途保留、取消与像素检查的细节见[已合入验收文档](https://github.com/MAD-Producer/Kilonova/blob/5935e637170455100731a74139cf827e800d0395/engineering/validation/video-resource-retirement-current.md)。该文档当时的“主线门禁待验”已由上述原生任务补齐。
