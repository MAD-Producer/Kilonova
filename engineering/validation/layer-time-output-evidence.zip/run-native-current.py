import hashlib
import json
import os
import pathlib
import subprocess
import time

ROOT = pathlib.Path(__file__).resolve().parent
build = json.loads((ROOT / 'build-current.json').read_text(encoding='utf8'))
assert build['exit'] == 0 and build['sources_unchanged']
assert len(build['artifacts']) == 1
artifact = build['artifacts'][0]
executable = pathlib.Path(artifact['path'])
assert hashlib.sha256(executable.read_bytes()).hexdigest() == artifact['sha256']
env = os.environ.copy()
env.pop('MOTION_LOG', None)
env.update({
    'MOTION_LAYER_TIME_EDITOR_NATIVE_ARTIFACTS': str(ROOT / 'native-current'),
    'MOTION_LAYER_TIME_EDITOR_ERROR_ARTIFACTS': str(ROOT / 'errors-current'),
    'MOTION_MAPPED_PREFETCH_REPORT': str(ROOT / 'prefetch-pixels.json'),
})
listing = subprocess.run([str(executable), '--list'], capture_output=True,
                         text=True, check=True, env=env).stdout
(ROOT / 'current-test-list.txt').write_text(listing, encoding='utf8')
jobs = [
    ('editor-current', 'layer_time::', False),
    ('native-current', 'shell::layer_time::native_tests::layer_time_native_menus_drafts_transactions_owners_and_reopen', True),
    ('prefetch-current', 'engine::mapped_video_prefetch_tests::', False),
]
results = []
for name, selector, ignored in jobs:
    expected = [line.split(': test')[0] for line in listing.splitlines()
                if ': test' in line and selector in line]
    assert expected, selector
    command = [str(executable), selector, '--test-threads=1', '--nocapture']
    if ignored:
        command += ['--ignored', '--exact']
    print('start ' + name, flush=True)
    began = time.time()
    with (ROOT / (name + '.stdout')).open('w', encoding='utf8') as out, \
         (ROOT / (name + '.stderr')).open('w', encoding='utf8') as err:
        process = subprocess.run(command, stdout=out, stderr=err, env=env)
    result = {'name': name, 'command': command, 'expected_tests': expected,
              'exit': process.returncode, 'seconds': time.time() - began,
              'executable_sha256': artifact['sha256'],
              'executable_unchanged': hashlib.sha256(executable.read_bytes()).hexdigest() == artifact['sha256']}
    (ROOT / (name + '.json')).write_text(json.dumps(result, indent=2), encoding='utf8')
    results.append(result)
    (ROOT / 'native-results.json').write_text(json.dumps(results, indent=2), encoding='utf8')
    print(json.dumps(result), flush=True)
