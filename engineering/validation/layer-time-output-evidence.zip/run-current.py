import hashlib
import json
import os
import pathlib
import subprocess
import time

ROOT = pathlib.Path(__file__).resolve().parent
WORK = pathlib.Path('E:/Dev/aem/.worktrees/ci-rust-disk-space')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

tracked = subprocess.run(['git', 'ls-files', '*.rs', '*Cargo.toml', 'Cargo.lock'], cwd=WORK,
                         check=True, capture_output=True, text=True).stdout.splitlines()
sources = {name: digest(WORK / name) for name in tracked}
new_test = 'crates/motion-desktop-media/tests/layer_time_frozen_export.rs'
sources[new_test] = digest(WORK / new_test)
(ROOT / 'final-sources.json').write_text(json.dumps(sources, indent=2), encoding='utf8')

jobs = [
    ('frozen-export-final', ['cargo', 'test', '-p', 'motion-desktop-media', '--test',
        'layer_time_frozen_export', '--features', 'ffmpeg,gpu-tests', '--locked', '--',
        '--test-threads=1', '--nocapture'],
        {'MOTION_LAYER_TIME_EXPORT_ARTIFACTS': str(ROOT / 'frozen-export-final')}),
    ('frozen-audio-current', ['cargo', 'test', '-p', 'motion-desktop-media', '--test',
        'layer_time_audio', '--features', 'ffmpeg,gpu-tests', '--locked', '--',
        '--test-threads=1', '--nocapture'],
        {'MOTION_TIME_AUDIO_EVIDENCE': str(ROOT / 'frozen-audio-current')}),
    ('model-time-current', ['cargo', 'test', '-p', 'motion-model', '--locked',
        '--test', 'layer_time', '--test', 'layer_time_document', '--test', 'layer_time_video',
        '--test', 'layer_time_projection', '--test', 'layer_time_direction',
        '--test', 'layer_time_stationary', '--test', 'audio_plan_time_bounds',
        '--', '--test-threads=1'], {}),
    ('media-time-current', ['cargo', 'test', '-p', 'motion-media', '--locked',
        '--test', 'layer_time_audio', '--test', 'mapped_audio_quality',
        '--', '--test-threads=1'], {}),
    ('build-current', ['cargo', 'test', '-p', 'motion-desktop', '--bin', 'motion-studio',
        '--features', 'ffmpeg', '--locked', '--no-run', '--message-format=json'], {}),
]

results = []
for name, command, extra in jobs:
    started = time.time()
    print('start ' + name, flush=True)
    env = os.environ.copy()
    env.update(extra)
    with (ROOT / (name + '.stdout')).open('w', encoding='utf8') as out, \
         (ROOT / (name + '.stderr')).open('w', encoding='utf8') as err:
        process = subprocess.run(command, cwd=WORK, env=env, stdout=out, stderr=err)
    result = {'name': name, 'command': command, 'exit': process.returncode,
              'seconds': time.time() - started,
              'sources_unchanged': all(digest(WORK / path) == value for path, value in sources.items())}
    if name == 'build-current' and process.returncode == 0:
        artifacts = []
        for line in (ROOT / (name + '.stdout')).read_text(encoding='utf8').splitlines():
            try:
                message = json.loads(line)
            except ValueError:
                continue
            if message.get('reason') == 'compiler-artifact' and message.get('executable') \
                    and message['target']['name'] == 'motion-studio':
                executable = pathlib.Path(message['executable'])
                artifacts.append({'path': str(executable), 'sha256': digest(executable),
                                  'fresh': message['fresh'], 'profile': message['profile']})
        result['artifacts'] = artifacts
    (ROOT / (name + '.json')).write_text(json.dumps(result, indent=2), encoding='utf8')
    results.append(result)
    (ROOT / 'current-results.json').write_text(json.dumps(results, indent=2), encoding='utf8')
    print(json.dumps(result), flush=True)

print('all jobs terminal', flush=True)
