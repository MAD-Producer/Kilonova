from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,urllib.request

root=Path('E:/Dev/aem/artifacts/pr-queue/tracking88-real-planar-acquisition-v1')
root.mkdir(exist_ok=False)
(root/'controller.py').write_bytes(Path(__file__).read_bytes())
base='https://cmp.felk.cvut.cz/cmp/demos/Tracking/linTrack/data/'
items=[('permission.html','index.html',1<<20),('phone.avi','videos/phone_100fps.avi',128<<20),('phone-gt.zip','phone/phone_gt.zip',4<<20),('mouse-pad.avi','videos/mouse_pad_100fps.avi',128<<20),('mouse-pad-gt.zip','mouse_pad/mouse_pad_gt.zip',4<<20)]
report=dict(status='running',pid=os.getpid(),startedUtc=datetime.now(timezone.utc).isoformat(),scope='External local qualification data; custom public-use statement, no redistribution',files=[])
def save():(root/'acquisition.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
save()
try:
    for name,relative,budget in items:
        url=base+relative;row=dict(name=name,url=url,status='reading',budget=budget);report['files'].append(row);save()
        print('start acquisition '+name,flush=True)
        digest=hashlib.sha256();count=0
        with urllib.request.urlopen(url,timeout=45) as response,(root/(name+'.pending')).open('xb') as output:
            while block:=response.read(1<<16):
                count+=len(block)
                if count>budget:raise ValueError('source exceeds recorded acquisition budget: '+name)
                output.write(block);digest.update(block)
        (root/(name+'.pending')).replace(root/name)
        row.update(status='acquired',bytes=count,sha256=digest.hexdigest());save()
    report['status']='acquired_not_yet_qualified'
except BaseException as cause:report.update(status='failed',failure=repr(cause));raise
finally:report['completedUtc']=datetime.now(timezone.utc).isoformat();save()
