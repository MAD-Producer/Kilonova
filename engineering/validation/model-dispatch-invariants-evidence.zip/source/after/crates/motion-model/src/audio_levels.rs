//! Stereo level envelopes in decibels; key times remain layer-local frames.
use crate::{ensure, Easing, Layer, Result, Track};
use serde::{Deserialize, Serialize};

pub const MIN_AUDIO_DB: f32 = -192.;
pub const MAX_AUDIO_DB: f32 = 24.;

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AudioLevels {
    pub left: Track<f32>,
    pub right: Track<f32>,
    /// Stereo balance, independent of the animated channel levels. Center is
    /// unity; moving right attenuates only the left channel and vice versa.
    #[serde(default)]
    pub balance: f32,
}
impl Default for AudioLevels {
    fn default() -> Self {
        Self {
            left: Track::constant(0.),
            right: Track::constant(0.),
            balance: 0.,
        }
    }
}
impl AudioLevels {
    pub fn validate(&self) -> Result<()> {
        ensure((-1. ..=1.).contains(&self.balance), "audio balance must be -1..1")?;
        for track in [&self.left, &self.right] {
            track.validate_local()?;
            ensure(
                track.axes.is_none() && track.keys.iter().all(|k| k.spatial.is_none()),
                "audio levels are scalar temporal tracks",
            )?;
            ensure(
                std::iter::once(track.value)
                    .chain(track.keys.iter().map(|k| k.value))
                    .all(|v| (MIN_AUDIO_DB..=MAX_AUDIO_DB).contains(&v)),
                "audio levels must be -192..24 dB",
            )?;
        }
        Ok(())
    }
    pub fn sample(&self, local_frame: f64) -> Result<[f32; 2]> {
        Ok([self.left.sample(local_frame)?.clamp(MIN_AUDIO_DB, MAX_AUDIO_DB),
            self.right.sample(local_frame)?.clamp(MIN_AUDIO_DB, MAX_AUDIO_DB)])
    }
    pub fn animated(&self) -> bool {
        !self.left.keys.is_empty() || !self.right.keys.is_empty()
    }
    pub fn balance_gain(&self) -> [f32; 2] {
        [1. - self.balance.max(0.), 1. + self.balance.min(0.)]
    }
}
pub fn db_gain(db: f32) -> f32 {
    10f32.powf(db / 20.)
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AudioChannel {
    Left,
    Right,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
pub enum AudioLevelsAction {
    Balance { value: f32 },
    Set {
        channel: AudioChannel,
        frame: u32,
        value: f32,
        #[serde(default)]
        animated: Option<bool>,
    },
    Animate {
        channel: AudioChannel,
        frame: u32,
        enabled: bool,
    },
    DeleteKey {
        channel: AudioChannel,
        frame: u32,
    },
    MoveKey {
        channel: AudioChannel,
        from: u32,
        to: u32,
    },
    CopyKey {
        channel: AudioChannel,
        from: u32,
        to: u32,
    },
    Curve {
        channel: AudioChannel,
        frame: u32,
        easing: Easing,
    },
    Clear,
}
pub fn edit(layer: &mut Layer, frames: u32, action: AudioLevelsAction) -> Result<()> {
    if layer.locked {
        return Err(crate::Error::Locked(layer.id));
    }
    ensure(
        matches!(
            layer.content,
            crate::Content::Audio { .. }
                | crate::Content::Video { .. }
                | crate::Content::Composition { .. }
        ),
        "audio levels require an audio, video or composition layer",
    )?;
    let local = |frame: u32| {
        ensure(frame < frames, "audio key outside composition")?;
        layer.edit_frame(frame)
    };
    if matches!(action, AudioLevelsAction::Clear) {
        layer.audio_levels = None;
        return Ok(());
    }
    if let AudioLevelsAction::Balance { value } = action {
        let mut levels = layer.audio_levels.clone().unwrap_or_default();
        levels.balance = value;
        levels.validate()?;
        layer.audio_levels = Some(levels);
        return Ok(());
    }
    let channel = match &action {
        AudioLevelsAction::Set { channel, .. }
        | AudioLevelsAction::Animate { channel, .. }
        | AudioLevelsAction::DeleteKey { channel, .. }
        | AudioLevelsAction::MoveKey { channel, .. }
        | AudioLevelsAction::CopyKey { channel, .. }
        | AudioLevelsAction::Curve { channel, .. } => *channel,
        AudioLevelsAction::Clear | AudioLevelsAction::Balance { .. } => {
            return Err(crate::Error::Invalid("audio channel dispatch requires a key action".into()));
        }
    };
    let mut levels = layer.audio_levels.clone().unwrap_or_default();
    let track = match channel {
        AudioChannel::Left => &mut levels.left,
        AudioChannel::Right => &mut levels.right,
    };
    match action {
        AudioLevelsAction::Set {
            frame,
            value,
            animated,
            ..
        } => {
            ensure(
                (MIN_AUDIO_DB..=MAX_AUDIO_DB).contains(&value),
                "audio levels must be -192..24 dB",
            )?;
            if let Some(enabled) = animated {
                track.set_animated(local(frame)?, enabled)?;
            }
            track.set_at(local(frame)?, value)?;
        }
        AudioLevelsAction::Animate { frame, enabled, .. } => {
            track.set_animated(local(frame)?, enabled)?
        }
        AudioLevelsAction::DeleteKey { frame, .. } => track.delete_key(local(frame)?)?,
        AudioLevelsAction::MoveKey { from, to, .. } => track.move_key(local(from)?, local(to)?)?,
        AudioLevelsAction::CopyKey { from, to, .. } => track.copy_key(local(from)?, local(to)?)?,
        AudioLevelsAction::Curve { frame, easing, .. } => track.set_curve(local(frame)?, easing)?,
        AudioLevelsAction::Clear | AudioLevelsAction::Balance { .. } => {
            return Err(crate::Error::Invalid("audio track dispatch requires a key action".into()));
        }
    }
    levels.validate()?;
    layer.audio_levels = Some(levels);
    Ok(())
}
