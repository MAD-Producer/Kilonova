"""Use the Windows curl transport when gh's Go TLS transport times out.

Credentials travel only through curl stdin, never argv, output, or a file.
"""
import argparse,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('route');p.add_argument('output');p.add_argument('--method',default='GET')
p.add_argument('--input')
a=p.parse_args()
assert a.route.startswith('repos/MAD-Producer/Kilonova/')
auth=subprocess.run(['gh','auth','token'],capture_output=True,text=True,timeout=10)
if auth.returncode:
    raise SystemExit('Cannot obtain existing GitHub credentials')
token=auth.stdout.strip()
assert token and '\n' not in token and '\r' not in token
config='header = '+json.dumps('Authorization: Bearer '+token)+'\n'
cmd=['curl.exe','--silent','--show-error','--fail-with-body','--connect-timeout','8','--max-time','40',
     '--config','-','--header','Accept: application/vnd.github+json',
     '--header','X-GitHub-Api-Version: 2022-11-28','--request',a.method,
     '--url','https://api.github.com/'+a.route]
if a.input: cmd+=['--header','Content-Type: application/json','--data-binary','@'+str(Path(a.input).resolve())]
r=subprocess.run(cmd,input=config.encode(),capture_output=True,timeout=45)
if r.returncode:
    sys.stderr.write('GitHub request failed: '+a.method+' '+a.route+'\n'+r.stderr.decode(errors='replace')+'\n'+r.stdout.decode(errors='replace')[:2000])
    raise SystemExit(r.returncode)
value=json.loads(r.stdout)
Path(a.output).write_bytes(r.stdout)
print(json.dumps({'method':a.method,'route':a.route,'saved':a.output,'type':type(value).__name__}))
