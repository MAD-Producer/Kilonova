import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

out = Path(__file__).parent
root = Path.cwd()
meta = json.loads((out / 'model-unit-compile.json').read_text(encoding='utf-8'))
assert meta['exit_code'] == 0 and meta['source_before'] == meta['source_after']
frozen = meta['source_after']
for name, digest in frozen.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
programs = []
for line in (out / 'model-unit-compile.stdout').read_text(encoding='utf-8').splitlines():
    record = json.loads(line)
    if record.get('reason') == 'compiler-artifact' and record.get('executable'):
        programs.append(record['executable'])
assert len(programs) == 1
program = Path(programs[0])
(out / 'verified-executable.json').write_bytes(json.dumps({
    'path': str(program), 'sha256': hashlib.file_digest(program.open('rb'), 'sha256').hexdigest(),
    'source': frozen}, indent=2).encode('utf-8'))

def run(phase, command):
    result = subprocess.run([sys.executable, str(out / 'run.py'), phase, *command])
    if result.returncode:
        raise SystemExit(result.returncode)
    actual = json.loads((out / (phase + '.json')).read_text(encoding='utf-8'))
    assert actual['source_before'] == actual['source_after'] == frozen, phase
    return (out / (phase + '.stdout')).read_text(encoding='utf-8')

for phase, selection in [('vector-invariants', 'vector::dispatch_tests::'),
                         ('clipboard-invariants', 'keyframe_clipboard::transfer_time::invariant_tests::')]:
    text = run(phase, [str(program), selection, '--nocapture', '--test-threads=1'])
    assert '2 passed; 0 failed; 0 ignored' in text

# The public command schema cannot create this temporary wrapper violation.
# This control injects only the private invariant and retains the exact new tests.
path = root / 'crates/motion-model/src/vector.rs'
current = path.read_bytes()
old = subprocess.check_output(['git', 'show', 'f101c5e3:crates/motion-model/src/vector.rs'])
marker = b'mod authored;\n'
assert old.count(marker) == 1
old = old.replace(marker, marker + b'#[cfg(test)]\n#[path = "vector/dispatch_tests.rs"]\nmod dispatch_tests;\n')
negative = out / 'negative'
negative.mkdir(exist_ok=True)
(negative / 'current-vector.rs').write_bytes(current)
(negative / 'baseline-with-new-tests.rs').write_bytes(old)
try:
    path.write_bytes(old)
    result = subprocess.run([sys.executable, str(out / 'run.py'), 'old-wrapper-negative',
        'cargo', 'test', '--locked', '-p', 'motion-model', '--lib',
        'vector::dispatch_tests::invalid_flat_wrapper_returns_native_error_without_publishing_partial_contents',
        '--', '--exact', '--nocapture', '--test-threads=1'])
    assert result.returncode == 101
    stdout = (out / 'old-wrapper-negative.stdout').read_text(encoding='utf-8')
    stderr = (out / 'old-wrapper-negative.stderr').read_text(encoding='utf-8')
    assert 'test result: FAILED. 0 passed; 1 failed;' in stdout
    assert 'a broken private wrapper must return an error' in stderr
    assert 'error[E' not in stderr
finally:
    path.write_bytes(current)
    restored = hashlib.sha256(path.read_bytes()).hexdigest()
    assert restored == frozen['crates/motion-model/src/vector.rs']
    (out / 'negative-restoration.json').write_bytes(json.dumps({
        'restored_sha256': restored, 'baseline_sha256': hashlib.sha256(old).hexdigest(),
        'tests_unchanged': True, 'scope': 'private temporary-wrapper invariant injection, not a public crash reproduction'}, indent=2).encode('utf-8'))

# Reuse the existing full model/core target instead of allocating another copy
# of its 142 test executables. Ownership was checked before this run.
os.environ['CARGO_TARGET_DIR'] = 'E:/Dev/aem/.tools/video-resource-retirement-target'
text = run('model-core-full', ['cargo', 'test', '--locked', '-p', 'motion-model', '-p', 'motion-core',
    '--', '--test-threads=1', '--nocapture'])
counts = [tuple(map(int, item)) for item in re.findall(
    r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)]
assert sum(c[0] for c in counts) >= 898 and all(c[1] == 0 for c in counts)
os.environ['CARGO_TARGET_DIR'] = 'E:/Dev/aem/.tools/viewer-inspection/native-target'
run('host-full', ['cargo', 'test', '--locked', '-p', 'motion-host', '--', '--test-threads=1', '--nocapture'])
run('all-targets', ['cargo', 'check', '--locked', '-p', 'motion-desktop', '-p', 'motion-host',
    '--all-targets', '--features', 'motion-desktop/ffmpeg,motion-host/diagnostics,motion-host/ai-depth'])
