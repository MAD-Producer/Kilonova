import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

out = Path(__file__).parent
root = Path.cwd()
phases = ['model-unit-compile', 'vector-invariants', 'clipboard-invariants',
          'model-core-full', 'host-full', 'all-targets', 'model-invariants-wrapper']
frozen = json.loads((out / 'model-unit-compile.json').read_text(encoding='utf-8'))['source_after']
for name, digest in frozen.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
summary = {}
for phase in phases:
    data = json.loads((out / (phase + '.json')).read_text(encoding='utf-8'))
    assert data['exit_code'] == 0 and data['source_before'] == data['source_after'] == frozen, phase
    text = (out / (phase + '.stdout')).read_text(encoding='utf-8')
    counts = [tuple(map(int, c)) for c in re.findall(
        r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)]
    assert all(c[1] == 0 for c in counts), phase
    summary[phase] = {'exit_code': 0, 'elapsed_seconds': data['elapsed_seconds'],
        'passed': sum(c[0] for c in counts), 'ignored': sum(c[2] for c in counts),
        'targets': len(counts), 'source_stable': True}
assert summary['vector-invariants']['passed'] == summary['clipboard-invariants']['passed'] == 2
assert summary['model-core-full']['passed'] >= 898 and summary['model-core-full']['ignored'] == 1
assert summary['host-full']['passed'] >= 286 and summary['host-full']['ignored'] == 0
full = (out / 'model-core-full.stdout').read_text(encoding='utf-8')
for name in [
    'invalid_flat_wrapper_returns_native_error_without_publishing_partial_contents',
    'healthy_flat_wrapper_preserves_authored_vector_and_edit_errors',
    'reverse_transfer_keeps_empty_and_single_key_terminal_metadata',
    'reverse_transfer_uses_preceding_segment_policy_and_preserves_rejection']:
    assert re.search(r'test [^\n]*' + re.escape(name) + r' \.\.\. ok', full), name
negative = json.loads((out / 'old-wrapper-negative.json').read_text(encoding='utf-8'))
assert negative['exit_code'] == 101
assert negative['source_before'] == negative['source_after']
delta = {name for name, digest in frozen.items() if negative['source_before'][name] != digest}
assert delta == {'crates/motion-model/src/vector.rs'}, delta
assert json.loads((out / 'negative-restoration.json').read_text(encoding='utf-8'))['restored_sha256'] == frozen['crates/motion-model/src/vector.rs']
initial = json.loads((out / 'initial/model-core-full.json').read_text(encoding='utf-8'))
assert initial.get('exit_code') != 0, 'interrupted compile must never be counted as a pass'

# Capture the final full-regression executables after their serial run, before
# any subsequent build reuses this target. They are not copied into the archive.
executables = {}
stderr = (out / 'model-core-full.stderr').read_text(encoding='utf-8')
for name in re.findall(r'\(([^\r\n]*?\.exe)\)', stderr):
    path = Path(name)
    assert path.is_file(), name
    executables[str(path)] = hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
assert len(executables) > 100
verification = {'phases': summary, 'source_files': len(frozen),
    'negative_changed_only_vector_source': True, 'negative_exit_code': 101,
    'initial_compile_intentionally_interrupted': True,
    'final_model_core_executable_sha256': executables,
    'scope': 'Four selected unit tests, complete model/core and host runs, desktop/host all-targets. Not complete final desktop runtime acceptance.'}
(out / 'verification-summary.json').write_bytes(json.dumps(verification, indent=2).encode('utf-8'))
payload = {}
for path in sorted(out.rglob('*')):
    if path.is_file() and path.suffix != '.zip' and path.name != 'package-receipt.json':
        payload['commands/' + path.relative_to(out).as_posix()] = path.read_bytes()
names = subprocess.check_output(['git', 'diff', '--name-only', '--', 'crates'], encoding='utf-8').splitlines()
names += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', 'crates'], encoding='utf-8').splitlines()
assert len(set(names)) == 10
for name in sorted(set(names)):
    data = (root / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == frozen[name], name
    payload['source/after/' + name] = data
    before = subprocess.run(['git', 'show', 'f101c5e3:' + name], capture_output=True)
    if before.returncode == 0:
        payload['source/before/' + name] = before.stdout
parent = out.parent / 'desktop-error-transport'
for name in ['exact-head-green-before-merge.json', 'merge-request.json', 'merge-response.json', 'merged-state.json']:
    payload['parent-merge/' + name] = (parent / name).read_bytes()
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(payload.items())}
payload['manifest.json'] = json.dumps(manifest, indent=2).encode('utf-8')
archive = root / 'engineering/validation/model-dispatch-invariants-evidence.zip'
assert not archive.exists(), 'do not overwrite a published archive'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as target:
    for name, data in sorted(payload.items()):
        target.writestr(name, data)
with zipfile.ZipFile(archive) as target:
    assert target.testzip() is None and set(target.namelist()) == set(payload)
    for name, data in payload.items():
        assert target.read(name) == data, name
receipt = {'members': len(payload), 'bytes': archive.stat().st_size,
    'sha256': hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest(),
    'model_core': summary['model-core-full'], 'host': summary['host-full'], 'source_files': len(frozen)}
(out / 'package-receipt.json').write_bytes(json.dumps(receipt, indent=2).encode('utf-8'))
print(json.dumps(receipt))
