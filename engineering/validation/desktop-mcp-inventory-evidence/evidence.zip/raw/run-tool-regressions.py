import json, os, subprocess, sys
from pathlib import Path

raw = Path(__file__).parent
root = Path.cwd()
(raw / 'initial-unit-import-failure.json').write_text(json.dumps(dict(
    command=['python','-m','unittest','tools.test_ci_desktop_release','tools.test_ci_tools'],
    exit=1, executed_product_tests=0, loader_errors=["ModuleNotFoundError: No module named 'yaml'", "ModuleNotFoundError: No module named 'validation_inventory'"],
    disposition='Invocation/environment error; use existing repository tools PYTHONPATH and already-installed pinned PyYAML 6.0.3. No source or assertion change.'), indent=2), 'utf-8')
env = os.environ.copy()
env['PYTHONPATH'] = str(root / 'tools') + os.pathsep + 'E:/Dev/aem/.tools/build-validation-python'
folder = raw / 'unit-temp'
folder.mkdir(exist_ok=True)
env['TEMP'] = env['TMP'] = str(folder)
command = [sys.executable, '-m', 'unittest', 'test_ci_desktop_release', 'test_ci_tools']
result = subprocess.run(command, cwd=root, env=env, capture_output=True)
(raw / 'unit.stdout').write_bytes(result.stdout)
(raw / 'unit.stderr').write_bytes(result.stderr)
(raw / 'unit-receipt.json').write_text(json.dumps(dict(command=command, exit=result.returncode,
    pythonpath=env['PYTHONPATH'], temp=str(folder)), indent=2), 'utf-8')
print(result.stdout.decode('utf-8', errors='replace')[-1200:], flush=True)
print(result.stderr.decode('utf-8', errors='replace')[-1600:], flush=True)
assert result.returncode == 0
