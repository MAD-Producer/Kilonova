import hashlib, importlib.util, json, os, subprocess, sys, traceback
from pathlib import Path

raw = Path(__file__).parent
root = Path.cwd()
stage = sys.argv[1]
binary = Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/motion-studio.exe')
assert hashlib.sha256(binary.read_bytes()).hexdigest() == '98a80dc955a38cf08e5dc343d2c56e626c47f4b47e9f59ec6ca77076e7890594'
os.environ.pop('RUST_MIN_STACK', None)
os.environ['MOTION_LOG'] = 'info'
os.environ['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + os.environ['PATH']
local = raw / stage
local.mkdir(exist_ok=True)
for name in ['TEMP', 'TMP', 'LOCALAPPDATA']:
    folder = local / name
    folder.mkdir(exist_ok=True)
    os.environ[name] = str(folder)
import tempfile
tempfile.tempdir = None
source = root / 'tools/ci_desktop.py'
spec = importlib.util.spec_from_file_location('native_ci_verifier', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
mutations = []
if stage in ['missing', 'extra']:
    original_queue = module.queue.Queue
    class InventoryMutationQueue(original_queue):
        def get(self, *args, **kwargs):
            line = super().get(*args, **kwargs)
            if line is not None:
                message = json.loads(line)
                result = message.get('result')
                if isinstance(result, dict) and isinstance(result.get('tools'), list):
                    original = [tool['name'] for tool in result['tools']]
                    assert 'import_tracking' in original and len(original) == 11
                    if stage == 'missing':
                        result['tools'] = [tool for tool in result['tools'] if tool['name'] != 'motion_seek']
                    else:
                        result['tools'].append(dict(name='not_a_published_tool'))
                    mutations.append(dict(original=original, mutated=[tool['name'] for tool in result['tools']]))
                    line = json.dumps(message) + '\n'
            return line
    module.queue.Queue = InventoryMutationQueue
outcome = dict(stage=stage, source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
    binary_source='ae83440117bd49f35ab4667fb04854ea683cd4e8 (node increment over main 0790404f; MCP/engine/tracking source identical to main)',
    default_log='info', rust_min_stack_overridden=False)
try:
    module.verify_mcp(binary, local)
except Exception as error:
    outcome.update(success=False, error_type=type(error).__name__, error=str(error))
    (local / 'verifier-error.txt').write_text(traceback.format_exc(), 'utf-8')
else:
    outcome.update(success=True)
outcome['inventory_reply_mutations'] = mutations
(local / 'receipt.json').write_text(json.dumps(outcome, indent=2), 'utf-8')
print(json.dumps(outcome), flush=True)
if stage == 'before':
    assert not outcome['success'] and outcome.get('error') == "MCP catalogue differs: missing=[], unexpected=['import_tracking']", 'not the intended inventory negative control'
elif stage == 'missing':
    assert len(mutations) == 1 and not outcome['success']
    assert outcome['error'] == "MCP catalogue differs: missing=['motion_seek'], unexpected=[]"
elif stage == 'extra':
    assert len(mutations) == 1 and not outcome['success']
    assert outcome['error'] == "MCP catalogue differs: missing=[], unexpected=['not_a_published_tool']"
else:
    assert outcome['success']
