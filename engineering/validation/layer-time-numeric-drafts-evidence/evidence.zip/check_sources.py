import json,pathlib,subprocess
root=pathlib.Path(__file__).parent
jobs=[('format',['rustfmt','--check','--edition','2021','--config','skip_children=true',
    'desktop/app/src/panels/property_authoring.rs',
    'desktop/app/src/panels/effect_controls/mapped_authoring_tests/numeric_time.rs',
    'desktop/app/src/panels/effect_controls/mapped_authoring_tests/numeric_time/faults.rs',
    'desktop/app/src/panels/numeric/contract_tests/mapped_time.rs']),
    ('styles',['python','-c',"import sys;sys.path.insert(0,'tools');import ci_desktop;ci_desktop.verify_style_consumers()"]),
    ('diff',['git','diff','--check'])]
results=[]
for name,args in jobs:
    r=subprocess.run(args,capture_output=True,text=True,encoding='utf-8')
    results.append({'name':name,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    print(name,r.returncode)
(root/'checks.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
assert all(r['exit']==0 for r in results)
