import hashlib,json,os,pathlib,re,subprocess,time
root=pathlib.Path(__file__).parent
workspace=pathlib.Path('E:/Dev/aem/.worktrees/layer-time-mapping')
env=os.environ.copy()
env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
env['MOTION_NUMERIC_TIME_FAULT_ARTIFACTS']=str(root/'faults')
env['MOTION_NUMERIC_TIME_NATIVE_ARTIFACTS']=str(root/'native')
sources=json.loads((root/'source-hashes.json').read_text(encoding='utf-8'))
def unchanged():
    for name,digest in sources.items():
        assert hashlib.sha256((workspace/name).read_bytes()).hexdigest()==digest,name
unchanged()
exe=root/'motion-studio-tested.exe'
(root/'binary.json').write_text(json.dumps({'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()},indent=2),encoding='utf-8')
jobs=[('effects',['panels::effect_controls::']),('properties',['panels::properties::']),
    ('numeric',['panels::numeric::']),('translated',['--exact','panels::tests::translated_numeric_edit_preserves_the_same_command_and_axis']),
    ('native',['--ignored','--exact','panels::numeric::contract_tests::mapped_time::native_mapped_numeric_cancel_and_new_draft_render_in_both_owners_and_languages'])]
results=[]
for label,args in jobs:
    started=time.monotonic()
    with (root/(label+'-stdout.log')).open('wb') as stdout,(root/(label+'-stderr.log')).open('wb') as stderr:
        p=subprocess.run([str(exe),*args,'--nocapture','--test-threads=1'],cwd=workspace,env=env,stdout=stdout,stderr=stderr,timeout=600)
    output=(root/(label+'-stdout.log')).read_text(encoding='utf-8',errors='replace')
    passed=re.findall(r'^test (\S+) \.\.\. ok$',output,re.M)
    ignored=re.findall(r'^test (\S+) \.\.\. ignored[^\n]*$',output,re.M)
    results.append({'group':label,'exit':p.returncode,'elapsedSeconds':round(time.monotonic()-started,3),'passed':passed,'ignored':ignored})
    (root/'test-results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(label,p.returncode,'passed',len(passed),'ignored',len(ignored),flush=True)
    if p.returncode or not passed:
        print(output[-5000:],flush=True)
        print((root/(label+'-stderr.log')).read_text(encoding='utf-8',errors='replace')[-5000:],flush=True)
        raise SystemExit(p.returncode or 1)
unchanged()
print('unchanged sources',len(sources),'distinct passes',len(set(n for r in results for n in r['passed'])),flush=True)
