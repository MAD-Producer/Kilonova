import hashlib,json,pathlib,shutil,zipfile
root=pathlib.Path(__file__).parent
workspace=pathlib.Path('E:/Dev/aem/.worktrees/layer-time-mapping')
dest=workspace/'engineering/validation/layer-time-numeric-drafts-evidence'
dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((root/'source-hashes.json').read_text(encoding='utf-8'))
for name,digest in sources.items():
    assert sha(workspace/name)==digest,name
results=json.loads((root/'test-results.json').read_text(encoding='utf-8'))
assert len(results)==5 and all(r['exit']==0 for r in results)
passed=set(n for r in results for n in r['passed'])
ignored=set(n for r in results for n in r['ignored'])-passed
assert len(passed)==79 and len(ignored)==2
assert len(list((root/'native').glob('*.png')))==24
bundle=dest/'evidence.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in root.rglob('*'):
        if not path.is_file() or path.suffix.lower()=='.exe': continue
        z.write(path,path.relative_to(root).as_posix())
    for name in sources:
        z.write(workspace/name,'source/'+name)
for source,name in [('Effect-main-Zh-committed.png','effect-main-zh.png'),
                    ('Transform-floating-En-committed.png','transform-floating-en.png')]:
    shutil.copyfile(root/'native'/source,dest/name)
manifest={'issue':257,'stage':'numeric draft time ownership','base':'15349f15cb2aa32d709f758ca2ca6dda1254d427',
    'branch':'feat/layer-time-mapping','binary':json.loads((root/'binary.json').read_text()),
    'sourceHashes':sources,'distinctPassed':len(passed),'unrunManual':sorted(ignored),
    'testResults':results,'nativeCases':8,'nativeScreenshots':24,
    'visualLimit':'Floating transform text clipping remains pending; no layout acceptance claimed.',
    'bundle':{'path':bundle.name,'sha256':sha(bundle),'bytes':bundle.stat().st_size},
    'screenshots':{p.name:sha(p) for p in dest.glob('*.png')}}
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('packaged',len(passed),'passes',len(ignored),'unrun manual tests',bundle.stat().st_size,'bytes')
