import json,pathlib,subprocess
root=pathlib.Path(__file__).parent
jobs=[('format',['rustfmt','--check','--edition','2021','--config','skip_children=true',
'desktop/app/src/engine/effect_pick.rs','desktop/app/src/engine/effect_pick/tests.rs','desktop/app/src/engine/effect_pick/tests/native.rs']),
('styles',['python','-c',"import sys;sys.path.insert(0,'tools');import ci_desktop;ci_desktop.verify_style_consumers()"]),
('diff',['git','diff','--check'])]
results=[]
for name,args in jobs:
    p=subprocess.run(args,capture_output=True,text=True,encoding='utf-8')
    results.append({'name':name,'args':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});print(name,p.returncode)
(root/'checks.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
assert all(p['exit']==0 for p in results)
