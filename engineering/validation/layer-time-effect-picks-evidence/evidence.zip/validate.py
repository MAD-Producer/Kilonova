import hashlib,json,os,pathlib,re,shutil,subprocess,sys,time
root=pathlib.Path(__file__).parent
workspace=pathlib.Path('E:/Dev/aem/.worktrees/layer-time-mapping')
sources=['desktop/app/src/engine/effect_pick.rs','desktop/app/src/engine/effect_pick/tests.rs','desktop/app/src/engine/effect_pick/tests/native.rs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--freeze' in sys.argv:
    (root/'source-hashes.json').write_text(json.dumps({p:sha(workspace/p) for p in sources},indent=2),encoding='utf-8')
    print('frozen sources',len(sources));sys.exit()
hashes=json.loads((root/'source-hashes.json').read_text())
def unchanged():
    for p,h in hashes.items():assert sha(workspace/p)==h,p
unchanged()
exe=root/'tested.exe'
if '--reuse' not in sys.argv:
    build=(root/'build.log').read_text(encoding='utf-8')
    match=re.findall(r'Executable .*?\((.*?\.exe)\)',build)
    assert len(match)==1,match
    shutil.copyfile(workspace/match[0],exe)
    (root/'binary.json').write_text(json.dumps({'path':str(exe),'sha256':sha(exe),'bytes':exe.stat().st_size},indent=2))
env=os.environ.copy()
env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
env['MOTION_MAPPED_PICK_ARTIFACTS']=str(root/'native')
jobs=[('worker',['engine::effect_pick::tests::']),('panel',['panels::effect_pick::tests::']),
('effect-controls',['panels::effect_controls::']),
('mapped-native',['--exact','engine::effect_pick::tests::native::mapped_native_picks_use_exact_local_keys_in_two_owners_and_languages','--ignored']),
('legacy-native',['--exact','panels::effect_pick::tests::native::native_effect_picks_preserve_source_coordinates_precision_history_and_failure_channels','--ignored'])]
if '--only-native' in sys.argv:jobs=jobs[3:4]
results=[]
for tag,args in jobs:
    begin=time.monotonic()
    result=subprocess.run([str(exe),*args,'--nocapture','--test-threads=1'],cwd=workspace,env=env,capture_output=True,timeout=600)
    (root/(tag+'-stdout.log')).write_bytes(result.stdout);(root/(tag+'-stderr.log')).write_bytes(result.stderr)
    stdout=result.stdout.decode('utf-8',errors='replace')
    passed=re.findall(r'^test (.*?) \.\.\. ok$',stdout,re.M);ignored=re.findall(r'^test (.*?) \.\.\. ignored',stdout,re.M)
    results.append({'group':tag,'args':args,'exit':result.returncode,'seconds':round(time.monotonic()-begin,3),'passed':passed,'ignored':ignored})
    (root/('native-results.json' if '--only-native' in sys.argv else 'test-results.json')).write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    print(tag,result.returncode,'passed',len(passed),'ignored',len(ignored),flush=True)
    if result.returncode: print(stdout[-4000:],result.stderr.decode('utf-8',errors='replace')[-4000:]);sys.exit(result.returncode)
unchanged();print('unchanged sources',len(hashes),'unique passes',len({p for r in results for p in r['passed']}))
