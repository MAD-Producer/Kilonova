import hashlib,json,pathlib,shutil,zipfile
root=pathlib.Path(__file__).parent
workspace=pathlib.Path('E:/Dev/aem/.worktrees/layer-time-mapping')
dest=workspace/'engineering/validation/layer-time-effect-picks-evidence'
dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((root/'source-hashes.json').read_text())
for n,h in sources.items():assert sha(workspace/n)==h,n
results=json.loads((root/'test-results.json').read_text())
assert len(results)==5 and all(p['exit']==0 for p in results)
passed={p for r in results for p in r['passed']}
unrun={p for r in results for p in r['ignored']}-passed
native=root/'native'
assert len(list(native.glob('*/*.png')))==32
assert len(list(native.glob('*/saved.json')))==8
assert len(list(native.glob('*/reopened.json')))==8
capture=json.loads((native/'capture-process.json').read_text());reopen=json.loads((native/'reopen-process.json').read_text());assert capture['pid']!=reopen['pid']
with zipfile.ZipFile(dest/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in root.rglob('*'):
        if p.is_file() and p.suffix.lower()!='.exe':z.write(p,p.relative_to(root).as_posix())
    for n in sources:z.write(workspace/n,'source/'+n)
for original,name in [('Zh-false-false/start-committed.png','position-main-zh.png'),('En-true-true/start_color-committed.png','color-floating-en.png')]:
    shutil.copyfile(native/original,dest/name)
manifest={'issue':257,'stage':'exact-time effect position and color picks','base':'0bf7cf826d96f48bd75b3b7213dda50af9c3f700',
'branch':'feat/layer-time-mapping','sourceHashes':sources,'binary':json.loads((root/'binary.json').read_text()),
'passed':len(passed),'unrunManual':sorted(unrun),'testResults':results,'nativeCases':8,'nativeScreenshots':32,
'processes':{'capture':capture,'reopen':reopen},'checks':json.loads((root/'checks.json').read_text()),
'bundle':{'path':'evidence.zip','sha256':sha(dest/'evidence.zip'),'bytes':(dest/'evidence.zip').stat().st_size},
'screenshots':{p.name:sha(p) for p in dest.glob('*.png')}}
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('packaged',len(passed),'unique passes,',len(unrun),'manual unrun,',manifest['bundle']['bytes'],'bytes')
