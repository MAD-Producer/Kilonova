import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path('E:/Dev/aem/.worktrees/panel-paint-reuse')
out = Path(__file__).parent
data = {}
for suffix in ('stdout', 'stderr', 'json'):
    for p in sorted(out.glob('*.' + suffix)):
        data['runs/' + p.name] = p.read_bytes()
for p in sorted((out / 'pixels').glob('*.png')):
    data['pixels/' + p.name] = p.read_bytes()
data['run.py'] = (out / 'run.py').read_bytes()
data['package.py'] = Path(__file__).read_bytes()
status = subprocess.run(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=root, capture_output=True, text=True, check=True).stdout
sources = []
for line in status.splitlines():
    name = line[3:]
    if name.endswith('.rs') or name == '.github/workflows/ci.yml':
        sources.append(name)
        data['source-final/' + name] = (root / name).read_bytes()
        before = subprocess.run(['git', 'show', 'e314cc92232dcd366b01e10454ae1100d4e24d63:' + name], cwd=root, capture_output=True)
        if before.returncode == 0:
            data['source-before/' + name] = before.stdout
data['changes.patch'] = subprocess.run(['git', 'diff', '--no-ext-diff', 'HEAD', '--', *sources], cwd=root, capture_output=True, check=True).stdout
exe = Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-774aa62586cb70fd.exe')
h = hashlib.sha256()
with exe.open('rb') as stream:
    for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
        h.update(block)
data['native-program.json'] = json.dumps({'path': str(exe), 'size': exe.stat().st_size, 'sha256': h.hexdigest()}, indent=2).encode()
data['cleanup-disposition.json'] = json.dumps({'action': 'remove completed own UI test exe/pdb files', 'result': 'not executed', 'reason': 'automatic approval rejected: blocked by policy', 'manifest': 'runs/completed-own-ui-binaries.json'}, indent=2).encode()
manifest = {name: {'size': len(value), 'sha256': hashlib.sha256(value).hexdigest()} for name, value in data.items()}
archive = root / 'engineering/validation/panel-paint-reuse-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, value in data.items():
        z.writestr(name, value)
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, expected in manifest.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == expected['sha256']
receipt = {'members': len(data) + 1, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'sources': sources}
(out / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt, ensure_ascii=False))
