import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('E:/Dev/aem/.worktrees/panel-paint-reuse')
out = Path(__file__).parent
phase = sys.argv[1]
command = sys.argv[2:]
sources = {}
for file in ['desktop/ui/src/panel.rs', 'desktop/ui/src/paint.rs', 'desktop/ui/src/widgets/composite.rs', 'desktop/app/src/node_editor/view/controls.rs', 'desktop/app/src/node_editor/view/control_tests.rs', 'desktop/app/src/node_editor/tests.rs', 'desktop/app/src/panels/graph_native_performance_tests.rs', 'desktop/app/src/plugin_editor/author/catalog.rs', 'desktop/ui/tests/panel_paint_reuse.rs', 'desktop/ui/tests/panel_paint_reuse/allocations.rs', 'desktop/ui/tests/panel_paint_pixels.rs', 'desktop/ui/tests/layer_visibility.rs', 'desktop/ui/tests/support/editor_capture.rs']:
    sources[file] = hashlib.sha256((root / file).read_bytes()).hexdigest()
start = time.time()
with (out / (phase + '.stdout')).open('wb') as stdout, (out / (phase + '.stderr')).open('wb') as stderr:
    result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr)
record = {'command': command, 'exit': result.returncode, 'elapsed_seconds': time.time() - start, 'sources': sources}
for file, sha in sources.items():
    if hashlib.sha256((root / file).read_bytes()).hexdigest() != sha:
        record['source_changed_during_run'] = file
(out / (phase + '.json')).write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps(record), flush=True)
print((out / (phase + '.stdout')).read_text(encoding='utf-8', errors='replace')[-7000:], flush=True)
print((out / (phase + '.stderr')).read_text(encoding='utf-8', errors='replace')[-2000:], flush=True)
