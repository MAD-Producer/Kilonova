import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
out = Path(__file__).parent
source = root / 'crates/motion-render/src/video_gpu.rs'
original = source.read_bytes()
needle = b'allocations: Some(prepared.allocations.map(|lease| lease.retention())),'
assert original.count(needle) == 1
mutant = original.replace(needle, b'allocations: None, // controlled loss of upload retention')
before = hashlib.sha256(original).hexdigest()
try:
    source.write_bytes(mutant)
    result = subprocess.run([sys.executable, str(out / 'run.py'), 'missing-retention-negative',
        'cargo', 'test', '--locked', '-p', 'motion-render', '--test', 'video_retirement_pressure',
        '--', '--test-threads=1', '--nocapture'])
finally:
    source.write_bytes(original)
    restored = hashlib.sha256(source.read_bytes()).hexdigest()
    (out / 'mutation-restoration.json').write_text(json.dumps({
        'file': str(source), 'original_sha256': before, 'mutant_sha256': hashlib.sha256(mutant).hexdigest(),
        'restored_sha256': restored, 'restored': restored == before,
    }, indent=2), encoding='utf-8')
assert restored == before
stdout = (out / 'missing-retention-negative.stdout').read_text(encoding='utf-8')
stderr = (out / 'missing-retention-negative.stderr').read_text(encoding='utf-8')
assert result.returncode == 101, f'expected runtime test refusal, got {result.returncode}'
assert '0 passed; 1 failed' in stdout, stdout[-1000:]
assert 'cache removal must not return capacity owned by unsubmitted tokens' in stderr, stderr[-2000:]
print('Negative control failed at retained capacity assertion; production source restored byte-for-byte.')
