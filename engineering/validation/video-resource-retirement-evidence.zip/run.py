import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path.cwd()
out = Path(__file__).parent
phase, *command = sys.argv[1:]

def sources():
    names = subprocess.check_output(['git', 'ls-files', 'crates/motion-render',
        'crates/motion-host', 'crates/motion-desktop-media', 'Cargo.toml', 'Cargo.lock'], encoding='utf-8').splitlines()
    names += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard',
        'crates/motion-render', 'crates/motion-desktop-media'], encoding='utf-8').splitlines()
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
        for name in sorted(set(names)) if (root / name).is_file()}

meta = {'command': command, 'cwd': str(root), 'source_before': sources(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'env': {key: os.environ.get(key) for key in ['MOTION_LOG', 'WGPU_BACKEND',
        'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL']}}
receipt = out / (phase + '.json')
receipt.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
started = time.monotonic()
with (out / (phase + '.stdout')).open('wb') as stdout, (out / (phase + '.stderr')).open('wb') as stderr:
    result = subprocess.run(command, stdout=stdout, stderr=stderr)
meta.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - started,
    source_after=sources())
receipt.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'phase': phase, 'exit_code': result.returncode,
    'elapsed_seconds': meta['elapsed_seconds'], 'source_unchanged': meta['source_before'] == meta['source_after']}))
sys.exit(result.returncode)
