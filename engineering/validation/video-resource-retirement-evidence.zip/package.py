import hashlib
import json
from pathlib import Path
import zipfile

root = Path.cwd()
out = Path(__file__).parent
archive = root / 'engineering/validation/video-resource-retirement-evidence.zip'
members = {p.name: p.read_bytes() for p in out.iterdir() if p.is_file()
    and p.suffix in ['.json', '.stdout', '.stderr', '.py', '.ps1']}
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    for name, data in sorted(members.items())}
members['archive-manifest.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(members.items()):
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    for name, entry in manifest.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == entry['sha256'], name
print(json.dumps({'archive': str(archive), 'members': len(members),
    'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}))
