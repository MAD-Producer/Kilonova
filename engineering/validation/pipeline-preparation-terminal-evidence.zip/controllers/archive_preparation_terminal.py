from pathlib import Path
import hashlib
import json
import zipfile
from PIL import Image

BASE=Path(__file__).parent
ROOT=Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
DEST=ROOT/'engineering/validation/pipeline-preparation-terminal-evidence.zip'
assert not DEST.exists()
phases=['tools-current-regression-v1','package-identity-normal-app-v1',
        'package-identity-normal-app-v2','package-identity-render-failure-v1',
        'package-identity-render-failure-v2','preparation-terminal-baseline-v1',
        'preparation-terminal-playback-test-v1','preparation-terminal-playback-test-v2',
        'preparation-terminal-native-v1','preparation-terminal-normal-build-v1',
        'preparation-terminal-normal-app-v1','preparation-terminal-tools-v1',
        'preparation-terminal-native-v2','preparation-terminal-normal-build-v2',
        'preparation-terminal-normal-app-v2','preparation-terminal-playback-test-v3',
        'preparation-terminal-tools-v2','preparation-terminal-normal-regression-v1']
expected_failures=set(phases[1:6])
receipts={}
for phase in phases:
    receipt=json.loads((BASE/(phase+'.json')).read_text(encoding='utf-8'))
    assert receipt['source_before']==receipt['source_after'],phase
    assert (receipt['exit_code']!=0)==(phase in expected_failures),(phase,receipt['exit_code'])
    receipts[phase]=receipt
final=receipts['preparation-terminal-native-v2']['source_after']
for phase in ['preparation-terminal-playback-test-v3','preparation-terminal-normal-build-v2',
              'preparation-terminal-normal-app-v2','preparation-terminal-tools-v2',
              'preparation-terminal-normal-regression-v1']:
    assert receipts[phase]['source_after']==final,phase
for name,digest in final.items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
report=json.loads((BASE/'preparation-terminal-normal-app-v2-evidence/report.json').read_text(encoding='utf-8'))
assert len(report['runs'])==5
assert all(r['exit_code']==0 for r in report['runs'])
assert len(set(r['pid'] for r in report['runs']))==5
assert report['runs'][-1]['idle_error_resubmission_stopped']
assert report['runs'][-1]['explicit_undo_recovers_original_pixels']
native=json.loads((BASE/'preparation-terminal-native-v2-evidence/report.json').read_text(encoding='utf-8'))
assert native['cacheSupported'] and len(native['cases'])==2
assert all(c['clearedWithoutOwnerRequests'] for c in native['cases'])
images=BASE/'preparation-terminal-status-native-v2-evidence'
assert len(list(images.glob('*.png')))==52
for status in ['preparing','ready']:
    actual=Image.open(images/f'clean-zh-main-1600x1000-1-{status}.png').convert('RGBA')
    # The status is the only product surface relevant to this scheduling fix.
    crop=actual.crop((0,980,1600,1000))
    expected=Image.open(ROOT/'engineering/validation/screenshots'/
                        ('preview-preparation-status.png' if status=='preparing' else 'preview-preparation-ready.png')).convert('RGBA')
    # Published status images intentionally include the footer plus 60px above.
    assert crop.tobytes()==expected.crop((0,expected.height-20,1600,expected.height)).tobytes(),status
files={}
def add(path,name):
    assert name not in files,name
    files[name]=path.read_bytes()
for phase in phases:
    for suffix in ['json','stdout','stderr']:
        add(BASE/(phase+'.'+suffix),'commands/'+phase+'.'+suffix)
for name in ['run.py','run_package_identity_normal_app.py','run_package_identity_normal_app_v1.py',
             'run_package_identity_render_failure.py','run_package_identity_render_failure_v1.py',
             'run_package_identity_render_failure_v2.py','package-identity-fixture-audit.json',
             'package-identity-protocol-audit.json','preparation-terminal-runtime-identity.json',
             'preparation-status-runtime-identity.json','archive_preparation_terminal.py',
             'preparation-terminal-final-runtime-identity.json',
             'preparation-terminal-first-archive-receipt.json']:
    add(BASE/name,'controllers/'+name)
for directory in ['package-identity-normal-app-v1-evidence','package-identity-normal-app-v2-evidence',
                  'package-identity-render-failure-v1-evidence','package-identity-render-failure-v2-evidence',
                  'preparation-terminal-baseline-v1-evidence','preparation-terminal-normal-app-v1-evidence',
                  'preparation-terminal-native-v1-evidence','preparation-terminal-status-native-v1-evidence',
                  'preparation-terminal-tools-v1-evidence',
                  'preparation-terminal-normal-app-v2-evidence',
                  'preparation-terminal-native-v2-evidence',
                  'preparation-terminal-status-native-v2-evidence',
                  'preparation-terminal-tools-v2-evidence',
                  'preparation-terminal-normal-regression-v1-evidence']:
    for path in sorted((BASE/directory).rglob('*')):
        if (path.is_file() and path.suffix not in ['.cache','.dll','.exe','.dmp']
            and not (path.suffix=='.msfx' and 'plugins' in path.parts)):
            add(path,'evidence/'+path.relative_to(BASE).as_posix())
for name in ['desktop/app/src/engine.rs','desktop/app/src/engine/preparation_progress.rs',
             'desktop/app/src/engine/frame_completion/tests/native.rs',
             'desktop/app/src/engine/frame_completion/tests/native/orphaned_preparation.rs',
             'desktop/app/src/shell/presentation.rs']:
    add(ROOT/name,'source/'+name)
index={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in files.items()}
with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()): z.writestr(name,data)
    z.writestr('index.json',json.dumps(index,indent=2))
with zipfile.ZipFile(DEST) as z:
    assert z.testzip() is None
    for name,entry in index.items():
        data=z.read(name)
        assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],name
receipt=dict(path=str(DEST),members=len(files)+1,bytes=DEST.stat().st_size,
             sha256=hashlib.sha256(DEST.read_bytes()).hexdigest(),sourceFiles=len(final),
             phases={p:dict(exit_code=r['exit_code'],elapsed_seconds=r['elapsed_seconds']) for p,r in receipts.items()})
(BASE/'preparation-terminal-archive-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
