"""Normal application shader replacement and rejection, with a shared native cache.

All shader text is independently authored here. No product source/test hooks or
driver-global cache manipulation. Never overwrites a prior evidence directory.
"""
from pathlib import Path
import copy
import ctypes
from ctypes import wintypes
import hashlib
import io
import json
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
import zipfile
from PIL import Image

ROOT = Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
BASE = Path(__file__).parent
BINARY = Path(sys.argv[1]).resolve(strict=True)
OUT = Path(sys.argv[2]).resolve()
assert not OUT.exists(), 'Preserve earlier runs'
OUT.mkdir()
ACCOUNT = OUT/'account'
CACHE = ACCOUNT/'MotionStudio/driver-pipeline-cache-v1'
ACCOUNT.mkdir()
PLUGIN = 'org.motionstudio.validation.pipeline-identity'
EFFECT = 'identity_probe'
SHADER_PATH = 'shaders/probe.wgsl'
manifest = dict(format_version=1, sdk_version=6, id=PLUGIN, version='1.0.0',
                name='Pipeline identity qualification', author='motion-studio contributors',
                license='MIT', effects=[dict(id=EFFECT, name='Pipeline identity',
                english_name='Pipeline identity', category='Validation', params=[],
                passes=[dict(shader=SHADER_PATH, entry='main_fx')],
                working_space='srgb', alpha_mode='straight')])
SOURCES = {
    'a': 'fn main_fx(p:vec2<f32>)->vec4<f32>{return vec4<f32>(0.125,0.75,0.25,1.0);}',
    'b': 'fn main_fx(p:vec2<f32>)->vec4<f32>{return vec4<f32>(0.75,0.125,0.5,1.0);}',
    'invalid': 'fn main_fx(p:vec2<f32>)->vec4<f32>{return missing_shader_symbol;}',
}

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def package(kind):
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for name,data in [('manifest.json',json.dumps(manifest,separators=(',',':'))),
                          (SHADER_PATH,SOURCES[kind])]:
            info=zipfile.ZipInfo(name,date_time=(2026,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,data)
    return stream.getvalue()

packages={kind:package(kind) for kind in SOURCES}
for kind,data in packages.items():
    (OUT/(kind+'.msfx')).write_bytes(data)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
for kind,source in SOURCES.items():
    (OUT/(kind+'.wgsl')).write_text(source,encoding='utf-8')
template=json.loads((BASE/'frame-completion-existing-model-layer-evidence/project/project.json').read_text(encoding='utf-8'))
project=copy.deepcopy(template)
project.update(name='Package identity qualification',width=64,height=64,
               fps={'numerator':30,'denominator':1},frames=60,
               work_area={'in_frame':0,'out_frame':60},assets=[],model_assets=[],
               tracking_assets=[],plugin_dependencies=[],layers=[])
layer=copy.deepcopy(template['layers'][0])
layer.update(name='Authored source',content={'kind':'solid','color':[0.8,0.2,0.1,1]},
             size=[48,48],three_d=False,effects=[])
layer['transform'].update(position={'value':[32,32,0],'keys':[]},rotation={'value':[0,0,0],'keys':[]})
project['layers']=[layer]
user32=ctypes.WinDLL('user32',use_last_error=True)
CALLBACK=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
user32.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
user32.ShowWindow.argtypes=[wintypes.HWND,ctypes.c_int]
user32.PostMessageW.argtypes=[wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM]
user32.EnumWindows.argtypes=[CALLBACK,wintypes.LPARAM]

def windows(pid):
    found=[]
    @CALLBACK
    def collect(handle,_):
        owner=wintypes.DWORD()
        user32.GetWindowThreadProcessId(handle,ctypes.byref(owner))
        if owner.value==pid: found.append(handle)
        return True
    assert user32.EnumWindows(collect,0)
    return found

def run(label,kind,cold=False):
    case=OUT/label
    case.mkdir()
    root=case/'project'
    root.mkdir()
    plugins=case/'plugins'
    plugins.mkdir()
    data=packages[kind]
    package_hash=hashlib.sha256(data).hexdigest()
    package_file=plugins/(package_hash+'.msfx')
    package_file.write_bytes(data)
    instance=dict(id=1,plugin=PLUGIN,effect=EFFECT,version='1.0.0',hash=package_hash,
                  enabled=True,seed=1,params={})
    fixture=copy.deepcopy(project)
    valid=kind!='invalid'
    if valid:
        fixture['layers'][0]['effects']=[instance]
        fixture['plugin_dependencies']=[{k:instance[k] for k in ['plugin','version','hash']}]
    source=root/'project.json'
    source.write_text(json.dumps(fixture,indent=2),encoding='utf-8')
    original_sha=sha(source)
    cache_before=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in CACHE.glob('*') if p.is_file()]
    assert bool(cache_before)!=cold, cache_before
    env=os.environ.copy()
    env.update(LOCALAPPDATA=str(ACCOUNT),MOTION_UI_LAYOUT=str(case/'workspace.json'))
    for key in ['MOTION_LOG','MOTION_PROJECT']: env.pop(key,None)
    stderr=(case/'stderr.log').open('w',encoding='utf-8')
    stdout=(case/'stdout.jsonl').open('w',encoding='utf-8')
    transcript=(case/'requests.jsonl').open('w',encoding='utf-8')
    proc=subprocess.Popen([str(BINARY),'--mcp-ui','--project',str(root),'--locale','en',
                           '--diagnostics-report',str(case/'diagnostics.json')],
                          stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,
                          text=True,encoding='utf-8',env=env,creationflags=subprocess.CREATE_NO_WINDOW)
    started=time.monotonic()
    received=queue.Queue()
    stop=threading.Event()
    def read():
        for line in proc.stdout:
            stdout.write(line);stdout.flush();received.put(line)
        received.put(None)
    reader=threading.Thread(target=read,daemon=True);reader.start()
    def show():
        shown=set()
        while not stop.wait(.02) and proc.poll() is None:
            for h in windows(proc.pid):
                if h not in shown: user32.ShowWindow(h,4);shown.add(h)
    shower=threading.Thread(target=show,daemon=True);shower.start()
    seq=0
    def send(method,params):
        nonlocal seq
        seq+=1
        request=dict(jsonrpc='2.0',id=seq,method=method,params=params)
        transcript.write(json.dumps(dict(at_ms=(time.monotonic()-started)*1000,request=request))+'\n');transcript.flush()
        proc.stdin.write(json.dumps(request)+'\n');proc.stdin.flush()
        line=received.get(timeout=20)
        assert line is not None,'Application exited before response'
        response=json.loads(line)
        assert response.get('id')==seq and 'error' not in response,response
        return response['result']
    def tool(name,args=None,expect_error=False):
        result=send('tools/call',dict(name=name,arguments=args or {}))
        assert bool(result.get('isError'))==expect_error,result
        return result if expect_error else result['structuredContent']
    def ready():
        deadline=time.monotonic()+30
        while True:
            s=tool('motion_state')
            if s.get('lastPresentedRevision')==s['revision'] and s['presented']>0 and not s['preview']['pipelinePreparation']['preparing']:
                return s
            assert time.monotonic()<deadline,s
            time.sleep(.02)
    receipt=dict(pid=proc.pid,label=label,kind=kind,package_hash=package_hash,
                 binary_sha256=sha(BINARY),cache_before=cache_before)
    try:
        send('initialize',dict(protocolVersion='2025-11-25',capabilities={},clientInfo=dict(name='package-identity-qualification',version='1')))
        proc.stdin.write(json.dumps(dict(jsonrpc='2.0',method='notifications/initialized'))+'\n');proc.stdin.flush()
        s=ready()
        receipt['first_complete_ms']=(time.monotonic()-started)*1000
        (case/'state.json').write_text(json.dumps(s,indent=2),encoding='utf-8')
        prep=s['preview']['pipelinePreparation']
        receipt['driver_load']=prep['driverCache']['load']
        assert receipt['driver_load']==('missing' if cold else 'restored'),prep
        if valid: assert prep['task']['phase']=='installed',prep
        builds=s['preview']['effectPipelineBuilds']
        png=tool('render_preview')['path']
        shutil.copy2(png,case/'preview.png')
        pixels=Image.open(case/'preview.png').convert('RGBA')
        assert pixels.size==(64,64)
        center=list(pixels.getpixel((32,32)))
        expected={'a':[32,191,64,255],'b':[191,32,128,255],'invalid':[204,51,26,255]}[kind]
        assert all(abs(a-b)<=1 for a,b in zip(center,expected)),(kind,center,expected)
        receipt.update(center=center,rgba_sha256=hashlib.sha256(pixels.tobytes()).hexdigest(),effectPipelineBuilds=builds)
        after=tool('motion_state')
        assert after['preview']['effectPipelineBuilds']==builds,'Capture created an unprepared pipeline'
        assert after['project']==s['project'] and after['revision']==s['revision']
        assert sha(source)==original_sha,'Startup/capture changed the authored project'
        if not valid:
            # Generic model edits intentionally commit independently of installed
            # packages. Exercise the render error boundary, not a plugin-import
            # assumption: a populated native cache cannot rescue rejected code.
            committed=tool('motion_edit',dict(expectedRevision=s['revision'],commands=[dict(op='effect',object=1,action=dict(kind='insert',instance=instance))]))
            assert committed['revision']==s['revision']+1
            assert committed['project']['layers'][0]['effects']==[instance]
            error=tool('render_preview',expect_error=True)
            text=json.dumps(error)
            for token in ['missing plugin',PLUGIN,package_hash]: assert token in text,text
            (case/'rejection.json').write_text(json.dumps(error,indent=2),encoding='utf-8')
            unchanged=tool('motion_state')
            assert unchanged['revision']==committed['revision'] and unchanged['project']==committed['project'],'Failed rendering mutated the committed project'
            assert not unchanged['preview']['pipelinePreparation']['preparing'],'Terminal failure left a permanent preparation indicator'
            receipt['failed_render_preserves_committed_project']=True
        deadline=time.monotonic()+10
        while not any(p.is_file() for p in CACHE.glob('*')):
            assert time.monotonic()<deadline,'No cache persisted'
            tool('motion_state');time.sleep(.02)
        for h in windows(proc.pid): user32.PostMessageW(h,0x0010,0,0)
        proc.stdin.close()
        receipt['exit_code']=proc.wait(timeout=20)
        reader.join(timeout=5)
        assert receipt['exit_code']==0
        log=ACCOUNT/'MotionStudio/logs/motion-studio.log'
        shutil.copy2(log,case/'motion-studio.log')
        file_text=log.read_text(encoding='utf-8',errors='replace')
        stderr.flush()
        error_text=(case/'stderr.log').read_text(encoding='utf-8',errors='replace')
        out_text=(case/'stdout.jsonl').read_text(encoding='utf-8')
        assert 'logging initialized level=INFO' in file_text
        for line in out_text.splitlines(): assert json.loads(line)['jsonrpc']=='2.0'
        if not valid:
            for text in [file_text,error_text]:
                assert 'site=host.registry.load' in text and 'missing_shader_symbol' in text and 'pass 0' in text,text[-2000:]
                assert package_hash in text
            assert 'missing_shader_symbol' not in out_text,'Error log contaminated stdout'
            receipt['default_diagnostic_file_stderr_stdout_isolation']=True
        assert sha(package_file)==package_hash,'Rejected/loaded archive modified'
        receipt['cache_after']=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in CACHE.glob('*') if p.is_file()]
        receipt['elapsed_ms']=(time.monotonic()-started)*1000
        (case/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
        print(json.dumps(receipt),flush=True)
        return receipt
    except BaseException:
        (case/'partial-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
        raise
    finally:
        stop.set();shower.join(timeout=1)
        if proc.poll() is None: proc.kill();proc.wait(timeout=10)
        reader.join(timeout=5)
        (case/'process-exit.json').write_text(json.dumps(dict(exit_code=proc.returncode)),encoding='utf-8')
        stdout.close();stderr.close();transcript.close()

runs=[run('a-cold','a',cold=True),run('a-warm','a'),run('b-replaces-a','b'),
      run('a-replaces-b','a'),run('invalid-shader','invalid')]
assert len({r['pid'] for r in runs})==len(runs)
assert runs[0]['rgba_sha256']==runs[1]['rgba_sha256']==runs[3]['rgba_sha256']
assert runs[2]['rgba_sha256']!=runs[1]['rgba_sha256'],'Changed package executed the old shader'
assert runs[0]['package_hash']==runs[1]['package_hash']==runs[3]['package_hash']!=runs[2]['package_hash']
(OUT/'report.json').write_text(json.dumps(dict(runs=runs,scope='Same plugin/version/manifest; changed independently authored source and archive hash. Private application cache only; no driver-global cache cleared. Invalid source is rejected by normal CPU package validation before native pipeline compilation.'),indent=2),encoding='utf-8')
