import os,subprocess,json,time,sys,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
exe=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-b34b3a7e7eb835e8.exe')
env=os.environ.copy();env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH'];env.pop('MOTION_LOG',None)
env['MOTION_MAPPED_PATH_ARTIFACTS']=str(root/'native')
env['MOTION_MAPPED_PATH_FAULT_ARTIFACTS']=str(root/'numeric-faults')
env['MOTION_PATH_NAVIGATION_FAULT_ARTIFACTS']=str(root/'navigation-faults')
groups=[('mapped',['panels::path_controls::mapped_authoring_tests::']),('paths',['panels::path_controls::','--skip','panels::path_controls::mapped_authoring_tests::']),('key-navigation',['panels::key_navigation::']),('key-selection',['panels::key_selection::']),('native',['--exact','panels::path_controls::mapped_authoring_tests::native::native_mapped_paths_keep_exact_keys_in_both_hosts_languages_and_directions','--ignored'])]
results=[]
before=hashlib.sha256(exe.read_bytes()).hexdigest()
for name,args in groups:
    if len(sys.argv)>1 and name not in sys.argv[1:]:continue
    start=time.time()
    with (root/(name+'.log')).open('wb') as log:r=subprocess.run([str(exe),*args,'--nocapture','--test-threads=1'],stdout=log,stderr=subprocess.STDOUT,env=env)
    row=dict(group=name,args=args,exit=r.returncode,seconds=round(time.time()-start,3),exeSha256=before);results.append(row)
    (root/('results-'+('-'.join(sys.argv[1:]) if len(sys.argv)>1 else 'all')+'.json')).write_text(json.dumps(results,indent=2));print(json.dumps(row),flush=True)
    assert hashlib.sha256(exe.read_bytes()).hexdigest()==before,'test executable changed during run'
    if r.returncode:break
raise SystemExit(any(x['exit'] for x in results))
