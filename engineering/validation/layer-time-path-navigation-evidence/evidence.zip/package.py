import hashlib,json,re,shutil,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path.cwd()
dest=repo/'engineering/validation/layer-time-path-navigation-evidence'
dest.mkdir(exist_ok=True)
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
sources=json.loads((root/'source-hashes.json').read_text())
format_only=[]
for name,sha in sources.items():
    if digest(repo/name)==sha:continue
    assert name=='desktop/app/src/panels/path_controls/mapped_authoring_tests.rs',name
    assert digest(root/'tested-harness.rs')==sha
    # rustfmt's stdout carries a two-line filename header. Its exact output
    # must match the final source; no manual semantic normalization is used.
    formatted='\n'.join((root/'formatted-tested-harness.txt').read_text(encoding='utf-8-sig').splitlines()[2:])+'\n'
    assert formatted==(repo/name).read_text(),name
    format_only.append(dict(path=name,compiledSha256=sha,finalSha256=digest(repo/name),proof='tested-harness.rs and formatted-tested-harness.txt'))
groups=[];unique=set();hashes=set()
for name in ['mapped','paths','key-navigation','key-selection','native']:
    logs=(root/(name+'.log')).read_text(errors='replace')
    assert 'test result: ok.' in logs and 'test result: FAILED' not in logs,name
    passed=re.findall(r'^test (\S+) \.\.\. ok$',logs,re.M)
    ignored=re.findall(r'^test (\S+) \.\.\. ignored.*$',logs,re.M)
    unique.update(passed);groups.append(dict(group=name,passed=passed,ignored=ignored))
    result=json.loads((root/('results-'+('mapped' if name=='mapped' else 'paths-key-navigation-key-selection-native')+'.json')).read_text())
    hashes.update(row['exeSha256'] for row in result if row['group']==name)
assert len(hashes)==1,hashes
exe=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-b34b3a7e7eb835e8.exe')
assert digest(exe) in hashes,'tested executable changed'
checks=json.loads((root/'checks.json').read_text(encoding='utf-8-sig'))
assert all(v==0 for v in checks.values()),checks
assert len(list((root/'native').rglob('*.png')))==80
assert len(list((root/'native').rglob('reopened.json')))==16
a=json.loads((root/'native/capture-process.json').read_text());b=json.loads((root/'native/reopen-process.json').read_text())
assert a['pid']!=b['pid']
for source,name in [('Masks-Zh-false-false/navigated.png','mask-navigation-main-zh.png'),('Vector-En-true-true/navigated.png','vector-navigation-floating-en.png')]:
    shutil.copyfile(root/'native'/source,dest/name)
archive=dest/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.suffix.lower() in {'.log','.json','.py','.ps1','.png','.rs','.txt'}:
            z.write(p,p.relative_to(root).as_posix())
manifest=dict(issue=257,pr=579,stage='mapped mask and vector key navigation and atomic toggling',base='e26abf9ddd3ac7144619be14aeed66e773a43b2b',branch='feat/layer-time-mapping',sourceHashes=sources,formatOnlySources=format_only,checks=checks,passed=len(unique),testResults=groups,unrunManual=sorted({n for g in groups for n in g['ignored']}-unique),
    binary=dict(path=str(exe),sha256=digest(exe),bytes=exe.stat().st_size,scope='all final groups use the same build; production sources and executable unchanged during final verification; one new test harness formatted afterward with exact formatter-equivalence proof'),
    native=dict(cases=16,screenshots=80,separateProcessReopens=16,capturePid=a['pid'],reopenPid=b['pid'],input='synthetic Input through production chrome; actual native GPU capture, not physical OS mouse input'),
    observationSites=['mask.navigation_time','vector.navigation_time','path.navigation_selection'],
    originalFailures=['initial-navigation-failure.log and initial-actual/expected.json: real missing Delete dispatch after navigation; also invalid spatial group fixture','editor-action-fixture-compile-failure.log: new fixture returned Value rather than Result','interim-mapped.log: intermediate 10 passing tests; not counted as final source proof'],
    limits=['Windows verification only','vector-group spatial identities explicitly unsupported by current model; no guard removed','partial authored mask pose copying remains disabled','existing numeric text clipping and general DESIGN baseline retained','camera gestures and real media device/high-speed sampling acceptance remain','issue 257 stays open'],
    archive=dict(file='evidence.zip',sha256=digest(archive),bytes=archive.stat().st_size))
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(passed=len(unique),archiveBytes=archive.stat().st_size,sources=len(sources))))
