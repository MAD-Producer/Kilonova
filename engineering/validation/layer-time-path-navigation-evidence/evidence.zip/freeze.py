import hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path.cwd()
names=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())
names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
hashes={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in sorted(names) if name.endswith('.rs')}
(root/'source-hashes.json').write_text(json.dumps(hashes,indent=2))
print(len(hashes))
