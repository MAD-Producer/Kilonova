$env:WGPU_BACKEND='dx12'
$env:PYTHONUTF8='1'
$env:TEMP='E:/Dev/aem/artifacts/issue-goal-current/native-pipeline-preparation/temp'
$env:TMP=$env:TEMP
$env:TMPDIR=$env:TEMP
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
$base='E:/Dev/aem/artifacts/issue-goal-current/native-pipeline-preparation'
$env:MOTION_PIPELINE_SURFACE_EVIDENCE="$base/multiview-dx12-surface-v1-evidence"
$hostBinary='E:/Dev/aem/.tools/pipeline-status-target/debug/deps/motion_host-1549c6f1f789ffe7.exe'
python "$base/run.py" multiview-dx12-surface-v1 $hostBinary --exact session::pipeline_preparation::tests::native::actual_surface_keeps_chrome_and_front_responsive_until_current_revision_is_prepared --nocapture --test-threads=1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python "$base/run.py" multiview-dx12-group-v1 $hostBinary session::viewer::tests --nocapture --test-threads=1
exit $LASTEXITCODE
