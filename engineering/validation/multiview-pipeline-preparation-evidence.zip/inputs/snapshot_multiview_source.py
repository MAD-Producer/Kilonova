from pathlib import Path
import subprocess, sys, shutil
root = Path.cwd()
out = Path(__file__).parent/(sys.argv[1]+'-source')
assert not out.exists()
names = subprocess.check_output(['git','diff','--name-only','--','crates','desktop/app'],text=True).splitlines()
names += subprocess.check_output(['git','ls-files','--others','--exclude-standard','crates','desktop/app'],text=True).splitlines()
for name in sorted(set(names)):
    source = root/name
    destination = out/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,destination)
print('frozen changed source files:',len(set(names)))
