param([string]$Phase, [string]$Filter)
. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:CARGO_TARGET_DIR='E:/Dev/aem/.tools/pipeline-status-target'
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:CARGO_PROFILE_DEV_DEBUG='0'
$env:CARGO_PROFILE_TEST_DEBUG='0'
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:LIBCLANG_PATH='E:/Dev/aem/.tools/python-libclang/clang/native'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
$env:TEMP='E:/Dev/aem/artifacts/issue-goal-current/native-pipeline-preparation/temp'
$env:TMP=$env:TEMP
$env:TMPDIR=$env:TEMP
$env:PYTHONUTF8='1'
python E:/Dev/aem/artifacts/issue-goal-current/native-pipeline-preparation/snapshot_multiview_source.py $Phase
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python E:/Dev/aem/artifacts/issue-goal-current/native-pipeline-preparation/run.py $Phase cargo test --locked -p motion-render -p motion-host -p motion-desktop --lib --bin motion-studio --features motion-host/diagnostics,motion-host/ai-depth,motion-desktop/ffmpeg $Filter -- --nocapture --test-threads=1
exit $LASTEXITCODE
