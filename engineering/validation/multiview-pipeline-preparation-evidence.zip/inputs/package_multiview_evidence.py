from pathlib import Path
import hashlib,json,subprocess
from zipfile import ZipFile,ZIP_DEFLATED

BASE=Path(__file__).parent
ROOT=Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
DEST=ROOT/'engineering/validation/multiview-pipeline-preparation-evidence.zip'
assert not DEST.exists(),'Evidence archives must not be overwritten'
allowed={'.rs','.py','.ps1','.json','.jsonl','.stdout','.stderr','.log','.png','.txt','.md','.toml'}
entries={}
for top in BASE.glob('multiview-*'):
 for f in ([top] if top.is_file() else top.rglob('*')):
  if not f.is_file():continue
  rel=f.relative_to(BASE)
  if 'account' in rel.parts or 'driver-pipeline-cache-v1' in rel.parts:continue
  if f.suffix not in allowed and f.name not in ['stdout','stderr']:continue
  entries['inputs/'+rel.as_posix()]=f.read_bytes()
for pattern in ['run_multiview*.py','run_multiview*.ps1','snapshot_multiview_source.py',
                'run.py','verify_multiview_final.py','package_multiview_evidence.py',
                'final-summary.json','preparation-terminal-final-runtime-identity.json']:
 for f in BASE.glob(pattern):entries['inputs/'+f.name]=f.read_bytes()
names=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()
names+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','crates','desktop/app'],cwd=ROOT,text=True).splitlines()
for n in sorted(set(names)):
 if n.endswith('.rs'):entries['final-source/'+n]=(ROOT/n).read_bytes()
entries['final-tracked-source.diff']=subprocess.check_output(['git','diff','--','crates','desktop/app'],cwd=ROOT)
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(entries.items())}
entries['manifest.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8')
with ZipFile(DEST,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
with ZipFile(DEST) as z:
 assert z.testzip() is None
 for name,info in manifest.items():
  data=z.read(name)
  assert len(data)==info['bytes'] and hashlib.sha256(data).hexdigest()==info['sha256']
receipt={'file':str(DEST),'members':len(entries),'bytes':DEST.stat().st_size,'sha256':hashlib.sha256(DEST.read_bytes()).hexdigest(),
         'verified':'Every member byte count/SHA-256 and zip CRC; excludes executable/DLL/driver-cache/plugin binaries'}
(BASE/'multiview-evidence-archive-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
