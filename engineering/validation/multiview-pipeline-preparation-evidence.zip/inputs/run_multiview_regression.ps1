param([string]$Version='v2')
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
$env:TEMP='E:/Dev/aem/artifacts/issue-goal-current/native-pipeline-preparation/temp'
$env:TMP=$env:TEMP
$env:TMPDIR=$env:TEMP
$env:PYTHONUTF8='1'
$base='E:/Dev/aem/artifacts/issue-goal-current/native-pipeline-preparation'
$env:MOTION_VIEWER_FRAME_ARTIFACTS="$base/multiview-final-viewer-frame-evidence"
$env:MOTION_CELL_INSPECTION_ARTIFACTS="$base/multiview-final-inspection-evidence"
$env:MOTION_MULTIVIEW_WORKER_ARTIFACTS="$base/multiview-final-worker-evidence"
$env:MOTION_FRAME_COMPLETION_EVIDENCE="$base/multiview-final-frame-completion-evidence"
$env:MOTION_PREPARATION_STATUS_EVIDENCE="$base/multiview-final-status-evidence"
$env:MOTION_ORPHANED_PREPARATION_EVIDENCE="$base/multiview-final-orphan-evidence"
$env:MOTION_IDLE_PREPARATION_FAULT_EVIDENCE="$base/multiview-final-owner-fault-evidence"
$binary='E:/Dev/aem/.tools/pipeline-status-target/debug/deps/motion_studio-23fc7bd01540ff7e.exe'
foreach ($filter in @('engine::viewer_frame::native','engine::multiview_tests','engine::frame_completion::tests','engine::preparation_progress::native_tests')) {
    $phase='multiview-desktop-'+$filter.Split('::')[1]+'-'+$Version
    python "$base/run.py" $phase $binary $filter --nocapture --test-threads=1
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
