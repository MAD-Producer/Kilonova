from pathlib import Path
import hashlib,json,re,subprocess

BASE=Path(__file__).parent
ROOT=Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
phases={
 'multiview-pipeline-prepare-v3':26,
 'multiview-native-host-v2':4,
 'multiview-desktop-viewer_frame-v2':2,
 'multiview-desktop-multiview_tests-v2':1,
 'multiview-desktop-frame_completion-v2':6,
 'multiview-desktop-preparation_progress-v2':2,
 'multiview-dx12-surface-v1':1,
 'multiview-dx12-group-v1':4,
 'multiview-normal-build-v2':0,
 'multiview-normal-app-v3':0,
}
reference=None
receipts=[]
for name,count in phases.items():
 d=json.loads((BASE/(name+'.json')).read_text(encoding='utf-8'))
 assert d['exit_code']==0,(name,d.get('exit_code'))
 assert d['source_before']==d['source_after'],name
 if reference is None:reference=d['source_before']
 assert reference==d['source_before'],name
 matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
                    (BASE/(name+'.stdout')).read_text(encoding='utf-8'))
 assert sum(int(m[0]) for m in matches)==count,(name,matches)
 assert all(m[1:]==('0','0') for m in matches),(name,matches)
 receipts.append({'phase':name,'tests':count,'exit_code':0,'elapsed_seconds':d['elapsed_seconds']})
names=subprocess.check_output(['git','ls-files','desktop/app','desktop/ui','crates','Cargo.toml','Cargo.lock'],cwd=ROOT,text=True).splitlines()
names+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','desktop/app','desktop/ui','crates'],cwd=ROOT,text=True).splitlines()
current={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in sorted(set(names)) if (ROOT/n).is_file()}
assert current==reference,'Verified source differs from current worktree'
report=json.loads((BASE/'multiview-normal-app-v3-evidence/report.json').read_text(encoding='utf-8'))
assert len(report['runs'])==4
runtime=json.loads((BASE/'multiview-normal-runtime-v2/runtime-receipt.json').read_text(encoding='utf-8'))
exe=next(f['sha256'] for f in runtime['files'] if f['name']=='motion-studio.exe')
for run in report['runs']:
 assert run['binary_sha256']==exe and run['exit_code']==0
 assert run['accepted_layout']==('two' if run['pair']=='authored-two' else 'four')
 assert run['driver_load']==('missing' if run['kind']=='cold' else 'restored')
state=None
for line in (BASE/'multiview-normal-baseline-v1-evidence/authored-two/cold/stdout.jsonl').open(encoding='utf-8'):
 value=json.loads(line)
 candidate=value.get('result',{}).get('structuredContent',{})
 if 'preview' in candidate:state=candidate
assert state and state['presented']>0
prep=state['preview']['pipelinePreparation']
assert prep['preparing'] and prep['task'] is None and prep['driverCache']['load'] is None
old=json.loads((BASE/'multiview-normal-baseline-v1-evidence/authored-two/cold/partial-receipt.json').read_text(encoding='utf-8'))
old_identity=json.loads((BASE/'preparation-terminal-final-runtime-identity.json').read_text(encoding='utf-8'))
assert old['binary_sha256'] in json.dumps(old_identity),'Old executable identity missing'
surface=json.loads((BASE/'multiview-dx12-surface-v1-evidence/surface.json').read_text(encoding='utf-8'))
assert surface['backend']=='Dx12'
worker=json.loads((BASE/'multiview-final-worker-evidence/report.json').read_text(encoding='utf-8'))
assert worker['authoredStateUnchanged'] and worker['preparationPolls']>0
summary={'phases':receipts,'tests':sum(phases.values()),'ignored':0,'identical_source_files':len(reference),
 'runtime':runtime,'normal_processes':report['runs'],
 'old_baseline':{'exe_sha256':old['binary_sha256'],'presented':state['presented'],
                 'preparing':prep['preparing'],'task':prep['task'],'cache_load':prep['driverCache']['load']},
 'dx12':{'backend':surface['backend'],'adapter':surface['adapter'],'driver':surface['driver'],
          'scope':'Actual native surface and four viewer tests; surface fixture has no application cache storage'},
 'normal_cache_scope':report['scope'],'existing_assertions_preserved':True}
(BASE/'final-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'tests':summary['tests'],'source_files':len(reference),'ordinary_processes':4,'dx12':surface['backend']}))
