from pathlib import Path
p=Path('crates/motion-render/src/renderer.rs')
s=p.read_text(encoding='utf-8')
s=s.replace('image_active: std::collections::BTreeSet<u64>,','image_active: Vec<u64>,\n    image_wanted_scratch: Vec<u64>,')
s=s.replace('image_active: Default::default(),','image_active: Default::default(),\n            image_wanted_scratch: Vec::new(),')
s=s.replace('!self.image_active.contains(id)', 'self.image_active.binary_search(id).is_err()')
s=s.replace('self.image_active.contains(&id)', 'self.image_active.binary_search(&id).is_ok()')
s=s.replace('self.image_active.clear();','self.image_active = Vec::new();\n        self.image_wanted_scratch = Vec::new();')
old='''        use crate::image_resources::{decode_with_budget, scene_assets, Resolution};
        let decode_budget = self.effect_gpu.builder.decoded_image_budget;
        let wanted = scene_assets(scene);'''
new='''        let mut wanted = std::mem::take(&mut self.image_wanted_scratch);
        crate::image_resources::collect_scene_assets(scene, &mut wanted);
        let result = self.prepare_scene_assets_with_demand(scene, resolution, asynchronous, &wanted);
        // Restore storage on every Result path, including refusal and pending
        // decode. The scratch contents are never used as committed active IDs.
        self.image_wanted_scratch = wanted;
        result
    }
    fn prepare_scene_assets_with_demand(&mut self, scene: &Scene,
        resolution: crate::image_resources::Resolution, asynchronous: bool, wanted: &[u64]) -> Result<bool> {
        use crate::image_resources::{decode_with_budget, Resolution};
        let decode_budget = self.effect_gpu.builder.decoded_image_budget;'''
assert old in s
s=s.replace(old,new)
s=s.replace('for id in &wanted {','for id in wanted {')
s=s.replace('for id in wanted.difference(&self.image_active) {','for id in wanted.iter().filter(|id| self.image_active.binary_search(id).is_err()) {')
s=s.replace('self.image_active = wanted.clone();','self.image_active.clear();\n            self.image_active.extend_from_slice(wanted);')
s=s.replace('let allowed = crate::image_resources::allowed_assets(&wanted, &self.image_prefetch,','let allowed = crate::image_resources::AllowedAssets::new(wanted, &self.image_prefetch,')
s=s.replace('self.image_decode.cancel_unwanted_with_budget(&allowed, resolution, decode_budget);','self.image_decode.cancel_unwanted_matching(|id| allowed.contains(id), resolution, Some(decode_budget));')
s=s.replace('!wanted.contains(&source.id)', 'wanted.binary_search(&source.id).is_err()')
s=s.replace('for id in wanted {\n            if self.images.contains_key(&TextureKey::Static(id))','for &id in wanted {\n            if self.images.contains_key(&TextureKey::Static(id))')
p.write_text(s,encoding='utf-8')
