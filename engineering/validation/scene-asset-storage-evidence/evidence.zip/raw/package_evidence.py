import hashlib, json, re, zipfile
from pathlib import Path
ROOT=Path('E:/Dev/aem/.worktrees/layer-time-mapping')
RAW=Path('E:/Dev/aem/artifacts/issue-goal-current/scene-asset-storage')
OUT=ROOT/'engineering/validation/scene-asset-storage-evidence'
DEPS=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps')
SOURCES=['crates/motion-render/src/image_resources.rs','crates/motion-render/src/image_resources/allowed.rs','crates/motion-render/src/renderer.rs','crates/motion-render/src/renderer/image_trim_tests.rs','crates/motion-render/src/renderer/scene_asset_storage_tests.rs','crates/motion-render/src/test_allocations.rs','engineering/validation/scene-asset-storage.md']
def read(p):
    b=p.read_bytes()
    return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8-sig')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
results={}
for name,expected in [('final-scene',2),('allowed',4),('trim',3),('regression',13),('workspace',0)]:
    code=int(read(RAW/(name+'.exit')).strip())
    assert code==0,(name,code)
    counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',read(RAW/(name+'.log')))
    assert all(int(f)==0 and int(i)==0 for _,f,i in counts)
    passed=sum(int(n) for n,_,_ in counts)
    assert passed==expected,(name,passed)
    results[name]={'exit_code':code,'passed':passed,'log':name+'.log'}
assert int(read(RAW/'before.exit').strip())==101
assert 'left: 120' in read(RAW/'before.log')
assert read(RAW/'final-scene.log').count('calls=120 allocations=0')==6
binaries=['motion_render-1fcc3fb8d09fa888.exe','image_allowed_sets-63173e4cc37d1c8b.exe','image_decode_budget-3cf3064063c2f85a.exe','image_preview_cache-f37ecb360dd6074f.exe','image_working_set-1f549d0dcc754f0f.exe']
manifest={'base_commit':'aef2fd4b483d807abd5ab81dd5ade5b116e49ef0','branch':'perf/scene-asset-storage','issue':126,'issue_complete':False,'results':results,'distinct_tests':22,'baseline':{'exit':101,'allocations':120,'calls':120},'source_sha256_raw_files':{s:sha(ROOT/s) for s in SOURCES},'binary_sha256':{b:sha(DEPS/b) for b in binaries},'commands':['cargo test -p motion-render --lib scene_asset_storage --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --nocapture','cargo test -p motion-render --lib image_resources::allowed --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --nocapture','cargo test -p motion-render --lib image_trim_tests --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --nocapture','cargo test -p motion-render --test image_allowed_sets --test image_preview_cache --test image_working_set --test image_decode_budget --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture','cargo check --workspace --all-targets --exclude motion-android --locked --features motion-desktop/ffmpeg,motion-host/diagnostics --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target'],'scope':'Calling-thread allocations during resident image preparation after warmup; no whole-frame, background-allocation or FPS claim. No new production observation or fault-channel acceptance.','ci':'pending'}
OUT.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(OUT/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(RAW.iterdir()):
        if p.is_file() and p.name!='pr-body.md': z.write(p,'raw/'+p.name)
    for s in SOURCES: z.write(ROOT/s,'final-source/'+s)
manifest['evidence_zip_sha256']=sha(OUT/'evidence.zip')
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results))
