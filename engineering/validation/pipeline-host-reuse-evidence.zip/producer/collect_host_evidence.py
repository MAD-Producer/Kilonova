"""Freeze completed command evidence and exact sources without overwriting history."""
import hashlib,json,pathlib,subprocess,zipfile

root=pathlib.Path.cwd()
out=pathlib.Path(__file__).parent
dest=root/'engineering/validation/pipeline-host-reuse-evidence.zip'
assert not dest.exists(), 'immutable evidence archive already exists'
phases=['host-worker-check','host-worker-native','host-lookahead-native','host-full',
 'host-metadata-locate','host-all-lib','host-package-access-diagnostic','reuse-native',
 'reuse-native-corrected','host-surface-native','host-reuse-all-targets','reuse-native-final',
 'host-all-lib-final','preparation-default-log','preparation-sink-native']
members={}
reports=[]
for phase in phases:
    record=json.loads((out/(phase+'.json')).read_text(encoding='utf-8'))
    assert 'exit_code' in record, phase+' still running'
    reports.append({'phase':phase,'command':record['command'],'exit_code':record['exit_code'],
      'elapsed_seconds':record['elapsed_seconds'],'source_count':len(record['source_before']),
      'source_unchanged':record['source_before']==record['source_after']})
    assert reports[-1]['source_unchanged'], phase+' changed source while running'
    for suffix in ['.json','.stdout','.stderr']:
        path=out/(phase+suffix)
        members['commands/'+path.name]=path.read_bytes()
for directory in ['surface-native-evidence','default-log-sink-evidence']:
    for path in sorted((out/directory).rglob('*')):
        if path.is_file():members['native/'+str(path.relative_to(out)).replace('\\','/')]=path.read_bytes()
for name in ['run.py','collect_host_evidence.py','host-reuse-warning-scope.json']:
    members['producer/'+name]=(out/name).read_bytes()
for name in ['compile_sink_acceptance.py','sink_acceptance.rs','sink-compile-corrected.rs',
 'sink-compile.json','sink-compile.stdout','sink-compile.stderr',
 'sink-compile-corrected.json','sink-compile-corrected.stdout','sink-compile-corrected.stderr']:
    members['producer/'+name]=(out/name).read_bytes()
baseline='daf806b5f29c2ec0a70e41068445230fb7b13585'
changed=subprocess.check_output(['git','diff','--name-only',baseline,'--','crates','desktop/app/src/logging.rs'],text=True).splitlines()
changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','crates','desktop/app/src/logging'],text=True).splitlines()
for name in sorted(set(changed)):
    path=root/name
    if path.is_file():members['source/current/'+name]=path.read_bytes()
    before=subprocess.run(['git','show',baseline+':'+name],capture_output=True)
    if before.returncode==0:members['source/baseline/'+name]=before.stdout
exe_records={}
for exe in ['motion_render-4e278093648f3252.exe','motion_host-9819308cd86120da.exe']:
    path=pathlib.Path(r'E:\Dev\aem\.tools\viewer-inspection\native-target\debug\deps')/exe
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
    exe_records[exe]={'sha256':h.hexdigest(),'bytes':path.stat().st_size}
summary={'baseline':baseline,'head_before_evidence_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'reports':reports,'native_executables':exe_records,
 'limits':['library tests are not full integration suites','SceneCount default-sink test is not native-invalid-WGSL qualification',
   'sink harness substitutes idle engine panic context; no panic qualification',
   'desktop test build E0786 / os error 1455 and two host allocation failures remain non-green',
   'initial E0463 and PermissionDenied causes remain unconfirmed','no independent-process cold/warm speed claim']}
members['summary.json']=json.dumps(summary,ensure_ascii=False,indent=2).encode('utf-8')
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(members.items())}
members['manifest.json']=json.dumps(manifest,indent=2).encode('utf-8')
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(members.items()):archive.writestr(name,data)
with zipfile.ZipFile(dest) as archive:
    assert archive.testzip() is None
    for name,entry in manifest.items():assert hashlib.sha256(archive.read(name)).hexdigest()==entry['sha256']
receipt={'path':str(dest),'members':len(members),'bytes':dest.stat().st_size,
 'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'reports':reports}
(out/'host-evidence-receipt.json').write_bytes(json.dumps(receipt,ensure_ascii=False,indent=2).encode('utf-8'))
print(json.dumps({key:receipt[key] for key in ['path','members','bytes','sha256']},ensure_ascii=False))
