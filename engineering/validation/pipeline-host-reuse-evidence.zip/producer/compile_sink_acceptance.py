"""Bounded native evidence, not full desktop test qualification.

Uses the unchanged production logger and the unchanged new assertion body.
Only the idle engine panic-context accessor is substituted; no panic is injected
or claimed by this harness. Job execution, GPU rendering and sinks are real.
"""
import pathlib,re,subprocess,json,hashlib,os,time,sys
root=pathlib.Path.cwd(); out=pathlib.Path(__file__).parent
source=root/'desktop/app/src/logging/pipeline_preparation_tests.rs'
logger=root/'desktop/app/src/logging.rs'
phase=sys.argv[1] if len(sys.argv)>1 else 'sink-compile'
body=source.read_text(encoding='utf-8').replace('use super::*;','').replace('#[test]\n','').replace('//!','//')
harness=out/(phase+'.rs')
harness.write_bytes(('''// Production sink, idle context only; does not qualify panic hooks.
#[path = "'''+str(logger).replace('\\','/')+'''"] mod logging;
mod engine {
 pub(crate) fn current_command() -> Option<(u64,&'static str,std::time::Duration)> { None }
}
use logging::{init,flush};
use std::{fs,fs::File,path::PathBuf,time::Duration};
'''+body+'''
fn main() { preparation_start_precedes_blocking_and_failure_reaches_default_sinks(); }
''').encode('utf-8'))
failed=(out/'preparation-default-log.stderr').read_text(encoding='utf-8',errors='replace')
externs=dict(re.findall(r'--extern (\w+)=([^\s`]+)',failed))
names=['log','motion_core','motion_render','pollster','tempfile']
exe=out/'sink-acceptance.exe'
cmd=['rustc','--crate-name','pipeline_sink_acceptance','--edition=2021',str(harness),
 '-C','debuginfo=0','-L','dependency=E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps','-o',str(exe)]
for name in names:cmd+=['--extern',name+'='+externs[name]]
for path in re.findall(r'-L native=([^\s`]+)',failed):cmd+=['-L','native='+path]
files=[source,logger,harness]+[pathlib.Path(externs[name]) for name in names]
def hashes():
    result={}
    for path in files:
        h=hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
        result[str(path)]=h.hexdigest()
    return result
meta={'command':cmd,'scope':__doc__,'before':hashes()}
began=time.monotonic()
with (out/(phase+'.stdout')).open('wb') as stdout,(out/(phase+'.stderr')).open('wb') as stderr:
    result=subprocess.run(cmd,stdout=stdout,stderr=stderr)
meta.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-began,after=hashes())
if exe.exists():meta['executable_sha256']=hashlib.sha256(exe.read_bytes()).hexdigest()
(out/(phase+'.json')).write_bytes(json.dumps(meta,indent=2).encode('utf-8'))
print(json.dumps({k:meta[k] for k in ['exit_code','elapsed_seconds','scope']}))
raise SystemExit(result.returncode)
