import hashlib, json, os, subprocess
from pathlib import Path
p = Path(__file__).parent
rows = [json.loads(l) for l in (p / 'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
assert rows[-1] == dict(reason='build-finished', success=True)
exe = [r['executable'] for r in rows if r.get('reason') == 'compiler-artifact' and r['target']['name'] == 'motion-studio' and r.get('executable')][-1]
env = os.environ.copy()
env.pop('RUST_MIN_STACK', None)
env['MOTION_LOG'] = 'info'
env['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + env['PATH']
records = []
for module, test, key, directory, name, count in [
    ('restore_geometry', 'record_complete_restoration_frames_for_original_path_comparison', 'MOTION_NODE_RESTORE_EVIDENCE', 'node-restore-geometry', 'restore', 320),
    ('viewport_geometry', 'record_complete_navigation_and_release_paint_for_original_path_comparison', 'MOTION_NODE_VIEWPORT_EVIDENCE', 'node-viewport-geometry', 'viewport', 312),
    ('input_geometry', 'record_complete_outside_canvas_edits_for_original_path_comparison', 'MOTION_NODE_INPUT_EVIDENCE', 'node-input-geometry', 'input', 64),
    ('collapse_geometry', 'record_complete_collapse_frames_for_original_path_comparison', 'MOTION_NODE_COLLAPSE_EVIDENCE', 'node-collapse-geometry', 'collapse', 216),
    ('inline_geometry', 'record_complete_inline_transactions_for_original_path_comparison', 'MOTION_NODE_INLINE_EVIDENCE', 'node-frame-input', 'inline', 744),
    ('canvas_geometry', 'record_complete_canvas_transactions_for_original_path_comparison', 'MOTION_NODE_CANVAS_EVIDENCE', 'node-canvas-geometry', 'canvas', 448),
]:
    local = env.copy()
    final = p / (name + '-final-paint.json')
    local[key] = str(final)
    command = [exe, '--exact', f'node_editor::view::frame_cards_tests::{module}::{test}', '--test-threads=1', '--nocapture']
    result = subprocess.run(command, env=local, capture_output=True)
    (p / (name + '-final.stdout')).write_bytes(result.stdout)
    (p / (name + '-final.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0
    original = p.parent / directory / 'before-paint.json'
    assert json.loads(original.read_text('utf-8')) == json.loads(final.read_text('utf-8'))
    values = json.loads(final.read_text('utf-8'))
    assert sum(len(frames) if isinstance(frames, list) else 1 for frames in values.values()) == count
    row = dict(command=command, exit=result.returncode, frames=count, exact_equal=True, original=str(original),
        original_sha256=hashlib.sha256(original.read_bytes()).hexdigest(), final_sha256=hashlib.sha256(final.read_bytes()).hexdigest())
    records.append(row)
    print(json.dumps(dict(name=name, frames=count, exact_equal=True)), flush=True)
field = json.loads((p / 'comparison.json').read_text('utf-8'))
assert field['frames'] == 816 and field['exact_equal'] and not field['normalization']
comparison = dict(executable_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest(), prior_records=records,
    field_frames=816, total_complete_frames=816 + sum(r['frames'] for r in records), exact_equal=True, normalization=False)
assert comparison['total_complete_frames'] == 2920
(p / 'final-comparison.json').write_text(json.dumps(comparison, indent=2), 'utf-8')
print(json.dumps(dict(total_complete_frames=2920, exact_equal=True)), flush=True)
