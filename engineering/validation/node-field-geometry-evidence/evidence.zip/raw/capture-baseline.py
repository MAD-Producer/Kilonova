import hashlib,json,subprocess
from pathlib import Path
p=Path(__file__).parent;root=Path.cwd();base='88d9d4c8'
assert subprocess.check_output(['git','rev-parse','HEAD']).decode().startswith(base)
paths=['desktop/app/src/node_editor/view/'+name for name in ['mod.rs','interaction.rs','canvas.rs','frame_cards_tests.rs','frame_cards_tests/field_geometry.rs']]
hashes={}
for path in paths:
    data=(root/path).read_bytes()
    if path in paths[:3]:assert data==subprocess.check_output(['git','show',base+':'+path])
    dest=p/'before-source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    hashes[path]=hashlib.sha256(data).hexdigest()
(p/'before-source.json').write_text(json.dumps(hashes,indent=2),'utf-8')
for name in ['app-build.jsonl','app-build.stderr']:(p/name.replace('app-','before-')).write_bytes((p/name).read_bytes())
print(json.dumps(hashes),flush=True)
