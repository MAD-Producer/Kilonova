from pathlib import Path
import json

raw = Path(__file__).parent
previous = raw.parent / 'node-restore-geometry'
for name in ['run-regressions.py', 'run-workspace.py', 'check-startup.py']:
    (raw / name).write_bytes((previous / name).read_bytes())
text = (previous / 'build-production.ps1').read_text('utf-8')
(raw / 'build-production.ps1').write_text(text.replace('node-restore-geometry', 'node-field-geometry'), 'utf-8')
text = (previous / 'run-prior-records.py').read_text('utf-8')
text = text.replace("    ('viewport_geometry'", "    ('restore_geometry', 'record_complete_restoration_frames_for_original_path_comparison', 'MOTION_NODE_RESTORE_EVIDENCE', 'node-restore-geometry', 'restore', 320),\n    ('viewport_geometry'", 1)
text = text[:text.index('restoration = json.loads')]
text += """field = json.loads((p / 'comparison.json').read_text('utf-8'))
assert field['frames'] == 816 and field['exact_equal'] and not field['normalization']
comparison = dict(executable_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest(), prior_records=records,
    field_frames=816, total_complete_frames=816 + sum(r['frames'] for r in records), exact_equal=True, normalization=False)
assert comparison['total_complete_frames'] == 2920
(p / 'final-comparison.json').write_text(json.dumps(comparison, indent=2), 'utf-8')
print(json.dumps(dict(total_complete_frames=2920, exact_equal=True)), flush=True)
"""
(raw / 'run-prior-records.py').write_text(text, 'utf-8')

root = Path.cwd()
paths = json.loads((raw / 'before-source.json').read_text('utf-8'))
import hashlib
hashes = {}
for path in paths:
    data = (root / path).read_bytes()
    dest = raw / 'final-source' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    hashes[path] = hashlib.sha256(data).hexdigest()
(raw / 'final-source.json').write_text(json.dumps(hashes, indent=2), 'utf-8')
