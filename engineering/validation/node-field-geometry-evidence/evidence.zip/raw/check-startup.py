import hashlib,json,os,subprocess
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(l) for l in (p/'production-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
assert any(r.get('reason')=='build-finished' and r['success'] for r in rows)
exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
local=p/'startup-appdata';local.mkdir(exist_ok=True);env['LOCALAPPDATA']=str(local)
command=[exe,'--command-list'];r=subprocess.run(command,env=env,capture_output=True)
(p/'startup.stdout').write_bytes(r.stdout);(p/'startup.stderr').write_bytes(r.stderr)
result=dict(command=command,exit=r.returncode,executable_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest(),controlled_local_appdata=str(local),rust_min_stack_overridden=False)
(p/'startup.json').write_text(json.dumps(result,indent=2),'utf-8')
assert r.returncode==0
assert isinstance(json.loads(r.stdout),dict)
assert not r.stderr
print(json.dumps(result),flush=True)


