import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

out = Path(__file__).parent
def run(phase, command):
    code = subprocess.run([sys.executable, str(out / 'run.py'), phase, *command]).returncode
    if code:
        raise SystemExit(code)
    meta = json.loads((out / (phase + '.json')).read_text(encoding='utf-8'))
    assert meta['source_before'] == meta['source_after'], phase
    return meta

compile_meta = run('stable-native-compile', ['cargo', 'test', '--locked', '-p', 'motion-desktop',
    '--features', 'ffmpeg', '--bin', 'motion-studio', '--no-run', '--message-format=json'])
programs = []
for line in (out / 'stable-native-compile.stdout').read_text(encoding='utf-8').splitlines():
    event = json.loads(line)
    if event.get('reason') == 'compiler-artifact' and event.get('target', {}).get('name') == 'motion-studio' and event.get('executable'):
        programs.append(event['executable'])
assert len(programs) == 1
program = Path(programs[0])
identity = hashlib.file_digest(program.open('rb'), 'sha256').hexdigest()
(out / 'verified-executable.json').write_text(json.dumps({'path':str(program),'sha256':identity,
    'compile_source':compile_meta['source_after']},indent=2),encoding='utf-8')
os.environ.pop('MOTION_LOG', None)
for phase, selection, exact in [
    ('actual-native-worker', 'engine::viewer_capture_error_tests::native_viewer_capture_and_save_failures_keep_types_default_sinks_and_recover', True),
    ('existing-capture-context', 'engine::capture_context_tests::', False),
    ('existing-precision-capture', 'engine::precision_capture_tests::', False),
    ('existing-cell-inspection', 'engine::viewer_frame::native::inspection::', False),
]:
    args = [str(program)] + (['--exact'] if exact else []) + [selection, '--test-threads=1', '--nocapture']
    meta = run(phase, args)
    assert meta['source_before'] == compile_meta['source_before']
    stdout = (out / (phase + '.stdout')).read_text(encoding='utf-8')
    assert '1 passed; 0 failed; 0 ignored' in stdout, phase
    assert hashlib.file_digest(program.open('rb'), 'sha256').hexdigest() == identity
print('Actual native faults, channel assertions and three existing capture regressions passed.')
