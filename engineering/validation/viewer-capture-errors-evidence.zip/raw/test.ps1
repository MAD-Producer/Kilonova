. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:CARGO_TARGET_DIR='E:/Dev/aem/.tools/viewer-inspection/native-target'
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:LIBCLANG_PATH='E:/Dev/aem/.tools/python-libclang/clang/native'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
$env:MOTION_VIEWER_CAPTURE_ERROR_ARTIFACTS='E:/Dev/aem/artifacts/issue-goal-current/viewer-capture-errors/native-child'
$env:MOTION_CAPTURE_CONTEXT_ARTIFACTS='E:/Dev/aem/artifacts/issue-goal-current/viewer-capture-errors/existing-capture-context'
python E:/Dev/aem/artifacts/issue-goal-current/viewer-capture-errors/run.py @args
exit $LASTEXITCODE
