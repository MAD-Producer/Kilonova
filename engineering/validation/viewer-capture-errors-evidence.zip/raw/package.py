import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root = Path.cwd()
out = Path(__file__).parent
phases = ['native-compile', 'stable-native-compile', 'actual-native-worker',
          'existing-capture-context', 'existing-precision-capture',
          'existing-cell-inspection', 'stable-native-verification-wrapper']
members = {}
stable = json.loads((out / 'stable-native-compile.json').read_text(encoding='utf-8'))
assert stable['exit_code'] == 0
assert stable['source_before'] == stable['source_after']
for phase in phases:
    meta = json.loads((out / (phase + '.json')).read_text(encoding='utf-8'))
    assert meta['exit_code'] == 0
    if phase != 'native-compile':
        assert meta['source_before'] == meta['source_after'] == stable['source_after']
    for extension in ['json', 'stdout', 'stderr']:
        name = phase + '.' + extension
        members['raw/' + name] = (out / name).read_bytes()
for name, digest in stable['source_after'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
for phase in phases[2:6]:
    assert '1 passed; 0 failed; 0 ignored' in members['raw/' + phase + '.stdout'].decode('utf-8')
for directory in ['native-child', 'existing-capture-context']:
    files = sorted((out / directory).rglob('*'))
    assert files, directory
    for path in files:
        if path.is_file():
            members['raw/' + path.relative_to(out).as_posix()] = path.read_bytes()
for name in ['package.py', 'verify.py', 'run.py', 'test.ps1',
             'verified-executable.json', 'initial-build-disposition.md']:
    members['raw/' + name] = (out / name).read_bytes()
paths = ['desktop/app/src/engine.rs',
         'desktop/app/src/engine/viewer_inspection.rs',
         'desktop/app/src/engine/viewer_capture_error_tests.rs']
for name in paths:
    members['source/current/' + name] = (root / name).read_bytes()
members['change.patch'] = subprocess.check_output(['git', 'diff', '--', *paths], cwd=root)
members['scope.json'] = json.dumps({
    'base': stable['head'],
    'issue': 138,
    'actual_faults': ['capture budget rejection', 'save target budget rejection',
                      'PNG destination is an existing directory'],
    'regressions': phases[3:6],
    'default_channels': 'Info start precedes each Error; file and stderr retain causes; stdout has none',
    'recovery': 'Exact PNG pixels, project and revision; retained snapshot and generation verified',
    'limits': ['First compile source changed only in the new test fixture and is not frozen acceptance',
               'Individual Presenter/encode/readback phases were not all fault injected',
               'Remote CI and remaining text-only providers are outside this local evidence'],
}, ensure_ascii=False, indent=2).encode('utf-8')
members['manifest.json'] = json.dumps({name: {
    'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)
} for name, data in sorted(members.items())}, indent=2).encode('utf-8')
archive = root / 'engineering/validation/viewer-capture-errors-evidence.zip'
assert not archive.exists(), 'Published evidence remains immutable'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in members.items():
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.namelist() == list(members)
    for name, data in members.items():
        assert z.read(name) == data, name
receipt = {'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'bytes': archive.stat().st_size, 'members': len(members)}
(out / 'package-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt))
