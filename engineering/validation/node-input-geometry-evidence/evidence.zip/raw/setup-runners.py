from pathlib import Path
p=Path(__file__).parent;previous=Path('E:/Dev/aem/artifacts/issue-goal-current/dock-solve-reuse')
for name in ['build-app.ps1','build-production.ps1','run-regressions.py','run-workspace.py','check-startup.py','merge602.py']:
 s=(previous/name).read_text('utf-8').replace('issue-goal-current/dock-solve-reuse','issue-goal-current/node-input-geometry')
 (p/name).write_text(s,'utf-8')
