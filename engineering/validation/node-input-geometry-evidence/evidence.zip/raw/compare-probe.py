import hashlib,json
from pathlib import Path
p=Path(__file__).parent
before=json.loads((p/'before-paint.json').read_text('utf-8'))
after=json.loads((p/'after-paint.json').read_text('utf-8'))
assert len(before)==16 and before.keys()==after.keys()
assert all(len(v)==4 for v in before.values())
assert before==after,'complete paint, response, state and history changed'
receipt=dict(configurations=16,frames=64,exact_equal=True,normalization=False,
    before_sha256=hashlib.sha256((p/'before-paint.json').read_bytes()).hexdigest(),
    after_sha256=hashlib.sha256((p/'after-paint.json').read_bytes()).hexdigest())
(p/'comparison.json').write_text(json.dumps(receipt,indent=2),'utf-8')
print(json.dumps(receipt))
