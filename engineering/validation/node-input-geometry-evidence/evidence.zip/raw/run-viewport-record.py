import hashlib,json,os,subprocess
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(l) for l in (p/'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
assert rows[-1]==dict(reason='build-finished',success=True)
exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info'
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
env['MOTION_NODE_VIEWPORT_EVIDENCE']=str(p/'viewport-final-paint.json')
command=[exe,'--exact','node_editor::view::frame_cards_tests::viewport_geometry::record_complete_navigation_and_release_paint_for_original_path_comparison','--test-threads=1','--nocapture']
r=subprocess.run(command,env=env,capture_output=True)
(p/'viewport-final.stdout').write_bytes(r.stdout);(p/'viewport-final.stderr').write_bytes(r.stderr)
assert r.returncode==0
baseline=Path('E:/Dev/aem/artifacts/issue-goal-current/node-viewport-geometry/before-paint.json')
assert json.loads(baseline.read_text('utf-8'))==json.loads((p/'viewport-final-paint.json').read_text('utf-8'))
assert json.loads((p/'before-paint.json').read_text('utf-8'))==json.loads((p/'final-paint.json').read_text('utf-8'))
receipt=dict(command=command,exit=r.returncode,executable_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest(),
    viewport_frames=312,viewport_equal=True,input_frames=64,input_equal=True,normalization=False)
(p/'final-comparison.json').write_text(json.dumps(receipt,indent=2),'utf-8')
print(json.dumps(receipt))
