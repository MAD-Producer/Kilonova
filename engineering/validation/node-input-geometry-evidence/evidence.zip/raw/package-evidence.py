import hashlib,json,re,subprocess,zipfile
from pathlib import Path
raw=Path(__file__).parent;root=Path.cwd();base='c4b0d23e342ef50274ba5718954d696bc8fba92a'
out=root/'engineering/validation/node-input-geometry-evidence';out.mkdir(exist_ok=True)
def digest(data):return hashlib.sha256(data).hexdigest()
def git(*args,input=None):return subprocess.check_output(['git',*args],input=input)
paths=['desktop/app/src/node_editor/view/mod.rs','desktop/app/src/node_editor/view/controls.rs',
    'desktop/app/src/node_editor/view/frame_cards_tests.rs','desktop/app/src/node_editor/view/frame_cards_tests/input_geometry.rs']
sources={path:(root/path).read_bytes() for path in paths}
assert json.loads((raw/'before-paint.json').read_text('utf-8'))==json.loads((raw/'final-paint.json').read_text('utf-8'))
viewport=Path('E:/Dev/aem/artifacts/issue-goal-current/node-viewport-geometry/before-paint.json')
assert json.loads(viewport.read_text('utf-8'))==json.loads((raw/'viewport-final-paint.json').read_text('utf-8'))
counts=[]
for i in range(4):
    text=(raw/f'regression-{i}.stdout').read_text('utf-8');m=re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',text)
    assert m;counts.append(int(m[1]))
assert counts==[188,4,13,7]
assert '187 passed; 1 failed;' in (raw/'old-parent-count.stdout').read_text('utf-8')
before=json.loads((raw/'before-tests.json').read_text('utf-8'));assert [r['exit'] for r in before]==[101,0]
final=json.loads((raw/'final-tests.json').read_text('utf-8'));assert [r['exit'] for r in final]==[0,0]
for path in ['costs.json','layouts.json']:assert len(json.loads((raw/path).read_text('utf-8')))==48
startup=json.loads((raw/'startup.json').read_text('utf-8'));assert startup['exit']==0 and not (raw/'startup.stderr').read_bytes()
for file in ['before-build.jsonl','first-after-build.jsonl','app-build.jsonl','production-build.jsonl']:
    rows=[json.loads(l) for l in (raw/file).read_text('utf-8-sig').splitlines() if l.startswith('{')]
    assert rows[-1]==dict(reason='build-finished',success=True)
summary=dict(base=base,tests_passed=214,test_counts=counts+[2],input_configurations=16,input_frames=64,
    viewport_frames=312,complete_frames_equal=376,normalization=False,negative_control_exits=[101,0],
    production_executable_sha256=startup['executable_sha256'],
    source_sha256={path:digest(data) for path,data in sources.items()},
    source_git_blobs={path:git('hash-object','--path='+path,'--stdin',input=data).decode().strip() for path,data in sources.items()})
(raw/'summary.json').write_text(json.dumps(summary,indent=2),'utf-8')
records=[]
for file in sorted(raw.iterdir()):
    if not file.is_file() or file.suffix not in ['.json','.jsonl','.stdout','.stderr','.ps1','.py']:continue
    if file.name.startswith(('github_api','merge602','publish','fix-macos','ci-','pr602','analyze-ci','finalize-pr')):continue
    records.append(('raw/'+file.name,file.read_bytes()))
for path,data in sources.items():records.append(('final-source/'+path,data))
for path in paths[:3]:records.append(('baseline-source/'+path,git('show',base+':'+path)))
records.append(('baseline/viewport-before-paint.json',viewport.read_bytes()))
records.append(('README.txt',b'Baseline production source is PR #603 head c4b0d23e; the same new input test fixture runs before and after. All 16 outside-canvas edits build two cards before and one after. All 64 complete frames match exactly, including full paint/response/EditorSnapshot and both undo/redo lengths. Existing parent navigation >=2 expectation fails after the functional optimization; functional and geometry assertions remain, with count strengthened to ==1. A fixture-only first compile omitted library_open=true and was never used for baseline execution. Final viewport recorder matches all 312 original pre-viewport-optimization frames. Final desktop suite passes 214 distinct tests; no native/GPU Present, whole-frame peak-memory or universal one-solve-per-frame claim. Source hashes identify compiler input bytes; Git blob hashes identify repository-normalized files.\n'))
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,data in records:z.writestr(path,data)
manifest=dict(**summary,archive_sha256=digest(archive.read_bytes()),records=[dict(path=name,bytes=len(data),sha256=digest(data)) for name,data in records])
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n','utf-8')
with zipfile.ZipFile(archive) as z:
    for row in manifest['records']:assert digest(z.read(row['path']))==row['sha256']
print(json.dumps(dict(tests=214,frames=376,records=len(records),bytes=archive.stat().st_size,sha256=manifest['archive_sha256'])))
