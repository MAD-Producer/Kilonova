from pathlib import Path
import json,subprocess,os,time,re
base=Path('E:/Dev/aem/artifacts/issue-goal-current');root=base/'time-mini-final-validation'
results=json.loads((root/'results.json').read_text());assert not any(r['scope']=='property_focus_consumers' for r in results)
env=os.environ.copy();env.pop('MOTION_LOG',None);env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
scope='property_focus_consumers';command=[str(root/'motion-studio-tested.exe'),'property_focus','--test-threads=1'];began=time.monotonic()
with (root/(scope+'-stdout.log')).open('wb') as stdout,(root/(scope+'-stderr.log')).open('wb') as stderr:
    completed=subprocess.run(command,cwd='E:/Dev/aem/.worktrees/layer-time-mapping',env=env,stdout=stdout,stderr=stderr,timeout=240)
output=(root/(scope+'-stdout.log')).read_text(encoding='utf-8')
result={'scope':scope,'command':command,'code':completed.returncode,'seconds':round(time.monotonic()-began,3),
    'passed':re.findall(r'^test (.+) \.\.\. ok$',output,re.M),'ignored':re.findall(r'^test (.+) \.\.\. ignored(?:,.*)?$',output,re.M)}
results.append(result);(root/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(result))
assert completed.returncode==0 and result['passed']
