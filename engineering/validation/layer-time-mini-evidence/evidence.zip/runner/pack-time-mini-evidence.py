from pathlib import Path
import json,hashlib,subprocess,zipfile
from PIL import Image,ImageChops
repo=Path('E:/Dev/aem/.worktrees/layer-time-mapping');base=Path('E:/Dev/aem/artifacts/issue-goal-current');root=base/'time-mini-final-validation'
out=repo/'engineering/validation/layer-time-mini-evidence';out.mkdir(exist_ok=True)
inputs=json.loads((base/'time-mini-final-inputs.json').read_text(encoding='utf-8'))
for name,digest in inputs['sources'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
results=json.loads((root/'results.json').read_text(encoding='utf-8'));assert len(results)==8 and all(r['code']==0 for r in results)
assert 'Finished `dev` profile' in (base/'time-mini-workspace-check.log').read_text(encoding='utf-8')
passed=set();ignored=set()
for result in results:passed.update(result['passed']);ignored.update(result['ignored'])
ignored-=passed
images=sorted((root/'native').rglob('*.png'));assert len(images)==8
native={p.relative_to(root/'native').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in images}
presentation={}
for tag,box in [('zh-main-forward',(0,80,1000,550)),('en-floating-reverse',(0,0,1000,480))]:
    raw=root/'native'/tag/'hover.png';target=out/(tag+'.png');original=Image.open(raw);original.crop(box).save(target)
    assert ImageChops.difference(Image.open(target),original.crop(box)).getbbox() is None
    presentation[target.name]={'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'source':tag+'/hover.png','crop':box}
subprocess.run(['git','add','--',*inputs['sources']],cwd=repo,check=True)
patch=subprocess.check_output(['git','diff','--cached','--binary','--',*inputs['sources']],cwd=repo);(root/'source.patch').write_bytes(patch)
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.suffix.lower() in ['.json','.png','.log','.patch']:z.write(p,'final/'+p.relative_to(root).as_posix())
    for p in sorted(base.glob('time-mini-*')):
        if p.is_file() and p.suffix.lower() in ['.json','.log','.txt']:z.write(p,'attempts/'+p.name)
    for name in ['run-time-mini-final.py','finish-time-mini-focus.py','pack-time-mini-evidence.py']:z.write(base/name,'runner/'+name)
capture=json.loads((root/'native/capture-process.json').read_text());reopen=json.loads((root/'native/reopen-process.json').read_text());assert capture['pid']!=reopen['pid']
manifest={'baseCommit':inputs['base'],'branch':'feat/layer-time-mapping','sources':inputs['sources'],
    'sourcePatchSha256':hashlib.sha256(patch).hexdigest(),'testBinary':json.loads((root/'test-binary.json').read_text()),
    'tests':{'uniquePassed':len(passed),'notRunManual':len(ignored)},'passed':sorted(passed),'notRunManual':sorted(ignored),
    'nativeImages':native,'presentationImages':presentation,'separateProcesses':{'capture':capture,'reopen':reopen},
    'archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},
    'limits':['Windows pixel ratio 1; actual main/floating chrome inputs and GPU/worker, not OS mouse injection.',
        'Retains existing warnings, layout and style violations; no claim that issue 257 is complete.',
        'Default fault injection covers controls clock/keys and mini readout clock; other new observation sites not individually injected.',
        'Legacy curve clipboard still requires an exact whole composition projection; local curve clipboard is pending.']}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'tests':manifest['tests'],'binary':manifest['testBinary'],'archive':manifest['archive']},ensure_ascii=False))
