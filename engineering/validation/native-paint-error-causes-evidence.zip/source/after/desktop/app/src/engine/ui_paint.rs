//! Preserve a failed chrome upload across the host's infallible overlay callback.
pub(super) mod allocation;
#[cfg(test)]
mod admission_tests;
#[cfg(all(test, target_os = "windows"))]
mod native_error_tests;

/// UI and node-preview screenshots capture display pixels independently of
/// the project's native working attachment. The shader sees linear premultiplied
/// values; the sRGB attachment encodes them once for PNG readback.
pub(super) fn display_capture_target(
    renderer: &motion_render::Renderer,
    width: u32,
    height: u32,
) -> Result<motion_render::ImageCaptureTarget, motion_render::RenderError> {
    use motion_effects::{AlphaMode, WorkingSpace, image_contract::{ChannelPrecision, ImageContract, ImageMeaning}};
    renderer.image_capture_target(width, height, ImageContract::new(
        ImageMeaning::Color { space: WorkingSpace::Linear, alpha: AlphaMode::Premultiplied },
        ChannelPrecision::Unorm8,
    ))
}

pub(super) fn finish(
    result: motion_host::Result<bool>,
    paint_error: Option<motion_ui::paint::PaintError>,
    window: u64,
) -> motion_host::Result<bool> {
    match (result, paint_error) {
        (result, None) => result,
        (Ok(_), Some(cause)) => Err(error(format!("present window={window}"), cause)),
        (Err(primary), Some(secondary)) => Err(motion_host::Error::Related {
            context: format!("UI overlay window={window}"),
            primary: Box::new(primary),
            secondary: Box::new(motion_host::Error::from_source(secondary)),
        }),
    }
}

pub(super) fn error(context: impl Into<String>, cause: motion_ui::paint::PaintError) -> motion_host::Error {
    motion_host::Error::with_context(context, motion_host::Error::from_source(cause))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::engine::{respond, Flight, CURRENT_COMMAND};
    use motion_ui::{paint, Color, Painter, Rect};

    #[test]
    #[cfg_attr(not(feature = "gpu-tests"), ignore = "requires an actual GPU")]
    fn real_paint_limit_failure_reaches_reply_file_and_stderr_at_default_level() {
        const CHILD: &str = "MOTION_UI_BUFFER_LIMIT_CHILD";
        const TEST: &str = "engine::ui_paint::tests::real_paint_limit_failure_reaches_reply_file_and_stderr_at_default_level";
        if let Some(root) = std::env::var_os(CHILD) {
            let _logger = crate::logging::init(root.into()).unwrap();
            let instance =
                wgpu::Instance::new(wgpu::InstanceDescriptor::new_without_display_handle());
            let adapter =
                pollster::block_on(instance.request_adapter(&Default::default())).unwrap();
            let mut descriptor = wgpu::DeviceDescriptor::default();
            descriptor.required_limits.max_buffer_size = 5_767_168;
            let (device, queue) = pollster::block_on(adapter.request_device(&descriptor)).unwrap();
            let mut painter = Painter::new(&device, wgpu::TextureFormat::Rgba8Unorm);
            let texture = device.create_texture(&wgpu::TextureDescriptor {
                label: None,
                size: wgpu::Extent3d {
                    width: 8,
                    height: 8,
                    depth_or_array_layers: 1,
                },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: wgpu::TextureFormat::Rgba8Unorm,
                usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
                view_formats: &[],
            });
            let view = texture.create_view(&Default::default());
            let mut list = paint::PaintList::default();
            for _ in 0..11_092 {
                paint::rect(&mut list, Rect::new(0., 0., 8., 8.), Color([1.; 4]));
            }
            let scope = device.push_error_scope(wgpu::ErrorFilter::Validation);
            let mut encoder = device.create_command_encoder(&Default::default());
            let error = painter
                .render(&device, &queue, &mut encoder, &view, &list, [8.; 2])
                .unwrap_err();
            assert_eq!(error.required_bytes, 5_856_576);
            assert!(pollster::block_on(scope.pop()).is_none());
            assert_eq!(finish(Ok(false), None, 7).map_err(String::from), Ok(false));
            assert_eq!(finish(Ok(true), None, 7).map_err(String::from), Ok(true));
            assert_eq!(
                finish(Err("primary".into()), None, 7).map_err(String::from),
                Err("primary".into())
            );
            // The host overlay callback returns (), so preserve its actual error
            // after either a successful or degraded host presentation.
            for (request, host_result) in [
                (901, Ok(true)),
                (902, Ok(false)),
                (903, Err("original surface failure".into())),
            ] {
                let result = finish(host_result, Some(error.clone()), 7);
                let original = result.as_ref().unwrap_err().to_string();
                if request == 903 {
                    assert!(original.starts_with("original surface failure; UI overlay"));
                }
                let (reply, receive) = std::sync::mpsc::channel();
                CURRENT_COMMAND.set(Some(Flight {
                    request,
                    operation: "present",
                    started: std::time::Instant::now(),
                }));
                respond(reply, result.map_err(motion_host::Error::from));
                CURRENT_COMMAND.set(None);
                assert_eq!(receive.recv().unwrap().map_err(String::from), Err(original));
            }
            return;
        }
        let root = tempfile::tempdir().unwrap();
        let output = std::process::Command::new(std::env::current_exe().unwrap())
            .args(["--exact", TEST, "--nocapture"])
            .env(CHILD, root.path())
            .env_remove("MOTION_LOG")
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}\n{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        let file = std::fs::read_to_string(root.path().join("motion-studio.log")).unwrap();
        let stderr = String::from_utf8(output.stderr).unwrap();
        let stdout = String::from_utf8(output.stdout).unwrap();
        assert!(file.contains("logging initialized level=INFO"));
        for marker in [
            "kind=solid",
            "vertices=66552",
            "required_bytes=5856576",
            "limit_bytes=5767168",
            "window=7",
            "original surface failure",
        ] {
            assert!(file.contains(marker), "file missing {marker}");
            assert!(stderr.contains(marker), "stderr missing {marker}");
            assert!(!stdout.contains(marker), "stdout leaked {marker}");
        }
        for request in [901, 902, 903] {
            let marker = format!("error #{request} present ");
            assert_eq!(file.matches(&marker).count(), 1);
            assert_eq!(stderr.matches(&marker).count(), 1);
        }
    }
}
