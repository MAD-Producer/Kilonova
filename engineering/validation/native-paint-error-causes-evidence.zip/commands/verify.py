import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

out = Path(__file__).parent
root = Path.cwd()
compiled = json.loads((out / 'native-paint-compile.json').read_text(encoding='utf-8'))
assert compiled['exit_code'] == 0
assert compiled['source_before'] == compiled['source_after']
for name, sha in compiled['source_after'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha, name
programs = []
for line in (out / 'native-paint-compile.stdout').read_text(encoding='utf-8').splitlines():
    event = json.loads(line)
    if event.get('reason') == 'compiler-artifact' and event.get('target', {}).get('name') == 'motion-studio' and event.get('executable'):
        programs.append(event['executable'])
assert len(programs) == 1
program = Path(programs[0])
digest = hashlib.file_digest(program.open('rb'), 'sha256').hexdigest()
(out / 'verified-executable.json').write_text(json.dumps({'path': str(program),
    'sha256': digest, 'source': compiled['source_after']}, indent=2), encoding='utf-8')
os.environ.pop('MOTION_LOG', None)
os.environ['MOTION_VIEWER_CAPTURE_ERROR_ARTIFACTS'] = str(out / 'viewer-child')
os.environ['MOTION_CAPTURE_CONTEXT_ARTIFACTS'] = str(out / 'capture-context-child')
os.environ['MOTION_DIAGNOSTICS_NATIVE_ERROR_ARTIFACTS'] = str(out / 'diagnostics-child')


def run(phase, command):
    code = subprocess.run([sys.executable, str(out / 'run.py'), phase, *command]).returncode
    if code:
        raise SystemExit(code)
    meta = json.loads((out / (phase + '.json')).read_text(encoding='utf-8'))
    assert meta['source_before'] == meta['source_after'] == compiled['source_after'], phase


passed = 0
for phase, selection, expected in [
    ('paint-all', 'engine::ui_paint::', 3),
    ('engine-errors', 'engine::error::tests::', 5),
    ('viewer-native', 'engine::viewer_capture_error_tests::', 1),
    ('capture-context', 'engine::capture_context_tests::', 1),
    ('precision-capture', 'engine::precision_capture_tests::', 1),
    ('cell-inspection', 'engine::viewer_frame::native::inspection::', 1),
    ('diagnostics-all', 'diagnostics::', 15),
]:
    listed = subprocess.check_output([str(program), selection, '--list'], encoding='utf-8')
    names = [line.removesuffix(': test') for line in listed.splitlines() if line.endswith(': test')]
    assert len(names) == expected, (phase, names)
    (out / (phase + '-test-names.json')).write_text(json.dumps(names, indent=2), encoding='utf-8')
    run(phase, [str(program), selection, '--test-threads=1', '--nocapture'])
    assert f'{expected} passed; 0 failed; 0 ignored' in (out / (phase + '.stdout')).read_text(encoding='utf-8'), phase
    passed += expected
assert hashlib.file_digest(program.open('rb'), 'sha256').hexdigest() == digest
print(json.dumps({'desktop_passed': passed, 'source_and_executable_stable': True}), flush=True)
run('host-full', ['cargo', 'test', '--locked', '-p', 'motion-host', '--', '--test-threads=1', '--nocapture'])
run('all-targets', ['cargo', 'check', '--locked', '-p', 'motion-desktop', '-p', 'motion-host',
    '--all-targets', '--features', 'motion-desktop/ffmpeg,motion-host/diagnostics,motion-host/ai-depth'])
