"""Resume after correcting a new integration test's declared source type."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

out = Path(__file__).parent
root = Path.cwd()
desktop = json.loads((out / 'verified-executable.json').read_text(encoding='utf-8'))
delta = {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
         for name, digest in desktop['source'].items()
         if hashlib.sha256((root / name).read_bytes()).hexdigest() != digest}
assert set(delta) == {'crates/motion-host/tests/native_provider_errors.rs'}, delta
before = (out / 'initial-host-failure/native_provider_errors.rs').read_text(encoding='utf-8')
after = (root / 'crates/motion-host/tests/native_provider_errors.rs').read_text(encoding='utf-8')
old = '    let native = error.source().unwrap().downcast_ref::<Error>().unwrap();'
new = ('    // thiserror retains the declared Box<Error>, as with Context/Cleanup.\n'
       '    let native = error.source().unwrap().downcast_ref::<Box<Error>>().unwrap();\n'
       '    assert_eq!(native.composition_detail().unwrap() as *const _, detail);')
assert before.count(old) == 1 and before.replace(old, new) == after
assert hashlib.file_digest(Path(desktop['path']).open('rb'), 'sha256').hexdigest() == desktop['sha256']
(out / 'host-test-correction.json').write_text(json.dumps({
    'scope': 'Only the new host integration test changed. All production and all desktop test source bytes are unchanged.',
    'original_sha256': desktop['source']['crates/motion-host/tests/native_provider_errors.rs'],
    'corrected_sha256': delta['crates/motion-host/tests/native_provider_errors.rs'],
    'change': 'Downcast the declared Box<Error> and additionally check original detail pointer identity. No assertion removed or weakened.',
    'desktop_executable_sha256': desktop['sha256']}, indent=2), encoding='utf-8')
expected = dict(desktop['source'])
expected.update(delta)
def run(phase, command):
    result = subprocess.run([sys.executable, str(out / 'run.py'), phase, *command])
    if result.returncode:
        raise SystemExit(result.returncode)
    meta = json.loads((out / (phase + '.json')).read_text(encoding='utf-8'))
    assert meta['source_before'] == meta['source_after'] == expected, phase

run('host-provider-corrected', ['cargo', 'test', '--locked', '-p', 'motion-host',
    '--test', 'native_provider_errors', '--', '--test-threads=1', '--nocapture'])
run('host-full-corrected', ['cargo', 'test', '--locked', '-p', 'motion-host',
    '--', '--test-threads=1', '--nocapture'])
run('all-targets', ['cargo', 'check', '--locked', '-p', 'motion-desktop', '-p', 'motion-host',
    '--all-targets', '--features', 'motion-desktop/ffmpeg,motion-host/diagnostics,motion-host/ai-depth'])
