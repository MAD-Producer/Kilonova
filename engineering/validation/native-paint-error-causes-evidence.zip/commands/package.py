"""Archive actual commands, failure-channel evidence and verified source bytes."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

out = Path(__file__).parent
root = Path.cwd()
phases = ['native-paint-compile', 'paint-all', 'engine-errors', 'viewer-native',
          'capture-context', 'precision-capture', 'cell-inspection',
          'diagnostics-all', 'host-provider-corrected', 'host-full-corrected',
          'all-targets', 'native-paint-corrected-wrapper']
source = json.loads((out / 'verified-executable.json').read_text(encoding='utf-8'))
desktop_inventory = source['source']
correction = json.loads((out / 'host-test-correction.json').read_text(encoding='utf-8'))
inventory = dict(desktop_inventory)
inventory['crates/motion-host/tests/native_provider_errors.rs'] = correction['corrected_sha256']
for name, digest in inventory.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
assert hashlib.file_digest(Path(source['path']).open('rb'), 'sha256').hexdigest() == source['sha256']
summary = {}
desktop_passed = 0
for phase in phases:
    meta = json.loads((out / f'{phase}.json').read_text(encoding='utf-8'))
    assert meta['exit_code'] == 0, phase
    expected = desktop_inventory if phase in phases[:8] else inventory
    assert meta['source_before'] == meta['source_after'] == expected, phase
    stdout = (out / f'{phase}.stdout').read_text(encoding='utf-8')
    counts = [tuple(map(int, match)) for match in re.findall(
        r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout)]
    assert all(failed == 0 for _, failed, _ in counts), phase
    passed = sum(item[0] for item in counts)
    ignored = sum(item[2] for item in counts)
    summary[phase] = {'exit_code': 0, 'elapsed_seconds': meta['elapsed_seconds'],
                      'passed': passed, 'ignored': ignored, 'source_stable': True}
    names_file = out / f'{phase}-test-names.json'
    if names_file.exists():
        names = json.loads(names_file.read_text(encoding='utf-8'))
        for name in names:
            assert f'test {name} ... ok' in stdout, (phase, name)
        assert len(names) == passed and ignored == 0, phase
        desktop_passed += passed
assert desktop_passed == 27
host_stdout = (out / 'host-full-corrected.stdout').read_text(encoding='utf-8')
for name in ['foreign_provider_keeps_native_source_identity_os_code_and_lifetime',
             'related_failure_keeps_primary_detail_and_both_native_causes']:
    assert f'test {name} ... ok' in host_stdout, name
assert summary['host-full-corrected']['passed'] > 280
assert json.loads((out / 'initial-host-failure/host-full.json').read_text(encoding='utf-8'))['exit_code'] == 101
report = json.loads((out / 'native-child/report.json').read_text(encoding='utf-8'))
assert all(report[key] is True for key in ['atlas_io_native', 'painter_budget_native',
    'pixels_unchanged', 'project_unchanged', 'related_primary_native'])
assert report['primary_os_code'] == 2
payload = {}
for path in sorted(out.rglob('*')):
    if path.is_file() and path.suffix != '.zip' and path.name not in [
            'package-receipt.json', 'verification-summary.json'] and not path.name.startswith('issue-'):
        payload['commands/' + path.relative_to(out).as_posix()] = path.read_bytes()
changed = ['crates/motion-host/src/error.rs',
           'crates/motion-host/tests/native_provider_errors.rs',
           'desktop/app/src/engine.rs', 'desktop/app/src/engine/ui_paint.rs',
           'desktop/app/src/engine/ui_paint/admission_tests.rs',
           'desktop/app/src/engine/ui_paint/native_error_tests.rs']
for name in changed:
    data = (root / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == inventory[name], name
    payload['source/after/' + name] = data
    before = subprocess.run(['git', 'show', 'HEAD:' + name], capture_output=True)
    if before.returncode == 0:
        payload['source/before/' + name] = before.stdout
verification = {'desktop_passed': desktop_passed,
                'source_files': len(inventory), 'executable_sha256': source['sha256'],
                'phases': summary, 'native_report': report,
                'host_test_correction': correction,
                'scope': '27 selected desktop tests; full motion-host; desktop/host all-targets with ffmpeg, diagnostics and ai-depth'}
data = json.dumps(verification, ensure_ascii=False, indent=2).encode('utf-8')
payload['verification-summary.json'] = data
(out / 'verification-summary.json').write_bytes(data)
manifest = {name: {'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
            for name, content in sorted(payload.items())}
payload['manifest.json'] = json.dumps(manifest, indent=2).encode('utf-8')
archive = root / 'engineering/validation/native-paint-error-causes-evidence.zip'
assert not archive.exists(), 'published archives must never be overwritten'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as target:
    for name, content in sorted(payload.items()):
        target.writestr(name, content)
with zipfile.ZipFile(archive) as target:
    assert set(target.namelist()) == set(payload)
    assert target.testzip() is None
    for name, content in payload.items():
        assert target.read(name) == content, name
receipt = {'path': str(archive), 'members': len(payload), 'bytes': archive.stat().st_size,
           'sha256': hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest(),
           'desktop_passed': desktop_passed, 'host_passed': summary['host-full-corrected']['passed'],
           'host_ignored': summary['host-full-corrected']['ignored'], 'source_files': len(inventory)}
(out / 'package-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt))
