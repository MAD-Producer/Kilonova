param([string]$Stage)
$ErrorActionPreference='Stop'
. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$evidenceRoot='E:/Dev/aem/artifacts/issue-goal-current/anchor-key-identities'
cargo rustc -p motion-core --test layer_anchor_animation --profile test --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --message-format=json -- -C debuginfo=0 -C link-arg=/DEBUG:NONE 1> "$evidenceRoot/$Stage-core-build.jsonl" 2> "$evidenceRoot/$Stage-core-build.stderr"
$runExit=$LASTEXITCODE
Set-Content -LiteralPath "$evidenceRoot/$Stage-core-build.exit" -Value $runExit
if($runExit -ne 0){exit $runExit}
$artifact=Get-Content -LiteralPath "$evidenceRoot/$Stage-core-build.jsonl" | ForEach-Object {$_ | ConvertFrom-Json} | Where-Object {$_.reason -eq 'compiler-artifact' -and $_.target.name -eq 'layer_anchor_animation' -and $_.executable} | Select-Object -Last 1
if(-not($artifact.profile.test -and $artifact.profile.debug_assertions -and $artifact.profile.overflow_checks)){throw 'test profile checks missing'}
Get-FileHash -LiteralPath $artifact.executable -Algorithm SHA256 | ConvertTo-Json | Set-Content -LiteralPath "$evidenceRoot/$Stage-core-binary.json"
& $artifact.executable --test-threads=1 --nocapture *> "$evidenceRoot/$Stage-core.log"
$runExit=$LASTEXITCODE
Set-Content -LiteralPath "$evidenceRoot/$Stage-core.exit" -Value $runExit
exit $runExit
