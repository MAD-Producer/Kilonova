import hashlib, json, re, subprocess, zipfile
from pathlib import Path
raw=Path('E:/Dev/aem/artifacts/issue-goal-current/anchor-key-identities')
out=Path('engineering/validation/anchor-key-identities-evidence')
out.mkdir(parents=True,exist_ok=True)
suites=[('integrated-core',17),('integrated-after-space',17),('integrated-controls',44),('native-integrated',1)]
seen=set()
for stage,count in suites:
    assert int((raw/(stage+'.exit')).read_text(encoding='utf-8-sig').strip())==0
    log=(raw/(stage+'.log')).read_text(encoding='utf-8-sig')
    names=re.findall(r'^test (\S+) \.\.\. ok$',log,re.M)
    assert len(names)==count,(stage,len(names))
    assert not seen.intersection(names)
    seen.update(names)
assert len(seen)==79
assert int((raw/'integrated-workspace-check.exit').read_text(encoding='utf-8-sig').strip())==0
base='6ab57829211346edc8dd0356bd9d15cefc6ae57d'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
paths=subprocess.check_output(['git','diff','--name-only',base,'HEAD'],text=True).splitlines()
sources=[]
for p in paths:
    if p.endswith('.rs'):
        b=Path(p).read_bytes()
        sources.append(dict(path=p,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))
(raw/'integrated-source-basis.json').write_text(json.dumps(dict(base=base,codeCommit=head,sources=sources),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for p in sorted((raw/'native-integrated').glob('*.png')):
    (out/p.name).write_bytes(p.read_bytes())
entries=[]
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(raw.rglob('*')):
        if p.is_file():
            b=p.read_bytes(); rel=p.relative_to(raw).as_posix()
            entries.append(dict(path=rel,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))
            z.writestr(rel,b)
manifest=dict(base=base,codeCommit=head,stage='local acceptance passed; remote CI pending',
    tests=dict(distinctPassed=79,core=17,properties=17,transformControls=44,nativeExplicit=1,prefixIgnoredUnchanged=6),
    checks=dict(workspace='FFmpeg + motion-host/diagnostics, all targets excluding Android: passed',styleConsumers='passed',rustfmtNewModules='passed',diffCheck='passed'),
    retainedFailures=['before-single-cgu: original replacement regression','first-core: two new fixture/protocol expectation errors, corrected with original guards intact','compiler import/type errors and access violations','integrated-properties: disk full before execution','first main fetch failed; successful canonical fetch and integration followed'],
    pending=['current-head remote CI','all panels/platforms/DPI: outside this interaction change','remaining #257 work'],
    evidence=entries)
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f'Packaged {len(entries)} evidence files; {len(seen)} distinct passing tests; code {head}')
