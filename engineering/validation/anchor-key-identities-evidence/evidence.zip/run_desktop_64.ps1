param([string]$Stage,[string]$Filter='anchor_key_tests',[switch]$Ignored)
$ErrorActionPreference='Stop'
. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:LIBCLANG_PATH='E:/Dev/aem/.tools/python-libclang/clang/native'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
$evidenceRoot='E:/Dev/aem/artifacts/issue-goal-current/anchor-key-identities'
cargo rustc -p motion-desktop --bin motion-studio --profile test --features ffmpeg --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --message-format=json -- -C codegen-units=64 -C debuginfo=0 -C link-arg=/DEBUG:NONE 1> "$evidenceRoot/$Stage-build.jsonl" 2> "$evidenceRoot/$Stage-build.stderr"
$runExit=$LASTEXITCODE
Set-Content -LiteralPath "$evidenceRoot/$Stage-build.exit" -Value $runExit
if ($runExit -ne 0) {exit $runExit}
$testArtifact=Get-Content -LiteralPath "$evidenceRoot/$Stage-build.jsonl" | ForEach-Object {$_ | ConvertFrom-Json} | Where-Object {$_.reason -eq 'compiler-artifact' -and $_.target.name -eq 'motion-studio' -and $_.executable} | Select-Object -Last 1
if(-not ($testArtifact.profile.test -and $testArtifact.profile.debug_assertions -and $testArtifact.profile.overflow_checks)) {throw 'test profile assertions missing'}
Get-FileHash -LiteralPath $testArtifact.executable -Algorithm SHA256 | ConvertTo-Json | Set-Content -LiteralPath "$evidenceRoot/$Stage-binary.json"
$runArgs=@($Filter,'--test-threads=1','--nocapture')
if($Ignored) {$runArgs+='--ignored'}
& $testArtifact.executable @runArgs *> "$evidenceRoot/$Stage.log"
$runExit=$LASTEXITCODE
Set-Content -LiteralPath "$evidenceRoot/$Stage.exit" -Value $runExit
exit $runExit
