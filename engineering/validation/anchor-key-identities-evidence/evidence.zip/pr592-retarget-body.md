## 问题与改动

遮罩提取按来源逐项上传 uniform，32 层测试场景会产生 28 次 queue.write_buffer。本 PR 在原依赖规划后复用 CPU 存储，保留原动态偏移，将本次占用槽位跨度合并为一次上传；空需求不上传。

GPU buffer、纹理、预算、reservation 生命周期、提取顺序、绑定和附件操作保持原语义。一个来源的 alpha／luma 提取共用同一参数槽位。稀疏跨度可能传输更多 padding，本次不宣称带宽收益。

前置 #590 已合并为 6ab57829，本 PR 已改为直接合入 main，仅包含后续 uniform 打包上传。Refs #126。

## 验证

- 旧实现实际失败：要求一次上传，观测为 28 次；修正先前不合法的 fixture RGBA 后才到达该目标断言，两次原始失败均留档。
- 29 项不同测试通过，0 失败、0 ignored：规划及 uniform 8、连续合成段 3、完整预览测量 1、遮罩准入 5、图层合成 7、精度集成 5。
- 四种精度、七种场景、三次实际位置变化、正式／预览两种路径，共 168 个场景，与保留的逐项上传路径比较完整原生像素、draw_calls、纹理字节及资源身份。覆盖 128 层、四种 matte 模式、同来源双模式、隐藏来源及空场景切换。
- 独立旧 payload 对照验证 1／8／128 个来源各 120 次暖机后打包零分配，并验证稀疏高偏移、重复项、空需求和尺寸变化。内部受控投影错误在首次上传前拒绝，旧像素／台账保留，恢复后输出正确。
- 带 FFmpeg／diagnostics 的 workspace all-targets 检查通过，排除 Android，耗时 2 分 15 秒。

144 条完整预览测量中，8 层遮罩整帧分配从 826 次降至 802 次，32 层从 3113 次降至 3004 次。只统计调用线程成功分配次数，不包含分配字节、其他线程和外部驱动内存，不据此推导 FPS。

## 仍未完成

整帧分配仍随层数增长，#126 保持开放。错误继续走既有 Result／宿主边界，本次未重新执行完整桌面日志输出验收。没有放宽既有断言、预算、超时或重试；没有 UI、依赖或素材变化。

[验证与审计](https://github.com/MAD-Producer/Kilonova/blob/df680bec/engineering/validation/matte-uniform-upload.md) · [证据清单](https://github.com/MAD-Producer/Kilonova/blob/df680bec/engineering/validation/matte-uniform-upload-evidence/manifest.json)
