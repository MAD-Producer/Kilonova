import hashlib,json,re,shutil,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path.cwd()
dest=repo/'engineering/validation/layer-time-path-authoring-evidence'
dest.mkdir(exist_ok=True)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((root/'source-hashes.json').read_text())
for name,sha in sources.items():
    assert digest(repo/name)==sha,name
groups=[]
unique=set()
for name in ['core','mapped','boundary-time','paths','audio','numeric','native']:
    logs=(root/(name+'.log')).read_text(errors='replace')
    assert 'test result: ok.' in logs and 'test result: FAILED' not in logs,name
    passed=re.findall(r'^test (\S+) \.\.\. ok$',logs,re.M)
    ignored=re.findall(r'^test (\S+) \.\.\. ignored.*$',logs,re.M)
    unique.update(passed)
    groups.append(dict(group=name,passed=passed,ignored=ignored))
checks=json.loads((root/'checks.json').read_text(encoding='utf-8-sig'))
assert all(v==0 for v in checks.values()),checks
assert len(list((root/'native').rglob('*.png')))==48
assert len(list((root/'native').rglob('reopened.json')))==16
a=json.loads((root/'native/capture-process.json').read_text())
b=json.loads((root/'native/reopen-process.json').read_text())
assert a['pid']!=b['pid']
for source,name in [('Masks-Zh-false-false/committed.png','mask-main-zh.png'),('Vector-En-true-true/committed.png','vector-floating-en.png')]:
    shutil.copyfile(root/'native'/source,dest/name)
archive=dest/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.suffix.lower() in {'.log','.json','.py','.ps1','.png'}:
            z.write(p,p.relative_to(root).as_posix())
manifest=dict(issue=257,pr=579,stage='exact-time vector and mask parameter authoring',base='04e74a492e5749db5112f8d503059ddf314c3ca1',branch='feat/layer-time-mapping',sourceHashes=sources,checks=checks,passed=len(unique),testResults=groups,unrunManual=sorted({n for g in groups for n in g['ignored']}-unique),
    binaries=[dict(path=str(root/n),sha256=digest(root/n),bytes=(root/n).stat().st_size) for n in ['tested.exe','core-tested.exe','motion_studio-b34b3a7e7eb835e8.pdb']],
    native=dict(cases=16,screenshots=48,separateProcessReopens=16,capturePid=a['pid'],reopenPid=b['pid'],input='synthetic Input through production main/floating chrome with real native GPU capture; no physical OS mouse input'),
    originalFailures=['initial-compile-failure.log: wrong new fixture field name and ambiguous helper import','initial-fixture-failure.log: Group fixture incorrectly retained outer fill/stroke; production validation unchanged','audio-missing-symbols-failure.log: copied test executable lacked adjacent debug symbols; panic backtrace symbol assertion failed; production and existing assertion unchanged'],
    observationSites=['mask.numeric_time_begin','mask.numeric_time_continue','vector.numeric_time_begin','vector.numeric_time_continue'],
    limits=['Windows only','no new layout styling or product-wide visual compliance claim','partial path navigation and continuous spatial edit entrances remain','camera gestures, roving compensation and real media device/high-speed sampling acceptance incomplete','existing warnings and Epic Overlay missing Vulkan JSON records retained','issue 257 stays open'],
    archive=dict(file='evidence.zip',sha256=digest(archive),bytes=archive.stat().st_size))
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(passed=len(unique),archiveBytes=archive.stat().st_size,sources=len(sources))))
