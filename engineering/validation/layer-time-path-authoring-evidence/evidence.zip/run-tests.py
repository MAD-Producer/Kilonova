import os,subprocess,json,time,sys
from pathlib import Path
root=Path(__file__).resolve().parent
exe=str(root/'tested.exe')
env=os.environ.copy();env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH'];env.pop('MOTION_LOG',None)
env['MOTION_MAPPED_PATH_ARTIFACTS']=str(root/'native');env['MOTION_MAPPED_PATH_FAULT_ARTIFACTS']=str(root/'faults')
groups=[('mapped',['panels::path_controls::mapped_authoring_tests::']),('boundary-time',['panels::path_controls::mask_boundaries::viewer::tests::mapped_time::']),('paths',['panels::path_controls::','--skip','panels::path_controls::mapped_authoring_tests::','--skip','panels::path_controls::mask_boundaries::viewer::tests::mapped_time::']),('audio',['panels::audio::']),('numeric',['panels::numeric::']),('native',['--exact','panels::path_controls::mapped_authoring_tests::native::native_mapped_paths_keep_exact_keys_in_both_hosts_languages_and_directions','--ignored'])]
results=[]
for name,args in groups:
    if len(sys.argv)>1 and name not in sys.argv[1:]:continue
    start=time.time()
    with (root/(name+'.log')).open('wb') as log:result=subprocess.run([exe,*args,'--nocapture','--test-threads=1'],stdout=log,stderr=subprocess.STDOUT,env=env)
    row=dict(group=name,args=args,exit=result.returncode,seconds=round(time.time()-start,3));results.append(row)
    (root/('results'+('-'+'-'.join(sys.argv[1:]) if len(sys.argv)>1 else '')+'.json')).write_text(json.dumps(results,indent=2));print(json.dumps(row),flush=True)
    if result.returncode:break
raise SystemExit(any(x['exit'] for x in results))
