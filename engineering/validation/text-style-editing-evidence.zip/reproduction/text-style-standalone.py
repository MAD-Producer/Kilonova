import hashlib
import json
import os
from pathlib import Path
import queue
import subprocess
import threading
from PIL import Image, ImageChops

root = Path('E:/Dev/aem/artifacts/pr-ci-followups')
preview = Path('E:/Dev/aem/artifacts/text-style-preview')
out = root / 'text-style-standalone'
out.mkdir(exist_ok=True)
env = os.environ.copy()
env['PATH'] = str(preview) + ';' + str(Path(os.environ['SystemRoot']) / 'System32')
env.pop('MOTION_LOG', None)
binary = str(preview / 'motion-studio.exe')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

manifest = json.loads((preview / 'ffmpeg-runtime.json').read_text(encoding='utf-8'))
runtime = []
for entry in manifest['files']:
    if not entry['path'].startswith('bin/'):
        continue
    path = preview / Path(entry['path']).name
    actual = digest(path)
    assert actual == entry['sha256'], (path.name, actual, entry['sha256'])
    runtime.append({'file': path.name, 'sha256': actual})

def run(name, args, timeout=60):
    result = subprocess.run([binary] + args, cwd=preview, env=env, capture_output=True, timeout=timeout)
    (out / (name + '.stdout.log')).write_bytes(result.stdout)
    (out / (name + '.stderr.log')).write_bytes(result.stderr)
    assert result.returncode == 0, (name, result.returncode, result.stderr.decode('utf-8', errors='replace'))
    return result

catalogue = run('command-list', ['--command-list'])
json.loads(catalogue.stdout)
assert not catalogue.stderr
run('video-smoke', ['--video-smoke', str(root / 'text-style-export-final/styled.mp4')])
for locale in ('zh', 'en'):
    run('smoke-' + locale, ['--smoke', str(out / ('smoke-' + locale + '.json')), '--locale', locale], 60)

cjk = root / 'text-style-native-cjk-final'
stderr = (out / 'cjk-reopen.stderr.log').open('wb')
process = subprocess.Popen([binary, '--mcp', '--project', str(cjk / 'project')], cwd=preview,
    env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr, text=True, encoding='utf-8')
responses = queue.Queue()
def read():
    for line in process.stdout:
        responses.put(line)
    responses.put(None)
threading.Thread(target=read, daemon=True).start()
sequence = 0
transcript = []
def send(method, params=None, notification=False):
    global sequence
    sequence += 1
    request = {'jsonrpc': '2.0', 'method': method}
    if not notification:
        request['id'] = sequence
    if params is not None:
        request['params'] = params
    process.stdin.write(json.dumps(request) + '\n')
    process.stdin.flush()
    if notification:
        return
    line = responses.get(timeout=60)
    assert line is not None, 'MCP process exited without reply'
    response = json.loads(line)
    transcript.append(response)
    assert response.get('id') == sequence and 'error' not in response, response
    result = response['result']
    assert not result.get('isError'), result
    return result
try:
    send('initialize', {'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'text-style-proof','version':'1'}})
    send('notifications/initialized', notification=True)
    state = send('tools/call', {'name':'motion_state','arguments':{}})['structuredContent']
    style = state['project']['layers'][0]['content']['style']
    assert style == {'font_size':48.0,'width':420,'line_height':76.0,'tracking':3.0,
        'stroke_width':1.5,'alignment':'center','indent_left':12.0,'indent_right':12.0,'indent_first':16.0}, style
    rendered = send('tools/call', {'name':'render_preview','arguments':{'frame':0}})['structuredContent']
    (out / 'cjk-render-result.json').write_text(json.dumps(rendered,ensure_ascii=False,indent=2),encoding='utf-8')
    image_path = Path(rendered['path'])
    actual = Image.open(image_path).convert('RGBA')
    expected = Image.open(cjk / 'zh-styled-output.png').convert('RGBA')
    assert actual.size == expected.size == (640,360)
    assert ImageChops.difference(actual, expected).getbbox() is None
    actual.save(out / 'cjk-reopened.png')
    process.stdin.close()
    assert process.wait(timeout=20) == 0
finally:
    if process.poll() is None:
        process.kill()
        process.wait(timeout=10)
    stderr.close()
    (out / 'cjk-mcp-responses.json').write_text(json.dumps(transcript,ensure_ascii=False,indent=2),encoding='utf-8')

results = {'production_source':'c75d06a91a80563cb9088499abbe43fe94e77534',
    'executable_sha256':digest(preview/'motion-studio.exe'), 'ffmpeg_runtime':runtime,
    'minimal_path':env['PATH'], 'command_list_json_stdout':True,'command_list_empty_stderr':True,
    'video_decode':True,'smoke_locales':['zh','en'],'cjk_independent_reopen_exact':True,
    'cjk_style':style}
(out / 'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
(preview / 'BUILD-INFO.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=False))
