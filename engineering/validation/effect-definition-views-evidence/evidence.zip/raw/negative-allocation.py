import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('E:/Dev/aem/.worktrees/layer-time-mapping')
out = Path(__file__).parent
path = root / 'desktop/app/src/panels/effect_controls/definition.rs'
original = path.read_bytes()
try:
    text = original.decode('utf-8')
    start = text.index('pub(super) fn parameters(')
    text = text[:start] + '''pub(super) fn parameters(definition: &Value) -> impl Iterator<Item = &Value> {
    let mut params: Vec<_> = definition["params"].as_array().into_iter().flatten().collect();
    params.sort_by_key(|param| param["kind"] == "curve");
    params.into_iter()
}
'''
    path.write_text(text, 'utf-8')
    script = out / 'build-negative.ps1'
    script.write_text((out / 'build-probe.ps1').read_text('utf-8').replace('/probe-build.', '/negative-build.'), 'utf-8')
    built = subprocess.run(['pwsh', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(script)], cwd=root)
    assert built.returncode == 0
    rows = [json.loads(l) for l in (out / 'negative-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
    exe = [r['executable'] for r in rows if r.get('reason') == 'compiler-artifact' and r['target']['name'] == 'effect_definition_views' and r.get('executable')][-1]
    env = os.environ.copy()
    env.pop('RUST_MIN_STACK', None)
    env['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + env['PATH']
    command = [exe, '--exact', 'repeated_definition_and_parameter_visits_do_not_allocate_or_retain_old_generations', '--nocapture']
    result = subprocess.run(command, env=env, capture_output=True)
    (out / 'negative-tests.stdout').write_bytes(result.stdout)
    (out / 'negative-tests.stderr').write_bytes(result.stderr)
    assert result.returncode == 101
    assert b'FAILED' in result.stdout and b'borrowed_allocations=120' in result.stdout
    receipt = {'executable_sha256': hashlib.sha256(Path(exe).read_bytes()).hexdigest(),
               'command': command, 'exit': result.returncode, 'detected_real_original_sort_allocation': True}
    (out / 'negative-receipt.json').write_text(json.dumps(receipt, indent=2), 'utf-8')
    print(json.dumps(receipt))
finally:
    path.write_bytes(original)
    assert path.read_bytes() == original
    subprocess.run(['git', 'diff', '--exit-code', '--', str(path)], cwd=root, check=True)
    (out / 'negative-restored.json').write_text(json.dumps({'source_sha256': hashlib.sha256(original).hexdigest()}), 'utf-8')
