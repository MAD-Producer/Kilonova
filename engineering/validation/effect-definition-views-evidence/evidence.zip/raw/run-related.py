from pathlib import Path
import hashlib
import json
import os
import subprocess

out = Path(__file__).parent
rows = [json.loads(l) for l in (out / 'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
exe = [r['executable'] for r in rows if r.get('reason') == 'compiler-artifact' and r['target']['name'] == 'motion-studio' and r.get('executable')][-1]
env = os.environ.copy()
env.pop('RUST_MIN_STACK', None)
env['MOTION_LOG'] = 'info'
env['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + env['PATH']
env['TEMP'] = env['TMP'] = 'E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['MOTION_DEFINITION_VIEW_EVIDENCE'] = str(out / 'fixed-paint.json')
command = [exe, 'panels::effect_controls::', 'panels::animation_controls::', 'panels::layer_identity::', 'panels::effect_timeline::', '--test-threads=1', '--nocapture']
result = subprocess.run(command, env=env, capture_output=True)
(out / 'related-tests.stdout').write_bytes(result.stdout)
(out / 'related-tests.stderr').write_bytes(result.stderr)
(out / 'related-tests.json').write_text(json.dumps({'command': command, 'exit': result.returncode,
    'executable_sha256': hashlib.sha256(Path(exe).read_bytes()).hexdigest(), 'runtime_stack_override': False}, indent=2), 'utf-8')
print(result.stdout.decode('utf-8', errors='replace')[-3000:])
print(result.stderr.decode('utf-8', errors='replace')[-2000:])
assert result.returncode == 0
