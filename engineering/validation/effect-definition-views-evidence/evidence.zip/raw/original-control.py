import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('E:/Dev/aem/.worktrees/layer-time-mapping')
out = Path(__file__).parent
paths = ['desktop/app/src/panels/effect_controls.rs', 'desktop/app/src/panels/effect_timeline.rs']
original = {p: (root / p).read_bytes() for p in paths}
parent = '6cc48dc8216d09ead3d86d9d9e0eeb314df55ca9'
try:
    for path in paths:
        data = subprocess.check_output(['git', 'show', parent + ':' + path], cwd=root)
        if path.endswith('/effect_controls.rs'):
            assert data.count(b'mod curve;') == 1
            data = data.replace(b'mod curve;', b'mod curve;\npub(super) mod definition;')
        (root / path).write_bytes(data)
    build = (out / 'build-app.ps1').read_text('utf-8').replace('/app-build.', '/original-build.')
    script = out / 'build-original.ps1'
    script.write_text(build, 'utf-8')
    built = subprocess.run(['pwsh', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(script)], cwd=root)
    assert built.returncode == 0
    rows = [json.loads(l) for l in (out / 'original-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
    exe = [r['executable'] for r in rows if r.get('reason') == 'compiler-artifact' and r['target']['name'] == 'motion-studio' and r.get('executable')][-1]
    env = os.environ.copy()
    env.pop('RUST_MIN_STACK', None)
    env['MOTION_LOG'] = 'info'
    env['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + env['PATH']
    env['TEMP'] = env['TMP'] = 'E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
    env['MOTION_DEFINITION_VIEW_EVIDENCE'] = str(out / 'original-paint.json')
    command = [exe, '--exact', 'panels::effect_controls::track_cache_tests::definition_views::actual_definition_views_preserve_full_draw_height_hits_and_refresh_current_catalogue', '--nocapture']
    result = subprocess.run(command, env=env, capture_output=True)
    (out / 'original-tests.stdout').write_bytes(result.stdout)
    (out / 'original-tests.stderr').write_bytes(result.stderr)
    assert result.returncode == 0
    fixed = json.loads((out / 'fixed-paint.json').read_text('utf-8'))
    previous = json.loads((out / 'original-paint.json').read_text('utf-8'))
    assert previous == fixed, 'original and optimized complete paints differ'
    assert len(fixed) == 16
    assert all(before != changed for before, changed in fixed.values())
    receipt = {'original_executable_sha256': hashlib.sha256(Path(exe).read_bytes()).hexdigest(),
               'command': command, 'exit': result.returncode, 'complete_draw_comparisons': 32,
               'changed_definition_controls': 16, 'full_original_fixed_equality': True}
    (out / 'original-receipt.json').write_text(json.dumps(receipt, indent=2), 'utf-8')
    print(json.dumps(receipt))
finally:
    for path, data in original.items():
        (root / path).write_bytes(data)
        assert (root / path).read_bytes() == data
    subprocess.run(['git', 'diff', '--exit-code', '--', *paths], cwd=root, check=True)
    (out / 'original-restored.json').write_text(json.dumps({p: hashlib.sha256(data).hexdigest() for p, data in original.items()}, indent=2), 'utf-8')
