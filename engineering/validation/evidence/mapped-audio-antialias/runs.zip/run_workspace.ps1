param([string]$Stage='final')
$ErrorActionPreference='Stop'
. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:LIBCLANG_PATH='E:/Dev/aem/.tools/python-libclang/clang/native'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
$evidenceRoot='E:/Dev/aem/artifacts/issue-goal-current/mapped-audio-antialias'
cargo check --workspace --all-targets --exclude motion-android --features motion-desktop/ffmpeg,motion-host/diagnostics --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target *> "$evidenceRoot/$Stage-workspace-check.log"
$runExit=$LASTEXITCODE
Set-Content -LiteralPath "$evidenceRoot/$Stage-workspace-check.exit" -Value $runExit
exit $runExit
