param([string]$Stage, [string]$Target='mapped_audio_quality', [string]$Filter='')
$ErrorActionPreference='Stop'
. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$evidenceRoot='E:/Dev/aem/artifacts/issue-goal-current/mapped-audio-antialias'
# This selected test retains the normal test profile, assertions and overflow
# checks. Only final MSVC PDB emission is omitted on this space-limited disk.
$selectionArgs=@('--test',$Target)
if ($Target -eq 'lib') { $selectionArgs=@('--lib') }
cargo rustc -p motion-media @selectionArgs --profile test --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --message-format=json -- -C link-arg=/DEBUG:NONE 1> "$evidenceRoot/$Stage-build.jsonl" 2> "$evidenceRoot/$Stage-build.stderr"
$buildExit=$LASTEXITCODE
Set-Content -LiteralPath "$evidenceRoot/$Stage-build.exit" -Value $buildExit
if ($buildExit -ne 0) { exit $buildExit }
$testArtifact=Get-Content -LiteralPath "$evidenceRoot/$Stage-build.jsonl" | ForEach-Object { $_ | ConvertFrom-Json } | Where-Object { $_.reason -eq 'compiler-artifact' -and ($_.target.name -eq $Target -or ($Target -eq 'lib' -and $_.target.name -eq 'motion_media')) -and $_.executable } | Select-Object -Last 1
if (-not $testArtifact) { throw 'missing selected test executable artifact' }
if (-not ($testArtifact.profile.test -and $testArtifact.profile.debug_assertions -and $testArtifact.profile.overflow_checks)) { throw 'selected artifact lost test/assertion/overflow checks' }
Get-FileHash -LiteralPath $testArtifact.executable -Algorithm SHA256 | ConvertTo-Json | Set-Content -LiteralPath "$evidenceRoot/$Stage-binary.json"
& $testArtifact.executable $Filter --test-threads=1 --nocapture *> "$evidenceRoot/$Stage.log"
$runExit=$LASTEXITCODE
Set-Content -LiteralPath "$evidenceRoot/$Stage.exit" -Value $runExit
exit $runExit
