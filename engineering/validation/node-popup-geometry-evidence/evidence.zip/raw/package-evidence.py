import hashlib, json, re, subprocess, zipfile
from pathlib import Path

raw = Path(__file__).parent
repo = Path('E:/Dev/aem/.worktrees/layer-time-mapping')
out = repo / 'engineering/validation/node-popup-geometry-evidence'
out.mkdir(exist_ok=True)
digest = lambda data: hashlib.sha256(data).hexdigest()
comparison = json.loads((raw / 'final-comparison.json').read_text('utf-8'))
assert comparison['total_complete_frames'] == 3240 and comparison['exact_equal'] and not comparison['normalization']
names = []
for prefix, expected in [('regression-0', 206), ('regression-1', 4), ('regression-2', 13), ('regression-3', 7), ('costs.json', 1), ('layouts.json', 1)]:
    text = (raw / (prefix + '.stdout')).read_text('utf-8')
    assert re.search(rf'test result: ok\. {expected} passed; 0 failed; 0 ignored;', text)
    selected = re.findall(r'^test (\S+) \.\.\.', text, re.M)
    assert len(selected) == expected
    names.extend(selected)
assert len(names) == len(set(names)) == 232
assert json.loads((raw / 'startup.json').read_text('utf-8'))['exit'] == 0
assert json.loads((raw / 'final-tests.json').read_text('utf-8'))[0]['executable_sha256'] == comparison['executable_sha256']

sources = ['desktop/app/src/node_editor/view/control_popup.rs', 'desktop/app/src/node_editor/view/controls.rs',
    'desktop/app/src/node_editor/view/frame_cards_tests.rs', 'desktop/app/src/node_editor/view/frame_cards_tests/popup_geometry.rs']
original_records = []
for row in comparison['prior_records']:
    original = Path(row['original'])
    # The comparison receipt identifies the original and current complete files.
    assert digest(original.read_bytes()) == row['original_sha256'] == row['final_sha256']
    original_records.append(dict(path=str(original), sha256=row['original_sha256'], frames=row['frames']))

omitted = []
members = {}
for file in sorted(raw.iterdir()):
    if not file.is_file():
        continue
    if file.name.endswith('-final-paint.json'):
        assert digest(file.read_bytes()) in {r['final_sha256'] for r in comparison['prior_records']}
        omitted.append(dict(path=str(file), bytes=file.stat().st_size, sha256=digest(file.read_bytes()), reason='prior complete record retained in raw; existing original archive reused'))
        continue
    if file.name in ['evidence-receipt.json']:
        continue
    members['raw/' + file.name] = file.read_bytes()
for name in sources:
    members['source/' + name] = (repo / name).read_bytes()
members['source/production.diff'] = subprocess.check_output(['git', 'diff', '--', *sources], cwd=repo)
members['source/base.txt'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo)
members['verification/distinct-tests.json'] = json.dumps(names, indent=2).encode()
archive = out / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, data in members.items():
        zipped.writestr(name, data)
with zipfile.ZipFile(archive) as zipped:
    assert set(zipped.namelist()) == set(members)
    for name, data in members.items():
        assert digest(zipped.read(name)) == digest(data)
manifest = dict(base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    raw_directory=str(raw), distinct_passing_tests=232, exact_complete_frames=3240,
    new_complete_frames=320, original_double_build_frames=224, final_builds_per_new_frame=1,
    comparison_normalization=False, test_executable_sha256=comparison['executable_sha256'],
    production_startup=json.loads((raw / 'startup.json').read_text('utf-8')),
    original_records=original_records, unarchived_prior_final_records=omitted,
    archive=dict(file='evidence.zip', bytes=archive.stat().st_size, sha256=digest(archive.read_bytes())),
    members=[dict(path=name, bytes=len(data), sha256=digest(data)) for name, data in members.items()],
    limits=['CPU draw records are not native screenshots or GPU timings.', 'Full workspace and final cross-platform CI remain unproven.',
        'Current PR 604 head is unchanged; this local follow-up is not covered by its CI.'])
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False), 'utf-8')
(raw / 'evidence-receipt.json').write_text(json.dumps(manifest['archive'], indent=2), 'utf-8')
print(json.dumps(dict(members=len(members), archive=manifest['archive'], distinct_passing_tests=232, exact_complete_frames=3240)), flush=True)
