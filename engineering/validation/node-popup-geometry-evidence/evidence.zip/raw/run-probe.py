import ast, hashlib, json, os, re, subprocess, sys
from pathlib import Path

p = Path(__file__).parent
stage = sys.argv[1]
rows = [json.loads(l) for l in (p / 'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
assert rows[-1] == dict(reason='build-finished', success=True)
exe = Path([r['executable'] for r in rows if r.get('reason') == 'compiler-artifact' and r['target']['name'] == 'motion-studio' and r.get('executable')][-1])
env = os.environ.copy()
env.pop('RUST_MIN_STACK', None)
env['MOTION_LOG'] = 'info'
env['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + env['PATH']
receipts = []
for index, name in enumerate(['choice_popups_build_geometry_once_while_preserving_navigation_and_history', 'record_complete_choice_popup_frames_for_original_path_comparison']):
    local = env.copy()
    if index == 1:
        local['MOTION_NODE_POPUP_EVIDENCE'] = str(p / (stage + '-paint.json'))
    command = [str(exe), '--exact', 'node_editor::view::frame_cards_tests::popup_geometry::' + name, '--test-threads=1', '--nocapture']
    result = subprocess.run(command, env=local, capture_output=True)
    (p / f'{stage}-{index}.stdout').write_bytes(result.stdout)
    (p / f'{stage}-{index}.stderr').write_bytes(result.stderr)
    row = dict(command=command, exit=result.returncode, expected_exit=101 if stage == 'before' and index == 0 else 0, executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest())
    receipts.append(row)
    print(json.dumps(row), flush=True)
(p / (stage + '-tests.json')).write_text(json.dumps(receipts, indent=2), 'utf-8')
assert all(r['exit'] == r['expected_exit'] for r in receipts)
if stage == 'before':
    match = re.search(r'one card build for choice popup frames: (\[.*\])', (p / 'before-0.stderr').read_text('utf-8'))
    assert match, 'failure is not the geometry-count negative control'
    counts = ast.literal_eval(match[1])
    assert len(counts) == 320 and all(ports == builds * nodes for _, builds, ports, nodes in counts)
    (p / 'before-counts.json').write_text(json.dumps(counts, indent=2), 'utf-8')
    print(json.dumps(dict(frames=len(counts), double_build_frames=sum(r[1] == 2 for r in counts))), flush=True)
else:
    before = json.loads((p / 'before-paint.json').read_text('utf-8'))
    after = json.loads((p / (stage + '-paint.json')).read_text('utf-8'))
    assert len(before) == len(after) == 320 and before == after
    (p / 'comparison.json').write_text(json.dumps(dict(frames=320, exact_equal=True, normalization=False, executable_sha256=receipts[0]['executable_sha256']), indent=2), 'utf-8')
