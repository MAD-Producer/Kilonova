import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

out = Path(__file__).parent
root = Path.cwd()
phases = ['diagnostics-native-compile', 'diagnostics-all', 'final-viewer-native',
          'final-capture-context', 'final-precision-capture', 'final-cell-inspection',
          'diagnostics-verification-wrapper']
compiled = json.loads((out / 'diagnostics-native-compile.json').read_text(encoding='utf-8'))
assert compiled['exit_code'] == 0
assert compiled['source_before'] == compiled['source_after']
members = {}
for phase in phases:
    meta = json.loads((out / (phase + '.json')).read_text(encoding='utf-8'))
    assert meta['exit_code'] == 0, phase
    assert meta['source_before'] == meta['source_after'] == compiled['source_after'], phase
    for extension in ['json', 'stdout', 'stderr']:
        name = phase + '.' + extension
        members['raw/' + name] = (out / name).read_bytes()
for name, digest in compiled['source_after'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
for directory in ['native-child', 'final-native-child', 'final-capture-context-child']:
    files = sorted((out / directory).rglob('*'))
    assert files, directory
    for path in files:
        if path.is_file():
            members['raw/' + path.relative_to(out).as_posix()] = path.read_bytes()
for name in ['package.py', 'run.py', 'test.ps1', 'verify.py',
             'listed-diagnostics-tests.txt', 'verified-executable.json']:
    members['raw/' + name] = (out / name).read_bytes()
members['raw/diagnostics-owner-audit.json'] = (out.parent / 'viewer-capture-errors/diagnostics-owner-audit.json').read_bytes()
paths = ['desktop/app/src/diagnostics.rs', 'desktop/app/src/main.rs',
         'desktop/app/src/diagnostics/native_error_tests.rs',
         'desktop/app/src/diagnostics/tests.rs']
for name in paths:
    members['source/current/' + name] = (root / name).read_bytes()
for name in paths:
    if name.endswith('native_error_tests.rs'):
        continue
    members['source/before/' + name] = subprocess.check_output(['git', 'show', '707c9d90:' + name], cwd=root)
members['change.patch'] = subprocess.check_output(['git', 'diff', '--', *paths], cwd=root)
identity = json.loads(members['raw/verified-executable.json'])
assert identity['source'] == compiled['source_after']
for phase, count in [('diagnostics-all',len(identity['diagnostics_tests']))] + [(name,1) for name in phases[2:6]]:
    assert f'{count} passed; 0 failed; 0 ignored' in members['raw/' + phase + '.stdout'].decode('utf-8'), phase
members['scope.json'] = json.dumps({
    'base':compiled['head'], 'issue':138,
    'diagnostics_tests':identity['diagnostics_tests'], 'viewer_regressions':4,
    'actual_faults':['parent path is a file','rename destination is an existing directory'],
    'native_identity':'Real reporter replies preserve std::io::Error and OS code; clones share their Host source; display text cannot forge the native type',
    'default_observation':'Controlled report lock proves Info start before snapshot; two Errors in file and stderr, none in stdout',
    'recovery':'Original file/directory and records preserved, temporary file removed, healthy export and checkpoint work',
    'limits':['JSON serialization source retained, but impossible Value encoding failure not injected',
              'Disk-full/fsync hardware failure not injected','Sentry delivery behavior unchanged',
              'Remaining issue-138 providers and remote CI are outside this evidence'],
}, ensure_ascii=False, indent=2).encode('utf-8')
members['manifest.json'] = json.dumps({name: {
    'sha256':hashlib.sha256(data).hexdigest(), 'bytes':len(data)
} for name,data in sorted(members.items())}, indent=2).encode('utf-8')
archive = root / 'engineering/validation/diagnostics-native-errors-evidence.zip'
assert not archive.exists(), 'Published evidence stays immutable'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in members.items():
        z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.namelist() == list(members)
    for name,data in members.items():
        assert z.read(name) == data, name
receipt = {'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
           'bytes':archive.stat().st_size, 'members':len(members),
           'diagnostics_passed':len(identity['diagnostics_tests']), 'viewer_passed':4}
(out / 'package-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
