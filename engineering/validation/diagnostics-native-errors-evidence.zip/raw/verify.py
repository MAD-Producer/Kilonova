import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

out = Path(__file__).parent
root = Path.cwd()
compiled = json.loads((out / 'diagnostics-native-compile.json').read_text(encoding='utf-8'))
assert compiled['exit_code'] == 0
assert compiled['source_before'] == compiled['source_after']
for name, digest in compiled['source_after'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
programs = []
for line in (out / 'diagnostics-native-compile.stdout').read_text(encoding='utf-8').splitlines():
    event = json.loads(line)
    if event.get('reason') == 'compiler-artifact' and event.get('target', {}).get('name') == 'motion-studio' and event.get('executable'):
        programs.append(event['executable'])
assert len(programs) == 1
program = Path(programs[0])
identity = hashlib.file_digest(program.open('rb'), 'sha256').hexdigest()
listed = subprocess.check_output([str(program), 'diagnostics::', '--list'], encoding='utf-8')
(out / 'listed-diagnostics-tests.txt').write_text(listed, encoding='utf-8')
names = [line.removesuffix(': test') for line in listed.splitlines() if line.endswith(': test')]
existing = re.findall(r'#\[test\]\s*fn (\w+)\(', (root / 'desktop/app/src/diagnostics/tests.rs').read_text(encoding='utf-8'))
assert existing
assert all('diagnostics::tests::' + name in names for name in existing)
assert 'diagnostics::native_error_tests::actual_reporter_keeps_native_io_replies_default_channels_and_recovers' in names
(out / 'verified-executable.json').write_text(json.dumps({'path':str(program), 'sha256':identity,
    'source':compiled['source_after'], 'diagnostics_tests':names}, indent=2), encoding='utf-8')
os.environ.pop('MOTION_LOG', None)
os.environ['MOTION_VIEWER_CAPTURE_ERROR_ARTIFACTS'] = str(out / 'final-native-child')
os.environ['MOTION_CAPTURE_CONTEXT_ARTIFACTS'] = str(out / 'final-capture-context-child')
for phase, selection, expected in [
    ('diagnostics-all', 'diagnostics::', len(names)),
    ('final-viewer-native', 'engine::viewer_capture_error_tests::', 1),
    ('final-capture-context', 'engine::capture_context_tests::', 1),
    ('final-precision-capture', 'engine::precision_capture_tests::', 1),
    ('final-cell-inspection', 'engine::viewer_frame::native::inspection::', 1),
]:
    code = subprocess.run([sys.executable, str(out / 'run.py'), phase,
        str(program), selection, '--test-threads=1', '--nocapture']).returncode
    if code:
        raise SystemExit(code)
    meta = json.loads((out / (phase + '.json')).read_text(encoding='utf-8'))
    assert meta['source_before'] == meta['source_after'] == compiled['source_after']
    text = (out / (phase + '.stdout')).read_text(encoding='utf-8')
    assert f'{expected} passed; 0 failed; 0 ignored' in text, phase
assert hashlib.file_digest(program.open('rb'), 'sha256').hexdigest() == identity
print(json.dumps({'diagnostics_passed':len(names), 'viewer_regressions_passed':4,
                  'source_and_executable_stable':True}))
