import json, os, subprocess, sys
from pathlib import Path

out = Path(__file__).parent
prefix = sys.argv[1] + '-' if len(sys.argv) > 1 else ''
def run(phase, args, env=None):
    return subprocess.run([sys.executable, str(out / 'run.py'), prefix + phase, *args], env=env).returncode

if len(sys.argv) > 2:
    assert len(sys.argv) == 4 and sys.argv[2] == '--executable'
    artifacts = [str(Path(sys.argv[3]).resolve(strict=True))]
else:
    code = run('freeze-sync-compile', ['cargo','test','--locked','-p','motion-desktop','--features','ffmpeg',
        '--bin','motion-studio','--no-run','--message-format=json'])
    assert code == 0, code
    artifacts = []
    for line in (out / (prefix + 'freeze-sync-compile.stdout')).read_text(encoding='utf-8').splitlines():
        value = json.loads(line)
        if value.get('reason') == 'compiler-artifact' and value.get('target',{}).get('name') == 'motion-studio' and value.get('executable'):
            artifacts.append(value['executable'])
assert len(artifacts) == 1, artifacts
test = 'engine::failure::tests::asynchronous_movie_freeze_keeps_command_context_before_completion_and_during_panic'
for phase,control,expected in [('freeze-sync-positive',None,0),('freeze-wrong-reason-negative','wrong_reason',101),('freeze-no-reply-negative','no_reply',101)]:
    env = os.environ.copy()
    for key in ['MOTION_LOG','MOTION_FREEZE_LOG_TEST_CHILD','MOTION_FREEZE_LOG_TEST_CONTROL']:
        env.pop(key,None)
    if control: env['MOTION_FREEZE_LOG_TEST_CONTROL'] = control
    env['MOTION_FREEZE_LOG_TEST_EVIDENCE'] = str(out / (prefix + phase))
    code = run(phase, [artifacts[0], '--exact', test, '--test-threads=1', '--nocapture'], env)
    assert code == expected, (phase,code,expected)
    stdout = (out / (prefix + phase + '.stdout')).read_text(encoding='utf-8')
    stderr = (out / (prefix + phase + '.stderr')).read_text(encoding='utf-8')
    if control == 'wrong_reason':
        assert 'controlled unexpected freeze cause' in stderr and 'freeze log child exceeded 20s' not in stderr
        assert '0 passed; 1 failed' in stdout
    elif control == 'no_reply':
        assert 'freeze log child exceeded 20s' in stderr and '0 passed; 1 failed' in stdout
        assert json.loads((out / (prefix + phase + '.json')).read_text(encoding='utf-8'))['elapsed_seconds'] >= 20
    else: assert '1 passed; 0 failed' in stdout
    assert all((out / (prefix + phase) / name).is_file() for name in ['worker.stdout','worker.stderr','worker.log'])
code = run('native-context-integrated', [artifacts[0], 'engine::error::tests', '--test-threads=1','--nocapture'])
assert code == 0, code
print('Corrected positive and both real negative controls completed; native context tests passed.')
