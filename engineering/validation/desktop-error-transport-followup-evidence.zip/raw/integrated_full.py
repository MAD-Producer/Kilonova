import hashlib
import json
import subprocess
import sys
from pathlib import Path

out = Path(__file__).parent
root = Path.cwd()
compiled = json.loads((out / 'integrated-freeze-sync-compile.json').read_text(encoding='utf-8'))
assert compiled['exit_code'] == 0
assert compiled['source_before'] == compiled['source_after']
for name, sha in compiled['source_after'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha, name
programs = []
for line in (out / 'integrated-freeze-sync-compile.stdout').read_text(encoding='utf-8').splitlines():
    event = json.loads(line)
    if (event.get('reason') == 'compiler-artifact'
            and event.get('target', {}).get('name') == 'motion-studio'
            and event.get('executable')):
        programs.append(event['executable'])
assert len(programs) == 1, programs
program = Path(programs[0])
identity = {'path':str(program), 'sha256':hashlib.file_digest(program.open('rb'), 'sha256').hexdigest(),
            'compile_head':compiled['head'], 'compile_command':compiled['command'],
            'desktop_scope':'Entire compiled test executable, no name filter, one test thread',
            'host_scope':'Entire motion-host crate with its default gpu-tests feature',
            'old_run_disposition':'Unfinished a9d1bf04 run intentionally stopped after integration; not a pass'}
(out / 'integrated-full-executable.json').write_text(json.dumps(identity, indent=2), encoding='utf-8')
def run(phase, command):
    print(phase + ' start', flush=True)
    result = subprocess.run([sys.executable, str(out / 'run.py'), phase, *command])
    print(phase + ' exit=' + str(result.returncode), flush=True)
    return result.returncode

code = run('integrated-desktop-full', [str(program), '--test-threads=1', '--nocapture'])
assert hashlib.file_digest(program.open('rb'), 'sha256').hexdigest() == identity['sha256']
if code:
    raise SystemExit(code)
code = run('integrated-host-full', ['cargo', 'test', '--locked', '-p', 'motion-host',
                                  '--', '--test-threads=1', '--nocapture'])
raise SystemExit(code)
