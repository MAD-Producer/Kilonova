. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:CARGO_TARGET_DIR='E:/Dev/aem/.tools/viewer-inspection/native-target'
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:LIBCLANG_PATH='E:/Dev/aem/.tools/python-libclang/clang/native'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
$env:MOTION_ERROR_TRANSPORT_EVIDENCE='E:/Dev/aem/artifacts/issue-goal-current/desktop-error-transport/native-worker'
python E:/Dev/aem/artifacts/issue-goal-current/desktop-error-transport/run.py @args

exit $LASTEXITCODE
