import hashlib, json, subprocess, zipfile
from pathlib import Path

out = Path(__file__).parent
root = Path.cwd()
members = {}
phases = [
    'complete-desktop-host', 'tracking-video-adaptation', 'atlas-text-contract',
    'freeze-panic-recompiled', 'baseline-freeze-control', 'panic-phase-wrapper',
    'panic-phase-diagnostic', 'native-context-final', 'freeze-controls-wrapper',
    'freeze-sync-compile', 'freeze-sync-positive', 'freeze-observer-controls-wrapper',
    'observer-freeze-sync-compile', 'observer-freeze-sync-positive',
    'observer-freeze-wrong-reason-negative', 'observer-freeze-no-reply-negative',
    'observer-native-context-integrated', 'complete-desktop-host-verified',
    'complete-desktop-host-pdb-recovered',
    'complete-desktop-host-space-recovered',
    'integrated-main-all-targets', 'integrated-main-all-targets-quoted',
    'integrated-freeze-controls-wrapper', 'integrated-freeze-sync-compile',
    'integrated-freeze-sync-positive', 'integrated-freeze-wrong-reason-negative',
    'integrated-freeze-no-reply-negative', 'integrated-native-context-integrated',
    'integrated-desktop-host-full-wrapper', 'integrated-desktop-full', 'integrated-host-full',
]
for phase in phases:
    for ext in ['json', 'stdout', 'stderr']:
        path = out / f'{phase}.{ext}'
        members[f'raw/{path.name}'] = path.read_bytes()

superseded = json.loads(members['raw/complete-desktop-host-space-recovered.json'])
assert superseded['exit_code'] == 4294967295
assert superseded['source_before'] == superseded['source_after']
full = json.loads(members['raw/integrated-desktop-full.json'])
assert full['exit_code'] == 0, full.get('exit_code')
assert full['source_before'] == full['source_after']
integrated = json.loads(members['raw/integrated-main-all-targets-quoted.json'])
assert integrated['exit_code'] == 0
assert integrated['source_before'] == integrated['source_after']
assert full['source_before'] == integrated['source_before']
host = json.loads(members['raw/integrated-host-full.json'])
assert host['exit_code'] == 0
assert host['source_before'] == host['source_after'] == integrated['source_before']
for name, expected in integrated['source_after'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
for phase, code in [('integrated-freeze-sync-positive', 0),
                    ('integrated-freeze-wrong-reason-negative', 101),
                    ('integrated-freeze-no-reply-negative', 101),
                    ('integrated-native-context-integrated', 0)]:
    meta = json.loads(members[f'raw/{phase}.json'])
    assert meta['exit_code'] == code
    assert meta['source_before'] == meta['source_after'] == integrated['source_before']
    assert meta['env']['MOTION_LOG'] is None

# Main integration changes the tested source. The interrupted older run does
# not substitute for the successful full execution required above.
all_names = set(superseded['source_after']) | set(integrated['source_after'])
delta = {name: {'superseded': superseded['source_after'].get(name),
                'integration': integrated['source_after'].get(name)}
         for name in sorted(all_names)
         if superseded['source_after'].get(name) != integrated['source_after'].get(name)}
git_delta = subprocess.check_output(['git', 'diff', '--name-only', superseded['head'],
                                    integrated['head']], text=True).splitlines()
newline_only = {}
for name in sorted(set(delta) - set(git_delta)):
    old_blob = subprocess.check_output(['git', 'show', superseded['head'] + ':' + name])
    new_blob = subprocess.check_output(['git', 'show', integrated['head'] + ':' + name])
    assert old_blob == new_blob, name
    lf = old_blob.replace(b'\r\n', b'\n')
    variants = {'LF': hashlib.sha256(lf).hexdigest(),
                'CRLF': hashlib.sha256(lf.replace(b'\n', b'\r\n')).hexdigest()}
    assert delta[name]['superseded'] in variants.values(), name
    assert delta[name]['integration'] in variants.values(), name
    newline_only[name] = {'git_blob_unchanged': True, 'variant_sha256': variants,
                         'observed_sha256': delta[name]}
assert set(delta) <= set(git_delta) | set(newline_only)
for name in ['desktop/app/src/engine/failure/tests.rs',
             'desktop/app/src/engine/error.rs', 'desktop/app/src/engine/error/tests.rs',
             'desktop/app/src/logging.rs', 'desktop/app/src/engine/movie_freeze.rs']:
    assert name not in set(delta) - set(newline_only), name
members['source-scope-comparison.json'] = json.dumps({
    'interrupted_old_head': superseded['head'], 'integration_head': integrated['head'],
    'changed_sources': delta, 'git_changed_paths': git_delta,
    'newline_only': newline_only,
    'old_run_covers_integration': False,
    'integration_full_regression': {'desktop_head': full['head'], 'host_head': host['head']},
    'integration_checks': ['all-targets with ffmpeg/ai-depth/diagnostics',
                           'actual freeze positive and both negative controls',
                           'five native error/context checks', 'full desktop and host executions'],
}, indent=2).encode('utf-8')

for name in ['run.py', 'test.ps1', 'integration-test.ps1', 'freeze_controls.py', 'panic_phase.py',
             'integrated_full.py', 'integrated-full-executable.json', 'pre-integration-run-termination.json',
             'panic-phase-restoration.json', 'obsolete-run-termination.json',
             'freeze-sync-proposed.patch', 'freeze-sync-proposed.rs',
             'link-cleanup-receipt.json', 'cleanup-review-disposition.json', 'completed-cache-compression-targets.json',
             'completed-cache-compression.stdout', 'completed-cache-compression.stderr',
             'second-pdb-isolation.json', 'completed-cache-compression-more-targets.json',
             'completed-cache-compression-more.stdout', 'completed-cache-compression-more.stderr',
             'followup-package-initial-failure.json',
             'package_followup.py']:
    members[f'raw/{name}'] = (out / name).read_bytes()
for dirname in ['freeze-sync-positive', 'observer-freeze-sync-positive',
                'observer-freeze-wrong-reason-negative', 'observer-freeze-no-reply-negative',
                'panic-phase-child', 'focused-native-snapshot']:
    for path in sorted((out / dirname).rglob('*')):
        if path.is_file():
            members['raw/' + path.relative_to(out).as_posix()] = path.read_bytes()
for dirname in ['integrated-freeze-sync-positive', 'integrated-freeze-wrong-reason-negative',
                'integrated-freeze-no-reply-negative', 'native-worker', 'integrated-native-worker']:
    for path in sorted((out / dirname).rglob('*')):
        if path.is_file():
            members['raw/' + path.relative_to(out).as_posix()] = path.read_bytes()

for name in ['desktop/app/src/engine/failure/tests.rs', 'desktop/app/src/logging.rs',
             'desktop/app/src/engine/error/tests.rs', 'desktop/app/src/engine.rs',
             'desktop/app/src/engine/frame_capture.rs', 'desktop/app/src/engine/movie_freeze.rs',
             'crates/motion-host/src/error.rs']:
    members['source/current/' + name] = (root / name).read_bytes()
name = 'desktop/app/src/engine/failure/tests.rs'
members['source/before-approved-synchronization/' + name] = subprocess.check_output(
    ['git', 'show', '056d8672:' + name])
restore = json.loads(members['raw/panic-phase-restoration.json'])
assert restore['restored']
assert hashlib.sha256(members['source/current/desktop/app/src/logging.rs']).hexdigest() == restore['original_sha256']

members['scope.json'] = json.dumps({
    'scope': 'Followup failure, diagnosis, approved synchronization and real controls; interrupted old regression; full desktop and host regression of the main-integration source.',
    'approval': 'User explicitly approved synchronization scope and negative controls; original five-second receive assertion and error/context checks remain.',
    'limitations': ['No production panic speedup', 'No actual OS thread-exhaustion injection',
        'Old full desktop run was stopped and is not a pass', 'Model/core evidence is a separate archive',
        'The superseded a9d1bf04 regression was intentionally interrupted and is not a pass',
        'Final remote checks and remaining issue-138 text providers are not covered by this local archive'],
}, ensure_ascii=False, indent=2).encode('utf-8')
manifest = {name: {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
            for name, data in sorted(members.items())}
members['manifest.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8')
archive = root / 'engineering/validation/desktop-error-transport-followup-evidence.zip'
assert not archive.exists(), 'Keep any previously published archive immutable'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in members.items():
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.namelist() == list(members)
    for name, data in members.items():
        assert z.read(name) == data, name
receipt = {'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'bytes': archive.stat().st_size, 'members': len(members)}
(out / 'followup-package-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt))
