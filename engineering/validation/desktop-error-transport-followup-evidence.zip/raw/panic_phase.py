import hashlib, json, subprocess, sys
from pathlib import Path

out = Path(__file__).parent
source = Path('desktop/app/src/logging.rs')
original = source.read_bytes()
needle = b'''        log::error!(
            "panic command={:?}: {info}\\n{}",
            crate::engine::current_command(),
            Backtrace::force_capture()
        );
        IN_PANIC_HOOK.set(false);
        original(info);'''
replacement = b'''        // Temporary diagnostic only: retain formatting under the same logger
        // lock and leave all existing assertions, deadlines and hooks intact.
        struct PhaseTrace(Backtrace);
        impl std::fmt::Display for PhaseTrace {
            fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                let began = std::time::Instant::now();
                eprintln!("PANIC_PHASE format_start command={:?}", crate::engine::current_command());
                let result = std::fmt::Display::fmt(&self.0, f);
                eprintln!("PANIC_PHASE format_done command={:?} elapsed_us={}", crate::engine::current_command(), began.elapsed().as_micros());
                result
            }
        }
        let began = std::time::Instant::now();
        let backtrace = Backtrace::force_capture();
        eprintln!("PANIC_PHASE capture_done command={:?} elapsed_us={}", crate::engine::current_command(), began.elapsed().as_micros());
        log::error!(
            "panic command={:?}: {info}\\n{}",
            crate::engine::current_command(),
            PhaseTrace(backtrace)
        );
        eprintln!("PANIC_PHASE logger_done command={:?} elapsed_us={}", crate::engine::current_command(), began.elapsed().as_micros());
        IN_PANIC_HOOK.set(false);
        let previous = std::time::Instant::now();
        original(info);
        eprintln!("PANIC_PHASE original_hook_done command={:?} elapsed_us={}", crate::engine::current_command(), previous.elapsed().as_micros());'''
assert original.count(needle) == 1
mutated = original.replace(needle, replacement, 1)
meta = {'original_sha256': hashlib.sha256(original).hexdigest(), 'diagnostic_sha256': hashlib.sha256(mutated).hexdigest()}
try:
    source.write_bytes(mutated)
    # Direct child mode keeps its default-level log and every original hook
    # phase available after either success or a real timeout.
    import os
    env = os.environ.copy()
    env['MOTION_FREEZE_LOG_TEST_CHILD'] = str(out / 'panic-phase-child')
    env.pop('MOTION_LOG', None)
    result = subprocess.run([sys.executable, str(out / 'run.py'), 'panic-phase-diagnostic',
        'cargo', 'test', '--locked', '-p', 'motion-desktop', '--features', 'ffmpeg',
        '--bin', 'motion-studio', 'engine::failure::tests::asynchronous_movie_freeze_keeps_command_context_before_completion_and_during_panic',
        '--', '--exact', '--test-threads=1', '--nocapture'], env=env)
    meta['diagnostic_exit_code'] = result.returncode
finally:
    source.write_bytes(original)
    meta['restored_sha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
    meta['restored'] = source.read_bytes() == original
    (out / 'panic-phase-restoration.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
assert meta['restored']
print(json.dumps(meta))
