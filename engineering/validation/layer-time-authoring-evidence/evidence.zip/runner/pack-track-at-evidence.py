from pathlib import Path
import json,hashlib,zipfile,subprocess,shutil,re
from PIL import Image,ImageChops
repo=Path('E:/Dev/aem/.worktrees/layer-time-mapping');base=Path('E:/Dev/aem/artifacts/issue-goal-current');root=base/'track-at-final-validation'
out=repo/'engineering/validation/layer-time-authoring-evidence';out.mkdir(exist_ok=True)
inputs=json.loads((base/'track-at-final-build-inputs.json').read_text(encoding='utf-8'))
for name,digest in inputs['sources'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
results=json.loads((root/'results.json').read_text(encoding='utf-8'));assert all(r['code']==0 for r in results)
assert any(r['scope']=='native' for r in results)
passed=set();ignored=set()
for r in results:
 prefix='core:'+r['scope']+':' if r['scope'].startswith('core-') else 'desktop:'
 passed.update(prefix+name for name in r['passed']);ignored.update(prefix+name for name in r['ignored'])
ignored-=passed
images=sorted((root/'native').rglob('*.png'));assert len(images)==8
raw_images={str(p.relative_to(root/'native')):hashlib.sha256(p.read_bytes()).hexdigest() for p in images}
for tag in ['zh-main-forward','en-floating-reverse']:
 source=root/'native'/tag/'after.png';target=out/(tag+'.png');box=(16,24,448,232)
 original=Image.open(source);original.crop(box).save(target)
 assert ImageChops.difference(Image.open(target),original.crop(box)).getbbox() is None
# Stage the source first so untracked modules are represented in this patch.
source_paths=list(inputs['sources']);subprocess.run(['git','add','--',*source_paths],cwd=repo,check=True)
patch=subprocess.check_output(['git','diff','--cached','--binary','--',*source_paths],cwd=repo);(root/'source.patch').write_bytes(patch)
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for path in sorted(root.rglob('*')):
  if path.is_file() and path.suffix.lower() in ['.json','.log','.png','.patch']:
   z.write(path,'final/'+path.relative_to(root).as_posix())
 for path in sorted(base.glob('track-at-*')):
  if path.is_file() and path.suffix.lower() in ['.log','.json','.txt']:
   z.write(path,'attempts/'+path.name)
 for name in ['run-track-at-final.py','pack-track-at-evidence.py']:
  z.write(base/name,'runner/'+name)
manifest={'baseCommit':inputs['base'],'branch':'feat/layer-time-mapping','sources':inputs['sources'],
 'sourcePatchSha256':hashlib.sha256(patch).hexdigest(),'testBinaries':json.loads((root/'test-binaries.json').read_text()),
 'testCount':{'uniquePassed':len(passed),'core':len([n for n in passed if n.startswith('core:')]),'desktopIncludingNative':len([n for n in passed if n.startswith('desktop:')]),'notRunManual':len(ignored)},
 'passed':sorted(passed),'notRunManual':sorted(ignored),'actualNativeImages':raw_images,
 'presentationImages':{p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'crop':[16,24,448,232]} for p in out.glob('*.png')},
 'separateProcesses':{'capture':json.loads((root/'native/capture-process.json').read_text()),'reopen':json.loads((root/'native/reopen-process.json').read_text())},
 'archive':{'file':'evidence.zip','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},
 'limits':['Windows, pixel ratio 1; raw effect-control inputs on real GPU window surfaces, not OS pointer injection or full chrome focus routing.',
 'Existing warnings preserved. First rustc access violation retained as a console excerpt only; complete raw output was not redirected for that attempt.',
 'Clock observation stdout/stderr assertions run in a subprocess; copied default file log retained. Native worker child stdout/stderr retained directly.',
 'No claim that issue 257 is complete; remaining entry points and real media/device acceptance are listed in the completion document.']}
assert manifest['separateProcesses']['capture']['pid']!=manifest['separateProcesses']['reopen']['pid']
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'counts':manifest['testCount'],'archiveBytes':archive.stat().st_size,'binary':manifest['testBinaries'].get('motion-studio-tested.exe')},ensure_ascii=False))
