import os,sys,subprocess,json,hashlib,shutil,re,time
from pathlib import Path
repo=Path('E:/Dev/aem/.worktrees/layer-time-mapping')
base=Path('E:/Dev/aem/artifacts/issue-goal-current')
root=base/'track-at-final-validation';root.mkdir(exist_ok=True)
inputs=json.loads((base/'track-at-final-build-inputs.json').read_text(encoding='utf-8'))
for name,digest in inputs['sources'].items():
    assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest, f'source changed after final build started: {name}'
env=os.environ.copy();env['TEMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp';env['TMP']=env['TEMP']
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
env.pop('MOTION_LOG',None);env['MOTION_TRACK_AT_NATIVE_ARTIFACTS']=str(root/'native')
env['MOTION_TRACK_AT_FAULT_LOG_COPY']=str(root/'clock-fault-file.log')
target=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps')
bin_dir=root/'binaries';bin_dir.mkdir(exist_ok=True)
source=target/'motion_studio-b34b3a7e7eb835e8.exe';exe=bin_dir/'motion-studio-tested.exe';shutil.copy2(source,exe)
core={}
log=(base/'track-at-final-build.log').read_text(encoding='utf-8')
compiled=dict(re.findall(r'Executable tests[\\/]([^.]+)\.rs \(([^)]+)\)',log))
for name in ['track_at','local_keyframes','layer_time','layer_time_clipboard','command_registry']:
    source=Path(compiled[name])
    dest=bin_dir/(name+'.exe');shutil.copy2(source,dest);core[name]=dest
records=[]
def run(scope,args):
    start=time.monotonic();p=subprocess.run([str(a) for a in args],cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (root/(scope+'-stdout.log')).write_bytes(p.stdout);(root/(scope+'-stderr.log')).write_bytes(p.stderr)
    text=p.stdout.decode('utf-8',errors='replace')
    passed=re.findall(r'^test ([^\r\n]+?) \.\.\. ok$',text,re.M)
    ignored=re.findall(r'^test ([^\r\n]+?) \.\.\. ignored[^\r\n]*$',text,re.M)
    records.append({'scope':scope,'command':[str(a) for a in args],'code':p.returncode,'seconds':time.monotonic()-start,'passed':passed,'ignored':ignored})
    (root/'results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    print(scope,p.returncode,len(passed),'passed',len(ignored),'ignored',flush=True)
for name,path in core.items():run('core-'+name,[path,'--nocapture','--test-threads=1'])
for name in ['panels::effect_controls','panels::key_navigation','panels::numeric','panels::properties','panels::transform_controls','engine::keyframe_timing']:
    run('desktop-'+name.replace('::','-'),[exe,name,'--nocapture','--test-threads=1'])
if not any(r['code'] for r in records):
    run('native',[exe,'--exact','panels::effect_controls::mapped_authoring_tests::native::mapped_numeric_native_worker_pixels_errors_history_and_reopen','--ignored','--nocapture','--test-threads=1'])
binaries={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in bin_dir.glob('*.exe')}
(root/'test-binaries.json').write_text(json.dumps(binaries,indent=2),encoding='utf-8')
raise SystemExit(any(r['code'] for r in records))
