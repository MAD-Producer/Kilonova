import hashlib, json, os, subprocess, textwrap, time, traceback
from pathlib import Path

p=Path(__file__).parent
root=Path.cwd()
out=p/'release-native'
out.mkdir(exist_ok=True)
rows=[json.loads(l) for l in (p/'release-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
assert rows[-1]==dict(reason='build-finished',success=True)
binary=Path([r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1])
assert binary.parent.name=='release'
source=(root/'tools/ci_desktop.py').read_text('utf-8')
published=subprocess.check_output(['git','show','20f3310126f169ff1f1dc4c8303bc2004079a632:tools/ci_desktop.py']).decode('utf-8')
assert source==published
start=source.index('        node_report = output / f"node-smoke-{locale}.json"')
end=source.index('\n    verify_mcp(binary, output)',start)
block=textwrap.dedent(source[start:end])
(out/'unchanged-ci-node-verifier.py').write_text(block,'utf-8')
local=out/'appdata';local.mkdir(exist_ok=True)
temp=out/'tmp';temp.mkdir(exist_ok=True)
os.environ['LOCALAPPDATA']=str(local)
os.environ['TEMP']=os.environ['TMP']=str(temp)
os.environ.pop('RUST_MIN_STACK',None)
os.environ['MOTION_LOG']='info'
os.environ['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+os.environ['PATH']
receipt=dict(head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),
    profile='release',ffmpeg=True,compiler_overrides=False,
    executable_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
    ci_verifier_sha256=hashlib.sha256(source.encode()).hexdigest(),
    verifier_block_sha256=hashlib.sha256(block.encode()).hexdigest(),
    rust_min_stack_overridden=False,unchanged_timeout_seconds=125,
    controlled_appdata=str(local),controlled_temp=str(temp),records=[],
    physical_input_verified=False)
def save(): (out/'receipt.json').write_text(json.dumps(receipt,indent=2),'utf-8')
def bytes_of(value): return value.encode('utf-8') if isinstance(value,str) else value or b''
save()
try:
    for locale in ['en','zh']:
        begun=time.monotonic()
        row=dict(locale=locale,state='in_flight',command=[str(binary),'--node-smoke',str(out/f'node-smoke-{locale}.json'),'--locale',locale])
        receipt['records'].append(row);save()
        print('Unchanged release native acceptance started: '+locale,flush=True)
        exec(compile(block,str(out/'unchanged-ci-node-verifier.py'),'exec'),dict(Path=Path,json=json,subprocess=subprocess,binary=binary,output=out,locale=locale))
        row.update(state='verified',elapsed_seconds=time.monotonic()-begun);save()
        print('Unchanged release native acceptance verified: '+locale,flush=True)
except BaseException as error:
    row.update(state='failed',elapsed_seconds=time.monotonic()-begun,cause_type=type(error).__name__)
    (out/'failure.txt').write_text(traceback.format_exc(),'utf-8')
    if isinstance(error,subprocess.TimeoutExpired):
        (out/'timeout.stdout').write_bytes(bytes_of(error.stdout))
        (out/'timeout.stderr').write_bytes(bytes_of(error.stderr))
    raise
finally:
    receipt['native_verified']=len(receipt['records'])==2 and all(r['state']=='verified' for r in receipt['records'])
    save()
