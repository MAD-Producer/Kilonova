import json, os, subprocess
from pathlib import Path
RAW=Path('E:/Dev/aem/artifacts/issue-goal-current/pipeline-validation-poll')
def read(p):
    b=p.read_bytes()
    return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8-sig')
assert int(read(RAW/'desktop-build.exit').strip()) == 0
artifacts=[json.loads(line) for line in read(RAW/'desktop-build.log').splitlines() if line.startswith('{')]
items=[v for v in artifacts if v.get('reason')=='compiler-artifact' and v.get('target',{}).get('name')=='motion-studio' and v.get('profile',{}).get('test') and v.get('executable')]
assert len(items)==1, [(v.get('target'),v.get('profile')) for v in items]
exe=items[0]['executable']
(RAW/'desktop-artifact.json').write_text(json.dumps(items[0],indent=2)+'\n',encoding='utf-8')
env=os.environ.copy()
env['MOTION_POINTWISE_FILE_ARTIFACTS']=str(RAW/'production-channels')
listed=subprocess.run([exe,'logging::pointwise_compile_tests','--list'],env=env,capture_output=True,text=True)
assert listed.returncode==0,listed.stderr
(RAW/'desktop-list.txt').write_text(listed.stdout,encoding='utf-8')
assert listed.stdout.count(': test\n')==2, listed.stdout
with (RAW/'desktop-final.log').open('wb') as output, (RAW/'desktop-final.stderr').open('wb') as error:
    result=subprocess.run([exe,'logging::pointwise_compile_tests','--test-threads=1','--nocapture'],env=env,stdout=output,stderr=error)
(RAW/'desktop-final.exit').write_text(str(result.returncode)+'\n',encoding='utf-8')
print(exe)
print(read(RAW/'desktop-final.log')[-2000:])
assert result.returncode==0, read(RAW/'desktop-final.stderr')[-2000:]
