import hashlib,json,re,tomllib,zipfile
from pathlib import Path
ROOT=Path('E:/Dev/aem/.worktrees/layer-time-mapping')
RAW=Path('E:/Dev/aem/artifacts/issue-goal-current/pipeline-validation-poll')
OUT=ROOT/'engineering/validation/pipeline-validation-poll-evidence'
DEPS=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps')
REGISTRY=Path('C:/Users/nova/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f')
def read(p):
    b=p.read_bytes()
    return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8-sig')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
SOURCES=['crates/motion-render/src/effect_gpu.rs','crates/motion-render/tests/gpu_failure_observation.rs','crates/motion-render/tests/wgpu_upgrade.rs','crates/motion-render/src/effect_gpu/pipeline_cache/tests.rs','crates/motion-render/src/renderer/snapshot_storage_tests.rs','desktop/app/src/logging/pointwise_compile_tests.rs','engineering/validation/pipeline-validation-poll.md']
results={}
for name,expected in [('render',3),('desktop-final',2),('cache',1),('snapshots',2),('workspace',0)]:
    code=int(read(RAW/(name+'.exit')).strip())
    assert code==0,(name,code)
    counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',read(RAW/(name+'.log')))
    assert all(int(f)==0 and int(i)==0 for _,f,i in counts)
    count=sum(int(n) for n,_,_ in counts)
    assert count==expected,(name,count)
    results[name]={'exit_code':code,'passed':count,'log':name+'.log'}
artifact=json.loads((RAW/'desktop-artifact.json').read_text(encoding='utf-8'))
assert artifact['profile']['test'] and artifact['profile']['debug_assertions'] and artifact['profile']['overflow_checks']
assert int(read(RAW/'desktop-build.exit').strip())==0
channels={}
for mode in ['portable','native','warm-cache/portable','warm-cache/native']:
    root=RAW/'production-channels'/mode
    counts={}
    for kind,path in [('file',root/'logs/motion-studio.log'),('stderr',root/'stderr.txt'),('stdout',root/'stdout.txt')]:
        body=read(path)
        lines=[line for line in body.splitlines() if 'motion_render::pointwise_compile' in line and 'phase=failure' in line]
        assert len(lines)==(0 if kind=='stdout' else 1),(mode,kind,len(lines))
        if kind!='stdout': assert 'ERROR' in lines[0],(mode,kind,lines)
        else: assert 'motion_render::pointwise_compile' not in body
        counts[kind]={'failure_records':len(lines),'sha256':sha(path)}
    channels[mode]=counts
lock=tomllib.loads((ROOT/'Cargo.lock').read_text(encoding='utf-8'))
packages={v['name']:{'version':v['version'],'checksum':v.get('checksum')} for v in lock['package'] if v['name'] in ['wgpu','wgpu-types']}
assert packages['wgpu']['version']=='30.0.1' and packages['wgpu-types']['version']=='30.0.1'
api_sources={'wgpu_native_scope':REGISTRY/'wgpu-30.0.1/src/backend/wgpu_core.rs','poll_type':REGISTRY/'wgpu-types-30.0.1/src/lib.rs'}
binaries=['motion_render-1fcc3fb8d09fa888.exe','wgpu_upgrade-caae6ee351c2f903.exe','gpu_failure_observation-7842539269294d3f.exe']
manifest={'base_commit':'6e6f66b5114574797f01cf7bf37d3bfc69acdcef','branch':'perf/scene-asset-storage','pr':589,'issue':126,'issue_complete':False,'results':results,'distinct_tests':8,'default_info_production_channels':channels,'desktop_test_profile':artifact['profile'],'desktop_test_linker_override':'-C link-arg=/DEBUG:NONE; only selected test executable, no Cargo profile or CI changes','source_sha256_raw_files':{p:sha(ROOT/p) for p in SOURCES},'binary_sha256':{p:sha(DEPS/p) for p in binaries}|{Path(artifact['executable']).name:sha(Path(artifact['executable']))},'dependency_api_evidence':{'locked':packages,'local_source_sha256':{key:sha(p) for key,p in api_sources.items()},'inspected_contract':'Native error scope returns ready(scope.error); Poll checks once without waiting for queue submission. No timing/FPS claim.'},'commands':['cargo test -p motion-render --test wgpu_upgrade --test gpu_failure_observation --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture','cargo rustc -p motion-desktop --bin motion-studio --profile test --features ffmpeg --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --message-format=json-render-diagnostics -- -C link-arg=/DEBUG:NONE','<verified desktop test artifact> logging::pointwise_compile_tests --test-threads=1 --nocapture','cargo test -p motion-render --lib native_pipeline_retirement_bounds_and_exact_static_proof --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture','cargo test -p motion-render --lib snapshot_storage_tests --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture','cargo check --workspace --all-targets --exclude motion-android --locked --features motion-desktop/ffmpeg,motion-host/diagnostics --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target'],'limits':['Native local tests only; cross-platform CI pending.','Combined simultaneous shader rejection and poll error not injected.','Synchronous driver compilation and whole-preview-frame allocation remain separate work.'],'ci':'pending for final head'}
OUT.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(OUT/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(RAW.rglob('*')):
        if p.is_file():z.write(p,'raw/'+p.relative_to(RAW).as_posix())
    for p in SOURCES:z.write(ROOT/p,'final-source/'+p)
manifest['evidence_zip_sha256']=sha(OUT/'evidence.zip')
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results))
