import os, subprocess, json, time, hashlib, re, sys
from pathlib import Path

root = Path(__file__).resolve().parent
deps = Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps')
env = os.environ.copy()
env['TEMP'] = env['TMP'] = 'E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + env['PATH']
env.pop('MOTION_LOG', None)
env['MOTION_MAPPED_SPATIAL_ERROR_ARTIFACTS'] = str(root / 'faults')
env['MOTION_SPATIAL_KEYFRAME_ERROR_ARTIFACTS'] = str(root / 'existing-faults')
env['MOTION_SPATIAL_TRACK_ARTIFACTS'] = str(root / 'storage')

# Exact Cargo outputs are supplied from this build, not a newest-file glob.
binaries = json.loads((root / 'binaries.json').read_text())
groups = [
    ('mapped-core', 'spatial_key_time', []),
    ('existing-core', 'spatial_keyframes', []),
    ('worker', 'motion_studio', ['engine::animation_action_tests::']),
    ('selection', 'motion_studio', ['panels::key_selection::tests::ui::spatial::']),
    ('roving', 'motion_studio', ['panels::animation_menu::roving::tests::']),
]
results = []
for name, stem, args in groups:
    if len(sys.argv) > 1 and name not in sys.argv[1:]:
        continue
    exe = Path(binaries[stem])
    before = hashlib.sha256(exe.read_bytes()).hexdigest()
    start = time.time()
    with (root / (name + '.log')).open('wb') as output:
        p = subprocess.run([str(exe), *args, '--nocapture', '--test-threads=1'],
                           stdout=output, stderr=subprocess.STDOUT, env=env)
    result = dict(group=name, exit=p.returncode, seconds=round(time.time()-start, 3),
                  exe=str(exe), exeSha256=before, args=args)
    log = (root / (name + '.log')).read_text(errors='replace')
    counts = re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', log)
    assert counts, log[-4000:]
    result.update(passed=int(counts[1]), failed=int(counts[2]), ignored=int(counts[3]))
    results.append(result)
    (root / ('results-' + '-'.join(sys.argv[1:]) + '.json' if len(sys.argv) > 1 else 'results.json')).write_text(json.dumps(results, indent=2))
    print(json.dumps(result), flush=True)
    assert hashlib.sha256(exe.read_bytes()).hexdigest() == before, 'binary changed during test run'
    if p.returncode:
        raise SystemExit(p.returncode)
assert all(r['passed'] > 0 for r in results), 'empty test filter'
