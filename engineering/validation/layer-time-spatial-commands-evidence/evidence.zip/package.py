from pathlib import Path
import json, hashlib, zipfile

raw = Path(__file__).resolve().parent
repo = Path('E:/Dev/aem/.worktrees/layer-time-mapping')
dest = repo / 'engineering/validation/layer-time-spatial-commands-evidence'
dest.mkdir(exist_ok=True)
sources = json.loads((raw / 'source-hashes.json').read_text())
for file, expected in sources.items():
    assert hashlib.sha256((repo / file).read_bytes()).hexdigest() == expected, file
results = json.loads((raw / 'results-final.json').read_text())
assert len(results) == 5 and sum(r['passed'] for r in results) == 38
assert all(r['exit'] == 0 and r['passed'] > 0 for r in results)
assert sum(r['ignored'] for r in results) == 3
for result in results:
    assert hashlib.sha256(Path(result['exe']).read_bytes()).hexdigest() == result['exeSha256']
checks = json.loads((raw / 'checks.json').read_text())
assert all(value == 0 for value in checks.values()), checks
manifest = dict(sourceSha256=sources, results=results, checks=checks,
                passed=38, ignored=3, fullIssueComplete=False,
                remaining=['mapped spatial mini editor and selection transforms',
                           'initial signed-local roving identities',
                           'media device, prewarm and high-speed final integration'],
                newUiScreenshots=False)
archive = dest / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for file in sorted(raw.rglob('*')):
        if file.is_file() and file.suffix in ['.log', '.json', '.py', '.ps1', '.msproj']:
            z.write(file, file.relative_to(raw).as_posix())
manifest['archiveSha256'] = hashlib.sha256(archive.read_bytes()).hexdigest()
manifest['archiveBytes'] = archive.stat().st_size
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(archiveBytes=manifest['archiveBytes'], passed=38, ignored=3)))
