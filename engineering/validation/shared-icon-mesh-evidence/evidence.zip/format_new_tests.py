from pathlib import Path
import subprocess

blocks = [
    ('desktop/ui/src/icons/geometry_tests.rs', 'fn transformed_shared_icons_keep_owned_gpu_pixels_and_detect_wrong_placement()', None),
    ('desktop/app/src/plugin_editor/author/catalog.rs', 'mod mesh_tests {', None),
    ('desktop/app/src/node_editor/view/control_tests.rs', 'fn canvas_transform_keeps_shared_icons_and_exact_coordinates()', 'fn row('),
    ('desktop/ui/tests/icon_geometry.rs', 'fn warmed_icon_instances_keep_zero_allocations_through_node_transform_and_clip()', '#[test]\nfn triangle_clip_temporaries'),
    ('desktop/ui/tests/paint_clip_buffers.rs', 'fn fully_contained_shared_icon_clips_preserve_source_geometry_without_allocating()', '#[test]\nfn contained_triangles'),
]
for name, marker, end_marker in blocks:
    path = Path(name)
    text = path.read_text(encoding='utf-8')
    position = text.index(marker)
    start = text.rfind('#[cfg(test)]' if marker.startswith('mod ') else '#[test]', 0, position)
    assert start >= 0
    end = text.index(end_marker, position) if end_marker else len(text)
    block = text[start:end]
    result = subprocess.run(['rustfmt', '--edition', '2021', '--config', 'skip_children=true', '--emit', 'stdout'],
        input=block, text=True, encoding='utf-8', capture_output=True, check=True)
    path.write_text(text[:start] + result.stdout.rstrip() + ('\n\n' if end_marker else '\n') + text[end:], encoding='utf-8', newline='\n')
print('Formatted five new test blocks; existing surrounding code retained')
