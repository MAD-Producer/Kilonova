import base64
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

REPO = 'MAD-Producer/Kilonova'
BRANCH = 'perf/shared-icon-mesh'
RAW = Path('E:/Dev/aem/artifacts/issue-goal-current/shared-icon-mesh')


def git(*args):
    return subprocess.check_output(['git', *args])


def api(method, endpoint, data=None):
    command = ['gh', 'api', '--method', method, f'repos/{REPO}/{endpoint}']
    if data is not None:
        payload = RAW / 'api-payload.json'
        payload.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        command += ['--input', str(payload)]
    result = subprocess.run(command, capture_output=True, text=True, encoding='utf-8')
    if result.returncode:
        raise RuntimeError(result.stderr)
    return json.loads(result.stdout)


assert git('branch', '--show-current').decode().strip() == BRANCH
assert not git('status', '--porcelain').strip(), 'commit all intended changes first'
local = git('rev-parse', 'HEAD').decode().strip()
parent = git('rev-parse', 'HEAD^').decode().strip()
refs = api('GET', f'git/matching-refs/heads/{BRANCH}')
assert len(refs) <= 1
if refs:
    assert refs[0]['ref'] == f'refs/heads/{BRANCH}'
    assert refs[0]['object']['sha'] == parent, 'remote parent changed'
paths = git('diff', '--name-only', parent, local).decode().splitlines()
assert paths and all(path.startswith(('desktop/ui/', 'desktop/app/src/node_editor/',
    'desktop/app/src/plugin_editor/author/catalog.rs',
    'desktop/app/src/panels/graph_native_performance_tests.rs',
    'engineering/validation/shared-icon-mesh')) for path in paths)
entries = []
for path in paths:
    content = git('show', f'{local}:{path}')
    expected = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
    blob = api('POST', 'git/blobs', dict(content=base64.b64encode(content).decode(), encoding='base64'))
    assert blob['sha'] == expected
    entries.append(dict(path=path, mode='100644', type='blob', sha=expected))
tree = api('POST', 'git/trees', dict(base_tree=git('rev-parse', f'{parent}^{{tree}}').decode().strip(), tree=entries))
assert tree['sha'] == git('rev-parse', f'{local}^{{tree}}').decode().strip()
an, ae, at, cn, ce, ct = git('show', '-s', '--format=%an%x00%ae%x00%at%x00%cn%x00%ce%x00%ct', local).decode().strip().split('\0')


def date(value):
    return datetime.datetime.fromtimestamp(int(value), datetime.timezone.utc).isoformat().replace('+00:00', 'Z')


message = git('show', '-s', '--format=%B', local).decode().rstrip('\n') + '\n'
commit = api('POST', 'git/commits', dict(message=message, tree=tree['sha'], parents=[parent],
    author=dict(name=an, email=ae, date=date(at)), committer=dict(name=cn, email=ce, date=date(ct))))
content = (f"tree {tree['sha']}\nparent {parent}\nauthor {an} <{ae}> {at} +0000\ncommitter {cn} <{ce}> {ct} +0000\n\n" + message).encode()
sha = subprocess.check_output(['git', 'hash-object', '-t', 'commit', '-w', '--stdin'], input=content).decode().strip()
assert sha == commit['sha']
if refs:
    api('PATCH', f'git/refs/heads/{BRANCH}', dict(sha=sha, force=False))
else:
    api('POST', 'git/refs', dict(ref=f'refs/heads/{BRANCH}', sha=sha))
subprocess.run(['git', 'update-ref', f'refs/heads/{BRANCH}', sha, local], check=True)
subprocess.run(['git', 'update-ref', f'refs/remotes/origin/{BRANCH}', sha], check=True)
(RAW / f'publication-{sha[:8]}.json').write_text(json.dumps(dict(original=local,
    published=sha, tree=tree['sha'], parent=parent, paths=paths), ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('Published identical tree:', sha)
