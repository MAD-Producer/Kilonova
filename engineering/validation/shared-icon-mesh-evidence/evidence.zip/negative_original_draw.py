import hashlib
import json
import os
from pathlib import Path
import subprocess

raw = Path('E:/Dev/aem/artifacts/issue-goal-current/shared-icon-mesh')
source = Path('desktop/ui/src/icons.rs')
fixed = source.read_bytes()
baseline = subprocess.check_output(['git', 'show', '6ab57829211346edc8dd0356bd9d15cefc6ae57d:desktop/ui/src/icons.rs'])
assert baseline != fixed
try:
    source.write_bytes(baseline)
    command = ['cargo', 'rustc', '-p', 'motion-ui', '--test', 'icon_geometry', '--profile', 'test', '--locked',
        '--target-dir', 'E:/Dev/aem/.tools/viewer-inspection/native-target', '--message-format=json', '--',
        '-C', 'codegen-units=1', '-C', 'debuginfo=0', '-C', 'link-arg=/DEBUG:NONE']
    with (raw / 'negative-build.jsonl').open('wb') as out, (raw / 'negative-build.stderr').open('wb') as err:
        build = subprocess.run(command, stdout=out, stderr=err)
    (raw / 'negative-build.exit').write_text(str(build.returncode))
    assert build.returncode == 0, 'negative implementation must build before executing'
    records = [json.loads(line) for line in (raw / 'negative-build.jsonl').read_text(encoding='utf-8').splitlines()]
    artifact = [item for item in records if item.get('reason') == 'compiler-artifact'
        and item.get('target', {}).get('name') == 'icon_geometry' and item.get('executable')][-1]
    run = subprocess.run([artifact['executable'], '--exact', 'warmed_icons_do_not_allocate_per_instance', '--nocapture'],
        capture_output=True)
    (raw / 'negative.stdout').write_bytes(run.stdout)
    (raw / 'negative.stderr').write_bytes(run.stderr)
    (raw / 'negative.exit').write_text(str(run.returncode))
    assert run.returncode == 101
    assert b'one=1 two_hundred=200' in run.stdout
    assert b'immutable mesh instances must not allocate triangle copies' in run.stderr
    (raw / 'negative-receipt.json').write_text(json.dumps(dict(
        sourceCommit='6ab57829211346edc8dd0356bd9d15cefc6ae57d',
        originalSourceSha256=hashlib.sha256(baseline).hexdigest(),
        fixedSourceSha256=hashlib.sha256(fixed).hexdigest(),
        test='warmed_icons_do_not_allocate_per_instance', exit=run.returncode,
        binarySha256=hashlib.sha256(Path(artifact['executable']).read_bytes()).hexdigest()), indent=2))
    print('Original implementation rejected: 1 / 200 allocations, test exit 101')
finally:
    source.write_bytes(fixed)
    assert source.read_bytes() == fixed
