import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

raw = Path('E:/Dev/aem/artifacts/issue-goal-current/shared-icon-mesh')
out = Path('engineering/validation/shared-icon-mesh-evidence')
out.mkdir(exist_ok=True)
for name in ['ui-complete-final.exit', 'default-node_editor.exit',
    'default-plugin_editor-tests.exit', 'default-catalog.exit']:
    assert (raw / name).read_text(encoding='utf-8-sig').strip() == '0', name
assert (raw / 'negative.exit').read_text().strip() == '101'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


pairs = []
for actual in sorted((raw / 'gpu').glob('*-actual.png')):
    expected = actual.with_name(actual.name.replace('-actual.png', '-owned.png'
        if actual.name.startswith('node-') else '-legacy.png'))
    assert sha(actual) == sha(expected), actual.name
    pairs.append(dict(actual=actual.name, expected=expected.name, sha256=sha(actual)))
assert len(pairs) == 24
wrong = list((raw / 'gpu').glob('*-wrong.png'))
assert len(wrong) == 9
for path in wrong:
    assert sha(path) != sha(path.with_name(path.name.replace('-wrong.png', '-owned.png')))

paths = set(subprocess.check_output(['git', 'diff', '--name-only', '6ab57829211346edc8dd0356bd9d15cefc6ae57d']).decode().splitlines())
paths.update(subprocess.check_output(['git', 'diff', '--name-only', '6ab57829211346edc8dd0356bd9d15cefc6ae57d', 'HEAD']).decode().splitlines())
sources = [dict(path=name, sha256=sha(Path(name))) for name in sorted(paths) if name.endswith('.rs')]
assert sources
files = [path for path in sorted(raw.rglob('*')) if path.is_file() and path.name != 'api-payload.json']
entries = [dict(path=str(path.relative_to(raw)).replace('\\', '/'), bytes=path.stat().st_size, sha256=sha(path)) for path in files]
archive = out / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for path in files:
        bundle.write(path, str(path.relative_to(raw)).replace('\\', '/'))
shutil.copyfile(raw / 'gpu/icons-1.5-clips1-actual.png', out / 'icons-actual.png')
shutil.copyfile(raw / 'gpu/node-icons-zoom1.25-ratio1.5-actual.png', out / 'node-icons-actual.png')
manifest = dict(scope='Refs #129; icon geometry only; issue remains open',
    base='6ab57829211346edc8dd0356bd9d15cefc6ae57d', sources=sources,
    tests=dict(ui=201, compileFailExample=1, nodeEditor=177, pluginPanel=6, catalog=1,
        totalDifferentChecks=386, repeatedRunsAndChildProcessesCountedAgain=False),
    gpuPairs=pairs, negativePlacementImages=9, originalImplementationNegativeExit=101,
    archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive)), entries=entries)
(out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(f'Packaged {len(entries)} raw files, {len(pairs)} identical GPU pairs, {archive.stat().st_size} bytes')
