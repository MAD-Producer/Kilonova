//! Glyph atlas for shell chrome. Windows uses grid-fitted grayscale glyphs
//! from the selected installed face. Rasterization is per glyph; complex-script
//! shaping and bidirectional layout are not yet supported.

use ab_glyph::{Font, FontArc, PxScale, PxScaleFont, ScaleFont};
use unicode_segmentation::UnicodeSegmentation;
pub mod shaping;
pub mod glyph_index;
pub mod layout;

struct SharedFontBytes(FontArc);
impl AsRef<[u8]> for SharedFontBytes {
    fn as_ref(&self) -> &[u8] {
        self.0.font_data()
    }
}
fn shaper_for(font: &FontArc, index: u32) -> Result<shaping::RunShaper, String> {
    shaping::RunShaper::from_source(std::sync::Arc::new(SharedFontBytes(font.clone())), index)
        .map_err(|cause| cause.to_string())
}
// Fits the minimum texture dimension supported by the desktop's downlevel
// devices. RGBA coverage is bounded to 16 MiB on both CPU and GPU.
const MAX_ATLAS_DIMENSION: u32 = 2048;

// The chrome atlas does not shape variation sequences or joining forms.
// Their scalar fallback is invisible and non-advancing, independent of cmap
// support. This does not implement substitution, bidi or mark positioning.
// https://unicode.org/faq/unsup_char.html
fn is_sequence_control(character: char) -> bool {
    matches!(character,
        '\u{180b}'..='\u{180d}' | '\u{180f}'
        | '\u{200c}' | '\u{200d}'
        | '\u{fe00}'..='\u{fe0f}' | '\u{e0100}'..='\u{e01ef}')
}
#[cfg(test)]
mod observation_tests;
#[cfg(test)]
mod lifetime_tests;
#[cfg(test)]
mod format_controls_tests;
#[cfg(target_os = "windows")]
mod windows;

/// One rendered glyph in the atlas.
#[derive(Clone, Copy)]
pub struct GlyphEntry {
    /// Atlas rectangle in normalised coordinates.
    pub uv: [f32; 4],
    /// Offset from the pen position to the glyph's top-left, in pixels.
    pub offset: [f32; 2],
    pub advance: f32,
}

/// Atlas geometry.
#[derive(Clone, Copy)]
pub struct AtlasConfig {
    pub width: u32,
    pub height: u32,
    pub padding: u32,
}

impl Default for AtlasConfig {
    fn default() -> Self {
        Self {
            width: 1024,
            height: 1024,
            padding: 1,
        }
    }
}

/// CPU-side glyph cache plus the coverage bitmap uploaded to the GPU.
///
/// The bitmap holds white premultiplied coverage in every channel; the shader
/// multiplies it by the per-glyph colour, so a glyph only ever costs one texel
/// read regardless of how many times it is drawn.
pub struct TextAtlas {
    font: PxScaleFont<FontArc>,
    /// Font size in pixels per em, as used by the design and stylesheet.
    font_size: f32,
    shaper: shaping::RunShaper,
    fallback_shaper: Option<shaping::RunShaper>,
    fallback: Option<PxScaleFont<FontArc>>,
    config: AtlasConfig,
    max_dimension: u32,
    pixels: Vec<u8>,
    entries: std::collections::HashMap<(char, u32, u32), GlyphEntry>,
    indexed_entries: std::collections::HashMap<(glyph_index::FontSlot, u16, u32, u32), GlyphEntry>,
    layouts: layout::LayoutCache,
    pixel_ratio: f32,
    pub selected_family: String,
    #[cfg(target_os = "windows")]
    hinted: Option<windows::Rasterizer>,
    /// Pen position of the next glyph in the atlas, in texels.
    cursor: [f32; 2],
    row_height: u32,
    pub line_height: f32,
    pub ascent: f32,
    dirty: bool,
    /// Families discovered on this machine, for the diagnostics panel.
    pub families: Vec<String>,
    observations: crate::observability::Failures,
}

impl TextAtlas {
    /// Build an atlas from the system UI font at `scale` logical pixels.
    pub fn from_system(scale: f32) -> Result<Self, String> {
        let (font, families, family, index) = load_system_font(false)?;
        let mut atlas = Self::new(font, index, scale, families)?;
        atlas.configure_family(family);
        Ok(atlas)
    }

    pub fn from_system_language(scale: f32, chinese: bool) -> Result<Self, String> {
        Self::from_family("system-ui", scale, chinese)
    }
    pub fn from_family(family: &str, scale: f32, chinese: bool) -> Result<Self, String> {
        let (font, families, selected, index) = load_preferred_font(chinese, Some(family))?;
        let mut atlas = Self::new(font, index, scale, families)?;
        atlas.configure_family(selected);
        if atlas.font.font.glyph_id('中').0 == 0 {
            match load_system_font(true) {
                Ok((fallback, _, _, index)) => {
                    atlas.fallback_shaper = Some(shaper_for(&fallback, index)?);
                    atlas.fallback = Some(PxScaleFont { scale: em_scale(&fallback, scale), font: fallback });
                }
                Err(error) => {
                    log::warn!("UI font fallback unavailable family={:?} reason={error}", atlas.selected_family);
                }
            }
        }
        Ok(atlas)
    }
    pub fn font_size(&self) -> f32 {
        self.font_size
    }
    fn configure_family(&mut self, family: String) {
        #[cfg(target_os = "windows")]
        {
            self.hinted = windows::Rasterizer::new(&family);
            if self.hinted.is_none() {
                log::warn!("UI font hinting unavailable family={family:?} reason=CreateCompatibleDC_returned_null fallback=outline");
            }
        }
        self.selected_family = family;
    }
    pub fn pixel_ratio(&self) -> f32 {
        self.pixel_ratio
    }
    pub fn set_pixel_ratio(&mut self, ratio: f32) {
        if ratio.is_finite() && ratio > 0. {
            self.pixel_ratio = ratio.clamp(0.5, 4.);
        }
    }
    pub fn supports(&self, character: char) -> bool {
        self.shaping_face(character).nominal_glyph(character).is_some()
    }
    fn shaping_face(&self, character: char) -> &shaping::RunShaper {
        if self.shaper.nominal_glyph(character).is_none() {
            if let Some(fallback) = &self.fallback_shaper {
                if fallback.nominal_glyph(character).is_some() {
                    return fallback;
                }
            }
        }
        &self.shaper
    }
    /// Bind the same collection face used to construct `font` to the shaper.
    /// A font the shaping reader cannot open is returned to the caller as an error.
    pub fn new(
        font: FontArc,
        face_index: u32,
        scale: f32,
        families: Vec<String>,
    ) -> Result<Self, String> {
        let shaper = shaper_for(&font, face_index)?;
        let font = PxScaleFont {
            scale: em_scale(&font, scale),
            font,
        };
        let line_height = font.height().max(scale);
        let ascent = font.ascent();
        let config = AtlasConfig::default();
        let pixels = vec![0u8; (config.width * config.height * 4) as usize];
        Ok(Self {
            font,
            shaper,
            fallback_shaper: None,
            font_size: scale,
            fallback: None,
            config,
            max_dimension: MAX_ATLAS_DIMENSION,
            pixels,
            entries: std::collections::HashMap::new(),
            indexed_entries: std::collections::HashMap::new(),
            layouts: Default::default(),
            pixel_ratio: 1.,
            selected_family: "custom".into(),
            #[cfg(target_os = "windows")]
            hinted: None,
            cursor: [0.0, 0.0],
            row_height: 0,
            line_height,
            ascent,
            dirty: true,
            families,
            observations: Default::default(),
        })
    }

    /// Scale the rasterisation size, for example after a display scale change.
    pub fn set_scale(&mut self, scale: f32) {
        let current = self.font_size;
        if (scale - current).abs() < f32::EPSILON {
            return;
        }
        self.font_size = scale;
        self.font.scale = em_scale(&self.font.font, scale);
        if let Some(fallback) = &mut self.fallback {
            fallback.scale = em_scale(&fallback.font, scale);
        }
        self.ascent = self.font.ascent();
        self.line_height = self.font.height().max(scale);
        self.clear();
    }

    fn clear(&mut self) {
        self.entries.clear();
        self.indexed_entries.clear();
        self.layouts.clear();
        self.pixels.fill(0);
        self.cursor = [0.0, 0.0];
        self.row_height = 0;
        self.dirty = true;
    }

    /// Reserve without moving existing texels or clearing previously emitted
    /// glyphs. Failed reservations leave the shelf cursor unchanged.
    fn reserve(&mut self, width: u32, height: u32) -> bool {
        let Some(width) = width.checked_add(self.config.padding) else { return false; };
        let Some(height) = height.checked_add(self.config.padding) else { return false; };
        if width > self.max_dimension || height > self.max_dimension { return false; }
        loop {
            let mut cursor = self.cursor;
            let mut row_height = self.row_height;
            if cursor[0] + width as f32 > self.config.width as f32 {
                cursor[0] = 0.;
                cursor[1] += row_height as f32;
                row_height = 0;
            }
            if width <= self.config.width && cursor[1] + height as f32 <= self.config.height as f32 {
                self.cursor = cursor;
                self.row_height = row_height.max(height);
                return true;
            }
            let old = self.config;
            let new_width = old.width.saturating_mul(2).min(self.max_dimension);
            let new_height = old.height.saturating_mul(2).min(self.max_dimension);
            if new_width == old.width && new_height == old.height { return false; }
            let mut pixels = vec![0; new_width as usize * new_height as usize * 4];
            for (from, to) in self.pixels.chunks_exact(old.width as usize * 4)
                .zip(pixels.chunks_exact_mut(new_width as usize * 4)) {
                to[..from.len()].copy_from_slice(from);
            }
            for entry in self.entries.values_mut().chain(self.indexed_entries.values_mut()) {
                for i in 0..4 {
                    entry.uv[i] *= if i % 2 == 0 { old.width as f32 / new_width as f32 }
                        else { old.height as f32 / new_height as f32 };
                }
            }
            self.config.width = new_width;
            self.config.height = new_height;
            self.pixels = pixels;
            self.dirty = true;
            log::debug!("UI glyph atlas grew from={}x{} to={new_width}x{new_height} entries={}", old.width, old.height, self.entries.len());
        }
    }

    fn observe_capacity(&self, character: char, size: f32) {
        // Lifetime pressure counter, reset only when this atlas is replaced.
        // A refusal must not clear or overwrite retained glyphs.
        self.observations.record("text.atlas_full", "capacity", format_args!(
            "family={:?} width={} height={} max_dimension={} entries={} glyph=U+{:04X} size={size} pixel_ratio={} fallback=advance_without_bitmap",
            self.selected_family, self.config.width, self.config.height, self.max_dimension,
            self.entries.len(), character as u32, self.pixel_ratio));
    }

    pub fn pixel_data(&self) -> &[u8] {
        &self.pixels
    }

    pub fn config(&self) -> AtlasConfig {
        self.config
    }

    /// True when new glyphs were rasterised since the last upload.
    pub fn take_dirty(&mut self) -> bool {
        std::mem::take(&mut self.dirty)
    }

    /// Advance width of a character, without rasterising it.
    ///
    /// Unmapped code points take a fixed width so a layout never collapses when
    /// a label contains a character the system font lacks.
    fn face(&self, character: char) -> &PxScaleFont<FontArc> {
        if self.font.glyph_id(character).0 == 0 {
            if let Some(fallback) = &self.fallback {
                if fallback.glyph_id(character).0 != 0 {
                    return fallback;
                }
            }
        }
        &self.font
    }
    fn advance(&self, character: char) -> f32 {
        if is_sequence_control(character) {
            return 0.;
        }
        let font = self.face(character);
        let id = font.glyph_id(character);
        if id.0 == 0 {
            return font.scale.x * 0.5;
        }
        font.h_advance(id)
    }

    /// Rasterise a character if it is not already cached.
    pub fn glyph(&mut self, character: char) -> GlyphEntry {
        self.glyph_at(character, self.font_size)
    }
    /// Rasterize at the requested em size rather than enlarging a small bitmap.
    pub fn glyph_at(&mut self, character: char, size: f32) -> GlyphEntry {
        if !size.is_finite() || size <= 0. || !self.font_size.is_finite() || self.font_size <= 0. {
            self.observe_capacity(character, size);
            return GlyphEntry { uv: [0.; 4], offset: [0.; 2], advance: 0. };
        }
        if is_sequence_control(character) {
            // Preserve the public oversized-request diagnostic. A valid
            // sequence control needs no atlas texel or missing-glyph episode.
            if size * self.pixel_ratio > self.max_dimension as f32 {
                self.observe_capacity(character, size);
            }
            return GlyphEntry { uv: [0.; 4], offset: [0.; 2], advance: 0. };
        }
        let key = (character, size.to_bits(), self.pixel_ratio.to_bits());
        if let Some(entry) = self.entries.get(&key) {
            if entry.uv == [0.; 4] && !character.is_whitespace() && !self.supports(character) {
                self.observe_missing_glyph(character, size);
            }
            return *entry;
        }
        let ratio = size / self.font_size;
        let advance = self.advance(character) * ratio;
        let blank = GlyphEntry {
            uv: [0.0; 4],
            offset: [0.0, 0.0],
            advance,
        };
        // Bound rasterization before passing extreme sizes to the outline or
        // platform rasterizer, as well as checking actual bitmap bounds below.
        if size * self.pixel_ratio > self.max_dimension as f32 {
            self.observe_capacity(character, size);
            return blank;
        }
        let font = self.face(character);
        let id = font.glyph_id(character);
        if id.0 == 0 {
            self.observe_missing_glyph(character, size);
            self.entries.insert(key, blank);
            return blank;
        }
        let primary = self.font.glyph_id(character).0 != 0;
        let font = font.clone();
        let Some(entry) = self.rasterize_glyph(font, id.0, size, blank, primary, character) else {
            return blank;
        };
        self.entries.insert(key, entry);
        entry
    }

    fn rasterize_glyph(
        &mut self,
        font: PxScaleFont<FontArc>,
        id: u16,
        size: f32,
        blank: GlyphEntry,
        primary: bool,
        character: char,
    ) -> Option<GlyphEntry> {
        #[cfg(not(target_os = "windows"))]
        let _ = primary;
        let mut glyph = ab_glyph::Glyph {
            id: ab_glyph::GlyphId(id), scale: font.scale, position: ab_glyph::point(0., 0.),
        };
        glyph.scale = PxScale::from(font.scale.y * (size / self.font_size) * self.pixel_ratio);
        let Some(outlined) = font.outline_glyph(glyph) else {
            return Some(blank);
        };
        // Pixel bounds are integers and exactly match what `draw` reports, so
        // the atlas rectangle and the draw coordinates agree without rounding.
        let bounds = outlined.px_bounds();
        #[cfg(target_os = "windows")]
        let hinted = if primary {
            self.hinted
                .as_mut()
                .and_then(|r| r.glyph(id, size * self.pixel_ratio))
        } else {
            None
        };
        #[cfg(target_os = "windows")]
        let (width, height, offset) = hinted.as_ref().map_or(
            (
                (bounds.max.x - bounds.min.x) as u32,
                (bounds.max.y - bounds.min.y) as u32,
                [bounds.min.x, bounds.min.y],
            ),
            |b| (b.width, b.height, b.offset),
        );
        #[cfg(not(target_os = "windows"))]
        let (width, height, offset) = (
            (bounds.max.x - bounds.min.x) as u32,
            (bounds.max.y - bounds.min.y) as u32,
            [bounds.min.x, bounds.min.y],
        );
        if width == 0 || height == 0 {
            // Whitespace advances without a bitmap.
            return Some(blank);
        }
        let padding = self.config.padding;
        if !self.reserve(width, height) {
            self.observe_capacity(character, size);
            return None;
        }
        let x = self.cursor[0] as u32;
        let y = self.cursor[1] as u32;
        let stride = self.config.width as usize;
        let pixels = &mut self.pixels;
        let mut write = |column: u32, row: u32, coverage: f32| {
            let local_column = column;
            let local_row = row;
            if local_column >= width || local_row >= height {
                return;
            }
            let index =
                ((y + local_row) as usize * stride + x as usize + local_column as usize) * 4;
            pixels[index..index + 4].fill((coverage.clamp(0.0, 1.0) * 255.0).round() as u8);
        };
        #[cfg(target_os = "windows")]
        if let Some(bitmap) = hinted {
            for (i, c) in bitmap.coverage.into_iter().enumerate() {
                write(i as u32 % width, i as u32 / width, c as f32 / 255.);
            }
        } else {
            outlined.draw(&mut write);
        }
        #[cfg(not(target_os = "windows"))]
        outlined.draw(&mut write);
        self.cursor[0] += width as f32 + padding as f32;
        let entry = GlyphEntry {
            uv: [
                x as f32 / self.config.width as f32,
                y as f32 / self.config.height as f32,
                (x + width) as f32 / self.config.width as f32,
                (y + height) as f32 / self.config.height as f32,
            ],
            // Atlas rows advance downward; glyph space advances upward.
            offset: offset.map(|v| v / self.pixel_ratio),
            advance: blank.advance,
        };
        self.dirty = true;
        Some(entry)
    }


    fn observe_missing_glyph(&self, character: char, size: f32) {
        self.observations.record("text.missing_glyph", &format!("U+{:04X}", character as u32),
            format_args!("family={:?} size={size} pixel_ratio={} fallback_available={}",
                self.selected_family, self.pixel_ratio, self.fallback.is_some()));
    }

    /// Total advance width of a string in logical pixels.
    pub fn measure(&mut self, text: &str) -> f32 {
        text.chars().map(|c| self.advance(c)).sum()
    }

    /// Truncate at an extended grapheme boundary to fit `width`, appending an
    /// ellipsis when characters are lost. This does not add script shaping.
    pub fn ellipsize(&mut self, text: &str, width: f32) -> String {
        let (prefix, ellipsis) = self.fitted_text(text, width);
        let mut result = prefix.to_owned();
        if ellipsis {
            result.push('\u{2026}');
        }
        result
    }

    /// Borrow the visible prefix and report whether to emit an ellipsis.
    /// Drawing can iterate this pair without allocating an intermediate string.
    pub(crate) fn fitted_text<'a>(&self, text: &'a str, width: f32) -> (&'a str, bool) {
        if text.chars().map(|c| self.advance(c)).sum::<f32>() <= width {
            return (text, false);
        }
        let ellipsis_width = self.advance('\u{2026}');
        if !width.is_finite() || width < ellipsis_width {
            return ("", false);
        }
        let mut end = 0;
        let mut used = 0.0;
        for (index, cluster) in text.grapheme_indices(true) {
            let advance = cluster.chars().map(|c| self.advance(c)).sum::<f32>();
            if used + advance + ellipsis_width > width {
                break;
            }
            end = index + cluster.len();
            used += advance;
        }
        (&text[..end], true)
    }
}

// ab_glyph's PxScale is ascender-to-descender height, not pixels per em.
// Design tools and CSS use em size, so convert once for each selected face.
fn em_scale(font: &FontArc, pixels: f32) -> PxScale {
    PxScale::from(
        pixels * font.height_unscaled() / font.units_per_em().unwrap_or(font.height_unscaled()),
    )
}

/// Prefer a platform UI face, then fall back to any installed font.
fn load_system_font(chinese: bool) -> Result<(FontArc, Vec<String>, String, u32), String> {
    load_preferred_font(chinese, None)
}
fn load_preferred_font(
    chinese: bool,
    family: Option<&str>,
) -> Result<(FontArc, Vec<String>, String, u32), String> {
    let mut database = fontdb::Database::new();
    database.load_system_fonts();
    let families: Vec<String> = database
        .faces()
        .filter_map(|face| face.families.first().map(|(name, _)| name.clone()))
        .filter(|name| !name.is_empty())
        .collect::<std::collections::BTreeSet<_>>()
        .into_iter()
        .collect();
    let mut preferred = Vec::new();
    if let Some(family) = family.filter(|f| *f != "system-ui") {
        preferred.push(family);
    }
    if chinese {
        preferred.extend([
            "Microsoft YaHei UI",
            "Microsoft YaHei",
            "PingFang SC",
            "Heiti SC",
            "Hiragino Sans GB",
            "Songti SC",
            "Noto Sans CJK SC",
            "WenQuanYi Micro Hei",
        ]);
    }
    preferred.extend([
        "Segoe UI",
        "SF Pro Text",
        "Helvetica Neue",
        "Inter",
        "Roboto",
        "Noto Sans",
        "DejaVu Sans",
        "Arial",
    ]);
    let mut candidates: Vec<fontdb::ID> = Vec::new();
    for wanted in preferred {
        if let Some(id) = database.query(&fontdb::Query {
            families: &[fontdb::Family::Name(wanted)],
            ..fontdb::Query::default()
        }) {
            candidates.push(id);
        }
    }
    // A monospaced face keeps numeric columns aligned if it is all we have.
    candidates.extend(
        database
            .faces()
            .filter(|face| face.monospaced)
            .map(|face| face.id),
    );
    candidates.extend(database.faces().map(|face| face.id));
    let prefer_chinese = chinese && family.is_none_or(|name| name == "system-ui");
    if let Some((font, family, index)) = select_candidate(&database, candidates, prefer_chinese) {
        return Ok((font, families, family, index));
    }
    Err("no usable system font was found".into())
}

fn select_candidate(
    database: &fontdb::Database,
    candidates: impl IntoIterator<Item = fontdb::ID>,
    prefer_chinese: bool,
) -> Option<(FontArc, String, u32)> {
    let mut fallback = None;
    for id in candidates {
        let font = database.with_face_data(id, |data, index| {
            ab_glyph::FontVec::try_from_vec_and_index(data.to_vec(), index)
                .map(|font| (FontArc::new(font), index))
        });
        if let Some(Ok((font, index))) = font {
            let family = database
                .face(id)
                .and_then(|f| f.families.first())
                .map(|f| f.0.clone())
                .unwrap_or_else(|| "unknown".into());
            if prefer_chinese && font.glyph_id('中').0 == 0 {
                fallback.get_or_insert((font, family, index));
                continue;
            }
            return Some((font, family, index));
        }
    }
    fallback
}

#[cfg(test)]
mod font_selection_tests;

#[cfg(test)]
mod tests {
    use super::*;

    /// The atlas needs a real font, so these tests use whichever system face the
    /// host provides and skip when none is installed.
    fn fixture() -> Option<TextAtlas> {
        TextAtlas::from_system(13.0).ok()
    }

    #[test]
    fn every_glyph_lands_inside_the_atlas() {
        let Some(mut atlas) = fixture() else {
            return;
        };
        let (width, height) = (atlas.config().width, atlas.config().height);
        for character in "Motion Studio 0123456789 /.".chars() {
            let entry = atlas.glyph(character);
            assert!(entry.uv[0] >= 0.0 && entry.uv[2] <= 1.0, "{character}");
            assert!(entry.uv[1] >= 0.0 && entry.uv[3] <= 1.0, "{character}");
            assert!(
                (entry.uv[2] - entry.uv[0]) * width as f32 <= width as f32,
                "{character} overflows"
            );
            assert!(
                (entry.uv[3] - entry.uv[1]) * height as f32 <= height as f32,
                "{character} overflows"
            );
        }
    }

    #[test]
    fn whitespace_advances_without_consuming_atlas_texels() {
        let Some(mut atlas) = fixture() else {
            return;
        };
        let space = atlas.glyph(' ');
        assert_eq!(space.uv, [0.0; 4]);
        assert!(space.advance > 0.0);
    }

    #[test]
    fn measuring_does_not_rasterise() {
        let Some(mut atlas) = fixture() else {
            return;
        };
        atlas.take_dirty();
        let width = atlas.measure("Motion Studio");
        assert!(width > 0.0);
        assert!(!atlas.take_dirty(), "measure must not dirty the atlas");
    }

    #[test]
    fn ellipsize_fits_within_the_requested_width() {
        let Some(mut atlas) = fixture() else {
            return;
        };
        let limit = 40.0;
        let shown = atlas.ellipsize("Effect Controls", limit);
        assert!(shown.ends_with('\u{2026}'));
        assert!(atlas.measure(&shown) <= limit, "{shown:?}");
        assert_eq!(atlas.ellipsize("ab", 10_000.0), "ab");
    }

    #[test]
    fn the_atlas_reports_dirty_only_after_new_glyphs() {
        let Some(mut atlas) = fixture() else {
            return;
        };
        assert!(atlas.take_dirty());
        atlas.glyph('A');
        assert!(atlas.take_dirty());
        atlas.glyph('A');
        assert!(!atlas.take_dirty());
    }

    #[test]
    fn changing_scale_repacks_the_atlas() {
        let Some(mut atlas) = fixture() else {
            return;
        };
        atlas.glyph('A');
        atlas.take_dirty();
        atlas.set_scale(26.0);
        assert!(atlas.take_dirty());
        assert_eq!(atlas.entries.len(), 0);
        assert!(atlas.line_height >= 26.0);
    }

    #[test]
    fn dpi_rasterization_preserves_logical_metrics_and_existing_uvs() {
        let Some(mut atlas) = fixture() else { return; };
        let width = atlas.measure("Preview 123");
        let first = atlas.glyph('A');
        atlas.set_pixel_ratio(2.0);
        let second = atlas.glyph('A');
        assert_eq!(atlas.measure("Preview 123"), width);
        assert_eq!(first.advance, second.advance);
        assert!(second.uv[2] - second.uv[0] > first.uv[2] - first.uv[0]);
        atlas.set_pixel_ratio(1.0);
        assert_eq!(atlas.glyph('A').uv, first.uv);
    }
}
