import hashlib, json, subprocess, zipfile
from pathlib import Path
from PIL import Image

repo=Path('E:/Dev/aem/.worktrees/layer-time-mapping')
root=Path('E:/Dev/aem/artifacts/issue-goal-current')
out=repo/'engineering/validation/layer-time-typed-lanes-evidence'
read=lambda name:json.loads((root/name).read_text(encoding='utf-8'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
reports={mode:read('layer-time-typed-lanes-'+mode+'-results.json') for mode in ['quick','all','native']}
assert len(reports['all']['suites'])==9
for report in reports.values():
    assert report['sha256_before']==report['sha256_after']
    assert all(s['exit_code']==0 and not s['failed'] and s['passed'] for s in report['suites'].values())
assert len({r['sha256_before'] for r in reports.values()})==1
checks=read('layer-time-typed-lanes-checks.json')
assert all(value==0 for value in checks.values())
passed=set().union(*(set(r['distinct_passed']) for r in reports.values()))
ignored=set().union(*(set(r['distinct_ignored']) for r in reports.values()))-passed
images=[];processes={}
for folder in [root/'layer-time-typed-lanes-native'/f'case-{i}' for i in range(5)]+[root/'layer-time-typed-lanes-property-native']:
    capture=json.loads((folder/'capture-process.json').read_text(encoding='utf-8'))
    reopen=json.loads((folder/'reopen-process.json').read_text(encoding='utf-8'))
    assert capture['pid']!=reopen['pid']
    processes[str(folder.relative_to(root))]={'capture':capture,'reopen':reopen}
    files=sorted(folder.glob('*.png'))
    assert len(files)==(16 if folder.name.endswith('property-native') else 4)
    for path in files:
        with Image.open(path) as image:
            assert image.size==(1000,800)
            assert len(image.convert('RGB').getcolors(800000) or [])>20
            images.append({'path':str(path.relative_to(root)),'sha256':sha(path),'size':list(image.size)})
assert len(images)==36
doc=repo/'engineering/validation/layer-time-typed-lanes.md'
paragraph=f'''当前程序 SHA-256：`{reports['all']['sha256_before']}`。
九组相关回归、四项新增快速验证及两项手动原生验收共 **{len(passed)} 个不同测试通过**，
仍有 {len(ignored)} 项手动测试未执行，不能将其计为通过。
新增类型化来源生成 20 张实际 GPU 截图；原有属性映射手势再执行生成 16 张，
合计 36 张 1000×800 图。六组保存/重开均核验独立进程 PID。

最终工作区 all-target check（排除 Android，启用 FFmpeg 与 host diagnostics）、
两个新增/扩展测试文件的 rustfmt check、样式消费者检查及 git diff --check 通过。
编译保留既有 unused/dead-code 警告；日志中本机 Epic Overlay Vulkan JSON 缺失等
环境错误不屏蔽，不将目标站点通过扩张为全局无 Error 声明。

原始输出、失败记录、程序/源码哈希、进程信息和图像索引见
[证据清单](layer-time-typed-lanes-evidence/manifest.json) 与
[原始证据包](layer-time-typed-lanes-evidence/evidence.zip)。'''
text=doc.read_text(encoding='utf-8')
assert text.count('FINAL_RESULTS_PENDING')==1
doc.write_text(text.replace('FINAL_RESULTS_PENDING',paragraph),encoding='utf-8')
out.mkdir(parents=True,exist_ok=True)
paths=set()
for candidate in root.iterdir():
    if 'layer-time-typed-lanes' not in candidate.name:continue
    if candidate.is_dir():paths.update(p for p in candidate.rglob('*') if p.is_file())
    elif candidate.is_file():paths.add(candidate)
paths=sorted(p for p in paths if p.suffix.lower() in {'.log','.json','.png','.py','.txt'})
assert sum(p.stat().st_size for p in paths)<100*1024*1024
entries=[];archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
    for path in paths:
        relative=path.relative_to(root).as_posix();bundle.write(path,relative)
        entries.append({'path':relative,'bytes':path.stat().st_size,'sha256':sha(path)})
names=[]
for args in [['diff','--name-only','-z'],['ls-files','--others','--exclude-standard','-z']]:
    names+=subprocess.check_output(['git',*args],cwd=repo).decode().split('\0')
sources={name:sha(repo/name) for name in sorted(set(names)) if name and (repo/name).is_file() and 'layer-time-typed-lanes-evidence/' not in name}
manifest={'base':'ecd56ea66ac6ca817eefc90ec77fa92ec5e402f4','branch':'feat/layer-time-mapping','issue':257,'issue_complete':False,
          'results':reports,'checks':checks,'passed':sorted(passed),'remaining_ignored':sorted(ignored),
          'native_processes':processes,'images':images,'source_sha256':sources,'archive_sha256':sha(archive),'archive_entries':entries,
          'limits':['visible time editing controls and other mapped edit paths incomplete','physical OS input and other platforms not executed','Track f32 Hold semantics unchanged','numeric time fault sites and impossible address guards not independently fault-injected']}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for entry in entries:assert hashlib.sha256(bundle.read(entry['path'])).hexdigest()==entry['sha256']
print(json.dumps({'passed':len(passed),'ignored':len(ignored),'images':len(images),'archive_entries':len(entries),'archive_bytes':archive.stat().st_size}))
