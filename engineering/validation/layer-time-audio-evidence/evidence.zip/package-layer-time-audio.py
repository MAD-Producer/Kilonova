import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile
from datetime import datetime, timezone

repo = Path('E:/Dev/aem/.worktrees/layer-time-mapping')
raw = Path('E:/Dev/aem/artifacts/issue-goal-current')
out = repo / 'engineering/validation/layer-time-audio-evidence'
sources = [
    'crates/motion-model/src/composition.rs',
    'crates/motion-model/src/composition/audio_time.rs',
    'crates/motion-media/src/mixer.rs',
    'crates/motion-media/src/mixer/mapped.rs',
    'crates/motion-media/src/mixer/memory.rs',
    'crates/motion-media/tests/layer_time_audio.rs',
    'crates/motion-desktop-media/tests/layer_time_audio.rs',
    'desktop/app/src/audio_output/producer_observation/tests.rs',
]
final = {'model-final': (211, 0), 'media-final': (187, 2), 'core': (36, 0),
         'output': (27, 1), 'native-final': (1, 0)}
names = ['before', 'fixed', 'expanded', 'regression', 'model', 'media-serial',
         'native', 'native-retained', 'default-channels', 'workspace'] + list(final)
logs = {name: raw / f'layer-time-audio-{name}.log' for name in names}

def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def content(path):
    return path.read_text(encoding='utf-8', errors='replace')

assert 'test result: FAILED. 1 passed; 3 failed;' in content(logs['before'])
assert 'test result: FAILED. 93 passed; 6 failed;' in content(logs['regression'])
results = {}
programs = {}
for name, (passed, ignored) in final.items():
    text = content(logs[name])
    assert not re.search(r'^error|test result: FAILED', text, re.M), name
    rows = [tuple(map(int, match)) for match in re.findall(
        r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)]
    count = [sum(row[i] for row in rows) for i in range(3)]
    assert count == [passed, 0, ignored], (name, count)
    results[name] = dict(zip(['passed', 'failed', 'ignored'], count))
    for path in re.findall(r'\((E:[^\r\n()]+\.exe)\)', text):
        file = Path(path)
        programs[file.as_posix()] = identity(file)
check = content(logs['workspace'])
assert 'Finished `dev` profile' in check and not re.search(r'^error', check, re.M)
assert 'test result: ok. 1 passed; 0 failed;' in content(logs['default-channels'])

native = raw / 'layer-time-audio-native-files'
files = sorted(file for file in native.rglob('*') if file.is_file())
assert len(files) == 23, len(files)  # 4*5 actual media/source files + three producer outputs
for mode in ['reverse', 'nested', 'remap', 'freeze']:
    assert f'mode={mode} decoded_aac_frames=10240 exact_flat_pcm_control=true' in content(logs['native-final'])
    assert (native / mode / 'flat-reference.f32').stat().st_size == 9600 * 2 * 4
    assert (native / mode / 'decoded-aac.f32').stat().st_size == 10240 * 2 * 4
file_log = content(native / 'producer/motion-studio.log')
stderr = content(native / 'producer/stderr.txt')
stdout = content(native / 'producer/stdout.txt')
assert len(re.findall(r' ERROR ', file_log)) == 1
assert stderr.count('audio mixer failed playback=') == 1
assert 'audio mapped cache' not in stdout and 'audio mixer start' not in stdout
assert file_log.index('audio mixer start playback=') < file_log.index('audio mixer failed playback=')
for text in [file_log, stderr]:
    assert all(field in text for field in ['asset=83', 'first_sample=4790',
                                         'sample_frames=10', 'output_begin=0', 'output_end=10'])

out.mkdir(exist_ok=True)
with zipfile.ZipFile(out / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, path in logs.items():
        archive.write(path, 'logs/' + path.name)
    for path in files:
        archive.write(path, 'native/' + path.relative_to(native).as_posix())
    for name in sources:
        archive.write(repo / name, 'source-final/' + name)
    for name in ['crates/motion-media/src/mixer.rs', 'crates/motion-model/src/composition.rs']:
        archive.writestr('source-parent/' + name,
            subprocess.check_output(['git', 'show', '9f9bccd6:' + name], cwd=repo))
    archive.write(Path(__file__), 'package-layer-time-audio.py')

manifest = {
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'branch': 'feat/layer-time-mapping', 'parent': '9f9bccd6', 'issue': 257,
    'status': 'audio_execution_stage_only_issue_remains_open',
    'test_configuration': 'single-threaded as in existing CI; CARGO_BUILD_JOBS=1; CARGO_INCREMENTAL=0',
    'commands': {
        'model-final': 'cargo test -p motion-model --target-dir E:/Dev/aem/.tools/layer-time-mapping/target -- --test-threads=1',
        'media-final': 'cargo test -p motion-media --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1',
        'core': 'cargo test -p motion-core --test audio_levels --test audio_references --test composition_fps --test composition_resources --test subframe_clips --test layer_switches --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1',
        'output': 'cargo test -p motion-desktop --features ffmpeg,motion-host/diagnostics --bin motion-studio --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target audio_output:: -- --test-threads=1',
        'native-final': 'cargo test -p motion-desktop-media --locked --features ffmpeg,motion-host/diagnostics --test layer_time_audio --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture',
        'workspace': 'cargo check --workspace --all-targets --exclude motion-android --locked --features motion-desktop/ffmpeg,motion-host/diagnostics --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target',
        'default-channels': '<compiled motion-studio test binary> --exact audio_output::producer_observation::tests::mapped_pcm_read_failure_reaches_default_file_and_stderr_after_a_published_start --test-threads=1',
    },
    'source_sha256': {name: identity(repo / name) for name in sources},
    'results': results,
    'distinct_passed_tests': sum(v['passed'] for v in results.values()),
    'ignored_not_counted_as_passed': sum(v['ignored'] for v in results.values()),
    'duplicate_runs_not_added': [name for name in names if name not in final],
    'workspace_all_targets': 'passed excluding retired motion-android; desktop FFmpeg and host diagnostics',
    'raw_log_sha256': {path.name: identity(path) for path in logs.values()},
    'programs_at_final_verification': programs,
    'actual_media_and_default_channels': {path.relative_to(native).as_posix(): identity(path) for path in files},
    'archive': identity(out / 'evidence.zip'),
    'limitations': ['No real native audio-device acceptance (existing ignored test)',
                    'Two existing media large-file acceptances remain ignored',
                    'No velocity-adaptive antialias cutoff or pitch preservation',
                    'UI/editing/cache/pre-render/source-range and full real-time acceptance remain pending',
                    'Initial default parallel package test failure retained; budget and assertions unchanged'],
}
assert manifest['distinct_passed_tests'] == 462
(out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'passed': manifest['distinct_passed_tests'], 'ignored': 3,
                  'media_files_and_logs': len(files), 'archive': manifest['archive']}, ensure_ascii=False))
