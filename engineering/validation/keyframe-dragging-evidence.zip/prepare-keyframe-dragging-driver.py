from pathlib import Path

folder=Path('E:/Dev/aem/artifacts/pr-ci-followups')
script=(folder/'keyframe-selection-os-driver.py').read_text('utf-8')
script=script.replace('keyframe-selection-os-main-zh','keyframe-dragging-os-main-zh')
script=script.replace("STAGE = Path('E:/Dev/aem/artifacts/pr-ci-followups/keyframe-selection-ui-runtime')",
    "source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd='E:/Dev/aem/.worktrees/keyframe-dragging',text=True).strip()\nSTAGE=Path('E:/Dev/aem/artifacts/pr-ci-followups/keyframe-dragging-runtime-'+source_commit[:8])")
script=script.replace("cwd='E:/Dev/aem/.worktrees/layer-clipboard'","cwd='E:/Dev/aem/.worktrees/keyframe-dragging'")
script=script.replace("if not (STAGE / binary.name).exists(): shutil.copy2(binary, STAGE / binary.name)",
    "if not (STAGE / binary.name).exists(): shutil.copy2(binary, STAGE / binary.name)\nassert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==hashlib.file_digest((STAGE/binary.name).open('rb'),'sha256').hexdigest(), 'refusing to reuse a different staged executable'")
script=script.replace("seq = 0","seq = 0\nheld_keys=set()\nmouse_held=False")
script=script.replace("elif op in ('move','down','up'):","elif op in ('hold_keys','release_keys'):\n                focus(hwnd)\n                for value in action['keys']:\n                    user.keybd_event(value,0,0 if op=='hold_keys' else 2,0)\n                    if op=='hold_keys': held_keys.add(value)\n                    else: held_keys.discard(value)\n                    time.sleep(.025)\n            elif op in ('move','down','up'):")
script=script.replace("if op!='move': user.mouse_event(0x2 if op=='down' else 0x4,0,0,0,0)",
    "if op!='move':\n                    user.mouse_event(0x2 if op=='down' else 0x4,0,0,0,0)\n                    mouse_held=op=='down'")
script=script.replace("finally:\n    if app.poll() is None:",
    "finally:\n    if mouse_held: user.mouse_event(0x4,0,0,0,0)\n    for value in held_keys: user.keybd_event(value,0,2,0)\n    if app.poll() is None:")
target=folder/'keyframe-dragging-os-driver.py'
compile(script,str(target),'exec')
target.write_text(script,'utf-8')
print(target)
