"""External Windows input validation; no editor hooks or fabricated Input values."""
import ctypes
from ctypes import wintypes as W
import hashlib
import json
import os
from pathlib import Path
import queue
import shutil
import subprocess
import sys
import threading
import time
from PIL import ImageGrab

BASE = Path(os.environ.get('MOTION_KEYFRAME_OS_ARTIFACTS', 'E:/Dev/aem/artifacts/pr-ci-followups/keyframe-dragging-os-main-zh'))
BASE.mkdir(parents=True, exist_ok=True)
source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd='E:/Dev/aem/.worktrees/keyframe-dragging',text=True).strip()
STAGE=Path('E:/Dev/aem/artifacts/pr-ci-followups/keyframe-dragging-runtime-'+source_commit[:8])
STAGE.mkdir(exist_ok=True)
binary = Path('E:/Dev/aem/target/host-error-contract-verified/debug/motion-studio.exe')
if not (STAGE / binary.name).exists(): shutil.copy2(binary, STAGE / binary.name)
assert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==hashlib.file_digest((STAGE/binary.name).open('rb'),'sha256').hexdigest(), 'refusing to reuse a different staged executable'
for dll in Path('E:/Dev/aem/artifacts/video-first-preview/ffmpeg/prefix/bin').glob('*.dll'):
    if not (STAGE / dll.name).exists(): shutil.copy2(dll, STAGE / dll.name)
manifest = {'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd='E:/Dev/aem/.worktrees/keyframe-dragging',text=True).strip(), 'kind': 'local FFmpeg debug staging, not an official release archive',
            'files': {f.name: hashlib.file_digest(f.open('rb'), 'sha256').hexdigest()
                      for f in STAGE.iterdir() if f.is_file()}}
(BASE / 'runtime-manifest.json').write_text(json.dumps(manifest, indent=2), 'utf-8')
existing_project = os.environ.get('MOTION_KEYFRAME_OS_PROJECT')
if existing_project:
    project = Path(existing_project)
    assert (project / 'project.json').is_file(), project
else:
    project = BASE / 'project'
    project.mkdir(exist_ok=True)
    p = json.loads(Path('E:/Dev/aem/artifacts/pr-ci-followups/parent-main-sync-error-output/project/project.json').read_text('utf-8'))
    import copy
    first=copy.deepcopy(next(layer for layer in p['layers'] if layer['id']==7))
    second=copy.deepcopy(first); second['id']=8
    controller=copy.deepcopy(first); controller['id']=9; controller['content']={'kind':'null'}
    p['layers']=[first,second]
    p['width']=640; p['height']=360; p['frames']=120
    for layer,offset,name in zip(p['layers'],[7,40],['Position study','Separated axes']):
        layer['id']=7 if offset==7 else 9
        layer['name']=name
        layer['timeline']={'in_frame':offset,'out_frame':110,'offset_frame':offset}
        layer['transform']['position']={'value':[0.,0.,0.], 'keys':[
            {'frame':frame,'value':[float(frame),20.,0.],'ease':'linear'} for frame in [3,13]]}
        if offset==40:
            layer['transform']['position']={'axes':{
                axis:{'value':0.,'keys':[{'frame':f,'value':float(f) if axis=='x' else (20. if axis=='y' else 0.),'ease':'linear'} for f in [3,13]]}
                for axis in ['x','y','z']}}
    (project / 'project.json').write_text(json.dumps(p), 'utf-8')
settings = json.loads(Path('E:/Dev/aem/artifacts/custom-shortcuts/native-restart-verified/settings.json').read_text('utf-8'))
settings['shortcut_bindings'] = {'overrides': []}
settings['root'] = {'Split': {'edge': 'Top', 'split': .65,
    'first': {'Dock': {'id': 3, 'tabs': [3], 'active': 0}},
    'second': {'Dock': {'id': 4, 'tabs': [4], 'active': 0}}}}
settings['floating'] = []
settings['hidden'] = [1, 2, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]
settings['window_geometry'] = {}
if os.environ.get('MOTION_KEYFRAME_OS_PROPERTIES') == '1':
    settings['root'] = {'Split': {'edge': 'Right', 'split': .25,
        'first': settings['root'], 'second': {'Dock': {'id': 11, 'tabs': [11], 'active': 0}}}}
    settings['hidden'].remove(11)
if os.environ.get('MOTION_KEYFRAME_OS_FLOAT') == '1':
    settings['root'] = {'Dock': {'id': 3, 'tabs': [3], 'active': 0}}
    settings['floating'] = [4]
    settings['window_geometry'] = {'4': {'size': [1100, 450], 'position': [800, 200]}}
layout = BASE / 'workspace.json'
layout.write_text(json.dumps(settings), 'utf-8')
env = dict(os.environ)
for name in ['MOTION_LOG', 'MOTION_PROJECT', 'MOTION_LOCALE', 'MOTION_UI_STYLE']:
    env.pop(name, None)
env['MOTION_UI_LAYOUT'] = str(layout)
env['LOCALAPPDATA'] = str(BASE / 'userdata')
env['PATH'] = os.environ['SystemRoot'] + '/System32;' + os.environ['SystemRoot']
user = ctypes.windll.user32
kernel = ctypes.windll.kernel32
user.GetForegroundWindow.restype = W.HWND
user.WindowFromPoint.argtypes = [W.POINT]
user.WindowFromPoint.restype = W.HWND
user.GetAncestor.argtypes = [W.HWND, W.UINT]
user.GetAncestor.restype = W.HWND
user.SetForegroundWindow.argtypes = [W.HWND]
user.GetWindowThreadProcessId.argtypes = [W.HWND, ctypes.POINTER(W.DWORD)]
user.PostMessageW.argtypes = [W.HWND, W.UINT, W.WPARAM, W.LPARAM]
for name in ['GetWindowRect', 'GetClientRect']:
    getattr(user, name).argtypes = [W.HWND, ctypes.POINTER(W.RECT)]
user.ClientToScreen.argtypes = [W.HWND, ctypes.POINTER(W.POINT)]
user.GetDpiForWindow.argtypes = [W.HWND]
user.BringWindowToTop.argtypes = [W.HWND]
CB = ctypes.WINFUNCTYPE(W.BOOL, W.HWND, W.LPARAM)
previous = user.GetForegroundWindow()
stderr = (BASE / 'stderr.log').open('wb')
app = subprocess.Popen([str(STAGE / binary.name), '--mcp-ui', '--project', str(project), '--locale', os.environ.get('MOTION_KEYFRAME_OS_LOCALE', 'zh')],
    env=env, cwd=STAGE, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr,
    text=True, encoding='utf-8', creationflags=subprocess.CREATE_NO_WINDOW)
responses = queue.Queue()
raw = (BASE / 'stdout.jsonl').open('w', encoding='utf-8')
def reader():
    for line in app.stdout:
        raw.write(line); raw.flush(); responses.put(line)
threading.Thread(target=reader, daemon=True).start()
seq = 0
held_keys=set()
mouse_held=False
def request(method, params=None):
    global seq
    seq += 1
    payload = {'jsonrpc': '2.0', 'id': seq, 'method': method}
    if params is not None: payload['params'] = params
    app.stdin.write(json.dumps(payload) + '\n'); app.stdin.flush()
    result = json.loads(responses.get(timeout=30))
    assert result.get('id') == seq and 'error' not in result, result
    return result['result']
def state():
    return request('tools/call', {'name': 'motion_state', 'arguments': {}})['structuredContent']
def windows():
    found = []
    @CB
    def visit(hwnd, _):
        pid = W.DWORD(); user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == app.pid and user.IsWindowVisible(hwnd):
            title = ctypes.create_unicode_buffer(512); user.GetWindowTextW(hwnd, title, 512)
            r = W.RECT(); user.GetClientRect(hwnd, ctypes.byref(r))
            origin = W.POINT(); user.ClientToScreen(hwnd, ctypes.byref(origin))
            found.append({'hwnd': hwnd, 'title': title.value, 'client': [r.right, r.bottom],
                          'origin': [origin.x, origin.y], 'dpi': user.GetDpiForWindow(hwnd)})
        return True
    user.EnumWindows(visit, 0)
    return found
def focus(hwnd):
    assert any(w['hwnd'] == hwnd for w in windows()), 'refusing a foreign HWND'
    foreground = user.GetForegroundWindow()
    tid = user.GetWindowThreadProcessId(foreground, None)
    current = kernel.GetCurrentThreadId()
    attached = user.AttachThreadInput(current, tid, True) if tid != current else False
    try:
        user.ShowWindow(hwnd, 9); user.SetWindowPos(hwnd,W.HWND(-1),0,0,0,0,0x13); user.BringWindowToTop(hwnd); user.SetForegroundWindow(hwnd)
    finally:
        if attached: user.AttachThreadInput(current, tid, False)
    time.sleep(.15)
    assert user.GetForegroundWindow() == hwnd, 'OS focus was not granted'
def keys(hwnd, values):
    focus(hwnd)
    try:
        for v in values: user.keybd_event(v, 0, 0, 0); time.sleep(.025)
    finally:
        for v in reversed(values): user.keybd_event(v, 0, 2, 0); time.sleep(.025)
def click(hwnd, point, right=False, modifiers=()):
    focus(hwnd)
    origin = W.POINT(); user.ClientToScreen(hwnd, ctypes.byref(origin))
    user.SetCursorPos(origin.x + int(point[0]), origin.y + int(point[1]))
    time.sleep(.1)
    try:
        actual = user.GetAncestor(user.WindowFromPoint(W.POINT(origin.x + int(point[0]), origin.y + int(point[1]))), 2)
        assert actual == hwnd, f'pointer hits another HWND: requested={hwnd}, actual={actual}, windows={windows()}'
        assert user.GetForegroundWindow() == hwnd, 'focus changed before mouse press'
        for key in modifiers: user.keybd_event(key, 0, 0, 0)
        time.sleep(.04)
        user.mouse_event(0x8 if right else 0x2, 0, 0, 0, 0)
        time.sleep(.08)
        user.mouse_event(0x10 if right else 0x4, 0, 0, 0, 0)
    finally:
        for key in reversed(modifiers): user.keybd_event(key, 0, 2, 0)
def capture(hwnd, name):
    focus(hwnd); time.sleep(.4)
    r = W.RECT(); user.GetWindowRect(hwnd, ctypes.byref(r))
    ImageGrab.grab(bbox=(r.left, r.top, r.right, r.bottom)).save(BASE / (name + '.png'))
    (BASE / (name + '-geometry.json')).write_text(json.dumps({'windowRect':[r.left,r.top,r.right,r.bottom],'windows':windows(),'hwnd':hwnd},indent=2),'utf-8')
try:
    request('initialize', {'protocolVersion': '2025-11-25', 'capabilities': {},
                           'clientInfo': {'name': 'parent-os-input', 'version': '1'}})
    app.stdin.write(json.dumps({'jsonrpc': '2.0', 'method': 'notifications/initialized'}) + '\n')
    app.stdin.flush()
    initial = state()
    (BASE / 'initial-state.json').write_text(json.dumps(initial, indent=2), 'utf-8')
    deadline = time.monotonic() + 30
    while not any(w['title'].startswith('Motion Studio') for w in windows()):
        assert time.monotonic() < deadline, 'no visible application window'
        time.sleep(.1)
    main = next(w['hwnd'] for w in windows() if w['title'].startswith('Motion Studio'))
    user.SetWindowPos.argtypes = [W.HWND, W.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, W.UINT]
    user.SetWindowPos(main, W.HWND(-1), 60, 60, 1280, 850, 0x4)
    time.sleep(1)
    deadline = time.monotonic() + 30
    while True:
        settled = state()
        desktop = settled['desktop']
        expected_windows = 2 if os.environ.get('MOTION_KEYFRAME_OS_FLOAT') == '1' else 1
        if (not desktop['headless'] and desktop['sharedGpuDevice']
                and desktop['panelWindows'] == expected_windows
                and settled['presented'] > 0
                and settled['lastPresentedRevision'] == settled['revision']
                and settled['lastPresentedViewRevision'] == settled['viewRevision']):
            break
        assert time.monotonic() < deadline, 'native UI did not become ready'
        time.sleep(.1)
    (BASE / 'native-ready-state.json').write_text(json.dumps(settled, indent=2), 'utf-8')
    capture(main, 'startup')
    (BASE / 'ready.json').write_text(json.dumps({'pid': app.pid, 'windows': windows()}), 'utf-8')
    control = BASE / 'action.json'
    scripted = iter(json.loads(Path(sys.argv[1]).read_text('utf-8'))) if len(sys.argv) > 1 else None
    while True:
        if app.poll() is not None: raise RuntimeError('application exited unexpectedly: ' + str(app.returncode))
        if scripted is not None:
            action = next(scripted)
        else:
            if not control.exists(): time.sleep(.05); continue
            action = json.loads(control.read_text('utf-8')); control.unlink()
        response = {'id': action['id']}
        try:
            hwnd = action.get('hwnd', main)
            if action.get('window') == 'float':
                hwnd = next(w['hwnd'] for w in windows() if w['title'].endswith(' — Motion Studio'))
            op = action['op']
            if op == 'click': click(hwnd, action['point'], action.get('right', False), action.get('modifiers', []))
            elif op in ('hold_keys','release_keys'):
                focus(hwnd)
                for value in action['keys']:
                    user.keybd_event(value,0,0 if op=='hold_keys' else 2,0)
                    if op=='hold_keys': held_keys.add(value)
                    else: held_keys.discard(value)
                    time.sleep(.025)
            elif op in ('move','down','up'):
                focus(hwnd)
                origin=W.POINT(); user.ClientToScreen(hwnd,ctypes.byref(origin))
                point=action['point']; user.SetCursorPos(origin.x+int(point[0]),origin.y+int(point[1]))
                time.sleep(.1)
                if op!='move':
                    user.mouse_event(0x2 if op=='down' else 0x4,0,0,0,0)
                    mouse_held=op=='down'
            elif op == 'keys': keys(hwnd, action['keys'])
            elif op == 'capture': capture(hwnd, action['name'])
            elif op == 'state': response['state'] = state()
            elif op == 'windows': response['windows'] = windows()
            elif op == 'tool': response['result'] = request('tools/call', {'name': action['name'], 'arguments': action.get('arguments', {})})
            elif op == 'close':
                user.PostMessageW(main, 0x10, 0, 0); app.wait(timeout=30)
                response['exit'] = app.returncode
                (BASE / ('reply-' + str(action['id']) + '.json')).write_text(json.dumps(response, ensure_ascii=False, indent=2), 'utf-8')
                break
            else: raise ValueError(op)
            time.sleep(.35)
        except Exception as error:
            response['error'] = repr(error)
            if scripted is not None: raise
        (BASE / ('reply-' + str(action['id']) + '.json')).write_text(json.dumps(response, ensure_ascii=False, indent=2), 'utf-8')
finally:
    if mouse_held: user.mouse_event(0x4,0,0,0,0)
    for value in held_keys: user.keybd_event(value,0,2,0)
    if app.poll() is None: app.kill(); app.wait(timeout=10)
    stderr.close()
    if previous: user.SetForegroundWindow(previous)
