import json
from pathlib import Path
import sys
import time

root=Path(sys.argv[1]); plan=Path(sys.argv[2])
for action in json.loads(plan.read_text('utf-8')):
    reply=root/('reply-'+str(action['id'])+'.json')
    assert not reply.exists(),f'refusing to reuse action id {action["id"]}'
    temp=root/'action.pending'
    temp.write_text(json.dumps(action), 'utf-8')
    temp.replace(root/'action.json')
    deadline=time.monotonic()+35
    while not reply.exists():
        if time.monotonic()>=deadline:raise TimeoutError(f'OS action did not reply: {action}')
        time.sleep(.03)
    result=json.loads(reply.read_text('utf-8'))
    assert 'error' not in result,result
    print(action['id'],action['op'],'ok',flush=True)
