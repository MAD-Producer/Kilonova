import sys,subprocess,json,os,time,hashlib
from pathlib import Path
root=Path.cwd(); out=Path(__file__).parent; phase=sys.argv[1]; command=sys.argv[2:]
source_names=subprocess.check_output(['git','ls-files','desktop/app','crates/motion-host','crates','crates/motion-core','crates/motion-desktop-media','Cargo.toml','Cargo.lock'],encoding='utf-8').splitlines()
source_names+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','desktop/app','crates/motion-host','crates','crates/motion-core','crates/motion-desktop-media'],encoding='utf-8').splitlines()
def sources():
 return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(set(source_names)) if (root/n).is_file()}
meta={'command':command,'cwd':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_before':sources(),'env':{k:os.environ.get(k) for k in ['MOTION_LOG','MOTION_ERROR_TRANSPORT_EVIDENCE','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','FFMPEG_DIR','TEMP']}}
(out/(phase+'.json')).write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
a=time.monotonic()
with (out/(phase+'.stdout')).open('wb') as stdout,(out/(phase+'.stderr')).open('wb') as stderr:
 result=subprocess.run(command,stdout=stdout,stderr=stderr)
meta.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-a,source_after=sources())
(out/(phase+'.json')).write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'phase':phase,'exit_code':result.returncode,'elapsed_seconds':meta['elapsed_seconds']}))
sys.exit(result.returncode)

