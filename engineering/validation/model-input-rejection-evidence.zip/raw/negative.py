import hashlib, json, subprocess, sys
from pathlib import Path

out = Path(__file__).parent
source = Path('crates/motion-model/src/model.rs')
original = source.read_bytes()
needle = b'    pub fn validate(&self) -> Result<()> {\n        ensure(self.version == CURRENT_PROJECT_VERSION'
assert original.count(needle) == 1
mutated = original.replace(needle, b'    pub fn validate(&self) -> Result<()> {\n        return Ok(()); // controlled missing-validation negative\n        ensure(self.version == CURRENT_PROJECT_VERSION', 1)
meta = {'original_sha256': hashlib.sha256(original).hexdigest(),
        'mutated_sha256': hashlib.sha256(mutated).hexdigest()}
try:
    source.write_bytes(mutated)
    result = subprocess.run([sys.executable, str(out / 'run.py'), 'missing-validation-negative',
        'cargo', 'test', '--locked', '-p', 'motion-core', '--test', 'model_input_rejection',
        'decoded_invalid_projects_preserve_native_causes_at_validation_and_engine_construction',
        '--', '--exact', '--test-threads=1', '--nocapture'])
    meta['negative_exit_code'] = result.returncode
finally:
    source.write_bytes(original)
    meta['restored_sha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
    meta['restored'] = source.read_bytes() == original
    (out / 'mutation-restoration.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
assert meta['restored']
assert meta['negative_exit_code'] == 101, meta
stdout = (out / 'missing-validation-negative.stdout').read_text(encoding='utf-8')
stderr = (out / 'missing-validation-negative.stderr').read_text(encoding='utf-8')
assert '0 passed; 1 failed' in stdout and 'called `Result::unwrap_err()` on an `Ok` value' in stderr
print(json.dumps(meta))
