. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:CARGO_BUILD_JOBS='2'
$env:CARGO_INCREMENTAL='0'
$env:CARGO_TARGET_DIR='E:/Dev/aem/.tools/video-resource-retirement-target'
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:PYTHONIOENCODING='utf-8'
$env:FFMPEG_DIR='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1'
$env:LIBCLANG_PATH='E:/Dev/aem/.tools/python-libclang/clang/native'
$env:PATH="$env:FFMPEG_DIR/bin;$env:PATH"
python E:/Dev/aem/artifacts/issue-goal-current/model-input-rejection/run.py @args
exit $LASTEXITCODE

