import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path('E:/Dev/aem/.worktrees/layer-time-mapping')
RAW = Path('E:/Dev/aem/artifacts/issue-goal-current/vector-planning')
OUT = ROOT / 'engineering/validation/vector-scratch-planning-evidence'
DEPS = Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps')
SOURCES = [
    'crates/motion-render/src/layer_gpu.rs',
    'crates/motion-render/src/layer_gpu/groups.rs',
    'crates/motion-render/src/layer_gpu/groups/planning_tests.rs',
    'crates/motion-render/src/lib.rs',
    'crates/motion-render/src/renderer.rs',
    'crates/motion-render/src/renderer/vector_planning_tests.rs',
    'crates/motion-render/src/test_allocations.rs',
    'engineering/validation/vector-scratch-planning.md',
]

def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()

def read(path):
    data = path.read_bytes()
    return data.decode('utf-16' if data[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig')

results = {}
for name in ['planning-restored-final', 'vector-regression', 'workspace-final']:
    code = int(read(RAW / (name + '.exit')).strip())
    assert code == 0, (name, code)
    log = read(RAW / (name + '.log'))
    counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', log)
    assert all(int(failed) == 0 and int(ignored) == 0 for _, failed, ignored in counts)
    results[name] = {'exit_code': code, 'tests_passed': sum(int(passed) for passed, _, _ in counts), 'log': name + '.log'}
assert results['planning-restored-final']['tests_passed'] == 3
assert results['vector-regression']['tests_passed'] == 16
negative = read(RAW / 'planning-negative.log')
assert 'left: 240' in negative and 'left: 120' in negative
assert int(read(RAW / 'planning-negative.exit').strip()) == 101
for name, saved in [('crates/motion-render/src/layer_gpu/groups.rs', 'groups-before-negative.rs'), ('crates/motion-render/src/layer_gpu.rs', 'layer-before-negative.rs')]:
    assert sha(ROOT / name) == sha(RAW / saved), name
binaries = ['motion_render-1fcc3fb8d09fa888.exe', 'vector_budget_alignment-80f3822d5431cb6a.exe', 'vector_error_boundaries-4162b162d7ecfa99.exe', 'vector_groups-02147addf7395614.exe', 'vector_upload_reuse-a94ca798c1da72b3.exe']
manifest = {
    'base_commit': '9d085c0f1fb63106babb48d5781b700e20da6eac',
    'branch': 'perf/vector-scratch-planning',
    'issue': 126,
    'issue_complete': False,
    'results': results,
    'negative_control': {'exit_code': 101, 'failed_tests': 2, 'group_allocations': 240, 'flat_allocations': 120, 'iterations': 120},
    'first_failures': {'planning-first.exit': 101, 'planning-restored.exit': 101},
    'source_sha256_raw_files': {name: sha(ROOT / name) for name in SOURCES},
    'binary_sha256': {name: sha(DEPS / name) for name in binaries},
    'commands': [
        'cargo test -p motion-render --lib --features gpu-tests --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target planning -- --test-threads=1 --nocapture',
        'cargo test -p motion-render --features gpu-tests --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --test vector_groups --test vector_upload_reuse --test vector_budget_alignment --test vector_error_boundaries -- --test-threads=1 --nocapture',
        'cargo check --workspace --all-targets --exclude motion-android --locked --features motion-desktop/ffmpeg,motion-host/diagnostics --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target',
    ],
    'environment': {'adapter': 'NVIDIA GeForce RTX 4070 Laptop GPU', 'backend': 'Vulkan', 'driver': '591.86', 'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0'},
    'scope': {'counted': 'successful allocations on the calling test thread inside the named planning operations, after warmup', 'excluded': ['GPU initialization', 'fixture creation', 'background thread allocations', 'full-frame allocation and FPS claims']},
    'ci': 'pending at submission',
}
negative_hash = re.search(r'Hash\s*:\s*([0-9A-Fa-f]{64})', read(RAW / 'negative-binary-hash.txt')).group(1).lower()
assert negative_hash != manifest['binary_sha256']['motion_render-1fcc3fb8d09fa888.exe']
manifest['negative_control']['binary_sha256'] = negative_hash
manifest['negative_control']['replacements'] = {
    'groups.rs': ['self.needed_scratch.clear();', 'self.needed_scratch = HashSet::new();'],
    'layer_gpu.rs': ['self.raster_targets_scratch.clear();', 'self.raster_targets_scratch = std::collections::HashSet::new();'],
}
OUT.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(OUT / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(RAW.rglob('*')):
        if path.is_file():
            archive.write(path, 'raw/' + path.relative_to(RAW).as_posix())
    for name in SOURCES:
        archive.write(ROOT / name, 'final-source/' + name)
manifest['evidence_zip_sha256'] = sha(OUT / 'evidence.zip')
(OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(results))
