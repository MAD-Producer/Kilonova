from pathlib import Path
import hashlib, json, subprocess, zipfile

root=Path('E:/Dev/aem/.worktrees/desktop-release-contracts')
out=Path('E:/Dev/aem/artifacts/issue-goal-current/ui-text-layout')
for name in ['font-final-result.json','font-app-check-result.json','font-final-framework-build-result.json']:
    assert json.loads((out/name).read_text(encoding='utf-8-sig'))['exit']==0,name
native=json.loads((out/'font-final-native/results.json').read_text())
assert len(native['cases'])==6
assert all(x['exit']==(1 if x.get('expected_rejection') else 0) for x in native['cases'])
sources=['desktop/ui/src/text.rs','desktop/ui/src/text/fallback.rs','desktop/ui/src/text/layout.rs',
         'desktop/ui/src/text/glyph_index.rs','desktop/ui/src/text/format_controls_tests.rs',
         'desktop/ui/src/text/shaping.rs','desktop/ui/examples/framework.rs','tools/ci_ui_framework.py',
         'engineering/validation/ui-text-shaping-current.md','desktop/ui/Cargo.toml','Cargo.lock']
files={'source/'+p:root/p for p in sources}
for path in out.glob('*font*'):
    if path.is_file() and path.suffix in ['.stdout','.stderr','.json','.py']:
        files['raw/'+path.name]=path
for folder in ['font-final-native','font-fallback-native','font-source-observations',
               'font-source-final-observations','font-final-ui-v3-observations','font-final-observations']:
    for path in (out/folder).rglob('*'):
        if path.is_file(): files['raw/'+str(path.relative_to(out)).replace('\\','/')]=path
for path in (root/'engineering/validation/ui-text-layout-native').iterdir():
    files['source/'+str(path.relative_to(root)).replace('\\','/')]=path
executables={}
for line in (out/'font-final.stdout').read_text(encoding='utf-8-sig').splitlines():
    if not line.startswith('{'):continue
    item=json.loads(line)
    if item.get('reason')=='compiler-artifact' and item.get('executable') and item['profile']['test']:
        path=Path(item['executable']);executables[item['target']['name']]={'path':str(path),
          'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'profile':item['profile']}
assert len(executables)==5
manifest={
 'base_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'scope':'System font grapheme fallback and UI component native gallery; not complete issue 129',
 'unique_passed':132,'test_counts':[115,2,10,2,3], 'executables':executables,
 'native_exe_sha256':native['exe_sha256'],
 'commands':[
 ['cargo','test','-p','motion-ui','--lib','--test','text_layout','--test','text_bounds','--test','atlas_bounds','--test','text_shaping','--locked','--target-dir','E:/Dev/aem/.tools/viewer-inspection/native-target','--message-format=json','--','--test-threads=1','--nocapture'],
 ['cargo','build','-p','motion-ui','--example','framework','--locked','--target-dir','E:/Dev/aem/.tools/viewer-inspection/native-target','--message-format=json'],
 ['cargo','check','-p','motion-desktop','--features','ffmpeg','--locked','--offline','--target-dir','E:/Dev/aem/.tools/viewer-inspection/native-target','--message-format=json']],
 'environment':{'MOTION_LOG':'info','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0',
 'TEMP':'E:/Dev/aem/artifacts/pr-integration-current/link-tmp','TMP':'E:/Dev/aem/artifacts/pr-integration-current/link-tmp',
 'FFMPEG_DIR':'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1',
 'LIBCLANG_PATH':'E:/Dev/aem/.tools/python-libclang/clang/native'},
 'retained_limits':{'extra_font_faces':32,'extra_source_bytes':67108864,'negative_keys':128,'negative_key_bytes':16384},
 'remaining':['application default file/stderr sink qualification','color emoji',
              'complex bidi cursor/selection consistency','full desktop executable/native qualification'],
 'members':{name:{'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for name,path in sorted(files.items())}}
target=root/'engineering/validation/ui-font-fallback-evidence.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(files.items()):z.write(path,name)
    z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
with zipfile.ZipFile(target) as z:
    for name,item in manifest['members'].items():assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256'],name
print(json.dumps({'archive':str(target),'members':len(files)+1,'bytes':target.stat().st_size,
 'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2))
