from pathlib import Path
import hashlib, json, os, struct, subprocess, sys, time, traceback

root=Path('E:/Dev/aem/.worktrees/desktop-release-contracts')
out=Path(sys.argv[1]) if len(sys.argv)>1 else Path('E:/Dev/aem/artifacts/issue-goal-current/ui-text-layout/font-fallback-native')
out.mkdir(exist_ok=True)
exe=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/examples/framework.exe')
digest=hashlib.sha256(exe.read_bytes()).hexdigest()
os.environ['MOTION_LOG']='info'
os.environ['TEMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
os.environ['TMP']=os.environ['TEMP']
results=[]
def record(item):
    results.append(item)
    (out/'results.json').write_text(json.dumps({'exe_sha256':digest,'cases':results},ensure_ascii=False,indent=2),encoding='utf-8')
    print(item['case'],item.get('exit'),flush=True)

command=['python',str(root/'tools/ci_ui_framework.py'),'--binary',str(exe),'--output',str(out/'gallery')]
began=time.monotonic()
result=subprocess.run(command,cwd=root,capture_output=True)
(out/'gallery.stdout').write_bytes(result.stdout)
(out/'gallery.stderr').write_bytes(result.stderr)
record({'case':'original-native-verifier','exit':result.returncode,'seconds':time.monotonic()-began,'command':command})
assert result.returncode == 0, result.stderr.decode('utf-8',errors='replace')

sample='caf\u00e9 / cafe\u0301 \u00b7 \u0633\u0644\u0627\u0645 123 \u00b7 \u4f4d\u7f6e'
checks=['ok','independentUiOnly','numericDragOneUndo','undoRestored','floatingPresented','layoutRoundtrip',
        'secondaryButtonsPreservedGesture','secondaryOwnerGuarded','floatingCancellationRestored','tabNavigationGuarded']
for locale,size,name in [('en','1280x800','en-wide'),('zh','1280x800','zh-wide'),('en','800x600','en-narrow')]:
    report=out/(name+'.json')
    command=[str(exe),'--smoke',str(report),'--locale',locale,'--size',size,'--sample-text',sample]
    began=time.monotonic()
    try:
        result=subprocess.run(command,cwd=root,capture_output=True,timeout=45)
    except subprocess.TimeoutExpired as error:
        for stream in ['stdout','stderr']:
            (out/(name+'.timeout.'+stream)).write_bytes(getattr(error,stream) or b'')
        record({'case':name,'timeout':45,'seconds':time.monotonic()-began,'command':command})
        raise
    (out/(name+'.stdout')).write_bytes(result.stdout)
    (out/(name+'.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, result.stderr.decode('utf-8',errors='replace')
    assert result.stdout == b''
    data=json.loads(report.read_text(encoding='utf-8-sig'))
    assert all(data.get(key) is True for key in checks),data
    image=report.with_suffix('.png')
    pixels=image.read_bytes()
    assert pixels[:8] == b'\x89PNG\r\n\x1a\n' and len(pixels)>1024
    record({'case':name,'exit':result.returncode,'seconds':time.monotonic()-began,'command':command,
            'dimensions':struct.unpack('>II',pixels[16:24]),'image_sha256':hashlib.sha256(pixels).hexdigest()})

for name,args in [('missing-sample',['--sample-text']),('oversized-sample',['--sample-text','x'*16385])]:
    result=subprocess.run([str(exe),*args],cwd=root,capture_output=True,timeout=45)
    (out/(name+'.stdout')).write_bytes(result.stdout)
    (out/(name+'.stderr')).write_bytes(result.stderr)
    assert result.returncode == 1 and not result.stdout
    assert b'--sample-text requires a value of at most 16384 UTF-8 bytes' in result.stderr
    assert b'x'*20 not in result.stderr
    record({'case':name,'exit':result.returncode,'expected_rejection':True})
