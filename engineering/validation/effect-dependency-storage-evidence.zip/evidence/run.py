import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import re

root = Path('E:/Dev/aem/.worktrees/effect-dependency-storage')
out = Path(__file__).parent
phase, *command = sys.argv[1:]
files = ['crates/motion-render/src/effect_plan/preparation.rs', 'crates/motion-render/src/effect_plan/preparation/dependency_storage_tests.rs', 'crates/motion-render/src/renderer/preview_allocation_tests.rs']
sources = {f: hashlib.sha256((root / f).read_bytes()).hexdigest() for f in files}
start = time.time()
with (out / (phase + '.stdout')).open('wb') as stdout, (out / (phase + '.stderr')).open('wb') as stderr:
    result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr)
record = {'command': command, 'exit': result.returncode, 'elapsed_seconds': time.time() - start,
          'sources': sources, 'sources_after': {f: hashlib.sha256((root / f).read_bytes()).hexdigest() for f in files},
          'environment': {k: os.environ.get(k) for k in ['CARGO_TARGET_DIR', 'MOTION_LOG', 'FFMPEG_DIR']}}
record['binaries'] = {}
for name in re.findall(r'Running[^\r\n]*\(([^\r\n)]+\.exe)\)', (out / (phase + '.stderr')).read_text(encoding='utf-8', errors='replace')):
    binary = Path(name)
    record['binaries'][name] = {'sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                               'mtime_ns': binary.stat().st_mtime_ns}
(out / (phase + '.json')).write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps(record), flush=True)
for suffix in ['stdout', 'stderr']:
    print((out / (phase + '.' + suffix)).read_text(encoding='utf-8', errors='replace')[-4500:], flush=True)
