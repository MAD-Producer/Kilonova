import hashlib
import json
from pathlib import Path
import re
import statistics
import zipfile

out = Path(__file__).parent
root = Path('E:/Dev/aem/.worktrees/effect-dependency-storage')
phases = ['baseline-dependency', 'baseline-valid-limits', 'fixed-dependency', 'fixed-render-lib',
          'negative-restored-nested-storage', 'legacy-full-frame', 'negative-missing-image-edge',
          'restored-timestamp-render', 'final-render', 'final-desktop-check']
records = {phase: json.loads((out / (phase + '.json')).read_text(encoding='utf-8')) for phase in phases}
assert all(record['sources'] == record['sources_after'] for record in records.values())
for phase, code in [('baseline-dependency', 101), ('baseline-valid-limits', 101), ('fixed-dependency', 101),
                    ('fixed-render-lib', 0), ('negative-restored-nested-storage', 101), ('legacy-full-frame', 0),
                    ('negative-missing-image-edge', 101), ('restored-timestamp-render', 101), ('final-render', 0), ('final-desktop-check', 0)]:
    assert records[phase]['exit'] == code, (phase, records[phase]['exit'])
for file, sha in records['final-render']['sources'].items():
    assert hashlib.sha256((root / file).read_bytes()).hexdigest() == sha
    assert records['final-desktop-check']['sources'][file] == sha
for phase in ['negative-restored-nested-storage', 'negative-missing-image-edge', 'legacy-full-frame']:
    for file in ['crates/motion-render/src/effect_plan/preparation/dependency_storage_tests.rs',
                 'crates/motion-render/src/renderer/preview_allocation_tests.rs']:
        assert records[phase]['sources'][file] == records['final-render']['sources'][file]

final_text = (out / 'final-render.stdout').read_text(encoding='utf-8')
summaries = [tuple(map(int, match)) for match in re.findall(
    r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', final_text)]
assert len(summaries) == 7 and summaries[0][0] == 314, summaries
assert all(not any(row[1:]) for row in summaries), summaries
stale = json.loads((out / 'restored-timestamp-evidence.json').read_text(encoding='utf-8'))['observations'][-1]
binaries = {name.replace('\\', '/'): value for name, value in records['final-render']['binaries'].items()}
assert binaries[stale['file'].replace('\\', '/')]['sha256'] != stale['sha256']
assert 'FAILED. 2 passed; 1 failed;' in (out / 'negative-restored-nested-storage.stdout').read_text(encoding='utf-8')
assert 'FAILED. 1 passed; 2 failed;' in (out / 'negative-missing-image-edge.stdout').read_text(encoding='utf-8')
assert 'cases=625 refused=500 recovery_allocations=0' in final_text
allocation_rows = [tuple(map(int, match)) for match in re.findall(
    r'dependency_validation layers=(\d+) repetition=(\d+) allocations=(\d+)', final_text)]
assert len(allocation_rows) == 16 and all(row[2] == 8 for row in allocation_rows)

def frames(phase):
    result = []
    for line in (out / (phase + '.stdout')).read_text(encoding='utf-8').splitlines():
        at = line.find('{')
        if at < 0:
            continue
        try:
            row = json.loads(line[at:])
        except ValueError:
            continue
        if isinstance(row, dict) and 'kind' in row and 'total' in row:
            result.append(row)
    assert len(result) == 192, (phase, len(result))
    return result

comparison = []
for phase in ['legacy-full-frame', 'final-render']:
    rows = frames(phase)
    for kind in ['solid', 'vector', 'matte', 'effect']:
        for layers in [1, 8, 32]:
            group = [row for row in rows if row['kind'] == kind and row['layers'] == layers]
            assert len(group) == 16
            comparison.append({'phase': phase, 'kind': kind, 'layers': layers, 'frames': len(group),
                               **{key: statistics.median(row[key] for row in group)
                                  for key in ['sample', 'prepare', 'create', 'encode', 'submit', 'poll', 'total']}})
for layers in [8, 32]:
    old, new = [row for row in comparison if row['kind'] == 'effect' and row['layers'] == layers]
    assert new['total'] < old['total'], (old, new)

summary = {'test_targets': summaries, 'tests_passed': sum(row[0] for row in summaries),
           'dependency_checks': allocation_rows, 'reference_graphs': 625, 'cycles_refused': 500,
           'full_frame_comparison': comparison, 'final_sources': records['final-render']['sources'],
           'limits': ['Calling-thread allocation counts, not all process threads or byte totals.',
                      'Whole-frame allocation count still grows with effect/matte work.',
                      'Actual GPU captures compare complete pixels; no native-window/UI acceptance claimed.',
                      'Desktop check compiles FFmpeg targets; it does not execute the full desktop/media suite.']}
(out / 'test-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
members = {}
for phase in phases:
    for suffix in ['json', 'stdout', 'stderr']:
        file = out / (phase + '.' + suffix)
        members['runs/' + file.name] = file.read_bytes()
for name in ['run.py', 'package.py', 'test-summary.json', 'preparation.baseline.rs', 'preparation.fixed.rs', 'restored-timestamp-evidence.json']:
    members['evidence/' + name] = (out / name).read_bytes()
for file in records['final-render']['sources']:
    members['sources/' + file] = (root / file).read_bytes()
mutant = (out / 'preparation.fixed.rs').read_bytes().replace(b'dependencies[node][1] = source;', b'dependencies[node][1] = NO_INPUT;')
# The actual injection used Path.write_text on Windows after universal-newline
# reading; reconstruct its CRLF bytes, rather than the fixed source's LF bytes.
mutant = mutant.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')
assert hashlib.sha256(mutant).hexdigest() == records['negative-missing-image-edge']['sources']['crates/motion-render/src/effect_plan/preparation.rs']
members['evidence/preparation.missing-image-edge.rs'] = mutant
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in members.items()}
members['MANIFEST.json'] = json.dumps(manifest, indent=2).encode()
destination = root / 'engineering/validation/effect-dependency-storage-evidence.zip'
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(destination) as archive:
    assert set(archive.namelist()) == set(members)
    assert archive.testzip() is None
    assert all(archive.read(name) == data for name, data in members.items())
receipt = {'archive': str(destination), 'members': len(members), 'bytes': destination.stat().st_size,
           'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'tests_passed': summary['tests_passed']}
(out / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt), flush=True)
print(json.dumps([row for row in comparison if row['kind'] == 'effect']), flush=True)
