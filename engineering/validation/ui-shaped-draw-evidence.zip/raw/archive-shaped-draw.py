from pathlib import Path
import hashlib, json, subprocess, zipfile

root = Path('E:/Dev/aem/.worktrees/desktop-release-contracts')
out = Path('E:/Dev/aem/artifacts/issue-goal-current/ui-text-layout')
assert json.loads((out/'draw-observations-result.json').read_text(encoding='utf-8-sig'))['exit'] == 0
assert json.loads((out/'framework-native-result.json').read_text(encoding='utf-8-sig'))['exit'] == 0
assert all(x['exit'] == 0 for x in json.loads((out/'framework-samples/results.json').read_text()))

sources = [
 'desktop/ui/src/text.rs', 'desktop/ui/src/text/fitting.rs',
 'desktop/ui/src/text/layout.rs', 'desktop/ui/src/text/glyph_index.rs',
 'desktop/ui/src/text/format_controls_tests.rs', 'desktop/ui/src/ui.rs',
 'desktop/ui/tests/text_layout.rs', 'desktop/ui/tests/text_bounds/grapheme.rs',
 'desktop/ui/examples/framework.rs', 'engineering/validation/ui-text-shaping-current.md',
 'Cargo.lock', 'desktop/ui/Cargo.toml', 'tools/ci_ui_framework.py',
]
files = {f'source/{p}': root/p for p in sources}
for prefix in ['initial-draw-ui', 'draw-ui', 'draw-observations', 'framework-build', 'framework-sample-build']:
    for path in out.glob(prefix+'*'):
        if path.is_file(): files['raw/'+path.name] = path
for name in ['framework-native-result.json', 'framework-native-exe.json',
             'framework-native.stdout', 'framework-native.stderr', 'archive-shaped-draw.py']:
    path = out/name
    if path.exists(): files['raw/'+name] = path
for folder in ['framework-native', 'framework-samples', 'shaped-observations']:
    for path in (out/folder).rglob('*'):
        if path.is_file(): files['raw/'+str(path.relative_to(out)).replace('\\','/')] = path

executables = {}
for line in (out/'draw-observations.stdout').read_text(encoding='utf-8-sig').splitlines():
    if not line.startswith('{'): continue
    item = json.loads(line)
    if item.get('reason') != 'compiler-artifact' or not item.get('executable'): continue
    path = Path(item['executable'])
    if item['profile']['test']:
        executables[item['target']['name']] = {
            'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'profile': item['profile'],
        }
assert len(executables) == 5, executables.keys()
manifest = {
 'base_head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'scope': 'UI shaped draw integration, component faults, native gallery; not full editor/release acceptance',
 'test_counts': [109,2,10,2,3], 'unique_passed': 126,
 'executables': executables,
 'remaining': ['default-font Arabic coverage missing in both sample captures',
               'color emoji and general script fallback',
               'actual application default file/stderr fault sink qualification',
               'complex bidi cursor/edit consistency and whole issue 129'],
 'command': ['cargo','test','-p','motion-ui','--lib','--test','text_layout',
             '--test','text_bounds','--test','atlas_bounds','--test','text_shaping',
             '--locked','--target-dir','E:/Dev/aem/.tools/viewer-inspection/native-target',
             '--message-format=json','--','--test-threads=1','--nocapture'],
 'environment': {'MOTION_LOG':'info','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0',
                 'TEMP':'E:/Dev/aem/artifacts/pr-integration-current/link-tmp',
                 'TMP':'E:/Dev/aem/artifacts/pr-integration-current/link-tmp'},
 'members': {name:{'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                   'bytes':path.stat().st_size} for name,path in sorted(files.items())},
}
target = root/'engineering/validation/ui-shaped-draw-evidence.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(files.items()): z.write(path,name)
    z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
with zipfile.ZipFile(target) as z:
    for name,item in manifest['members'].items():
        assert hashlib.sha256(z.read(name)).hexdigest() == item['sha256'],name
print(json.dumps({'archive':str(target),'members':len(files)+1,'bytes':target.stat().st_size,
                  'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2))
