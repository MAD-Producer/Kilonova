from pathlib import Path
w=Path('E:/Dev/aem/.worktrees/layer-time-mapping')
p=w/'crates/motion-core/src/command_registry.rs'
p.write_text(p.read_text(encoding='utf-8').replace('easing_schema()', 'named_schema("Easing").1'),encoding='utf-8')
p=w/'desktop/app/src/panels/animation_controls/time.rs'
s=p.read_text(encoding='utf-8')
s=s.replace('pub(super) struct Entry', '''/// Author identity is never encoded in a display coordinate.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in crate::panels) enum Address {
    Frame(i64),
    Local(i32),
    Spatial(u64),
}
#[derive(Clone, Copy, Debug)]
pub(super) struct KeyTime {
    pub address: Address,
    pub local: f64,
}
impl Address {
    pub(super) fn selected(self, target: KeyframeTarget) -> Option<super::super::key_selection::AddressedKey> {
        use super::super::key_selection::{AddressedKey, Key, LocalKey, SpatialKey};
        Some(match self {
            Self::Frame(frame) => AddressedKey::Frame(Key { target, frame: frame.try_into().ok()? }),
            Self::Local(frame) => AddressedKey::Local(LocalKey { target, frame }),
            Self::Spatial(id) => AddressedKey::Spatial(SpatialKey { target, id }),
        })
    }
}
pub(super) struct Entry''')
s=s.replace('pub frame: i64,','pub address: Address,\n    pub local: f64,')
pos=s.index('        let keys = match track["keys"]')
s=s[:pos]+'''        if let Some(keys) = track.get("spatial_keys") {
            let keys = keys.as_array().filter(|keys| keys.len() <= 16_385)
                .ok_or_else(|| Error::Invalid("invalid mini spatial key array".into()))?;
            let mut result = Vec::with_capacity(keys.len());
            let mut ids = std::collections::BTreeSet::new();
            for value in keys {
                let id = value["id"].as_u64().filter(|id| *id > 0 && ids.insert(*id))
                    .ok_or_else(|| Error::Invalid("invalid mini spatial key identity".into()))?;
                let local = value["local_frame"].as_f64().filter(|t| t.is_finite())
                    .ok_or_else(|| Error::Invalid("invalid mini spatial key time".into()))?;
                if result.last().is_some_and(|entry: &Entry<'_>| entry.local > local) {
                    return Err(Error::Invalid("mini spatial keys are not in authored order".into()));
                }
                let composition = self.clock.projected_composition_frame(local, self.offset)?;
                if value["frame"].as_f64() != Some(composition) {
                    return Err(Error::Invalid("mini spatial key projection disagrees with clock".into()));
                }
                result.push(Entry {value, address: Address::Spatial(id), local, composition});
            }
            return Ok(result);
        }
''' + s[pos:]
s=s.replace('entry.frame >= i64::from(local)', 'entry.local >= f64::from(local)')
s=s.replace('                frame,\n                composition,','                address: if self.mapped { Address::Local(frame as i32) } else { Address::Frame(frame) },\n                local: if self.mapped { frame as f64 } else { self.clock.key_edit_time(composition, self.offset)? },\n                composition,')
s=s.replace('        frame: i64,\n        easing: Easing,','        address: Address,\n        easing: Easing,')
s=s.replace('        if self.mapped {\n            Command::LocalKeyframes', '''        if let Address::Spatial(key) = address {
            return Command::SpatialKeyframes {
                target: KeyframeTarget::Property { object, property, axis },
                edit: motion_core::SpatialKeyEdit::Curve { key, easing },
            };
        }
        let frame = match address { Address::Frame(frame) => frame, Address::Local(frame) => i64::from(frame), Address::Spatial(_) => unreachable!() };
        if self.mapped {
            Command::LocalKeyframes''')
s=s.replace('        self.key_local = mapped;', '''        self.selected_key = Some(if mapped { Address::Local(frame as i32) } else { Address::Frame(frame) });''')
insert=s.index('    pub(in crate::panels) fn take_local_selection(')
s=s[:insert]+'''    pub(super) fn select_address(&mut self, state: &Value, object: u64, property: Property, axis: Option<Axis>, address: Address) {
        self.choose_track_in(state, object, property, axis);
        self.selected_key = Some(address);
        self.key_explicit = true;
        match address {
            Address::Local(frame) => self.local_selection = Some(Some(super::super::key_selection::LocalKey {
                target: KeyframeTarget::Property {object,property,axis}, frame })),
            Address::Spatial(id) => self.spatial_selection = Some(Some(super::super::key_selection::SpatialKey {
                target: KeyframeTarget::Property {object,property,axis}, id })),
            Address::Frame(_) => {},
        }
    }
    pub(in crate::panels) fn take_spatial_selection(&mut self) -> Option<Option<super::super::key_selection::SpatialKey>> {
        self.spatial_selection.take()
    }
''' + s[insert:]
p.write_text(s,encoding='utf-8')
