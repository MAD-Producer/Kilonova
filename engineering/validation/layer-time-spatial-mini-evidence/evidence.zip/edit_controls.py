from pathlib import Path
w=Path('E:/Dev/aem/.worktrees/layer-time-mapping')
p=w/'desktop/app/src/panels/animation_controls.rs'
s=p.read_text(encoding='utf-8')
s=s.replace('mod time;', 'pub(in crate::panels) mod time;')
s=s.replace('selected_key: Option<i64>', 'selected_key: Option<time::Address>')
s=s.replace('    key_local: bool,\n','')
s=s.replace('    local_selection: Option<Option<super::key_selection::LocalKey>>,','    local_selection: Option<Option<super::key_selection::LocalKey>>,\n    spatial_selection: Option<Option<super::key_selection::SpatialKey>>,')
s=s.replace('Option<(u64, Property, Option<Axis>, i64)>', 'Option<(u64, Property, Option<Axis>, time::Address)>')
s=s.replace('Option<(motion_core::KeyframeTarget, i64)>','Option<(motion_core::KeyframeTarget, time::Address)>')
s=s.replace('            self.key_local = false;\n','')
s=s.replace('        self.key_local = false;\n','')
s=s.replace('self.selected_key = Some(frame);', 'self.selected_key = Some(time::Address::Frame(frame));')
s=s.replace('if !self.key_explicit || self.key_local {', 'if !self.key_explicit {')
s=s.replace('        Some(KeySelection {\n            object,', '        let time::Address::Frame(frame) = self.selected_key? else { return None; };\n        Some(KeySelection {\n            object,')
s=s.replace('frame: self.selected_key?.try_into().ok()?', 'frame: frame.try_into().ok()?')
s=s.replace('        self.local_selection = None;', '        self.local_selection = None;\n        self.spatial_selection = None;')
start=s.index('        if !timing.mapped && self.key_local')
end=s.index('        let animated =',start)
s=s[:start]+'''        // Convert an explicit legacy selection only once and only at an exact,
        // unambiguous projection. A stale stable ID must never claim a neighbour.
        if timing.mapped && self.key_explicit {
            if let Some(time::Address::Frame(frame)) = self.selected_key {
                let matching: Vec<_> = keys.iter().filter(|key| key.composition == frame as f64).collect();
                self.selected_key = (matching.len() == 1).then(|| matching[0].address);
            }
        }
        self.display_track(object, property, self.axis);
        let key_valid = !self.key_explicit || self.selected_key.is_some_and(|address|
            keys.iter().any(|key| key.address == address));
        let retargeted = self.drag_key.is_some_and(|key|
            Some(key) != self.selected_key.map(|address| (object, property, self.axis, address)));
        if (locked || !key_valid || retargeted) && self.cancel() {
            out.push(Action::History(4));
            return;
        }
        let spatial = track.get("spatial_keys").is_some();
''' + s[end:]
s=s.replace('!locked && (animated || !timing.mapped || timing.integer().is_some())', '!locked && (animated || spatial || !timing.mapped || timing.integer().is_some())')
s=s.replace('!locked && (!timing.mapped || timing.integer().is_some())', '!locked && (spatial || !timing.mapped || timing.integer().is_some())')
old='''            self.select_display_key(state, object, property, self.axis,
                if timing.mapped { i64::from(timing.integer().expect("enabled exact key")) } else { frame as i64 }, timing.mapped);'''
new='''            if spatial {
                // New IDs are assigned by the worker. Do not fabricate one from time.
                self.clear_key();
            } else {
                self.select_display_key(state, object, property, self.axis,
                    if timing.mapped { i64::from(timing.integer().expect("enabled exact key")) } else { frame as i64 }, timing.mapped);
            }'''
assert old in s;s=s.replace(old,new)
s=s.replace('keys.iter().position(|key| key.frame == f)', 'keys.iter().position(|key| key.address == f)')
s=s.replace('.rposition(|key| key.frame as f64 <= timing.local)', '.rposition(|key| key.local <= timing.local)')
s=s.replace('let selected_frame = keys[selected].frame;', 'let selected_address = keys[selected].address;\n        let selected_frame = keys[selected].local;')
s=s.replace('self.selected_key = Some(selected_frame);\n            self.key_local = timing.mapped;', 'self.selected_key = Some(selected_address);')
s=s.replace('self.select_display_key(state, object, property, self.axis, next.frame, timing.mapped);', 'self.select_address(state, object, property, self.axis, next.address);')
s=s.replace('selected_frame.to_string()', 'keys[selected].composition.to_string()')
start=s.index('            !locked && (timing.mapped || selected_frame >= 0)')
end=s.index('        *y += 30.;',start)
s=s[:start]+'''            !locked && (spatial || timing.mapped || selected_frame >= 0.) && (spatial || !timing.mapped || timing.integer().is_some()) && self.dragging.is_none() && key_valid,
        ) {
            if let time::Address::Spatial(id) = selected_address {
                out.push(Action::Edit(Command::SpatialKeyframes {
                    target: motion_core::KeyframeTarget::Property {object, property, axis: self.axis},
                    edit: motion_core::SpatialKeyEdit::Time {key: id, time: timing.composition},
                }));
                self.select_address(state, object, property, self.axis, selected_address);
            } else {
                let destination = if timing.mapped { i64::from(timing.integer().expect("enabled exact key")) } else { frame as i64 };
                let from = match selected_address {time::Address::Frame(frame)=>frame,time::Address::Local(frame)=>i64::from(frame),time::Address::Spatial(_)=>unreachable!()};
                if let Some(delta) = destination.checked_sub(from).and_then(|d| i32::try_from(d).ok()) {
                    out.push(Action::Edit(if timing.mapped {
                        Command::LocalKeyframes { target: motion_core::KeyframeTarget::Property { object, property, axis: self.axis },
                            edit: motion_core::LocalKeyEdit::Translate { frames: vec![from as i32], delta_frame: delta, copy: false, value_offset: None } }
                    } else { Command::MoveKey { object, property, axis: self.axis, from: from as u32, to: frame } }));
                    self.select_display_key(state, object, property, self.axis, destination, timing.mapped);
                } else {
                    let _ = observe!("curve.controls.move_delta", Err::<(),_>("local move exceeds signed frame range"),
                        "object={object} property={property:?} from={from} to={destination}");
                }
            }
        }
        if button(
            list, atlas, input,
            Rect::new(start + width / 2., *y, width / 2., 24.),
            locale.t(T::DeleteKey),
            !locked && (spatial || timing.mapped || selected_frame >= 0.) && self.dragging.is_none() && key_valid,
        ) {
            out.push(Action::Edit(match selected_address {
                time::Address::Spatial(key) => Command::SpatialKeyframes { target: motion_core::KeyframeTarget::Property {object,property,axis:self.axis}, edit: motion_core::SpatialKeyEdit::Delete {key} },
                time::Address::Local(frame) => Command::LocalKeyframes { target: motion_core::KeyframeTarget::Property { object, property, axis: self.axis }, edit: motion_core::LocalKeyEdit::Delete { frames: vec![frame] } },
                time::Address::Frame(frame) => Command::DeleteKey { object, property, axis: self.axis, frame: frame as u32 },
            }));
            self.clear_key();
            if spatial { self.spatial_selection = Some(None); }
            else if timing.mapped { self.local_selection = Some(None); }
        }
''' +s[end:]
start=s.index('        let mut easing = super::graph_handles::observed_easing(')
end=s.index('        let choices =',start)
s=s[:start]+'''        let mut easing = if spatial {
            let Some(easing) = observe!("curve.controls.spatial_easing",
                serde_json::from_value::<Easing>(keyframe["easing"].clone()).map_err(motion_core::Error::from)
                    .and_then(|easing| { easing.validate()?; Ok(easing) }),
                "object={object} property={property:?} key={selected_address:?} phase=easing").ok() else { return; };
            easing
        } else {
            super::graph_handles::observed_easing(keyframe, object, property, selected_frame)
        };
        let fixed_interval = !spatial || keyframe["roving"] == false && keys.get(selected + 1).is_some_and(|key| key.value["roving"] == false);
        let editable = !locked && (timing.mapped || selected_frame >= 0.) && selected + 1 < keys.len() && key_valid && fixed_interval;
''' +s[end:]
s=s.replace('let clipboard_frame = if timing.mapped { None } else { u32::try_from(selected_frame).ok() };', 'let clipboard_frame = match selected_address {time::Address::Frame(frame)=>u32::try_from(frame).ok(),_=>None};')
s=s.replace('let clipboard_local = timing.mapped.then_some(selected_frame).and_then(|frame| i32::try_from(frame).ok());', 'let clipboard_local = match selected_address {time::Address::Local(frame)=>Some(frame),_=>None};')
s=s.replace('self.mini.draw(list,atlas,', 'self.mini.draw_interval(list,atlas,')
s=s.replace('selected_frame,keys.get(selected+1).map(|key|key.frame),', 'time::KeyTime {address:selected_address,local:selected_frame},keys.get(selected+1).map(|key|time::KeyTime {address:key.address,local:key.local}),')
s=s.replace('self.select_display_key(state, object, property, self.axis, selected_frame, timing.mapped);', 'self.select_address(state, object, property, self.axis, selected_address);')
s=s.replace('self.drag_key = Some((object, property, self.axis, selected_frame));', 'self.drag_key = Some((object, property, self.axis, selected_address));')
s=s.replace('object, property, self.axis, selected_frame, easing)', 'object, property, self.axis, selected_address, easing)')
p.write_text(s,encoding='utf-8')
p=w/'desktop/app/src/panels/animation_controls/selection.rs'
s=p.read_text(encoding='utf-8').replace('self.selected_key = Some(frame);','self.selected_key = Some(time::Address::Frame(frame));').replace('        self.key_local = false;\n','')
p.write_text(s,encoding='utf-8')
p=w/'desktop/app/src/panels/graph_ranges.rs'
s=p.read_text(encoding='utf-8').replace('Option<(KeyframeTarget, i64)>','Option<(KeyframeTarget, super::animation_controls::time::Address)>').replace('target: KeyframeTarget, frame: i64','target: KeyframeTarget, frame: super::animation_controls::time::Address')
p.write_text(s,encoding='utf-8')
p=w/'desktop/app/src/panels/curves.rs'
s=p.read_text(encoding='utf-8')
at=s.index('        if let Some(key) = panels.animation_controls.take_local_selection()')
s=s[:at]+'''        if let Some(key) = panels.animation_controls.take_spatial_selection() {
            let _ = observe!("curve.controls.spatial_selection",
                panels.selected_keys.apply_addressed(state, key.map(super::key_selection::AddressedKey::Spatial),
                    super::key_selection::Mode::Replace),
                "object={object:?} phase=spatial_selection");
        }
''' +s[at:]
p.write_text(s,encoding='utf-8')
