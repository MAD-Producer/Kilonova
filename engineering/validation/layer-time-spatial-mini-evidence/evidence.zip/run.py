import os,subprocess,json,hashlib,time,re,sys
from pathlib import Path
root=Path(__file__).resolve().parent
binary=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-b34b3a7e7eb835e8.exe')
env=os.environ.copy();env.pop('MOTION_LOG',None)
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['MOTION_STABLE_SPATIAL_FAULT_ARTIFACTS']=str(root/'faults-final')
env['MOTION_SPATIAL_MINI_NATIVE_ARTIFACTS']=str(root/'native-final')
groups=[('new',['panels::animation_controls::spatial_tests::']),
 ('mini',['panels::animation_controls::mini::']),
 ('mapped',['panels::animation_controls::mapped_tests::']),
 ('controls',['panels::animation_controls::tests::']),
 ('ranges-mini',['panels::graph_ranges::tests::mini::']),
 ('stable-numeric',['panels::property_authoring::spatial_tests::']),
 ('native',['--exact','panels::animation_controls::spatial_tests::native::native_spatial_mini_captures_commit_and_reopens_in_separate_process','--ignored'])]
rows=[]
for name,args in groups:
 if len(sys.argv)>1 and name not in sys.argv[1:]:continue
 sha=hashlib.sha256(binary.read_bytes()).hexdigest();start=time.time()
 with (root/(name+'.log')).open('wb') as log:
  result=subprocess.run([str(binary),*args,'--nocapture','--test-threads=1'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 content=(root/(name+'.log')).read_text(encoding='utf-8',errors='replace')
 matches=list(re.finditer(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',content))
 row=dict(group=name,args=args,exit=result.returncode,seconds=round(time.time()-start,3),exe=str(binary),exeSha256=sha)
 if matches:
  m=matches[-1];row.update(passed=int(m[1]),failed=int(m[2]),ignored=int(m[3]))
 rows.append(row);(root/('results-'+('-'.join(sys.argv[1:]) or 'all')+'.json')).write_text(json.dumps(rows,indent=2),encoding='utf-8')
 print(json.dumps(row),flush=True)
 assert sha==hashlib.sha256(binary.read_bytes()).hexdigest()
 if result.returncode:raise SystemExit(result.returncode)
 assert row.get('passed',0)>0,'empty test filter'
