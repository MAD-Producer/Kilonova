from pathlib import Path
w=Path('E:/Dev/aem/.worktrees/layer-time-mapping')
p=w/'desktop/app/src/panels/animation_controls/mini.rs'
s=p.read_text(encoding='utf-8')
s=s.replace('use motion_core::KeyframeTarget;', 'use motion_core::KeyframeTarget;\nuse super::time::{Address, KeyTime};')
at=s.index('pub(super) fn selection(')
end=s.index('    let times: Vec<_>',at)
s=s[:at]+'''#[cfg(test)]
fn legacy_time(state: &Value, target: &KeyframeTarget, frame: i64) -> KeyTime {
    KeyTime {address: if super::time::mapped(state,target) {Address::Local(frame as i32)} else {Address::Frame(frame)},local:frame as f64}
}
#[cfg(test)]
pub(super) fn selection(state: &Value, target: &KeyframeTarget, start: i64, end: Option<i64>, context: &Context<'_>, legacy: Option<KeySelection>, easing: Easing, automatic: Bounds) -> Option<Bounds> {
    selection_interval(state,target,legacy_time(state,target,start),end.map(|f|legacy_time(state,target,f)),context,legacy,easing,automatic)
}
fn selection_interval(
    state: &Value,
    target: &KeyframeTarget,
    start: KeyTime,
    end: Option<KeyTime>,
    context: &Context<'_>,
    legacy: Option<KeySelection>,
    easing: Easing,
    automatic: Bounds,
) -> Option<Bounds> {
    let end = end.filter(|end| end.local > start.local)?;
    let selected = |key: KeyTime| {
        let address = key.address.selected(target.clone())?;
        Some(match context.selection.status(state) {
            Status::Current => context.selection.contains_addressed(&address),
            Status::Unowned => match key.address {
                Address::Frame(frame) => legacy.is_some_and(|key| {
                    KeyframeTarget::Property {object:key.object,property:key.property,axis:key.axis} == *target
                        && i64::from(key.frame) == frame
                }),
                _ => false,
            },
            Status::Empty | Status::Stale => false,
        })
    };
''' +s[end:]
s=s.replace('    pub(super) fn draw(\n','''    #[cfg(test)]
    pub(super) fn draw(
        &mut self, list: &mut PaintList, atlas: &mut TextAtlas, rect: Rect,
        state: &Value, input: &Input, locale: Locale, easing: Easing,
        target: KeyframeTarget, start: i64, end: Option<i64>, legacy: Option<KeySelection>,
        frozen: Option<Bounds>, context: Option<Context<'_>>,
    ) -> (Rect,Bounds) {
        let first=legacy_time(state,&target,start);
        let last=end.map(|f|legacy_time(state,&target,f));
        self.draw_interval(list,atlas,rect,state,input,locale,easing,target,first,last,legacy,frozen,context)
    }
    pub(super) fn draw_interval(
''')
# Only the production draw and readout declarations use these multiline forms.
s=s.replace('        start: i64,\n        end: Option<i64>,','        start: KeyTime,\n        end: Option<KeyTime>,')
s=s.replace('selection(state, &target, start, end, ctx, legacy, easing, all)', 'selection_interval(state, &target, start, end, ctx, legacy, easing, all)')
s=s.replace('ctx.ranges.capture_mini(target.clone(), start);', 'ctx.ranges.capture_mini(target.clone(), start.address);')
s=s.replace('self.actual_readout(', 'self.actual_readout_interval(')
s=s.replace('    pub(super) fn actual_readout(\n','''    #[cfg(test)]
    pub(super) fn actual_readout(&mut self, state:&Value, locale:Locale, target:&KeyframeTarget,
        start:i64, end:Option<i64>, time:f64, speed:bool, title:String, lines:Vec<String>) -> (String,Vec<String>) {
        self.actual_readout_interval(state,locale,target,legacy_time(state,target,start),end.map(|f|legacy_time(state,target,f)),time,speed,title,lines)
    }
    pub(super) fn actual_readout_interval(
''')
start=s.index('        let frame = if super::time::mapped(state, target)')
end=s.index('        let source = ',start)
s=s[:start]+'''        let Some(end) = end.filter(|end| end.local > start.local) else { return (title, lines); };
        if !time.is_finite() || !(0. ..=1.).contains(&time)
            || !start.local.is_finite() || !end.local.is_finite() { return (title, lines); }
        let local = start.local + (end.local - start.local) * time;
        let frame = if matches!(start.address,Address::Frame(_)) {
            if start.local < 0. { return (title,lines); }
            local
        } else {
            let projected = super::super::property_authoring::clock(state, target.object())
                .and_then(|(clock, offset)| clock.projected_composition_frame(local, offset));
            let Some(frame) = observe!("curve.mini.readout_clock", projected,
                "phase=project target={target:?} key={:?} local={local} generation={:?} revision={:?}",
                start.address, state["document_generation"].as_u64(), state["revision"].as_u64()).ok() else {
                lines.push(if locale == Locale::Zh { "实际读数不可用" } else { "Actual readout unavailable" }.into());
                return (title, lines);
            };
            frame
        };
''' +s[end:]
# Legacy helper remains a test-only contract; production receives exact doubles.
s=s.replace('pub(super) fn interval_frame(', '#[cfg(test)]\npub(super) fn interval_frame(')
p.write_text(s,encoding='utf-8')
