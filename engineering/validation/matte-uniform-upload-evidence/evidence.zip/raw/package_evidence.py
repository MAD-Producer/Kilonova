import hashlib, json, pathlib, re, zipfile
ROOT=pathlib.Path('E:/Dev/aem/.worktrees/layer-time-mapping')
RAW=pathlib.Path(__file__).resolve().parent
DEST=ROOT/'engineering/validation/matte-uniform-upload-evidence'

def read(path):
    b=path.read_bytes()
    return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8-sig')

def sha(path):
    with path.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

results={}
for name,count in [('compositing',8),('runs',3),('frame',1),('admission',5),('integration',12),('workspace',0)]:
    assert int(read(RAW/f'final-{name}.exit'))==0,name
    log=read(RAW/f'final-{name}.log')
    matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',log)
    assert sum(int(x[0]) for x in matches)==count,(name,matches)
    assert all(x[1:]==('0','0') for x in matches),(name,matches)
    results[name]={'passed':count,'exit_code':0,'log':f'final-{name}.log'}
assert int(read(RAW/'before.exit'))==101
assert 'left: 28' in read(RAW/'before.log') and 'right: 1' in read(RAW/'before.log')
assert int(read(RAW/'fixture-first-failure.exit'))==101
assert 'invalid RGBA color' in read(RAW/'fixture-first-failure.log')
cases=re.findall(r'precision=(Unorm8|Unorm16|Float16|Float32) layers=(\d+) revision=(\d+) preview=(false|true) legacy_uploads=(\d+) batched_uploads=(\d+)',read(RAW/'final-compositing.log'))
assert len(cases)==168
assert {(p,int(n),int(r),v) for p,n,r,v,_,_ in cases}=={(p,n,r,v)
    for p in ['Unorm8','Unorm16','Float16','Float32'] for n in [2,8,32,128,3,0,16]
    for r in range(3) for v in ['false','true']}
measurements={}
for phase,path in [('per_source',RAW.parent/'composition-pass-runs/final-frame.log'),('batched',RAW/'final-frame.log')]:
    rows=[json.loads(m.group(1)) for line in read(path).splitlines() if (m:=re.search(r'(\{.*\})$',line))]
    assert len(rows)==144
    measurements[phase]=[]
    for kind in ['solid','vector','matte']:
        for layers in [1,8,32]:
            group=[r for r in rows if r['kind']==kind and r['layers']==layers]
            assert [r['frame'] for r in group]==list(range(4,20))
            measurements[phase].append({'kind':kind,'layers':layers,'frames':16,
                'ranges':{key:[min(r[key] for r in group),max(r[key] for r in group)] for key in ['sample','prepare','create','encode','submit','poll','total']}})
sources=['crates/motion-render/src/renderer.rs','crates/motion-render/src/renderer/compositing.rs',
    'crates/motion-render/src/renderer/compositing/uniform_tests.rs',
    'crates/motion-render/src/renderer/preview_allocation_tests.rs','engineering/validation/matte-uniform-upload.md']
binaries={}
for name in ['compositing','runs','frame','admission','integration']:
    for item in re.findall(r'Running[^\n]*\(([^\n]+\.exe)\)',read(RAW/f'final-{name}.log')):
        path=pathlib.Path(item);binaries[path.name]=sha(path)
assert len(binaries)==3,binaries
DEST.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(DEST/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in RAW.iterdir():
        if p.is_file() and p.suffix in ['.log','.exit','.py','.rs','.json']:
            z.write(p,'raw/'+p.name)
    z.write(RAW.parent/'composition-pass-runs/final-frame.log','baseline/frame.log')
    for s in sources: z.write(ROOT/s,'final-source/'+s)
manifest={'base_commit':'07718094e1e7c0b4cb08d0d25c74f5f214dbec9e','parent_pr':590,'issue':126,'issue_complete':False,
    'results':results,'distinct_tests':29,'native_pixel_scenarios':168,
    'frame_allocation_counts':measurements,'source_sha256_raw_files':{s:sha(ROOT/s) for s in sources},
    'baseline_binary':json.loads(read(RAW/'baseline-binary.json')),
    'binary_sha256':binaries,'evidence_zip_sha256':sha(DEST/'evidence.zip'),'ci':'pending for final head',
    'limits':['Calling-thread allocation counts, not bytes, FPS, other threads or external driver memory.',
        'Sparse occupied spans can upload more padding than separate payloads; unchanged GPU destination capacity.',
        'Full-frame allocation growth remains; issue 126 open.',
        'Controlled internal projection failure, not a new full desktop logging acceptance.']}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'tests':29,'archive_bytes':(DEST/'evidence.zip').stat().st_size,'measurements':measurements['batched']}))
