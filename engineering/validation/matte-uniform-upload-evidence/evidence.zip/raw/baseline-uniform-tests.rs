use super::*;
use motion_core::compositing::{MatteMode, TrackMatte};

fn project(count: u64) -> Project {
    let mut project = Project::new(32, 24, 30, 120).unwrap();
    project.background = [0.1, 0.2, 0.3, 0.4];
    for id in 1..=count {
        let mut layer = motion_core::Layer::solid(id, "Matte uniform", [16., 12.],
            [8. + id as f32 / 3., 12., 0.], [id as f32 / count as f32, 0.4, 0.8, 0.6]);
        if (id - 1) % 8 != 0 {
            layer.track_matte = Some(TrackMatte { source: id - 1, hide_source: false,
                mode: if id % 2 == 0 { MatteMode::Alpha } else { MatteMode::Luma } });
        }
        project.layers.push(layer);
    }
    project.validate().unwrap();
    project
}

#[test]
#[cfg_attr(not(feature = "gpu-tests"), ignore = "requires an actual GPU")]
fn many_matte_sources_share_one_uniform_upload_without_changing_pixels() {
    let project = project(32);
    let mut scene = Scene::new(&project).unwrap();
    scene.sample(&project, 0., None, &motion_core::ExpressionEvaluator).unwrap();
    let mut renderer = pollster::block_on(Renderer::headless()).unwrap();
    let target = renderer.capture_target(32, 24).unwrap();
    renderer.matte_planning.uniform_uploads.set(0);
    renderer.capture(&scene, &target).unwrap();
    assert_eq!(renderer.matte_planning.order.len(), 28);
    assert_eq!(renderer.matte_planning.uniform_uploads.get(), 1,
        "all projected matte uniforms must share one queue upload");
    renderer.check_health().unwrap();
}
