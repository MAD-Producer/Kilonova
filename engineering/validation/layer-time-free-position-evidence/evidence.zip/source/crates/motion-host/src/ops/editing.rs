//! Commands, gestures and temporal curve operations.
use crate::session::{Result, Session};
use motion_core::Command;
use serde_json::{json, Value};

fn restore_imported_effects<'a>(effects: impl IntoIterator<Item = &'a motion_core::EffectInstance>, root: &std::path::Path, original: &motion_effects::Registry, registry: &mut Option<motion_effects::Registry>) -> Result<()> {
    let current = registry.as_ref().unwrap_or(original);
    let missing: Vec<_> = effects.into_iter().filter(|e| e.node_graph.as_ref().is_some_and(|s| s.get("runtime").is_some())
        && current.resolve(&e.plugin, &e.version, &e.hash).is_err()).collect();
    if missing.is_empty() { return Ok(()); }
    crate::node_effects::restore_effects(missing, root, registry.get_or_insert_with(|| original.clone()))?;
    Ok(())
}
fn restore_command_runtimes(command: &Command, root: &std::path::Path, original: &motion_effects::Registry, registry: &mut Option<motion_effects::Registry>) -> Result<()> {
    match command {
        Command::InComposition { command, .. } => restore_command_runtimes(command, root, original, registry),
        Command::ApplyAnimationPreset { preset, .. } => restore_imported_effects(&preset.effects, root, original, registry),
        Command::PasteLayers { clipboard, .. } => {
            let view = clipboard.resolve()?;
            restore_imported_effects(view.layers.iter().copied().chain(view.compositions.iter().flat_map(|c| &c.layers)).flat_map(|l| &l.effects), root, original, registry)
        },
        Command::Effect { action: motion_core::EffectAction::Insert { instance } | motion_core::EffectAction::Replace { instance }, .. } =>
            restore_imported_effects(std::iter::once(instance), root, original, registry),
        _ => Ok(()),
    }
}

fn validate_presets(registry: &motion_effects::Registry, project: &motion_core::Project, command: &Command) -> Result<()> {
    match command {
        Command::InComposition { composition, command } => {
            let mut scoped = project.clone(); scoped.activate_composition(composition)?;
            validate_presets(registry, &scoped, command)
        }
        Command::ApplyAnimationPreset { preset, objects, .. } => {
            preset.validate()?;
            for effect in &preset.effects {
                let package = registry.resolve(&effect.plugin, &effect.version, &effect.hash)?;
                let definition = package.manifest.effects.iter().find(|d| d.id == effect.effect)
                    .ok_or("preset effect definition missing")?;
                if definition.compatibility == motion_effects::Compatibility::Unsupported {
                    return Err("preset effect is unsupported".into());
                }
                if effect.params.len() != definition.params.len() {
                    return Err("preset public parameter set does not match installed definition".into());
                }
                for schema in &definition.params {
                    let param = effect.params.get(&schema.id).ok_or("preset public parameter missing")?;
                    if param.kind != schema.kind || param.animatable != schema.animatable
                        || param.min != schema.min || param.max != schema.max || param.implemented != schema.implemented {
                        return Err(format!("preset public parameter schema mismatch: plugin={} effect={} parameter={}",
                            effect.plugin, effect.effect, schema.id).into());
                    }
                }
                if effect.image_input.is_some() && !definition.required_capabilities.iter().any(|c| c == "image_input") {
                    return Err("preset effect does not accept an image input".into());
                }
                for object in objects {
                    let layer = project.layers.iter().find(|l| l.id == *object).ok_or("preset target layer missing")?;
                    if matches!(layer.content, motion_core::Content::Adjustment)
                        && definition.renderer != motion_effects::RendererKind::Image {
                        return Err("adjustment layers support image presets only".into());
                    }
                }
            }
            Ok(())
        }
        _ => Ok(()),
    }
}

// The model rolls back before returning a failed preparation. Keep the host's
// native error separately rather than flattening it to the model callback type.
#[cfg(test)]
fn apply_prepared(
    engine: &mut motion_core::Engine,
    commands: Vec<Command>,
    prepare: impl FnOnce(&motion_core::Project) -> Result<()>,
) -> Result<Vec<motion_core::EditResult>> {
    apply_prepared_with_cameras(engine, commands, &motion_core::AuthoredCameraSampler, prepare)
}

fn apply_prepared_with_cameras(
    engine: &mut motion_core::Engine,
    commands: Vec<Command>,
    cameras: &dyn motion_core::CameraSampler,
    prepare: impl FnOnce(&motion_core::Project) -> Result<()>,
) -> Result<Vec<motion_core::EditResult>> {
    let mut primary = None;
    engine.apply_batch_with_cameras_and_prepare(commands, cameras, |project| {
        prepare(project).map_err(|error| {
            let bridge = motion_core::Error::Invalid(error.to_string());
            primary = Some(error);
            bridge
        })
    }).map_err(|error| primary.unwrap_or_else(|| error.into()))
}

impl Session {
    /// Apply a batch of commands with asset validation and one-step undo.
    pub fn apply_commands(&mut self, text: &str) -> Result<Value> {
        let commands = motion_core::parse_commands(text).map_err(crate::Error::from)?;
        self.apply_command_batch(commands)
    }
    pub fn apply_command_batch(&mut self, commands: Vec<Command>) -> Result<Value> {
        fn calibration_targets(command: &Command, composition: &str, targets: &mut std::collections::BTreeMap<(String, u64), bool>) {
            match command {
                Command::InComposition { composition, command } => calibration_targets(command, composition, targets),
                Command::DepthCalibration { object, calibration } => { targets.insert((composition.to_owned(), *object), calibration.is_some()); },
                _ => {},
            }
        }
        let mut depth_targets = std::collections::BTreeMap::new();
        for command in &commands { calibration_targets(command, &self.engine.project().composition_id, &mut depth_targets); }
        let depth_targets: Vec<_> = depth_targets.into_iter().filter_map(|(target, selected)| selected.then_some(target)).collect();
        fn video_calibrations(command: &Command, composition: &str, targets: &mut Vec<(String, Command)>) {
            match command {
                Command::InComposition { composition, command } => video_calibrations(command, composition, targets),
                Command::VideoDepthCalibration { .. } => targets.push((composition.to_owned(), command.clone())),
                _ => {},
            }
        }
        let mut video_samples = Vec::new();
        for command in &commands { video_calibrations(command, &self.engine.project().composition_id, &mut video_samples); }
        #[cfg(feature = "ai-depth")]
        let depth_sample = if depth_targets.is_empty() && video_samples.is_empty() { None } else { self.depth_calibration_sample()? };
        fn selects_camera(command: &Command) -> bool {
            match command {
                Command::CameraImported { .. } => true,
                Command::InComposition { command, .. } => selects_camera(command),
                _ => false,
            }
        }
        let mut registry = None;
        for command in &commands {
            restore_command_runtimes(command, &self.root, &self.effects.registry, &mut registry)?;
            validate_presets(registry.as_ref().unwrap_or(&self.effects.registry), self.engine.project(), command)?;
        }
        let resources = commands.iter().any(Command::changes_resources);
        let camera_sources = resources || commands.iter().any(selects_camera);
        let previous_models = self.scene.model_source_catalog();
        let mut candidate_models = None;
        let previous_nodes = self.engine.project().node_resources()?;
        if self.editor.as_ref().is_some_and(|e| e.gesture) {
            return Err("finish the plugin editor gesture before ordinary edits".into());
        }
        let results = apply_prepared_with_cameras(&mut self.engine, commands, &previous_models, |project| {
                for (composition, command) in &video_samples {
                    let Command::VideoDepthCalibration { object, sample } = command else { continue; };
                    let view = project.composition_view(composition)?;
                    let selected = view.layers.iter().find(|layer| layer.id == *object)
                        .and_then(|layer| layer.video_depth_calibration.as_ref())
                        .and_then(|track| track.at(sample.start_us()));
                    // A later command may clear or replace this exact sample.
                    // Every sample surviving the transaction must have come
                    // from the independently installed decoder/inference result.
                    if selected != Some(sample) { continue; }
                    #[cfg(feature = "ai-depth")]
                    depth_sample.as_ref().ok_or("video depth calibration requires an installed current result")?
                        .validate_video(project, composition, *object, sample)?;
                    #[cfg(not(feature = "ai-depth"))]
                    return Err("video depth calibration authoring requires an enabled native depth backend".into());
                }
                for (composition, object) in &depth_targets {
                    let view = project.composition_view(composition)?;
                    if let Some(_calibration) = view.layers.iter().find(|layer| layer.id == *object)
                        .and_then(|layer| layer.depth_calibration.as_ref()) {
                        #[cfg(feature = "ai-depth")]
                        depth_sample.as_ref().ok_or("depth calibration requires an installed current result")?
                            .validate(project, composition, *object, _calibration)?;
                        #[cfg(not(feature = "ai-depth"))]
                        return Err("depth calibration authoring requires an enabled native depth backend".into());
                    }
                }
                if project.node_resources()? != previous_nodes {
                    for resource in project.node_resources()? { motion_core::storage::open_node_resource(&self.root, &resource)?; }
                }
                if camera_sources {
                    candidate_models = Some(motion_render::ModelSourceCatalog::prepare(project, &self.root, &previous_models)?);
                }
                if resources {
                    motion_core::storage::validate_assets(&self.root, project)?;
                    if let Some(g) = &mut self.graphics {
                        // configure_assets resolves every source before changing
                        // its catalog/caches, so Err leaves the old renderer intact.
                        g.renderer.configure_assets_with_model_catalog(project, &self.root,
                            candidate_models.as_ref().unwrap_or(&previous_models))
                            .map_err(crate::Error::from)?;
                    }
                }
                Ok(())
            })?;
        if let Some(catalog) = candidate_models { self.scene.set_model_source_catalog(catalog); }
        if let Some(registry) = registry {
            self.effects.set_registry(registry.clone());
            if let Some(g) = &mut self.graphics { g.renderer.set_effect_registry(registry); }
        }
        if resources {
            self.effects.alpha_images.clear();
            self.editor_renderer = None;
            self.editor_target = None;
        }
        // The edit has committed. A frame-specific expression failure is reported
        // in renderError without pretending the stored edit failed or losing it.
        if let Err(error) = self.sample() {
            self.last_error = Some(error.to_string());
        }
        let mut snapshot = self.snapshot()?;
        if let Some(result) = results.last() {
            snapshot["edit_result"] = serde_json::to_value(result).map_err(crate::Error::from)?;
            snapshot["edit_results"] =
                serde_json::to_value(&results).map_err(crate::Error::from)?;
        }
        Ok(snapshot)
    }
}

pub fn command(id: i64, text: &str) -> Result<Value> {
    crate::session::with_session(id, |s| s.apply_commands(text))
}

pub fn drag(
    id: i64,
    object: i64,
    dx: f64,
    dy: f64,
    width: i32,
    height: i32,
) -> Result<Value> {
    drag_at_key(id,object,dx,dy,width,height,None)
}

pub fn drag_at_key(
    id: i64, object: i64, dx: f64, dy: f64, width: i32, height: i32, spatial_key: Option<u64>,
) -> Result<Value> {
    crate::session::with_session(id, |s| {
        if width <= 0 || height <= 0 || !dx.is_finite() || !dy.is_finite() {
            return Err("invalid preview drag".into());
        }
        s.sample()?;
        let commands=drag_commands(s,&s.scene,object,dx,dy,width,height,spatial_key)?;
        s.engine
            .apply_batch(commands)
            .map_err(crate::Error::from)?;
        s.sample()?;
        s.snapshot()
    })
}

/// Undo/redo and gesture bracketing. Operations are stable across hosts.
pub const HISTORY_UNDO: i32 = 0;
pub const HISTORY_REDO: i32 = 1;
pub const HISTORY_BEGIN: i32 = 2;
pub const HISTORY_COMMIT: i32 = 3;
pub const HISTORY_CANCEL: i32 = 4;

pub fn history(id: i64, op: i32) -> Result<Value> {
    crate::session::with_session(id, |s| {
        let active = s.engine.project().composition_id.clone();
        match op {
            HISTORY_UNDO => {
                s.engine.undo().map_err(crate::Error::from)?;
            }
            HISTORY_REDO => {
                s.engine.redo().map_err(crate::Error::from)?;
            }
            HISTORY_BEGIN => s.engine.begin_gesture().map_err(crate::Error::from)?,
            HISTORY_COMMIT if s.editor.as_ref().is_some_and(|e|e.gesture) => s.close_plugin_editor(true, "host_commit")?,
            HISTORY_CANCEL if s.editor.as_ref().is_some_and(|e|e.gesture) => s.close_plugin_editor(false, "host_cancel")?,
            HISTORY_COMMIT => s.engine.end_gesture(true).map_err(crate::Error::from)?,
            HISTORY_CANCEL => s.engine.end_gesture(false).map_err(crate::Error::from)?,
            _ => return Err("invalid history operation".into()),
        }
        if !s.engine.gesture_active() {
            let target = if s.engine.project().composition_ids().contains(&active) {
                active.as_str()
            } else {
                motion_core::MAIN_COMPOSITION
            };
            s.engine
                .activate_composition(target)
                .map_err(crate::Error::from)?;
        }
        s.frame = s.frame.min(f64::from(s.engine.project().frames - 1));
        s.audio_mixer = None;
        s.video_frames.clear();
        if matches!(op, HISTORY_UNDO | HISTORY_REDO | HISTORY_CANCEL) {
            s.effects.alpha_images.clear();
            s.editor_renderer = None;
            s.editor_target = None;
        }
        if let Some(g) = &mut s.graphics {
            g.renderer
                .configure_assets_with_model_catalog(s.engine.project(), &s.root, &s.scene.model_source_catalog())
                .map_err(crate::Error::from)?;
        }
        if let Err(error) = s.sample() {
            s.last_error = Some(error.to_string());
        }
        s.snapshot()
    })
}

/// Sample an easing into graph points without touching a session.
pub fn curve_graph(text: &str) -> Result<Value> {
    let easing: motion_core::Easing = serde_json::from_str(text).map_err(crate::Error::from)?;
    easing.validate().map_err(crate::Error::from)?;
    let points: Vec<_> = (0..=160).map(|i| easing.sample(i as f64 / 160.0)).collect();
    Ok(json!({"points": points,
        "definitionScale": easing.curve.map_or(1.0, |c| c.definition_scale())}))
}

#[cfg(test)]
mod preparation_failure_tests {
    use super::*;

    #[test]
    #[cfg_attr(not(feature = "gpu-tests"), ignore = "requires an actual GPU")]
    fn native_renderer_prepare_error_survives_model_rollback_and_recovery() {
        let directory = tempfile::tempdir().unwrap();
        let mut engine = motion_core::Engine::new(
            motion_core::Project::new(64, 64, 30, 60).unwrap()).unwrap();
        let before = engine.snapshot();
        let history = engine.history_diagnostics();
        let mut renderer = pollster::block_on(motion_render::Renderer::headless()).unwrap();
        renderer.configure_assets(engine.project(), directory.path()).unwrap();
        let commands = || vec![Command::RegisterAsset { asset: motion_core::Asset {
            id: 1, path: "assets/new.png".into(), width: 16, height: 16,
        }}];
        let error = apply_prepared(&mut engine, commands(), |project| {
            renderer.configure_assets(project, directory.path()).map_err(crate::Error::from)
        }).unwrap_err();
        assert!(matches!(&error,
            crate::Error::Render(motion_render::RenderError::ImageResource(
                motion_render::image_resources::Error::Io(cause)))
                if cause.kind() == std::io::ErrorKind::NotFound),
            "renderer error lost its identity at model callback: {error:?}");
        assert_eq!(engine.snapshot(), before);
        assert_eq!(engine.revision(), 0);
        assert_eq!(engine.history_diagnostics(), history);
        assert!(!engine.can_undo());
        assert_eq!(renderer.asset_ids(), &[0]);

        std::fs::create_dir(directory.path().join("assets")).unwrap();
        image::DynamicImage::new_rgba8(16, 16)
            .save(directory.path().join("assets/new.png")).unwrap();
        apply_prepared(&mut engine, commands(), |project| {
            renderer.configure_assets(project, directory.path()).map_err(crate::Error::from)
        }).unwrap();
        assert_eq!(engine.revision(), 1);
        assert!(engine.can_undo());
        assert_eq!(renderer.asset_ids(), &[0, 1]);
        assert!(engine.undo().unwrap());
        assert_eq!(engine.snapshot(), before);
    }
}

fn drag_commands(
    s: &crate::session::Session,
    scene: &motion_render::Scene,
    object: i64,
    dx: f64,
    dy: f64,
    width: i32,
    height: i32,
    spatial_key: Option<u64>,
) -> Result<Vec<Command>> {
    if width <= 0 || height <= 0 || !dx.is_finite() || !dy.is_finite() {
        return Err("invalid preview drag".into());
    }
    let layer = s
        .engine
        .project()
        .layers
        .iter()
        .find(|l| l.id == object as u64)
        .ok_or("drag layer does not exist")?;
    if !layer.active(s.frame, s.engine.project().frames) {
        return Err("drag layer is outside its clip".into());
    }
    let sampled_position = layer
        .transform
        .position
        .sample(layer.local_frame(s.frame))?;
    let position = if let Some(key) = spatial_key {
        layer.transform.position.spatial_animation.as_ref()
            .and_then(|animation| animation.keys().iter().find(|candidate| candidate.id == key))
            .map(|key| key.value)
            .ok_or_else(|| crate::Error::from(format!("drag object={object} key={key}: spatial key no longer exists")))?
    } else { sampled_position };
    let separated = layer.transform.position.axes.is_some();
    let mut world_position = scene
        .node_position(object as u64)
        .ok_or("object transform is unavailable")?;
    if spatial_key.is_some() && layer.three_d {
        let shift = motion_core::scene_prefix_offset_with_cameras(
            s.engine.project(), object as u64, s.frame,
            std::array::from_fn(|i| position[i] - sampled_position[i]),
            &scene.model_source_catalog(),
        )?;
        for i in 0..3 { world_position[i] += shift[i]; }
    }
    let offset = if layer.three_d {
        scene
            .screen_translation(
                world_position,
                [dx as f32, dy as f32],
                [width as u32, height as u32],
            )
            .map_err(crate::Error::from)?
    } else {
        let p = s.engine.project();
        let scale = (width as f32 / p.width as f32).min(height as f32 / p.height as f32);
        [dx as f32 / scale, dy as f32 / scale, 0.0]
    };
    let offset = motion_core::scene_prefix_delta_with_cameras(
        s.engine.project(),
        object as u64,
        s.frame,
        offset,
        &scene.model_source_catalog(),
    )
    .map_err(crate::Error::from)?;
    let frame = s.frame.floor() as u32;
    let commands = if let Some(key) = spatial_key {
        vec![Command::TrackAt {
            target: motion_core::KeyframeTarget::Property {
                object:object as u64, property:motion_core::Property::Position, axis:None },
            frame:s.frame,
            edit:motion_core::TrackEdit::SetSpatialKey {
                key, value:motion_core::TrackValue::Vec3(std::array::from_fn(|i| position[i]+offset[i])) },
        }]
    } else if separated {
        [
            motion_core::Axis::X,
            motion_core::Axis::Y,
            motion_core::Axis::Z,
        ]
        .into_iter()
        .enumerate()
        .filter(|(i, _)| offset[*i].abs() > 1e-6)
        .map(|(i, axis)| Command::SetComponent {
            object: object as u64,
            property: motion_core::Property::Position,
            axis,
            frame,
            value: position[i] + offset[i],
        })
        .collect()
    } else {
        vec![Command::SetVector {
            object: object as u64,
            property: motion_core::Property::Position,
            frame,
            value: std::array::from_fn(|i| position[i] + offset[i]),
        }]
    };
    let precise = layer.time_mapping.is_some() || layer.transform.position.spatial_animation.is_some();
    Ok(commands.into_iter().map(|command| {
        if !precise { return command; }
        let (axis,value)=match command {
            Command::SetComponent {axis,value,..} => (Some(axis),motion_core::TrackValue::Scalar(value)),
            Command::SetVector {value,..} => (None,motion_core::TrackValue::Vec3(value)),
            _ => return command,
        };
        Command::TrackAt {target:motion_core::KeyframeTarget::Property {
            object:object as u64, property:motion_core::Property::Position, axis },
            frame:s.frame,edit:motion_core::TrackEdit::Set {value}}
    }).collect())
}
impl crate::session::Session {
    pub fn drag_for_view(
        &mut self,
        view: motion_render::ViewCamera<'_>,
        object: u64,
        delta: [f32; 2],
        size: [i32; 2],
    ) -> Result<Value> {
        self.drag_for_view_at_key(view,object,delta,size,None)
    }
    /// A gesture may retain a spatial key independently of its retimed sample.
    pub fn drag_for_view_at_key(
        &mut self, view: motion_render::ViewCamera<'_>, object: u64,
        delta: [f32; 2], size: [i32; 2], spatial_key: Option<u64>,
    ) -> Result<Value> {
        self.sample()?;
        let scene = self.scene.fork_view(view)?;
        let commands = drag_commands(
            self,
            &scene,
            object as i64,
            delta[0] as f64,
            delta[1] as f64,
            size[0],
            size[1],
            spatial_key,
        )?;
        self.engine
            .apply_batch(commands)
            .map_err(crate::Error::from)?;
        self.sample()?;
        self.snapshot()
    }
}
