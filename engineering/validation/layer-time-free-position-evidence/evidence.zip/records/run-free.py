import os,subprocess,time,json,hashlib,re
from pathlib import Path
root=Path('E:/Dev/aem/artifacts/issue-goal-current/spatial-free/final')
root.mkdir(exist_ok=True,parents=True)
binary=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-b34b3a7e7eb835e8.exe')
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+['desktop/app/src/panels/transform_controls/spatial/free_position_tests.rs','desktop/app/src/engine/viewer_input/free_drag_tests.rs']
hashes={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files}
(root/'source-sha256.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
env=os.environ.copy();env.pop('MOTION_LOG',None)
env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
for key,folder in [('MOTION_FREE_DRAG_FAULT_ARTIFACTS','free-faults'),('MOTION_VIEWER_INPUT_ARTIFACTS','viewer-faults'),('MOTION_STABLE_SPATIAL_FAULT_ARTIFACTS','panel-faults'),('MOTION_FREE_POSITION_NATIVE_ARTIFACTS','native-free'),('MOTION_CONTINUOUS_POSITION_NATIVE_ARTIFACTS','native-axis')]:env[key]=str(root/folder)
groups=[('free',['panels::transform_controls::spatial::free_position_tests::']),('worker',['engine::viewer_input::']),('native-free',['--exact','panels::transform_controls::spatial::native_tests::continuous_position::native_free_position_drag_keeps_stable_keys_in_main_and_floating_owners','--ignored']),('transform',['panels::transform_controls::']),('composition',['panels::composition::tests::']),('native-axis',['--exact','panels::transform_controls::spatial::native_tests::continuous_position::native_continuous_position_handles_save_reopen_and_undo_in_both_window_owners','--ignored'])]
rows=[]
for name,args in groups:
    sha=hashlib.sha256(binary.read_bytes()).hexdigest();start=time.monotonic()
    with (root/(name+'.log')).open('wb') as f:r=subprocess.run([str(binary),*args,'--nocapture','--test-threads=1'],env=env,stdout=f,stderr=subprocess.STDOUT)
    text=(root/(name+'.log')).read_text(encoding='utf-8',errors='replace');matches=list(re.finditer(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored',text))
    row=dict(group=name,args=args,exit=r.returncode,seconds=round(time.monotonic()-start,3),binarySha256=sha)
    if matches:
        m=matches[-1];row.update(passed=int(m[1]),failed=int(m[2]),ignored=int(m[3]))
    rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2),encoding='utf-8');print(json.dumps(row),flush=True)
    assert sha==hashlib.sha256(binary.read_bytes()).hexdigest()
    if r.returncode:raise SystemExit(r.returncode)
    assert row.get('passed',0)>0
assert hashes=={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files}
