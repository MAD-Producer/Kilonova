矢量纹理预算、分组目标保留和暂存去重每次都会新建尺寸／深度集合；动画指纹变化时，纹理全部可复用也会额外收集一份脏网格列表。改为复用集合容量，并通过同一只读判定的迭代器完成普通／分组目标暂存，避免收集脏引用 Vec。

每次重新收集当前成员，空矢量帧和完整释放回收集合存储。保留纹理创建／提交顺序、全局和来源预算、原始错误原因及像素语义。没有用户可见 UI、依赖、工程格式或素材变更。

验证：

- 最终规划分组 **4 项通过**。指定集合操作在 1／8／96 个网格下重复 120 次零分配；完整脏纹理准备在真实普通／分组图层、1／8／32 层六种场景下各重复 120 次零分配。独立有序集合核对预算，实际纹理暂存覆盖拒绝、恢复、去重和释放。
- 新增完整准备验证先在旧实现上以 **120 次分配实际失败**；修改遍历后同一断言通过。准备阶段保留旧像素及完整资源台账，实际新帧与全新渲染器逐 RGBA 字节一致。
- 既有矢量分组、上传复用、预算对齐和错误边界 **16 项通过**，包含真实 GPU 像素、跨编码隔离、预算少一字节拒绝、原始原因与恢复。
- 带 FFmpeg／diagnostics 的 workspace all-targets 检查通过，排除已停止维护的 Android 包。最终 PR CI 待运行。

[最终验证说明](https://github.com/MAD-Producer/Kilonova/blob/FINAL_HEAD/engineering/validation/vector-texture-iteration.md)、[最终结果与源码／二进制哈希](https://github.com/MAD-Producer/Kilonova/blob/FINAL_HEAD/engineering/validation/vector-texture-iteration-evidence/manifest.json)、[原始证据包](https://github.com/MAD-Producer/Kilonova/blob/FINAL_HEAD/engineering/validation/vector-texture-iteration-evidence/evidence.zip)。[先前集合复用阶段](https://github.com/MAD-Producer/Kilonova/blob/0ba7817e/engineering/validation/vector-scratch-planning.md)及其失败／恢复证据继续保留，不以旧源码通过结果代替最终验证。

关联 #126，聚合 issue 保持打开。只证明指定准备操作的调用线程分配消除，不宣称整帧零分配、GPU 分配减少或帧率提升。迭代版本需重新检查两遍只读条件，以此交换临时列表分配；帧时收益仍待独立测量。开工已核对其他分支，避开追踪和后台预渲染工作。
