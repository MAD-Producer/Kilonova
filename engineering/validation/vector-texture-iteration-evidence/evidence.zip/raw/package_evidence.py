import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path('E:/Dev/aem/.worktrees/layer-time-mapping')
RAW = Path('E:/Dev/aem/artifacts/issue-goal-current/vector-texture-iteration')
OUT = ROOT / 'engineering/validation/vector-texture-iteration-evidence'
DEPS = Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps')
SOURCES = ['crates/motion-render/src/layer_gpu.rs', 'crates/motion-render/src/layer_gpu/groups.rs', 'crates/motion-render/src/layer_gpu/groups/planning_tests.rs', 'crates/motion-render/src/renderer/vector_planning_tests.rs', 'crates/motion-render/src/test_allocations.rs', 'engineering/validation/vector-texture-iteration.md']

def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()

def read(path):
    data = path.read_bytes()
    return data.decode('utf-16' if data[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig')

results = {}
for name, expected in [('after', 4), ('regression', 16), ('workspace', 0)]:
    code = int(read(RAW / (name + '.exit')).strip())
    assert code == 0, (name, code)
    counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', read(RAW / (name + '.log')))
    assert all(int(failed) == 0 and int(ignored) == 0 for _, failed, ignored in counts)
    passed = sum(int(passed) for passed, _, _ in counts)
    assert passed == expected, (name, passed, expected)
    results[name] = {'exit_code': code, 'tests_passed': passed, 'log': name + '.log'}
assert int(read(RAW / 'before-runtime.exit').strip()) == 101
assert 'left: 120' in read(RAW / 'before-runtime.log')
assert read(RAW / 'after.log').count('dirty texture preparation layers=') == 6
binaries = ['motion_render-1fcc3fb8d09fa888.exe', 'vector_budget_alignment-80f3822d5431cb6a.exe', 'vector_error_boundaries-4162b162d7ecfa99.exe', 'vector_groups-02147addf7395614.exe', 'vector_upload_reuse-a94ca798c1da72b3.exe']
manifest = {
    'base_commit': '0ba7817ee0f255a021d06791839871d731d5c6a1', 'branch': 'perf/vector-scratch-planning', 'issue': 126, 'issue_complete': False,
    'results': results, 'baseline': {'runtime_exit': 101, 'allocations': 120, 'iterations': 120, 'fixture_compile_exit': 101},
    'source_sha256_raw_files': {name: sha(ROOT / name) for name in SOURCES},
    'binary_sha256': {name: sha(DEPS / name) for name in binaries},
    'commands': [
        'cargo test -p motion-render --lib --features gpu-tests --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target planning -- --test-threads=1 --nocapture',
        'cargo test -p motion-render --features gpu-tests --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --test vector_groups --test vector_upload_reuse --test vector_budget_alignment --test vector_error_boundaries -- --test-threads=1 --nocapture',
        'cargo check --workspace --all-targets --exclude motion-android --locked --features motion-desktop/ffmpeg,motion-host/diagnostics --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target',
    ],
    'scope': 'Specific preparation operations on the calling thread after warmup; excludes scene/plan building, final drawing, background allocations and FPS claims.',
    'ci': 'pending for final head',
}
OUT.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(OUT / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(RAW.rglob('*')):
        if path.is_file(): archive.write(path, 'raw/' + path.relative_to(RAW).as_posix())
    for name in SOURCES: archive.write(ROOT / name, 'final-source/' + name)
manifest['evidence_zip_sha256'] = sha(OUT / 'evidence.zip')
(OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(results))
