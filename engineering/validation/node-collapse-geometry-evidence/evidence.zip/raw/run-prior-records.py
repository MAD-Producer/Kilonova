import hashlib,json,os,subprocess
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(l) for l in (p/'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
assert rows[-1]==dict(reason='build-finished',success=True)
exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info'
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
cases=[('viewport','viewport_geometry::record_complete_navigation_and_release_paint_for_original_path_comparison','MOTION_NODE_VIEWPORT_EVIDENCE','node-viewport-geometry',312),
    ('input','input_geometry::record_complete_outside_canvas_edits_for_original_path_comparison','MOTION_NODE_INPUT_EVIDENCE','node-input-geometry',64)]
receipts=[]
for name,test,key,baseline_dir,count in cases:
    local=env.copy();path=p/(name+'-final-paint.json');local[key]=str(path)
    command=[exe,'--exact','node_editor::view::frame_cards_tests::'+test,'--test-threads=1','--nocapture']
    r=subprocess.run(command,env=local,capture_output=True)
    (p/(name+'-final.stdout')).write_bytes(r.stdout);(p/(name+'-final.stderr')).write_bytes(r.stderr)
    assert r.returncode==0
    original=p.parent/baseline_dir/'before-paint.json'
    assert json.loads(original.read_text('utf-8'))==json.loads(path.read_text('utf-8'))
    receipts.append(dict(command=command,exit=r.returncode,frames=count,exact_equal=True,
        original_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),final_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
before=json.loads((p/'before-paint.json').read_text('utf-8'));final=json.loads((p/'final-paint.json').read_text('utf-8'))
assert before==final and len(before)==24 and all(len(v)==9 for v in before.values())
receipt=dict(executable_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest(),prior_records=receipts,
    collapse_frames=216,total_complete_frames=592,exact_equal=True,normalization=False)
(p/'final-comparison.json').write_text(json.dumps(receipt,indent=2),'utf-8')
print(json.dumps(receipt))
