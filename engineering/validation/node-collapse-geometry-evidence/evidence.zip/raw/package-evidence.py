import hashlib, json, re, subprocess, zipfile
from pathlib import Path

raw=Path(__file__).parent;root=Path.cwd();base='c14f20f5b157775b4ced4c8806f16e267fdba10a'
out=root/'engineering/validation/node-collapse-geometry-evidence';out.mkdir(exist_ok=True)
def digest(data):return hashlib.sha256(data).hexdigest()
def git(*args,input=None):return subprocess.check_output(['git',*args],input=input)
paths=['desktop/app/src/node_editor/view/'+p for p in ['mod.rs','canvas.rs','frame_cards_tests.rs','frame_cards_tests/collapse_geometry.rs','wire_target_tests.rs','wires/socket_index_tests.rs']]
sources={path:(root/path).read_bytes() for path in paths}
counts=[]
for i in range(4):
    text=(raw/f'regression-{i}.stdout').read_text('utf-8')
    m=re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',text)
    assert m;counts.append(int(m[1]))
assert counts==[192,4,13,7]
for name in ['costs.json','layouts.json']:
    assert len(json.loads((raw/name).read_text('utf-8')))==48
assert all(r['exit']==0 for r in json.loads((raw/'workspace-tests.json').read_text('utf-8')))
assert [r['exit'] for r in json.loads((raw/'before-tests.json').read_text('utf-8'))]==[101,0]
assert [r['exit'] for r in json.loads((raw/'final-tests.json').read_text('utf-8'))]==[0,0]
before_counts=json.loads((raw/'before-counts.json').read_text('utf-8'))
assert len(before_counts)==48 and all(builds==2 and resolutions==2*nodes for _,builds,resolutions,nodes in before_counts)
comparison=json.loads((raw/'final-comparison.json').read_text('utf-8'))
assert comparison['total_complete_frames']==592 and comparison['exact_equal'] and not comparison['normalization']
assert json.loads((raw/'before-paint.json').read_text('utf-8'))==json.loads((raw/'final-paint.json').read_text('utf-8'))
startup=json.loads((raw/'startup.json').read_text('utf-8'))
assert startup['exit']==0 and not (raw/'startup.stderr').read_bytes()
assert isinstance(json.loads((raw/'startup.stdout').read_bytes()),dict)
for name in ['before-build.jsonl','app-build.jsonl','production-build.jsonl']:
    rows=[json.loads(l) for l in (raw/name).read_text('utf-8-sig').splitlines() if l.startswith('{')]
    assert rows[-1]==dict(reason='build-finished',success=True)
before_source=json.loads((raw/'before-source.json').read_text('utf-8'))
for path,sha in before_source.items():assert digest((raw/'before-source'/path).read_bytes())==sha
preflight=json.loads((raw/'preflight.json').read_text('utf-8'))
assert preflight and not any(row['overlap'] for row in preflight)
geometry_count=re.search(r'original rebuild geometry comparisons=(\d+)',(raw/'regression-0.stdout').read_text('utf-8'))
assert geometry_count
summary=dict(base=base,tests_passed=218,test_counts=counts+[2],collapse_configurations=24,collapse_transitions=48,
    collapse_complete_frames=216,prior_viewport_frames=312,prior_input_frames=64,total_complete_frames=592,
    exact_equal=True,normalization=False,geometry_comparisons=int(geometry_count[1]),negative_control_exits=[101,0],
    production_executable_sha256=startup['executable_sha256'],test_executable_sha256=comparison['executable_sha256'],
    before_source_sha256=before_source,source_sha256={path:digest(data) for path,data in sources.items()},
    source_git_blobs={path:git('hash-object','--path='+path,'--stdin',input=data).decode().strip() for path,data in sources.items()})
(raw/'summary.json').write_text(json.dumps(summary,indent=2),'utf-8')
records=[]
excluded=('github_api','merge602','publish','finalize-pr','run-viewport-record','setup')
for file in sorted(raw.iterdir()):
    if not file.is_file() or file.suffix not in ['.json','.jsonl','.stdout','.stderr','.ps1','.py']:continue
    if file.name.startswith(excluded):continue
    records.append(('raw/'+file.name,file.read_bytes()))
for path,data in sources.items():records.append(('final-source/'+path,data))
for path in before_source:records.append(('baseline-compiler-source/'+path,(raw/'before-source'/path).read_bytes()))
for directory,name in [('node-viewport-geometry','viewport'),('node-input-geometry','input')]:
    baseline=raw.parent/directory/'before-paint.json'
    assert json.loads(baseline.read_text('utf-8'))==json.loads((raw/(name+'-final-paint.json')).read_text('utf-8'))
    records.append(('baseline-prior/'+name+'-paint.json',baseline.read_bytes()))
records.append(('README.txt',b'PR #603 collapse/open increment, based on c14f20f5. Same two new collapse probes execute against baseline production code and final code. Baseline count assertion genuinely fails after full functional assertions: 48 actual collapse/open transitions build twice and resolve 2*N card port specs. Final count assertion passes with one build and N resolutions. All 216 collapse frames plus 312 original viewport frames and 64 original outside-canvas frames match exactly without normalization. Distinct desktop regressions=218; full GPU Present, native input, whole-frame time/peak and universal one-solve requirements remain pending. Two fixture scaffolding failures and compiler STATUS_ACCESS_VIOLATION are retained separately and are not performance negative controls. Each Card retains an extra row-count and collapse flag; no zero-memory-overhead claim.\n'))
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in records:z.writestr(name,data)
manifest=dict(**summary,archive_sha256=digest(archive.read_bytes()),records=[dict(path=name,bytes=len(data),sha256=digest(data)) for name,data in records])
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n','utf-8')
with zipfile.ZipFile(archive) as z:
    for row in manifest['records']:assert digest(z.read(row['path']))==row['sha256']
print(json.dumps(dict(tests=218,frames=592,records=len(records),bytes=archive.stat().st_size,sha256=manifest['archive_sha256'])))
