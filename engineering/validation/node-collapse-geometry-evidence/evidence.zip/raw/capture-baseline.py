import hashlib,json,shutil
from pathlib import Path
p=Path(__file__).parent;root=Path.cwd()
counts=json.loads((p/'before-counts.json').read_text('utf-8'))
assert len(counts)==48 and all(b==2 and r==2*n for _,b,r,n in counts)
paths=['desktop/app/src/node_editor/view/canvas.rs','desktop/app/src/node_editor/view/mod.rs',
    'desktop/app/src/node_editor/view/frame_cards_tests.rs','desktop/app/src/node_editor/view/frame_cards_tests/collapse_geometry.rs']
hashes={}
for path in paths:
    dest=p/'before-source'/path;dest.parent.mkdir(parents=True,exist_ok=True)
    data=(root/path).read_bytes();dest.write_bytes(data);hashes[path]=hashlib.sha256(data).hexdigest()
for file in ['app-build.jsonl','app-build.stderr']:
    shutil.copyfile(p/file,p/file.replace('app-build','before-build'))
(p/'before-source.json').write_text(json.dumps(hashes,indent=2),'utf-8')
print(json.dumps(dict(negative_controls=48,sources=len(paths))))
