import hashlib
import json
from pathlib import Path
import re
import zipfile

root = Path('E:/Dev/aem/.worktrees/ui-text-working-set')
out = Path(__file__).parent
sha = lambda data: hashlib.sha256(data).hexdigest()
record = json.loads((out / 'ui-full-final.json').read_text(encoding='utf-8'))
assert record['exit'] == 0 and 'source_changed_during_run' not in record
for file, digest in record['sources'].items():
    assert sha((root / file).read_bytes()) == digest, file
result_pattern = r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out'
counts = re.findall(result_pattern, (out / 'ui-full-final.stdout').read_text(encoding='utf-8'))
assert sum(int(row[0]) for row in counts) == 306, counts
assert all(all(int(v) == 0 for v in row[1:]) for row in counts)
negative = json.loads((out / 'negative-restored-entry-cap.json').read_text(encoding='utf-8'))
assert negative['exit'] == 101 and 'source_changed_during_run' not in negative
assert '0 passed; 3 failed;' in (out / 'negative-restored-entry-cap.stdout').read_text(encoding='utf-8')
for file, digest in record['sources'].items():
    if '/src/text/' not in file or '/budget_tests.rs' in file:
        assert negative['sources'][file] == digest, file
for name in ['layout', 'fitting']:
    assert (out / f'{name}.fixed.rs').read_bytes() == (root / f'desktop/ui/src/text/{name}.rs').read_bytes()
check = json.loads((out / 'desktop-final-check.json').read_text(encoding='utf-8'))
assert check['exit'] == 0 and 'source_changed_during_run' not in check
assert check['sources'] == record['sources']
requests = re.findall(r'(complete|fitted|draw) distinct_labels=(\d+)[^\r\n]* allocations=(\d+)', (out / 'ui-full-final.stderr').read_text(encoding='utf-8'))
assert len(requests) == 30 and all(int(row[2]) == 0 for row in requests), requests
pixels = out / 'final-pixels'
actuals = sorted(pixels.glob('*-actual.png'))
assert len(actuals) == 40 and len(list(pixels.glob('*.png'))) == 120
for actual in actuals:
    ref = actual.with_name(actual.name.replace('-actual.png', '-reference.png'))
    wrong = actual.with_name(actual.name.replace('-actual.png', '-wrong-label.png'))
    assert actual.read_bytes() == ref.read_bytes()
    assert wrong.read_bytes() != ref.read_bytes()
summary = {'base': 'e2dd04ab032598f977555bdb934177baab0a55f4', 'uiTests': 306, 'targetsIncludingDoctests': len(counts), 'newTestsIncludedInFullCount': 11, 'allocationMeasurements': requests, 'actualPixelPairs': 40, 'visibleWrongLabelControls': 40, 'restoredEntryCapFailures': 3, 'perCacheRetainedDataBudgetBytes': 1048576, 'limits': ['Spare hash buckets, allocator overhead, callers, atlas and shaping storage are not part of the retained-data charge.', 'New text and working sets exceeding the budget can allocate; this is not a whole-frame zero-allocation claim.', 'GPU images are offscreen components, not native window screenshots.']}
(out / 'test-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
members = {}
for file in out.iterdir():
    if file.suffix in ['.json', '.stdout', '.stderr', '.rs', '.py'] and file.name not in ['archive-receipt.json', 'pr-created.json']:
        members['records/' + file.name] = file.read_bytes()
for file in pixels.glob('*.png'):
    members['pixels/' + file.name] = file.read_bytes()
for file in record['sources']:
    members['source/' + file] = (root / file).read_bytes()
members['manifest.json'] = json.dumps({name: {'bytes': len(data), 'sha256': sha(data)} for name, data in members.items()}, indent=2).encode()
archive = root / 'engineering/validation/ui-text-working-set-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, data in members.items():
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, data in members.items():
        assert z.read(name) == data
receipt = {'members': len(members), 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()), 'summary': summary}
(out / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt))
