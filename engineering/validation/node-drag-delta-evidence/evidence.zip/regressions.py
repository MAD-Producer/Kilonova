import os,json,subprocess,hashlib,shutil
from pathlib import Path
p=Path(__file__).parent
exe=p/'isolated-runtime/tests-final.exe'
shutil.copy2('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-5e7ba7fc172e25b3.exe',exe)
e=os.environ.copy();e.pop('RUST_MIN_STACK',None);e['MOTION_LOG']='info';e['TEMP']=e['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
results=[]
for i,f in enumerate(['node_editor::','panels::frame_cache_tests::','panels::tests::','shell::presentation::interaction_tests::','panels::workload_tests::']):
 command=[str(exe),f,'--test-threads=1','--nocapture'];r=subprocess.run(command,env=e,capture_output=True)
 (p/'after'/('regression-'+str(i)+'.stdout')).write_bytes(r.stdout);(p/'after'/('regression-'+str(i)+'.stderr')).write_bytes(r.stderr)
 results.append(dict(command=command,exit=r.returncode));print(r.stdout.decode(errors='replace')[-350:],flush=True)
 (p/'after/regression.json').write_text(json.dumps(dict(exe_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),results=results),indent=2))
 assert r.returncode==0
