"""Real desktop entrypoint: bounded nested lookahead, default failure channels.

Uses the independently authored setup helpers from the earlier process check.
No test-only renderer, injected failure, or application logger is substituted.
"""
from pathlib import Path

helpers = Path(__file__).with_name('run_current_registry_normal_app.py').read_text(encoding='utf-8')
exec(compile(helpers.split('\ndef run(')[0], str(Path(__file__)), 'exec'))


def run(label, references):
    case = OUT / label
    case.mkdir()
    account = case / 'account'
    account.mkdir()
    fixture = copy.deepcopy(project)
    leaf = copy.deepcopy(layer)
    leaf['timeline'] = {'in_frame': 20, 'out_frame': 24, 'offset_frame': 0}
    child_layers = []
    for index in range(20):
        item = copy.deepcopy(leaf)
        item['id'] = 100 + index
        effect = copy.deepcopy(instance)
        effect['id'] = 100 + index
        item['effects'] = [effect]
        child_layers.append(item)
    fixture['compositions'] = [{
        'id': 'comp-budget-child', 'name': 'Bounded future scene',
        'width': 64, 'height': 64, 'fps': fixture['fps'], 'frames': 60,
        'work_area': {'in_frame': 0, 'out_frame': 60}, 'guides': [],
        'background': [0, 0, 0, 0], 'camera': fixture['camera'],
        'layers': child_layers, 'expressions': [],
    }]
    fixture['plugin_dependencies'] = [{key: instance[key] for key in ['plugin', 'version', 'hash']}]
    fixture['layers'] = []
    for index in range(references):
        reference = copy.deepcopy(layer)
        reference.update(id=1000+index, name='Future reference '+str(index), effects=[],
                         content={'kind': 'composition', 'clip': {
                             'composition': 'comp-budget-child', 'source_start_frame': 0,
                             'volume': 1, 'muted': False}})
        fixture['layers'].append(reference)
    root = case / 'project'
    root.mkdir()
    source = root / 'project.json'
    source.write_text(json.dumps(fixture, ensure_ascii=False, indent=2), encoding='utf-8')
    shutil.copy2(source, case / 'initial-project.json')
    original = sha(source)
    env = os.environ.copy()
    env['LOCALAPPDATA'] = str(account)
    env['MOTION_UI_LAYOUT'] = str(case / 'workspace.json')
    env.pop('MOTION_LOG', None)
    env.pop('MOTION_PROJECT', None)
    stderr = (case / 'stderr.log').open('w', encoding='utf-8')
    stdout = (case / 'stdout.jsonl').open('w', encoding='utf-8')
    transcript = (case / 'requests.jsonl').open('w', encoding='utf-8')
    started = time.monotonic()
    proc = subprocess.Popen([str(BINARY), '--mcp-ui', '--project', str(root), '--locale', 'en',
                             '--diagnostics-report', str(case / 'diagnostics.json')],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr,
                            text=True, encoding='utf-8', env=env,
                            creationflags=subprocess.CREATE_NO_WINDOW)
    received = queue.Queue()
    def read():
        for line in proc.stdout:
            stdout.write(line)
            stdout.flush()
            received.put(line)
        received.put(None)
    reader = threading.Thread(target=read, daemon=True)
    reader.start()
    stop = threading.Event()
    def show_owned_windows():
        shown = set()
        while not stop.wait(.02) and proc.poll() is None:
            for handle in windows(proc.pid):
                if handle not in shown:
                    user32.ShowWindow(handle, 4)
                    shown.add(handle)
    threading.Thread(target=show_owned_windows, daemon=True).start()
    seq = 0
    def send(method, params):
        nonlocal seq
        seq += 1
        request = {'jsonrpc': '2.0', 'id': seq, 'method': method, 'params': params}
        transcript.write(json.dumps({'at_ms': (time.monotonic()-started)*1000, 'request': request})+'\n')
        transcript.flush()
        proc.stdin.write(json.dumps(request)+'\n')
        proc.stdin.flush()
        line = received.get(timeout=30)
        assert line is not None, 'Normal application exited without a response'
        response = json.loads(line)
        assert response.get('id') == seq and 'error' not in response, response
        result = response['result']
        assert not result.get('isError'), result
        return result
    def tool(name):
        return send('tools/call', {'name': name, 'arguments': {}})['structuredContent']
    receipt = {'pid': proc.pid, 'references': references, 'binary_sha256': sha(BINARY),
               'entrypoint': '--mcp-ui', 'MOTION_LOG': None, 'fixture_sha256': original}
    try:
        send('initialize', {'protocolVersion': '2025-11-25', 'capabilities': {},
                            'clientInfo': {'name': 'nested-lookahead-qualification', 'version': '1'}})
        proc.stdin.write(json.dumps({'jsonrpc': '2.0', 'method': 'notifications/initialized'})+'\n')
        proc.stdin.flush()
        deadline = time.monotonic()+40
        while True:
            state = tool('motion_state')
            prep = state['preview']['pipelinePreparation']
            if (state.get('lastPresentedRevision') == state['revision'] and
                    state['presented'] > 0 and not prep['preparing']):
                break
            assert time.monotonic() < deadline, state
            time.sleep(.02)
        (case / 'presented-state.json').write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
        assert prep['task']['phase'] == 'installed', prep
        assert prep['error'] is None, prep
        assert prep['limited'] == (references == 32), prep
        if references == 32:
            assert len(prep['lookaheadErrors']) == 1, prep
            assert 'event budget exceeded' in prep['lookaheadErrors'][0]['cause'], prep
        else:
            assert prep['lookaheadErrors'] == [], prep
        result = tool('render_preview')
        shutil.copy2(Path(result['path']), case / 'current.png')
        pixels = Image.open(case / 'current.png').convert('RGBA')
        assert pixels.size == (64, 64)
        receipt['rgba_sha256'] = hashlib.sha256(pixels.tobytes()).hexdigest()
        receipt['preparation'] = prep
        assert sha(source) == original, 'Startup changed the authored document'
        for handle in windows(proc.pid):
            user32.PostMessageW(handle, 0x0010, 0, 0)
        proc.stdin.close()
        receipt['exit_code'] = proc.wait(timeout=20)
        assert receipt['exit_code'] == 0, receipt
        reader.join(timeout=5)
        assert not reader.is_alive()
        stderr.flush()
        stdout.flush()
        log = account / 'MotionStudio/logs/motion-studio.log'
        shutil.copy2(log, case / 'motion-studio.log')
        file_text = log.read_text(encoding='utf-8')
        error_text = (case / 'stderr.log').read_text(encoding='utf-8')
        wire = (case / 'stdout.jsonl').read_text(encoding='utf-8')
        # Error causes in structured motion_state are protocol data, not log
        # pollution. Every stdout line must be a complete JSON-RPC response.
        for line in wire.splitlines():
            assert json.loads(line)['jsonrpc'] == '2.0'
        reason = 'pipeline lookahead failed'
        if references == 32:
            failures = [line for line in file_text.splitlines() if reason in line]
            assert failures, file_text
            for failure in failures:
                for field in ['request=', 'generation=', 'revision=', 'frame=',
                              'phase=enumerate', 'elapsed_ms=', 'event budget exceeded']:
                    assert field in failure, failure
                request_id = failure.split('request=')[1].split()[0]
                start = 'pipeline preparation start request='+request_id+' '
                position = file_text.index(failure)
                assert any(start in line and 'phase=plan' in line for line in file_text[:position].splitlines())
            assert reason in error_text and 'event budget exceeded' in error_text
            receipt['default_error_file_stderr_stdout_isolation'] = True
            receipt['failure_records'] = failures
        else:
            assert reason not in file_text and reason not in error_text
        receipt['elapsed_ms'] = (time.monotonic()-started)*1000
        (case / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps({'case': label, 'pid': proc.pid, 'elapsed_ms': receipt['elapsed_ms'],
                          'limited': prep['limited']}), flush=True)
        return receipt
    except BaseException:
        (case / 'partial-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
        raise
    finally:
        stop.set()
        if proc.poll() is None:
            proc.kill()
            proc.wait(timeout=10)
        (case / 'process-exit.json').write_text(json.dumps({'exit_code': proc.returncode}), encoding='utf-8')
        reader.join(timeout=5)
        stderr.close()
        stdout.close()
        transcript.close()


healthy = run('healthy-control', 1)
limited = run('event-budget', 32)
assert healthy['pid'] != limited['pid']
assert healthy['rgba_sha256'] == limited['rgba_sha256'], 'Lookahead failure changed current-frame pixels'
(OUT / 'report.json').write_text(json.dumps({'runs': [healthy, limited],
    'scope': 'Two independent normal desktop processes, same current full RGBA; actual validated nested graph budget failure; default logging'},
    ensure_ascii=False, indent=2), encoding='utf-8')
