from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

P = Path(__file__).parent
S = Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
OUT = P / 'nested-pipeline-lookahead-evidence.zip'
assert not OUT.exists(), 'Never replace previous evidence'
phases = ['nested-lookahead-shared-budget-model', 'nested-lookahead-desktop-build',
          'nested-lookahead-desktop-all-targets',
          'nested-lookahead-normal-app']
source = None
for phase in phases:
    result = json.loads((P/(phase+'.json')).read_text(encoding='utf-8'))
    assert result['exit_code'] == 0, phase
    assert result['source_before'] == result['source_after'], phase
    if source is None:
        source = result['source_before']
    assert source == result['source_before'], phase
# The optional repeat never started tests: its build directory disappeared.
# The successful 16-test run has byte-identical production code. Its only
# source difference is the appended model unit test, itself in the 71-test run.
host = json.loads((P/'nested-lookahead-full-host-final.json').read_text(encoding='utf-8'))
assert host['exit_code'] == 0 and host['source_before'] == host['source_after']
path = 'crates/motion-model/src/layer_time/crossings.rs'
assert [name for name in source if source[name] != host['source_before'].get(name)] == [path]
assert source.keys() == host['source_before'].keys()
current = (S/path).read_bytes()
marker = b'\n    #[test]\n    fn shared_work_exhaustion_rejects_partial_crossings_and_fresh_budget_recovers()'
assert current.index(b'#[cfg(test)]\nmod tests {') < current.index(marker)
previous = current[:current.index(marker)] + current[-2:]
assert hashlib.sha256(previous).hexdigest() == host['source_before'][path]
assert hashlib.sha256(current).hexdigest() == source[path]
assert previous == (P/'nested-lookahead-host-tested-crossings.rs').read_bytes()
report = json.loads((P/'nested-lookahead-normal-app-evidence/report.json').read_text(encoding='utf-8'))
healthy, limited = report['runs']
assert healthy['pid'] != limited['pid']
assert healthy['rgba_sha256'] == limited['rgba_sha256']
assert all(run['exit_code'] == 0 for run in report['runs'])
assert limited['default_error_file_stderr_stdout_isolation']
members = {}
def add(name, data):
    assert name not in members
    members[name] = data
for item in sorted(P.glob('nested-lookahead-*')):
    if item.is_file() and item.suffix in ['.json', '.stdout', '.stderr']:
        add('commands/'+item.name, item.read_bytes())
for item in sorted((P/'nested-lookahead-normal-app-evidence').rglob('*')):
    relative = item.relative_to(P/'nested-lookahead-normal-app-evidence')
    if item.is_file() and 'account' not in relative.parts and item.suffix in ['.json', '.jsonl', '.log', '.png']:
        add('application/'+relative.as_posix(), item.read_bytes())
for name in ['run.py', 'run_nested_lookahead_normal_app.py', 'run_current_registry_normal_app.py',
             'archive_nested_lookahead.py']:
    add('controller/'+name, (P/name).read_bytes())
add('controller/template-project.json', (P/'frame-completion-existing-model-layer-evidence/project/project.json').read_bytes())
add('tested-source-identity.json', json.dumps(source, indent=2).encode())
add('host-tested-crossings.rs', previous)
add('current-crossings.rs', current)
add('working.patch', subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=S))
for name in ['crates/motion-host/src/session/pipeline_preparation/lookahead.rs',
             'crates/motion-host/src/session/pipeline_preparation/tests/nested.rs']:
    add('new-source/'+name, (S/name).read_bytes())
runtime = []
for item in sorted((P/'nested-lookahead-runtime').iterdir()):
    if item.is_file():
        with item.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        runtime.append({'name': item.name, 'bytes': item.stat().st_size, 'sha256': digest})
add('runtime-identity.json', json.dumps(runtime, indent=2).encode())
manifest = [{'name': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(members.items())]
add('manifest.json', json.dumps(manifest, indent=2).encode())
with zipfile.ZipFile(OUT, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    for item in manifest:
        assert hashlib.sha256(archive.read(item['name'])).hexdigest() == item['sha256']
receipt = {'archive': str(OUT), 'members': len(members), 'bytes': OUT.stat().st_size,
           'sha256': hashlib.sha256(OUT.read_bytes()).hexdigest(), 'source_count': len(source),
           'base_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=S, text=True).strip(),
           'normal_app_runs': 2, 'exit_code': 0}
(P/'nested-lookahead-archive-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt))
