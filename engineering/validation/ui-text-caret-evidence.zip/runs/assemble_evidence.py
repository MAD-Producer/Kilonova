from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile

repo = Path('E:/Dev/aem/.worktrees/desktop-release-contracts')
root = Path('E:/Dev/aem/artifacts/issue-goal-current/ui-text-caret')
result = json.loads((root / 'full-ui-result.json').read_text(encoding='utf-8'))
desktop = json.loads((root / 'desktop-check-result.json').read_text(encoding='utf-8'))
assert result['exit'] == desktop['exit'] == 0
assert all(result['required_inventory'].values())
assert result['totals'][1:] == [0, 0, 0, 0]
sources = json.loads((root / 'full-sources.json').read_text(encoding='utf-8'))
assert sources['head'] == result['source'] == desktop['source']
for name, digest in sources['files'].items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest, name

pngs = sorted((root / 'gpu-final').glob('*.png'))
assert len(pngs) == 70
for path in pngs:
    assert path.read_bytes() == (root / 'gpu' / path.name).read_bytes(), path.name
visual = repo / 'engineering/validation/ui-text-caret-native'
visual.mkdir(exist_ok=True)
shutil.copyfile(root / 'gpu/before-after.png', visual / 'before-after.png')

items = {}
for path in sorted(root.rglob('*')):
    if not path.is_file() or path.name in ['ci607-127008149834.log', 'evidence-index.json']:
        continue
    items['runs/' + path.relative_to(root).as_posix()] = path.read_bytes()
changed = subprocess.check_output(
    ['git', 'diff', '--name-only', '5468e210', '--', 'desktop/ui'], cwd=repo, text=True
).splitlines()
for name in changed:
    items['sources/' + name] = (repo / name).read_bytes()
manifest = {
    'tested_source': sources['head'],
    'parent': '5468e2108ca436ab1b2e81c639fa5be5ad348d98',
    'full_ui': result,
    'desktop_check': desktop,
    'gpu': {'comparisons': 40, 'negative_controls': 30, 'dpi': [1, 1.25, 1.5, 1.75, 2], 'widths': [96, 360]},
    'scope': 'Actual native component GPU readback, not a complete desktop-window acceptance.',
    'files': {k: {'bytes': len(v), 'sha256': hashlib.sha256(v).hexdigest()} for k, v in items.items()},
}
items['manifest.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8')
archive = repo / 'engineering/validation/ui-text-caret-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for name, content in items.items():
        z.writestr(name, content)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(items)
    for name, content in items.items():
        assert z.read(name) == content, name
index = {'members': len(items), 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
(root / 'evidence-index.json').write_text(json.dumps(index, indent=2), encoding='utf-8')
print(json.dumps(index))
