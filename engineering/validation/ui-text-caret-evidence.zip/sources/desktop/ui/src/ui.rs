//! Immediate-mode widgets and drawing helpers for panel content.
//!
//! Widgets write into a [`PaintList`] and read interaction from an [`Input`].
//! Keeping the API in terms of logical pixels means the same panel code serves
//! a 100% and a 200% display without branching.

use crate::input::{Event, Input, Key, MouseButton, Rect};
use crate::paint::{self, PaintList};
use crate::theme::Color;
mod numeric_readout;
mod text_layout;
pub(crate) use text_layout::positioned_text;
pub use numeric_readout::{number_text, NumberFormat};

/// Interaction result for one widget.
#[derive(Clone, Copy, PartialEq, Debug)]
pub struct Response {
    pub hovered: bool,
    pub clicked: bool,
    pub active: bool,
}

impl Response {
    fn none() -> Self {
        Self {
            hovered: false,
            clicked: false,
            active: false,
        }
    }
}

/// Draw and hit test a push button.
pub fn button(
    list: &mut PaintList,
    atlas: &mut crate::text::TextAtlas,
    area: Rect,
    label: &str,
    input: &impl crate::InputSource,
    enabled: bool,
) -> Response {
    let view = input.input_view();
    let input = &view;
    let styles = list.styles();

    button_styled(
        list,
        atlas,
        area,
        label,
        input,
        enabled,
        styles.as_ref(),
        "button",
    )
}
/// Draw and hit test an icon-only button sharing the `button.icon` styling.
pub fn button_icon(
    list: &mut PaintList,
    area: Rect,
    icon: crate::icons::Icon,
    input: &impl crate::InputSource,
    enabled: bool,
) -> Response {
    let view = input.input_view();
    let input = &view;
    let styles = list.styles();
    let states = if enabled {
        crate::style::States::default()
    } else {
        crate::style::States::default().with(crate::style::State::Disabled)
    };
    crate::icons::button(list, area, icon, input, styles.as_ref(), states)
}
pub fn button_styled(
    list: &mut PaintList,
    atlas: &mut crate::text::TextAtlas,
    area: Rect,
    label: &str,
    input: &impl crate::InputSource,
    enabled: bool,
    sheet: &crate::style::StyleSheet,
    class: &str,
) -> Response {
    let view = input.input_view();
    let input = &view;
    button_with_states(
        list,
        atlas,
        area,
        label,
        input,
        enabled,
        sheet,
        class,
        crate::style::States::default(),
    )
}
pub fn button_with_states(
    list: &mut PaintList,
    atlas: &mut crate::text::TextAtlas,
    area: Rect,
    label: &str,
    input: &impl crate::InputSource,
    enabled: bool,
    sheet: &crate::style::StyleSheet,
    class: &str,
    mut states: crate::style::States,
) -> Response {
    let view = input.input_view();
    let input = &view;
    use crate::style::{box_style, text_style, State};
    let hovered = enabled && area.contains(input.mouse);
    let clicked = hovered
        && input
            .pressed
            .is_some_and(|(b, p)| b == MouseButton::Left && area.contains(p));
    if hovered {
        states = states.with(State::Hovered);
    }
    if clicked || hovered && input.held == Some(MouseButton::Left) {
        states = states.with(State::Pressed);
    }
    if !enabled {
        states = states.with(State::Disabled);
    }
    let style = sheet
        .resolve(class, states)
        .unwrap_or_else(|| sheet.resolve("button", states).expect("button style"));
    box_style(list, area, style);
    text_style(
        list,
        atlas,
        area.shrink(style.padding),
        label,
        style,
        Align::Center,
    );
    Response {
        hovered,
        clicked,
        active: false,
    }
}

/// Horizontal alignment within a text rect.
#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Align {
    Left,
    Center,
    Right,
}

/// Draw a single line of text, ellipsized to fit `area`.
pub fn text(
    list: &mut PaintList,
    atlas: &mut crate::text::TextAtlas,
    area: Rect,
    label: &str,
    color: Color,
    align: Align,
) {
    text_sized(list, atlas, area, label, color, align, atlas.font_size());
}
pub fn text_sized(
    list: &mut PaintList,
    atlas: &mut crate::text::TextAtlas,
    area: Rect,
    label: &str,
    color: Color,
    align: Align,
    font_size: f32,
) {
    draw_text(list, atlas, area, label, color, align, font_size, false);
}

pub(crate) fn text_clipped(
    list: &mut PaintList,
    atlas: &mut crate::text::TextAtlas,
    area: Rect,
    label: &str,
    color: Color,
    align: Align,
    font_size: f32,
) {
    draw_text(list, atlas, area, label, color, align, font_size, true);
}

fn draw_text(
    list: &mut PaintList,
    atlas: &mut crate::text::TextAtlas,
    area: Rect,
    label: &str,
    color: Color,
    align: Align,
    font_size: f32,
    clip: bool,
) {
    if area.width() <= 0.0 || label.is_empty() {
        return;
    }
    if !font_size.is_finite() || font_size <= 0. || !atlas.font_size().is_finite() || atlas.font_size() <= 0. {
        atlas.report_layout_failure("invalid_size", format_args!("size={font_size} base_size={}", atlas.font_size()));
        return;
    }
    let fit = match atlas.fit_line(label, area.width() / font_size) {
        Ok(fit) => fit,
        Err(cause) => {
            atlas.report_layout_failure("draw", format_args!("bytes={} cause={cause}", label.len()));
            return;
        }
    };
    let width = fit.layout.advance * font_size;
    let origin = match align {
        Align::Left => area.min[0],
        Align::Center => area.min[0] + (area.width() - width).max(0.0) * 0.5,
        Align::Right => area.max[0] - width,
    };
    positioned_text(list, atlas, area, &fit.layout, origin, font_size, clip, |_| color);
}

/// A numeric field that scrubs horizontally and accepts a typed value.
///
/// This is the shared property-value interaction: drag changes the value
/// smoothly, a click opens the text field, and modifier keys invert or
/// constrain the drag.
#[derive(Clone, Copy, Default, Debug)]
pub struct ScrubField {
    pub editing: bool,
    /// Set while the pointer is dragging the value.
    pub dragging: bool,
    /// Value captured at drag start so late updates cannot move the base.
    pub drag_origin: f32,
}

impl ScrubField {
    pub fn begin(&mut self, value: f32) {
        self.dragging = true;
        self.drag_origin = value;
    }

    pub fn end(&mut self) {
        self.dragging = false;
        self.editing = false;
    }

    /// Value for a horizontal drag of `delta` logical pixels from where the
    /// drag started, clamped to the property's range.
    pub fn scrub(&self, delta: f32, range: (f32, f32), step: f32) -> f32 {
        (self.drag_origin + delta * step).clamp(range.0, range.1)
    }
}

/// Draw a scrub field and report whether the user grabbed it.
pub fn scrub_field(
    list: &mut PaintList,
    atlas: &mut crate::text::TextAtlas,
    area: Rect,
    label: &str,
    value: f32,
    field: &mut ScrubField,
    input: &impl crate::InputSource,
) -> Response {
    let view = input.input_view();
    let input = &view;
    let styles = list.styles();
    let colors = styles.colors();

    let hovered = area.contains(input.mouse);
    let grabbed = hovered
        && matches!(
            input.pressed,
            Some((MouseButton::Left, p)) if area.contains(p)
        );
    paint::rect(list, area, colors.SUNKEN);
    if hovered || field.dragging {
        paint::stroke(list, area, colors.ACCENT.with_alpha(0.6), 1.0);
    }
    let right = Rect::new(
        area.min[0] + area.width() * 0.45,
        area.min[1],
        area.width() * 0.55,
        area.height(),
    );
    let left = Rect::new(
        area.min[0],
        area.min[1],
        right.min[0] - area.min[0],
        area.height(),
    );
    text_clipped(
        list,
        atlas,
        left,
        label,
        colors.TEXT_MUTED,
        Align::Left,
        atlas.font_size(),
    );
    numeric_readout::scrub_text(
        list,
        atlas,
        right,
        value,
        colors.TEXT,
        Align::Right,
    );
    Response {
        hovered,
        clicked: grabbed,
        active: field.dragging,
    }
}

/// Format a value the way the engine reports it: no exponent, stable precision.
pub fn format_value(value: f32) -> String {
    if value == 0.0 {
        return "0".to_owned();
    }
    if !value.is_finite() {
        return "—".to_owned();
    }
    let magnitude = value.abs();
    let text = if magnitude >= 1000.0 {
        format!("{value:.1}")
    } else if magnitude >= 10.0 {
        format!("{value:.2}")
    } else if magnitude >= 1.0 {
        format!("{value:.3}")
    } else {
        format!("{value:.4}")
    };
    let trimmed = text.trim_end_matches('0');
    if magnitude >= 1000.0 && trimmed.ends_with('.') {
        format!("{trimmed}0")
    } else {
        trimmed.trim_end_matches('.').to_owned()
    }
}

/// Tab strip for a dock. Returns the tab index that was clicked, if any.
pub fn tab_strip(
    list: &mut PaintList,
    atlas: &mut crate::text::TextAtlas,
    area: Rect,
    titles: &[&str],
    active: usize,
    input: &impl crate::InputSource,
) -> Option<usize> {
    let view = input.input_view();
    let input = &view;
    let styles = list.styles();
    let colors = styles.colors();

    paint::rect(list, area, colors.CHROME);
    paint::rect(
        list,
        Rect::new(area.min[0], area.max[1] - 1.0, area.width(), 1.0),
        colors.BORDER,
    );
    if titles.is_empty() {
        return None;
    }
    let mut x = area.min[0];
    let mut clicked = None;
    for (index, title) in titles.iter().enumerate() {
        let tab = Rect::new(
            x,
            area.min[1],
            (atlas.measure(title) + 22.).min((area.max[0] - x).max(0.)),
            area.height() - 1.0,
        );
        let selected = index == active;
        paint::rect(
            list,
            tab,
            if selected {
                colors.PANEL
            } else {
                colors.CHROME
            },
        );
        let color = if selected {
            colors.TEXT
        } else {
            colors.TEXT_MUTED
        };
        text(
            list,
            atlas,
            Rect::new(
                tab.min[0] + 6.0,
                tab.min[1],
                tab.width() - 12.0,
                tab.height(),
            ),
            title,
            color,
            Align::Left,
        );
        if tab.contains(input.mouse)
            && matches!(input.pressed, Some((MouseButton::Left, p)) if tab.contains(p))
        {
            clicked = Some(index);
        }
        x += tab.width();
    }
    clicked
}

/// A checkbox with a label, used across the property panels.
pub fn checkbox(
    list: &mut PaintList,
    atlas: &mut crate::text::TextAtlas,
    area: Rect,
    label: &str,
    value: &mut bool,
    input: &impl crate::InputSource,
) -> Response {
    let view = input.input_view();
    let input = &view;
    let styles = list.styles();
    let colors = styles.colors();

    let box_area = Rect::new(area.min[0] + 2.0, area.min[1] + 3.0, 12.0, 12.0);
    let hovered = area.contains(input.mouse);
    let clicked =
        hovered && matches!(input.pressed, Some((MouseButton::Left, p)) if area.contains(p));
    if clicked {
        *value = !*value;
    }
    paint::rect(list, box_area, colors.SUNKEN);
    paint::stroke(
        list,
        box_area,
        if *value { colors.ACCENT } else { colors.BORDER },
        1.0,
    );
    if *value {
        paint::rect(
            list,
            Rect::new(box_area.min[0] + 3.0, box_area.min[1] + 3.0, 6.0, 6.0),
            colors.ACCENT,
        );
    }
    text(
        list,
        atlas,
        Rect::new(
            box_area.max[0] + 6.0,
            area.min[1],
            area.width(),
            area.height(),
        ),
        label,
        colors.TEXT,
        Align::Left,
    );
    Response {
        hovered,
        clicked,
        active: false,
    }
}

/// One row of the layer list: eye, lock, name and colour chip.
pub struct LayerRow {
    pub id: u64,
    pub name: String,
    pub color: Color,
    pub visible: bool,
    pub locked: bool,
    pub selected: bool,
    pub camera: bool,
    pub active: bool,
}

/// Draw the layer list, returning the clicked row id and column.
#[derive(Default, Debug)]
pub struct LayerListHit {
    pub row: Option<u64>,
    pub column: LayerColumn,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub enum LayerColumn {
    #[default]
    Name,
    Visibility,
    Lock,
}

/// Draw a vertical layer list with fixed row height.
pub fn layer_list(
    list: &mut PaintList,
    atlas: &mut crate::text::TextAtlas,
    area: Rect,
    rows: &[LayerRow],
    offset: f32,
    input: &impl crate::InputSource,
) -> LayerListHit {
    let view = input.input_view();
    let input = &view;
    let styles = list.styles();
    let colors = styles.colors();

    let mut hit = LayerListHit::default();
    let row_height = styles.metric("row.height", 22.).max(1.);
    let gutter = 44.0;
    let offset = if offset.is_finite() { offset.max(0.) } else { 0. };
    let first = (offset / row_height).floor().max(0.0) as usize;
    let last = ((offset + area.height().max(0.)) / row_height).ceil() as usize;
    paint::rect(list, area, colors.PANEL);
    let mut content = list.child();
    for index in first..last.min(rows.len()) {
        let row = &rows[index];
        let top = area.min[1] + index as f32 * row_height - offset;
        let row_area = Rect::new(area.min[0], top, area.width(), row_height);
        let visible_area = area.intersection(row_area);
        if visible_area.width() <= 0. || visible_area.height() <= 0. {
            continue;
        }
        let background = if row.selected {
            colors.ACCENT.with_alpha(0.18)
        } else if row.camera {
            colors.TRACK_CAMERA.with_alpha(0.10)
        } else {
            colors.PANEL
        };
        paint::rect(&mut content, row_area, background);
        if !row.active {
            // Inactive clips stay readable but clearly recede.
            paint::rect(&mut content, row_area, colors.APP_BACKGROUND.with_alpha(0.55));
        }
        let color = if row.camera {
            colors.TRACK_CAMERA
        } else {
            row.color
        };
        paint::rect(
            &mut content,
            Rect::new(row_area.min[0] + 2.0, top + 5.0, 3.0, row_height - 10.0),
            color,
        );
        let name_area = Rect::new(
            row_area.min[0] + gutter,
            top,
            row_area.width() - gutter - 8.0,
            row_height,
        );
        text(
            &mut content,
            atlas,
            name_area,
            &row.name,
            if row.active {
                colors.TEXT
            } else {
                colors.TEXT_MUTED
            },
            Align::Left,
        );
        let eye = Rect::new(row_area.min[0] + 12.0, top, 14.0, row_height);
        let lock = Rect::new(row_area.min[0] + 28.0, top, 14.0, row_height);
        icon(
            &mut content,
            eye,
            if row.visible { Icon::Eye } else { Icon::EyeOff },
        );
        icon(
            &mut content,
            lock,
            if row.locked { Icon::Lock } else { Icon::Unlock },
        );
        if let Some((MouseButton::Left, point)) = input.pressed {
            if visible_area.contains(point) {
                hit.row = Some(row.id);
                hit.column = if eye.contains(point) {
                    LayerColumn::Visibility
                } else if lock.contains(point) {
                    LayerColumn::Lock
                } else {
                    LayerColumn::Name
                };
            }
        }
    }
    content.clip_to(area);
    list.append(content);
    hit
}

/// Minimal line icons drawn as shapes; the project ships no icon font.
#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Icon {
    Eye,
    EyeOff,
    Lock,
    Unlock,
    Keyframe,
    Stopwatch,
    Camera,
    Chevron,
}

pub fn icon(list: &mut PaintList, area: Rect, icon: Icon) {
    let styles = list.styles();
    let colors = styles.colors();

    let svg = match icon {
        Icon::Eye | Icon::EyeOff => Some(crate::icons::Icon::Eye),
        Icon::Lock => Some(crate::icons::Icon::Lock),
        Icon::Camera => Some(crate::icons::Icon::Camera),
        Icon::Keyframe => Some(crate::icons::Icon::Key),
        Icon::Stopwatch => Some(crate::icons::Icon::Stopwatch),
        Icon::Chevron => Some(crate::icons::Icon::ChevronDown),
        _ => None,
    };
    if let Some(svg) = svg {
        crate::icons::draw(
            list,
            area,
            svg,
            16.,
            if icon == Icon::Keyframe {
                colors.KEYFRAME
            } else {
                colors.TEXT_MUTED
            },
        );
        if icon == Icon::EyeOff {
            let x = area.min[0] + area.width() * 0.25;
            let y = area.min[1] + area.height() * 0.25;
            paint::line(
                list,
                vec![[x, y + area.height() * 0.5], [x + area.width() * 0.5, y]],
                colors.TEXT_MUTED,
            );
        }
        return;
    }
    let size = 12.0;
    let min = [
        area.min[0] + (area.width() - size) * 0.5,
        area.min[1] + (area.height() - size) * 0.5,
    ];
    let max = [min[0] + size, min[1] + size];
    let color = colors.TEXT_MUTED;
    match icon {
        Icon::Chevron => {
            paint::line(
                list,
                vec![
                    [min[0] + 3.0, min[1] + 2.0],
                    [min[0] + 7.0, min[1] + 6.0],
                    [min[0] + 11.0, min[1] + 2.0],
                ],
                color,
            );
        }
        Icon::Eye | Icon::EyeOff => {
            paint::line(
                list,
                vec![
                    [min[0], min[1] + 6.0],
                    [min[0] + 4.0, min[1] + 2.0],
                    [min[0] + 8.0, min[1] + 2.0],
                    [min[0] + 12.0, min[1] + 6.0],
                    [min[0] + 8.0, min[1] + 10.0],
                    [min[0] + 4.0, min[1] + 10.0],
                    [min[0], min[1] + 6.0],
                ],
                color,
            );
            paint::rect(list, Rect::new(min[0] + 5.0, min[1] + 5.0, 2.0, 2.0), color);
            if icon == Icon::EyeOff {
                paint::line(
                    list,
                    vec![[min[0], min[1] + 10.0], [min[0] + 12.0, min[1] + 1.0]],
                    color,
                );
            }
        }
        Icon::Lock | Icon::Unlock => {
            paint::rect(list, Rect::new(min[0] + 2.0, min[1] + 6.0, 8.0, 5.0), color);
            let shackle = if icon == Icon::Lock {
                vec![
                    [min[0] + 3.0, min[1] + 6.0],
                    [min[0] + 3.0, min[1] + 3.0],
                    [min[0] + 9.0, min[1] + 3.0],
                    [min[0] + 9.0, min[1] + 6.0],
                ]
            } else {
                vec![
                    [min[0] + 3.0, min[1] + 6.0],
                    [min[0] + 3.0, min[1] + 4.0],
                    [min[0] + 9.0, min[1] + 3.0],
                    [min[0] + 9.0, min[1] + 1.0],
                ]
            };
            paint::line(list, shackle, color);
        }
        Icon::Keyframe => {
            // A diamond, the same marker the timeline uses.
            let mid = [(min[0] + max[0]) * 0.5, (min[1] + max[1]) * 0.5];
            let radius = 4.0;
            paint::line(
                list,
                vec![
                    [mid[0], mid[1] - radius],
                    [mid[0] + radius, mid[1]],
                    [mid[0], mid[1] + radius],
                    [mid[0] - radius, mid[1]],
                    [mid[0], mid[1] - radius],
                ],
                colors.KEYFRAME,
            );
        }
        Icon::Stopwatch => {
            paint::rect(list, Rect::new(min[0] + 2.0, min[1] + 4.0, 8.0, 7.0), color);
            paint::line(
                list,
                vec![[min[0] + 6.0, min[1] + 2.0], [min[0] + 6.0, min[1] + 4.0]],
                color,
            );
        }
        Icon::Camera => {
            paint::rect(list, Rect::new(min[0], min[1] + 3.0, 9.0, 6.0), color);
            paint::line(
                list,
                vec![
                    [min[0] + 9.0, min[1] + 5.0],
                    [min[0] + 12.0, min[1] + 3.0],
                    [min[0] + 12.0, min[1] + 9.0],
                    [min[0] + 9.0, min[1] + 7.0],
                ],
                color,
            );
        }
    }
}

/// Translate a raw event into a frame's input, keeping the previous mouse
/// position so drags can be measured as deltas.
pub fn accumulate(input: &mut Input, event: Event) {
    input.pending = true;
    match event {
        Event::MouseMoved { position } => {
            if let Some(origin) = input.pointer_origin {
                input.pointer_travel = input
                    .pointer_travel
                    .max((position[0] - origin[0]).hypot(position[1] - origin[1]));
            }
            input.mouse = position;
        }
        Event::MousePressed { position, button } => {
            if let Some(previous) = input.pressed {
                static OVERWRITES: std::sync::OnceLock<crate::observability::Failures> = std::sync::OnceLock::new();
                OVERWRITES.get_or_init(Default::default).record("input.pressed_overwrite", "pending", format_args!("previous={previous:?} next=({button:?},{position:?})"));
            }
            input.mouse = position;
            input.pressed = Some((button, position));
            // A secondary button must not steal an ongoing pointer gesture.
            if input.held.is_none() {
                input.held = Some(button);
                input.pointer_origin = Some(position);
                input.pointer_travel = 0.;
            }
        }
        Event::MouseReleased { position, button } => {
            if let Some(previous) = input.released {
                static OVERWRITES: std::sync::OnceLock<crate::observability::Failures> = std::sync::OnceLock::new();
                OVERWRITES.get_or_init(Default::default).record("input.released_overwrite", "pending", format_args!("previous={previous:?} next=({button:?},{position:?})"));
            }
            input.mouse = position;
            input.released = Some((button, position));
            if let Some(origin) = input.pointer_origin {
                input.pointer_travel = input
                    .pointer_travel
                    .max((position[0] - origin[0]).hypot(position[1] - origin[1]));
            }
            if input.held == Some(button) {
                input.held = None;
                input.pointer_origin = None;
            }
        }
        Event::MouseWheel { delta } => {
            input.wheel[0] += delta[0];
            input.wheel[1] += delta[1];
        }
        Event::KeyPressed { key, modifiers } | Event::KeyRepeated { key, modifiers } => {
            input.modifiers = modifiers;
            if !input.held_keys.contains(&key) {
                input.held_keys.push(key);
            }
            if !input.composing && !input.ime_consumed {
                input.key_repeats.resize(input.keys.len(), false);
                input.keys.push((key, modifiers));
                input
                    .key_repeats
                    .push(matches!(event, Event::KeyRepeated { .. }));
            }
        }
        Event::KeyReleased { key, modifiers } => {
            input.modifiers = modifiers;
            input.held_keys.retain(|held| *held != key);
            input.released_keys.push(key);
        }
        Event::ImeComposition(active) => {
            input.composing = active;
            input.ime_consumed = true;
            input.keys.clear();
            input.key_repeats.clear();
        }
        Event::TextCommit(text) => {
            input.composing = false;
            input.ime_consumed = true;
            input.keys.clear();
            input.key_repeats.clear();
            input.text.push_str(&text);
        }
        Event::TextInput(text) => input.text.push_str(&text),
        Event::LongPress { position } => input.long_press = Some(position),
        Event::PointerLeft => {
            input.mouse = [f32::NEG_INFINITY; 2];
            input.held = None;
            input.pressed = None;
            input.released = None;
            input.pointer_origin = None;
            input.pointer_travel = 0.;
            input.long_press = None;
        }
        Event::FocusLost => {
            input.focus_lost = true;
            input.held = None;
            input.pressed = None;
            input.released = None;
            input.modifiers = Default::default();
            input.held_keys.clear();
            input.released_keys.clear();
            input.keys.clear();
            input.key_repeats.clear();
            input.text.clear();
            input.composing = false;
            input.ime_consumed = false;
            input.pointer_origin = None;
            input.pointer_travel = 0.;
        }
    }
}

/// Key chords the shell reacts to globally.
pub fn matches(input: &impl crate::InputSource, key: Key, control: bool) -> bool {
    let view = input.input_view();
    let input = &view;
    input.key_presses().any(|(k, m, repeat)| !repeat && k == key && m.control == control)
}

impl Default for Response {
    fn default() -> Self {
        Response::none()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::input::{Modifiers, Scroll};

    #[test]
    fn pending_input_survives_painting_and_coalesces_wheel_until_consumed() {
        let mut input = Input::default();
        accumulate(
            &mut input,
            Event::MousePressed {
                position: [10., 20.],
                button: MouseButton::Left,
            },
        );
        accumulate(&mut input, Event::MouseWheel { delta: [1., 2.] });
        accumulate(&mut input, Event::MouseWheel { delta: [3., -1.] });
        assert!(input.pending);
        assert_eq!(input.wheel, [4., 1.]);
        let mut paint_input = Input {
            mouse: input.mouse,
            ..Default::default()
        };
        paint_input.begin_frame();
        assert!(input.pending);
        input.begin_frame();
        assert!(!input.pending);
        assert_eq!(input.held, Some(MouseButton::Left));
        assert_eq!(input.wheel, [0., 0.]);
    }

    #[test]
    fn leaving_the_window_invalidates_the_last_hit_test_coordinate() {
        let mut input = Input::default();
        accumulate(
            &mut input,
            Event::MousePressed {
                position: [10., 20.],
                button: MouseButton::Left,
            },
        );
        accumulate(&mut input, Event::PointerLeft);
        assert_eq!(input.held, None);
        assert_eq!(input.pointer_origin, None);
        assert!(!Rect::new(0., 0., 100., 100.).contains(input.mouse));

        // winit can still deliver the button release after CursorLeft. The
        // shell uses the invalidated coordinate, so no widget sees it inside.
        let position = input.mouse;
        accumulate(
            &mut input,
            Event::MouseReleased {
                position,
                button: MouseButton::Left,
            },
        );
        assert!(!Rect::new(0., 0., 100., 100.).contains(input.released.unwrap().1));
    }

    #[test]
    fn values_format_without_trailing_noise() {
        assert_eq!(format_value(0.0), "0");
        assert_eq!(format_value(1080.0), "1080.0");
        assert_eq!(format_value(0.5), "0.5");
        assert_eq!(format_value(-12.25), "-12.25");
        assert_eq!(format_value(f32::NAN), "—");
    }

    #[test]
    fn scrubbing_is_relative_to_the_drag_origin_not_the_current_value() {
        let mut field = ScrubField::default();
        field.begin(10.0);
        // A second update mid-drag must not compound.
        assert_eq!(field.scrub(100.0, (-1000.0, 1000.0), 0.5), 60.0);
        assert_eq!(field.scrub(100.0, (-1000.0, 1000.0), 0.5), 60.0);
    }

    #[test]
    fn scrubbing_respects_the_declared_range() {
        let mut field = ScrubField::default();
        field.begin(0.0);
        assert_eq!(field.scrub(10_000.0, (0.0, 360.0), 1.0), 360.0);
        assert_eq!(field.scrub(-10_000.0, (0.0, 360.0), 1.0), 0.0);
    }

    #[test]
    fn modifiers_are_recorded_for_keyboard_chords() {
        let mut input = Input::default();
        input.begin_frame();
        accumulate(
            &mut input,
            Event::KeyPressed {
                key: Key::Z,
                modifiers: Modifiers {
                    control: true,
                    ..Default::default()
                },
            },
        );
        assert!(matches(&input, Key::Z, true));
        assert!(!matches(&input, Key::Z, false));
        input.begin_frame();
        assert!(input.keys.is_empty());
    }

    #[test]
    fn a_scroll_region_clamps_to_its_content() {
        let mut scroll = Scroll::default();
        scroll.consume(-500.0, 100.0, 400.0);
        assert_eq!(scroll.offset, 300.0);
        scroll.consume(-500.0, 100.0, 400.0);
        assert_eq!(scroll.offset, 300.0, "must not scroll past the content");
        scroll.consume(5000.0, 100.0, 400.0);
        assert_eq!(scroll.offset, 0.0);
    }
}
