from pathlib import Path
import subprocess, json, os, hashlib

raw = Path(__file__).parent
paths = [Path('desktop/app/src/panels/effect_controls.rs'), Path('desktop/app/src/panels/animation_controls.rs')]
originals = {path: path.read_bytes() for path in paths}
script = (raw / 'build-app.ps1').read_text(encoding='utf-8').replace('app-build.jsonl', 'negative-build.jsonl').replace('app-build.stderr', 'negative-build.stderr')
(raw / 'build-negative.ps1').write_text(script, encoding='utf-8')
try:
    for path, site, clear in [(paths[0], 'effects.layer_id', 'self.clear_key_channel();'), (paths[1], 'curve.controls.layer_id', 'self.clear_key();')]:
        source = originals[path].decode('utf-8').replace('\r\n', '\n')
        guard = f'''        let Some(object) = self.layer_identity.read(layer, state, "{site}") else {{
            if self.cancel() {{ out.push(Action::History(4)); }}
            {clear}
            return;
        }};'''
        assert source.count(guard) == 1
        path.write_text(source.replace(guard, '        let object = layer["id"].as_u64().unwrap();'), encoding='utf-8')
    result = subprocess.run(['pwsh', '-NoProfile', '-File', str(raw / 'build-negative.ps1')])
    assert result.returncode == 0, 'negative control must compile'
    records = [json.loads(line) for line in (raw / 'negative-build.jsonl').read_text(encoding='utf-8').splitlines() if line.startswith('{')]
    exe = next(r['executable'] for r in records if r.get('reason') == 'compiler-artifact' and r.get('target', {}).get('name') == 'motion-studio' and r.get('executable'))
    env = os.environ.copy()
    env.pop('RUST_MIN_STACK', None)
    env.update(MOTION_LOG='info', TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp', TMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp')
    env['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + env['PATH']
    tests = [('effects', 'panels::layer_identity::tests::actual_property_renderers_skip_malformed_layers_without_rows_actions_or_panics_and_recover'), ('easing', 'panels::animation_controls::mapped_tests::layer_identity::malformed_layer_identity_cancels_real_easing_drag_once_and_preserves_undo_state')]
    receipts = []
    for name, test in tests:
        command = [exe, '--exact', test, '--nocapture']
        result = subprocess.run(command, env=env, capture_output=True)
        (raw / f'negative-{name}.stdout').write_bytes(result.stdout)
        (raw / f'negative-{name}.stderr').write_bytes(result.stderr)
        assert result.returncode == 101
        assert b'FAILED' in result.stdout and b'Option::unwrap()' in result.stderr
        receipts.append(dict(command=command, exit=result.returncode, original_unwrap_panicked=True))
        print(name, 'original unwrap control fails as required:', result.returncode, flush=True)
    (raw / 'negative-receipt.json').write_text(json.dumps(dict(executable=exe, sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest(), tests=receipts), indent=2), encoding='utf-8')
finally:
    for path, content in originals.items():
        path.write_bytes(content)
    subprocess.run(['git', 'diff', '--exit-code', '--', *[str(path) for path in paths]], check=True)
    print('Both production guards restored; rebuild required before positive tests.', flush=True)
