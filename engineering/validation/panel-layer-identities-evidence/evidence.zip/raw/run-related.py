from pathlib import Path
import json,subprocess,os,hashlib
raw=Path(__file__).parent
records=[json.loads(line) for line in (raw/'app-build.jsonl').read_text(encoding='utf-8').splitlines() if line.startswith('{')]
exe=next(r['executable'] for r in records if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='motion-studio' and r.get('executable'))
env=os.environ.copy();env.pop('RUST_MIN_STACK',None)
env.update(MOTION_LOG='info',TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp',TMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp',MOTION_PANEL_ID_EVIDENCE=str(raw/'final-default-logs-restored'))
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
args=[exe,'panels::layer_identity::','panels::effect_controls::','panels::animation_controls::','--nocapture']
receipt=dict(executable=exe,sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest(),command=args,runtime_stack_override=False)
(raw/'final-executable.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
assert receipt['sha256']!=json.loads((raw/'negative-receipt.json').read_text())['sha256'],'do not execute the old negative binary as positive evidence'
with (raw/'related-tests.stdout').open('w',encoding='utf-8') as out,(raw/'related-tests.stderr').open('w',encoding='utf-8') as err:
    result=subprocess.run(args,env=env,stdout=out,stderr=err)
(raw/'related-tests-exit.json').write_text(json.dumps(dict(exit=result.returncode)),encoding='utf-8')
lines=(raw/'related-tests.stdout').read_text(encoding='utf-8').splitlines()
print('\n'.join(line for line in lines if 'test result:' in line or 'ignored' in line or 'FAILED' in line or 'panels::layer_identity::' in line))
print((raw/'related-tests.stderr').read_text(encoding='utf-8')[-2500:])
raise SystemExit(result.returncode)
