from pathlib import Path
p=Path('crates/motion-render/src/renderer.rs')
s=p.read_text(encoding='utf-8')
old='''        let obsolete_inputs:Vec<_>=self.images.keys().copied()
            .filter(|k|matches!(k,TextureKey::Mask(_) | TextureKey::EffectInput(_))).collect();
        if !obsolete_inputs.is_empty() {
            for key in obsolete_inputs {
                if let Some(image) = self.images.remove(&key) {
                    self.texture_bytes = self.texture_bytes.saturating_sub(image.bytes);
                }
            }
            self.mask_gpu.clear();self.effect_gpu.state.invalidate();
        }'''
assert old in s
s=s.replace(old,'        self.release_effect_input_images();')
start=s.index('    fn prepare_input_snapshots(')
end=s.index('        let needed=',start)
s=s[:start]+'''    fn release_effect_input_images(&mut self) {
        let mut removed = false;
        self.images.retain(|key, image| {
            if matches!(key, TextureKey::Mask(_) | TextureKey::EffectInput(_)) {
                self.texture_bytes = self.texture_bytes.saturating_sub(image.bytes);
                removed = true;
                false
            } else { true }
        });
        if removed {
            self.mask_gpu.clear();
            self.effect_gpu.state.invalidate();
        }
    }
    fn prepare_input_snapshots(&mut self)->Result<()> {
        let frame=&self.effect_gpu.builder.frame;
        let input_order=self.effect_gpu.builder.effect_snapshot_order();
        let storage=crate::image_formats::color_storage(frame.precision);
        let format=crate::image_formats::native_format(storage);
        let pixel_bytes=storage.bytes_per_pixel();
        self.images.retain(|key, image| {
            if matches!(key, TextureKey::EffectInput(_))
                && !input_order.iter().any(|&i| TextureKey::EffectInput(frame.draws[i].layer) == *key) {
                self.texture_bytes = self.texture_bytes.saturating_sub(image.bytes);
                self.effect_gpu.state.invalidate();
                false
            } else { true }
        });
''' + s[end:]
old='''        let needed=specs.iter().filter(|(key,_,w,h)|self.images.get(key).is_none_or(|image|image.size!=(*w,*h)||image._texture.format()!=format))
            .map(|(_,_,w,h)|u64::from(*w)*u64::from(*h)*pixel_bytes).sum();
        self.trim_image_cache(needed);
        for (key,layer,width,height) in specs {'''
new='''        let needed=input_order.iter().map(|&i| {
            let draw=&frame.draws[i];let pass=&frame.passes[draw.pass_end-1];
            (TextureKey::EffectInput(draw.layer),pass.width,pass.height)
        }).filter(|(key,w,h)|self.images.get(key).is_none_or(|image|image.size!=(*w,*h)||image._texture.format()!=format))
            .map(|(_,w,h)|u64::from(w)*u64::from(h)*pixel_bytes).sum();
        self.trim_image_cache(needed);
        for index in 0..self.effect_gpu.builder.effect_snapshot_order().len() {
            let i=self.effect_gpu.builder.effect_snapshot_order()[index];
            let frame=&self.effect_gpu.builder.frame;
            let draw=&frame.draws[i];let pass=&frame.passes[draw.pass_end-1];
            let (key,layer,width,height)=(TextureKey::EffectInput(draw.layer),draw.layer,pass.width,pass.height);'''
assert old in s
s=s.replace(old,new)
s=s.replace('let image_input_order = loop {','loop {')
s=s.replace('''            let input_order = self.effect_gpu.builder.effect_snapshot_order().to_vec();
            self.prepare_input_snapshots(&input_order)''','''            self.prepare_input_snapshots()''')
s=s.replace('Ok(()) => break input_order,','Ok(()) => break,')
s=s.replace('for i in image_input_order {','for &i in self.effect_gpu.builder.effect_snapshot_order() {')
p.write_text(s,encoding='utf-8')
p=Path('crates/motion-render/src/renderer/snapshot_storage_tests.rs')
s=p.read_text(encoding='utf-8').replace('renderer.prepare_input_snapshots(&order).unwrap();','renderer.prepare_input_snapshots().unwrap();')
p.write_text(s,encoding='utf-8')
