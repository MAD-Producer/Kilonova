import hashlib,json,re,zipfile
from pathlib import Path
ROOT=Path('E:/Dev/aem/.worktrees/layer-time-mapping')
RAW=Path('E:/Dev/aem/artifacts/issue-goal-current/snapshot-storage')
OUT=ROOT/'engineering/validation/snapshot-storage-evidence'
DEPS=Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps')
SOURCES=['crates/motion-render/src/renderer.rs','crates/motion-render/src/renderer/snapshot_storage_tests.rs','crates/motion-render/src/renderer/admission_tests/input_snapshot_context.rs','crates/motion-render/src/renderer/scene_asset_storage_tests.rs','crates/motion-render/src/test_allocations.rs','engineering/validation/snapshot-storage.md']
def read(p):
    b=p.read_bytes()
    return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8-sig')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
results={}
for name,expected in [('final-snapshot',9),('regression',10),('scene-regression',2),('workspace',0)]:
    code=int(read(RAW/(name+'.exit')).strip())
    assert code==0,(name,code)
    counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',read(RAW/(name+'.log')))
    assert all(int(f)==0 and int(i)==0 for _,f,i in counts)
    count=sum(int(n) for n,_,_ in counts)
    assert count==expected,(name,count)
    results[name]={'exit_code':code,'passed':count,'log':name+'.log'}
assert int(read(RAW/'before.exit').strip())==101
assert 'left: 120' in read(RAW/'before.log')
assert read(RAW/'final-snapshot.log').count('calls=120 allocations=0')==3
binaries=['motion_render-1fcc3fb8d09fa888.exe','frame_image_imports-8d8832285c6b6175.exe','image_input_order_allocations-7644902f8f2c540b.exe','typed_snapshot_execution-915ef53abd56fb31.exe']
manifest={'base_commit':'4bd7cd18a173458a3a385aaab1323f10e85e5122','branch':'perf/scene-asset-storage','pr':589,'issue':126,'issue_complete':False,'results':results,'distinct_tests':21,'baseline':{'exit':101,'calls':120,'allocations':120},'source_sha256_raw_files':{p:sha(ROOT/p) for p in SOURCES},'binary_sha256':{p:sha(DEPS/p) for p in binaries},'commands':['cargo test -p motion-render --lib snapshot --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture','cargo test -p motion-render --test typed_snapshot_execution --test frame_image_imports --test image_input_order_allocations --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture','cargo test -p motion-render --lib scene_asset_storage --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target -- --test-threads=1 --nocapture','cargo check --workspace --all-targets --exclude motion-android --locked --features motion-desktop/ffmpeg,motion-host/diagnostics --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target'],'scope':'Calling-thread allocations in resident snapshot preparation, after plan creation and GPU warmup. Whole-preview-frame allocation, background work and FPS remain unproven. Existing production failure channels unchanged.','ci':'pending for final head'}
OUT.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(OUT/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(RAW.iterdir()):
        if p.is_file():z.write(p,'raw/'+p.name)
    for p in SOURCES:z.write(ROOT/p,'final-source/'+p)
manifest['evidence_zip_sha256']=sha(OUT/'evidence.zip')
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results))
