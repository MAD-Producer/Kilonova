"""Freeze the completed frame-continuation runs; never overwrite evidence."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

ROOT = Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
ART = Path(__file__).parent
OUT = ROOT / 'engineering/validation/desktop-pipeline-frame-completion-evidence.zip'
BASE = '7cf26f865f4a314667b20ca9bbacb553814d0456'
assert not OUT.exists()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

assert git('rev-parse', 'HEAD').decode().strip() == BASE
names = (git('ls-files', 'desktop/app', 'desktop/ui', 'crates', 'Cargo.toml', 'Cargo.lock')
         + git('ls-files', '--others', '--exclude-standard', 'desktop/app', 'desktop/ui', 'crates')).decode().splitlines()
live = {n: hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
        for n in sorted(set(names)) if (ROOT/n).is_file()}
final = json.loads((ART/'frame-completion-lifecycle.json').read_text(encoding='utf-8'))['source_before']
assert live == final
changed = sorted(set((git('diff', '--name-only') + git('ls-files', '--others', '--exclude-standard')).decode().splitlines()))
changed = [n for n in changed if n.startswith(('crates/', 'desktop/'))]
assert len(changed) == 11, changed

members = {}
def add(name, data):
    assert name not in members, name
    members[name] = data

qualified = []
historical = []
test_count = 0
for f in sorted(ART.glob('frame-completion*.json')):
    d = json.loads(f.read_text(encoding='utf-8'))
    if 'source_before' not in d:
        continue
    assert d['source_before'] == d['source_after'], f
    stdout = (ART/(f.stem+'.stdout')).read_bytes()
    stderr = (ART/(f.stem+'.stderr')).read_bytes()
    row = {'phase': f.stem, 'command': d['command'], 'exit_code': d['exit_code'],
           'elapsed_seconds': d['elapsed_seconds'], 'source_unchanged': True,
           'matches_final_source': d['source_before'] == final,
           'results': re.findall(r'test result:.*', stdout.decode('utf-8', errors='replace'))}
    if row['matches_final_source']:
        assert d['exit_code'] == 0, f
        if f.stem != 'frame-completion-all-targets':
            assert len(row['results']) == 1, row
            match = re.search(r'ok\. (\d+) passed; 0 failed; 0 ignored;', row['results'][0])
            assert match and int(match[1]) > 0, row
            test_count += int(match[1])
        qualified.append(row)
    else:
        historical.append(row)
    for suffix in ['.json', '.stdout', '.stderr']:
        path = ART/(f.stem+suffix)
        add('runs/'+path.name, path.read_bytes())
assert len(qualified) == 17 and test_count == 38, (len(qualified), test_count)
for directory in sorted(ART.glob('frame-completion*-evidence')):
    for f in sorted(directory.rglob('*')):
        if f.is_file():
            add('native/'+f.relative_to(ART).as_posix(), f.read_bytes())
report = json.loads((ART/'frame-completion-lifecycle-evidence/report.json').read_text(encoding='utf-8'))
assert [r['scenario'] for r in report] == ['complete','edit','reopen','shutdown']
assert all(r['supported'] for r in report)
assert report[-1]['cancelledBeforeWorkerRelease'] is True
assert all(r['completion']['pending'] == 0 for r in report[:-1])
binary = Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-23245631dbb5fb4e.exe')
with binary.open('rb') as stream:
    binary_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
summary = {'baseline': BASE, 'source_files': len(final), 'qualified_runs': qualified,
           'historical_runs_not_final_qualification': historical, 'passed': test_count,
           'failed': 0, 'ignored': 0,
           'desktop_binary': {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': binary_sha},
           'scope': 'Scoped local native Windows regressions, not full CI or complete issue #64',
           'changed_source_files': changed,
           'native_scenarios': [{k:v for k,v in r.items() if k != 'after'} for r in report]}
add('qualification.json', json.dumps(summary, ensure_ascii=False, indent=2).encode('utf-8'))
add('source-identity.json', json.dumps(final, indent=2).encode('utf-8'))
add('changes.patch', git('diff', '--binary'))
for n in changed:
    add('sources/current/'+n, (ROOT/n).read_bytes())
    base = subprocess.run(['git','show',BASE+':'+n], cwd=ROOT, capture_output=True)
    if base.returncode == 0:
        add('sources/baseline/'+n, base.stdout)
for n in ['run.py','archive_frame_completion.py','frame-completion-test-list.txt']:
    add('controller/'+n, (ART/n).read_bytes())
prior = ART.parent/'next-priority'
for n in ['pr627-windows-cache-storage-failed.log','pr627-7cf-jobs-before-frame-completion.json']:
    add('historical-ci/'+n, (prior/n).read_bytes())
manifest = [{'name': n, 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
            for n,b in sorted(members.items())]
add('manifest.json', json.dumps(manifest, indent=2).encode('utf-8'))
OUT.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(OUT, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n,b in sorted(members.items()):
        z.writestr(n,b)
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    assert len(z.infolist()) == len(members)
    for row in manifest:
        assert hashlib.sha256(z.read(row['name'])).hexdigest() == row['sha256']
receipt = {'archive': str(OUT), 'members': len(members), 'bytes': OUT.stat().st_size,
           'sha256': hashlib.sha256(OUT.read_bytes()).hexdigest(), 'qualification': summary}
receipt_path = ART/'frame-completion-archive-receipt.json'
assert not receipt_path.exists()
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k != 'qualification'}, ensure_ascii=False))
