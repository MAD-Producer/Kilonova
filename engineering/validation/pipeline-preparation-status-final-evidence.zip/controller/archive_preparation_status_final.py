from pathlib import Path
import hashlib
import json
import zipfile
from PIL import Image

P = Path(__file__).parent
S = Path('E:/Dev/aem/.worktrees/desktop-arm-runner')
E = P/'preparation-status-native-v2-evidence'
report = json.loads((E/'report.json').read_text(encoding='utf-8'))
assert report['cacheSupported'] is True
assert report['sourceUnchanged'] and report['revisionUnchanged']
assert report['completedWithoutInput'] and report['stablePollDoesNotInvalidate']
assert len(report['cases']) == 24
assert all(case['errorPixelsPreserved'] and case['statusPixelsChanged'] for case in report['cases'])
phases = ['preparation-status-host-desktop-v1', 'preparation-status-host-desktop-v2',
          'preparation-status-native-v1', 'preparation-status-normal-build-v1',
          'preparation-status-native-v2', 'preparation-status-normal-build-v2',
          'preparation-status-normal-app-v1']
for name in phases:
    data = json.loads((P/(name+'.json')).read_text(encoding='utf-8'))
    assert data['source_before'] == data['source_after'], name
    assert data['exit_code'] == (101 if name.endswith('desktop-v1') else 0), name
log = (E/'motion-studio.log').read_text(encoding='utf-8')
assert 'logging initialized level=INFO' in log
assert not any('start #' in line and line.endswith(' present') for line in log.splitlines())
assert not any('pipeline cache start' in line for line in (E/'stdout').read_text(encoding='utf-8').splitlines())
visuals = P/'preparation-status-final-visuals'
visuals.mkdir(exist_ok=False)
for mode in ['preparing', 'ready']:
    source = E/f'clean-zh-main-1600x1000-1-{mode}.png'
    with Image.open(source) as image:
        assert image.size == (1600,1000)
        image.crop((0, image.height-80, image.width, image.height)).save(visuals/(mode+'.png'))

# Verify the visual-review correction, beyond mere busy/ready differences.
a = Image.open(E/'clean-zh-main-1600x1000-1-preparing.png').convert('RGBA')
b = Image.open(E/'clean-zh-main-1600x1000-1-ready.png').convert('RGBA')
left_a = a.crop((0,980,200,1000)); left_b = b.crop((0,980,200,1000))
assert len(set(left_a.getdata())) == 1, 'default Ready still visible while preparing'
assert len(set(left_b.getdata())) > 1, 'Ready did not return after completion'
right_a = a.crop((1400,980,1600,1000)); right_b = b.crop((1400,980,1600,1000))
assert len(set(right_a.getdata())) > 1, 'preparing hint absent'
assert len(set(right_b.getdata())) == 1, 'preparing hint remained after completion'

members = {}
normal = P/'preparation-status-normal-app-v1-evidence'
normal_report = json.loads((normal/'report.json').read_text(encoding='utf-8'))
assert len(normal_report['runs']) == 8
assert len({run['pid'] for run in normal_report['runs']}) == 8
assert all(run['exit_code'] == 0 for run in normal_report['runs'])
for file in normal.rglob('*'):
    if file.is_file() and file.suffix in ['.json','.jsonl','.png','.log']:
        relative = file.relative_to(normal)
        if any(part in ['account','workspace'] for part in relative.parts): continue
        members['normal-application/'+relative.as_posix()] = file.read_bytes()
members['controller/preparation-status-runtime-identity.json'] = (P/'preparation-status-runtime-identity.json').read_bytes()
members['controller/run_current_registry_normal_app.py'] = (P/'run_current_registry_normal_app.py').read_bytes()
members['controller/template-project.json'] = (P/'frame-completion-existing-model-layer-evidence/project/project.json').read_bytes()
for name in phases:
    for suffix in ['.json','.stdout','.stderr']:
        file = P/(name+suffix)
        members['commands/'+file.name] = file.read_bytes()
for file in E.iterdir():
    if file.is_file():
        members['native/'+file.name] = file.read_bytes()
for name in ['preparation-status-native-fixture-before-resize-correction.rs',
             'preparation-status-native-fixture-audit.json',
             'preparation-status-runtime-placement.json',
             'preparation-status-style-check.json', 'preparation-status-style-check-final.json',
             'archive_preparation_status.py','archive_preparation_status_final.py','run.py']:
    members['controller/'+name] = (P/name).read_bytes()
current = json.loads((P/'preparation-status-native-v2.json').read_text(encoding='utf-8'))
for name, digest in current['source_after'].items():
    # Source receipt already carries the full tree; include actual changed
    # implementation/test files so the UI proof can be inspected offline.
    if name in ['crates/motion-host/src/session.rs',
                'crates/motion-host/src/session/pipeline_preparation.rs',
                'crates/motion-host/src/session/pipeline_preparation/tests.rs',
                'crates/motion-host/src/session/pipeline_preparation/tests/observation.rs',
                'desktop/app/src/engine.rs','desktop/app/src/main.rs',
                'desktop/app/src/engine/frame_completion/tests/native.rs',
                'desktop/app/src/engine/frame_completion/tests/native/preparation_status.rs',
                'desktop/app/src/panels/mod.rs','desktop/app/src/panels/types.rs',
                'desktop/app/src/panels/preparation_status.rs',
                'desktop/app/src/shell/presentation.rs']:
        data = (S/name).read_bytes()
        assert hashlib.sha256(data).hexdigest() == digest, name
        members['source/'+name] = data
manifest = [{'name': name, 'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()}
            for name,data in sorted(members.items())]
members['manifest.json'] = json.dumps(manifest,indent=2).encode()
archive = S/'engineering/validation/pipeline-preparation-status-final-evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in manifest:
        assert hashlib.sha256(z.read(item['name'])).hexdigest()==item['sha256']
receipt = {'archive':str(archive),'members':len(members),'bytes':archive.stat().st_size,
           'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
           'nativeCases':len(report['cases']), 'pngs':len(list(E.glob('*.png')))}
(P/'preparation-status-final-archive-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
