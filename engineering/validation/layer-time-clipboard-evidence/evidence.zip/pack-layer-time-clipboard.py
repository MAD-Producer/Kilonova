import hashlib,json,re,subprocess,zipfile
from pathlib import Path
from PIL import Image
repo=Path('E:/Dev/aem/.worktrees/layer-time-mapping')
r=Path('E:/Dev/aem/artifacts/issue-goal-current')
out=repo/'engineering/validation/layer-time-clipboard-evidence';out.mkdir(exist_ok=True)
reports={mode:json.loads((r/f'layer-time-clipboard-{mode}-third-results.json').read_text(encoding='utf-8')) for mode in ['quick','all','native']}
assert all(s['exit_code']==0 for v in reports.values() for s in v['suites'].values())
sha={v['sha256_after'] for v in reports.values()};assert len(sha)==1
passed={n for v in reports.values() for n in v['distinct_passed']}
ignored={n for v in reports.values() for n in v['distinct_ignored']}-passed
core=(r/'layer-time-clipboard-core-final.log').read_text(encoding='utf-8')
assert len(re.findall(r'test result: ok\.',core))==2 and 'test result: FAILED' not in core
coretests=re.findall(r'^test (\S+) \.\.\. ok$',core,flags=re.M);assert len(coretests)==74
for filename,mark in [('layer-time-clipboard-workspace-check.log','Finished `dev` profile'),('layer-time-clipboard-build-fourth.log','Finished `test` profile')]:
 assert mark in (r/filename).read_text(encoding='utf-8')
summary={'different_tests_passed':len(passed)+len(coretests),'desktop_passed':len(passed),'core_passed':len(coretests),'manual_not_run':len(ignored),'desktop_tests':sorted(passed),'core_tests':coretests,'manual_ignored':sorted(ignored),'program_sha256':next(iter(sha))}
(r/'layer-time-clipboard-final-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
native=r/'layer-time-clipboard-native-third'
assert len(list(native.rglob('*.png')))==20
for case in ['Masks','FlatVector','GroupVector','Effects','Audio']:
 assert (native/case/'reopened.json').exists()
for source,name,crop in [(native/'Effects/zh-main-forward-pasted.png','zh-main-pasted.png',(0,80,1000,220)),(native/'Audio/en-float-reverse-pasted.png','en-float-reverse-pasted.png',(0,0,1000,145))]:
 Image.open(source).crop(crop).save(out/name)
doc=repo/'engineering/validation/layer-time-clipboard.md';text=doc.read_text(encoding='utf-8')
text=text.replace('待写入最终结果。证据保留首轮失败，不用重跑覆盖原始输出。',f'''共 **{summary['different_tests_passed']} 个不同测试通过**（核心 {summary['core_passed']}、桌面 {summary['desktop_passed']}），
另有 {summary['manual_not_run']} 项手动测试未执行。FFmpeg / host diagnostics 桌面测试构建、
排除 Android 的工作区 all-targets check、新增模块 rustfmt、样式消费者及 diff 检查通过。
最终测试程序 SHA-256：`{summary['program_sha256']}`。
原生验收生成 20 张实际截图，核验五个工程在独立进程重开后的完整状态。
既有编译警告和机器上 Vulkan overlay 注册残留的 loader 报错保留在原始输出，
未修改系统注册表或把这些日志算作本功能修复。

[证据清单](layer-time-clipboard-evidence/manifest.json) 和
[原始证据包](layer-time-clipboard-evidence/evidence.zip) 收录最终结果和历次原始失败。
两张下图仅裁掉空白区域，原始整窗截图仍在证据包。

![中文主窗粘贴结果](layer-time-clipboard-evidence/zh-main-pasted.png)
![英文倒放浮窗粘贴结果](layer-time-clipboard-evidence/en-float-reverse-pasted.png)''')
doc.write_text(text,encoding='utf-8')
files=sorted(p for p in r.glob('layer-time-clipboard-*') if p.is_file())
for folder in sorted(p for p in r.glob('layer-time-clipboard-*') if p.is_dir()):files+=sorted(p for p in folder.rglob('*') if p.is_file())
files+=[r/'run-layer-time-clipboard.py',r/'pack-layer-time-clipboard.py']
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,p.relative_to(r).as_posix())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True,encoding='utf-8').splitlines()
changed=git('-c','core.safecrlf=false','diff','--name-only')+git('ls-files','--others','--exclude-standard')
sources={n:h(repo/n) for n in sorted(set(changed)) if (repo/n).is_file() and 'layer-time-clipboard-evidence/' not in n}
manifest={'base_commit':git('rev-parse','HEAD')[0],'branch':git('branch','--show-current')[0],'scope':'#257 precise mapped property keyframe clipboard; issue remains open','summary':summary,'program':reports['all']['program'],'sources_sha256':sources,'evidence_zip_sha256':h(out/'evidence.zip'),'raw_files':{p.relative_to(r).as_posix():h(p) for p in files},'cropped_images':{'zh-main-pasted.png':{'source':'layer-time-clipboard-native-third/Effects/zh-main-forward-pasted.png','crop':[0,80,1000,220]},'en-float-reverse-pasted.png':{'source':'layer-time-clipboard-native-third/Audio/en-float-reverse-pasted.png','crop':[0,0,1000,145]}},'limits':['Windows hidden native surfaces, real Shell/GPU/worker, synthetic input through application chrome; no OS mouse injection','No claim of complete #257 acceptance','No baseline assertion relaxed; see validation document for feature expectation and new fault-fixture corrections','Normal cancellation and supersession retain existing protocol; no timeout/retry/restart changes']}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if not isinstance(v,list)},ensure_ascii=False));print('zip bytes', (out/'evidence.zip').stat().st_size)
