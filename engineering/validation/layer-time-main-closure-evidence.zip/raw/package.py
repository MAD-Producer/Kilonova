import hashlib
import json
from pathlib import Path
import zipfile

out = Path(__file__).parent
root = Path('E:/Dev/aem')
work = root / '.worktrees/viewer-capture-errors'
audit = json.loads((out / 'closure-audit.json').read_text(encoding='utf-8'))
assert audit['native_passed'] == 1
assert audit['all_other_project_fields_exact']
members = {}
for name in ['audit.py', 'package.py', 'run.py', 'run_native.py', 'test.ps1',
             'executable-reference.json', 'native-command.json', 'native-current.json',
             'native-current.stdout', 'native-current.stderr', 'native-current-verified.json',
             'native-current-verified.stdout', 'native-current-verified.stderr',
             'pr-611.json', 'pr-613.json', 'closure-audit.json']:
    members['raw/' + name] = (out / name).read_bytes()
for path in sorted((out / 'native-current').rglob('*')):
    if path.is_file():
        members['raw/' + path.relative_to(out).as_posix()] = path.read_bytes()
media = root / 'artifacts/issue-goal-current/video-resource-retirement'
for name in ['main-ffmpeg-job.json', 'main-ffmpeg-job.log']:
    members['main/' + name] = (media / name).read_bytes()
for name in ['crates/motion-desktop-media/tests/layer_time_audio.rs',
             'crates/motion-desktop-media/tests/layer_time_frozen_export.rs',
             'crates/motion-media/tests/mapped_audio_quality/reference.rs',
             'desktop/app/src/shell/layer_time/native_tests.rs',
             'crates/motion-model/src/camera.rs', 'crates/motion-model/src/model.rs']:
    members['source/' + name] = (work / name).read_bytes()
manifest = {name: {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
            for name, data in members.items()}
members['manifest.json'] = json.dumps(manifest, indent=2).encode()
target = work / 'engineering/validation/layer-time-main-closure-evidence.zip'
assert not target.exists(), 'Never replace a published evidence archive'
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in members.items():
        z.writestr(name, data)
with zipfile.ZipFile(target) as z:
    for name, data in members.items():
        assert z.read(name) == data, name
receipt = {'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
           'bytes': target.stat().st_size, 'members': len(members)}
(out / 'package-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt))
