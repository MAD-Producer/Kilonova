import hashlib
import json
from pathlib import Path
import struct
import subprocess
import zipfile

root = Path('E:/Dev/aem')
out = Path(__file__).parent
work = root / '.worktrees/desktop-error-main'


def git_bytes(head, name):
    return subprocess.check_output(['git', 'show', head + ':' + name], cwd=root)


archive = work / 'engineering/validation/layer-time-output-evidence.zip'
archive_sha = hashlib.sha256(archive.read_bytes()).hexdigest()
assert archive_sha == 'e93da91ba521f26e5bbfafbef86de319fda0a6b0c95e621a39b3bc9d18b270e5'
head = subprocess.check_output(['git', 'rev-parse', 'origin/main'], cwd=root, text=True).strip()
media = root / 'artifacts/issue-goal-current/video-resource-retirement'
job = json.loads((media / 'main-ffmpeg-job.json').read_text(encoding='utf-8'))
assert job['conclusion'] == 'success' and job['status'] == 'completed'
job_head = job['head_sha']
checks = []
with zipfile.ZipFile(archive) as z:
    manifest = json.loads(z.read('manifest.json'))
    for name, meta in manifest['files'].items():
        data = z.read(name)
        assert len(data) == meta['bytes'], name
        assert hashlib.sha256(data).hexdigest() == meta['sha256'], name
    sources = json.loads(z.read('final-sources.json'))
    for name, sha in sources.items():
        if 'layer_time' not in name:
            continue
        data = git_bytes(head, name)
        actual = hashlib.sha256(data).hexdigest()
        record = {'path': name, 'archive_inventory_sha256': sha, 'main_git_sha256': actual}
        if name.endswith('layer_time_frozen_export.rs'):
            # The archive retains both failed and corrected new fixture versions.
            assert data == z.read('source/layer_time_frozen_export.rs'), name
            record['disposition'] = 'Final archived fixture, rather than its earlier inventory entry, exactly equals main.'
        elif name.endswith('layer_time_audio.rs'):
            assert data == git_bytes(job_head, name), name
            record['disposition'] = 'Subsequent #606 independent FIR oracle correction; exact successful main-job source.'
        else:
            assert actual == sha, name
            record['disposition'] = 'Historical tested source exactly equals current main.'
        checks.append(record)

for name in [
    'crates/motion-desktop-media/tests/layer_time_frozen_export.rs',
    'crates/motion-desktop-media/tests/layer_time_video.rs',
    'crates/motion-media/tests/mapped_audio_quality/reference.rs',
    'desktop/app/src/shell/layer_time/native_tests.rs',
]:
    data = git_bytes(head, name)
    assert data == git_bytes(job_head, name), name
    checks.append({'path': name, 'native_main_job_identical': True,
                   'sha256': hashlib.sha256(data).hexdigest()})

reference = json.loads((out / 'executable-reference.json').read_text(encoding='utf-8'))
run = json.loads((out / 'native-current-verified.json').read_text(encoding='utf-8'))
assert run['exit_code'] == 0
assert run['source_before'] == run['source_after'] == reference['source']
assert hashlib.sha256(Path(reference['path']).read_bytes()).hexdigest() == reference['sha256']
assert '1 passed; 0 failed; 0 ignored' in (out / 'native-current-verified.stdout').read_text(encoding='utf-8')
for name in ['desktop/app/src/shell/layer_time/native_tests.rs',
             'desktop/app/src/shell/layer_time.rs', 'desktop/app/src/dialogs/layer_time.rs']:
    assert hashlib.sha256(git_bytes(head, name)).hexdigest() == run['source_after'][name], name

native = out / 'native-current'
saved = json.loads((native / 'saved-project.json').read_text(encoding='utf-8'))
reopened = json.loads((native / 'reopened.json').read_text(encoding='utf-8'))
# The actual Rust test deserializes BOTH as Project and asserts exact equality.
# Its raw serde_json::Value snapshot widens f32 to f64. Compare only the known
# f32 fields by exact IEEE bits; every other field, including f64 clocks, remains
# recursively exact. This is no approximate tolerance or project-field omission.
f32_paths = {f'/background/{i}' for i in range(4)} | {
    f'/camera/position/value/{i}' for i in range(3)} | {'/camera/radius/value'}
spellings = []


def compare(a, b, path=''):
    if isinstance(a, dict) and isinstance(b, dict):
        assert a.keys() == b.keys(), path
        for key in a:
            compare(a[key], b[key], path + '/' + key)
    elif isinstance(a, list) and isinstance(b, list):
        assert len(a) == len(b), path
        for i, (left, right) in enumerate(zip(a, b)):
            compare(left, right, path + '/' + str(i))
    elif a != b:
        assert path in f32_paths, (path, a, b)
        assert struct.pack('<f', a) == struct.pack('<f', b), (path, a, b)
        spellings.append({'path': path, 'saved_json': a, 'snapshot_json': b,
                          'identical_f32_bits': struct.pack('<f', a).hex()})


compare(saved, reopened['project'])
assert reopened['history']['undoEntries'] == 0
pids = [json.loads((native / name).read_text())['pid']
        for name in ['capture-process.json', 'reopen-process.json']]
assert pids[0] != pids[1]
pngs = sorted(native.glob('*.png'))
assert len(pngs) == 9

log = (media / 'main-ffmpeg-job.log').read_text(encoding='utf-8')
test_names = [
    'frozen_movie_remapped_aac_equals_flat_authored_pcm_after_live_edits',
    'saved_reopened_frozen_png_and_movie_keep_mapped_video_clocks_after_live_edits',
    'frozen_png_matches_an_unmapped_native_source_oracle_after_live_clock_changes',
    'scene_timeline_and_native_reader_share_mapped_cfr_and_vfr_source_frames',
]
for name in test_names:
    assert name + ' ... ok' in log, name
assert 'cargo test -p motion-desktop-media --locked --features ffmpeg,gpu-tests,ai-depth' in log
for number in [611, 613]:
    pr = json.loads((out / f'pr-{number}.json').read_text(encoding='utf-8'))
    assert pr['state'] == 'MERGED'
    assert sum(item.get('conclusion') == 'SUCCESS' for item in pr['statusCheckRollup']) == 8
    subprocess.run(['git', 'merge-base', '--is-ancestor', pr['mergeCommit']['oid'], head], cwd=root, check=True)

receipt = {
    'head': head, 'native_main_head': job_head, 'native_job': job['html_url'],
    'old_archive_sha256': archive_sha, 'old_archive_verified_members': len(manifest['files']),
    'source_checks': checks, 'native_executable_sha256': reference['sha256'],
    'native_run_source': run['head'], 'native_passed': 1,
    'native_seconds': run['elapsed_seconds'], 'independent_pids': pids,
    'typed_project_equality_asserted_in_actual_native_test': True,
    'raw_json_f32_spelling_differences': spellings,
    'all_other_project_fields_exact': True,
    'screenshots': [path.name for path in pngs], 'native_main_test_names': test_names,
    'initial_native_invocation': '0 passed, 1 ignored due to a misplaced --; retained and not accepted.',
    'initial_audit': 'Raw JSON equality was rejected. Five known f32 fields differ only in JSON widening; exact original Rust Project equality passed. No product or existing test assertion changed.',
    'limits': ['Historical 83 passes are not new whole-workspace execution.',
               'Roving compensation is explicitly unsupported, not silently applied.',
               'Pitch follows speed; no pitch-preserving claim.',
               'Native input covers Windows main and 150% floating owner via real Shell/GPU input, not physical OS injection or every platform.',
               'The native FFmpeg job succeeded; its entire superseded main workflow did not complete successfully.'],
}
(out / 'closure-audit.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'verified_source_rows': len(checks), 'verified_old_members': len(manifest['files']),
                  'native_passed': 1, 'screenshots': len(pngs), 'f32_spellings': len(spellings)}))
