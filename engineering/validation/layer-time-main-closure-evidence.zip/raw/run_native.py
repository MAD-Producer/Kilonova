import hashlib
import json
import subprocess
import sys
from pathlib import Path

out = Path(__file__).parent
identity = json.loads((out / 'executable-reference.json').read_text(encoding='utf-8'))
program = Path(identity['path'])
assert hashlib.file_digest(program.open('rb'), 'sha256').hexdigest() == identity['sha256']
name = 'shell::layer_time::native_tests::layer_time_native_menus_drafts_transactions_owners_and_reopen'
command = [str(program), '--exact', name, '--ignored', '--nocapture', '--test-threads=1']
result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
(out / 'native-command.json').write_text(json.dumps({'command':command, 'exit_code':result.returncode},indent=2),encoding='utf-8')
assert result.returncode == 0
assert b'1 passed; 0 failed; 0 ignored' in result.stdout
assert hashlib.file_digest(program.open('rb'), 'sha256').hexdigest() == identity['sha256']
