from pathlib import Path
import json,subprocess,os,hashlib,sys
raw=Path(__file__).parent
kind=sys.argv[1]
records=[json.loads(line) for line in (raw/f'{kind}-build.jsonl').read_text(encoding='utf-8').splitlines() if line.startswith('{')]
name='motion-studio' if kind=='app' else 'effect_search_cache'
exe=next(r['executable'] for r in records if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name and r.get('executable'))
env=os.environ.copy(); env.pop('RUST_MIN_STACK',None)
env.update(MOTION_LOG='info',TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp',TMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp',MOTION_EFFECT_CATALOGUE_CAPTURE=str(raw/'captures'))
env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
args=[exe]+(['panels::effect_controls::'] if kind=='app' else [])+['--nocapture']
(raw/f'{kind}-executable.json').write_text(json.dumps(dict(executable=exe,sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest(),runtime_stack_override=False,command=args),indent=2),encoding='utf-8')
with (raw/f'{kind}-tests.stdout').open('w',encoding='utf-8') as out, (raw/f'{kind}-tests.stderr').open('w',encoding='utf-8') as err:
    r=subprocess.run(args,env=env,stdout=out,stderr=err)
(raw/f'{kind}-tests-exit.json').write_text(json.dumps(dict(exit=r.returncode)),encoding='utf-8')
lines=(raw/f'{kind}-tests.stdout').read_text(encoding='utf-8').splitlines()
print('\n'.join(line for line in lines if 'GPU locale' in line or 'test result:' in line or 'FAILED' in line or 'allocations' in line))
print((raw/f'{kind}-tests.stderr').read_text(encoding='utf-8')[-1500:])
raise SystemExit(r.returncode)
