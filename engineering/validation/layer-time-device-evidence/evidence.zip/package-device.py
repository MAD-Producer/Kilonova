import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

repo = Path('E:/Dev/aem/.worktrees/layer-time-mapping')
raw = Path('E:/Dev/aem/artifacts/issue-goal-current/spatial-free/ci')
dest = repo / 'engineering/validation/layer-time-device-evidence'
dest.mkdir(parents=True, exist_ok=True)

def digest(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def read(path):
    data = path.read_bytes()
    return data.decode('utf-16' if data.startswith(b'\xff\xfe') else 'utf-8-sig')

def outcome(name, exit_name=None):
    text = read(raw / name)
    found = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored', text)
    result = {'log': name, 'sha256': digest(raw / name)['sha256']}
    if exit_name:
        result['exitCode'] = int(read(raw / exit_name).strip()) if (raw / exit_name).exists() else None
    if found:
        state, passed, failed, ignored = found[-1]
        result.update(status=state, passed=int(passed), failed=int(failed), ignored=int(ignored))
    else:
        result['status'] = 'no_terminal_result_verified'
    return result

sources = [
    '.github/workflows/ci.yml',
    'desktop/app/src/audio_output.rs',
    'desktop/app/src/audio_output/mapped_device_tests.rs',
    'desktop/app/src/audio_output/producer_observation/tests.rs',
]
report = json.loads((raw / 'mapped-device-report.json').read_text())
assert len(report) == 6
assert all(item['deviceRate'] == 48000 and item['submittedFrames'] == 24000
           and item['finalFrame'] == 15.0 and item['underruns'] == 0 for item in report)
results = {
    'hardware': outcome('mapped-device-first.log'),
    'audio_output': outcome('audio-output-final.log', 'audio-output-final.exit'),
    'graph_ranges': outcome('graph-ranges-final.log', 'graph-ranges-final.exit'),
}
assert results['hardware']['status'] == 'ok'
assert results['audio_output']['exitCode'] == 0
files = ['linux-job.log', 'workflow-tests.log', 'workflow-tests-configured.log',
         'real-device-first.log', 'real-device-configured.log', 'mapped-device-build.log',
         'mapped-device-build.exit', 'mapped-device-first.log', 'mapped-device-report.json',
         'audio-output-final.log', 'audio-output-final.exit', 'graph-ranges-final.log']
if (raw / 'graph-ranges-final.exit').exists(): files.append('graph-ranges-final.exit')
with zipfile.ZipFile(dest / 'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for name in files: z.write(raw / name, 'raw/' + name)
    for name in sources: z.write(repo / name, 'source/' + name)
    z.write(__file__, 'package-device.py')
binary = Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-b34b3a7e7eb835e8.exe')
manifest = {
    'createdUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'issue': 257, 'pr': 579, 'branch': 'feat/layer-time-mapping',
    'parent': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'scope': 'Windows actual audio device acceptance; issue remains open',
    'binary': {'path': str(binary), **digest(binary)},
    'source': {name: digest(repo / name) for name in sources},
    'results': results, 'deviceReport': report,
    'commands': {
        'build': 'cargo test -p motion-desktop --bin motion-studio --features ffmpeg,motion-host/diagnostics --no-run --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target',
        'hardware': '<binary> --exact audio_output::mapped_device_tests::mapped_audio_reaches_the_real_device_for_stretch_reverse_freeze_turn_and_nested_fps --ignored --test-threads=1 --nocapture',
        'regression': '<binary> audio_output:: --test-threads=1',
        'graph_ranges': '<binary> panels::graph_ranges:: --test-threads=1',
        'environment': {'TEMP': 'E:/Dev/aem/artifacts/pr-integration-current/link-tmp', 'MOTION_LOG': 'unset (default info)', 'FFMPEG_DIR': 'existing pinned FFmpeg 8.1 runtime'},
    },
    'ciFailure': 'https://github.com/MAD-Producer/Kilonova/actions/runs/41410961603/job/125163671849',
    'ciFixValidation': {'workflowPolicyTests': 14, 'actionlint': 'passed; shellcheck not run locally', 'actualRunner': 'pending next CI'},
    'limits': ['No physical speaker loopback recording', 'Slow-device peak is not an independent source-index oracle',
               'No high-speed adaptive low-pass acceptance', 'Other operating systems and hardware unverified'],
    'archive': digest(dest / 'evidence.zip'),
}
(dest / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(results, ensure_ascii=False, indent=2))
