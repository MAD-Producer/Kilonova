import hashlib,json,os,subprocess,sys
from pathlib import Path
out=Path(__file__).parent;stage=sys.argv[1]
rows=[json.loads(l) for l in (out/'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH'];env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
names=['wheel_pan_and_minimap_changes_project_existing_metadata_once','initial_pointer_batch_and_normal_release_reuse_metadata_but_identity_restoration_rebuilds','record_complete_navigation_and_release_paint_for_original_path_comparison']
receipts=[]
for index,name in enumerate(names):
 local=env.copy()
 if index==2:local['MOTION_NODE_VIEWPORT_EVIDENCE']=str(out/(stage+'-paint.json'))
 command=[exe,'--exact','node_editor::view::frame_cards_tests::viewport_geometry::'+name,'--test-threads=1','--nocapture']
 r=subprocess.run(command,env=local,capture_output=True);(out/(stage+'-'+str(index)+'.stdout')).write_bytes(r.stdout);(out/(stage+'-'+str(index)+'.stderr')).write_bytes(r.stderr)
 receipts.append({'command':command,'exit':r.returncode,'expected_exit':101 if stage=='before' and index<2 else 0,'executable_sha256':hashlib.sha256(Path(exe).read_bytes()).hexdigest()})
 print(json.dumps(receipts[-1]),flush=True)
(out/(stage+'-tests.json')).write_text(json.dumps(receipts,indent=2),'utf-8')
assert all(r['exit']==r['expected_exit'] for r in receipts)
