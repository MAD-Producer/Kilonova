import json
from pathlib import Path
from github_api import request
p=Path(__file__).parent
prs=request('repos/MAD-Producer/Kilonova/pulls?state=open&per_page=100')
rows=[]
for pr in prs:
 if pr['number'] in [602,603]:continue
 files=[];page=1
 while True:
  part=request(f"repos/MAD-Producer/Kilonova/pulls/{pr['number']}/files?per_page=100&page={page}")
  files.extend(row['filename'] for row in part)
  if len(part)<100:break
  page+=1
 overlap=[f for f in files if f=='desktop/ui/src/dock.rs' or f.startswith('desktop/ui/src/dock/')]
 rows.append(dict(pr=pr['number'],head=pr['head']['sha'],files=files,overlap=overlap))
 print(json.dumps(dict(pr=pr['number'],files=len(files),overlap=overlap)),flush=True)
(p/'preflight.json').write_text(json.dumps(rows,indent=2),'utf-8')
assert not any(row['overlap'] for row in rows)
