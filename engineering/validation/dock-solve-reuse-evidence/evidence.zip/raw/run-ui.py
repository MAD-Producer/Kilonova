import hashlib,json,os,subprocess,sys
from pathlib import Path
p=Path(__file__).parent;stage=sys.argv[1]
rows=[json.loads(l) for l in (p/'ui-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
assert rows[-1]==dict(reason='build-finished',success=True)
exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion_ui' and r.get('executable')][-1]
env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
command=[exe,'dock::solve_cache_tests::','--test-threads=1','--nocapture']
r=subprocess.run(command,env=env,capture_output=True)
(p/(stage+'.stdout')).write_bytes(r.stdout);(p/(stage+'.stderr')).write_bytes(r.stderr)
receipt=dict(command=command,exit=r.returncode,executable_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest(),expected_exit=101 if stage=='before' else 0)
(p/(stage+'.json')).write_text(json.dumps(receipt,indent=2),'utf-8')
print(r.stdout.decode('utf-8',errors='replace')[-2200:]);print(r.stderr.decode('utf-8',errors='replace')[-2000:]);print(json.dumps(receipt))
assert r.returncode==receipt['expected_exit']
