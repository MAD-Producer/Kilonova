import hashlib,json,re,subprocess,zipfile
from pathlib import Path
raw=Path(__file__).parent;root=Path.cwd();base='9ae6b16b75f0b67b99b6c48b4ab13639735b9046'
out=root/'engineering/validation/dock-solve-reuse-evidence';out.mkdir(exist_ok=True)
def digest(data):return hashlib.sha256(data).hexdigest()
def git(*args,input=None):return subprocess.check_output(['git',*args],input=input)
source_paths=['desktop/ui/src/dock.rs','desktop/ui/src/dock/solve_cache.rs','desktop/ui/src/dock/solve_cache_tests.rs','desktop/app/src/panels/mod.rs','desktop/app/src/panels/workload_tests.rs']
sources={path:(root/path).read_bytes() for path in source_paths}
old=Path('E:/Dev/aem/artifacts/issue-goal-current/node-viewport-geometry/before-paint.json')
assert json.loads(old.read_text('utf-8'))==json.loads((raw/'final-paint.json').read_text('utf-8'))
counts=[]
for index in range(4):
 text=(raw/f'regression-{index}.stdout').read_text('utf-8');match=re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',text);assert match;counts.append(int(match[1]))
assert counts==[186,4,13,7]
assert '76 passed; 0 failed; 15 ignored;' in (raw/'ui-all.stdout').read_text('utf-8')
assert '6 passed; 0 failed; 0 ignored;' in (raw/'integration.stdout').read_text('utf-8')
for file in ['costs.json','layouts.json']:assert len(json.loads((raw/file).read_text('utf-8')))==48
summary=dict(base=base,tests_passed=294,gpu_tests_not_run=15,ui_cpu_passed=76,dock_constraints_passed=6,desktop_distinct_passed=212,geometry_comparisons=390,complete_paint_state_frames=312,before_paint_sha256=digest(old.read_bytes()),final_paint_sha256=digest((raw/'final-paint.json').read_bytes()),source_sha256={path:digest(data) for path,data in sources.items()},source_git_blobs={path:git('hash-object','--path='+path,'--stdin',input=data).decode().strip() for path,data in sources.items()})
(raw/'summary.json').write_text(json.dumps(summary,indent=2),'utf-8')
records=[]
for file in sorted(raw.iterdir()):
 if file.is_file() and file.suffix in ['.json','.jsonl','.stdout','.stderr','.ps1','.py'] and not file.name.startswith(('github_api','merge602','publish','setup-publication')):
  records.append(('raw/'+file.name,file.read_bytes()))
for path,data in sources.items():records.append(('final-source/'+path,data))
records.append(('baseline/before-paint.json',old.read_bytes()))
records.append(('baseline/dock.rs',git('show',base+':desktop/ui/src/dock.rs')))
records.append(('README.txt',b'Baseline is PR #603 head 9ae6b16b before the low-level cache. The baseline test binary adds the actual-root counter and five new unit tests; three actual negative controls fail. Final tests compare public solve to independent original solve_into recursion. Source hashes identify actual compiler input bytes; source_git_blobs identify normalized repository blobs. Old panel solves counters are frame construction counters, renamed without changing expected values. 15 GPU tests retain their existing feature-dependent ignore attributes; they were not run in this local CPU suite. No Native Present, physical input, universal one-solve-per-frame or whole-frame timing/peak-memory claim.\n'))
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in records:z.writestr(name,data)
manifest=dict(**summary,archive_sha256=digest(archive.read_bytes()),records=[dict(path=name,bytes=len(data),sha256=digest(data)) for name,data in records])
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n','utf-8')
with zipfile.ZipFile(archive) as z:
 for row in manifest['records']:assert digest(z.read(row['path']))==row['sha256']
print(json.dumps(dict(tests=294,geometry=390,frames=312,records=len(records),zip_bytes=archive.stat().st_size,archive_sha256=manifest['archive_sha256'])))
