import hashlib,json,os,subprocess
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(l) for l in (p/'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH'];env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
receipts=[]
for name,key,file in [('complete_shell_drag_frames_match_static_work_and_solve_once_for_each_stable_layout','MOTION_WORKSPACE_COST_EVIDENCE','costs.json'),('real_presets_resize_maximize_and_tab_changes_invalidate_once_without_stale_geometry','MOTION_LAYOUT_COST_EVIDENCE','layouts.json')]:
 local=env.copy();local[key]=str(p/file)
 command=[exe,'--exact','panels::workload_tests::'+name,'--test-threads=1','--nocapture']
 r=subprocess.run(command,env=local,capture_output=True);(p/(file+'.stdout')).write_bytes(r.stdout);(p/(file+'.stderr')).write_bytes(r.stderr)
 receipts.append(dict(command=command,exit=r.returncode,executable_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest()))
 print(r.stdout.decode('utf-8',errors='replace')[-700:],flush=True)
 print(r.stderr.decode('utf-8',errors='replace')[-700:],flush=True)
(p/'workspace-tests.json').write_text(json.dumps(receipts,indent=2),'utf-8')
assert all(r['exit']==0 for r in receipts)
