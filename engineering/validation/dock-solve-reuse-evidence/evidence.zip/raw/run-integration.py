import hashlib,json,os,subprocess
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(l) for l in (p/'integration-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
assert rows[-1]==dict(reason='build-finished',success=True)
exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='dock_constraints' and r.get('executable')][-1]
env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
command=[exe,'--test-threads=1','--nocapture'];r=subprocess.run(command,env=env,capture_output=True)
(p/'integration.stdout').write_bytes(r.stdout);(p/'integration.stderr').write_bytes(r.stderr)
(p/'integration.json').write_text(json.dumps(dict(command=command,exit=r.returncode,executable_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest()),indent=2),'utf-8')
print(r.stdout.decode('utf-8',errors='replace')[-1800:]);print(r.stderr.decode('utf-8',errors='replace')[-700:]);assert r.returncode==0
