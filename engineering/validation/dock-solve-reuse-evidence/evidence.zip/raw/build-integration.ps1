. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:RUST_MIN_STACK='33554432'
cargo test -p motion-ui --test dock_constraints --no-default-features --no-run --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --config profile.test.package.motion-render.debug=0 --config profile.test.package.motion-model.debug=0 --config profile.test.package.motion-host.debug=0 --config profile.test.package.motion-core.debug=0 --config profile.test.package.motion-media.debug=0 --config profile.test.package.motion-scene.debug=0 --config profile.test.package.motion-effects.debug=0 --config profile.test.package.motion-ui.debug=0 --config profile.test.package.motion-desktop-media.debug=0 --config profile.test.package.motion-graph.debug=0 --message-format=json 1> E:/Dev/aem/artifacts/issue-goal-current/dock-solve-reuse/integration-build.jsonl 2> E:/Dev/aem/artifacts/issue-goal-current/dock-solve-reuse/integration-build.stderr
exit $LASTEXITCODE
