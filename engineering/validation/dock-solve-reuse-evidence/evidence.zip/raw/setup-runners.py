from pathlib import Path
p=Path(__file__).parent
previous=Path('E:/Dev/aem/artifacts/issue-goal-current/node-viewport-geometry')
for name in ['build-app.ps1','build-production.ps1','run-probe.py','run-regressions.py','run-workspace.py','check-startup.py']:
 s=(previous/name).read_text('utf-8')
 s=s.replace('issue-goal-current/node-viewport-geometry','issue-goal-current/dock-solve-reuse')
 (p/name).write_text(s,'utf-8')
