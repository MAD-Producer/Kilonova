import hashlib,json,os,subprocess
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(l) for l in (p/'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')];exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH'];env['TEMP']=env['TMP']='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
filters=['node_editor::','panels::frame_cache_tests::','panels::tests::','shell::presentation::interaction_tests::']
results=[]
for index,name in enumerate(filters):
 command=[exe,name,'--test-threads=1','--nocapture'];r=subprocess.run(command,env=env,capture_output=True);prefix='regression-'+str(index);(p/(prefix+'.stdout')).write_bytes(r.stdout);(p/(prefix+'.stderr')).write_bytes(r.stderr);results.append({'filter':name,'command':command,'exit':r.returncode});print(r.stdout.decode('utf-8',errors='replace')[-1000:],flush=True);print(r.stderr.decode('utf-8',errors='replace')[-600:],flush=True);assert r.returncode==0
(p/'regression.json').write_text(json.dumps({'executable_sha256':hashlib.sha256(Path(exe).read_bytes()).hexdigest(),'results':results},indent=2),'utf-8')

