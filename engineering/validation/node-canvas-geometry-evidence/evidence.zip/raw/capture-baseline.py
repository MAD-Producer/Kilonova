import hashlib, json, shutil, subprocess
from pathlib import Path
p = Path(__file__).parent
root = Path.cwd()
base = 'bda11de0cdcbc8b44f72dd5e9b801b207d4e2851'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == base
paths = ['desktop/app/src/node_editor/view/' + name for name in
    ['mod.rs', 'interaction.rs', 'frame_cards_tests.rs', 'frame_cards_tests/canvas_geometry.rs']]
hashes = {}
for path in paths:
    data = (root / path).read_bytes()
    dest = p / 'before-source' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    hashes[path] = hashlib.sha256(data).hexdigest()
    if path.endswith(('/mod.rs', '/interaction.rs')):
        assert subprocess.check_output(['git', 'show', base + ':' + path]) == data
(p / 'before-source.json').write_text(json.dumps(hashes, indent=2), 'utf-8')
for suffix in ['jsonl', 'stderr']:
    shutil.copyfile(p / ('app-build.' + suffix), p / ('before-build.' + suffix))
print(json.dumps(hashes))
