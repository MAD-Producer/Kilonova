import ast, hashlib, json, os, re, subprocess, sys
from pathlib import Path

p = Path(__file__).parent
stage = sys.argv[1]
rows = [json.loads(l) for l in (p / 'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
assert rows[-1] == dict(reason='build-finished', success=True)
exe = [r['executable'] for r in rows if r.get('reason') == 'compiler-artifact' and r['target']['name'] == 'motion-studio' and r.get('executable')][-1]
env = os.environ.copy()
env.pop('RUST_MIN_STACK', None)
env['MOTION_LOG'] = 'info'
env['PATH'] = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;' + env['PATH']
receipts = []
for i, name in enumerate(['connection_and_preview_frames_resolve_card_ports_once_without_changing_transactions',
                           'record_complete_canvas_transactions_for_original_path_comparison']):
    local = env.copy()
    if i == 1:
        local['MOTION_NODE_CANVAS_EVIDENCE'] = str(p / (stage + '-paint.json'))
    command = [exe, '--exact', 'node_editor::view::frame_cards_tests::canvas_geometry::' + name, '--test-threads=1', '--nocapture']
    r = subprocess.run(command, env=local, capture_output=True)
    (p / f'{stage}-{i}.stdout').write_bytes(r.stdout)
    (p / f'{stage}-{i}.stderr').write_bytes(r.stderr)
    receipts.append(dict(command=command, exit=r.returncode, expected_exit=101 if stage == 'before' and i == 0 else 0,
                         executable_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest()))
    print(json.dumps(receipts[-1]), flush=True)
(p / (stage + '-tests.json')).write_text(json.dumps(receipts, indent=2), 'utf-8')
assert all(r['exit'] == r['expected_exit'] for r in receipts)
if stage == 'before':
    output = (p / 'before-0.stderr').read_text('utf-8')
    match = re.search(r'one final card build for connection and preview edits: (\[.*\])', output)
    assert match, 'fixture assertion failures are not performance negative controls'
    counts = ast.literal_eval(match[1])
    assert len(counts) == 448 and all(ports == builds * nodes for _, builds, ports, nodes in counts)
    changed = [r for r in counts if r[0].endswith(tuple('-' + case + '-release' for case in ['Connect', 'Rewire', 'Disconnect', 'Cut']) + ('-Preview-press', '-RestorePreview-press'))]
    assert len(changed) == 48 and all(r[1] == 2 for r in changed)
    (p / 'before-counts.json').write_text(json.dumps(counts, indent=2), 'utf-8')
else:
    before = json.loads((p / 'before-paint.json').read_text('utf-8'))
    final = json.loads((p / 'final-paint.json').read_text('utf-8'))
    assert len(before) == len(final) == 448
    assert before == final
    (p / 'canvas-comparison.json').write_text(json.dumps(dict(frames=448, exact_equal=True, normalization=False,
        before_sha256=hashlib.sha256((p / 'before-paint.json').read_bytes()).hexdigest(),
        final_sha256=hashlib.sha256((p / 'final-paint.json').read_bytes()).hexdigest()), indent=2), 'utf-8')

