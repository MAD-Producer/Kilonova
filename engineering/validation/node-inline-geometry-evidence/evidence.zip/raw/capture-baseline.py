import hashlib,json,shutil
from pathlib import Path

p=Path(__file__).parent;root=Path.cwd()
counts=json.loads((p/'before-counts.json').read_text('utf-8'))
assert len(counts)==744
paths=['desktop/app/src/node_editor/view/'+name for name in ['mod.rs','controls.rs','frame_cards_tests.rs','frame_cards_tests/inline_geometry.rs']]
sources={}
for path in paths:
    data=(root/path).read_bytes();target=p/'before-source'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    sources[path]=hashlib.sha256(data).hexdigest()
(p/'before-source.json').write_text(json.dumps(sources,indent=2),'utf-8')
for name in ['app-build.jsonl','app-build.stderr']:shutil.copyfile(p/name,p/name.replace('app-','before-'))
print(json.dumps(dict(negative_count_records=len(counts),sources=sources)))
