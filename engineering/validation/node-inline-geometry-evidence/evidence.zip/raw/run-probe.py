import ast,hashlib,json,os,re,subprocess,sys
from pathlib import Path
p=Path(__file__).parent;stage=sys.argv[1]
rows=[json.loads(l) for l in (p/'app-build.jsonl').read_text('utf-8-sig').splitlines() if l.startswith('{')]
assert rows[-1]==dict(reason='build-finished',success=True)
exe=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='motion-studio' and r.get('executable')][-1]
env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env['MOTION_LOG']='info';env['PATH']='E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin;'+env['PATH']
receipts=[]
for i,name in enumerate(['inline_value_edits_build_final_cards_once_without_changing_transactions','record_complete_inline_transactions_for_original_path_comparison']):
    local=env.copy()
    if i==1:local['MOTION_NODE_INLINE_EVIDENCE']=str(p/(stage+'-paint.json'))
    command=[exe,'--exact','node_editor::view::frame_cards_tests::inline_geometry::'+name,'--test-threads=1','--nocapture']
    r=subprocess.run(command,env=local,capture_output=True)
    (p/f'{stage}-{i}.stdout').write_bytes(r.stdout);(p/f'{stage}-{i}.stderr').write_bytes(r.stderr)
    receipts.append(dict(command=command,exit=r.returncode,expected_exit=101 if stage=='before' and i==0 else 0,executable_sha256=hashlib.sha256(Path(exe).read_bytes()).hexdigest()))
    print(json.dumps(receipts[-1]),flush=True)
(p/(stage+'-tests.json')).write_text(json.dumps(receipts,indent=2),'utf-8')
assert all(r['exit']==r['expected_exit'] for r in receipts)
if stage=='before':
    text=(p/'before-0.stderr').read_text('utf-8')
    match=re.search(r'one final card build for inline edits: (\[.*\])',text)
    assert match,'fixture failure is not a performance negative control'
    counts=ast.literal_eval(match[1])
    assert len(counts)==744 and all(resolutions==builds*nodes for _,builds,resolutions,nodes in counts)
    changes=[r for r in counts if r[0].endswith(('-move1','-move2','-Text-save'))]
    assert len(changes)==168 and all(r[1]==2 for r in changes)
    (p/'before-counts.json').write_text(json.dumps(counts,indent=2),'utf-8')
