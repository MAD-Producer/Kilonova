from pathlib import Path
import hashlib, json, re, subprocess, zipfile

root = Path('E:/Dev/aem/.worktrees/layer-time-mapping')
raw = Path('E:/Dev/aem/artifacts/issue-goal-current')
out = root / 'engineering/validation/ui-contracts-current-evidence'
out.mkdir(exist_ok=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
groups = {'ui-input-contracts': 29, 'ui-remaining-contracts': 36, 'ui-atlas-bounds': 9}
members, receipts = {}, {}
for group, expected in groups.items():
    directory = raw / group
    assert json.loads((directory/'result.json').read_text(encoding='utf-8-sig'))['exit'] == 0
    output = (directory/'tests.stdout').read_text(encoding='utf-8-sig')
    summaries = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', output)
    assert sum(int(s[0]) for s in summaries) == expected
    assert all(s[1:] == ('0', '0') for s in summaries)
    executables = []
    for line in output.splitlines():
        try: item = json.loads(line)
        except ValueError: continue
        if item.get('reason') == 'compiler-artifact' and item.get('executable'):
            path = Path(item['executable'])
            executables.append({'path': str(path), 'sha256': sha(path), 'profile': item['profile']})
    receipts[group] = {'passed': expected, 'failed': 0, 'ignored': 0, 'summaries': summaries, 'executables': executables}
    for p in directory.iterdir():
        if p.is_file(): members[group+'/'+p.name] = p
sources = ['desktop/ui/tests/'+name+'.rs' for name in ['atlas_bounds', 'borrowed_input', 'failure_boundaries', 'framework', 'input_ownership', 'text_bounds', 'paint_clip_buffers', 'icon_geometry', 'dock_constraints', 'grapheme_editing', 'diamond_bounds', 'tabs']]
sources += [p.relative_to(root).as_posix() for p in (root/'desktop/ui/src').rglob('*') if p.is_file()]
sources += [p.relative_to(root).as_posix() for p in (root/'desktop/ui/tests/text_bounds').rglob('*') if p.is_file()]
for source in sources: members['source/'+source] = root/source
receipt = {'head': git('rev-parse', 'HEAD'), 'ui_source_tree': git('rev-parse', 'HEAD:desktop/ui/src'), 'production_source_diff_empty': not git('diff', '85ae6868', '--', 'crates', 'desktop/app', 'desktop/ui/src', 'Cargo.toml', 'Cargo.lock'), 'unique_tests': 74, 'groups': receipts, 'source_sha256': {s: sha(root/s) for s in sources}, 'limits': ['standard Cargo test profile, not release', 'RUST_MIN_STACK=33554432 in the recorded test environment', 'warmed allocation scope only', 'no complex-script shaping proof', 'no custom stylesheet tab proof', 'offscreen GPU is not a physical display test']}
assert receipt['production_source_diff_empty']
receipt_path = raw/'ui-contracts-source-receipt.json'
receipt_path.write_text(json.dumps(receipt, indent=2), encoding='utf-8')
members['source-receipt.json'] = receipt_path
members['archive.py'] = Path(__file__)
manifest = {name: {'sha256': sha(p), 'bytes': p.stat().st_size} for name,p in members.items()}
with zipfile.ZipFile(out/'evidence.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for name,p in members.items(): z.write(p,name)
with zipfile.ZipFile(out/'evidence.zip') as z:
    assert set(z.namelist()) == set(manifest)
    for name,value in manifest.items(): assert hashlib.sha256(z.read(name)).hexdigest() == value['sha256']
(out/'manifest.json').write_text(json.dumps({'archive_sha256': sha(out/'evidence.zip'), 'members': manifest}, indent=2), encoding='utf-8')
print(json.dumps({'unique_tests':74,'members':len(manifest),'zip_bytes':(out/'evidence.zip').stat().st_size}))
