. E:/Dev/aem/.tools/msvc-portable/env.ps1
$env:TEMP='E:/Dev/aem/artifacts/pr-integration-current/link-tmp'
$env:TMP=$env:TEMP
$env:CARGO_BUILD_JOBS='1'
$env:CARGO_INCREMENTAL='0'
$env:RUST_MIN_STACK='33554432'
$env:MOTION_LOG='info'
$auditDir='E:/Dev/aem/artifacts/issue-goal-current/ui-input-contracts'
git rev-parse HEAD > "$auditDir/source-head.txt"
cargo test -p motion-ui --test input_ownership --test borrowed_input --test failure_boundaries --test framework --locked --target-dir E:/Dev/aem/.tools/viewer-inspection/native-target --message-format=json -- --test-threads=1 --nocapture 1> "$auditDir/tests.stdout" 2> "$auditDir/tests.stderr"
$testExit=$LASTEXITCODE
@{exit=$testExit;completed=(Get-Date).ToString('o')} | ConvertTo-Json > "$auditDir/result.json"
exit $testExit
