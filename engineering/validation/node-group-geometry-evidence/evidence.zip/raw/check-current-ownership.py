import json, subprocess
from pathlib import Path

raw = Path(__file__).parent
repo = 'repos/MAD-Producer/Kilonova/'
def request(path):
    result = subprocess.run(['gh', 'api', repo + path], capture_output=True)
    if result.returncode:
        (raw / 'ownership-api-error.stderr').write_bytes(result.stderr)
        raise RuntimeError(f'GitHub read failed for {path}; original stderr retained')
    return json.loads(result.stdout)

main = request('commits/main')['sha']
tree = next(x['sha'] for x in request('contents/desktop/app/src/node_editor?ref=' + main) if x['name'] == 'view')
rows = []
for pr in request('pulls?state=open&per_page=100'):
    if pr['number'] == 604:
        continue
    files = []
    page = 1
    while True:
        part = request(f'pulls/{pr["number"]}/files?per_page=100&page={page}')
        files += [x['filename'] for x in part]
        if len(part) < 100:
            break
        page += 1
    overlap = [f for f in files if f.startswith('desktop/app/src/node_editor/')]
    row = dict(pr=pr['number'], head=pr['head']['sha'], files=files, overlap=overlap)
    if overlap:
        other = next(x['sha'] for x in request('contents/desktop/app/src/node_editor?ref=' + pr['head']['sha']) if x['name'] == 'view')
        row.update(view_tree=other, matches_current_main=other == tree)
    rows.append(row)
    print(json.dumps({k:v for k,v in row.items() if k != 'files'}), flush=True)
assert all(not r['overlap'] or r.get('matches_current_main') for r in rows)
(raw / 'current-ownership.json').write_text(json.dumps(dict(main=main, main_view_tree=tree, prs=rows), indent=2), 'utf-8')
