import hashlib, json, os, subprocess
from pathlib import Path
out = Path(__file__).parent
executable = Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps/motion_studio-a9ea002b22e1a2a1.exe')
runtime = 'E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin'
results = []
for mode, path in [('forward', runtime), ('native', runtime.replace('/', '\\'))]:
    env = dict(os.environ, PATH=path + os.pathsep + os.environ['PATH'])
    result = subprocess.run([str(executable), '--list'], capture_output=True, env=env, timeout=45)
    for stream in ['stdout', 'stderr']:
        (out / f'cache-worker-dll-{mode}.{stream}').write_bytes(getattr(result, stream))
    results.append({'mode': mode, 'runtime_path': path, 'command': [str(executable), '--list'],
        'exit_code': result.returncode, 'stdout_bytes': len(result.stdout), 'stderr_bytes': len(result.stderr)})
with executable.open('rb') as stream:
    digest = hashlib.file_digest(stream, 'sha256').hexdigest()
(out / 'cache-worker-dll-probe.json').write_text(json.dumps({'executable_sha256': digest,
    'runtime_dlls': {p.name: p.stat().st_size for p in Path(runtime).glob('*.dll')}, 'results': results}, indent=2), encoding='utf-8')
print(json.dumps(results))
