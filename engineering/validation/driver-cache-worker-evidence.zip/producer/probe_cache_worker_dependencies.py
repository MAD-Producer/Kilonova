import ctypes, json, os, subprocess
from pathlib import Path
out = Path(__file__).parent
runtime = Path('E:/Dev/aem/.tools/ffmpeg-dev/ffmpeg-n8.1-latest-win64-lgpl-shared-8.1/bin')
results = []
with os.add_dll_directory(str(runtime)):
    for name in ['avutil-60.dll', 'swresample-6.dll', 'avcodec-62.dll', 'avformat-62.dll', 'swscale-9.dll']:
        try:
            library = ctypes.WinDLL(str(runtime / name))
            results.append({'name': name, 'loaded': bool(library._handle)})
        except OSError as error:
            results.append({'name': name, 'error': str(error), 'winerror': error.winerror})
(out / 'cache-worker-dependencies.json').write_text(json.dumps({'loads': results}, indent=2), encoding='utf-8')
print(json.dumps(results))
