import hashlib, json, re, subprocess
from pathlib import Path
root = Path.cwd()
out = Path(__file__).parent
baseline = '284c6b0dd259f2163a43629bc6b842a39fb419ab'
records = []
paths = set()
for phase in ['cache-worker-render-tests', 'cache-worker-render-corrected',
              'cache-worker-preparation-regression', 'cache-worker-desktop-default-log',
              'cache-worker-desktop-runtime-fixed', 'cache-worker-all-targets']:
    record = json.loads((out / (phase + '.json')).read_text(encoding='utf-8'))
    assert 'exit_code' in record and record['source_before'] == record['source_after'], phase
    records.append({'phase': phase, 'exit_code': record['exit_code'],
                    'elapsed_seconds': record['elapsed_seconds'], 'source_files': len(record['source_before'])})
    text = (out / (phase + '.stderr')).read_text(encoding='utf-8', errors='replace')
    for block in re.split(r'(?m)^(?=warning:|error:)', text):
        if block.startswith('warning:'):
            paths.update(path.replace('\\', '/') for path in re.findall(r'-->\s+((?:crates|desktop)[^:\n]+):\d+:\d+', block))
warnings = []
for name in sorted(paths):
    previous = subprocess.check_output(['git', 'show', baseline + ':' + name])
    current = (root / name).read_bytes()
    warnings.append({'path': name, 'unchanged_from_baseline': current.replace(b'\r\n', b'\n') == previous.replace(b'\r\n', b'\n')})
warning_sites = warnings
result = {'baseline': baseline, 'records': records, 'compiler_locations': warnings,
    'warning_locations_excluding_initial_fixture_error': warning_sites,
    'all_warning_files_unchanged': all(entry['unchanged_from_baseline'] for entry in warning_sites),
    'limits': 'compiler locations within warning blocks only; not a claim that repository warnings were fixed'}
(out / 'cache-worker-warning-scope.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({'records': records, 'warning_files': len(warning_sites),
    'all_warning_files_unchanged': result['all_warning_files_unchanged']}))
