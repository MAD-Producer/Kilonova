"""Preserve actual cache-worker command outputs, including the initial failure."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path.cwd()
out = Path(__file__).parent
baseline = '284c6b0dd259f2163a43629bc6b842a39fb419ab'
target = root / 'engineering/validation/driver-cache-worker-evidence.zip'
assert not target.exists(), 'evidence must never be overwritten'
phases = ['cache-worker-render-tests', 'cache-worker-render-corrected',
          'cache-worker-preparation-regression', 'cache-worker-desktop-default-log',
          'cache-worker-desktop-runtime-fixed',
          'cache-worker-all-targets']
members = {}
reports = []
for phase in phases:
    record = json.loads((out / (phase + '.json')).read_text(encoding='utf-8'))
    assert 'exit_code' in record, phase + ' is not terminal'
    assert record['source_before'] == record['source_after'], phase + ' source changed'
    reports.append({key: record[key] for key in ['command', 'exit_code', 'elapsed_seconds']}
                   | {'phase': phase, 'source_unchanged': True,
                      'source_files': len(record['source_before'])})
    for suffix in ['.json', '.stdout', '.stderr']:
        path = out / (phase + suffix)
        members['commands/' + path.name] = path.read_bytes()

names = subprocess.check_output(['git', 'diff', '--name-only', baseline, '--', 'crates', 'desktop'], text=True).splitlines()
names += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', 'crates', 'desktop'], text=True).splitlines()
for name in sorted(set(names)):
    members['source/current/' + name] = (root / name).read_bytes()
    original = subprocess.run(['git', 'show', baseline + ':' + name], capture_output=True)
    if original.returncode == 0:
        members['source/baseline/' + name] = original.stdout

# Recover and verify the exact initial failing fixture, rather than treating
# the corrected source as the source of both commands.
fixture = 'crates/motion-render/src/driver_pipeline_cache/tasks/tests.rs'
before = members['source/current/' + fixture].replace(
    b'let mut state = TaskState::default();\n    state.next_request = u64::MAX - 1;',
    b'let mut state = TaskState {\n        next_request: u64::MAX - 1,\n        ..Default::default()\n    };', 1)
failed = json.loads((out / 'cache-worker-render-tests.json').read_text(encoding='utf-8'))
assert hashlib.sha256(before).hexdigest() == failed['source_before'][fixture]
members['source/initial-failed/' + fixture] = before

for directory in ['cache-worker-native-evidence', 'cache-worker-desktop-evidence']:
    for path in sorted((out / directory).rglob('*')):
        if path.is_file() and path.name != 'recovered-cache':
            members['native/' + path.relative_to(out).as_posix()] = path.read_bytes()
for name in ['run.py', 'collect_cache_worker_evidence.py', 'probe_cache_worker_dll_path.py',
             'probe_cache_worker_dependencies.py', 'audit_cache_worker_evidence.py']:
    members['producer/' + name] = (out / name).read_bytes()
for path in sorted(out.glob('cache-worker-dll-*')):
    members['environment/' + path.name] = path.read_bytes()
for name in ['cache-worker-dependencies.json', 'cache-worker-runtime-links.json',
             'cache-worker-runtime-cwd.stdout', 'cache-worker-runtime-cwd.stderr',
             'cache-worker-sidecar-list.stdout', 'cache-worker-sidecar-list.stderr',
             'cache-worker-warning-scope.json']:
    members['environment/' + name] = (out / name).read_bytes()

executables = {}
for name in ['motion_render-4e278093648f3252.exe', 'motion_studio-a9ea002b22e1a2a1.exe']:
    path = Path('E:/Dev/aem/.tools/viewer-inspection/native-target/debug/deps') / name
    with path.open('rb') as stream:
        executables[name] = {'bytes': path.stat().st_size,
            'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}
members['summary.json'] = json.dumps({
    'baseline': baseline, 'reports': reports, 'native_executables': executables,
    'evidence_env': {
        'cache-worker-render-corrected': {'MOTION_DRIVER_TASK_EVIDENCE': str(out / 'cache-worker-native-evidence')},
        'cache-worker-desktop-runtime-fixed': {'MOTION_DRIVER_CACHE_LOG_EVIDENCE': str(out / 'cache-worker-desktop-evidence')},
    },
    'limits': ['not automatic application cache-directory integration',
               'not a full desktop, host or render regression',
               'worker IO / independent devices, not independent-process startup timing',
               'controlled blocking is render task state evidence, not a desktop blocked-IO sink test',
               'initial desktop run did not start (STATUS_DLL_NOT_FOUND); existing runtime hardlinks allowed the same EXE to start',
               'no completed global issue #64 claim'],
}, ensure_ascii=False, indent=2).encode('utf-8')
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(members.items())}
members['manifest.json'] = json.dumps(manifest, indent=2).encode('utf-8')
with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for name, entry in manifest.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == entry['sha256']
receipt = {'path': str(target), 'members': len(members), 'bytes': target.stat().st_size,
           'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'reports': reports}
(out / 'cache-worker-evidence-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({key: receipt[key] for key in ['path', 'members', 'bytes', 'sha256']}, ensure_ascii=False))
