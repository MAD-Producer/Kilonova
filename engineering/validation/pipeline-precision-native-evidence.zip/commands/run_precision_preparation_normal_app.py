"""Normal application cold/warm and live precision transitions.

Reuse the existing process/window/transport assertions without relaxing them.
All four public precisions are explicit fixture data, not renderer overrides.
"""
from pathlib import Path

P = Path(__file__).parent
source = (P/'run_current_registry_normal_app.py').read_text(encoding='utf-8')
source = source.split('\nresults=[]')[0]
marker = "        tool('motion_save')\n"
addition = '''        assert s['project']['working_precision'] == project['working_precision'], s['project']['working_precision']
        receipt['precision'] = project['working_precision']
        if pair == 'precision-unorm8':
            transitions = []
            for precision in ['unorm16', 'float16', 'float32', 'unorm8']:
                previous_revision = s['revision']
                edited = tool('motion_edit', {'expectedRevision': previous_revision,
                    'commands': [{'op': 'set_working_precision', 'precision': precision}]})
                assert edited['project']['working_precision'] == precision
                assert edited['revision'] > previous_revision
                s = ready(edited['revision'])
                assert s['project']['working_precision'] == precision
                assert s['preview']['pipelinePreparation']['lookaheadErrors'] == []
                snapshot('switch-'+precision, s)
                image = capture('switch-'+precision, s)
                transitions.append({'precision': precision, 'revision': s['revision'],
                                    'image': image, 'preparation': s['preview']['pipelinePreparation']})
            receipt['transitions'] = transitions
        tool('motion_save')
'''
assert source.count(marker) == 1
source = source.replace(marker, addition)
exec(compile(source, str(Path(__file__)), 'exec'))

results = []
for precision in ['unorm8', 'unorm16', 'float16', 'float32']:
    project['working_precision'] = precision
    cold = run('precision-'+precision, 'cold', True)
    warm = run('precision-'+precision, 'warm', True)
    assert cold['pid'] != warm['pid']
    assert cold['original_fixture_sha256'] == warm['original_fixture_sha256']
    assert cold['startup']['rgba_sha256'] == warm['startup']['rgba_sha256']
    results.extend([cold, warm])
for mode in ['cold', 'warm']:
    control = next(run for run in results if run['precision'] == 'unorm8' and run['kind'] == mode)
    for transition in control['transitions']:
        independent = next(run for run in results if run['precision'] == transition['precision'] and run['kind'] == mode)
        assert transition['image']['rgba_sha256'] == independent['startup']['rgba_sha256'], transition
assert len({run['pid'] for run in results}) == 8
(OUT/'report.json').write_text(json.dumps({'runs': results,
    'scope': 'Eight independent normal desktop processes, all four public precisions cold/warm; eight live precision edits; per-format full RGBA and no foreground pipeline creation'},
    ensure_ascii=False, indent=2), encoding='utf-8')
